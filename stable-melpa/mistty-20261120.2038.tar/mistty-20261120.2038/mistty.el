;;; mistty.el --- Shell/Comint alternative based on term.el -*- lexical-binding: t -*-

;; Copyright (C) 2023-2026 Stephane Zermatten

;; Author: Stephane Zermatten <szermatt@gmx.net>
;; Package-Version: 20261120.2038
;; Package-Revision: 5fa3f4782b21
;; Package-Requires: ((emacs "29.1"))
;; Keywords: convenience, unix
;; URL: http://github.com/szermatt/mistty

;; This program is free software: you can redistribute it and/or
;; modify it under the terms of the GNU General Public License as
;; published by the Free Software Foundation; either version 3 of the
;; License, or (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
;; General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see
;; `http://www.gnu.org/licenses/'.

;;; Commentary:
;;
;; This package defines a major mode for Emacs 29.1 and up that runs a
;; shell inside of a buffer, similarly to comint mode, started with
;; M-x mistty or M-x mistty-create. It is built on top of term.el.
;;
;; For details, see the documentation, at
;; https://mistty.readthedocs.io/en/latest/
;;

(require 'seq)
(require 'subr-x)
(require 'pcase)
(require 'text-property-search)
(require 'fringe)
(require 'cl-lib)
(require 'imenu)
(require 'shell)
(eval-when-compile
  (require 'files-x) ; with-connection-local-variables
  (require 'minibuffer))

(require 'mistty-custom)
(require 'mistty-changeset)
(require 'mistty-accum)
(eval-when-compile
  (require 'mistty-accum-macros))
(require 'mistty-prompt)
(require 'mistty-util)
(require 'mistty-log)
(require 'mistty-queue)
(require 'mistty-scrolline)
(require 'mistty-undo)
(require 'mistty-term)
(require 'mistty-alacritty)
(require 'mistty-eterm)
(require 'mistty-nav)
(require 'nerd-icons nil 'noerror) ;; optional

;;; Code:

(defconst mistty-version "2.3.2snapshot"
  "Mistty package version.")

;; Customization:
(defgroup mistty nil
  "Shell/Comint alternative with a real terminal."
  :group 'shell)

(defvar mistty-all-terminal-types '(eterm alacritty)
  "All known terminal types.

These are all the valid values for `mistty-terminal-type'.")

(defvar mistty-send-last-key-map '(keymap (t . mistty-send-last-key))
  "Keymap that sends everything to the terminal using `mistty-send-last-key'.")

(defvar-keymap mistty-prompt-map
  :doc "Keymap active on the part of `mistty-mode' synced with the terminal.

This map is active only on the portion of a MisTTY mode buffer
that is kept in sync with the terminal. Modifications made on
this portion of the buffer are copied to the terminal, when
possible.

Consider adding key bindings into `mistty-mode-map' instead so
they're always available; this is more straightforward.

If you add key bindings into this map, you might also want to have
access to the same bindings on fullscreen mode, so consider adding
bindings to `mistty-fullscreen-mode-map' as well.

It is used to send most key strokes and some keys directly to the
terminal."

  "RET" #'mistty-send-command
  "TAB" #'mistty-tab-command
  "DEL" #'mistty-backward-delete-char
  "C-d" #'mistty-delete-char
  "C-a" #'mistty-beginning-of-line

  "S-<return>" #'mistty-newline

  ;; While on the prompt, "quoted-char" turns into "send the next
  ;; key directly to the terminal".
  "C-q" mistty-send-last-key-map

  ;; Don't bother capturing single key-stroke modifications and
  ;; replaying them; just send them to the terminal. This works even
  ;; when the terminal doesn't accept editing.
  "<remap> <self-insert-command>" #'mistty-self-insert)

(defvar mistty-send-last-key-map '(keymap (t . mistty-send-last-key))
  "Keymap that forwards everything to`mistty-send-last-key'.")

(define-obsolete-function-alias
  'mistty-forbid-edit-map 'mistty-special-prompt-map "2.1")
(defvar-keymap mistty-special-prompt-map
  :doc "Keymap active when line editing is off.

This map is active on the part of `mistty-mode' synced with the
terminal when of of `mistty-special-prompt-regexps' has been
detected and replay is limited to insert and delete.

In practice, `mistty-special-prompt-regexps' is used to detect shell
search mode, and in such a mode, it's convenient if arrow keys
are sent directly to the terminal."
  "<up>" #'mistty-send-last-key
  "<down>" #'mistty-send-last-key
  "<left>" #'mistty-send-last-key
  "<right>" #'mistty-send-last-key)

(defvar mistty-fullscreen-mode-map
  (let ((map (make-sparse-keymap))
        (esc-map (make-sparse-keymap)))
    (keymap-set map "C-c C-j" #'mistty-toggle)
    (keymap-set map "C-c C-q" #'mistty-capture-keyboard)

    ;; Send C- M- and C-M- <ascii char> to the terminal,
    ;; except for:
    ;;    C-c, C-x, M-x, ESC-[, ESC-O (used in Emacs terminal input)
    ;;
    ;; C-q is handled specially and sends the following key to the
    ;; terminal, so to really send C-q, send C-q C-q
    (dotimes (c 128)
      (unless (memq c '(?\C-c ?\C-x ?\C-q))
        (define-key map (make-string 1 c) 'mistty-send-key)))
    (define-key map "\C-q" '(keymap (t . mistty-send-last-key)))
    (dotimes (c 128)
      (unless (memq c '(?x ?\[ ?O))
        (define-key esc-map (make-string 1 c) 'mistty-send-key)))
    (define-key esc-map "\e" 'mistty-send-key)
    (define-key map (kbd "ESC") esc-map)

    ;; Forward all keys for which a specific translation is known in
    ;; mistty-term-key-map to the terminal with common modifier
    ;; subsets.
    (dolist (type mistty-all-terminal-types)
      (dolist (ev (mistty--term-list-special-keys type))
        (dolist (prefix '("" "S-" "C-" "M-" "C-S-" "M-S-" "C-M-"))
          (define-key map (kbd (format "%s<%s>" prefix ev)) #'mistty-send-key))))

  map)
  "Additional keymap active while fullscreen.

This is in addition to the buffer keymap, `mistty-term-mode-map' for
eterm terminals and `mistty-mode-map' and `mistty-prompt-map' for
alacritty terminals.

By default, the terminal lets through \\[execute-extended-command] (but not ESC x) and key
sequences starting with the prefixes `C-c' and `C-x'.

`C-q' can be used to send these to the terminal. `C-c' `C-q' sends `C-c' and
`C-q' `C-x' sends `C-x'. `C-q' `C-q' sends `C-q'. If you're tired of typing
`C-q', type `C-c' `C-q', which triggers `mistty-capture-keyboard' for a while.

To liberate keys and have Emacs handle them, bind them to nil or remove
them from this map.

To add keys to send to the terminal, bind them to `mistty-send-key'.")

(defvar mistty--report-click-map
  (let ((map (make-sparse-keymap)))
    (define-key map [down-mouse-1] #'mistty-report-mouse-event)
    (define-key map [down-mouse-2] #'mistty-report-mouse-event)
    (define-key map [down-mouse-3] #'mistty-report-mouse-event)
    (define-key map [down-mouse-4] #'mistty-report-mouse-event)
    (define-key map [down-mouse-5] #'mistty-report-mouse-event)
    (define-key map [down-mouse-6] #'mistty-report-mouse-event)
    (define-key map [down-mouse-7] #'mistty-report-mouse-event)
    (define-key map [down-mouse-8] #'mistty-report-mouse-event)
    (define-key map [down-mouse-9] #'mistty-report-mouse-event)
    (define-key map [down-mouse-10] #'mistty-report-mouse-event)
    (define-key map [down-mouse-11] #'mistty-report-mouse-event)
    (define-key map [mouse-1] #'mistty-report-mouse-event)
    (define-key map [mouse-2] #'mistty-report-mouse-event)
    (define-key map [mouse-3] #'mistty-report-mouse-event)
    (define-key map [mouse-4] #'mistty-report-mouse-event)
    (define-key map [mouse-5] #'mistty-report-mouse-event)
    (define-key map [mouse-6] #'mistty-report-mouse-event)
    (define-key map [mouse-7] #'mistty-report-mouse-event)
    (define-key map [mouse-8] #'mistty-report-mouse-event)
    (define-key map [mouse-9] #'mistty-report-mouse-event)
    (define-key map [mouse-10] #'mistty-report-mouse-event)
    (define-key map [mouse-11] #'mistty-report-mouse-event)

    ;; TODO: add wheel up/down, possibly gated by an option

    map)
  "Map added to the terminal zone to report mouse clicks.")

;; Variables:

(defvar mistty-interactive-insert-hook
  (list #'mistty-simulate-self-insert-command)
  "Report interactively inserted text.

This hook is called whenever text that was inserted by
`mistty-self-insert' has been echoed back. It might report a
single character or a large number of characters, depending on
the speed of the terminal and how fast the user types.

This hook is called from the work buffer with the point right
after the inserted text.

This hook is not guaranteed to be called for all interactively
inserted text. If the user is too fast or the shell too slow and
a command gets run that's not `mistty-self-insert' before it was
reported, it just never will be called.

This is meant to be used to allow interactive completion or
suggestions to work in MisTTY, with a little work, as a
replacement of the usual approach, which is to track
`self-insert-command' in post-command hooks. Such an approach
doesn't work in the terminal region as typed characters usually
get echoed back to buffer outside of any command.

By default, this calls the function
`mistty-simulate-self-insert-command', which does nothing unless
the option variable `mistty-simulate-self-insert-command' is
non-nil.")

(defvar mistty-after-process-start-hook nil
  "Report that the MistTTY process started.

This hook is called from the MisTTY buffer just after the shell
process has been started and attached to the MisTTY window. The process
is available in `mistty-proc`. Note that the process might not have
output anything yet; the buffer is likely empty.")

(defvar mistty-after-process-end-hook (list #'mistty--at-end)
  "Report that the MisTTY process ended.

This hook is called with PROC as an argument from
the MisTTY buffer just after the shell process ended. PROC is
guaranteed to be a dead process. Its status can be checked with
`process-status`.

At the point this hook is called `mistty-proc` is already unset.

Note that this hook might never be called, in particular when the
MisTTY buffer is killed while the process is still running.

This hook can be used to kill the buffer after the shell ended
successfully. See `mistty-kill-buffer` and
`mistty-kill-buffer-and-window`.")

(defvar mistty-entered-fullscreen-hook
  '(mistty-keymap-auto)
  "Report that MisTTY just entered fullscreen mode.

At the point this hook is called, `mistty-fullscreen` is non-nil.

The default value reverts the effect of `mistty-toggle-keymap', so the
keymap switch doesn't look \"sticky\".")

(defvar mistty-left-fullscreen-hook
  '(mistty-exit-capture-keyboard mistty-keymap-auto)
  "Report that MisTTY just left fullscreen mode.

At the point this hook is called, `mistty-fullscreen` is nil.

The default value reverts the effect of `mistty-toggle-keymap' and
`mistty-capture-keyboard'.")

(defvar-local mistty-proc nil
  "The process that controls the terminal, usually a shell.")

(defvar-local mistty-fullscreen nil
  "Whether MisTTY is in full-screen mode.

This variable is non-nil when the alt buffer is used by the terminal, in
which case prompt detection is turned off and the terminal is displayed
in its entirety in the work buffer.

This variable is available in both the work buffer and the term
buffer.")

(defvar-local mistty-goto-cursor-next-time nil
  "Controls whether the point should be moved to the cursor.

If t, this variable tells `mistty--refresh' that it should move
the point to the cursor next time it copies the state of the
terminal to the work buffer.

If \\='off, this variable tells `mistty--refresh' not to move the
point to the cursor, even if it would normally do it.

If nil, this variable lets `mistty-refresh' do what it think is
best.

This variable is available in the work buffer.")

(defvar-local mistty--term nil
  "The current terminal instance.

This variable is available in both the work buffer and the term
buffer.")

(defvar-local mistty--queue nil
  "A queue of data to send to the process; a `mistty--queue' struct.

See mistty-queue.el.")

(defvar-local mistty-sync-marker nil
  "Marker for the start of the terminal region.")

(defvar-local mistty--last-prompt-considered -1
  "Scrolline of the last rejected possible prompt.")

(defconst mistty--prompt-regexp
  "[^[:alnum:][:cntrl:][:blank:]][[:blank:]]$"
  "Regexp used to identify possible prompts.

New, empty lines that might be prompts are evaluated against this
regexp. This regexp should match something that looks like the
end of a prompt with no commands.")

(defvar-local mistty--sync-ov nil
  "An overlay that covers the region [`mistty-sync-marker', `(point-max)'].

This overlay covers the region of the work buffer that's
currently kept in sync with the terminal. MisTTY tries to send
any modifications made to this region to the terminal for
processing. Such modification might be rejected and eventually
undone, accepted or accepted with modifications.

The special keymap `mistty-prompt-map' is active when the pointer
is on this overlay.

This variable is available in the work buffer.")

(defvar-local mistty--old-point nil
  "The position of the point captured in `pre-command-hook'.

It is used in the `post-command-hook'.

This variable is available in the work buffer.")

(defvar-local mistty--inhibit-refresh nil
  "When non-nil, prevent `mistty--refresh' from copying data.

When this variable is true, `mistty--refresh' does nothing
unless it is forced; it just sets
`mistty--need-refresh'. This is useful to temporarily
prevent changes to the terminal to be reflected to the work
buffer and shown to the user.

This variable is available in the work buffer.")

(defvar-local mistty--need-refresh nil
  "If true, the work buffer is known to be out-of-date.

This variable is set by `mistty--refresh' when copying data
from the terminal to the work buffer is disabled. It signals that
`mistty--refresh' should be called after setting
`mistty--refresh' to true again.

This variable is available in the work buffer.")

(defvar-local mistty--truncate-timer nil
  "An idle timer that'll truncate the buffer.

Truncation is configured by `mistty-buffer-maximum-size'.")

(defvar-local mistty--check-window-size-timer nil
  "An idle timer that checks window height on graphical displays.

Since line height isn't fixed on graphical displays, it might be
necessary to resize the process window depending on its content.")

(defvar-local mistty--special-prompt nil
  "Non-nil when normal editing is not available.

This is controlled by `mistty-special-prompt-regexp'.

When this is set, MisTTY assumes that typing and deletion work,
but moving the cursor doesn't. This allows replaying some simple
editing commands, such as a `yank' or a `backward-kill-word'.")

(defvar-local mistty--inhibit nil
  "When non-nil, inhibit communication with the terminal.

Normally, MisTTY allows normal Emacs operations during a command,
then replays any changes in the post-command hook. With this
variable set, MisTTY allows normal Emacs operations during a
chain of commands. Replay, refresh and even `mistty-prompt-map'
are suppressed.

This is used to allow longer-running, interactive commands such
as filling templates to run without interference from the shell
until the end.

This is a list of symbols, that represent the reason why normal
operations are inhibited. This allows dealing with more than one
running command at a time.")

(defvar mistty--inhibit-fake-nl-cleanup nil
  "Inhibit deletion of fake newline when moving the sync marker.

Normally, fake newlines are removed by `mistty--set-sync-mark',
when the terminal zone is moved, so they don't confuse cursor
movements.

Setting this variable to non-nil inhibit this behavior, which
might be useful in tests, to avoid tests being confused when
old positions are invalidated")

(defvar-local mistty--ignored-overlays nil
  "Foreign overlays that should just be ignored.

Normally, overlays are seen as a sign that there is a
long-running command and MisTTY lets it run until without
replaying the change. The overlays on this list must not be taken
as a sign that there is a long-running command.")

(defvar-local mistty--self-insert-line nil
  "Capture of the last string of self-inserted characters.

The first element is the distance from bol to the current point.
The second element is a list to which characters are pushed (this
means that most recent characters appear first.)

Whenever a character is inserted by `mistty-self-insert', it is added
to this. When a character or a series of such self-inserted character
is echoed back, call `mistty-interactive-insert-hook'.")

(defvar mistty-chain-start nil
  "The buffer that was current at the start of the `mistty' chain.

The `mistty' command is meant to be called multiple times, to
iterate through multiple buffers and possibly eventually creating
a new one. In such a scenario, it's useful to keep track of the
buffer `mistty' was called for the first time, so inherit the
`default-directory' of that buffer and possibly use TRAMP to
connect to the same host.")

(defvar-local mistty--interacted nil
  "Non-nil if there was a successful interaction in this session.

This is used by `mistty-kill-buffer' and `mistty-kill-buffer-and-window'
to decide whether it's OK to kill the buffer.")

(defvar-local mistty--terminal-size nil
  "If non-nil, a (cons WIDTH HEIGHT) that specify the terminal size.

When non-nil, tracking window size change is disabled.")

(defvar-local mistty--can-move-vertically nil
  "If non-nil, vertical moves are allowed.")

(defvar-local mistty--pickup-changes-timer nil
  "Idle timer that will call `mistty--pickup-changes'.")

(defvar-local mistty--cursor nil
  "Position of the cursor on the work buffer.

This is updated after each refresh.")

(defvar-local mistty--report-focus nil
  "Report focus in/out events if non-nil.")

(defvar-local mistty--focused nil
  "Non-nil if there is at least one buffer window with focus.")

(defvar-local mistty--mouse-reporting nil
  "Whether mouse events should be reported to the terminal.

This is t if mouse reporting was requested by the application, in
`mistty--mouse-reporting-requested', and is enabled.")

(defvar-local mistty--mouse-reporting-requested nil
  "Which mouse events were requested by the application.

It is either:

- nil, mouse reporting is deactivated.
- \\='click, report press and release events.
- \\='drag, report press, release, and mouse movement with pointer down.
- \\='motion, report all mouse events.")

(defconst mistty-min-terminal-width 8
  "Minimum terminal width.

Width smaller than that will not be accepted as terminal size and will
be ignored if coming from window size.")

(defconst mistty-min-terminal-height 4
  "Minimum terminal height.

Height smaller than that will not be accepted as terminal size and will
be ignored if coming from window size.")

(defconst mistty--secondary-mode-alist
   '((dead :tag dead
           :help "Process is dead")
     (running :tag running
              :help "Process running"
              :map prompt-map
              :button menu)
     (prompt :tag prompt
             :help "Prompt detected"
             :map prompt-map
             :button menu)
     (off :tag off
          :help "Emacs command executing"
          :map prompt-map
          :button exit-command)
     (special-prompt :tag special-prompt
                     :help "Special prompt detected, capturing special-prompt"
                     :map special-prompt-map
                     :button menu)
     (full :tag full
           :help "Fullscreen command running"
           :map fullscreen-mode-map
           :button menu)
     (capture :tag capture
              :help "Keyboard capture"
              :button exit-capture))
   "Secondary mode ID and map.

Each element is a plist that defines the associated overlay keymap, the
tag as well as the help message and button to be shown in the modeline
when the mode is active.

Secondary mode is detected by `mistty--secondary-mode' and the
map and mode line installed by `mistty--update-secondary-mode'")

;; optional nerd-icons integration
(defvar nerd-icons-mode-icon-alist) ;; defined by nerd-icons
(when (featurep 'nerd-icons)
  (unless (alist-get 'mistty-mode nerd-icons-mode-icon-alist)
    (setf (alist-get 'mistty-mode nerd-icons-mode-icon-alist)
          '(nerd-icons-devicon "nf-dev-terminal" :face nerd-icons-purple)))

  (setf (alist-get 'nerd-icons mistty-tag-alist-alist)
        `((dead . (nerd-icons-mdicon "nf-md-robot_dead_outline"))
          (running . (nerd-icons-mdicon "nf-md-robot_happy_outline"))
          (prompt . ">_")
          (off . (nerd-icons-mdicon "nf-md-robot_outline"))
          (special-prompt . (nerd-icons-mdicon "nf-md-arrow_all"))
          (full . (nerd-icons-mdicon "nf-md-fit_to_screen_outline"))
          (capture . (nerd-icons-mdicon "nf-md-keyboard"))
          (keyboard . (nerd-icons-mdicon "nf-md-keyboard_outline"))
          (keyboard-inactive . (nerd-icons-mdicon "nf-md-keyboard_off_outline"))
          (mouse . (nerd-icons-mdicon "nf-md-mouse"))
          (mouse-inactive . (nerd-icons-mdicon "nf-md-mouse_off")))))

(defconst mistty--mode-line-button-alist
  `((menu :menu mistty--secondary-mode-menu :help "Show menu")
    (exit-command :command mistty-ignore-long-running-command :help "Force exit of emacs command mode")
    (exit-capture :command mistty-exit-capture-keyboard :help "End keyboard capture")
    (keyboard :command mistty-toggle-keymap :help "Toggle fullscreen keyboard")
    (mouse :command mistty-toggle-mouse :help "Toggle mouse reporting"))
  "Button available in the mode-line.

Normally accessed using `mistty--mode-line-button'.

Entries in this list define buttons whose ID is referenced from
`mistty--secondary-mode-alist'.")

(defvar-local mistty--secondary-mode-map-override nil
  "Temporarily override the :map tag of `mistty--secondary-mode-alist'.

This is only valid for modes that have a non-nil :map tag.")

(defun mistty--add-secondary-mode-menu (map)
  "Add menu items to MAP related to secondary mode and keymaps."
  ;; Note that items are defined in reverse order

  (define-key
   map [mistty-mouse]
   '(menu-item "Mouse Reporting"
               mistty-toggle-mouse
               :visible mistty--mouse-reporting-requested
               :button (:toggle . mistty--mouse-reporting)))
  (define-key
   map [mistty-capture]
   '(menu-item "Capture Keyboard" mistty-capture-keyboard))
  (define-key map [mistty-separator-1] '(menu-item "--"))
  (define-key
   map [mistty-fullscreen]
   '(menu-item
     "Fullscreen Keymap"
     mistty-toggle-keymap
     :enable (not (eq 'fullscreen-mode-map (mistty--secondary-mode-map)))
     :button (:radio . (eq 'fullscreen-mode-map (mistty--secondary-mode-map)))
     :help "mistty-fullscreen-mode-map"))
  (define-key
   map [mistty-prompt]
   '(menu-item
     "Prompt Keymap" mistty-toggle-keymap
     :enable (eq 'fullscreen-mode-map (mistty--secondary-mode-map))
     :button (:radio . (not (eq 'fullscreen-mode-map (mistty--secondary-mode-map))))
     :help "mistty-prompt-map")))

(defvar mistty--secondary-mode-menu
  (let ((map (make-sparse-keymap "MisTTY")))
    (mistty--add-secondary-mode-menu map)

    map))

(defvar mistty-mode-menu
  (let ((map (make-sparse-keymap "MisTTY")))

    (define-key map [mistty-mistty-about] '(menu-item "About" mistty-about))
    (define-key map [mistty-separator-0] '(menu-item "--"))

    (define-key map [mistty-size-track-windows]
                '(menu-item "Terminal Size Tracks Window"
                            mistty-toggle-size-tracks-window
                            :button (:toggle . (mistty-terminal-size-tracks-window-p))))

    (define-key map [mistty-fit-to-window]
                '(menu-item "Fit Terminal to Window"
                            mistty-fit-to-window))
    (define-key map [mistty-grow-vertically]
                '(menu-item "Grow Terminal Vertically"
                            mistty-grow-vertically
                            :visible mistty-fullscreen))
    (define-key map [mistty-shrink-vertically]
                '(menu-item "Shrink Terminal Vertically"
                            mistty-shrink-vertically
                            :visible mistty-fullscreen))
    (define-key map [mistty-set-terminal-size]
                '(menu-item "Set Terminal Size"
                            mistty-set-terminal-size))

    (define-key map [mistty-separator-1] '(menu-item "--"))

    (mistty--add-secondary-mode-menu map)

    ;; Note that items are defined in reverse order
    ;;
    ;; This extends the menu built in mistty--secondary-mode-menu
    (define-key map [mistty-separator-2] '(menu-item "--"))

    (define-key map [mistty-create-buf]
                '(menu-item "New Buffer With Output" mistty-create-buffer-with-output))
    (define-key map [mistty-next-output]
                '(menu-item "Next Output" mistty-next-output))
    (define-key map [mistty-prev-output]
                '(menu-item "Prev Output" mistty-previous-output))

    (define-key map [mistty-separator-3] '(menu-item "--"))

    (define-key map [mistty-exit-command]
                '(menu-item "Exit Command"
                            mistty-ignore-long-running-command
                            :enable mistty--inhibit))
    (define-key map [mistty-clear]
                '(menu-item "Clear" mistty-clear))
    (define-key map [mistty-go-to-scrollback]
                '(menu-item "Go to Scrollback" mistty-toggle
                            :visible (and (>= (point) mistty-sync-marker)
                                          (> mistty-sync-marker (point-min)))))
    (define-key map [mistty-go-to-terminal]
                '(menu-item "Go to Terminal" mistty-toggle
                            :visible (and mistty-proc
                                          (< (point) mistty-sync-marker))))

    map))

(defvar-keymap mistty-mode-map
  :doc "Keymap of `mistty-mode'.

This map is active whenever the current buffer is in MisTTY mode."
  "C-c C-n" #'mistty-next-output
  "C-c C-p" #'mistty-previous-output
  "C-c C-l" #'mistty-clear
  "C-c C-r" #'mistty-create-buffer-with-output
  "C-c C-o" #'mistty-select-output
  "C-c C-j" #'mistty-toggle
  "C-c C-q" #'mistty-capture-keyboard
  "C-c C-k" #'mistty-toggle-keymap
  "C-c C-a" #'mistty-toggle-mouse
  "C-c C-s" #'mistty-sudo
  "C-c C-f" #'mistty-fit-to-window
  "C-c C-t" #'mistty-toggle-size-tracks-window
  "C-c <" #'mistty-shrink-vertically
  "C-c >" #'mistty-grow-vertically
  "C-e" #'mistty-end-of-line-or-goto-cursor

  ;; mistty-send-last-key makes here some globally useful keys
  ;; available in mistty-mode buffers. More specific keys can be
  ;; input using C-q while mistty-prompt-map is active.
  "C-c C-c" #'mistty-send-last-key
  "C-c C-z" #'mistty-send-last-key
  "C-c C-\\" #'mistty-send-last-key
  "C-c C-g" #'mistty-send-last-key
  ;;   when adding a new entry above, update mistty-term-mode-map and
  ;;   mistty-alacritty-mode-map, too.

  ;; Bind history search backward, previous history and next history
  ;; to meta keys, like comint does.
  "M-r" #'mistty-send-C-r
  "M-p" #'mistty-send-C-p
  "M-n" #'mistty-send-C-n
  "M-<up>" #'mistty-send-C-p
  "M-<down>" #'mistty-send-C-n
  "M-." #'mistty-send-key

  "<menu-bar> <mistty-mode-menu>" (cons "MisTTY" mistty-mode-menu))

(define-derived-mode mistty-mode fundamental-mode "misTTY" "Line-based TTY."
  :interactive nil
  (setq buffer-read-only nil)

  (setq mistty--send-function #'mistty--send-for-mistty-mode)
  (setq mistty--translate-key-function #'mistty--translate-key)

  ;; scroll down only when needed. This typically keeps the point at
  ;; the end of the window. This seems to be more in-line with what
  ;; commands such as more expect than the default Emacs behavior.
  (setq-local scroll-conservatively 1024)
  (setq-local window-point-insertion-type t)
  (setq-local scroll-margin 0)

  (add-hook 'pre-redisplay-functions #'mistty--cursor-skip nil t)
  (add-hook 'completion-in-region-mode-hook #'mistty--detect-completion-in-region nil t)
  (add-function :after after-focus-change-function #'mistty--check-frame-focus)
  (add-hook 'window-selection-change-functions #'mistty--check-window-focus nil t)
  (add-hook 'window-selection-change-functions #'mistty--set-notrack-cursor nil t)
  (add-hook 'window-buffer-change-functions #'mistty--check-window-focus nil t)

  (setq mistty--cursor (copy-marker (point-min)))
  (setq mistty-sync-marker (point-max-marker))
  (mistty--init-scrolline mistty-sync-marker 0)
  (setq mistty--sync-ov (make-overlay mistty-sync-marker (point-max) nil nil 'rear-advance))
  (overlay-put mistty--sync-ov 'wrap-prefix "")
  (overlay-put mistty--sync-ov 'line-number-disable t)
  (setq mistty--ignored-overlays (list mistty--sync-ov))
  (setq-local mistty--prompt-cell (mistty--make-prompt-cell))
  (setq-local beginning-of-defun-function #'mistty-beginning-of-defun)
  (setq-local end-of-defun-function #'mistty-end-of-defun)
  (setq-local imenu-create-index-function #'mistty-imenu-create-index)
  (setq-local imenu-sort-function nil) ;; keep imenu entries in order

  (add-hook 'mistty-start-capture-keyboard-hook
            #'mistty--update-secondary-mode nil t)
  (add-hook 'mistty-end-capture-keyboard-hook
            #'mistty--update-secondary-mode nil t)
  (mistty--update-secondary-mode)

  (when mistty-fringe-enabled
    (mistty-fringe-mode 'on)))
(put 'mistty-mode 'mode-class 'special)

(define-minor-mode mistty-fringe-mode
  "Highlight the synced region with a left fringe or margin.

This makes the synced region visible, which is useful as
modifications made inside of the synced region are treated
differently from modifications made inside of the synced region."
  :init-value nil
  (unless (derived-mode-p 'mistty-mode)
    (error "Mistty-fringe-mode only meaningful on MisTTY buffers"))
  (if mistty-fringe-mode
      ;; turn on
      (if (window-system)
          ;; implemented as a left fringe
          (progn
            (unless (fringe-bitmap-p 'mistty-bar)
              (define-fringe-bitmap
                'mistty-bar (make-vector 40 7) nil 3 'center))
            (overlay-put
             mistty--sync-ov
             'line-prefix
             (propertize " " 'display
                         '(left-fringe mistty-bar mistty-fringe-face))))
        ;; implemented as a left margin
        (progn
          (setq left-margin-width 1)
          (overlay-put
           mistty--sync-ov
           'line-prefix
           (propertize " " 'display
                       `((margin left-margin)
                         ,(propertize "┃" 'face 'mistty-fringe-face))))))
    ;; turn off
    (unless (window-system)
      (setq left-margin-width (default-value 'left-margin-width)))
    (overlay-put mistty--sync-ov 'line-prefix nil)))

(defun mistty--check-major-mode ()
  "Asserts that the current buffer is the work buffer."
  (unless (eq 'mistty-mode major-mode)
    (error "MisTTY buffer required, got %s" major-mode)))

(defsubst mistty--require-proc ()
  "Asserts that the current buffer has a live process."
  (unless (process-live-p mistty-proc) (error "No running process")))

(cl-defun mistty-exec (program &key width height)
  "Execute PROGRAM in the current buffer.

Buffer must be a `mistty-mode' buffer. If it is already running a
program, it is replaced with the new one.

PROGRAM can be either a string or a list. If it is a string, it
should be the name of an executable to run, without arguments. If
it is a list, it should be a list of executable and its
arguments.

WIDTH and HEIGHT, if specified, are used as the initial dimensions of
the terminal. When not specified and `mistty-default-terminal-size' is
nil, the dimension of the terminal is taken from the window showing the
current buffer or, if the buffer isn't displayed yet, the selected
window."
  (unless (derived-mode-p 'mistty-mode)
    (error "Not a mistty-mode buffer"))

  (when mistty--term
    (mistty--term-delete mistty--term))
  (erase-buffer)
  (setq mistty--scrolline-home-num 0)

  (let ((command (if (consp program) (car program) program))
        (args (if (consp program) (cdr program) nil)))
    (when (and mistty-default-terminal-size
               (null width)
               (null height))
      (setq width (car mistty-default-terminal-size))
      (setq height (cdr mistty-default-terminal-size)))

    (if (or width height)
        (progn
          (mistty--check-terminal-size width height)
          (setq-local mistty--terminal-size (cons width height)))

      (setq-local mistty--terminal-size nil)
      (let ((win (or (get-buffer-window (current-buffer))
                     (selected-window))))
        (setq width (mistty--terminal-width-from-window win))
        (setq height (mistty--terminal-height-from-window win))))
    (let ((work-buffer (current-buffer))
          success) ; clean up work buffer unless setup succeeds
      (unwind-protect
          (let* ((term (mistty--create-term
                        (or mistty-terminal-type
                            (if (mistty-alacritty-load 'noerror)
                                'alacritty
                              'eterm))
                        (concat " mistty tty " (buffer-name))
                        (cons command args)
                        :width width
                        :height height
                        :prompt-cell mistty--prompt-cell
                        :enter-fullscreen
                        (lambda ()
                          (mistty--enter-fullscreen work-buffer))
                        :leave-fullscreen
                        (lambda ()
                          (mistty--leave-fullscreen work-buffer))
                        :after-clear-screen
                        (lambda ()
                          (mistty--with-live-buffer work-buffer
                            (mistty--scroll-after-clear)))
                        :clear-scrollback
                        (lambda ()
                          (mistty--with-live-buffer work-buffer
                            (mistty--clear-scrollback)))
                        :after-reset
                        (lambda ()
                          (mistty--with-live-buffer work-buffer
                            (when mistty-fullscreen
                              (mistty--leave-fullscreen work-buffer))
                            (mistty--cancel-queue mistty--queue)
                            (mistty--release-all-changesets)
                            (setq mistty--inhibit-refresh nil)
                            (setq mistty-bracketed-paste nil)
                            (mistty--scroll-after-clear)))
                        :sync-scrolline
                        (lambda ()
                          (mistty--with-live-buffer work-buffer
                            mistty--scrolline-home-num))
                        :show-cursor
                        (lambda (show)
                          (mistty--with-live-buffer work-buffer
                            (if show
                                (mistty--show-cursor)
                              (mistty--hide-cursor))))
                        :report-focus
                        (lambda (report)
                          (mistty--with-live-buffer work-buffer
                            (unless (eq (not (not report))
                                        (not (not mistty--report-focus)))
                              (setq mistty--report-focus (not (not report)))
                              (mistty--report-focus))))
                        :request-report-mouse
                        (lambda (val)
                          (mistty--with-live-buffer work-buffer
                            (mistty--request-mouse-reporting val)))))
                 (accum (process-filter (mistty--term-proc term))))
            (mistty--add-sync-buffers accum work-buffer)
            (mistty--attach term)
            (mistty--check-buffer-focus (current-buffer))
            (mistty--wrap-capf-functions)
            (mistty--update-secondary-mode)
            (run-hooks 'mistty-after-process-start-hook)
            (setq success t))
        (unless success
          (kill-buffer work-buffer))))))

(defun mistty--request-mouse-reporting (val)
  "Set mouse reporting VAL.

VAL can be either:

- nil, mouse reporting is deactivated.
- \\='click, report press and release events.
- \\='drag, report press, release, and mouse movement with pointer down.
- \\='motion, report all mouse events."
  (when (and (null val)
             (when-let* ((prompt (mistty--active-prompt)))
               (mistty--prompt-click-events prompt)))
    ;; Mouse reporting cannot go lower than click as long as there is
    ;; an active prompt with click-events enabled.
    (setq val 'click))
  (unless (eq (null val) (null mistty--mouse-reporting-requested))
    (setq mistty--mouse-reporting
          (if (and val mistty-allow-mouse-reporting)
              t
            nil)))
  (setq mistty--mouse-reporting-requested val)
  (mistty-log "Mouse reporting: %s enabled: %s"
              val mistty--mouse-reporting)

  (mistty--update-secondary-mode))

(defun mistty--attach (term)
  "Attach the current `mistty-mode' buffer to TERM."
  (let ((work-buffer (current-buffer))
        (proc (mistty--term-proc term)))
    (setq mistty--term term)
    (setq mistty-proc proc)
    (setq mistty--queue (mistty--make-queue proc))
    (setq mistty-goto-cursor-next-time t)
    (mistty--needs-refresh)
    (set-process-sentinel
     proc
     (lambda (proc msg)
       (mistty--process-sentinel term work-buffer proc msg)))
    (add-hook 'kill-buffer-hook
              (lambda ()
                (mistty--term-delete term))
              nil t)
    (mistty--add-replay-hooks)

    (if-let* ((size mistty--terminal-size))
        (mistty--set-process-window-size (car size) (cdr size))
      (add-hook 'window-size-change-functions #'mistty--window-size-change nil t)
      ;; window sizes might not be reliable without a redisplay
      (redisplay t)
      (mistty--set-process-window-size-from-windows))))

(defun mistty--create-or-reuse-marker (m initial-pos)
  "Create the marker M set to INITIAL-POS or move it to that position.

Returns M or a new marker."
  (if (not (markerp m))
      (copy-marker initial-pos)
    (when (= 1 (marker-position m))
      (move-marker m initial-pos))
    m))

(defun mistty--detach ()
  "Detach the current `mistty-mode' buffer from its process."
  (mistty--check-major-mode)

  (mistty--remove-replay-hooks)
  (remove-hook 'window-size-change-functions #'mistty--window-size-change t)

  (when mistty--queue
    (mistty--cancel-queue mistty--queue)
    (setq mistty--queue nil))
  (mistty--release-all-changesets)
  (setq mistty-proc nil))

(defun mistty--add-replay-hooks ()
  "Register hooks for tracking and replaying changes."
  (add-hook 'before-change-functions #'mistty--before-change-on-work nil t)
  (add-hook 'after-change-functions #'mistty--after-change-on-work nil t)
  (add-hook 'pre-command-hook #'mistty--pre-command nil t)
  (add-hook 'post-command-hook #'mistty--post-command-undo nil t)
  (add-hook 'post-command-hook #'mistty--post-command-cursor nil t)
  (add-hook 'post-command-hook #'mistty--post-command-quit nil t)
  (add-hook 'post-command-hook #'mistty--post-command-schedule 10 t))

(defun mistty--remove-replay-hooks ()
  "Unregister hooks for tracking and replaying changes."
  (remove-hook 'before-change-functions #'mistty--before-change-on-work t)
  (remove-hook 'after-change-functions #'mistty--after-change-on-work t)
  (remove-hook 'pre-command-hook #'mistty--pre-command t)
  (remove-hook 'post-command-hook #'mistty--post-command-undo t)
  (remove-hook 'post-command-hook #'mistty--post-command-quit t)
  (remove-hook 'post-command-hook #'mistty--post-command-cursor t)
  (remove-hook 'post-command-hook #'mistty--post-command-schedule t))

(defun mistty-buffer-p (buffer)
  "Return the BUFFER if the buffer is a MisTTY buffer."
  (and
   (buffer-live-p buffer)
   (eq (buffer-local-value 'major-mode buffer) 'mistty-mode)

   buffer))

(defun mistty-live-buffer-p (buffer)
  "Return the BUFFER if the buffer is a live MisTTY buffer.

The process attached to the buffer must be live."
  (and
   (mistty-buffer-p buffer)
   (buffer-local-value 'mistty-proc buffer)
   (process-live-p (buffer-local-value 'mistty-proc buffer))

   ;; return
   buffer))

(defun mistty-list-live-buffers (&optional accept-buffer)
  "List of live MisTTY buffers, sorted.

ACCEPT-BUFFER, if specified, must be a function that takes in a
buffer and return non-nil if that buffer should be taken into
account by this command."
  (let ((cond #'mistty-live-buffer-p))
    (when accept-buffer
      (setq cond (lambda (buf) (when (and (mistty-live-buffer-p buf)
                                          (funcall accept-buffer buf))
                                 buf))))
    (sort (delq nil (mapcar cond (buffer-list)))
          (lambda (a b)
            (string< (buffer-name a) (buffer-name b))))))

;;;###autoload
(defun mistty (&optional other-window accept-buffer)
  "Go to the next MisTTY buffer, or create a new one.

The first time this command is called, it creates a new MisTTY
buffer. Afterwards, this command goes to a MisTTY buffer. If
already on a MisTTY buffer, go to the next one or create another
one.

If called with an argument, create a new buffer unconditionally,
so you can call `mistty' multiple times to visit existing MisTTY
buffers, and then, if it turns out to be necessary, call it a
final time with an argument to create a new one.

When creating a new buffer, the `default-directory' of that
buffer is taken from the buffer from which the chain of calls
`mistty' was started.

If OTHER-WINDOW is nil, execute the default action configured by
`display-comint-buffer-action'. If OTHER-WINDOW is a function, it is
passed to `pop-to-buffer` to be used as a `display-buffer' action.
Otherwise, display the buffer in another window.

    You might prefer configuring `display-buffer-alist' for
    comint category buffers to get the exact behavior you want instead
    of passing OTHER-WINDOW.

Passing ACCEPT-BUFFER is deprecated. Call `mistty-cycle-or-create'
instead. See that function for details on that argument.

    This function is for interactive use only. When building similar
    commands, call `mistty-cycle-or-create' instead."
  (interactive)
  (when (not (eq this-command last-command))
    (setq mistty-chain-start (current-buffer)))

  (mistty-cycle-or-create
   accept-buffer
   (lambda (other-window)
     (if mistty-chain-start
       (with-current-buffer mistty-chain-start
         (mistty-create nil other-window))
       (mistty-create nil other-window)))
   other-window))

(defun mistty-cycle-or-create (accept-buffer create-buffer other-window)
  "Cycle through existing buffers, creating one if necessary.

This function implements the behavior of `mistty' in a configurable way.

The first time this command is called, it creates a new MisTTY
buffer. Afterwards, this command goes to a MisTTY buffer. If
already on a MisTTY buffer, go to the next one or create another
one.

ACCEPT-BUFFER, if specified, must be a function that takes in a live
MisTTY buffer and return non-nil if that buffer should be taken into
account as existing buffer by this command. This can be used to manage
distinct group of buffers, such as buffers belonging to different
projects.

CREATE-BUFFER must be a function that creates a new buffer. It takes a
single argument, OTHER-WINDOW. It must return the newly created buffer.

If OTHER-WINDOW is nil, execute the default action configured by
`display-comint-buffer-action' to pop to the existing or newly-created
buffer. If OTHER-WINDOW is a function, it is passed to `pop-to-buffer`
to be used as a `display-buffer' action. Otherwise, display the buffer
in another window.

    You might prefer configuring `display-buffer-alist' for
    comint category buffers to get the exact behavior you want
    instead of passing OTHER-WINDOW."
  (let ((existing (mistty-list-live-buffers accept-buffer)))
    (if (or current-prefix-arg         ; command prefix was given
            (null existing)            ; there are no mistty buffers
            (and (null (cdr existing)) ; the current buffer is the only mistty buffer
                 (eq (current-buffer) (car existing))))
        (funcall create-buffer other-window)
      (mistty--goto-next existing other-window))))

;;;###autoload
(defun mistty-other-window ()
  "Go to the next MisTTY buffer in another window.

    You might prefer configuring `display-buffer-alist' for
    comint category buffers and calling `mistty' directly to get
    the exact behavior you want instead of using
    `mistty-other-window'.

    This function is for interactive use only. When building similar
    commands, consider calling `mistty-cycle-or-create' instead."
  (interactive)
  (mistty 'other-window))

(defun mistty--goto-next (existing &optional other-window)
  "Go to the next buffer in EXISTING, skipping the current one.

If OTHER-WINDOW is non-nil, put the buffer into another window."
  (let ((existing-tail (or (cdr (member (current-buffer) existing))
                           existing)))
    (if existing-tail
        (mistty--pop-to-buffer (car existing-tail) other-window)
      (user-error "No next mistty buffer"))))

(defun mistty--pop-to-buffer (buf other-window)
  "Display BUF.

If OTHER-WINDOW is nil, execute the default action configured by
`display-comint-buffer-action'. If OTHER-WINDOW is a function, it
is passed to `pop-to-buffer` to be used as a `display-buffer'
action. Otherwise, display the buffer in another window."
  (pop-to-buffer
   buf
   (cond
    ((functionp other-window) other-window)
    (other-window #'display-buffer-pop-up-window)
    (t (bound-and-true-p display-comint-buffer-action)))))

;;;###autoload
(defun mistty-create (&optional command other-window)
  "Create a new MisTTY buffer, running a shell.

The shell that is run can be configured by setting
`mistty-shell-command', `explicit-shell-file-name',
`shell-file-name' or come implicitly from the ESHELL or SHELL
environment variables.

Set COMMAND to specify instead the command to run for the current
call. COMMAND can be either a string or a list. If it is a
string, it should be the name of an executable to run, without
arguments. If it is a string, it should be a list of executable
and its arguments.

If this command is called with no prefix arg, it is executed in
the `default-directory' of the current buffer. If that directory
is a remote file, and if the TRAMP method supports it, the
command is executed on the remote host. This also works for
same-host methods, such as sudo. See Info node `(mistty)Remote
Shells with TRAMP' for details.

If this command is called with a prefix arg, it asks for the
value of `default-directory'. This is useful if you want start a
shell to a remote host without opening a file first.

If OTHER-WINDOW is nil, execute the default action configured by
`display-comint-buffer-action'. If OTHER-WINDOW is a function, it
is passed to `pop-to-buffer` to be used as a `display-buffer'
action. Otherwise, display the buffer in another window.

Upon success, the function returns the newly-created buffer."
  (interactive)
  (let* ((default-directory
          (or (and (memq this-command '(mistty-create mistty-create-other-window))
                   current-prefix-arg
                   (mistty--read-default-directory))
              default-directory))

         (buf (generate-new-buffer " *mistty-new"))
         (command (or command
                      (with-current-buffer buf
                        (with-connection-local-variables
                         (or
                          mistty-shell-command
                          explicit-shell-file-name
                          shell-file-name
                          (getenv "ESHELL")
                          (getenv "SHELL")))))))
    (with-current-buffer buf
      (setq-local mistty-shell-command command)
      (rename-buffer (mistty--generate-new-buffer-name (mistty-new-buffer-name)))
      (mistty-mode))
    ;; Note that it's important to attach the buffer to a window
    ;; before executing the command, so that the shell known the size
    ;; of the terminal from the very beginning.
    (mistty--pop-to-buffer buf other-window)
    (with-current-buffer buf (mistty-exec command))
    buf))

(defun mistty--generate-new-buffer-name (bufname)
  "Generate a unique buffer name based on BUFNAME.

If `mistty-force-reuse-buffer-name' is non-nil, this function might kill
dead MisTTY buffers to reuse their name."
  (if (or (not mistty-force-reuse-buffer-name)
          (string-prefix-p " " bufname))
      (generate-new-buffer-name bufname)

    (let ((index 0)
          (full-bufname bufname))
      (while
          (let (buf)
            (cl-incf index)
            (when (> index 1)
              (setq full-bufname (format "%s<%d>" bufname index)))

            (when (and (setq buf (get-buffer full-bufname))
                       (mistty-buffer-p buf)
                       (not (mistty-live-buffer-p buf)))
              (let ((kill-buffer-query-functions nil))
                (kill-buffer buf))
              (setq buf nil))

            buf))

      full-bufname)))

;;;###autoload
(defun mistty-create-other-window (&optional command)
  "Create a new MisTTY buffer, running a shell, in another window.

If this command is called with no prefix arg, it is executed in
the `default-directory' of the current buffer. If that directory
is a remote file, and if the TRAMP method supports it, the
command is executed on the remote host. This also works for
same-host methods, such as sudo. See Info node `(mistty)Remote
Shells with TRAMP' for details.

If this command is called with a prefix arg, it asks for the
value of `default-directory'. This is useful if you want start a
shell to a remote host without opening a file first.

COMMAND, if specified, is the command to execute instead of the
shell.

See the documentation of `mistty-create' for details."
  (interactive)
  (mistty-create command 'other-window))

(defun mistty--read-default-directory ()
  "Get the default directory."
  (read-directory-name "Default directory: " default-directory default-directory t nil))

(defun mistty--process-sentinel (term work-buffer proc msg)
  "Process sentinel for MisTTY shell processes.

TERM is the terminal instance and WORK-BUFFER is its work buffer.
PROC is the process, which might not be live anymore, and MSG is
a special string describing the new process state."
  (mistty-with-errors-logged "process sentinel"
    (mistty--term-handle-process-death term msg)

    (when (buffer-live-p work-buffer)
      (when (memq (process-status proc) '(signal exit))
        (while (accept-process-output proc 0 0 t))))

    (mistty--with-live-buffer work-buffer
      (mistty--remove-replay-hooks)
      (remove-hook 'window-size-change-functions #'mistty--window-size-change t)
      (when mistty--queue
        (mistty--cancel-queue mistty--queue)
        (setq mistty--queue nil))
      (mistty--release-all-changesets)
      (setq mistty-proc nil)

      (save-restriction
        (widen)
        (mistty--refresh 'forced)
        (let ((inhibit-read-only t)
              (inhibit-modification-hooks t))
          (remove-text-properties mistty-sync-marker
                                  (point-max) '(read-only nil)))
        (when (>= (point) (mistty-cursor))
          (goto-char (point-max))))

      (mistty--update-secondary-mode))

    (mistty--term-delete term)

    (mistty--run-after-process-end-hooks work-buffer proc)))

(defun mistty--run-after-process-end-hooks (buf proc)
  "Run hooks on `mistty-after-process-end-hook'.

The hooks are called from inside BUF after PROC has died. Since these
hooks tend to kill their buffer, make sure that running stops once the
buffer is killed."
  (run-hook-wrapped
   'mistty-after-process-end-hook
   (lambda (fun)
     (mistty--with-live-buffer buf
       (funcall fun proc)

       ;; continue
       t))))

(defun mistty--add-sync-buffers (accum work-buffer)
  "Sync the terminal region of WORK-BUFFER.

This function updates the state of ACCUM as necessary to keep the
terminal region of WORK-BUFFER in sync with the terminal."

  ;; Mark the terminal region as needing refresh as soon as the
  ;; processor filter is called. This might be in the middle of a
  ;; processor.
  (mistty--accum-add-around-process-filter
   accum
   (lambda (func)
     (funcall func)
     (mistty--with-live-buffer work-buffer
       (mistty--needs-refresh))))

  ;; Refresh the terminal region of the work buffer after data has
  ;; been processed.
  (mistty--accum-add-post-processor
   accum
   (lambda ()
     (mistty--with-live-buffer work-buffer
       (if mistty--queue
           (progn
             (mistty--cancel-timeout mistty--queue)
             (mistty--refresh)
             (mistty--dequeue mistty--queue 'intermediate)
             (mistty--dequeue-with-timer mistty--queue 'stable))
         (mistty--refresh)))))

  ;; Truncate work buffer
  (mistty--accum-add-post-processor
   accum
   (lambda ()
     (mistty--with-live-buffer work-buffer
       (mistty--maybe-truncate-when-idle))))

  ;; Resize terminal
  (mistty--accum-add-post-processor
   accum
   (lambda ()
     (mistty--with-live-buffer work-buffer
       (when (and (display-graphic-p)
                  mistty-fullscreen
                  (not mistty--terminal-size)
                  (not mistty--check-window-size-timer))
         (setq mistty--check-window-size-timer
               (run-with-idle-timer
                0.6 nil #'mistty--check-window-size work-buffer)))))))

(defun mistty--scroll-after-clear ()
  "Scroll the main window to the top of the screen.

This way, it looks like the buffer was cleared even though history is
kept."
  (mistty--check-major-mode)
  (when-let*
      ((win (get-buffer-window (current-buffer)))
       (screen-start-scrolline (mistty--term-scrolline-at-screen-top mistty--term))
       (screen-start-pos (mistty--find-scrolline screen-start-scrolline)))
    (mistty-log "SCROLL to %s@%s" screen-start-scrolline screen-start-pos)
    (set-window-start win screen-start-pos 'noforce)))

(defun mistty--clear-scrollback ()
  "Clear the work buffer above `mistty-sync-marker'."
  (mistty--check-major-mode)
  (when (< (point) mistty-sync-marker)
    (goto-char mistty-sync-marker)
    (setq mistty-goto-cursor-next-time 1))
  (when (> mistty-sync-marker 1)
    (mistty-log "CLEAR SCROLLBACK")
    (let ((inhibit-modification-hooks t)
          (inhibit-read-only t))
      (delete-region 1 mistty-sync-marker))))

(defun mistty--maybe-scroll-windows ()
  "Scroll windows as appropriate for the terminal mode.

In fullscreen mode, make sure that the top of the terminal is at the top
of the window.

In normal mode, make sure that the bottom of the terminal is visible,
not just the cursor, so that things like TAB expansion are usable."
  (if mistty-fullscreen
      (mistty--maybe-scroll-fullscreen-windows)
    (mistty--maybe-scroll-window-down)))

(defun mistty--maybe-scroll-fullscreen-windows ()
  "Anchor the top of the terminal to the top of the window."
  (mistty--check-major-mode)
  (dolist (win (get-buffer-window-list))
    (when (and (>= (window-point win) mistty-sync-marker)
               (< (window-start win) mistty-sync-marker))
        (set-window-start win mistty-sync-marker))))

(defun mistty--maybe-scroll-window-down ()
  "Make sure that newly inserted text is visible.

If there's something below the point in a prompt, the window down so
it's visible. Emacs won't do it on its own, since all it cares about is
the point being visible."
  (mistty--check-major-mode)
  (when (and (equal (point) (mistty-cursor))
             (mistty-on-prompt-p (point)))
    (let* ((pos (point))
           (end (mistty--last-non-ws))
           (lines-after-point (count-lines (point) end)))
      (when (> lines-after-point 1)
        (dolist (win (get-buffer-window-list))
          (when (and (equal pos (window-point win))
                     (not (pos-visible-in-window-p end win)))
            (with-selected-window win
              (recenter (- lines-after-point)))))))))

(defun mistty--set-notrack-cursor (win)
  "Flag window WIN for `mistty-goto-cursor'.

When a window is deselected, normally the buffer point is stored as
window point and not moved. `mistty-goto-cursor' will move that point to
track the terminal cursor, but only if the point was inside the terminal
zone when the window was deselected.

`mistty-goto-cursor' also doesn't change the window point of the
selected window, since it would just be the buffer point."
  (set-window-parameter
   win
   'mistty-notrack-cursor
   (or (eq win (selected-window))
       (not (or (>= (window-point win) mistty-sync-marker)
                (eq t mistty-goto-cursor-next-time))))))

(defun mistty-goto-cursor ()
  "Move the point to the terminal's cursor."
  (interactive)
  (when-let* ((cursor (mistty-cursor)))
    (goto-char cursor)

    ;; Also move the point of deselected windows that track the
    ;; cursor.
    (dolist (win (get-buffer-window-list (current-buffer) nil t))
      (unless (window-parameter win 'mistty-notrack-cursor)
        (set-window-point win cursor)
        (set-window-parameter win 'mistty--cursor-skip-state nil)))))

(defun mistty-cursor ()
  "Return the position of the terminal cursor in the MisTTY buffer.

This is the position of the cursor at the time of the last refresh. It
is updated after each refresh"
  (marker-position mistty--cursor))

(defun mistty--needs-refresh ()
  "Let next call to `mistty--refresh' know there's something to refresh."
  (mistty--check-major-mode)
  (setq mistty--need-refresh t))

(defun mistty--refresh (&optional forced)
  "Copy the end of the term buffer to the work buffer.

If FORCED is non-nil, force a refresh.

Refreshing means copying the region
[mistty-sync-marker,(point-max)] from the term buffer to the work
buffer, overwriting whatever that region of the work buffer
contains.

If refreshing is disabled, with `mistty--inhibit-refresh', this
function just sets `mistty--need-refresh' and returns.

Also updates prompt and point."
  (mistty--check-major-mode)
  (when (or forced
            (and mistty--need-refresh
                 (not mistty--inhibit-refresh)
                 (not mistty--inhibit)))
    (let ((events nil))
      (let ((inhibit-modification-hooks t)
            (inhibit-read-only t)
            (old-point-max (point-max))
            (point-was-at-cursor (= (point) mistty--cursor))
            sync-pos
            sync-scrolline
            on-prompt )
        (mistty--inhibit-undo
         (save-restriction
           (widen)
           (setq mistty--need-refresh nil)
           (setq on-prompt (unless mistty-fullscreen
                             (mistty-on-prompt-p (mistty-cursor))))

           (let ((keep-markers on-prompt))
             (mistty-log "refresh (%s)@%s"
                         (if keep-markers "complete" "quick")
                         mistty--scrolline-home-num)
             (pcase-setq `(,sync-pos ,sync-scrolline ,events)
                           (mistty--term-sync
                            mistty--term
                            (current-buffer)
                            mistty-sync-marker
                            mistty--scrolline-home-num
                            keep-markers
                            mistty--cursor)))
           (when (or (/= sync-pos mistty-sync-marker)
                     (/= sync-scrolline mistty--scrolline-home-num))
             (mistty--set-sync-mark sync-pos sync-scrolline))
           (unless mistty-fullscreen
             (mistty--post-process-prompts on-prompt))
           ;; Move the point to the cursor, if necessary.
           (when (process-live-p mistty-proc)
             (if mistty-fullscreen
                 ;; fullscreen; point follows cursor when in term region
                 (when (or (>= (point) mistty-sync-marker)
                           mistty-goto-cursor-next-time)
                   (mistty-goto-cursor))

               ;; not fullscreen; point sometimes follows cursor
               (when (and (not (eq mistty-goto-cursor-next-time 'off))
                          (or mistty-goto-cursor-next-time point-was-at-cursor))
                 (mistty-goto-cursor)))
             (setq mistty-goto-cursor-next-time nil))))
        (if mistty-fullscreen
            (mistty--maybe-scroll-fullscreen-windows)
          (when (> (point-max) old-point-max)
            (mistty--maybe-scroll-window-down))))

      (mistty--report-self-inserted-text)
      (mistty--handle-sync-events events))))

(defun mistty--post-process-prompts (on-prompt)
  "Update prompt state after syncing.

If ON-PROMPT is non-nil, check if vertical cursor motion is possible."
  (when-let* ((prompt (mistty--active-prompt))
              (scrolline (mistty--scrolline-at (mistty-cursor)))
              (prompt-end (mistty--prompt-end prompt)))
    (when (and (>= scrolline prompt-end)
               (mistty--maybe-move-sync-mark (mistty--prompt-end prompt)))
      (mistty-log "Closing %s prompt #%s [%s-%s]"
                  (mistty--prompt-source prompt)
                  (mistty--prompt-input-id prompt)
                  (mistty--prompt-start prompt)
                  (mistty--prompt-end prompt)
                  scrolline)))

  (when-let* ((prompt (mistty--get-prompt mistty--prompt-cell))
              (prompt-beg (mistty--find-scrolline
                           (mistty--prompt-start prompt))))
    ;; If a new prompt was detected, restrict sync region to
    ;; the beginning of that prompt.
    (let ((update-secondary-mode nil))
      (when (and (not (mistty--prompt-realized prompt))
                 (memq (mistty--prompt-source prompt) '(bracketed-paste osc133))
                 (null (mistty--prompt-end prompt))
                 (> (mistty-cursor) prompt-beg))
        (mistty-log "Realized %s prompt #%s [%s-] @%s"
                    (mistty--prompt-source prompt)
                    (mistty--prompt-input-id prompt)
                    (mistty--prompt-start prompt)
                    prompt-beg)
        (mistty--set-sync-mark prompt-beg (mistty--prompt-start prompt))
        (setf (mistty--prompt-realized prompt) t)
        (setq update-secondary-mode t))
      (when (and (mistty--prompt-click-events prompt)
                 (null mistty--mouse-reporting-requested))
        (mistty--request-mouse-reporting 'click)
        (setq update-secondary-mode t))

      (when update-secondary-mode
        (mistty--update-secondary-mode)))

    (when (mistty--prompt-realized prompt)
      (mistty--mark-continue-prompts prompt prompt-beg)
      (mistty--mark-right-prompt prompt-beg)
      (mistty--mark-prompt-fields prompt prompt-beg)))

  (let ((v (and on-prompt
                (not (mistty--can-click-to-move-p))
                (mistty--can-move-vertically-p))))
    (unless (eq v mistty--can-move-vertically)
      (mistty-log "Can move vertically: %s" v)
      (setq mistty--can-move-vertically v)))

  ;; Turn mistty-special-prompt on or off
  (let ((special-prompt (mistty--match-special-prompt-regexp-p)))
    (cond
     ((and special-prompt (not mistty--special-prompt))
      (setq mistty--special-prompt t)
      (mistty--update-secondary-mode)
      (mistty-log "SPECIAL PROMPT detected"))
     ((and (not special-prompt) mistty--special-prompt)
      (setq mistty--special-prompt nil)
      (mistty--update-secondary-mode)
      (mistty-log "SPECIAL PROMPT done")))))

(defun mistty--mark-continue-prompts (prompt prompt-start)
  "Detect and mark continue prompts that are part of PROMPT.

PROMPT starts at PROMPT-START, a position in the current buffer."
  (let* ((scrolline (1+ (mistty--prompt-start prompt)))
         (end-scrolline (mistty--prompt-end prompt))
         (bol (mistty--bol prompt-start 2)))
    (while (and (or (null end-scrolline) (< scrolline end-scrolline))
                (mistty--detect-continue-prompt bol))
      (cl-incf scrolline)
      (setq bol (mistty--bol bol 2)))))

(defun mistty--mark-right-prompt (prompt-beg)
  "Set text properties on the right prompt from PROMPT-BEG to eol."
  (let* ((line-end (max prompt-beg (mistty--eol prompt-beg)))
         (pos (text-property-any prompt-beg line-end 'mistty-skip 'right-prompt)))
    (when (and pos (> line-end pos))
      (put-text-property pos line-end 'yank-handler '(nil "" nil nil)))))

(defun mistty--mark-prompt-fields (prompt prompt-beg)
  "If user input start is known in PROMPT, mark fields.

PROMPT-BEG must be the position in the current buffer of the beginning
of the prompt.

Fields allow the like of `beginning-of-line' and `end-of-line' to ignore
prompt and right prompts."
  (when-let* ((start-scrolline (mistty--prompt-start prompt))
              (input-start (mistty--prompt-user-input-start prompt))
              (input-start-scrolline (car input-start))
              (input-start-chars (cdr input-start))
              (bol (if (> input-start-scrolline start-scrolline)
                       (save-excursion
                         (goto-char prompt-beg)
                         (mistty--move-scrollines (- input-start-scrolline start-scrolline))
                         (point))
                     prompt-beg))
              (end (mistty--eol bol))
              (start-pos (min end (+ bol input-start-chars))))
    (when (> start-pos bol)
      (add-text-properties
       bol start-pos
       '(field prompt
               inhibit-line-move-field-capture t
               front-sticky (field inhibit-line-move-field-capture)
               rear-nonsticky t)))
    (when-let* ((right-prompt-start
                 (when (> end start-pos)
                   (text-property-any start-pos end 'mistty-skip 'right-prompt))))
      ;; Give room for the point to go one column past the beginning
      ;; of the right prompt to not confuse field-aware commands
      ;; such as backward-word.
      (cl-incf right-prompt-start)
      (when (> end right-prompt-start)
        (add-text-properties
         right-prompt-start end
         '(field right-prompt
                 inhibit-line-move-field-capture t
                 front-sticky (field inhibit-line-move-field-capture)
                 rear-nonsticky t)))
        (setq end right-prompt-start))
    (let ((pos end))
      (while (and (eq ?  (char-before pos))
                  (eq 'trailing (get-text-property (1- pos) 'mistty-skip)))
        (cl-decf pos))
      (when (> end pos)
        ;; Give room to allow the cursor to go to the end of the line
        ;; and continue typing without leaving the field.
        (cl-incf pos))
      (when (> end pos)
        (add-text-properties
         pos end
         '(field trailing
                 inhibit-line-move-field-capture t
                 front-sticky (field inhibit-line-move-field-capture)
                 rear-nonsticky t))))))

(defun mistty--report-self-inserted-text ()
  "Report self-inserted text that was just echoed back.

This function compares the buffer with `mistty--self-insert-line'
to figure out a good time to call
`mistty-interactive-insert-hook'."
  (when (and mistty--self-insert-line
             (= (point) (mistty-cursor)))
    (let* ((str (apply #'concat (reverse (cdr mistty--self-insert-line))))
           (origin (- (point) (length str))))
      (when (and (string= str (mistty--safe-bufstring
                               origin (point)))
                 (eql (car mistty--self-insert-line)
                      (mistty--distance (mistty--bol (point)) origin)))
        (setq mistty--self-insert-line nil)
        (run-hook-wrapped 'mistty-interactive-insert-hook
                          #'mistty--run-hook-ignoring-errors)))))

(defun mistty--handle-sync-events (events)
  "Handle EVENTS returned by `mistty--term-sync'."
  (while-let ((ev (pop events)))
    (mistty-log "mistty-mode EV: %S" ev)
    (pcase ev
      (`(command-finished ,status ,scrolline)
       (let ((pos (mistty--find-scrolline scrolline)))
         (run-hook-wrapped
          'mistty-command-finished-hook
          (lambda (func)
            (prog1 nil
              (save-excursion
                (when pos (goto-char pos))
                (mistty-with-errors-logged "mistty-command-finished-hook"
                  (funcall func status))))))))
      (_ (mistty-log "Unknown event: %S" ev)))))

(defun mistty--run-hook-ignoring-errors (func)
  "Run FUNC with ARGS ignoring any errors.

Errors are reported to `message' and ignored."
  (prog1 nil ; call the next hook
    (with-demoted-errors "[mistty] hook failed: %s"
      (funcall func))))

(defun mistty-simulate-self-insert-command ()
  "Simulate the execution of `self-insert-command'.

This is meant to be called from `mistty-interactive-insert-hook'
to attempt to trigger auto-completion.

Does nothing unless the variable
`mistty-simulate-self-insert-command' is set to a non-nil
value (by default, it is nil)."
  (when mistty-simulate-self-insert-command
    (let ((last-command 'self-insert-command)
          (this-command 'self-insert-command))
      (run-hook-wrapped 'pre-command-hook #'mistty--wrap-pre-post-command)
      (run-hook-wrapped 'post-command-hook #'mistty--wrap-pre-post-command))))

(defun mistty--wrap-pre-post-command (func)
  "Run a pre or post command FUNC.

For `mistty-simulate-self-insert'."
  (prog1 nil ; call the next hook
    (unless (and (symbolp func) (string-prefix-p "mistty-" (symbol-name func)))
      (mistty--run-hook-ignoring-errors func))))

(defun mistty--match-special-prompt-regexp-p ()
  "Return t if `mistty-special-prompt-regexp' matches, nil otherwise.

The region searched is from the line containing the cursor to end
of buffer. The match must start on the line containing the
cursor to be considered."
  (when (process-live-p mistty-proc)
    (let* ((pos (mistty-cursor))
           (bol (mistty--bol pos))
           (eol (mistty--eol pos))
           (regexps mistty-special-prompt-regexps)
           (match nil))
      (while (and (not match) regexps)
        (save-excursion
          (goto-char bol)
          (when (and (search-forward-regexp (pop regexps) nil 'noerror)
                     (>= (match-beginning 0) bol)
                     (< (match-beginning 0) eol))
            (setq match t))))
      match)))

(defun mistty--can-move-vertically-p ()
  "Check whether vertical movements are allowed, return either nil or t.

Does not update `mistty--can-move-vertically'."
  (save-excursion
    (goto-char mistty-sync-marker)
    (catch 'mistty-end-loop
      (dolist (regexp mistty-move-vertically-regexps)
        (when (search-forward-regexp regexp (pos-eol) 'noerror)
          (throw 'mistty-end-loop t)))
      nil)))

(defun mistty--maybe-truncate-when-idle ()
  "Schedule a buffer truncation on an idle timer."
  (when (and (> mistty-buffer-maximum-size 0)
             (null mistty--truncate-timer))
    (setq mistty--truncate-timer
          (run-with-idle-timer
           1 nil #'mistty--maybe-truncate (current-buffer)))))

(defun mistty--maybe-truncate (buf)
  "Truncate BUF, if necessary and possible."
  (mistty--with-live-buffer buf
    (setq mistty--truncate-timer nil)
    (when (> mistty-buffer-maximum-size 0)
      (save-restriction
        (widen)
        (let ((cutoff (mistty--bol (point-max)
                                   (- mistty-buffer-maximum-size))))
          (when (and (> cutoff (point-min))
                     (< cutoff mistty-sync-marker))
            (mistty-truncate cutoff)))))))

(defun mistty-truncate (cutoff)
  "Delete everything int the MisTTY buffer until CUTOFF.

Fails if CUTOFF is inside the synced region."
  (mistty--check-major-mode)
  (save-restriction
    (widen)
    (when (> cutoff mistty-sync-marker)
      (error "Cutoff must be outside the synced region [%s-]"
             (marker-position mistty-sync-marker)))
    (delete-region (point-min) cutoff)))

(defun mistty--maybe-move-sync-mark (scrolline)
  "Move sync mark to SCROLLINE on both buffers, if possible.

This function checks whether SCROLLINE is displayed on the work buffer.
If it is, it sets the sync marker at that position and call
`mistty--set-sync-mark'.

Return nil if SCROLLINE is not accessible on the work buffer."
  (when-let* ((pos (mistty--find-scrolline scrolline)))
    (mistty--set-sync-mark pos scrolline)

    t))

(defun mistty--set-sync-mark (sync-pos scrolline)
  "Sync SYNC-POS with terminal at SCROLLINE.

SYNC-POS is a position on the work buffer that marks the start of the
terminal region.

SCROLLINE is a scrolline that's currently visible on the terminal."
  (mistty--check-major-mode)
  (unless (and (= sync-pos mistty-sync-marker)
               (= scrolline mistty--scrolline-home-num))
    (mistty-log "MOVE SYNC MARKER %s to %s at scrolline %s"
                (marker-position mistty-sync-marker)
                sync-pos
                scrolline)
    (when-let* ((p (mistty--active-prompt)))
      (if (and (mistty--prompt-realized p)
               (not (mistty--prompt-end p)))
          (mistty-log "Keep prompt #%s"
                      (mistty--prompt-input-id p))
      (mistty-log "Deactivate prompt #%s"
                  (mistty--prompt-input-id p))
      (mistty--set-prompt mistty--prompt-cell nil)
      (mistty--update-secondary-mode)))

    (mistty--process-archived-prompts sync-pos)
    (let ((old-marker-position (marker-position mistty-sync-marker)))
      (move-marker mistty-sync-marker sync-pos)
      (when (< old-marker-position sync-pos)
        (mistty--prepare-for-scrollback
         old-marker-position mistty--scrolline-home-num mistty-sync-marker)))
    (setq mistty--scrolline-home-num scrolline)
    (move-overlay mistty--sync-ov mistty-sync-marker (point-max))))

(defun mistty--process-archived-prompts (limit-pos)
  "Remove any archived prompt above END and mark their regions.

Only look up to LIMIT-POS.

This function cleans up the prompt archives, removing prompts above END.

It also marks the prompt region with the text property
\\=`mistty-input-id so they can be detected by functions like
`mistty-next-output'."
  (let ((limit (mistty--scrolline-at limit-pos))
        (inhibit-modification-hooks t)
        (inhibit-read-only t))
    (when-let* ((prompt (mistty--get-prompt mistty--prompt-cell)))
      (when (and (mistty--prompt-end prompt)
                 (<= (mistty--prompt-end prompt) limit))
        (mistty--set-prompt mistty--prompt-cell nil)))
    (dolist (prompt (mistty--prompt-cell-archive mistty--prompt-cell))
      (when (mistty--prompt-realized prompt)
        (when-let* ((prompt-beg (mistty--find-scrolline
                                 (mistty--prompt-start prompt)))
                   (prompt-end (when (mistty--prompt-end prompt)
                                 (mistty--find-scrolline
                                  (mistty--prompt-end prompt)))))
          (when (> prompt-end prompt-beg)
            (mistty-log "End %s prompt #%s %S Mark input range: [%s-%s]/[%s-%s]"
                        (mistty--prompt-source prompt)
                        (mistty--prompt-input-id prompt)
                        (mistty--prompt-cmdline prompt)
                        (mistty--prompt-start prompt)
                        (mistty--prompt-end prompt)
                        prompt-beg
                        prompt-end)
            (when (eq 'regexp (mistty--prompt-source prompt))
              (mistty--term-end-regexp-prompt mistty--term))
            (when (mistty--prompt-click-events prompt)
              (mistty--request-mouse-reporting
               (mistty--term-mouse-reporting mistty--term))
              (mistty--update-secondary-mode))
            (mistty--mark-continue-prompts prompt prompt-beg)
            (mistty--mark-right-prompt prompt-beg)
            (mistty--mark-prompt-fields prompt prompt-beg)
            (put-text-property
             prompt-beg prompt-end
             'mistty-input-id (mistty--prompt-input-id prompt))
            (when-let* ((cmdline (mistty--prompt-cmdline prompt)))
              (put-text-property
               prompt-beg prompt-end
               'mistty-cmdline cmdline))))))
    (setf (mistty--prompt-cell-archive mistty--prompt-cell) nil)))

(defun mistty--prepare-for-scrollback (beg scrolline end)
  "Transition a region from the terminal to the scrollback zone.

This function modifies the region from BEG to END as appropriate
for a scrollback area that's not going to be refreshed from the
terminal anymore.

SCROLLINE is the scrolline at BEG.

It removes the fake newlines which are not useful anymore and
just tend to cause issues."
  (when (> end beg)
    (let ((inhibit-modification-hooks t)
          (inhibit-read-only t))
      (mistty--mark-scrollines beg scrolline end)
      (when (not mistty--inhibit-fake-nl-cleanup)
        (mistty--cleanup-scrollback beg end)))))

(defun mistty--mark-scrollines (beg scrolline end)
  "Add text property \\='mistty-scrolline to scrollines from BEG to END.

SCROLLINE is the scrolline at BEG."
  (mistty--for-each-scrolline
   (lambda (bol eol)
     (put-text-property bol eol 'mistty-scrolline scrolline)
     (cl-incf scrolline))
   beg end))

(defun mistty-send-string (str)
  "Send STR to the process."
  (mistty--require-proc)
  (cond
   ((mistty--should-fallback-to-emacs)
    (insert str))
   (mistty--queue
    (mistty--enqueue-str mistty--queue str))
   (t
    (process-send-string mistty-proc str))))

(defun mistty-send-command ()
  "Send the current command to the shell.

  This also deactivates the mark, as it looks strange otherwise to
  have the command prompt and output marked."
  (interactive)
  (if (mistty--should-fallback-to-emacs)
      (insert "\n")
    (deactivate-mark)
    (mistty--require-proc)
    (mistty--enqueue
     mistty--queue
     (mistty--interact send-command (interact)
       (mistty-maybe-realize-possible-prompt)
       (setq mistty-goto-cursor-next-time t)
       (setq mistty--interacted t)
       (mistty--interact-send interact "\C-m")
       (mistty--interact-done)))))

(defun mistty-newline (&optional n)
  "Send one ore more newlines that won't submit the current command.

  This only works when the program tied to the terminal supports bracketed
  paste mode, as most recent version of shells do.

  If N is a positive integer that many newlines."
  (interactive "p")
  (let* ((nls (make-string (or n 1) ?\n))
         (nl-seq (concat "\e[200~" nls "\e[201~")))
    (if (mistty--should-fallback-to-emacs)
        (insert nls)

      (unless mistty-bracketed-paste
        (user-error "Newlines not supported in this context"))

      (mistty--check-major-mode)
      (if (not mistty-fullscreen)
          (progn
            (mistty-before-positional)
            (mistty--enqueue
             mistty--queue
             (mistty--interact newline (interact)
               (if (mistty-on-prompt-p (point))
                   (progn
                     (setq mistty-goto-cursor-next-time t)
                     (mistty--interact-send interact nl-seq)
                     (mistty--interact-done))
                 (insert nls)
                 (mistty--interact-done)))))

        ;; fullscreen
        (mistty--send-string mistty-proc nl-seq)))))

(defun mistty-positional-p (key)
  "Return non-nil if KEY is a positional key.

  A key is defined as positional if it traditionally have an effect
  that modifies what is displayed on the terminal in a way that
  depends on where the cursor is on the terminal. See also
  `mistty-positional-keys' for the set of control keys that are
  defined as positional.

  MisTTY will attempt to move the terminal cursor to the current
  point before sending such keys to the terminal.

  Non-control characters are always positional, since they're
  normally just inserted.

  KEY must be a string or vector such as the ones returned by `kbd'."
  (or (mistty-self-insert-p key)
      (and (length= key 1)
           (characterp (aref key 0))
           (seq-contains-p mistty-positional-keys (aref key 0)))))

(defun mistty--should-fallback-to-emacs ()
  "Decide whether to send a command to the terminal or modify the buffer.

This function should be called by command that can either execute
locally or be sent to the terminal for execution, such as self-insert.
It decides whether it is better to modify the buffer and let MisTTY
replay it later or to send the command to the terminal for direct
execution.

Normally, it's better to send commands to the terminal application so it
can decide what to do, but in some cases, this isn't practical."
  (and (eq 'mistty-mode major-mode)
       (or mistty--inhibit
           (mistty--active-changeset)
           (not (process-live-p mistty-proc))
           (not mistty--queue))))

(defun mistty-self-insert (&optional n c)
  "Send a self-inserting character to the terminal.

  If N is set, send the key that many times. It defaults to 1.

  C is the character to send, a single character."
  (interactive "p")
  (if (mistty--should-fallback-to-emacs)
      (self-insert-command n c)
    (mistty-send-key n (when c (make-string 1 c)) 'positional)))

(defun mistty-backward-delete-char (&optional n)
  "Send DEL N times to the terminal.

  If N is unset, send DEL once. If N is negative, send Control d
  that many times instead."
  (interactive "p")
  (if (mistty--should-fallback-to-emacs)
      (call-interactively 'backward-delete-char)
    (if (and (numberp n) (< n 0))
        (mistty-send-key (abs n) "\C-d" 'positional)
      (mistty-send-key n mistty-del 'positional))))

(defun mistty-delete-char (&optional n)
"Send Control D N times to the terminal.

  If N is unset, send Control d once. If N is negative, send DEL
  that many times instead."
  (interactive "p")
  (if (mistty--should-fallback-to-emacs)
      (call-interactively 'delete-char)
    (setq mistty--interacted t)
    (if (and (numberp n) (< n 0))
        (mistty-send-key (abs n) mistty-del 'positional)
      (mistty-send-key n "\C-d" 'positional))))

(defun mistty-tab-command (&optional n)
  "Send a TAB to the terminal.

  If N is specified, do it N times."
  (interactive "p")
  (if (mistty--should-fallback-to-emacs)
      (call-interactively 'indent-for-tab-command)
    (mistty-send-key n (kbd "TAB") 'positional)))

(defun mistty--send-for-mistty-mode (translated-key key n positional)
  "Send a key to the terminal.

TRANSLATED-KEY is the key translated into a terminal sequence.

KEY is the original Emacs key, if any. N is the number of repetition for
KEY in TRANSLATED-KEY. POSITIONAL is not nil if KEY is positionAL.

This is meant to be bound to `mistty--send-function' for `mistty-mode'
buffers."
  (mistty--check-major-mode)
  (mistty--require-proc)
  (mistty-log "KEY %s %s" (key-description key) n)
  (let* ((positional (or positional (mistty-positional-p key))))
    (cond
     ((not mistty-fullscreen)
      (mistty--pickup-changes)
      (when (and positional
                 (not (and (eq this-command 'mistty-self-insert)
                           (eq last-command 'mistty-self-insert))))
        (mistty-before-positional))
      (mistty--enqueue
       mistty--queue
       (mistty--interact send-key (interact)
         (when (eq this-command 'mistty-self-insert)
           (unless mistty--self-insert-line
             (setq mistty--self-insert-line
                   (cons (mistty--distance (mistty--bol (point)) (point)) nil)))
           (push translated-key (cdr mistty--self-insert-line)))
         (setq mistty-goto-cursor-next-time t)
         (mistty--maybe-add-key-to-undo n key (mistty-cursor))
         (mistty--interact-send interact translated-key)
         (mistty--interact-done))))

     ((process-live-p mistty-proc)
      (mistty--send-string mistty-proc translated-key))

     (t (user-error "No live process")))))

(defun mistty-send-C-r (n)
  "Send Control r to the terminal, usually backward history search.

  If an argument is specified, repeat it N time."
  (interactive "p")
  (mistty-send-key n (kbd "C-r")))

(defun mistty-send-C-p (n)
  "Send Control p to the terminal, usually move up or prev history.

  If an argument is specified, repeat it N time."
  (interactive "p")
  (mistty-send-key n (kbd "C-p")))

(defun mistty-send-C-n (n)
  "Send Control n to the terminal, usually move down or next history.

  If an argument is specified, repeat it N time."
  (interactive "p")
  (mistty-send-key n (kbd "C-n")))

(defun mistty-beginning-of-line (&optional n)
  "Go to the Nth beginning of line, possibly by sending Control a.

  This command moves the point to the beginning of the line, either
  by calling `beginning-of-line' or by sending Control a to the
  shell, if on a prompt.

  With an argument, this command just calls `beginning-of-line' and
  forwards the argument to it."
  (interactive "p")
  (let ((n (or n 1)))
    (if (or (/= n 1)
            (mistty--should-fallback-to-emacs))
        (beginning-of-line n)
      (mistty--enqueue
       mistty--queue
       (mistty--interact bol (interact)
         ;; While C-a is not, strictly-speaking, a positional,
         ;; it's a good sign that we're on a prompt.
         (if (or (mistty-maybe-realize-possible-prompt (point))
                 (mistty-on-prompt-p (point)))
             (progn
               (setq mistty-goto-cursor-next-time t)
               (mistty--interact-send
                interact (mistty--term-translate-key mistty--term [?\C-a]))
               (mistty--interact-done))
           (beginning-of-line n)
           (mistty--interact-done)))))))

(defun mistty-end-of-line-or-goto-cursor (&optional n)
  "Move the point to the end of the Nth line, then to the cursor.

  The first time this command is called, it moves the point to the
  end of the line, either using `end-of-line' or, if on a prompt,
  by sending Control e to the shell.

  The second time this command is called, it moves the point to the
  cursor.

  With an argument, this command just calls `end-of-line' and
  forwards the argument to it."
  (interactive "p")
  (let ((n (or n 1)))
    (if (and (= 1 n)
             (eq last-command this-command)
             mistty-proc ;; doesn't have to be running
             (/= (point) (mistty-cursor)))
        (progn (mistty-log "goto cursor") (mistty-goto-cursor))
      (progn (mistty-log "goto eol %s" n) (mistty-end-of-line n)))))

(defun mistty-end-of-line (&optional n)
  "Move the point to the end of the Nth line.

  This command moves the point to the end of the line, either using
  `end-of-line' or, if on a prompt, by sending Control e to the
  shell.

  With an argument, this command just calls `end-of-line' and
  forwards the argument to it."
  (interactive "p")
  (let ((n (or n 1)))
    (if (or (/= n 1)
            (mistty--should-fallback-to-emacs))
        (end-of-line n)
      (mistty--enqueue
       mistty--queue
       (mistty--interact eol (interact)
         ;; While C-e is not, strictly-speaking, a positional, it's
         ;; a good sign that we're on a prompt.
         (if (or (mistty-maybe-realize-possible-prompt (point))
                 (mistty-on-prompt-p (point)))
             (progn
               ;; If anything, move point to the cursor. This might
               ;; be the only visible effect if the cursor is
               ;; already at what the shell considers eol.
               (mistty-goto-cursor)
               (setq mistty-goto-cursor-next-time t)
               (mistty--interact-send
                interact (mistty--term-translate-key mistty--term [?\C-e]))
               (mistty--interact-done))
           (end-of-line n)
           (mistty--interact-done)))))))

(defun mistty--before-change-on-work (_beg end)
  "Prepare for allowing modifications on the work buffer up to END.

This is meant to be added to `before-change-functions'."
  (when (and (not mistty-fullscreen)
           mistty-sync-marker
           (>= end mistty-sync-marker))
    (unless (mistty--active-changeset)
      (mistty--activate-changeset
       :command (if (eq this-command t)
                    real-this-command
                  this-command)
       :possible-prompt (mistty--detect-possible-prompt)))
    ;; Temporarily stop refreshing the work buffer while collecting
    ;; modifications.
    (setq mistty--inhibit-refresh t)
    (unless this-command
      ;; Outside of a command, use an idle timer
      ;; to later on pickup the change and send it
      ;; to the terminal.
      (mistty--schedule-pickup-changes))))

(defun mistty--after-change-on-work (beg end old-length)
  "Handler for modifications made to the work buffer.

  BEG and END are the changed region and OLD-LENGTH the length of
  that region before the change.

  This is meant to be added to ==\'after-change-functions."
  (when (and mistty-sync-marker (>= end mistty-sync-marker))
    (when-let* ((cs (mistty--active-changeset)))
      (let ((inhibit-read-only t)
            ;; Restrict change tracking to sync region
            (beg (max beg mistty-sync-marker))
            (end (max end mistty-sync-marker))
            (old-end (max (+ beg old-length) mistty-sync-marker)))
        (mistty--inhibit-undo
         (mistty--changeset-mark-region cs beg end old-end))))))

(defun mistty--can-click-to-move-p ()
  "Check whether clicking can be used to move the cursor."
  (pcase mistty-allow-click-to-move
    ('always (or mistty--mouse-reporting-requested
                 (when-let* ((p (mistty--active-prompt)))
                   (mistty--prompt-click-events p))))
    ('osc133 (when-let* ((p (mistty--active-prompt)))
                     (mistty--prompt-click-events p)))
    (_ nil)))

(defun mistty--replay-interaction (cs)
  "Build a `mistty--interact' of type \\='replay to replay CS.

  If CS is empty, it is released immediately and this function returns nil
  instead of a interaction.

  Replay interactions are callable with `mistty--call-interact'.
  They take a single argument, another changeset, and attempt to
  append that changeset to the current one. If that works, the
  changeset is released and the call returns t, otherwise the call
  returns nil."
  (let ((interact (mistty--make-interact 'replay))

        ;; mistty--changeset-modification extracts modification from
        ;; the buffer. It must be called when the interaction is
        ;; created, not when it is run
        (modifications (mistty--changeset-modifications cs))
        (can-move-vertically mistty--can-move-vertically)
        (calling-buffer (current-buffer))
        (can-click-to-move (mistty--can-click-to-move-p))
        (term mistty--term)
        (inhibit-moves mistty--special-prompt)
        (beg (make-marker))
        (old-end (make-marker))

        trailing-ws-to-delete target
        backstage lower-limit upper-limit
        orig-beg content old-length waiting-for-last-change
        inserted-detector-regexp point-after-last-insert)

    ;; If the point is after the last insert, which is very common,
    ;; trust the cursor position instead of relying on
    ;; replace-buffer-contents to set the point properly. This is
    ;; cheaper and more reliable, as replace-buffer-contents has
    ;; trouble in some cases, especially when the inserted string is
    ;; too short or contains only spaces.
    (setq point-after-last-insert
          (when-let* ((m (car (last modifications))))
            (when (length> (nth 1 m) 0)
              (equal (point) (+ (nth 0 m) (length (nth 1 m)))))))

    ;; Init interact
    (cl-labels
        ((start (&optional _) ;; Interact entry point
           (set-buffer calling-buffer)
           (setq backstage (mistty--create-backstage term))
           (let ((work-sync-marker (marker-position mistty-sync-marker)))
             (set-buffer backstage)
             ;; Move modifications positions into the backstage buffer.
             ;; Rely on markers to keep the positions valid through
             ;; buffer modifications.
             (dolist (m modifications)
               (setcar m (copy-marker (+ (car m) (- work-sync-marker) (point-min))))))
           (setq lower-limit (point-min-marker))
           (setq upper-limit (point-max-marker))
           (next-modification))

         (next-modification ()
           (if modifications
               (handle-modification (pop modifications))
             (done-handling-modifications)))

         (handle-modification (m)
           (setq orig-beg (nth 0 m))
           (setq content (nth 1 m))
           (setq old-length (nth 2 m))

           (move-marker beg orig-beg)
           (if (< old-length 0)
               (let ((end (max beg (mistty--blank-end-start))))
                 (setq old-length (- end beg))
                 (move-marker old-end end))
             (move-marker old-end (+ beg old-length)))

           ;; don't try to delete blank lines at EOB
           (let ((blank-end (mistty--blank-end-start)))
             (let ((end (max beg blank-end)))
               (when (> old-end end)
                 (move-marker old-end end)))

             ;; don't even try to move through trailing ws at the
             ;; end of the prompt, as they may not exist (Issue #34)
             ;; even though they're not reported as blank.
             (setq trailing-ws-to-delete 0)
             (when (= old-end blank-end)
               (while (and (eq ?\  (char-before old-end)) (> old-end beg))
                 (cl-incf trailing-ws-to-delete)
                 (move-marker old-end (1- old-end)))))
           (setq old-length (- old-end beg))

           (mistty-log "replay: %s '%s' %s old-content: '%s' (limit: [%s-%s]) %s"
                       (marker-position orig-beg)
                       content
                       old-length
                       (mistty--safe-bufstring beg old-end)
                       (marker-position lower-limit)
                       (marker-position upper-limit)
                       (mistty--changeset-command cs))
           (if (> old-length 0)
               (setq target old-end)
             (setq target beg))
           (if (and (zerop old-length) (equal "" content))
               ;; The modification is empty, move on to the next one.
               ;; This can happen when the change specified "delete to
               ;; the end of the buffer" and there was nothing to
               ;; delete.
               (next-modification)
             (move-to-target)))

         (move-to-target ()
           (cond
            ((> target upper-limit)
             (mistty-log "SKIP target=%s > upper-limit=%s"
                         (marker-position target)
                         (marker-position upper-limit))
             (next-modification))

            ((and (< target lower-limit))
             (mistty-log "SKIP target=%s < lower-limit=%s"
                         (marker-position target)
                         (marker-position lower-limit))
             (next-modification))

            (inhibit-moves
             (mistty-log "INHIBITED: to target: %s -> %s" (point) target)
             (after-move-to-target))

            ((zerop (mistty--distance (point) target))
             (delete-lines))

            (can-click-to-move (click-to-move))

            (t (move-vertically))))

         (click-to-move ()
           (let ((click-seq (mistty--term-click-on
                             term target mistty-sync-marker)))
             (mistty-log "to target: %s -> %s with click"
                         (point) (marker-position target))
             (when click-seq
               (mistty--interact-send interact click-seq)
               (mistty--interact-wait-for-output-then
                #'after-move-to-target
                :pred (lambda ()
                        (mistty--update-backstage)
                        (zerop (mistty--distance (point) target)))))

             ;; null click-seq; This shouldn't happen.
             (move-vertically)))

         (move-vertically ()
           (let* ((distance (mistty--vertical-distance (point) target))
                  (replay-seq (mistty--move-vertically-seq
                               distance can-move-vertically)))
             (when replay-seq
               (mistty-log "to target: %s -> %s lines: %s (can-move-vertically=%s)"
                           (point) (marker-position target) distance can-move-vertically)
               (mistty--interact-send interact (mistty--translate-replay-seq term replay-seq))
               (mistty--interact-wait-for-output-then
                #'move-horizontally
                :pred (let ((comparison (cond (can-move-vertically '=)
                                              ((< distance 0) '<=)
                                              (t '>=))))
                        (lambda ()
                          (mistty--update-backstage)
                          (funcall comparison 0 (mistty--vertical-distance
                                                 (point) target))))
                ;; after-move-to-target-f deals with the point not being
                ;; where it should.
                :on-timeout #'after-move-to-target))

             (move-horizontally)))

         (move-horizontally ()
           (let ((distance (mistty--distance (point) target)))
             (mistty-log "to target: %s -> %s distance: %s"
                         (point) (marker-position target) distance)
             (when-let* ((replay-seq (mistty--move-horizontally-seq distance)))
               (mistty--interact-send
                interact (mistty--translate-replay-seq term replay-seq))
               (mistty--interact-wait-for-output-then
                #'after-move-to-target
                :pred (lambda ()
                        (mistty--update-backstage)
                        (zerop (mistty--distance (point) target)))))

             (delete-lines)))

         (after-move-to-target ()
           (mistty--update-backstage)
           (mistty-log "Got to %s" (point))
           (cond
            ((and (> (point) target)
                  (> (mistty--distance target (point)) 0))
             (mistty-log "LOWER LIMIT: %s (wanted %s)" (point) target)
             (move-marker lower-limit (point))
             (if (= old-length 0)
                 ;; insert anyways
                 (progn
                   (mistty-log "insert anyway, at %s instead of %s"
                               (point) (marker-position target))
                   (move-marker target (point))
                   (insert-and-delete))
               ;; skip delete or replace
               (mistty-log "SKIP delete or replace; %s (wanted %s)"
                           (point) (marker-position target))
               (next-modification)))

            ((and (> target (point))
                  (> (mistty--distance (point) target) 0))
             (mistty-log "UPPER LIMIT: %s (wanted %s)"
                         (point) (marker-position target))
             (move-marker upper-limit (point))
             (if (>= (point) beg)
                 (progn
                   (move-marker old-end (point))
                   (setq old-length (- old-end beg))
                   (insert-and-delete))
               (next-modification)))

            (t
             (move-marker target (point))
             (delete-lines))))

         ;; For multi-line delete, delete line by line. This allows not
         ;; knowing where a line really ends (Issue #34).
         (delete-lines ()
           (let ((lines (mistty--vertical-distance beg old-end)))
             (when (> lines 0)
               (let ((bol (save-excursion
                            (goto-char old-end)
                            (catch 'mistty-bol
                              (while (search-backward "\n" beg 'noerror)
                                (unless (get-text-property (match-beginning 0) 'term-line-wrap)
                                  (throw 'mistty-bol (match-end 0))))))))
                 (when (and bol (<= beg bol old-end))
                   (mistty-log "delete line: [%s-%s] beg: %s"
                               (1- bol)
                               (marker-position old-end)
                               (marker-position beg))
                   (mistty--interact-send
                    interact
                    (mistty--translate-replay-seq
                     term `((repeat ,(1+ (mistty--distance bol old-end)) (del)))))
                   (mistty--interact-wait-for-output-then
                    (lambda ()
                      (move-marker old-end (point))
                      (setq old-length (max 0 (- old-end beg)))

                      ;; Maybe delete another line
                      (delete-lines))
                    :pred (lambda ()
                            (mistty--update-backstage)
                            (< (mistty--vertical-distance
                                beg (point)) lines))
                    ;; If we can't even delete lines, just give up and move
                    ;; on to the next modification.
                    :on-timeout #'after-insert-and-delete))))
             (insert-and-delete)))

         (insert-and-delete ()
           (mistty-log "insert and delete: point: %s beg: %s old-end: %s"
                       (point)
                       (marker-position beg)
                       (marker-position old-end))
           (let ((replay-seq
                  (append
                   ;; delete
                   (when (> old-length 0)
                     (let ((char-count (mistty--distance beg old-end)))
                       (mistty-log "DELETE %s chars (was %s)" char-count old-length)
                       `((repeat ,char-count (del)))))

                   ;; delete trailing ws
                   (when (> trailing-ws-to-delete 0)
                     (mistty-log "DELETE %s trailing whitespaces with C-k" trailing-ws-to-delete)
                     `(kill-line))

                   ;; insert
                   (when (length> content 0)
                     (mistty-log "INSERT: '%s'" content)
                     (mistty--format-string-for-insert content cs)))))
             (when replay-seq
               ;; ignore term-line-wrap and mistty-skip when
               ;; building and running the detector.
               (mistty--remove-text-with-property 'term-line-wrap)
               (mistty--remove-text-with-property 'mistty-skip)
               (setq inserted-detector-regexp
                     (concat
                      "^"
                      (regexp-quote (mistty--safe-bufstring
                                     (mistty--bol beg) beg))
                      (string-replace "\n" " *\n" (regexp-quote content))))
               (mistty-log "RE /%s/" inserted-detector-regexp)
               (unless modifications
                 (setq waiting-for-last-change t))
               (mistty--interact-send
                interact (mistty--translate-replay-seq term replay-seq))
               (mistty--interact-wait-for-output-then
                #'after-insert-and-delete
                :pred (lambda ()
                        (mistty--update-backstage)
                        (mistty--remove-text-with-property 'term-line-wrap)
                        (mistty--remove-text-with-property 'mistty-skip)
                        (looking-back inserted-detector-regexp (point-min))))))

           ;; Nothing to do, move on to the next modification, if any
           (next-modification))

         (after-insert-and-delete ()
           (setq waiting-for-last-change nil)
           (mistty--update-backstage)
           (mistty--term-detect-dead-spaces-after-insert
            term
            content
            (mistty--scrolline-at beg)
            (- beg (mistty--bol beg)))

           ;; Move right prompt just like the shell would, to avoid it
           ;; confusing the sync happening after applying all
           ;; modifications.
           (when-let* ((content-nl (string-match "\n" content)))
             (with-current-buffer calling-buffer
               (let* ((content-end (+ orig-beg (length content)))
                      (eol (mistty--eol content-end)))
                 (when-let* ((right-prompt
                              (text-property-any content-end eol
                                                 'mistty-skip 'right-prompt)))
                   (save-excursion
                     (let ((inhibit-modification-hooks t)
                           (inhibit-read-only t)
                           (right-prompt-content (buffer-substring right-prompt eol)))
                       (goto-char (+ orig-beg content-nl))
                       (delete-region right-prompt eol)
                       (insert right-prompt-content)))))))

           (next-modification))

         (done-handling-modifications ()
           (set-buffer calling-buffer)

           ;; Force refresh, even if nothing was sent, if only to revert what
           ;; couldn't be replayed.
           (mistty--needs-refresh)

           (if (or inhibit-moves point-after-last-insert)
               (setq mistty-goto-cursor-next-time t)

             ;; Move cursor back to point unless the next interact is a
             ;; replay, in which case we let the replay move the cursor.
             (setq mistty-goto-cursor-next-time 'off)
             (let ((next (car (mistty--queue-more-interacts mistty--queue))))
               (when (or (null next)
                         (not (eq 'replay (mistty--interact-type next))))
                 (mistty--enqueue
                  mistty--queue
                  (mistty--cursor-to-point-interaction) 'prepend))))
           (mistty--interact-done))

         ;; Handles (mistty--call-interact)
         ;;
         ;; (mistty--call-interact interact 'replay OTHER-CS)
         ;; attempts to append modifications to an existing replay.
         ;;
         ;; OTHER-CS must be a changeset.
         ;;
         ;; If OTHER-CS can be appended to the current set of
         ;; modifications, this function takes ownership of OTHER-CS
         ;; and returns non-nil. Otherwise, this function returns
         ;; nil and the caller retains ownership of OTHER-CS.
         (handle-call-interact (other-cs)
           (when-let* ((text-to-insert (mistty--changeset-single-insert other-cs)))
             (when (and
                    (eql (mistty--changeset-beg other-cs)
                         (mistty--changeset-end cs))
                    (cond
                     (modifications
                      (let* ((tail (last modifications))
                             (m (car tail))
                             (beg (nth 0 m))
                             (content (nth 1 m))
                             (old-length (nth 2 m)))
                        (setcar tail
                                (list beg (concat content text-to-insert) old-length))
                        t))

                     ((and (null modifications) waiting-for-last-change)
                      (mistty--send-string mistty-proc text-to-insert)
                      (setq inserted-detector-regexp
                            (concat inserted-detector-regexp
                                    (regexp-quote text-to-insert)))
                      (mistty-log "updated RE /%s/" inserted-detector-regexp)
                      t)))
               (setf (mistty--changeset-end cs)
                     (mistty--changeset-end other-cs))
               (mistty--release-changeset other-cs)
               t)))

         ;; Cleanup any open state. This is called when the interact
         ;; is closed, from (mistty--interact-close interact).
         ;;
         ;; The interact might have been run fully, not have been
         ;; run at all, or have been run partially. Cleanup can be
         ;; done in all cases.
         (cleanup ()
           (mistty--delete-backstage backstage)

           ;; Always release the changeset at the end and re-enable
           ;; refresh.
           (mistty--release-changeset cs)
           (mistty--refresh-after-changeset)))

      (setf (mistty--interact-cb interact) #'start)
      (setf (mistty--interact-call interact) #'handle-call-interact)
      (setf (mistty--interact-cleanup interact) #'cleanup))

    (if modifications
        interact

      ;; Nothing to do; clean things up right away
      (mistty--interact-close interact)
      nil)))

(defun mistty--format-string-for-insert (str cs)
  "Return a replay sequence for inserting STR for changeset CS.

When bracketed paste is enabled, it is used only if STR contains control
characters, unless the command that created the changeset is in
`mistty-bracketed-paste-commands'."
  (if (and mistty-bracketed-paste
           (or (string-match "[\0-\010\012-\037]" str)
               (if-let* ((config (assq (mistty--changeset-command cs)
                                       mistty-bracketed-paste-command-alist)))
                   (cdr config)
                 mistty-bracketed-paste-default)))
      `((paste ,str))
    `(,(mistty--untabify str))))

(defun mistty--refresh-after-changeset ()
  "Refresh the work buffer again if there are not more changesets."
  (unless mistty--changesets
    (setq mistty--inhibit-refresh nil)
    (mistty--refresh)))

(defun mistty--move-horizontally-seq (direction)
  "Return a replay sequence to move horizontally.

The absolute value of DIRECTION specifies the number of character
to move and the sign specifies whether to go right (positive) or
left (negative)."
  (if (zerop direction)
      nil
    `((repeat ,(abs direction) ,(if (< direction 0) '(left) '(right))))))

(defun mistty--move-vertically-seq (direction can-move-vertically)
  "Return a replay sequence to move vertically.

The absolute value of DIRECTION specifies the number of lines
to move and the sign specifies whether to go down (positive) or
up (negative).

If CAN-MOVE-VERTICALLY is non-nil, issue up/down keystrokes, otherwise use
left/right, beginning-of-line and end-of-line."
  (if (zerop direction)
      nil
    `((repeat
      ,(abs direction)
      ,(cond
        ((and can-move-vertically (< direction 0)) '(up))
        ((and can-move-vertically (> direction 0)) '(down))
        ((< direction 0) '(bol left))
        (t '(eol right)))))))

(defun mistty-clear (n)
  "Clear the MisTTY buffer until the end of the last output.

With an argument, clear from the end of the last Nth output."
  (interactive "p")
  (let ((range (save-excursion (mistty-previous-output (or n 1)))))
    (mistty-truncate (min mistty-sync-marker (cdr range)))))

(defun mistty--pre-command ()
  "Function called from the `pre-command-hook' in `mistty-mode' buffers."
  (with-demoted-errors "mistty: pre-command error %S"
    (mistty--cancel-pickup-changes)
    (mistty--detect-foreign-overlays 'noschedule)
    (mistty--pre-command-for-undo)
    (when (and mistty--self-insert-line
               (not (eq this-command 'mistty-self-insert)))
      (setq mistty--self-insert-line nil))
    (setq mistty--old-point (point))))

(defun mistty--post-command-undo ()
  "Reset undo data."
  (mistty-with-errors-logged "post-command-undo"
    (mistty--post-command-for-undo)))

(defun mistty--post-command-cursor ()
  "Show cursor again if point moved."
  (mistty-with-errors-logged "post-command-cursor"
    (when (and mistty--old-point (/= (point) mistty--old-point))
      (mistty--show-cursor))))

(defun mistty--post-command-quit ()
  "Cancel replay on `keyboard-quit'."
  (mistty-with-errors-logged "post-command-quit"
    (when (and (or (eq this-command 'keyboard-quit)
                   (eq this-original-command 'keyboard-quit)))
      (when (not (mistty--queue-empty-p mistty--queue))
        (mistty-log "CANCEL")
        (message "MisTTY: Canceling replay")
        (mistty--cancel-queue mistty--queue))
      (mistty--ignore-foreign-overlays)
      (mistty--inhibit-clear 'noschedule)
      (when mistty--special-prompt
        (mistty-send-key 1 "\C-g")))))

(defun mistty--post-command-schedule ()
  "Schedule replay on an idle timer."
  (mistty-with-errors-logged "post-command-schedule"
    (run-with-idle-timer
     0 nil #'mistty--post-command-1
     (current-buffer)
     (and mistty--old-point
          (/= (point) mistty--old-point)))))

(defun mistty--inhibit-add (sym)
  "Add a source of inhibition with SYM as id.

This changes the value of `mistty--inhibit' and reacts to that
change."
  (let ((was-inhibited (if mistty--inhibit t nil)))
    (cl-pushnew sym mistty--inhibit)
    (unless was-inhibited
      (mistty-log "Long-running command ON %s" mistty--inhibit)
      (overlay-put mistty--sync-ov 'keymap nil)
      (mistty--update-secondary-mode))))

(defun mistty--inhibit-remove (sym noschedule)
  "Remove a source of inhibition with SYM as id.

This changes the value of `mistty--inhibit' and reacts to that
change, unless NOSCHEDULE evaluates to true."
  (when mistty--inhibit
    (setq mistty--inhibit (delq sym mistty--inhibit))
    (unless mistty--inhibit
      (mistty-log "Long-running command OFF")
      (mistty--update-secondary-mode)
      (unless noschedule
        (run-with-idle-timer
         0 nil #'mistty--post-command-1
         (current-buffer) 'point-moved)))))

(defun mistty--inhibit-set (sym val &optional noschedule)
  "Add or remove a source of inhibition with SYM as id.

If VAL evaluates to non-nil, add it, otherwise remove it.

This changes the value of `mistty--inhibit' and reacts to that
change, unless NOSCHEDULE evaluates to true."
  (if val
      (mistty--inhibit-add sym)
    (mistty--inhibit-remove sym noschedule)))

(defun mistty--inhibit-clear (&optional noschedule)
  "Clear `mistty--inhibit'.

This changes the value of `mistty--inhibit' and reacts to that
change, unless NOSCHEDULE evaluates to true."
  (dolist (sym (cl-copy-list mistty--inhibit))
    (mistty--inhibit-remove sym noschedule)))

(defun mistty--detect-foreign-overlays (noschedule)
  "Detect foreign overlays.

Foreign overlays are used as a sign that a long-running command
is active and that normal MisTTY operations should be turned off
for a time.

If NOSCHEDULE evaluates to non-nil, don't schedule a
`mistty--post-command-1' when inhibition is turned off by this
call.

Does nothing if the option `mistty-detect-foreign-overlays' is
off."
  (when mistty-detect-foreign-overlays
    (let ((ovs
           (delq nil
                 (mapcar
                  (lambda (ov)
                    (unless (memq ov mistty--ignored-overlays)
                      (let ((ovprops (overlay-properties ov))
                            (match nil))
                        (dolist (prop mistty-foreign-overlay-properties)
                          (when (memq prop ovprops)
                            ;;(mistty-log "detected ov matching %s: %s" prop ovprops)
                            (setq match t)))
                        (if match
                            ov
                          ;;(mistty-log "ignored foreign overlay: %s" ovprops)
                          nil))))
                  (overlays-in mistty-sync-marker (point-max))))))
      ;; If there are foreign overlays in an empty buffer, there will
      ;; likely always be.
      (if (and ovs (= 1 (point-max)))
          (progn
            (mistty-log "Foreign overlays detected too early. Turning off detection.")
            (setq-local mistty-detect-foreign-overlays nil))
        (mistty--inhibit-set 'mistty-overlays ovs noschedule)))))

(defun mistty--ignore-foreign-overlays ()
  "Ignore currently active foreign overlays.

This function tells `mistty--detect-foreign-overlays' to ignore
whatever overlay currently exists."
  (dolist (ov (overlays-in mistty-sync-marker (point-max)))
    (cl-pushnew ov mistty--ignored-overlays)))

(defun mistty--detect-completion-in-region ()
  "Inhibit replay and refresh while completion is in progress."
  (mistty--inhibit-set
   'mistty-completion-in-region completion-in-region-mode))

(defun mistty--post-command-1 (buf point-moved)
  "Function called from `mistty--post-command'.

BUF is the buffer to work in. POINT-MOVED is non-nil if the point
was moved by the last command.

This is the body of `mistty--post-command', which replays any
modifications or cursor movement executed during the command. It
is run in an idle timer to avoid failures inside of the
post-command hook."
  (mistty-with-errors-logged "post-command-1"
    (mistty--with-live-buffer buf
      (mistty--detect-foreign-overlays 'noschedule)
      (unless (mistty--pickup-changes)
        (when (and point-moved
                   (>= (point) mistty-sync-marker)
                   (process-live-p mistty-proc)
                   (not mistty--inhibit)
                   (not mistty--special-prompt))
          (mistty--enqueue mistty--queue (mistty--cursor-to-point-interaction))))
      (mistty--refresh))))

(defun mistty--release-all-changesets ()
  "Give up on replaying any open changesets."
  (while-let ((cs (car mistty--changesets)))
    (mistty--release-changeset cs))
  (mistty--cancel-pickup-changes))

(defun mistty--cancel-pickup-changes ()
  "Cancel any scheduled pickup change timer."
  (mistty--check-major-mode)
  (when (timerp mistty--pickup-changes-timer)
    (cancel-timer mistty--pickup-changes-timer)
    (setq mistty--pickup-changes-timer nil)))

(defun mistty--schedule-pickup-changes ()
  "Schedule `mistty-pickup-changes' to run on an idle timer."
  (mistty--cancel-pickup-changes)
  (setq mistty--pickup-changes-timer
        (run-with-idle-timer
         0 nil (lambda (buf)
                 (mistty--with-live-buffer buf
                   (mistty--pickup-changes)))
         (current-buffer))))

(defun mistty--pickup-changes ()
  "Pick up changes made to the terminal area to replay them.

Not every change is replayable. This function discards unreplayable
changes.

Return non-nil if a change was picked up to be replayed."
  (mistty--cancel-pickup-changes)
  (when (and (not mistty--inhibit)
             (process-live-p mistty-proc))
    (when-let* ((cs (mistty--active-changeset)))
      (mistty--inhibit-undo
       (save-restriction
         (widen)
         (mistty-log "PICK UP CHANGESET #%s [%s,%s)"
                     (mistty--changeset-id cs)
                     (mistty--changeset-beg cs)
                     (mistty--changeset-end cs))
         (if (mistty--should-replay cs)
             ;; Give changeset over to the interaction to replay.
             (prog1 t ; return non-nil
               (let ((last-interaction (mistty--queue-last-interact mistty--queue)))
                 (unless (and last-interaction
                              (eq 'replay (mistty--interact-type last-interaction))
                              ;; append to existing interaction
                              (mistty--call-interact last-interaction 'replay cs))
                   (mistty--enqueue mistty--queue (mistty--replay-interaction cs)))))

           ;; Abandon changeset
           (prog1 nil ; return nil
             (mistty--release-changeset cs)
             (mistty--refresh-after-changeset))))))))

(defun mistty--should-replay (cs)
  "Decide whether CS should be replayed.

Might modify CS before allowing replay."
  (let (replay)
    (cond
     ;; nothing to do
     ((not (mistty--changeset-p cs)))

     ;; modifications are part of the current prompt; replay them
     ((mistty-on-prompt-p (mistty-cursor))
      (setq replay t))

     ;; modifications are part of a possible prompt; realize it, keep
     ;; the modifications before the new prompt and replay the
     ;; modifications after the new prompt.
     ((and (mistty--changeset-possible-prompt cs)
           (mistty--changeset-restrict cs (mistty--bol (mistty-cursor))))
      (mistty--realize-possible-prompt (mistty--changeset-possible-prompt cs))
      (setq replay t))

     ;; leave all modifications if there's enough of an unmodified
     ;; section at the end. moving the sync mark is only possible
     ;; as long as the term and work buffers haven't diverged.
     ((and (< (mistty--changeset-end cs)
              ;; modifiable limit
              (mistty--bol (point-max) -5))
           (not mistty--need-refresh))
      (let* ((pos (mistty--bol (mistty--changeset-end cs) 3))
             (scrolline (mistty--scrolline-at pos)))
        (mistty--set-sync-mark pos scrolline)))

     (t ;; revert everything

      ;; The following forces a call to refresh, in time, even if
      ;; the process sent nothing new.
      (mistty--needs-refresh)))

    replay))

(defun mistty--cursor-to-point-interaction ()
  "Build a `mistty--interact' to move the cursor to the point."
  (let ((interact (mistty--make-interact 'cursor-to-point))
        (term mistty--term))
    (cl-labels
        ((can-move (from to)
           (and (mistty-on-prompt-p to)
                (not mistty--special-prompt)
                (>= from (point-min))
                (<= from (point-max))
                (>= to (point-min))
                (<= to (point-max))))

         (reached-target-p (target)
           ;; Ignoring skipped spaces is useful as, with
           ;; multiline prompts, it's hard to figure out
           ;; where the indentation should be without
           ;; understanding the language.
           (mistty--same-pos-ignoring-skipped
            (mistty-cursor) target))

         (wait-until-target-reached (target)
           (mistty--interact-wait-for-output-then
            (lambda ()
              (mistty-log "moved cursor to %s (goal: %s, point: %s) "
                          (mistty-cursor) target (point))
              (mistty--interact-done))
            :pred (lambda () (reached-target-p target))))

         ;; Interaction entry point
         (start (&optional _)
           (let ((from (mistty-cursor))
                 (to (point)))
             (unless (can-move from to)
               (mistty-log "move-to-point: can't move there")
               (mistty--interact-done))
             (when (zerop (mistty--distance from to))
               (mistty-log "move-to-point: nothing to do")
               (mistty--interact-done))

             ;; click to move
             (when (mistty--can-click-to-move-p)
               (when-let* ((click-seq (mistty--term-click-on
                                       term to mistty-sync-marker)))
                 (mistty-log "cursor to point: %s -> %s click" from to)
                 (mistty--interact-send interact click-seq)
                 (wait-until-target-reached to)))

             ;; move vertically
             (let ((distance (mistty--vertical-distance from to)))
               (let ((replay-seq (mistty--move-vertically-seq
                                  distance mistty--can-move-vertically)))
                 (when replay-seq
                   (mistty-log "cursor to point: %s -> %s lines: %s (can-move-vertically=%s)"
                               from to distance mistty--can-move-vertically)
                   (mistty--interact-send
                    interact (mistty--translate-replay-seq term replay-seq))
                   (mistty--interact-wait-for-output-then
                    #'move-horizontally
                    :pred (let ((comparison
                                 (cond (mistty--can-move-vertically '=)
                                       ((< distance 0) '<=)
                                       (t '>=))))
                            (lambda ()
                              (funcall comparison 0 (mistty--vertical-distance
                                                     (mistty-cursor) to))))))))

             (move-horizontally)))

         (move-horizontally (&optional _)
           (let ((from (mistty-cursor))
                 (to (point)))
             (unless (can-move from to)
               (mistty--interact-done))
             (when-let* ((distance (mistty--distance from to))
                         (replay-seq (mistty--move-horizontally-seq distance)))
               (mistty-log "cursor to point: %s -> %s distance: %s" from to distance)
               (mistty--interact-send
                interact (mistty--translate-replay-seq term replay-seq))
               (wait-until-target-reached to))
             (mistty--interact-done))))
      (setf (mistty--interact-cb interact) #'start))

    interact))

(defun mistty--same-pos-ignoring-skipped (posa posb)
  "Return non-nil if POSA and POSB are the same, skipped spaces.

This returns non-nil if POSA and POSB are equal or if there are
only spaces with ==\'mistty-skip between them."
  (if (= posa posb)
      t
    (let ((low (min posa posb))
          (high (max posa posb)))
      (not (text-property-any low high 'mistty-skip nil)))))

(defun mistty-terminal-size-tracks-window-p ()
  "Checks whether resizing windows will resize the terminal."
  (null mistty--terminal-size))

(defun mistty-terminal-size-tracks-window ()
  "Set terminal size automatically from the size of the windows.

By default, MisTTY sets the terminal to a size that fits the windows the
buffer is currently displayed in.

This can be modified by calling `mistty-set-terminal-size', which see.
This function reverts to the default behavior."
  (interactive)
  (add-hook 'window-size-change-functions #'mistty--window-size-change nil t)
  (mistty--set-process-window-size-from-windows)
  (setq mistty--terminal-size nil))

(defun mistty-toggle-size-tracks-window ()
  "Enable or disable terminal auto-sizing.

When tracking window size is enabled, MisTTY changes the terminal size
so that the terminal can be displayed fully in a window.

When no tracking window size, terminal size is fixed, but can be
modified manually with `mistty-fit-to-window',
`mistty-set-terminal-size', `mistty-grow-vertically' or
`mistty-grow-horizontally'.

Programmatically, prefer calling either
`mistty-terminal-size-tracks-window' or `mistty-set-terminal-size' after
checking `mistty-terminal-size-tracks-window-p'."
  (interactive)
  (if mistty--terminal-size
      (progn
        (mistty-terminal-size-tracks-window)
        (message "Terminal size tracks window: ON"))
    (let ((w (mistty--term-columns mistty--term))
          (h (mistty--term-lines mistty--term)))
      (mistty-set-terminal-size w h)
      (message "Terminal size %i x %i" w h))))

(defun mistty--check-terminal-size (width height)
  "Make sure that WIDTH and HEIGHT are acceptable term sizes."
  (unless (and width height)
    (user-error "Specify both width and height"))
  (unless (>= width mistty-min-terminal-width)
    (user-error "Terminal width must be at least %s" mistty-min-terminal-width))
  (unless (>= height mistty-min-terminal-height)
    (user-error "Terminal height must be at least %s" mistty-min-terminal-height)))

(defun mistty-set-terminal-size (width height)
  "Set size of the terminal to WIDTH x HEIGHT.

By default, MisTTY sets the terminal to a size that fits the windows the
buffer is currently displayed in.

If you prefer, you can instead give the terminal a fixed dimension. This
might be useful if you're running program that don't check the size of
the terminal before displaying.

To go back to tracking window size, call
`mistty-terminal-size-tracks-window'."
  (interactive "nTerminal width: \nnTerminal height: ")
  (mistty--check-terminal-size width height)
  (remove-hook 'window-size-change-functions #'mistty--window-size-change t)
  (mistty--set-process-window-size width height)
  (setq mistty--terminal-size (cons width height)))

(defun mistty--window-size-change (win)
  "Update the process terminal size, reacting to WIN changing size."
  (mistty-with-errors-logged "window-size-change"
    (when-let* ((buffer (window-buffer win)))
      (with-current-buffer buffer
        (when (and (derived-mode-p 'mistty-mode) (process-live-p mistty-proc))
          (mistty--set-process-window-size-from-windows))))))

(defun mistty--check-window-size (work-buffer)
  "Resize the process window for WORK-BUFFER if necessary.

This function is meant to be called manually or from the idle-timer,
`mistty--check-window-size-timer'."
  (setq mistty--check-window-size-timer nil)
  (mistty--with-live-buffer work-buffer
    (when (and (display-graphic-p)
               mistty-fullscreen
               (not mistty--terminal-size))
      (let ((bottom (mistty--blank-end-start)))
        (when (> bottom mistty-sync-marker)
          (cl-block nil
            (dolist (win (get-buffer-window-list work-buffer))
              (when (and (>= (window-start win) mistty-sync-marker)
                         (not (pos-visible-in-window-p bottom)))
                (mistty-log "WINDOW CHECK %s not visible, recomputing" bottom)
                (mistty--set-process-window-size-from-windows (list win))
                (cl-return)))))))))

(defun mistty--set-process-window-size-from-windows (&optional wins)
  "Adjust process terminal size based on WINS.

WINS default to all the windows displaying the current MisTTY buffer."
  (mistty--check-major-mode)
  (when-let* ((wins (or wins
                        (get-buffer-window-list
                         (current-buffer) nil t))))
    (let ((w (mistty--terminal-width-from-window (car wins)))
          (h (mistty--terminal-height-from-window (car wins))))
      (dolist (win (cdr wins))
        (setq w (min w (mistty--terminal-width-from-window win)))
        (setq h (min h (mistty--terminal-height-from-window win))))
      (mistty-log "set-process-window-size %sx%s" w h)
      (mistty--set-process-window-size w h))))

(defun mistty--terminal-width-from-window (win)
  "Figure out how many terminal columns can fit in WIN."
  (if (display-graphic-p (window-frame win))
      ;; Sacrifice a column as an attempt to display the terminal
      ;; content in a sane way, even with double-width characters.
      ;;
      ;; On a graphical display, when the last displayed char is a
      ;; double-width char, such as an emoji, Emacs decides to wrap
      ;; the line before the double-width character and screws up the
      ;; terminal display even if when character width is exactly two
      ;; characters and would fit into the line.
      (1- (window-max-chars-per-line win))
    (window-max-chars-per-line win)))

(defun mistty--terminal-height-from-window (win)
  "Figure out how many terminal lines can fit in WIN."
  (let ((default-height (with-selected-window win
                          (floor (window-screen-lines)))))
    (or (when (display-graphic-p (window-frame win))
          (with-current-buffer (window-buffer win)
            (when (and (markerp mistty-sync-marker)
                       (< mistty-sync-marker (point-max)))
              ;; Attempt to account for lines containing characters -
              ;; usually emoji - that are taller than normal on a
              ;; graphical display by computing an average line height
              ;; looking at the actual text size.
              ;;
              ;; This is a compromise. We cannot be exact as line
              ;; height changes dynamically on a graphical display.
              ;;
              ;; If we used only the height proposed by the default
              ;; algorithm, we would make the content of the window
              ;; systematically a little larger than the window.
              ;;
              ;; If, on the other hand, we used the maximum line
              ;; height, we would make the content systematically
              ;; smaller than the window can display.
              (let* ((win-height (window-body-height win 'pixelwise))
                     (text-height (cdr (window-text-pixel-size
                                        win mistty-sync-marker (point-max))))
                     (line-count (count-lines mistty-sync-marker (point-max)))
                     (avg-line-height (/ (float text-height) (float line-count))))
                (min default-height
                     (floor (/ (float win-height) avg-line-height)))))))
        default-height)))

(defun mistty--set-process-window-size (width height)
  "Set the process terminal size to WIDTH x HEIGHT.

Width and height are limited to `mistty-min-terminal-width' and
`mistty-min-terminal-height'."
  (when (process-live-p mistty-proc)
    (let ((width (max width mistty-min-terminal-width))
          (height (max height mistty-min-terminal-height)))
      (mistty--term-resize mistty--term width height))))

(defun mistty--enter-fullscreen (work-buffer)
  "Make WORK-BUFFER enter fullscreen mode."
  (mistty--with-live-buffer work-buffer
    (mistty--remove-replay-hooks)
    (mistty--cancel-queue mistty--queue)
    (mistty--release-all-changesets)
    (setq mistty-fullscreen t)
    (mistty--update-secondary-mode)
    (run-hooks 'mistty-entered-fullscreen-hook)
    (mistty-log "Entered fullscreen mode")))

(defun mistty--leave-fullscreen (work-buffer)
  "Make WORK-BUFFER leave fullscreen mode."
  (mistty--with-live-buffer work-buffer
    (let ((inhibit-read-only t)
          (inhibit-modification-hooks t))
      (remove-text-properties mistty-sync-marker (point-max) '(read-only nil)))
    (when mistty-proc
      (mistty--add-replay-hooks))
    (setq mistty-fullscreen nil)
    (mistty--update-secondary-mode)
    (run-hooks 'mistty-left-fullscreen-hook)
    (mistty-log "Left fullscreen mode")))

(defun mistty--update-mode-lines ()
  "Update the mode line of the current MisTTY buffer."
  (mistty--check-major-mode)
  (setq mode-line-process
        (when-let* ((mode (mistty--secondary-mode))
                    (entry (alist-get mode mistty--secondary-mode-alist)))
          (let ((button (plist-get entry :button)))
            (concat
             " "
             ;; Display secondary mode
             (propertize
              (mistty--tag (plist-get entry :tag))
              'help-echo (concat
                          (plist-get entry :help)
                          (when button
                            (concat "\nmouse-1: "
                                    (mistty--mode-line-button button :help))))
              'mouse-face (when button 'mode-line-highlight)
              'local-map (mistty--mode-line-button button))
             ;; Show whether fullscreen map is active
             (let* ((active (eq 'fullscreen-mode-map (mistty--secondary-mode-map)))
                    (tag (cond
                          (active (mistty--tag 'keyboard))
                          (mistty--secondary-mode-map-override
                           (mistty--tag 'keyboard-inactive))
                          (t ""))))
               (when (length> tag 0)
                 (concat
                  " "
                  (propertize
                   tag
                   'help-echo (concat
                               "Fullscreen keymap is " (if active "active" "inactive") "\nmouse-1: "
                               (mistty--mode-line-button 'keyboard :help))
                   'mouse-face 'mode-line-highlight
                   'local-map (mistty--mode-line-button 'keyboard)))))

             ;; Display and toggle mouse reporting
             (when mistty--mouse-reporting-requested
               (let* ((tag (mistty--tag (if mistty--mouse-reporting
                                            'mouse 'mouse-inactive))))
                 (when (length> tag 0)
                   (concat
                    " "
                    (propertize
                     tag
                     'help-echo (format
                                 "Report mouse %s: %s\nmouse-1: %s"
                                 (symbol-name mistty--mouse-reporting-requested)
                                 (if mistty--mouse-reporting "ON" "OFF")
                                 (mistty--mode-line-button 'mouse :help))
                     'mouse-face 'mode-line-highlight
                     'local-map (mistty--mode-line-button 'mouse))))))))))

  (force-mode-line-update))

(defun mistty--tag (id)
  "Return the tag corresponding to ID to be displayed in the mode line.

The tag that is returned depends on the values of `mistty-tag' and
`mistty-tag-alist-alist'."
  (let ((theme-alist (alist-get mistty-tag-theme mistty-tag-alist-alist)))
    (unless theme-alist
      (error "Invalid value for mistty-tag-theme: %s" mistty-tag-theme))

    (let ((val (alist-get id theme-alist)))
      (or (when (stringp val) val)
          (when (and (listp val)
                     (symbolp (car val))
                     (string-prefix-p "nerd-icons-" (symbol-name (car val)))
                     (setq val (eval val))
                     (stringp val))
            (setf (alist-get id theme-alist) val)
            val)
          (error "Incomplete theme in mistty-tag-alist-alist %s: %s is missing or invalid"
                 mistty-tag-theme id)))))

(defun mistty--mode-line-button (id &optional prop)
  "Get the definition of button ID that correspond to PROP.

This is a convenience function for accessing
`mistty--mode-line-button-alist'.

If PROP is nil, return the keymap defined as action, either by :command
or by :menu, in `mistty--mode-line-button-alist'."
  (if prop
      (plist-get
       (alist-get id mistty--mode-line-button-alist)
       prop)
    (let ((entry (alist-get id mistty--mode-line-button-alist)))
      `(keymap
        (mode-line
         keymap
         (down-mouse-1 . ,(if-let* ((menu (plist-get entry :menu)))
                              (symbol-value menu)
                            (plist-get entry :command))))))))

(define-obsolete-function-alias
  'mistty-toggle-buffers 'mistty-toggle "2.0.2snapshot")

(defun mistty-toggle ()
  "Toggle between the scrollback and terminal areas."
  (interactive)
  (mistty--check-major-mode)
  (cond
   ;; go from terminal area to scrollback area
   ((>= (point) mistty-sync-marker)
    (when (<= mistty-sync-marker (point-min))
      (user-error "No accessible scrollback area yet"))
    (goto-char (mistty--bol mistty-sync-marker 0))
    (when (eq (current-buffer) (window-buffer (selected-window)))
      (recenter)))

   ;; go from scrollback area to terminal area
   (t
    (goto-char (mistty-cursor))
    (mistty--maybe-scroll-windows))))

(defun mistty-sudo ()
  "Prepend sudo to the current command."
  (interactive)
  (goto-char (mistty-cursor))
  (execute-kbd-macro (kbd "C-a sudo SPC C-e")))

(defun mistty-on-prompt-p (pos)
  "Return non-nil if POS is on a prompt.

Prompts can span multiple lines; everything after the beginning of a
prompt is treated as being on a prompt, including completion options
displayed below the prompt as fish or zsh do."
  (and mistty-sync-marker
       (mistty--active-prompt)
       (>= pos mistty-sync-marker)))

(defun mistty-before-positional ()
  "Prepare the state for executing a positional command.

This creates any possible prompts that were detected at the last
minute. If a prompt is created, it also moves the cursor to the
point, as this is only done by the post-command hook on detected
prompts."
  (mistty--enqueue
   mistty--queue
   (mistty--interact before-positional (interact)
     (let ((cursor (mistty-cursor)))
       (when (and (mistty-maybe-realize-possible-prompt)
                  (not (= cursor (point))))
         (mistty--enqueue
          mistty--queue
          (mistty--cursor-to-point-interaction)
          'prepend))
       (mistty--interact-done)))))

(defun mistty-maybe-realize-possible-prompt (&optional pos)
  "If POS looks like it's on a possible prompt, create it now."
  (when (or (= (or pos (point)) (mistty-cursor))
            (= (pos-bol) (mistty--bol (mistty-cursor))))
    (when-let* ((prompt (mistty--detect-possible-prompt)))
      (mistty--realize-possible-prompt prompt)

      t)))

(defun mistty--detect-possible-prompt ()
  "Check if there might be a prompt at the cursor position.

If there is a a possible prompt at the position, return it. The prompt
can later be created with `mistty--realize-possible-prompt'."
  (save-excursion
    (goto-char (mistty-cursor))
    (let ((scrolline (mistty--scrolline-at-point))
          (scrolline-start (mistty--scrolline-start-pos))
          (prev-prompt (car (mistty--prompt-cell-archive mistty--prompt-cell))))
      (if (or
           (and
            ;; there's no active prompt
            (null (mistty--active-prompt))

            ;; not in a continuation line
            (= scrolline-start (pos-bol))
            ;; not already checked or had a prompt there
            (> scrolline mistty--last-prompt-considered)
            (or (null prev-prompt)
                (>= scrolline (or (mistty--prompt-end prev-prompt)
                                  (1+ (mistty--prompt-start prev-prompt)))))

            ;; it looks like a prompt
            (string-match-p
             mistty--prompt-regexp
             (mistty--safe-bufstring scrolline-start (point)))

            ;; it's at the very end of the buffer
            (progn
              (skip-chars-forward " \n")
              (eobp))))

          ;; Possible prompt at cursor
          (mistty--make-prompt
           :source 'regexp :start scrolline :end (1+ scrolline))

        ;; No possible prompt at cursor. Remember we checked this
        ;; position and rejected it
        (setq mistty--last-prompt-considered scrolline)

        nil))))

(defun mistty--realize-possible-prompt (prompt)
  "Add and realize PROMPT."
  (when (and (not (mistty--get-prompt mistty--prompt-cell))
             (mistty--maybe-move-sync-mark
              (mistty--prompt-start prompt)))
    (mistty--term-start-regexp-prompt
     mistty--term (mistty--prompt-start prompt))
    (mistty--set-prompt mistty--prompt-cell prompt)
    (setf (mistty--prompt-realized prompt) t)
    (mistty-log "Realized %s prompt #%s [%s-] @%s"
                (mistty--prompt-source prompt)
                (mistty--prompt-input-id prompt)
                (mistty--prompt-start prompt)
                (marker-position mistty-sync-marker))

    (mistty--update-secondary-mode)))

(defun mistty--prompt-contains-pos (prompt pos)
  "Return non-nil if POS is inside PROMPT."
  (when-let* ((scrolline (mistty--prompt-start prompt))
              (start (mistty--find-scrolline scrolline))
              (length (if-let* ((text (mistty--prompt-text prompt)))
                          (length text)
                        0))
              (user-input-start (+ start length)))
    (and (>= pos user-input-start) (<= pos (mistty--eol start)))))

(defun mistty--create-backstage (term)
  "Create a backstage buffer for TERM.

A backstage buffer is a partial copy of TERM's virtual terminal that's
kept up-to-date in a way that allows markers can be used to keep
positions stable while the buffer is being modified.

The value of the buffer-local variables `mistty-log', and
`mistty-bracketed-paste' are carried over to the backstage buffer."
  (let ((backstage (generate-new-buffer " *mistty-backstage" t))
        (sync-scrolline mistty--scrolline-home-num))
    (with-current-buffer backstage
      (setq-local mistty-sync-marker (point-min))
      (mistty--init-scrolline (point-min) sync-scrolline)
      (setq-local mistty--term term)
      (setq-local mistty--cursor (make-marker))
      (mistty--update-backstage))
    backstage))

(defun mistty--update-backstage ()
  "Update backstage to catch up to its process output.

The current buffer must be a backstage buffer, created by
`mistty--create-backstage'.

The point is set to the equivalent of proc marker
position (cursor) in the buffer."
  (mistty-log "RENDER BACKSTAGE @%s" mistty--scrolline-home-num)
  (mistty--term-sync-backstage
   mistty--term mistty--scrolline-home-num mistty--cursor))

(defun mistty--delete-backstage (backstage)
  "Gets rid of a BACKSTAGE buffer."
  (when (buffer-live-p backstage)
    (kill-buffer backstage)))

(defun mistty--cursor-skip (win)
  "Move WIN point to skip fake spaces and newlines.

This function skips spaces marked with ==\'mistty-skip, depending
on the direction of the last move.

This is meant to be added to `pre-redisplay-functions'"
  (when (and (not mistty-fullscreen)
             mistty-proc
             (process-live-p mistty-proc))
    (let (pos last-pos move-to)
      (when (and mistty-skip-empty-spaces
                 ;; Never move point at cursor.
                 (not (equal (point) (mistty-cursor)))
                 (mistty-on-prompt-p (setq pos (window-point win))))
        (when-let* ((last-state (window-parameter win 'mistty--cursor-skip-state)))
          (when (eq (car last-state) (current-buffer))
            (setq last-pos (cdr last-state))))
        (unless (equal pos last-pos)
          (pcase-dolist (`(,beg . ,end)
                         (mistty--cursor-skip-ranges
                          pos (lambda (type)
                                (memq type '(indent right-prompt continue-prompt empty-lines-at-eob dead)))))
            (unless move-to
              (setq
               move-to
               (cond
                ;; at the end of the range, which is also eob, move to beg
                ((and end (or (>= end (point-max))
                              (and (>= end (point-min))
                                   (eq 'empty-lines-at-eob
                                       (get-text-property end 'mistty-skip)))))
                 beg)

                ;; at a boundary, stay there
                ((or (null beg) (null end) (= pos beg) (= pos end)) nil)

                ;; horizontal movement from the left, go right
                ((and last-pos (<= last-pos beg) (mistty--same-line-p last-pos beg))
                 end)
                ;; horizontal movement from the right, go left
                ((and last-pos (>= last-pos end) (mistty--same-line-p last-pos end))
                 beg)
                ;; vertical move; on beg's line, so go to beg
                ((and (mistty--same-line-p pos beg) (not (mistty--same-line-p pos end)))
                 beg)
                ;; vertical move; on end's line, so go to end
                ((and (mistty--same-line-p pos end) (not (mistty--same-line-p pos beg)))
                 end)
                ;; closer to beg than to end, go to beg
                ((< (- pos beg) (- end pos))
                 beg)
                ;; otherwise go to end
                (t
                 end)))
              (when (equal move-to pos)
                (setq move-to nil))
              (when move-to
                (mistty-log "CURSOR MOVE beg %s end %s pos %s last-pos %s -> %s"
                            beg end pos last-pos move-to))))
          (when move-to
            (set-window-point win move-to))
          (set-window-parameter win 'mistty--cursor-skip-state
                                (cons (current-buffer) (or move-to pos))))))))

(defun mistty--cursor-skip-forward (pos)
  "Return the right end of the skip ranges containing POS.

Return POS if not in any skip ranges."
  (or (cdr (car (last (mistty--cursor-skip-ranges pos)))) pos))

(defun mistty--cursor-skip-ranges (pos &optional type-condition)
  "Ranges of spaces and newlines to skip over that contain POS.

Return a list of ( BEG . END ), sorted by BEG, increasing.

TYPE-CONDITION applies to mistty-skip types and defaults to skipping all
of them."
  (let ((beg (mistty--cursor-incomplete-skip-backward pos type-condition))
        (end (mistty--cursor-incomplete-skip-forward pos type-condition))
        (ranges nil))
    (save-excursion
      (goto-char beg)
      (while (and (> end (point))
                  (search-forward-regexp "\n *\n" end 'noerror))
        (let ((cursor (min (+ (match-beginning 0) 1
                              (mistty--line-indent beg))
                           (1- (match-end 0))))
              (actual-cursor (mistty-cursor)))
          (when (and actual-cursor
                     (> actual-cursor (match-beginning 0))
                     (< actual-cursor (match-end 0)))
            (setq cursor actual-cursor))
          (cond
           ((< pos cursor)
            (setq end cursor))
           ((> pos cursor)
            (setq beg cursor))
           (t ; (= pos cursor)
            (push (cons beg cursor) ranges)
            (setq beg cursor)))

          ;; The last \n can be the first \n of the next match.
          (goto-char (1- (match-end 0))))))
    (unless (= beg end)
      (push (cons beg end) ranges))
    (nreverse ranges)))

(defun mistty--line-indent (pos)
  "Return the intentation of the line at POS.

If the line contains a prompt, the indentation is the length of
the prompt from the beginning of the line."
  (save-excursion
    (goto-char (mistty--bol pos))
    (skip-chars-forward " ")))

(defun mistty--cursor-incomplete-skip-forward (pos type-condition)
  "Return the position of next non-skipped char after POS.

This implementation is incomplete. Always call
`mistty--cursor-skip-ranges' or `mistty--cursor-skip-forward' to
get correct results.

TYPE-CONDITION applies to mistty-skip types."
  (let ((stop nil)
        (type-condition (or type-condition #'identity)))
    (while (and (not stop)
                (< pos (point-max)))
      (cond
       ((and (eq ?\n (char-after pos))
             (or (and (> pos (point-min))
                      (funcall type-condition (get-text-property (1- pos) 'mistty-skip)))
                 (and (< pos (point-max))
                      (funcall type-condition (get-text-property (1+ pos) 'mistty-skip)))))
        (cl-incf pos))
       ((funcall type-condition (get-text-property pos 'mistty-skip))
        (setq pos (next-single-property-change
                   pos 'mistty-skip nil (point-max))))
       (t
        (setq stop t)))))
  pos)

(defun mistty--cursor-incomplete-skip-backward (pos type-condition)
  "Return the position of previous non-skipped char before POS.

This implementation is incomplete. Always call
`mistty--cursor-skip-ranges' to get correct results.

TYPE-CONDITION applies to mistty-skip types and defaults to skipping all
of them."
  (let ((stop nil)
        (type-condition (or type-condition #'identity)))
    (while (and (not stop) (> pos (point-min)))
      (cond
       ((and (eq ?\n (char-before pos))
             (or (funcall type-condition (get-text-property pos 'mistty-skip))
                 (and (>= (- pos 2) (point-min))
                      (funcall type-condition (get-text-property (- pos 2) 'mistty-skip)))))
        (cl-decf pos))
       ((funcall type-condition (get-text-property (1- pos) 'mistty-skip))
        (setq pos (previous-single-property-change
                   pos 'mistty-skip nil (point-min))))
       (t
        (setq stop t)))))
  pos)

(defun mistty--vertical-distance (beg end)
  "Compute the number up/down key presses to get from BEG to END.

Note that moving that distance vertically only gets the cursor to
the *line* on which END is."
  (mistty--count-lines beg end #'mistty--real-nl-p))

(defun mistty--distance (beg end)
  "Compute the number left/right key presses to get from BEG to END.

This function skips over the \\='term-line-wrap newlines as well
as \\='mistty-skip spaces."
  (let ((end (mistty--safe-pos (max beg end)))
        (sign (if (< end beg) -1 1))
        (pos (mistty--safe-pos (min beg end)))
        (count 0))
    (while (< pos end)
      (if (get-text-property pos 'term-line-wrap)
          ;; skip fake newlines
          (setq pos (1+ pos))
        (pcase-let ((`(,skip-beg . ,skip-end)
                     (car (last (mistty--cursor-skip-ranges pos)))))
          (cond
           ((or (null skip-beg) (null skip-end))
            ;; the position is not to be skipped over; count it towards
            ;; count.
            (setq pos (1+ pos))
            (setq count (1+ count)))
           ((= pos skip-end)
            (setq count (1+ count))
            (setq pos (1+ pos)))
           ((and (= pos skip-beg) (<= skip-end end))
            ;; we skipped a whole region; count it as 1 towards
            ;; count.
            (setq pos skip-end)
            (setq count (1+ count)))
           (t
            ;; we skipped a partial region; don't count it towards
            ;; count at all.
            (setq pos skip-end))))))
    (* sign count)))

(defun mistty-report-long-running-command (id active)
  "Report whether a specific long-running command is active.

MisTTY's replaying of modifications is turned off while a
long-running command is active, so the command can run without
interference. The result of the command is sent to the shell once
it's inactive.

MisTTY detects some long-running commands on its own by tracking
overlay, when `mistty-detect-foreign-overlays' is turned on. It
also detects completion in region by tracking
`completion-in-region-mode'.

Call this function when you'd like to use long-running command
that's not detected by MisTTY.

ID is a symbol that identifies the long-running command, so that
you can track and report several such commands without worrying
about interference. The same naming convention as you would for
functions to keep them unique.

If ACTIVE evaluates to true, report the long-running command as
active, which inhibits MisTTY's normal operation for the duration
of the command. If ACTIVE is nil, report the long-running command
as inactive, which turns MisTTY on again and triggers replaying
of any changes made in the terminal zone during that
command (unless a command with another ID is active; check with
`mistty-long-running-command-p')."
  (mistty--check-major-mode)
  (mistty--inhibit-set id active))

(defun mistty-long-running-command-p ()
  "Return non-nil if a long-running command is active.

See `mistty-report-long-running-command'."
  (mistty--check-major-mode)
  (if mistty--inhibit t nil))

(defun mistty-ignore-long-running-command ()
  "Ignore any long-running command currently active.

If MisTTY appears to be stuck, it might be because the end of
some long-running command hasn't been reported. This will
un-stuck MisTTY. It will not address the root cause of the
problem, however, which might be a bug in usage of
`mistty-report-long-running-command' or a bug in MisTTY. In the
later case, please file a bug report on
https://github.com/szermatt/mistty/issues"
  (interactive)
  (mistty--check-major-mode)
  (if mistty--inhibit
      (progn
        (message "MisTTY: ignore long-running command %s" mistty--inhibit)
        (mistty--inhibit-clear))
    (error "MisTTY: no long-running command is active")))

(defun mistty--wrap-capf-functions ()
  "Wrap the content `completion-at-point-functions' locally.

This function applies `mistty-capf-wrapper' to all function on
`completion-at-point-functions' in the current buffer.

This can be turned off by setting the option
`mistty-wrap-capf-functions' to nil."
  (when mistty-wrap-capf-functions
    (let ((capf-list (cl-copy-list completion-at-point-functions)))
      (setq-local completion-at-point-functions capf-list)
      (while capf-list
        (add-function :around (car capf-list) #'mistty-capf-wrapper)
        (setq capf-list (cdr capf-list))))))

(defun mistty-capf-wrapper (func &rest args)
  "Run FUNC with ARGS, with buffer narrowed to point.

This wrapper is meant to be applied to functions on
`completion-at-point-functions' to prevent them from seeing
autosuggestions. For details, see the option
`mistty-wrap-capf-functions'."
  (if (and (markerp mistty-sync-marker)
           (> (point) mistty-sync-marker))
      (save-restriction
        (narrow-to-region (point-min) (point))
        (apply func args))
    (apply func args)))

(defun mistty-kill-buffer (proc)
  "Kill MisTTY work buffer if PROC ended successfully.

This is meant to be added to `mistty-after-process-end-hook` if
you don't want a MisTTY buffer to remain after the shell ends. Be
sure that you never care for the buffer content after the shell
ends, as, in this case, it is simply lost.

Usage example:

  (add-hook \\='mistty-after-process-end-hook
            \\='mistty-kill-buffer)"
  (mistty--at-end proc 'kill-buffer))

(defun mistty-kill-buffer-and-window (proc)
  "Kill MisTTY work buffer and window if PROC ended successfully.

This is meant to be added to `mistty-after-process-end-hook` if
you don't want a MisTTY buffer and window to remain after the
shell ends. Be sure that you never care for the buffer content
after the shell ends, as, in this case, it is simply lost.

Usage example:

  (add-hook \\='mistty-after-process-end-hook
            \\='mistty-kill-buffer-and-window)"
  (mistty--at-end proc 'kill-buffer-and-window))

(defun mistty--at-end (proc &optional option-override)
  "Consider whether buffer and window should be kill.

This is called by `mistty-after-process-end-hook' and to apply the value
of option `mistty-after-end'.

PROC is the process that just ended.

If OPTION-OVERRIDE is non-nil, use that instead of the value of
`mistty-at-end'."
  (let ((option (or option-override mistty-at-end)))
    (when (and (memq option '(kill-buffer kill-buffer-and-window))
               (eq 'exit (process-status proc))
               (zerop (process-exit-status proc))
               mistty--interacted)
      (let ((buf (current-buffer))
            (win (get-buffer-window)))
        (cond
         ((eq option 'kill-buffer) (kill-buffer buf))
         ((eq option 'kill-buffer-and-window)
          (if (and (kill-buffer buf)
                   (window-parent win))
              (ignore-errors (delete-window)))))))))

(defun mistty--secondary-mode (&optional prop)
  "Return a property of the current secondary mode.

If PROP is nil, return the ID, otherwise return the property defined in
`mistty--secondary-mode-alist' for the current secondary mode.

The ID corresponds to an entry in `mistty--secondary-mode-alist'."
  (let ((id (cond
             (mistty--capture-keyboard-active 'capture)
             ((or (not mistty-proc) (not (process-live-p mistty-proc))) 'dead)
             (mistty-fullscreen 'full)
             (mistty--inhibit 'off)
             (mistty--special-prompt 'special-prompt)
             ((mistty--active-prompt) 'prompt)
             ((and mistty-proc (process-live-p mistty-proc)) 'running)
             (t 'running))))
    (if prop
        (plist-get (alist-get id mistty--secondary-mode-alist) prop)
      id)))

(defun mistty--update-secondary-mode ()
  "Update the secondary mode map and mode line.

This should be called after changing anything that affects the secondary
mode."
  (mistty--check-major-mode)
  (mistty-log "Update secondary mode")
  (mistty--update-secondary-mode-map)
  (mistty--update-mode-lines))

(defun mistty--secondary-mode-map ()
  "Return the secondary mode map.

This merges the map configured in `mistty--secondary-mode-alist' with
`mistty--secondary-mode-map-override'"
  (when-let* ((map-id (mistty--secondary-mode :map)))
    (or mistty--secondary-mode-map-override map-id)))

(defun mistty--update-secondary-mode-map ()
  "Install the appropriate keymap in the terminal area.

The keymap that is installed depends on the secondary mode and secondary
mode map override."
  (let* ((map-id (mistty--secondary-mode-map))
         (maps (pcase map-id
                 ('prompt-map (list mistty-prompt-map))
                 ('special-prompt-map
                  (list
                   mistty-special-prompt-map mistty-prompt-map))
                 ('fullscreen-mode-map
                  (list
                   mistty-fullscreen-mode-map mistty-prompt-map))
                 (_ nil))))
    (mistty-log "Install overlay map %s [mode: %s, mouse: %s]"
                map-id (mistty--secondary-mode) mistty--mouse-reporting)
    (when mistty--mouse-reporting
      (push mistty--report-click-map maps))
    ;; TODO: add maps for 'motion and mouse wheel

    (overlay-put
     mistty--sync-ov
     'keymap
     (if (length> maps 1)
         (make-composed-keymap maps)
       (car maps)))))

(defun mistty-keymap-auto ()
  "Switch back to the default map for the mode.

This switches back to using `mistty-prompt-map' or
`mistty-fullscreen-mode-map' as appropriate for the current terminal
mode. This reverts any override set by `mistty-toggle-keymap'.

This is equivalent to calling `mistty-toggle-keymap' with an argument
\\='auto."
  (interactive)
  (mistty-toggle-keymap 'auto))

(defun mistty-toggle-keymap (&optional map)
  "Toggle terminal area keymap between prompt and fullscreen.

When called interactively, this command toggles
`mistty-fullscreen-mode-map' on or off.

When called with an argument MAP, the behavior depends on the argument
value:

If MAP is \\='toggle or nil, toggle the fullscreen map on or off.
If MAP is \\='auto, switch back to the default.
If MAP is \\='fullscreen, force the fullscreen map on,
    `mistty-fullscreen-mode-map'.
If MAP is \\='prompt, force the prompt map on, `mistty-prompt-map'.

Note that this setting is normally only active until the next terminal
state changes, as the default value of both
`mistty-entered-fullscreen-hook' and `mistty-left-fullscreen-hook' call
`mistty-keymap-auto' to reset the map override."
  (interactive)
  (pcase map
    ('auto
     (unless (null mistty--secondary-mode-map-override)
       (message "MisTTY keymap: auto")
       (setq mistty--secondary-mode-map-override nil)
       (mistty--update-secondary-mode)))
    ('fullscreen
     (unless (eq mistty--secondary-mode-map-override 'fullscreen-mode-map)
       (message "MisTTY keymap: fullscreen")
       (setq mistty--secondary-mode-map-override 'fullscreen-mode-map)
       (mistty--update-secondary-mode)))
    ('prompt
     (unless (eq mistty--secondary-mode-map-override 'prompt-map)
       (message "MisTTY keymap: prompt")
       (setq mistty--secondary-mode-map-override 'prompt-map)
       (mistty--update-secondary-mode)))
    ((or 'toggle (pred null))
     (let* ((auto (mistty--secondary-mode :map))
            (current (or mistty--secondary-mode-map-override auto))
            (goal (if (eq current 'prompt-map)
                      'fullscreen-mode-map
                    'prompt-map)))
       (cond
        ((eq goal auto)
         (mistty-toggle-keymap 'auto))
        ((eq goal 'prompt-map)
         (mistty-toggle-keymap 'prompt))
        ((eq goal 'fullscreen-mode-map)
         (mistty-toggle-keymap 'fullscreen)))))
    (_ (error "Invalid argument %s" map))))

(defun mistty-toggle-mouse ()
  "Toggle mouse reporting on or off."
  (interactive)
  (if (not mistty--mouse-reporting-requested)
      (user-error "Application did not request mouse reporting")
    (if mistty--mouse-reporting
        (progn
          (setq mistty--mouse-reporting nil)
          (message "Mouse reporting OFF"))
      (setq mistty--mouse-reporting t)
      (message "Mouse reporting ON"))
    (mistty--update-secondary-mode)))

(defun mistty-new-buffer-name ()
  "Generate a name for a new MisTTY buffer.

This function interprets the customization option
`mistty-buffer-name' within the current context and returns the
result."
  (with-connection-local-variables
   (concat "*"
           (mapconcat
            (lambda (part)
              (if (functionp part)
                 (funcall part)
                part))
            mistty-buffer-name)
           "*")))

(defun mistty-buffer-name-shell ()
  "Return the short name of the shell to be run.

For example, if the command that's run is \"/usr/bin/bash\", this
function returns \"bash\".

This function is meant to be used in the configuration option
`mistty-buffer-name'. It relies on `mistty-shell-command' being
set by `mistty-create' in the environment the function is called."
  (file-name-sans-extension
   (file-name-nondirectory (if (consp mistty-shell-command)
                               (car mistty-shell-command)
                             mistty-shell-command))))

(defun mistty-buffer-name-user ()
  "TRAMP user, if not the current user, as \"-<user>\".

This function is meant to be used in the configuration option
`mistty-buffer-name'."
  (when-let* ((remote-user (file-remote-p default-directory 'user)))
    (unless (string= (getenv "USER") remote-user)
      (concat "-" remote-user))))

(defun mistty-buffer-name-host ()
  "TRAMP host, if not localhost, as \"@<host>\".

This function is meant to be used in the configuration option
`mistty-buffer-name'."
  (when-let* ((remote-host (file-remote-p default-directory 'host)))
    (unless (string= remote-host (system-name))
      (concat "@" remote-host))))

(defun mistty-about ()
  "Display MisTTY version and module information."
  (interactive)
  (message "MisTTY %s module %s"
           mistty-version (mistty-alacritty-modulename)))

(defun mistty--translate-key (key n)
  "Return the byte representation for sending KEY N times.

This chooses the correct representation for the current terminal."
  (mistty--term-translate-key mistty--term key n))

(defun mistty--translate-replay-seq (term replay-seq)
  "Translate REPLAY-SEQ into a sequence for terminal TERM.

Replay sequences are written in a mini-language as a list with the
following elements:
- str, sent as-is to the terminal
- (paste <str>) str is escaped with bracketed-paste then sent to the terminal
- (repeat n <seq>) repeat the given sequence n times
- up down left right, sent as arrow keys
- bol, eol, sent as control-A and control-E
- `kill-line', sent as control-K
- bs, backspace
- del, delete

The result is a vector of bytes, ready to be sent to the terminal."
  (mapconcat
   (lambda (elt)
     (pcase elt
       ('bol (mistty--term-translate-key term [?\C-a]))
       ('eol (mistty--term-translate-key term [?\C-e]))
       ('kill-line (mistty--term-translate-key term [?\C-k]))
       ('up (mistty--term-translate-key term [up]))
       ('down (mistty--term-translate-key term [down]))
       ('left (mistty--term-translate-key term [left]))
       ('right (mistty--term-translate-key term [right]))
       ;; This isn't correct if the kitty keyboard protocol is
       ;; enabled, but it's also the only thing that actually works.
       ;; TODO: find a way to make this work properly
       ('del "\b")
       (`(repeat ,n ,seq)
        (let ((term-seq (mistty--translate-replay-seq term seq)))
          (if (> n 1)
              (mapconcat
               (lambda (_) term-seq)
               (make-list n nil)
               "")
            term-seq)))
       (`(paste ,str) (mistty--bracketed-str str))
        ;; todo: support kkp's "Report all keys as escape codes"
        ((pred stringp) (encode-coding-string elt 'utf-8))
        (_ (error "Invalid replay-seq element: %S" elt))))
   replay-seq ""))

(defun mistty-fit-to-window ()
  "Make sure the terminal size matches selected window size.

This command resize the terminal to match the current window.

This is especially useful on a graphical display when the number of
lines computed to match window height doesn't match the height of the
terminal content anymore, as Emacs changes line height dynamically on a
graphical display."
  (interactive)
  (let ((win (selected-window)))
    (mistty--set-process-window-size-from-windows (list win))
    (when (and mistty-fullscreen (markerp mistty-sync-marker))
      (set-window-start win mistty-sync-marker))
    (let ((width (mistty--term-columns mistty--term))
          (height (mistty--term-lines mistty--term)))
      (when mistty--terminal-size
        (setq mistty--terminal-size (cons width height)))
      (message "Terminal size %i x %i%s"
               width height
               (if mistty--terminal-size
                   ""
                 " (Tracks windows: ON)")))))

(defun mistty-grow-vertically (&optional delta)
  "Increase the height of the virtual terminal.

This command switches the terminal to a fixed dimension and increase the
current size by DELTA. When called interactively DELTA can be provided
using a command argument.

Call `mistty-fit-to-window' to make the window fit the window again once
you're done.

If DELTA is negative, the window height is decreased."
  (interactive "p")
  (let ((delta (or delta 1))
        (width (mistty--term-columns mistty--term))
        (height (mistty--term-lines mistty--term)))
    (message "Terminal size %i x %i%+i" width height delta)
    (mistty-log "Terminal size %i x %i%+i" width height delta)
    (mistty-set-terminal-size width (+ height delta))))

(defun mistty-shrink-vertically (&optional delta)
  "Decrease the height of the virtual terminal.

This command switches the terminal to a fixed dimension and decrease the
current size by DELTA. When called interactively DELTA can be provided
using a command argument.

Call `mistty-fit-to-window' to make the window fit the window again once
you're done.

If DELTA is negative, the window height is increased."
  (interactive "p")
  (mistty-grow-vertically (- (or delta 1))))

(defun mistty-report-mouse-event (ev)
  "Report mouse event EV to the terminal."
  (interactive "e")
  (mistty-with-errors-logged "mistty-report-mouse-events"
    (let* ((posn (event-end ev))
           (win (posn-window posn))
           (buf (window-buffer win))
           (basic-type (event-basic-type ev))
           (mods (event-modifiers ev)))

      ;; Click selects the window
      (when (and (eq 'mouse-1 basic-type)
                 (memq 'down mods))
        (select-window win))

      (with-current-buffer buf
        (when (eq 'mistty-mode major-mode)
          (let ((proc (mistty--term-proc mistty--term)))
            ;; Move point to cursor, if necessary.
            (goto-char mistty--cursor)
            (set-window-point win mistty--cursor)
            (set-window-parameter win 'mistty--cursor-skip-state nil)

            ;; Send mouse event
            (mistty-log "MOUSE EVENT: %S" ev)
            (when-let* ((seq (mistty--term-translate-mouse
                              mistty--term ev nil mistty-sync-marker)))
              (when (process-live-p proc)
                (mistty-log "MOUSE EVENT SEND: %S" seq)
                (process-send-string proc seq)))

            ;; If mouse drag is requested, keep tracking the mouse
            ;; until the button is released.
            (when (and (memq basic-type '(mouse-1 mouse-2))
                       (memq 'down mods)
                       mistty--mouse-reporting
                       (memq mistty--mouse-reporting-requested '(drag motion))
                       ;; TODO: add separate support for motion and just
                       ;; check for drag here
                       (process-live-p proc))
              (mistty-log "TRACKING MOUSE ON (drag)")
              (track-mouse
                (let ((continue t))
                  (while continue
                    ;; We must use read-key and not read-event on
                    ;; terminals to get mouse event translation.
                    (pcase (read-key nil 'disable-fallback)
                      (`(mouse-movement ,posn)
                       (mistty-log "MOUSE MOVE EVENT col,row: %s x,y: %s"
                                   (posn-col-row posn) (posn-x-y posn))
                       (when-let* ((seq (mistty--term-translate-mouse
                                         mistty--term ev posn mistty-sync-marker)))
                         (mistty-log "MOUSE MOVE EVENT SEND: %S" seq)
                         (process-send-string proc seq)))

                      ((and (pred mouse-event-p)
                            `,move-ev
                            (guard (eq basic-type (event-basic-type move-ev))))
                       (mistty-log "MOUSE EVENT (drag end): %S" move-ev)
                       (when-let* ((seq (mistty--term-translate-mouse
                                         mistty--term move-ev nil mistty-sync-marker)))
                         (mistty-log "MOUSE EVENT SEND: %S" seq)
                         (process-send-string proc seq))
                       (setq continue nil)))))
                (mistty-log "TRACKING MOUSE OFF (drag)")

                nil))))))))

(defun mistty--check-frame-focus ()
  "Check and report whether focus was lost or gained for all buffer."
  (dolist (buf (buffer-list))
    (mistty--check-buffer-focus buf)))

(defun mistty--check-window-focus (win)
  "Check and report whether focus was lost or gained for WIN.

This function check WIN's buffer and WIN's old buffer. It is meant to be
used in hooks that report change to the selection or buffer of WIN."
  (let ((cur (window-buffer win))
        (old (window-buffer win)))
  (mistty--check-buffer-focus cur)
  (when (and (windowp old) (not (eq cur old)))
    (mistty--check-buffer-focus old))))

(defun mistty--check-buffer-focus (buf)
  "Check and report whether focus was lost or gained for BUF."
  (when (mistty-buffer-p buf)
    (with-current-buffer buf
      (let ((focused
             (not (not
                   (seq-some
                    (lambda (w)
                      (let ((f (window-frame w)))
                        (and
                         (frame-focus-state f)
                         (eq w (frame-selected-window f)))))
                    (get-buffer-window-list buf nil t))))))

        (unless (eq focused (not (not mistty--focused)))
          (setq mistty--focused focused)
          (mistty--report-focus))))))

(defun mistty-focused-p ()
  "Return non-nil if the current buffer's terminal is focused.

A terminal is focused is it is shown in at least one selected window of
a focused Emacs frame."
  mistty--focused)

(defun mistty--report-focus ()
  "Report focus to the application, if enabled."
  (let ((proc (mistty--term-proc mistty--term)))
    (when (and mistty--report-focus (process-live-p proc))
      (pcase-let ((`(,seq . ,msg) (if mistty--focused
                                      '("\e[I" . "IN")
                                    '("\e[O" . "OUT"))))
        (mistty-log "SEND %S (FOCUS %s)" seq msg)
        (process-send-string proc seq)))))

(defvar-local mistty--original-cursor nil
  "The local value `cursor-type' had before it was hidden.

Will be nil even though the cursor is hidden if the cursor had no
local value. `mistty--show-cursor' then restores the global
value.

Used in `mistty--hide-cursor' and `mistty--show-cursor'.")

(defun mistty--hide-cursor ()
  "Temporarily hide the cursor.

Does nothing if the cursor is already hidden."
  (when cursor-type
    (if (local-variable-p 'cursor-type)
        (setq mistty--original-cursor cursor-type)
      (setq mistty--original-cursor nil))
    (setq cursor-type nil)))

(defun mistty--show-cursor ()
  "Show the cursor again, after `mistty--hide-cursor'.

Does nothing if the cursor is already shown."
  (when (and (local-variable-p 'cursor-type) (null cursor-type))
    (if mistty--original-cursor
        (setq cursor-type mistty--original-cursor
              mistty--original-cursor nil)
      (kill-local-variable 'cursor-type))))

(when (eval-when-compile (>= emacs-major-version 30))
  ;; This avoids requiring the notifications package for a feature
  ;; that may not be used.
  (autoload 'notifications-notify "notifications")
  (declare-function notifications-notify "notifications")
  (autoload 'truncate-string-to-width "mule-util")

  (defun mistty-notify-command-finished (status)
    "Notify about finished commands.

This function is meant to be added to `mistty-command-finished-hook'.

The behavior of this command is controlled by the option
`mistty-notify-on-command-finished', which see."
    (when (or (eq t mistty-notify-on-command-finished)
              (and (eq 'unfocused mistty-notify-on-command-finished)
                   (not (mistty-focused-p))))

      (notifications-notify
       :title "Command finished"
       :body (format "Command%s finished%s"
                     (if-let* ((cmdline (mistty-previous-cmdline 1)))
                         (format
                          " '%s'"
                          (truncate-string-to-width
                           cmdline 20 nil nil "…"))
                       "")
                     (cond
                      ((equal 0 status) " successfully")
                      ((numberp status) (format " with status %s" status))
                      (t  "")))
       :actions '("default" "Go to buffer")
       :on-action (let ((buf (current-buffer)))
                    (lambda (_id key)
                      (when (equal "default" key)
                        (pop-to-buffer buf))))))))

(provide 'mistty)

;;; mistty.el ends here
