;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20261016.1905"
  "30 new custom blocks & 34 link types for Org-mode."
  '((s     "1.13.1")
    (dash  "2.18.1")
    (emacs "28.2")
    (org   "9.8")
    (lf    "26.10.1")
    (seq   "2.0"))
  :url "https://alhassy.github.io/org-special-block-extras"
  :commit "ab6edb56b6931e80a5ea1a6d5bc6a0afb06241cd"
  :revdesc "ab6edb56b693"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
