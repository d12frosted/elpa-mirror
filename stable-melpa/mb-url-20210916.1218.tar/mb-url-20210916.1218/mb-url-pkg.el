(define-package "mb-url" "20210916.1218" "Multiple Backends for Emacs URL package"
  '((emacs "24.4"))
  :commit "23a80edd1a98700db5f29019944b52b70fbcb327" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
