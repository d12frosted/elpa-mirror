;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260406.1238"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "20586fd827aa7222ed39b18de0821c29eb88e687"
  :revdesc "20586fd827aa"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
