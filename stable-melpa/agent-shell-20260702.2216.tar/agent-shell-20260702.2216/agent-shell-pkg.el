;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260702.2216"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a894020ddce9c0fc7db81555a8ba7cf0fb124449"
  :revdesc "a894020ddce9")
