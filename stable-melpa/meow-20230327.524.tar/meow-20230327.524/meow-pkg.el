(define-package "meow" "20230327.524" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "d80c2ff2f94333492dd7714c4210440162985b20" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
