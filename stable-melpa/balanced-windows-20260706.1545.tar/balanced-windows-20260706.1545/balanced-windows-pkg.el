;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "balanced-windows" "20260706.1545"
  "Keep windows balanced."
  '((emacs "25"))
  :url "https://github.com/wbolster/emacs-balanced-windows"
  :commit "f94f9cbe832147396bb0d67e687a9dc33ec2a2c5"
  :revdesc "f94f9cbe8321"
  :keywords '("convenience")
  :authors '(("wouter bolsterlee" . "wouter@bolsterl.ee"))
  :maintainers '(("wouter bolsterlee" . "wouter@bolsterl.ee")))
