;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "20260130.1755"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "247acbd9ef392596ebd84ea5b8e50ca9be9d8ea5"
  :revdesc "247acbd9ef39"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
