(define-package "solidity-mode" "20211112.1959" "Major mode for ethereum's solidity language" 'nil :commit "dae5957e5028ffecb527c98a0b0c39696fa9ec1c" :authors
  '(("Lefteris Karapetsas " . "lefteris@refu.co"))
  :maintainer
  '("Lefteris Karapetsas " . "lefteris@refu.co")
  :keywords
  '("languages" "solidity"))
;; Local Variables:
;; no-byte-compile: t
;; End:
