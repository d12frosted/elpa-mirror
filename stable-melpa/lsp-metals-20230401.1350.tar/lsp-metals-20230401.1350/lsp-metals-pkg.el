(define-package "lsp-metals" "20230401.1350" "Scala Client settings"
  '((emacs "26.1")
    (scala-mode "1.1")
    (lsp-mode "7.0")
    (lsp-treemacs "0.2")
    (dap-mode "0.3")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.0")
    (treemacs "2.5"))
  :commit "ae3eede6869e604cbea316d1f2dd8a4d3b673ef5" :authors
  '(("Ross A. Baker" . "ross@rossabaker.com")
    ("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Ross A. Baker" . "ross@rossabaker.com")
  :keywords
  '("languages" "extensions")
  :url "https://github.com/emacs-lsp/lsp-metals")
;; Local Variables:
;; no-byte-compile: t
;; End:
