;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-analyzer" "20191001.1717"
  "Org-analyzer is a tool that extracts time tracking data from org files."
  ()
  :url "https://github.com/rksm/clj-org-analyzer"
  :commit "19da62aa4dcf1090be8f574f6f2d4c7e116163a8"
  :revdesc "19da62aa4dcf"
  :keywords '("calendar")
  :authors '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers '(("Robert Krahn" . "robert@kra.hn")))
