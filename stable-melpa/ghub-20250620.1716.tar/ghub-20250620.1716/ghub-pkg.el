;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20250620.1716"
  "Client libraries for Git forge APIs."
  '((emacs     "29.1")
    (compat    "30.1")
    (let-alist "1.0.6")
    (llama     "0.6.3")
    (treepy    "0.1.2"))
  :url "https://github.com/magit/ghub"
  :commit "793459c5713e7a9f9be9c5d573b4e9a107bf33a2"
  :revdesc "793459c5713e"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
