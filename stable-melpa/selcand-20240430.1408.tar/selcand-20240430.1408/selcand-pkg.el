;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selcand" "20240430.1408"
  "Select a candidate from a tree of hint characters."
  '((emacs "25.1"))
  :url "https://github.com/erjoalgo/selcand"
  :commit "6baa1771eacbcfe7ec854362bed17baea865424e"
  :revdesc "6baa1771eacb"
  :keywords '("lisp" "completing-read" "prompt" "combinations" "vimium")
  :maintainers '(("concat \"erjoalgo\" \"@\" \"gmail\" \".com\"" . "")))
