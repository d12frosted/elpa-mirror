;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ride-mode" "20240727.456"
  "A major-mode for editing RIDE language."
  '((emacs "25.1"))
  :url "https://codeberg.org/deadblackclover/ride-mode"
  :commit "f1b826fc9b14007aefca8d5748549b9a720b0684"
  :revdesc "f1b826fc9b14"
  :keywords '("languages")
  :authors '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com"))
  :maintainers '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com")))
