;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iwd-manager" "20260103.2138"
  "Manage IWD via the D-Bus interface."
  '((emacs   "26.1")
    (promise "1.1"))
  :url "https://github.com/sarg/wpa-manager.el"
  :commit "22b424e6e6fa0eb4353394c64f31657ded09fe2b"
  :revdesc "22b424e6e6fa"
  :authors '(("Sergey Trofimov" . "sarg@sarg.org.ru"))
  :maintainers '(("Sergey Trofimov" . "sarg@sarg.org.ru")))
