(define-package "chronometrist-key-values" "20211118.1235" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "c92eaa924b92d96ae20aaf71fee66c4508b8f268" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
