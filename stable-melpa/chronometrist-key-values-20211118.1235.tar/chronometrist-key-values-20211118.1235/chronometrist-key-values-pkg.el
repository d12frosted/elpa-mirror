(define-package "chronometrist-key-values" "20211118.1235" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "5d5b423c597ac7f8b484a19943f480d3c04e2e39" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
