(define-package "chronometrist-key-values" "20211118.1235" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "1525df5fc2625037b302dd1490e2fad1a59b1ce4" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
