(define-package "chronometrist-key-values" "20211118.1235" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "4d1d0c53a926a0dff36efb4c2b73f7f5c615dd50" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
