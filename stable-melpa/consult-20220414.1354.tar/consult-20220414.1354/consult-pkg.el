(define-package "consult" "20220414.1354" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "27d8c1d30a55844cbd8f0f0ad250658412e6d613" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
