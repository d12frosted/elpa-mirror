(define-package "consult" "20220414.1354" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "32a33c3bdf788b53f2ef0af65c4681b653e44515" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
