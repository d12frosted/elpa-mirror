;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260214.1610"
  "Manage and navigate projects in Emacs easily."
  '((emacs "26.1"))
  :url "https://github.com/bbatsov/projectile"
  :commit "6d1604aa1160c28e35c384b17e62e8f72e95d24b"
  :revdesc "6d1604aa1160"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
