(define-package "sumibi" "20230916.1505" "Japanese input method powered by ChatGPT API"
  '((emacs "28.1")
    (popup "0.5.9")
    (unicode-escape "1.1")
    (deferred "0.5.1"))
  :commit "e394d881df1e7e12e28661eda425b3fd261febf6" :authors
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainer
  '("Kiyoka Nishiyama" . "kiyoka@sumibi.org")
  :keywords
  '("lisp" "ime" "japanese")
  :url "https://github.com/kiyoka/Sumibi")
;; Local Variables:
;; no-byte-compile: t
;; End:
