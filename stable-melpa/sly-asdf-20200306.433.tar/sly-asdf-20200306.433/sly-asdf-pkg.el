(define-package "sly-asdf" "20200306.433" "ASDF system support for SLY"
  '((emacs "24.3")
    (sly "1.0.0beta2")
    (popup "0.5.3"))
  :commit "32ce14994e8faee9321605cec36d156b02996c46" :keywords
  ("languages" "lisp" "sly" "asdf")
  :maintainer
  ("Matt George" . "mmge93@gmail.com")
  :url "https://github.com/mmgeorge/sly-asdf")
;; Local Variables:
;; no-byte-compile: t
;; End:
