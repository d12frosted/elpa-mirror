;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20261029.1552"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "be56d926421beba026fecd7f43b7d833fd1b23d6"
  :revdesc "be56d926421b"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
