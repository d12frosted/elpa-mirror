(define-package "embark" "20210726.2110" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c44ae5154b8386edcf450eeafc3131873c545b97" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
