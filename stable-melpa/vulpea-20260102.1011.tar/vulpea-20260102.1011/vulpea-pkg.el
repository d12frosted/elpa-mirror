;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260102.1011"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "365e7b3a103db6cdd7632ff7c245af8f213c190c"
  :revdesc "365e7b3a103d"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
