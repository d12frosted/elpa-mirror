(define-package "mini-echo" "20231124.1559" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "1b25b17b4151c24fdd5e2650446aca7c20cfca0a" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
