(define-package "binder" "20201106.356" "Global minor mode to facilitate multi-file writing projects"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "a4b601548ec147499a4095d6758977a4cc9df101" :keywords
  ("files" "outlines" "wp" "text")
  :authors
  (("Paul W. Rankin" . "pwr@skeletons.cc"))
  :maintainer
  ("Paul W. Rankin" . "pwr@skeletons.cc")
  :url "https://git.skeletons.cc/binder")
;; Local Variables:
;; no-byte-compile: t
;; End:
