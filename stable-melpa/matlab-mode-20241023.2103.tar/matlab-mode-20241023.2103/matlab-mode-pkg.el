;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241023.2103"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "ddaffa46a9e7a2ad824f884d3b36ca59b15d1de2"
  :revdesc "ddaffa46a9e7"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")))
