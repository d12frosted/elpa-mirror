;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250317.1103"
  "Ollama Buddy: Your Friendly AI Assistant."
  '((emacs "26.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "417963d9ea7a7ad6eff13a1510e7723eb4bbb471"
  :revdesc "417963d9ea7a"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
