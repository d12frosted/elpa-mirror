(define-package "csharp-mode" "20210328.2004" "C# mode derived mode"
  '((emacs "26.1")
    (tree-sitter "0.15.1")
    (tree-sitter-indent "0.1")
    (tree-sitter-langs "0.10.0"))
  :commit "0edf059d643b8f78b13e8426b23c2c830a7fb4c3" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
