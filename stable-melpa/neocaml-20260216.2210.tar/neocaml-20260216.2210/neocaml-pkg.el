;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260216.2210"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "ea665001d5554baa5bd2cbcb06929bd4c7840a6f"
  :revdesc "ea665001d555"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
