(define-package "shimbun" "20220809.115" "interfacing with web newspapers" 'nil :commit "a8e2e5c7b7576afd7b097b40c6ca39e5717f97a5" :authors
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
    ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
    ("Yuuichi Teranishi " . "teranisi@gohome.org")
    ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  '("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  '("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
