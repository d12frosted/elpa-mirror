;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-trac" "20171026.1823"
  "Org Export Backend to Trac WikiFormat."
  '((org "9.0"))
  :url "https://github.com/JalapenoGremlin/ox-trac"
  :commit "5ac6c81bbc18db6c17e267d6399778c3fb5bf1ee"
  :revdesc "5ac6c81bbc18"
  :keywords '("org-mode" "trac")
  :authors '(("Brian J. Carlson" . "hackerabutilizecom"))
  :maintainers '(("Brian J. Carlson" . "hackerabutilizecom")))
