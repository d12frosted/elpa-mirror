;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oj" "20230212.148"
  "Competitive programming tools client for AtCoder, Codeforces."
  '((emacs    "26.1")
    (quickrun "2.2"))
  :url "https://github.com/conao3/oj.el"
  :commit "6d586cb108c642bc166c64df113e03193f4d1495"
  :revdesc "6d586cb108c6"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
