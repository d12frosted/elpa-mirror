(define-package "citre" "20210719.1731" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "dbcc0badda4aa91f9c18c301385cfc9988702e62" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
