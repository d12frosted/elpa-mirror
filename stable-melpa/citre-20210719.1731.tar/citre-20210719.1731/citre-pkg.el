(define-package "citre" "20210719.1731" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "04175c36778007ae12a0887bebd85ee8ba22029b" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
