;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20251014.1554"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/deirn/mason.el"
  :commit "f119253e912af58ac4eb025ddc0821cc7d327ac4"
  :revdesc "f119253e912a"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
