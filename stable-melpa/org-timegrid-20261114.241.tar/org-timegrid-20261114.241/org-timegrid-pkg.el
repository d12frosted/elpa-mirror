;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261114.241"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "4c8249516823c776f556745f91346949cc9593c7"
  :revdesc "4c8249516823"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
