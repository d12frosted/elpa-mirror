;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260914.946"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-gnosis"
  :commit "b0066af25ed27681e70e63ded5a00b972956334c"
  :revdesc "b0066af25ed2"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
