;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261023.1606"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.18.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "527fcac9afd65c4c1bd9692f16250b31fdce7bc0"
  :revdesc "527fcac9afd6"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
