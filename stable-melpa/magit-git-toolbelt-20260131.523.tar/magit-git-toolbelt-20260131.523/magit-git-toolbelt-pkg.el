;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-git-toolbelt" "20260131.523"
  "A Magit interface for git-toolbelt."
  '((emacs     "26.1")
    (magit     "3.0.0")
    (transient "0.3.0"))
  :url "https://github.com/jonathanchu/magit-git-toolbelt"
  :commit "1e6368e3135d15595d8c840f15ee4e467791480b"
  :revdesc "1e6368e3135d"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
