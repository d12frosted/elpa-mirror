(define-package "spdx" "20231005.100" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "92ec7ce7b3236fee6ede2e8bd44819c0632eb9a0" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
