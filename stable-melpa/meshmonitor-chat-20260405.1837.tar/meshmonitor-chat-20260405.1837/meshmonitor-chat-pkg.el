;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meshmonitor-chat" "20260405.1837"
  "Chat client for MeshMonitor (Meshtastic)."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/meshmonitor-chat.el"
  :commit "675379ebcd9fe4bceaa39a762c669c703b78a206"
  :revdesc "675379ebcd9f"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
