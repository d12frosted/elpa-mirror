;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260303.2022"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.34.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "01135a4b8f9cc78cb05b5ab1638d6e23958585a6"
  :revdesc "01135a4b8f9c"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
