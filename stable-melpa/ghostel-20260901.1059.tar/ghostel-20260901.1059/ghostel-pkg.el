;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260901.1059"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "e0c185cd548b43f2d54490a0b7de95de7d2f0d8c"
  :revdesc "e0c185cd548b"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
