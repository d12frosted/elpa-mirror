;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260105.1259"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "8616ccb52a370c0d4ffca441a4bc2410a869e3b0"
  :revdesc "8616ccb52a37"
  :keywords '("convenience" "comm" "hypermedia"))
