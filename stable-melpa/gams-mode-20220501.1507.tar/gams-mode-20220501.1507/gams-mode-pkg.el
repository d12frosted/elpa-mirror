(define-package "gams-mode" "20220501.1507" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "1964d9a52693f3aa9279eed8864bc317ee5c6dc4" :authors
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
