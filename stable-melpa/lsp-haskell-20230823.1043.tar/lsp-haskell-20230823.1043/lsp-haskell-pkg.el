(define-package "lsp-haskell" "20230823.1043" "Haskell support for lsp-mode"
  '((emacs "27.1")
    (lsp-mode "3.0")
    (haskell-mode "16.1"))
  :commit "d15bbb7e254f7a2b05a1f1511e453ed8c50eb434" :keywords
  '("haskell")
  :url "https://github.com/emacs-lsp/lsp-haskell")
;; Local Variables:
;; no-byte-compile: t
;; End:
