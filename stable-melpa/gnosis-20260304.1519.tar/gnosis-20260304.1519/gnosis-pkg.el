;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260304.1519"
  "Knowledge System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.2.0"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "f90e0ddabb1ecf6b6a3a1a9e762b1ce2af56c1e5"
  :revdesc "f90e0ddabb1e"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
