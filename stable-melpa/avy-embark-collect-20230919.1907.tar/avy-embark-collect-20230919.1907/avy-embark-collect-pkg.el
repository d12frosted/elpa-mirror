(define-package "avy-embark-collect" "20230919.1907" "Use avy to jump to Embark Collect entries"
  '((emacs "25.1")
    (embark "0.9")
    (avy "0.5"))
  :commit "07af44c7de72efde79ac563cbecdfff0b48d8411" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
