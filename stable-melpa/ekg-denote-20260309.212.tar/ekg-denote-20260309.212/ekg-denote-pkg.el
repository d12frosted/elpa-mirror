;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-denote" "20260309.212"
  "Denote integration for ekg."
  '((ekg    "20260305")
    (denote "4.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "07c630b3227bf8714728d021b4641055def18b31"
  :revdesc "07c630b3227b"
  :keywords '("outlines" "hypermedia")
  :authors '(("Jay Rajput" . "jayrajput@gmail.com"))
  :maintainers '(("Jay Rajput" . "jayrajput@gmail.com")))
