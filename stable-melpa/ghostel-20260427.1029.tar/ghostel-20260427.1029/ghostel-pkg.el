;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260427.1029"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b9c12ca6419bb6a5afb9a25ae060e67729414f74"
  :revdesc "b9c12ca6419b"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
