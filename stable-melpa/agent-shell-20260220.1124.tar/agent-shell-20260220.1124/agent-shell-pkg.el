;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260220.1124"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e6e2f25729935604c46d7c34531f59df154cdb58"
  :revdesc "e6e2f2572993")
