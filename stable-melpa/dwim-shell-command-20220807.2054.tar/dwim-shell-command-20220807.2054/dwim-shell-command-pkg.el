(define-package "dwim-shell-command" "20220807.2054" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "ba838da662259f70e3e9af65831f4d5b1324f2a4" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
