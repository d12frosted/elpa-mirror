(define-package "ros" "20231016.1402" "Package to write code for ROS systems"
  '((emacs "27.1")
    (s "0")
    (with-shell-interpreter "0")
    (kv "0")
    (cl-lib "0")
    (transient "0")
    (hydra "0")
    (grep "0")
    (string-inflection "0")
    (docker-tramp "0"))
  :commit "aaf32cde6835826551f2b73e4dc8b63d0ff26eb0" :authors
  '(("Max Beutelspacher <https://github.com/mtb>"))
  :maintainers
  '(("Max Beutelspacher" . "max@beutelspacher.eu"))
  :maintainer
  '("Max Beutelspacher" . "max@beutelspacher.eu")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/DerBeutlin/ros.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
