(define-package "borg" "20210519.937" "assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.2.2")
    (magit "2.90.1"))
  :commit "dde5c6741f1372e35989637e51434105643218f4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
