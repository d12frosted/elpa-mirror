(define-package "dirvish" "20220106.1909" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "c5d09cbc7587c5c7905512580624fb9dfbc521a5" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
