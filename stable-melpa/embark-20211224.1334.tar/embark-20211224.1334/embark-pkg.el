(define-package "embark" "20211224.1334" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "ab1ee58dcc31e5c88428a7e258c12510f68b6898" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
