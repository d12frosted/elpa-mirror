;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260525.1554"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "1806231c258cb0f79ad6c8df8add46f6ab48d874"
  :revdesc "1806231c258c"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
