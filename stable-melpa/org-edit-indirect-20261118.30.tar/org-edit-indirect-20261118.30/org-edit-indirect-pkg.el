;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-edit-indirect" "20261118.30"
  "Edit anything, not just source blocks."
  '((emacs         "29.1")
    (edit-indirect "0.1.10")
    (org           "9.6"))
  :url "https://github.com/agzam/org-edit-indirect.el"
  :commit "49d5759481795d606cf098286a603a9c26913eb1"
  :revdesc "49d575948179"
  :keywords '("convenience" "extensions" "outlines")
  :authors '(("Ag Ibragimov" . "https://github.com/agzam"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
