(define-package "js2-refactor" "20190630.2108" "A JavaScript refactoring library for emacs."
  '((js2-mode "20101228")
    (s "1.9.0")
    (multiple-cursors "1.0.0")
    (dash "1.0.0")
    (s "1.0.0")
    (yasnippet "0.9.0.1"))
  :commit "d4c40b5fc86d3edd7c6a7d83ac86483ee1cb7a28")
;; Local Variables:
;; no-byte-compile: t
;; End:
