;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20251005.1228"
  "Consulting completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "e356cd8907f891c358cb1b4c8c3d14f4539a2a9b"
  :revdesc "e356cd8907f8"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
