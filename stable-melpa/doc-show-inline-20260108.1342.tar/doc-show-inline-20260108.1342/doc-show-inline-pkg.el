;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doc-show-inline" "20260108.1342"
  "Show doc-strings found in external files."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-doc-show-inline"
  :commit "4a81b89873f8d3594b7d7b65c15f86ec6c49e40c"
  :revdesc "4a81b89873f8"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
