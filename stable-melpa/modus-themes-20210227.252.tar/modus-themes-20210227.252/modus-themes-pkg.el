(define-package "modus-themes" "20210227.252" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "96a21ab2298ca9d7459964af78bdab279d6e10c8" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
