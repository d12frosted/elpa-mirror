;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moody" "20260504.1737"
  "Tabs and ribbons for the mode line."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/moody"
  :commit "c733279a3912024c82c85c6d1f734008c00942cc"
  :revdesc "c733279a3912"
  :keywords '("faces")
  :authors '(("Jonas Bernoulli" . "emacs.moody@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.moody@jonas.bernoulli.dev")))
