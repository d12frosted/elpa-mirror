;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250106.1157"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "8e9d76abe923f0f6faec679b227dfcfd1bdff320"
  :revdesc "8e9d76abe923"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
