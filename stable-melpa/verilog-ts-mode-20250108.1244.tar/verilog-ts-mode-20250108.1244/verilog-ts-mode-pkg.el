;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ts-mode" "20250108.1244"
  "Verilog Tree-sitter major mode."
  '((emacs        "29.1")
    (verilog-mode "2024.3.1.121933719"))
  :url "https://github.com/gmlarumbe/verilog-ts-mode"
  :commit "965fc8631ef09b2ddca43f2ef5667a8d0d9a6015"
  :revdesc "965fc8631ef0"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
