;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "20260125.1330"
  "Compiler explorer client (godbolt.org)."
  '((emacs "28.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "6d07c9b3c04509bc74b1d4aa83cd066bfc60951c"
  :revdesc "6d07c9b3c045"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
