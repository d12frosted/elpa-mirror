;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20250309.1057"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "f561eaf24d77fe76f5534d9ca955d4883adf1805"
  :revdesc "f561eaf24d77"
  :keywords '("hypermedia"))
