;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261022.947"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c80bd3985f81c83cd54420cce1a36ef693d22fc8"
  :revdesc "c80bd3985f81")
