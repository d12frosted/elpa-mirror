(define-package "x509-mode" "20180921.803" "View certificates, CRLs and keys using OpenSSL."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "9eb24c8721dcad9888b70213d06d770bc2386db7" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com")
    ("Package-Requires: ((emacs \"24.1\") (cl-lib \"0.5\"))"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
