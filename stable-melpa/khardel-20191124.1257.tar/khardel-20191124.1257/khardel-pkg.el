(define-package "khardel" "20191124.1257" "Integrate with khard"
  '((emacs "25.1")
    (yaml-mode "0.0.13"))
  :commit "5ee835a4429c58dec3900e4fa3d7cc1e778c969b" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://gitlab.petton.fr/DamienCassou/khardel")
;; Local Variables:
;; no-byte-compile: t
;; End:
