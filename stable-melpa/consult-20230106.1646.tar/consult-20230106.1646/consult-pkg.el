(define-package "consult" "20230106.1646" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.0.1"))
  :commit "8dde94ad1b4a50c4f97846d68175d65d3b697d1d" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
