(define-package "lsp-scheme" "20220913.1808" "Scheme support for lsp-mode"
  '((emacs "26.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "b316f0507759126bfaeb31448b56aed21443064f" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
