;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "20260105.206"
  "Display diffs using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "329a9612381f5118a6f05ce08bfa40229082021c"
  :revdesc "329a9612381f"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
