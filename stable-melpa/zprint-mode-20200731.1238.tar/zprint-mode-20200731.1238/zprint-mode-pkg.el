(define-package "zprint-mode" "20200731.1238" "Reformat Clojure(Script) code using zprint"
  '((emacs "24.3"))
  :commit "b9b72b4918156f2f44aa544be9e19ea391937c2a" :keywords
  ("tools")
  :authors
  (("Paulus Esterhazy" . "pesterhazy@gmail.com"))
  :maintainer
  ("Paulus Esterhazy" . "pesterhazy@gmail.com")
  :url "https://github.com/pesterhazy/zprint-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
