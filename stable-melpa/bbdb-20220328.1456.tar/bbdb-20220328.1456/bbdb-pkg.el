(define-package "bbdb" "20220328.1456" "The Insidious Big Brother Database for GNU Emacs" 'nil :commit "a50c89a6f01be757335e64df322837300c4ced04" :maintainer
  '("Roland Winkler" . "winkler@gnu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
