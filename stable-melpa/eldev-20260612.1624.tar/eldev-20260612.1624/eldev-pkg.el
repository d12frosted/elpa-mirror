;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "20260612.1624"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "7ce62b0a71f75c8568e391e45eafe0687f610076"
  :revdesc "7ce62b0a71f7"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
