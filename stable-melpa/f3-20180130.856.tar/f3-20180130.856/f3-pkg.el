(define-package "f3" "20180130.856" "a helm interface to find"
  '((emacs "24.3")
    (helm "2.8.8")
    (cl-lib "0.5"))
  :commit "19120dda2d760d3dd6c6aa620121d1de0a40932d" :authors
  '(("Danny McClanahan"))
  :maintainer
  '("Danny McClanahan")
  :keywords
  '("find" "file" "files" "helm" "fast" "finder")
  :url "https://github.com/cosmicexplorer/f3")
;; Local Variables:
;; no-byte-compile: t
;; End:
