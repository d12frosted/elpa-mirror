(define-package "daemons" "20231030.1710" "UI for managing init system daemons (services)"
  '((emacs "25.1")
    (s "1.13.0")
    (compat "29.1.4.2"))
  :commit "c329ca135e3e33a4bd6d898d2e803a6ca4e64b47" :authors
  '(("Chris Bowdon"))
  :maintainers
  '(("Chris Bowdon"))
  :maintainer
  '("Chris Bowdon")
  :keywords
  '("unix" "convenience")
  :url "https://github.com/cbowdon/daemons.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
