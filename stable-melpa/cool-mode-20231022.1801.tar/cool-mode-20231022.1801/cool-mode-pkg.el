(define-package "cool-mode" "20231022.1801" "Major mode for cool compiler language"
  '((emacs "25"))
  :commit "0f03f851c6aaccfa4699f8818f4b77e4b4e4f576" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :url "https://github.com/nverno/cool-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
