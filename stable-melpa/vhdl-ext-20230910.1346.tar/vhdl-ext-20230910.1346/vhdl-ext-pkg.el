(define-package "vhdl-ext" "20230910.1346" "VHDL Extensions"
  '((emacs "29.1")
    (vhdl-ts-mode "0.0.0")
    (eglot "1.9")
    (lsp-mode "8.0.0")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "32")
    (company "0.9.13")
    (outshine "3.0.1")
    (async "1.9.7"))
  :commit "c098e4b816f9fa8f7905c4fa56c4039b0b149b83" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
