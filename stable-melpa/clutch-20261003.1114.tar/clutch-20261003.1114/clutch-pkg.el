;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261003.1114"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "53face32dae847f33a6069c5965f5d8a50a82bdd"
  :revdesc "53face32dae8"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
