(define-package "speechd-el" "20210529.1649" "Client to speech synthesizers and Braille displays." 'nil :commit "74f8a4d83948163c17956d2a0e311d034f3613b9")
;; Local Variables:
;; no-byte-compile: t
;; End:
