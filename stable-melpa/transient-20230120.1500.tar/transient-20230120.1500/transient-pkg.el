(define-package "transient" "20230120.1500" "Transient commands"
  '((emacs "25.1")
    (compat "28.1.1.0"))
  :commit "5337e5eb449aeb00408240c2e669192f2cdc9343" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
