;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20260607.628"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "737c05d81c975ea56d7c1fb1bf8de5b4805d9062"
  :revdesc "737c05d81c97"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
