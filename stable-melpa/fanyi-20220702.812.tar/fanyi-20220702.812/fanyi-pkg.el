(define-package "fanyi" "20220702.812" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "07815b29decc08994e7b6ae24be188047531b1b9" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
