;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260328.812"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "889db7e8cfac96f5a96ef0bca8850d6faf7549f4"
  :revdesc "889db7e8cfac"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
