(define-package "meow" "20220123.2135" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "5dda9f4b7d73d1f866153d8e955112dfd8dec9ab" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
