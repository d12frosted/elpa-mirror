;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-sidebar" "20260610.2151"
  "Sidebar for `ibuffer'."
  '((emacs "29.1"))
  :url "https://github.com/jojojames/ibuffer-sidebar"
  :commit "0bd323f871959ac1ea61997ed566ce7b198fd03a"
  :revdesc "0bd323f87195"
  :keywords '("ibuffer" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
