;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260803.1209"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "4190f3e74a41346983b396c57d7d0f173012ea4e"
  :revdesc "4190f3e74a41"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
