(define-package "racket-mode" "20231118.1639" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "b7e4d62672a8df3495f6125fdf34b5e3b972d36a" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
