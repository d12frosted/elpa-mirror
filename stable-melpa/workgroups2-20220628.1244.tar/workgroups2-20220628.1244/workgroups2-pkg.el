(define-package "workgroups2" "20220628.1244" "save&load multiple named workspaces (or \"workgroups\")"
  '((emacs "25.1"))
  :commit "892f2dde2a45396685c89552157250c238fbc582" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
