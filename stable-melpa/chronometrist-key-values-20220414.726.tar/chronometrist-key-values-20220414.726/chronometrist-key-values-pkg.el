(define-package "chronometrist-key-values" "20220414.726" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "9f970ebb637d57b3234b6e1e85840dcf524037e6" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainers
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
