(define-package "chronometrist-key-values" "20220414.726" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "64898c6565f0e41f68483d965bccdf00fdde54a9" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
