(define-package "spdx" "20240811.116" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "199309f9a1e4ba968efe3c96bdae89a6e8169f99" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
