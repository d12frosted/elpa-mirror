(define-package "live-py-mode" "20230320.2347" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "f56343b3dc68aaeb4f9d2bdb48509750cdaa2fcf" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
