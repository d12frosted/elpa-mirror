(define-package "rust-mode" "20211022.1728" "A major-mode for editing Rust source code"
  '((emacs "25.1"))
  :commit "3e388ed7cf8a7d7ed730f2e041e180e538a161f7" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages")
  :url "https://github.com/rust-lang/rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
