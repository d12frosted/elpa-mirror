(define-package "kkp" "20230403.2156" "Enable support for the Kitty Keyboard Protocol"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "5652ba0bfa7a4c03daffc301c9ca4a9899c4f440" :authors
  '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers
  '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainer
  '("Benjamin Orthen" . "contact@orthen.net")
  :keywords
  '("terminals")
  :url "https://github.com/benjaminor/kkp")
;; Local Variables:
;; no-byte-compile: t
;; End:
