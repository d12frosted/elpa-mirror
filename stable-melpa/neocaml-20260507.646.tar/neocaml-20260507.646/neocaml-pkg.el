;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260507.646"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "657d4628b4099eb9914fc4e62869fe602561858e"
  :revdesc "657d4628b409"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
