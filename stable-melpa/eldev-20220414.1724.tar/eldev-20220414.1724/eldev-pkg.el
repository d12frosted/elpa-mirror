(define-package "eldev" "20220414.1724" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "ed6ade7cd938a1804584211ced62d84d3a08b27f" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
