;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debian-el" "20260314.39"
  "Startup file for the debian-el package."
  ()
  :commit "03ce2443bf7434915b7b192fe75c9c58143a4121"
  :revdesc "03ce2443bf74"
  :keywords '("debian" "apt" "elisp")
  :authors '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org"))
  :maintainers '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org")))
