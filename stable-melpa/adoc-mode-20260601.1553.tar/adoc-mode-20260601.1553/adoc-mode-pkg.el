;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260601.1553"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "717bce9c18039ced2a929ea4438267907714d2a5"
  :revdesc "717bce9c1803"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
