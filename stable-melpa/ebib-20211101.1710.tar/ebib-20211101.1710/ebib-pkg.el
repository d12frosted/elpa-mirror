(define-package "ebib" "20211101.1710" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "d48d30e3f59fd37d81878f88621d2821a77e1df6" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
