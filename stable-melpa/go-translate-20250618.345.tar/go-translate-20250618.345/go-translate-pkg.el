;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250618.345"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "94447ba667e73291a5b597e54f2cdeccce632d73"
  :revdesc "94447ba667e7"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
