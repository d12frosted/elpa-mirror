(define-package "notmuch" "20220114.2112" "run notmuch within emacs" 'nil :commit "87d5a5a8aa323077c0b79fce42d062839eb2ff2d" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
