(define-package "notmuch" "20220114.2112" "run notmuch within emacs" 'nil :commit "c7c422ded29e73f7f6b53e82c40a36c93c041253" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
