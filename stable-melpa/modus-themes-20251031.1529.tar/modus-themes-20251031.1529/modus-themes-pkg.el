;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251031.1529"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "83c34e9726294d0cc76d77369728643afbb2b5d9"
  :revdesc "83c34e972629"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
