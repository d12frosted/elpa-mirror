;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260705.916"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "933b35fe85ba050865ee7d1948bf2bb294b3de45"
  :revdesc "933b35fe85ba"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
