(define-package "helm-core" "20220802.1409" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "00bf87a6382dab67891c585869df546e1d753827" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
