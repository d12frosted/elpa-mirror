;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "multi-compile" "20211113.2119"
  "Multi target interface to compile."
  '((emacs "24.4")
    (dash  "2.12.1"))
  :url "https://github.com/ReanGD/emacs-multi-compile"
  :commit "360e44b200d07da379c906856d37613d0f06a9ae"
  :revdesc "360e44b200d0"
  :keywords '("tools" "compile" "build")
  :authors '(("Kvashnin Vladimir" . "reangd@gmail.com"))
  :maintainers '(("Kvashnin Vladimir" . "reangd@gmail.com")))
