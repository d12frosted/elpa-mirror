;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "20260901.1117"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "fa057cbe9abf98cf2c68a6c5cb775cb896e18ac4"
  :revdesc "fa057cbe9abf"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
