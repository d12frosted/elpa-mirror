(define-package "forth-mode" "20220402.2103" "Programming language mode for Forth" 'nil :commit "02482582985f5ace243ea07b492ec78520018975" :authors
  '(("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainer
  '("Lars Brinkhoff" . "lars@nocrew.org")
  :keywords
  '("languages" "forth")
  :url "http://github.com/larsbrinkhoff/forth-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
