;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calle24" "20260506.2210"
  "Emacs Toolbar Support for SF Symbols."
  '((emacs "29.1"))
  :url "https://github.com/kickingvegas/calle24"
  :commit "24d6240209b46c5005121d14cba3fae0e0ff257f"
  :revdesc "24d6240209b4"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
