;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyimpsort" "20250710.1126"
  "Sort Python imports."
  '((emacs  "24.3")
    (python "0"))
  :url "https://github.com/emacsorphanage/pyimpsort"
  :commit "f68f813fcc7c21e855503a129893e37c2fb33f01"
  :revdesc "f68f813fcc7c"
  :keywords '("tools" "python" "convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Alain Delplanque" . "alaindelplanque@mailoo.org")))
