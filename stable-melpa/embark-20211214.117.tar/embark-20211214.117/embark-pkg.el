(define-package "embark" "20211214.117" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "b17af024d92e5c8532ed94f157e65aa7f4cda334" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
