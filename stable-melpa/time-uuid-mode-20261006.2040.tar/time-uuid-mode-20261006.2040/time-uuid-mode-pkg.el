;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-uuid-mode" "20261006.2040"
  "Minor mode for previewing time uuids as an overlay."
  '((emacs "27.1"))
  :url "https://github.com/RobertPlant/time-uuid-mode"
  :commit "bf29490fc85d5c88e88fe4af65199f9f5cdc8b01"
  :revdesc "bf29490fc85d"
  :keywords '("extensions" "convenience" "data" "tools")
  :authors '(("Robert Plant" . "rob@robertplant.io"))
  :maintainers '(("Robert Plant" . "rob@robertplant.io")))
