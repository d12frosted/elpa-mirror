(define-package "sourcepawn-mode" "20230613.2043" "SourcePawn major mode" 'nil :commit "41b3c5a263cb8d02d82a9146ccf8b2e1e443407a" :authors
  '(("Aaron Griffith" . "aargri@gmail.com"))
  :maintainers
  '(("Aaron Griffith" . "aargri@gmail.com"))
  :maintainer
  '("Aaron Griffith" . "aargri@gmail.com")
  :url "http://gammalevel.com/teamfortress2/sourcepawn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
