(define-package "dirvish" "20220102.1136" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "de9464452a238f8740470291399a11e9ffd48b1c" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
