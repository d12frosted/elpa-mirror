(define-package "vim-tab-bar" "20240708.1801" "Vim-like tab bar"
  '((emacs "28.1"))
  :commit "d6167809d757ea3c326829d818f3f94fe25ef00c" :keywords
  '("frames")
  :url "https://github.com/jamescherti/vim-tab-bar.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
