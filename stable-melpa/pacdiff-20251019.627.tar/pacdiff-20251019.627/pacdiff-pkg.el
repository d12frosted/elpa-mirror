;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pacdiff" "20251019.627"
  "Manage pacdiff files."
  '((emacs "28.1"))
  :url "https://github.com/fbrosda/pacdiff.el"
  :commit "f1c13777e5c8056a6d6e823ecb51b9bbadc8e0c3"
  :revdesc "f1c13777e5c8"
  :authors '(("Fabian Brosda" . "fabi3141@gmx.de"))
  :maintainers '(("Fabian Brosda" . "fabi3141@gmx.de")))
