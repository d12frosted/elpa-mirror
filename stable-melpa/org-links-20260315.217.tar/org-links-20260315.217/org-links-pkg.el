;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260315.217"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "12d92485385fc6a240e38071fdd142648337b649"
  :revdesc "12d92485385f"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
