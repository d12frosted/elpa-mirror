;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20251208.1042"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "736787fda70510157085af2a19b9736044ad4298"
  :revdesc "736787fda705"
  :keywords '("convenience" "text"))
