(define-package "epkg" "20210227.1459" "browse the Emacsmirror package database"
  '((closql "1.0.1")
    (emacs "25.1"))
  :commit "9bc3b378178201ce694f0cf09f52f8f88fd2cf48" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
