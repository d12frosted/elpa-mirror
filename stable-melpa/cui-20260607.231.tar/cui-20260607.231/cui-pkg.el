;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260607.231"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "b1975a60f2c04e39d843e0e2aed1cee04838fea5"
  :revdesc "b1975a60f2c0"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
