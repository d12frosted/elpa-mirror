(define-package "helm-core" "20220720.1746" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "466d6a73115c469cdf2098da1506387a18c57c03" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
