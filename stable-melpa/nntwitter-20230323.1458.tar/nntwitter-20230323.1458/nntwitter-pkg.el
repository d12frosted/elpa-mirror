(define-package "nntwitter" "20230323.1458" "Gnus Backend For Twitter"
  '((emacs "25.1")
    (dash "20190401")
    (anaphora "20180618")
    (request "20190819"))
  :commit "8189100aa071386665b8616c6b57067383abd47b" :keywords
  '("news")
  :url "https://github.com/dickmao/nntwitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
