(define-package "dirvish" "20220403.1516" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a69d09a440997c30bb0203c66641a85e8ccb2688" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
