;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "20260428.2146"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "9a6d64058c445f73ef76c96a12b938c6bd22fdb6"
  :revdesc "9a6d64058c44")
