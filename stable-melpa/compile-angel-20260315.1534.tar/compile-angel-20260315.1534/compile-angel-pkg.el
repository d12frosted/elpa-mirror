;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260315.1534"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "ee95a02bc4f7d3686bbcb074e226321734666cf3"
  :revdesc "ee95a02bc4f7"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
