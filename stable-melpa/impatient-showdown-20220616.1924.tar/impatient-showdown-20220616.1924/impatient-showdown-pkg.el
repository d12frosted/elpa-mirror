(define-package "impatient-showdown" "20220616.1924" "Preview markdown buffer live over HTTP using showdown"
  '((emacs "24.3")
    (impatient-mode "1.1"))
  :commit "5d53a79a3856bead68eaf1f53f91c6654016ca9a" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("live" "preview" "markdown" "http" "server" "impatient")
  :url "https://github.com/jcs-elpa/impatient-showdown")
;; Local Variables:
;; no-byte-compile: t
;; End:
