;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "20260618.100"
  "Tree-sitter major mode for ShExC."
  '((emacs "29.1"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "bca9bfb037c0ba7c18753c17512b23968153f23b"
  :revdesc "bca9bfb037c0"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
