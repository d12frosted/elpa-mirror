;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20241210.2147"
  "Spaced Repetition System."
  '((emacs     "27.2")
    (emacsql   "4.0.1")
    (compat    "29.1.4.2")
    (transient "0.7.2"))
  :url "https://git.thanosapollo.org/gnosis"
  :commit "e5fd01a34c2488023118d26a4d2e8a5fdde282ba"
  :revdesc "e5fd01a34c24"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
