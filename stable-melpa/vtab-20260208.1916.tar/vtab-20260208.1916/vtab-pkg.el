;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vtab" "20260208.1916"
  "Vertical tab bar."
  '((emacs "27.1"))
  :url "https://github.com/mugen-void/vtab"
  :commit "b64327aecc2ee60f6987e6abb25e49e998e2e7fe"
  :revdesc "b64327aecc2e"
  :keywords '("convenience" "frames")
  :authors '(("mugen" . "mugen.void42@gmail.com"))
  :maintainers '(("mugen" . "mugen.void42@gmail.com")))
