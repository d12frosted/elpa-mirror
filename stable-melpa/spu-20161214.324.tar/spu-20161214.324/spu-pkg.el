;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spu" "20161214.324"
  "Silently upgrade package in the background."
  '((emacs  "24.4")
    (signal "1.0")
    (timp   "1.2.0"))
  :url "https://github.com/mola-T/spu"
  :commit "41eec86b595816e3852e8ad1a8e07e51a27fd065"
  :revdesc "41eec86b5958"
  :keywords '("convenience" "package")
  :authors '(("Mola-T" . "Mola@molamola.xyz"))
  :maintainers '(("Mola-T" . "Mola@molamola.xyz")))
