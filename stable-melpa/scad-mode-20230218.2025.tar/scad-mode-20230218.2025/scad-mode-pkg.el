(define-package "scad-mode" "20230218.2025" "A major mode for editing OpenSCAD code"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "3be01e4213f6828234e73c1f7ec66c0fb594abef" :authors
  '(("Len Trigg, Łukasz Stelmach, zk_phi, Daniel Mendler"))
  :maintainer
  '("Len Trigg <lenbok@gmail.com>, Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("languages")
  :url "https://github.com/openscad/emacs-scad-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
