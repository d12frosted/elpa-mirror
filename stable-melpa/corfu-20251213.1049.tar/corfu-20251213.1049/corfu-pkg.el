;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251213.1049"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "d73949b3e1ccada479acea91a11ede393a230166"
  :revdesc "d73949b3e1cc"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
