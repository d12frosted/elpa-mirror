;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260121.1317"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "58e90341e306a01343780a28c1c4e4f7bdba5cec"
  :revdesc "58e90341e306"
  :keywords '("outlines"))
