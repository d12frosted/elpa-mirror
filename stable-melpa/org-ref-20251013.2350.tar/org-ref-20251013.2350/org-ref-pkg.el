;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-ref" "20251013.2350"
  "Citations, cross-references and bibliographies in org-mode."
  '((org               "9.4")
    (htmlize           "0")
    (transient         "0")
    (avy               "0")
    (parsebib          "0")
    (bibtex-completion "0")
    (citeproc          "0")
    (ox-pandoc         "0")
    (request           "0"))
  :url "https://github.com/jkitchin/org-ref"
  :commit "046ec9c4fb7d5b87e60d5674040fb1f0c2a78789"
  :revdesc "046ec9c4fb7d"
  :keywords '("org-mode" "cite" "ref" "label")
  :authors '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainers '(("John Kitchin" . "jkitchin@andrew.cmu.edu")))
