(define-package "consult" "20210206.1726" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "237b7f7d5542b9269a8a5a37de827f1015fcffa9" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
