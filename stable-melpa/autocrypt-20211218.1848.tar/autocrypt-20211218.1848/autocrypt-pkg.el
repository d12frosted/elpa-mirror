(define-package "autocrypt" "20211218.1848" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "222954754ace827a80999955f02008841b260325" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "philipk@posteo.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
