(define-package "marginalia" "20231026.1813" "Enrich existing commands with completion annotations"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "3b078bff35e12be5ede6e12e9c05dd33519c0291" :authors
  '(("Omar Antolín Camarena <omar@matem.unam.mx>, Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Omar Antolín Camarena <omar@matem.unam.mx>, Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Omar Antolín Camarena <omar@matem.unam.mx>, Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("docs" "help" "matching" "completion")
  :url "https://github.com/minad/marginalia")
;; Local Variables:
;; no-byte-compile: t
;; End:
