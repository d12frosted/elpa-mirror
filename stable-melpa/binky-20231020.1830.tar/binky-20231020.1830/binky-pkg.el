(define-package "binky" "20231020.1830" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "76fbce5b634eea0e04c3c996b2c2437bce15a7cb" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
