(define-package "syslog-mode" "20210818.1408" "Major-mode for viewing log files"
  '((hide-lines "20130623")
    (ov "20150311"))
  :commit "8e0d3206825944681a25ae2d1b2388589ef6e655" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
