;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260313.1846"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "370ef690fa1c0f1fa5f359865b4d92954945888b"
  :revdesc "370ef690fa1c"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
