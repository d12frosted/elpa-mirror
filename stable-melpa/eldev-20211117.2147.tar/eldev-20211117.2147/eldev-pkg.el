(define-package "eldev" "20211117.2147" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "95e4ab2ddc6c9439ed695c9018d305513fd9f904" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
