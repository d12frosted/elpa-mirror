(define-package "eldev" "20211117.2147" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "17d43d22105d7412d822f755a613762e30180d04" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
