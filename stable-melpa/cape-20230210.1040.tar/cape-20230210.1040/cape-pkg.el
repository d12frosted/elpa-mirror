(define-package "cape" "20230210.1040" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "4bae9867a808bd9f130d651bf070f6c662c40f39" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
