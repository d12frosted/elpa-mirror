;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "realgud" "20260104.2302"
  "A modular front-end for interacting with external debuggers."
  '((load-relative "1.3.1")
    (loc-changes   "1.2")
    (test-simple   "1.3.0")
    (emacs         "25"))
  :url "https://github.com/realgud/realgud/"
  :commit "77f3130c930c3e3ab9c6ab9b4d9ddf928051d169"
  :revdesc "77f3130c930c"
  :keywords '("debugger" "gdb" "python" "perl" "go" "bash" "zsh" "bashdb" "zshdb" "remake" "trepan" "perldb" "pdb")
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '(("Rocky Bernstein" . "rocky@gnu.org")))
