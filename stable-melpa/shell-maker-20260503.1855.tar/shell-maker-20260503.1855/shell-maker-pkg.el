;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260503.1855"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "8fb4a30da4479d50d273a1dbafa61420cca36619"
  :revdesc "8fb4a30da447")
