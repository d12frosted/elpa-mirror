;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "20261031.223"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2")
    (json    "1.4"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "90af8a58f4ff28ed336ab1ba49dcd0860ed45b1d"
  :revdesc "90af8a58f4ff"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
