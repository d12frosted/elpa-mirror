;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-semantic" "20261022.727"
  "Search org notes by meaning, or by word."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/org-semantic"
  :commit "4ae55e17051401c5e3d3db03c72ec8e8d95e8a38"
  :revdesc "4ae55e170514"
  :keywords '("outlines" "matching" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
