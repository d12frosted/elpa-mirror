(define-package "kaolin-themes" "20230313.1916" "A set of eye pleasing themes"
  '((emacs "25.1")
    (autothemer "0.2.2")
    (cl-lib "0.6"))
  :commit "674435c66a6540f01618c34db7ea18cc087021fb" :authors
  '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainer
  '("Ogden Webb" . "ogdenwebb@gmail.com")
  :keywords
  '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
