(define-package "champagne" "20231119.1151" "Graphical countdowns"
  '((emacs "28.1")
    (posframe "1.4.2"))
  :commit "20d8193ca194fbf3749a0c0fa694d81b22b77a9d" :authors
  '(("Psionik K" . "73710933+psionic-k@users.noreply.github.com"))
  :maintainers
  '(("Psionik K" . "73710933+psionic-k@users.noreply.github.com"))
  :maintainer
  '("Psionik K" . "73710933+psionic-k@users.noreply.github.com")
  :keywords
  '("games")
  :url "http://github.com/positron-solutions/champagne")
;; Local Variables:
;; no-byte-compile: t
;; End:
