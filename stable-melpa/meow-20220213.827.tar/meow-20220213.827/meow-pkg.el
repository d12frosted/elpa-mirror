(define-package "meow" "20220213.827" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "87d395607b26386c929d95f2b7472744a83e6b8f" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
