;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260703.959"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "8bb537e4599a33ff448370589a3d7f8727156761"
  :revdesc "8bb537e4599a"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
