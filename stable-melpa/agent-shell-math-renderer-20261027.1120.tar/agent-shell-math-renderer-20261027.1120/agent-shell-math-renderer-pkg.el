;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20261027.1120"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.89.4")
    (latex-to-svg-backend "0.18.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "f90ab117669b75f7426a4084e5b7adeab3b57dda"
  :revdesc "f90ab117669b"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
