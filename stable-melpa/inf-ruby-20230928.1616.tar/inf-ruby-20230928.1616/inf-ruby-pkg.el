(define-package "inf-ruby" "20230928.1616" "Run a Ruby process in a buffer"
  '((emacs "26.1"))
  :commit "74c8be8e270b8be799387f180a14877b12466f35" :authors
  '(("Yukihiro Matsumoto")
    ("Nobuyoshi Nakada")
    ("Cornelius Mika" . "cornelius.mika@gmail.com")
    ("Dmitry Gutov" . "dgutov@yandex.ru")
    ("Kyle Hargraves" . "pd@krh.me"))
  :maintainers
  '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("languages" "ruby")
  :url "http://github.com/nonsequitur/inf-ruby")
;; Local Variables:
;; no-byte-compile: t
;; End:
