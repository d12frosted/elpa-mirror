;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "belarus-holidays" "20190102.1343"
  "Belarus holidays whith transfers."
  ()
  :url "http://bitbucket.org/EugeneMakei/belarus-holidays.el"
  :commit "35a18273e19edc3b4c761030ffbd11116483b83e"
  :revdesc "35a18273e19e"
  :authors '(("Yauhen Makei" . "yauhen.makei@gmail.com"))
  :maintainers '(("Yauhen Makei" . "yauhen.makei@gmail.com")))
