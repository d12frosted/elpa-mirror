(define-package "darkman" "20230527.1312" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "c45f00455c1e0e0dbd8b6f0da593c9e4299275dc" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainers
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://darkman.grtcdr.tn")
;; Local Variables:
;; no-byte-compile: t
;; End:
