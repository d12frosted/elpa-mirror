(define-package "ewal-doom-themes" "20200301.839" "Dread the colors of darkness"
  '((emacs "25")
    (ewal "0.1")
    (doom-themes "0.1"))
  :commit "732a2f4abb480f9f5a3249af822d8eb1e90324e3" :authors
  '(("Uros Perisic"))
  :maintainer
  '("Uros Perisic")
  :keywords
  '("faces")
  :url "https://gitlab.com/jjzmajic/ewal")
;; Local Variables:
;; no-byte-compile: t
;; End:
