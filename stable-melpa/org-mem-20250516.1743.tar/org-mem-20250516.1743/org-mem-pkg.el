;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250516.1743"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "aa03c1872d49fe285b6fd87c8fbedac8045c72a2"
  :revdesc "aa03c1872d49"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
