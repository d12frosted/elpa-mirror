;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261025.308"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "4a3b824567decd366171bd53be2c59092d23cdcd"
  :revdesc "4a3b824567de"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
