(define-package "apdl-mode" "20210809.1800" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "efab704f2d3060d71fcf427a15e791cc4ac68131" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
