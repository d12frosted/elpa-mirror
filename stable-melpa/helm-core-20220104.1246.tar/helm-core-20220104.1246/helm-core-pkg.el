(define-package "helm-core" "20220104.1246" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "e6730366aac6d8af0846695dccfadad8e31290dc")
;; Local Variables:
;; no-byte-compile: t
;; End:
