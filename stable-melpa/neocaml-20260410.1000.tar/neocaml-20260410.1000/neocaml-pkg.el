;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260410.1000"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "deb95d8b87641cf31d64487f627d8a51e48ff2e7"
  :revdesc "deb95d8b8764"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
