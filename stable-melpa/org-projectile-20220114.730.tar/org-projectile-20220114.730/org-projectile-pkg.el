(define-package "org-projectile" "20220114.730" "Repository todo management for org-mode"
  '((projectile "0.11.0")
    (dash "2.10.0")
    (emacs "24")
    (s "1.9.0")
    (org-category-capture "0.0.0"))
  :commit "bc5a2401b456c42c4346d59fa77d633770b6efea" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "projectile" "todo" "tools" "outlines")
  :url "https://github.com/IvanMalison/org-projectile")
;; Local Variables:
;; no-byte-compile: t
;; End:
