(define-package "apheleia" "20230325.1456" "Reformat buffer stably"
  '((emacs "26"))
  :commit "edec1e61c81da9e20575cf29a8875c56621e2edb" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/raxod502/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
