(define-package "telega" "20210104.1112" "Telegram client (unofficial)"
  '((emacs "26.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "bb8e38b0c85682b6cc488cf43e6d58accdfec82f" :authors
  (("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  ("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  ("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
