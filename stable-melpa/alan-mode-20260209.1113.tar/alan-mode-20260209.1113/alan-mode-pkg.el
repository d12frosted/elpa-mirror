;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alan-mode" "20260209.1113"
  "Major mode for editing Alan files."
  '((flycheck "32")
    (emacs    "25.1")
    (s        "1.12"))
  :url "https://github.com/Kjerner/AlanForEmacs"
  :commit "87eed317ea7eac483a33680fd230ffc9f0eb3297"
  :revdesc "87eed317ea7e"
  :keywords '("alan" "languages")
  :authors '(("Paul van Dam" . "pvandam@kjerner.com"))
  :maintainers '(("Paul van Dam" . "pvandam@kjerner.com")))
