(define-package "asm-blox" "20221102.500" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "1c850acd0e0e4c8865b687c9a70e9cba6a0222a0" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
