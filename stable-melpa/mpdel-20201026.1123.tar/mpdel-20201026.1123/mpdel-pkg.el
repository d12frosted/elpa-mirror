(define-package "mpdel" "20201026.1123" "Play and control your MPD music"
  '((emacs "25.1")
    (libmpdel "1.2.0")
    (navigel "0.7.0"))
  :commit "e937fbe0b98774e711134f3fac230a9fc66ac106" :keywords
  ("multimedia")
  :authors
  (("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  ("Damien Cassou" . "damien@cassou.me")
  :url "https://gitea.petton.fr/mpdel/mpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
