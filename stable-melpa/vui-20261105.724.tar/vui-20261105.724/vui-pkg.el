;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261105.724"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "bcb1b76460f09969f02a8ab988d3357a266f8c87"
  :revdesc "bcb1b76460f0"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
