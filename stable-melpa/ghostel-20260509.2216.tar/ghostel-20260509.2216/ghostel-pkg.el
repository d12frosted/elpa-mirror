;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260509.2216"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f4761ff3c55bb4b27271d78a26850515322f392e"
  :revdesc "f4761ff3c55b"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
