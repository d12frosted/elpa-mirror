(define-package "dirvish" "20220405.940" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "191a6e33a3067ed861af3bf1b434d788e039716b" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
