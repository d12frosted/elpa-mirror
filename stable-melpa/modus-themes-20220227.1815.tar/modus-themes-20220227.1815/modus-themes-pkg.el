(define-package "modus-themes" "20220227.1815" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "425d428a014125022315c2de69c17700a884d3ea" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
