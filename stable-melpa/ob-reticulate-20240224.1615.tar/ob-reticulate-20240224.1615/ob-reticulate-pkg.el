;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-reticulate" "20240224.1615"
  "Babel Functions for reticulate."
  '((org   "9.4")
    (emacs "24.4"))
  :url "https://github.com/jackkamm/ob-reticulate"
  :commit "dc08d43df967b15446f3d229fdc6bd600b7ea0df"
  :revdesc "dc08d43df967"
  :keywords '("literate programming" "reproducible research" "r" "python" "statistics" "languages" "outlines" "processes"))
