(define-package "smart-jump" "20210303.753" "Smart go to definition."
  '((emacs "25.1"))
  :commit "4b71456de97bfaa76e7276b499a29f74047b219e" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("tools")
  :url "https://github.com/jojojames/smart-jump")
;; Local Variables:
;; no-byte-compile: t
;; End:
