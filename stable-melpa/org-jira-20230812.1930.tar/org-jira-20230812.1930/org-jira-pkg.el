(define-package "org-jira" "20230812.1930" "Syncing between Jira and Org-mode."
  '((emacs "24.5")
    (cl-lib "0.5")
    (request "0.2.0")
    (dash "2.14.1"))
  :commit "49fc2c119b6bc7550754c2460abf4d06bff5650e" :maintainers
  '(("Matthew Carter" . "m@ahungry.com"))
  :maintainer
  '("Matthew Carter" . "m@ahungry.com")
  :keywords
  '("ahungry" "jira" "org" "bug" "tracker")
  :url "https://github.com/ahungry/org-jira")
;; Local Variables:
;; no-byte-compile: t
;; End:
