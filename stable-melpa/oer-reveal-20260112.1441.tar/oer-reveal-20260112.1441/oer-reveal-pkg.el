;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "20260112.1441"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.35.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "845be3095ede0e8cbe17b8e05ff24fbffc088b45"
  :revdesc "845be3095ede"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
