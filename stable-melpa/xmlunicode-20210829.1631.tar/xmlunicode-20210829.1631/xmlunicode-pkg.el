(define-package "xmlunicode" "20210829.1631" "Unicode support for XML" 'nil :commit "6e91a39114ae6ec98b26c9670db916a02c721b1f" :authors
  '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainer
  '("Norman Walsh" . "ndw@nwalsh.com")
  :keywords
  '("utf-8" "unicode" "xml" "characters"))
;; Local Variables:
;; no-byte-compile: t
;; End:
