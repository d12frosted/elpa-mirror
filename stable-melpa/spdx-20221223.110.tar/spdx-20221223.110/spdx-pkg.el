(define-package "spdx" "20221223.110" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "89158d866c2582e133720f2d743a29a7f1d988ed" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
