(define-package "flycheck-cfn" "20220221.1029" "Flycheck backend for AWS cloudformation"
  '((emacs "26.1")
    (flycheck "31"))
  :commit "4cf56affe3035fda364109836e26499431095185" :authors
  '(("William Orr" . "will@worrbase.com"))
  :maintainers
  '(("William Orr" . "will@worrbase.com"))
  :maintainer
  '("William Orr" . "will@worrbase.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/worr/cfn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
