;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250517.1447"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.8.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "9ecbe79465bc01b346b34ce0b2455e34f62a7fc1"
  :revdesc "9ecbe79465bc"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
