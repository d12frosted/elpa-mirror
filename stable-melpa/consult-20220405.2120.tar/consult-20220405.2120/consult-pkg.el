(define-package "consult" "20220405.2120" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "2ded333cf37c8f26cb25777de7ad3cda70934205" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
