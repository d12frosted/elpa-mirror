(define-package "consult" "20220405.2120" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "3df1b1e5126bf4f7446fdcc6d7a2a8573d814911" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
