;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kanagawa-themes" "20260522.325"
  "Elegant theme inspired by The Great Wave off Kanagawa."
  '((emacs "24.3"))
  :url "https://github.com/Fabiokleis/kanagawa-emacs"
  :commit "399dff7bc7abf5726ef85f880aa70d10b433afb4"
  :revdesc "399dff7bc7ab"
  :keywords '("themes" "faces")
  :authors '(("Mrjtjmn" . "meritamen@sdf.org"))
  :maintainers '(("Fabio Kleis" . "fabiohkrc@gmail.com")
                 ("Mrjtjmn" . "meritamen@sdf.org")))
