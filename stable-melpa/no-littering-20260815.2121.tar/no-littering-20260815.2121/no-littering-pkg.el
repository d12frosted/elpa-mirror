;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260815.2121"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "4740025b560c91d7e45c7c378d5539d26561e47e"
  :revdesc "4740025b560c"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
