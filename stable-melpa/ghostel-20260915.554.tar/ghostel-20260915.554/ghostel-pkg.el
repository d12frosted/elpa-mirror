;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260915.554"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f1b03e52c4c48bd66772317ebedfa374a4083afe"
  :revdesc "f1b03e52c4c4"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
