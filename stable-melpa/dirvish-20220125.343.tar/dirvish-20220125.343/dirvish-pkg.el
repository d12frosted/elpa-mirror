(define-package "dirvish" "20220125.343" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "ae9561037d70ac8509f8fec3c0db254b1cb07180" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
