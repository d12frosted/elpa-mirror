(define-package "soria-theme" "20210812.1003" "A xoria256 theme with some colors from openSUSE"
  '((emacs "25.1"))
  :commit "0b30ee125571a715d069846b4dafc5de8923cedd" :authors
  '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainer
  '("Miquel Sabaté Solà" . "mikisabate@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/mssola/soria")
;; Local Variables:
;; no-byte-compile: t
;; End:
