;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260327.1841"
  "Highlight window and cursor at switching."
  '((emacs "26.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "10ebcb8cb43890ce101ea72b60a9995a4bd4ece4"
  :revdesc "10ebcb8cb438"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
