(define-package "dwim-shell-command" "20221203.1801" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "da71ed398c143105dedba794a3996c181d44ae54" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
