;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-eca" "20260228.137"
  "Helm UI for ECA chats/workspaces."
  '((emacs "28.1")
    (eca   "0.8.1")
    (helm  "3.9.0"))
  :url "https://github.com/PalaceChan/helm-eca"
  :commit "34402f053cf6f42b77ff20bbd0891160605cc20e"
  :revdesc "34402f053cf6"
  :keywords '("tools" "convenience")
  :authors '(("PalaceChan" . "PalaceChan@users.noreply.github.com"))
  :maintainers '(("PalaceChan" . "PalaceChan@users.noreply.github.com")))
