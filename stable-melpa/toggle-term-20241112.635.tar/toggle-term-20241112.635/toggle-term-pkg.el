;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-term" "20241112.635"
  "Quickly toggle persistent term and shell buffers."
  '((emacs "25.1"))
  :url "https://github.com/justinlime/toggle-term.el"
  :commit "64f7022d214d5701c6babfe4a975baa60ec999c8"
  :revdesc "64f7022d214d"
  :keywords '("frames" "convenience" "terminals"))
