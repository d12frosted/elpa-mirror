;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shimbun" "20260408.652"
  "Interfacing with web newspapers."
  ()
  :url "https://github.com/emacs-w3m/emacs-w3m"
  :commit "ac4aeb3f7bf6d5a32127062b0ae311785fbc36ff"
  :revdesc "ac4aeb3f7bf6"
  :keywords '("news")
  :authors '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
             ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
             ("Yuuichi Teranishi" . "teranisi@gohome.org")
             ("Katsumi Yamaoka" . "yamaoka@jpl.org"))
  :maintainers '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
                 ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
                 ("Yuuichi Teranishi" . "teranisi@gohome.org")
                 ("Katsumi Yamaoka" . "yamaoka@jpl.org")))
