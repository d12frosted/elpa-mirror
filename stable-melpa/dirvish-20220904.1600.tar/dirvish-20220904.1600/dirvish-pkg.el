(define-package "dirvish" "20220904.1600" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "c08e1e5ecc56ca269e4fdde35d22842851317384" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
