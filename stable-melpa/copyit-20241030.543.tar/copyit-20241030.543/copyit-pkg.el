;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copyit" "20241030.543"
  "Copy it, yank anything!."
  '((emacs "24.3")
    (s     "1.9.0"))
  :url "https://github.com/zonuexe/emacs-copyit"
  :commit "09556ba8407dc2b132b7f76cd1b458c0773a1fe8"
  :revdesc "09556ba8407d"
  :keywords '("convenience" "yank" "clipboard")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
