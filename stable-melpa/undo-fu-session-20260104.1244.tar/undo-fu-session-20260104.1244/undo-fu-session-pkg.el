;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu-session" "20260104.1244"
  "Persistent undo, available between sessions."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu-session"
  :commit "58bd7f321e6fb2a359d32f23a962fd1d74966314"
  :revdesc "58bd7f321e6f"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
