(define-package "elpher" "20210820.1243" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "a3e7e8c83380707b0aacb7f048eb9b3a99526a16" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
