(define-package "boon" "20210215.744" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "432b685241c58217d606ef9a1085213144155812")
;; Local Variables:
;; no-byte-compile: t
;; End:
