(define-package "ecukes" "20230219.558" "Cucumber for Emacs"
  '((emacs "25")
    (commander "0.6.1")
    (espuds "0.2.2")
    (ansi "0.3.0")
    (dash "2.2.0")
    (s "1.8.0")
    (f "0.11.0"))
  :commit "68a3d6d7746f60a2fafcd4e23b3078e35f1c97d7")
;; Local Variables:
;; no-byte-compile: t
;; End:
