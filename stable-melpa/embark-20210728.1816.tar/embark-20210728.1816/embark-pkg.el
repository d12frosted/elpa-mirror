(define-package "embark" "20210728.1816" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "a4fec56e27bedeb742d9557fd01d5bc69a9d0bb3" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
