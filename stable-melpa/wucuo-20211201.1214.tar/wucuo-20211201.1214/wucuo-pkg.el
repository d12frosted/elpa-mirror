(define-package "wucuo" "20211201.1214" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "b6e35e275e033c664c7e47fbf2314231b90d8b06" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
