(define-package "smudge" "20210326.2222" "Control the Spotify app"
  '((emacs "27.1")
    (simple-httpd "1.5")
    (request "0.3")
    (oauth2 "0.16"))
  :commit "9e3488f485b7d7f3c97ebaad34ed552bb0cc228a" :keywords
  '("multimedia" "music" "spotify" "smudge")
  :url "https://github.com/danielfm/smudge")
;; Local Variables:
;; no-byte-compile: t
;; End:
