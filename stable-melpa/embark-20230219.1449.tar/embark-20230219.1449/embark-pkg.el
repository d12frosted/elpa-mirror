(define-package "embark" "20230219.1449" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "ce1aca600560d359ae85a20b36f6de19d3833771" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
