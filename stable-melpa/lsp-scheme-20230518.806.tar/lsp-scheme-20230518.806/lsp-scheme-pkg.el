(define-package "lsp-scheme" "20230518.806" "Scheme support for lsp-mode"
  '((emacs "26.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "e0aa799a73cdbe03ec9c2abe59f2c24c6211f66d" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainers
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
