;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250923.924"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "39280382d79bab3210513c8e9a4ecc61cefda7ac"
  :revdesc "39280382d79b"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
