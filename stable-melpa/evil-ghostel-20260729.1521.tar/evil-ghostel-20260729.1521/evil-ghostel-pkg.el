;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260729.1521"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.42.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f87c7ee794c34d4e100b229d49f07b89d0fec840"
  :revdesc "f87c7ee794c3"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
