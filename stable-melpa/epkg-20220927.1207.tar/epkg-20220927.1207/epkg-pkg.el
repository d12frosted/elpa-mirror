(define-package "epkg" "20220927.1207" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "28.1.1.0")
    (closql "20210927"))
  :commit "582759aa230e1de252f7b60711e38034769ab602" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
