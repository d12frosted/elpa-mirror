(define-package "osm" "20230925.655" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "f018af460d3daac0756db1ed92f52ef6b931c55c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
