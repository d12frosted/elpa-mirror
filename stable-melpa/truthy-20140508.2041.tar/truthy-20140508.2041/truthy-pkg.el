;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truthy" "20140508.2041"
  "Test the content of a value."
  '((list-utils "0.4.2"))
  :url "https://github.com/rolandwalker/truthy"
  :commit "782cee08fbb13f9be71ce8e88d980ec14db24a0f"
  :revdesc "782cee08fbb1"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
