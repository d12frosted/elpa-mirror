;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-ffdata" "20191017.1237"
  "Use ivy to access firefox data."
  '((emacs   "25.1")
    (counsel "0.11.0")
    (emacsql "3.0.0"))
  :url "https://github.com/cireu/counsel-ffdata"
  :commit "913cb1b8cd5e4ca2ba6613eab56d52040e08a0a5"
  :revdesc "913cb1b8cd5e"
  :keywords '("convenience" "tools" "matching")
  :authors '(("Zhu Zihao" . "all_but_last@163.com"))
  :maintainers '(("Zhu Zihao" . "all_but_last@163.com")))
