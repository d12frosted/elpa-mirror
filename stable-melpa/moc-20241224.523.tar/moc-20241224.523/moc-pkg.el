;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moc" "20241224.523"
  "Master of Ceremonies."
  '((emacs          "29.4")
    (hide-mode-line "1.0.3")
    (transient      "0.7.2"))
  :url "https://github.com/positron-solutions/moc"
  :commit "d5f9f68736fc1e8aeb35f63ab5449702ed3ff935"
  :revdesc "d5f9f68736fc"
  :keywords '("convenience" "outline")
  :authors '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainers '(("Positron Solutions" . "contact@positron.solutions")))
