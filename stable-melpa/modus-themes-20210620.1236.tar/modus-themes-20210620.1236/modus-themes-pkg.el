(define-package "modus-themes" "20210620.1236" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "3de5ecb28b522a942b6c3b5697da8af3bcca4705" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
