(define-package "inf-ruby" "20240506.1902" "Run a Ruby process in a buffer"
  '((emacs "26.1"))
  :commit "ff662e3fb720138a3c966e63c691c89e15c1233c" :authors
  '(("Yukihiro Matsumoto")
    ("Nobuyoshi Nakada")
    ("Cornelius Mika" . "cornelius.mika@gmail.com")
    ("Dmitry Gutov" . "dgutov@yandex.ru")
    ("Kyle Hargraves" . "pd@krh.me"))
  :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("languages" "ruby")
  :url "http://github.com/nonsequitur/inf-ruby")
;; Local Variables:
;; no-byte-compile: t
;; End:
