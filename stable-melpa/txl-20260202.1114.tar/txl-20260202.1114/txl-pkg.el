;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "txl" "20260202.1114"
  "Provides machine translation via DeepL's REST API."
  '((request        "0.3.2")
    (guess-language "0.0.1")
    (emacs          "24.4"))
  :url "https://github.com/tmalsburg/txl.el"
  :commit "87fcd5f65cd572dd992abcbbff1b1f5990d8de7e"
  :revdesc "87fcd5f65cd5"
  :keywords '("wp")
  :authors '(("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainers '(("Titus von der Malsburg" . "malsburg@posteo.de")))
