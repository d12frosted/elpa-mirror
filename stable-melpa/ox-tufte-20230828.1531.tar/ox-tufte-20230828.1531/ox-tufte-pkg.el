(define-package "ox-tufte" "20230828.1531" "Tufte HTML org-mode export backend"
  '((org "9.5")
    (emacs "27.1"))
  :commit "55e095ae4790c84a5d1d5b91b3c492af7f51b98c" :authors
  '(("M. Lee Hinman"))
  :maintainers
  '(("The Bayesians Inc."))
  :maintainer
  '("The Bayesians Inc.")
  :keywords
  '("org" "tufte" "html" "outlines" "hypermedia" "calendar" "wp")
  :url "https://github.com/ox-tufte/ox-tufte")
;; Local Variables:
;; no-byte-compile: t
;; End:
