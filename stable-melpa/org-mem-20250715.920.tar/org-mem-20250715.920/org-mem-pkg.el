;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250715.920"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "dbe49db397a8d39e508bfbff1de75d7813aede5a"
  :revdesc "dbe49db397a8"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
