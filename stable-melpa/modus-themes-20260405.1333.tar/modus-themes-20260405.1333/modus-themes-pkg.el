;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260405.1333"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "b07a5d50019d3f85721fc0986cad419a1940c366"
  :revdesc "b07a5d50019d"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
