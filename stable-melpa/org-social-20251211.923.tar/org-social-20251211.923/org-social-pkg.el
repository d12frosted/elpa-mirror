;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251211.923"
  "An Org-social client."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "08dbb4ac30c8260deaecc7d14d732aa80624be20"
  :revdesc "08dbb4ac30c8"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
