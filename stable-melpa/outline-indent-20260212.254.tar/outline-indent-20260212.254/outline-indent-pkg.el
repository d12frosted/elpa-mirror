;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260212.254"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "d4539a095cfaa5b8c1eb29cf47396e71495b5804"
  :revdesc "d4539a095cfa"
  :keywords '("outlines"))
