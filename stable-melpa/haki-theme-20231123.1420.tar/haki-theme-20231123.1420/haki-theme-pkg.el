(define-package "haki-theme" "20231123.1420" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "5dd50fe4739cf8d2e96a02f7a318bf4fed8cfe06" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
