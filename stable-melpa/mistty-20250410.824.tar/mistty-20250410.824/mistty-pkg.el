;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250410.824"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "34bbdd6798150008eb5b2a3c817d84dacf78c37b"
  :revdesc "34bbdd679815"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
