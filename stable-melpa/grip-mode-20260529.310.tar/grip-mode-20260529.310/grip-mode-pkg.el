;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grip-mode" "20260529.310"
  "Instant GitHub-flavored Markdown/Org preview using grip."
  '((emacs "24.4"))
  :url "https://github.com/seagle0128/grip-mode"
  :commit "903ee9ebab2c00fb13f68d984b54a782c4294552"
  :revdesc "903ee9ebab2c"
  :keywords '("convenience" "markdown" "preview")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
