;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-web-track" "20260215.734"
  "Web data tracking framework in Org Mode."
  '((emacs   "29.1")
    (request "0.3.0")
    (enlive  "0.0.1")
    (gnuplot "0.8.1"))
  :url "https://github.com/p-snow/org-web-track"
  :commit "2c4215499c0851e85b480bc19e96a236fb9af8f1"
  :revdesc "2c4215499c08"
  :keywords '("org" "agenda" "web" "hypermedia")
  :authors '(("p-snow" . "public@p-snow.org"))
  :maintainers '(("p-snow" . "public@p-snow.org")))
