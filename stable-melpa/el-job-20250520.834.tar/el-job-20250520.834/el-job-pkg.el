;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250520.834"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "cad950dd887d03fc4a328051f8fc8d9907bdb606"
  :revdesc "cad950dd887d"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
