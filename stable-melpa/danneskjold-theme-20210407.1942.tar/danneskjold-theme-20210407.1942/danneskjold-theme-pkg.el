(define-package "danneskjold-theme" "20210407.1942" "Beautiful high-contrast Emacs theme." 'nil :commit "cd45635155aa6bae941156043217ce11531deca9" :authors
  '(("Dmitry Akatov" . "akatovda@yandex.com"))
  :maintainer
  '("Dmitry Akatov" . "akatovda@yandex.com")
  :url "https://github.com/rails-to-cosmos/")
;; Local Variables:
;; no-byte-compile: t
;; End:
