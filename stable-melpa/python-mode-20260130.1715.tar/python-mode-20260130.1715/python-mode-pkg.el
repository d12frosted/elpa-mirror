;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20260130.1715"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "f829abe9c1629cc028253e2b8766053fa0510514"
  :revdesc "f829abe9c162"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
