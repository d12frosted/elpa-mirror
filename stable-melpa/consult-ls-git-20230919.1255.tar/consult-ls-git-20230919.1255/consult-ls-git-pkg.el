(define-package "consult-ls-git" "20230919.1255" "Consult integration for git"
  '((emacs "27.1")
    (consult "0.16"))
  :commit "cabea67e82e5e75d8ae45f7f2bb9d7910c4234ac" :authors
  '(("Robin Joy"))
  :maintainers
  '(("Robin Joy"))
  :maintainer
  '("Robin Joy")
  :keywords
  '("convenience")
  :url "https://github.com/rcj/consult-ls-git")
;; Local Variables:
;; no-byte-compile: t
;; End:
