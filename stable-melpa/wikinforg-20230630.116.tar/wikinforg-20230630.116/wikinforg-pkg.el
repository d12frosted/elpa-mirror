(define-package "wikinforg" "20230630.116" "Org-mode wikinfo integration"
  '((emacs "27.1")
    (wikinfo "0.0.0")
    (org "9.3"))
  :commit "525ab7d72ffbfbb57868f430a67cad010904ccf5" :authors
  '(("Nicholas Vollmer" . "progfolio@protonmail.com"))
  :maintainers
  '(("Nicholas Vollmer" . "progfolio@protonmail.com"))
  :maintainer
  '("Nicholas Vollmer" . "progfolio@protonmail.com")
  :keywords
  '("org" "convenience")
  :url "https://github.com/progfolio/wikinforg")
;; Local Variables:
;; no-byte-compile: t
;; End:
