(define-package "hyperdrive" "20230811.2032" "P2P filesystem"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5"))
  :commit "008af15a1ce5f35d844639a1236f015c02c9117c" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
