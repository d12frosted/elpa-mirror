(define-package "hass" "20220612.2151" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3"))
  :commit "9de26718ba6f369c9f161957cbc5136382fc51e1" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
