;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260517.947"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "a11cd92a026b1fc89b7ac61f089034383f540a30"
  :revdesc "a11cd92a026b"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
