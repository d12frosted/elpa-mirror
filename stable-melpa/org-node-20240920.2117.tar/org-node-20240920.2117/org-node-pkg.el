(define-package "org-node" "20240920.2117" "Link org-id entries into a network"
  '((emacs "28.1")
    (compat "30")
    (llama "0"))
  :commit "62d552adb04c9b26db73c9b8f2a24a9c8f5d8253" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node")
;; Local Variables:
;; no-byte-compile: t
;; End:
