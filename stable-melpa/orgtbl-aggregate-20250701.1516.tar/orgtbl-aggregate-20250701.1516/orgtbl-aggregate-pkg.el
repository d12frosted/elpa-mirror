;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20250701.1516"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "d7690d335f9311879c0f8dcbd05acf7698d53cca"
  :revdesc "d7690d335f93"
  :keywords '("data" "extensions"))
