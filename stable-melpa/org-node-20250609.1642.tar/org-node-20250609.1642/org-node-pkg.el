;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250609.1642"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.16.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f86fd4297852f9dbc5889ca422a6d34ba4aebcb0"
  :revdesc "f86fd4297852"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
