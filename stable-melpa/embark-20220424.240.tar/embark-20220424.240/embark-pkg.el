(define-package "embark" "20220424.240" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "5ad6fe2420fb29e5740e8acd8136c0aaa0b12921" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
