(define-package "consult" "20210807.1249" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "12b8df7e94974c82c5839bd8f8b6199184e61965" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
