;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20260529.2047"
  "Persist and restore text scale."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "15a82ff64a0c2562f472d0a1117d67d861ca7278"
  :revdesc "15a82ff64a0c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
