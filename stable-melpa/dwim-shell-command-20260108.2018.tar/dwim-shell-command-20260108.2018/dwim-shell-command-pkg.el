;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-shell-command" "20260108.2018"
  "Shell commands with DWIM behaviour."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/dwim-shell-command"
  :commit "b2744863219ed7fe613e70de57511563bc21cc11"
  :revdesc "b2744863219e")
