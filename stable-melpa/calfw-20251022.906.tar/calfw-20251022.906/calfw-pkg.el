;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251022.906"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "b7c78226d830aa182722813c1c5908182da97c09"
  :revdesc "b7c78226d830"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
