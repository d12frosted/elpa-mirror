;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260926.1400"
  "Curate an Emacs Lisp package archive."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://github.com/melpa/package-build"
  :commit "0e4d3f13bdde166b70e0ac8bc3c5eef15063d37d"
  :revdesc "0e4d3f13bdde"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
