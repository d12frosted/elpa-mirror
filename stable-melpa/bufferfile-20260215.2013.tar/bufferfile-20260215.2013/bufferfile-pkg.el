;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20260215.2013"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "6c3a089b3b25a26880f672a900402d59b638837d"
  :revdesc "6c3a089b3b25"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
