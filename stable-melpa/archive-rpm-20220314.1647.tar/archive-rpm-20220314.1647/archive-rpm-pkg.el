(define-package "archive-rpm" "20220314.1647" "RPM and CPIO support for archive-mode"
  '((emacs "24.4"))
  :commit "515d2230352fffcc982ae2e322d95cbee6aca760" :authors
  '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainer
  '("Magnus Henoch" . "magnus.henoch@gmail.com")
  :keywords
  '("files"))
;; Local Variables:
;; no-byte-compile: t
;; End:
