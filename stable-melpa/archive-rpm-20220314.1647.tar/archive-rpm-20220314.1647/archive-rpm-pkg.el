(define-package "archive-rpm" "20220314.1647" "RPM and CPIO support for archive-mode"
  '((emacs "24.4"))
  :commit "379dddfbe4e801df6fdb81a55528fab6c7dbb78e" :authors
  '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainer
  '("Magnus Henoch" . "magnus.henoch@gmail.com")
  :keywords
  '("files"))
;; Local Variables:
;; no-byte-compile: t
;; End:
