;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stgit" "20260518.524"
  "Major mode for StGit interaction."
  ()
  :url "http://stacked-git.github.io"
  :commit "41e81189613ff3060fa5cc372e871f61cbcd78c2"
  :revdesc "41e81189613f"
  :authors '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainers '(("David Kågedal" . "davidk@lysator.liu.se")))
