;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260708.601"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "0d01a788c86f6787748e755983aeb5ce653dec01"
  :revdesc "0d01a788c86f"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
