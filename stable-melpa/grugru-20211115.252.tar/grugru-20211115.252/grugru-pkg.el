(define-package "grugru" "20211115.252" "Rotate text at point"
  '((emacs "24.4"))
  :commit "3c32f92eaacfda8842c8afda744e3b7548cadd45" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
