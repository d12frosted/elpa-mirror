(define-package "datetime" "20230917.1822" "Parsing, formatting and matching timestamps"
  '((emacs "24.4")
    (extmap "1.1.1"))
  :commit "58b7ac95ad39db0426de5e6e96b32487773d090d" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
