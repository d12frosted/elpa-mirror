;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251103.1133"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "f5db470ed618d5c99cdae760312f26392c2b0171"
  :revdesc "f5db470ed618"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
