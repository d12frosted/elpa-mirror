;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "supersonic" "20261018.2009"
  "Music client for Subsonic servers and Music Assistant."
  '((emacs     "28.1")
    (transient "0.2")
    (aio       "1.2"))
  :url "https://github.com/systemfreund/supersonic.el"
  :commit "13860548ac02cdc75a684f1e52e80a20a2711419"
  :revdesc "13860548ac02"
  :keywords '("multimedia")
  :authors '(("systemfreund" . "github@o9z.de"))
  :maintainers '(("systemfreund" . "github@o9z.de")))
