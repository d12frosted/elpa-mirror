;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jump-to-line" "20130122.1653"
  "Jump to line number at point."
  ()
  :url "https://github.com/ongaeshi/jump-to-line"
  :commit "01ef8c3529d85e6c59cc20840acbc4a8e8325bc8"
  :revdesc "01ef8c3529d8"
  :keywords '("jump" "line" "back" "file" "ruby" "csharp" "python" "perl"))
