(define-package "mistty" "20230927.1936" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "ddfe965679a3d6d03ae93fd7b2b7c6743d8713b5" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
