(define-package "detached" "20221117.2210" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "ca0ee7e4650194d575e1355cdfcda13bbf7f40db" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
