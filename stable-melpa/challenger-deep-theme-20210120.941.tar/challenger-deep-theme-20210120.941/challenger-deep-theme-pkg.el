(define-package "challenger-deep-theme" "20210120.941" "challenger-deep Theme"
  '((emacs "24"))
  :commit "2a799259406a8b96a688873093ffab6630a3ad3b" :authors
  '(("MaxSt"))
  :maintainers
  '(("MaxSt"))
  :maintainer
  '("MaxSt")
  :url "https://github.com/challenger-deep-theme/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
