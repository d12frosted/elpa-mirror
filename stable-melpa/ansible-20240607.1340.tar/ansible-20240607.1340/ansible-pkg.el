(define-package "ansible" "20240607.1340" "Ansible minor mode"
  '((s "1.9.0")
    (f "0.16.2"))
  :commit "079c993b0825eef7c527f1e9083c3f0a0fefc01d" :authors
  '(("k1LoW (Kenichirou Oyama), <k1lowxb [at] gmail [dot] com> <k1low [at] 101000lab [dot] org>"))
  :maintainers
  '(("k1LoW (Kenichirou Oyama), <k1lowxb [at] gmail [dot] com> <k1low [at] 101000lab [dot] org>"))
  :maintainer
  '("k1LoW (Kenichirou Oyama), <k1lowxb [at] gmail [dot] com> <k1low [at] 101000lab [dot] org>")
  :url "https://gitlab.com/emacs-ansible/emacs-ansible")
;; Local Variables:
;; no-byte-compile: t
;; End:
