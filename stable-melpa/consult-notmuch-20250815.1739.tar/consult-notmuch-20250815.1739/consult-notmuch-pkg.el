;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-notmuch" "20250815.1739"
  "Notmuch search using consult."
  '((emacs   "28.1")
    (consult "2.7")
    (notmuch "0.31"))
  :url "https://codeberg.org/jao/consult-notmuch"
  :commit "abc0318c9971b4288cc96f6f934ad6d36e63d9f9"
  :revdesc "abc0318c9971"
  :keywords '("mail")
  :authors '(("Jose A Ortega Ruiz" . "jao@gnu.org")))
