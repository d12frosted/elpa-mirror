(define-package "helm" "20221023.607" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.8")
    (popup "0.5.3"))
  :commit "2e33e343a1f47f7d13b03b5239850dc73ea39990" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
