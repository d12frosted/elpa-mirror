;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250215.1652"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "65846e7ebdf08483d63386ba53c631a0fcc0ee8a"
  :revdesc "65846e7ebdf0"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
