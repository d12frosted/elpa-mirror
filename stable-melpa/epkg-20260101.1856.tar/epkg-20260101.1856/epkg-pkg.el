;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260101.1856"
  "Browse the Emacsmirror package database."
  '((emacs   "28.1")
    (compat  "30.1")
    (closql  "2.4")
    (emacsql "4.3")
    (llama   "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "0dcab271d547736791e13be49cd6ee3630110eb1"
  :revdesc "0dcab271d547"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
