(define-package "citre" "20220124.1529" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "ef0711048da5917f4edf4822040ce4059fefb9e6" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
