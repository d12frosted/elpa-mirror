;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260403.532"
  "XMPP/Jabber client."
  '((emacs "29.1")
    (fsm   "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-jabber"
  :commit "661a46a77904e03c62e806e67ae1382dd23fda08"
  :revdesc "661a46a77904"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
