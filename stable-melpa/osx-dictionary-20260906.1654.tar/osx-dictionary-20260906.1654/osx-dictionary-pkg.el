;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osx-dictionary" "20260906.1654"
  "Interface for OSX Dictionary.app."
  '((cl-lib "0.5"))
  :url "https://github.com/xuchunyang/osx-dictionary.el"
  :commit "655bca5cea78440a1ac41f9cd78711b9c8aff8f3"
  :revdesc "655bca5cea78"
  :keywords '("mac" "dictionary")
  :authors '(("Chunyang Xu" . "mail@xuchunyang.me"))
  :maintainers '(("Chunyang Xu" . "mail@xuchunyang.me")))
