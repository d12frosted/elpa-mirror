(define-package "burly" "20220825.2211" "Save and restore frame/window configurations with buffers"
  '((emacs "27.1")
    (map "2.1"))
  :commit "4a877f80252edac8dc7e613b1c5b3aa4e9b9137f" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
