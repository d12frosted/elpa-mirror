;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "20250104.418"
  "A set of eye pleasing themes."
  '((emacs      "25.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "a37e99217d20ae61c544a4a8dae442d699257926"
  :revdesc "a37e99217d20"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
