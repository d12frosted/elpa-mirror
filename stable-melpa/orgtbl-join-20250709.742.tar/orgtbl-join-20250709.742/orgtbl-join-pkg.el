;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20250709.742"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "f7eff55603645bc10c84370a36da9ce50a5d33f4"
  :revdesc "f7eff5560364"
  :keywords '("data" "extensions"))
