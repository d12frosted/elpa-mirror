(define-package "mono-complete" "20230401.258" "Completion suggestions with multiple back-ends"
  '((emacs "28.1"))
  :commit "37036a643372960937b08b92675b2983809aea40" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mono-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
