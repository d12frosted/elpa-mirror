;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark-consult" "20260218.624"
  "Consult integration for Embark."
  '((emacs   "29.1")
    (compat  "30")
    (embark  "1.1")
    (consult "3.2"))
  :url "https://github.com/oantolin/embark"
  :commit "0bdfd38d281d6375e6e675ce6f1bd597a9e3b136"
  :revdesc "0bdfd38d281d"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
