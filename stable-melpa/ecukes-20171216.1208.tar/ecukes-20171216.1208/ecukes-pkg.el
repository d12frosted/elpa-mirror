(define-package "ecukes" "20171216.1208" "Cucumber for Emacs."
  '((commander "0.6.1")
    (espuds "0.2.2")
    (ansi "0.3.0")
    (dash "2.2.0")
    (s "1.8.0")
    (f "0.11.0"))
  :commit "3a77ba9f1064c2bca47b401974c009e65727c46e")
;; Local Variables:
;; no-byte-compile: t
;; End:
