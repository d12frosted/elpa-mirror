(define-package "dwim-shell-command" "20221218.46" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "18b1af3635f68a941e2d451b249808322b1a69a4" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
