;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20261127.48"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "db7f60efdf8364e66161cb8a8ea9bb703ab37247"
  :revdesc "db7f60efdf83"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
