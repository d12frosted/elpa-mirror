;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "encourage-mode" "20151128.905"
  "Encourages you in your work. :D."
  '((emacs "24.4"))
  :url "https://github.com/halbtuerke/encourage-mode.el"
  :commit "ca411e6bfd3d0edffe95852127bd995730b942e3"
  :revdesc "ca411e6bfd3d"
  :keywords '("fun")
  :authors '(("Patrick Mosby" . "patrick@schreiblogade.de"))
  :maintainers '(("Patrick Mosby" . "patrick@schreiblogade.de")))
