(define-package "ebib" "20220616.1517" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "26.1"))
  :commit "9afe139ee03ccd4c9fd5c2882ea4fff9d57f725d" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
