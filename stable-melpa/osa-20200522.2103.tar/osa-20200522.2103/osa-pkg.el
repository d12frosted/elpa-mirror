;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osa" "20200522.2103"
  "OSA (JavaScript / AppleScript) bridge."
  '((emacs "25.1"))
  :url "https://github.com/atomontage/osa"
  :commit "615ca9eef4131a23d9971691fa0d0f20fe59d01b"
  :revdesc "615ca9eef413"
  :keywords '("extensions")
  :authors '(("xristos" . "xristos@sdf.org"))
  :maintainers '(("xristos" . "xristos@sdf.org")))
