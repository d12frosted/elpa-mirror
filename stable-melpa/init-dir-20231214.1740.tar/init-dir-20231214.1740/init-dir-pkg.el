(define-package "init-dir" "20231214.1740" "Init directory instead of just a single file"
  '((emacs "27.1"))
  :commit "c18f8e35885f5f126fae68d7e65cc61d63a1e0b6" :authors
  '(("Jared Finder" . "jared@finder.org"))
  :maintainers
  '(("Jared Finder" . "jared@finder.org"))
  :maintainer
  '("Jared Finder" . "jared@finder.org")
  :keywords
  '("extensions" "internal")
  :url "http://github.com/chaosemer/init-dir")
;; Local Variables:
;; no-byte-compile: t
;; End:
