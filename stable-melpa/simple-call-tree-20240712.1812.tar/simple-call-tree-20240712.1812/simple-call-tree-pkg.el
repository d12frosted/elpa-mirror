(define-package "simple-call-tree" "20240712.1812" "analyze source code based on font-lock text-properties"
  '((emacs "24.3")
    (anaphora "1.0.0"))
  :commit "54032274d046b00ca5dd3a4e6af7d377f357f9e7" :authors
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("programming")
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
