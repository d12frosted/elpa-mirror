;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260425.2304"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "695f30bbaa227f9aa5ef891bb7ac6f973efdc99c"
  :revdesc "695f30bbaa22"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
