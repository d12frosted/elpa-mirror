;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "koishi-theme" "20260212.1605"
  "A sweet theme inspired by Koishi's color tone."
  '((emacs "24.1"))
  :url "https://github.com/gynamics/koishi-theme.el"
  :commit "e699d5181265981d28f1bd3c13446916c77aeb06"
  :revdesc "e699d5181265"
  :keywords '("faces"))
