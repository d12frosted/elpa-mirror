;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jal" "20260810.1023"
  "Java Agent Loader (JAL) for JDTLS."
  '((emacs "28.1"))
  :url "https://github.com/saulotoledo/java-agent-loader"
  :commit "f42bd3b9ec1ea6ca68c23b007071f85451891df6"
  :revdesc "f42bd3b9ec1e"
  :keywords '("java" "languages" "tools")
  :authors '(("Saulo Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo Toledo" . "saulotoledo@gmail.com")))
