;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261126.913"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "e51b05e3807c0906640d247b8878beafdde85627"
  :revdesc "e51b05e3807c"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
