;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "autoscratch" "20251217.1834"
  "Automatically switch scratch buffer mode."
  '((emacs "24.1"))
  :url "https://codeberg.org/scip/autoscratch"
  :commit "c56cc89dc4a51e0d5966391d78849dc391634bb5"
  :revdesc "c56cc89dc4a5"
  :keywords '("convenience" "buffer" "scrach")
  :authors '(("T.v.Dein" . "tlinden@cpan.org"))
  :maintainers '(("T.v.Dein" . "tlinden@cpan.org")))
