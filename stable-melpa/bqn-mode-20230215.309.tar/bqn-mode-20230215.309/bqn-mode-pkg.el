(define-package "bqn-mode" "20230215.309" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "6089e141dd693f809673c518fa07283ffeadb734" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
