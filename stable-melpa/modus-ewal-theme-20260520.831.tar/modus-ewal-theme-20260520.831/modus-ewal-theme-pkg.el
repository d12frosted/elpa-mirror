;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-ewal-theme" "20260520.831"
  "Modus theme that uses pywal colors powered by ewal."
  '((emacs        "25.1")
    (modus-themes "5.2.0")
    (ewal         "0.2.1"))
  :url "https://github.com/deadendpl/modus-ewal-theme"
  :commit "dba8efce3e43f0bbf6e8de073159559e35b531a4"
  :revdesc "dba8efce3e43"
  :keywords '("faces" "theme")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
