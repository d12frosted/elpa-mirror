(define-package "stimmung-themes" "20210416.1450" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "c149f45fe529369d95bbcb41989468abb0f100f1" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
