;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eshell-outline" "20201121.620"
  "Enhanced outline-mode for Eshell."
  '((emacs "25.1"))
  :url "https://git.jamzattack.xyz/eshell-outline"
  :commit "6f917afa5b3d36764d76d7864589094647d8c3b4"
  :revdesc "6f917afa5b3d"
  :keywords '("unix" "eshell" "outline" "convenience")
  :authors '(("Jamie Beardslee" . "jdb@jamzattack.xyz"))
  :maintainers '(("Jamie Beardslee" . "jdb@jamzattack.xyz")))
