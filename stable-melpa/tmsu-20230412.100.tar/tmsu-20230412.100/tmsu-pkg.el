(define-package "tmsu" "20230412.100" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "27b017b143890deaa1349f545ee8c096799142ea" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
