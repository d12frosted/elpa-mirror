;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260810.917"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "60e21a2feb0eb728183dff1331f72953c46a1e2a"
  :revdesc "60e21a2feb0e"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
