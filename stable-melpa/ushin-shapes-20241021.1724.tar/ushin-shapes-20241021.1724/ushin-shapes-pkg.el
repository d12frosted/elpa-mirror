;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ushin-shapes" "20241021.1724"
  "USHIN shapes in org-mode."
  '((emacs        "27.1")
    (svg-tag-mode "0.3.3")
    (svg-lib      "0.3"))
  :url "https://git.sr.ht/~ushin/ushin-shapes.el"
  :commit "6b8f432518ea790fcb34dbcaac6ae223001dbfba"
  :revdesc "6b8f432518ea"
  :keywords '("convenience")
  :authors '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers '(("Joseph Turner" . "joseph@ushin.org")))
