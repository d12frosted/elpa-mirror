;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20261020.609"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.67.1")
    (latex-to-svg-backend "0.16.1"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "288dc041f2d9ca986c8899cf99d016b883888801"
  :revdesc "288dc041f2d9"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
