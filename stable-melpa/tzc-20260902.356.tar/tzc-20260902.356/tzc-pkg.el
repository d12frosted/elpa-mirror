;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260902.356"
  "Converts time between different time zones."
  '((emacs     "28.1")
    (org       "9.5")
    (transient "0.3.7"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "26e9627f572f724273c920bd83df5f676ff45871"
  :revdesc "26e9627f572f"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
