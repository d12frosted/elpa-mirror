(define-package "circe" "20201207.1" "Client for IRC in Emacs"
  '((cl-lib "0.5"))
  :commit "107b74c9f4318eaa385819876cd8772ef650d1f4" :url "https://github.com/jorgenschaefer/circe")
;; Local Variables:
;; no-byte-compile: t
;; End:
