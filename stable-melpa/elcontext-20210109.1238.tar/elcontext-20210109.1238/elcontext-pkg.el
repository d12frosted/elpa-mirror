;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcontext" "20210109.1238"
  "Create context specific actions."
  '((ht           "2.3")
    (hydra        "0.14.0")
    (emacs        "24.3")
    (f            "0.20.0")
    (osx-location "0.4")
    (uuidgen      "0.3"))
  :url "https://github.com/rollacaster/elcontext"
  :commit "2efd3dd8c5176c4f071bb048be6cb069b05d6e9e"
  :revdesc "2efd3dd8c517"
  :keywords '("calendar" "convenience"))
