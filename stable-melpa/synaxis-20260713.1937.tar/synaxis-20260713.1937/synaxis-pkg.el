;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synaxis" "20260713.1937"
  "Feed reader with SQLite storage."
  '((emacs        "29.1")
    (keymap-popup "0.2.1"))
  :url "https://git.thanosapollo.org/synaxis"
  :commit "fd0272e9a9dde9e31d592348638f62bcb3baebfe"
  :revdesc "fd0272e9a9dd"
  :keywords '("news" "hypermedia" "rss" "atom")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
