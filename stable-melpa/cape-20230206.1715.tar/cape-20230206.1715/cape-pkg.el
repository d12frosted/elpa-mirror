(define-package "cape" "20230206.1715" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "56601bbccb1371ec6ab3788140a9f0440dccc914" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
