;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-mongo" "20170720.1919"
  "Execute mongodb queries within org-mode blocks."
  '((org "8"))
  :url "https://github.com/krisajenkins/ob-mongo"
  :commit "371bf19c7c10eab2f86424f8db8ab685997eb5aa"
  :revdesc "371bf19c7c10"
  :keywords '("org" "babel" "mongo" "mongodb")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
