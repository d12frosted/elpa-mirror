;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crappy-jsp-mode" "20140311.931"
  "A pretty crappy major-mode for jsp."
  ()
  :url "https://github.com/magnars/crappy-jsp-mode"
  :commit "6c45ab92b452411cc0fab9bcee2f456276b4fc40"
  :revdesc "6c45ab92b452"
  :keywords '("jsp" "major" "mode")
  :authors '(("Magnar Sveen" . "magnars@gmail.com")
             ("Jostein Holje" . "jostein.holje@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")
                 ("Jostein Holje" . "jostein.holje@gmail.com")))
