;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "runner" "20160524.1048"
  "Improved \"open with\" suggestions for dired."
  ()
  :url "https://github.com/thamer/runner"
  :commit "a211d57ddc600410d07a8b534920ba905b093d87"
  :revdesc "a211d57ddc60"
  :keywords '("shell command" "dired" "file extension" "open with")
  :authors '(("Thamer Mahmoud" . "thamer.mahmoud@gmail.com"))
  :maintainers '(("Thamer Mahmoud" . "thamer.mahmoud@gmail.com")))
