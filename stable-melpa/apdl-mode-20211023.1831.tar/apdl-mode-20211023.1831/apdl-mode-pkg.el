(define-package "apdl-mode" "20211023.1831" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "c55c6468526100ba0da00bff05cfb17cdf8839cf" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
