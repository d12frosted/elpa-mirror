(define-package "w3m" "20210408.1132" "an Emacs interface to w3m" 'nil :commit "769bbfa0b9c7c6ae6cfa7b65959d6b26ca4809a5" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
