(define-package "embark" "20211021.1340" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "edf352906519d229488119c5952095655bd304e3" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
