(define-package "simple-modeline" "20201218.840" "A simple mode-line configuration for Emacs"
  '((emacs "26.1"))
  :commit "38973dec2912e2136d8fde5f2667063863fee15a" :keywords
  ("mode-line" "faces")
  :authors
  (("Eder Elorriaga" . "gexplorer8@gmail.com"))
  :maintainer
  ("Eder Elorriaga" . "gexplorer8@gmail.com")
  :url "https://github.com/gexplorer/simple-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
