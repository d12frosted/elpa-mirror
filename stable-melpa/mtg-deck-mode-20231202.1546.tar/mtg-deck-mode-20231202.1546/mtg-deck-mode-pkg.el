(define-package "mtg-deck-mode" "20231202.1546" "Major mode to edit MTG decks"
  '((emacs "25.1"))
  :commit "3cb3866951feae40531c0a2e4fa72c0f2989c36c" :keywords
  '("data" "mtg" "magic")
  :url "https://github.com/mattiasb/mtg-deck-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
