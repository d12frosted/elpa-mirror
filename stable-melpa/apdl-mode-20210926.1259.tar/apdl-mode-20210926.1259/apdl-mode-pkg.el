(define-package "apdl-mode" "20210926.1259" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "4ac9aca7a68ce07a5ca5319e19f3ce24ae55a5a1" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
