;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-python-preset" "20260402.158"
  "Eglot preset for Python."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-python-preset"
  :commit "0c6118e234ba42866ce045cb8fc89997633d871e"
  :revdesc "0c6118e234ba"
  :keywords '("python" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
