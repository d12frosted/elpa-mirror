;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251125.1628"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.7.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "3803449d80318bb4005fd9509ebc8a669750ceea"
  :revdesc "3803449d8031")
