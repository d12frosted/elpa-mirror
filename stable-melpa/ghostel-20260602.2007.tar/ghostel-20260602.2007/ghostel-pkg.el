;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260602.2007"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "4443fc95fdb8b20d6413c0a7cf78a3de74617043"
  :revdesc "4443fc95fdb8"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
