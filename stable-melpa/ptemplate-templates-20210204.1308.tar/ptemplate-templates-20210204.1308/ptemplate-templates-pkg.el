(define-package "ptemplate-templates" "20210204.1308" "Official templates"
  '((emacs "25.1")
    (ptemplate "2.0.0"))
  :commit "66bcd5d16289809ac771a7f25bd62b6eaa1ab022" :authors
  '(("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainer
  '("Nikita Bloshchanevich" . "nikblos@outlook.com")
  :url "https://github.com/nbfalcon/ptemplate-templates")
;; Local Variables:
;; no-byte-compile: t
;; End:
