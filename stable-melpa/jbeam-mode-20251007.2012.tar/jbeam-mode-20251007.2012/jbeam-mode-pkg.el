;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jbeam-mode" "20251007.2012"
  "Major mode for JBeam files."
  '((emacs "24.3"))
  :url "https://github.com/webdevred/jbeam-mode"
  :commit "0c5fe9737575d046b79254e959c6b76489ad5ce7"
  :revdesc "0c5fe9737575"
  :keywords '("languages"))
