;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260412.919"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "17264f7edc72046524f9f846038537b658cfe100"
  :revdesc "17264f7edc72"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
