;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-journal" "20260730.1852"
  "Daily note interface for vulpea."
  '((emacs     "29.1")
    (vulpea    "2.5.0")
    (vulpea-ui "1.1.0")
    (vui       "1.3.0")
    (dash      "2.20.0"))
  :url "https://github.com/d12frosted/vulpea-journal"
  :commit "48bdabab3bf61abe4c854128759f5e789d46b98e"
  :revdesc "48bdabab3bf6"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
