;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruby-extra-highlight" "20250103.1518"
  "Highlight Ruby parameters."
  ()
  :url "https://github.com/Lindydancer/ruby-extra-highlight"
  :commit "d1f6d41e5c2fc4cc7a23f4e79fa3710fdc74ec61"
  :revdesc "d1f6d41e5c2f"
  :keywords '("languages" "faces"))
