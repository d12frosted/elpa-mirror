;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250625.2118"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "cdf27ce064cb77e124a8a0ef1222bf4f935217e9"
  :revdesc "cdf27ce064cb"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
