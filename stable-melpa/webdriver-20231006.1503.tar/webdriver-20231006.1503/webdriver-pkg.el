(define-package "webdriver" "20231006.1503" "WebDriver local end implementation"
  '((emacs "27.1"))
  :commit "7b2e1b4f62d5667a239ebd5534fcdeaef1deebf9" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/mauroaranda/emacs-webdriver")
;; Local Variables:
;; no-byte-compile: t
;; End:
