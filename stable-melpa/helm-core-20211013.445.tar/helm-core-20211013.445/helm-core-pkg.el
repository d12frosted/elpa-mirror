(define-package "helm-core" "20211013.445" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "fddbef6ebcd1e63edf3db1646edd5083790f11f9")
;; Local Variables:
;; no-byte-compile: t
;; End:
