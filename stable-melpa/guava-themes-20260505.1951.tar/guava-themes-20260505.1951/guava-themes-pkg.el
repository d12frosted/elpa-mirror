;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260505.1951"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "136f796216aa9f2c5b0e3fdd03166efc812fb5f2"
  :revdesc "136f796216aa"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
