;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260817.551"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "736c3a84ab2386b1e3e2985ccb8b4ab24a9281f7"
  :revdesc "736c3a84ab23"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
