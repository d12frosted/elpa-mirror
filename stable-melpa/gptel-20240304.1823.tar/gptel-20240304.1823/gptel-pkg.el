(define-package "gptel" "20240304.1823" "Interact with ChatGPT or other LLMs"
  '((emacs "27.1")
    (transient "0.4.0")
    (compat "29.1.4.1"))
  :commit "aa8bc91c6790e902eacdc80a50cab2679e063ccf" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
