(define-package "org-link-beautify" "20230304.1214" "Beautify Org Links"
  '((emacs "28.1")
    (all-the-icons "5.0.0"))
  :commit "8e0e45bf5bb06996895e99a223ee038fa9da5bf9" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
