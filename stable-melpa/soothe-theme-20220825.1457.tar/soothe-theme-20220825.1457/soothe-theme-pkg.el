(define-package "soothe-theme" "20220825.1457" "A dark colorful theme"
  '((emacs "24.3")
    (autothemer "0.2"))
  :commit "502bf30af4c42d4223635730201b5bc1e52afec4" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/emacs-soothe-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
