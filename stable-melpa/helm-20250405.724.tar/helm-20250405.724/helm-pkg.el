;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250405.724"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.2")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "c5f055826a9d711a97a73096a9585a5fbd6c7b16"
  :revdesc "c5f055826a9d"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
