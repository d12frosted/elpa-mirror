;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260905.705"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "ba8aafb8b4379b00841cb6ce3094f95bbc9d10ba"
  :revdesc "ba8aafb8b437"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
