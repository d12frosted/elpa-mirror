;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250625.1859"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "fa3506a480ba0bca3febd7f41246c6f1253913a1"
  :revdesc "fa3506a480ba"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
