;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260121.1419"
  "Emacs frontend for pi coding agent."
  '((emacs         "28.1")
    (markdown-mode "2.6"))
  :url "https://github.com/dnouri/pi.el"
  :commit "9c07eba23864a49efff5e2b3a65680aae162122a"
  :revdesc "9c07eba23864"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
