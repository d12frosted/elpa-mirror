(define-package "wat-ts-mode" "20230923.349" "Major mode for webassembly text format"
  '((emacs "29.1"))
  :commit "1cb99e67fd0cc83fd56e5eaddf9835257beba154" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("wasm" "wat" "wast" "languages" "tree-sitter")
  :url "https://github.com/nverno/wat-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
