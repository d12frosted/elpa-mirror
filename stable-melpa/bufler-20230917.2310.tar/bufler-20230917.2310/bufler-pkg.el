(define-package "bufler" "20230917.2310" "Group buffers into workspaces with programmable rules"
  '((emacs "26.3")
    (burly "0.4pre")
    (dash "2.18")
    (f "0.17")
    (pretty-hydra "0.2.2")
    (magit-section "0.1")
    (map "2.1"))
  :commit "171e5899e9e00f40625079fe3161af969dfaa768" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/bufler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
