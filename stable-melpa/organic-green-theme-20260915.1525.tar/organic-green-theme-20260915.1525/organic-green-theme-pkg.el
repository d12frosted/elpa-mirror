;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "organic-green-theme" "20260915.1525"
  "Light green color theme."
  '((emacs "24.1"))
  :url "https://github.com/kostafey/organic-green-theme"
  :commit "654a4b6a3716d165d39398225048a83d3a3a3ccd"
  :revdesc "654a4b6a3716"
  :keywords '("faces")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
