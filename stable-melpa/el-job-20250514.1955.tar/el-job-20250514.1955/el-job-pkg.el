;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250514.1955"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "3b349c1ca09279016372f137cd7293387f31fdd5"
  :revdesc "3b349c1ca092"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
