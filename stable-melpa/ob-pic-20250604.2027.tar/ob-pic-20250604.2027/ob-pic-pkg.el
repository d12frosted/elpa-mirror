;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-pic" "20250604.2027"
  "Org babel functions for pic language -*- lexical-binding: t;."
  '((emacs "24.1"))
  :url "https://github.com/ddoherty03/ob-pic"
  :commit "e60eab82e8fa70ebb288350166baff56ec8f1342"
  :revdesc "e60eab82e8fa"
  :keywords '("org" "babel" "pic" "tools")
  :authors '(("Daniel E. Doherty" . "ded-obpic@ddoherty.net"))
  :maintainers '(("Daniel E. Doherty" . "ded-obpic@ddoherty.net")))
