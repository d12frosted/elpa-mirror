(define-package "eldev" "20211113.1804" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "70aa39c6c6ed696b7f1505c1c9bf4b2556179a27" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
