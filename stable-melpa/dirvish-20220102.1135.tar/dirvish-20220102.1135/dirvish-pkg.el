(define-package "dirvish" "20220102.1135" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "8234d3dd59ba3f6f629f18090ce2d308a2bb1d7e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
