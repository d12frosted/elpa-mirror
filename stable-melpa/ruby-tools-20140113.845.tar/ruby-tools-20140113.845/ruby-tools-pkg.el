(define-package "ruby-tools" "20140113.845" "Collection of handy functions for ruby-mode." 'nil :commit "6e7fb376085bfa7010ecd3dfad63adacc6e2b4ac" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("speed" "convenience" "ruby")
  :url "http://github.com/rejeep/ruby-tools")
;; Local Variables:
;; no-byte-compile: t
;; End:
