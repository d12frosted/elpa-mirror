(define-package "modus-themes" "20211225.1838" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "ed918981a088255de76aca48ed34e7e7057a9dbe" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
