(define-package "lister" "20211017.1656" "Yet another list printer"
  '((emacs "26.1"))
  :commit "3a3e3ad1cc1e66445ab55349f2948f1706166d2d" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
