(define-package "spdx" "20220923.205" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "cb733ffbb621c0c3eb3a7ab349c33df41dbcce72" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
