(define-package "neut-mode" "20240407.2322" "A major mode for Neut"
  '((emacs "29"))
  :commit "fac0d1bbd3763eb7509249c34d5798f73d59d715" :authors
  '(("vekatze" . "vekatze@icloud.com"))
  :maintainers
  '(("vekatze" . "vekatze@icloud.com"))
  :maintainer
  '("vekatze" . "vekatze@icloud.com")
  :url "https://github.com/vekatze/neut-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
