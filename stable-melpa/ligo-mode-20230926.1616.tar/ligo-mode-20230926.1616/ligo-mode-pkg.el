(define-package "ligo-mode" "20230926.1616" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "8a854e90b8d197f075fa63d8f1ff4800e3901d52" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
