(define-package "org-jira" "20210622.130" "Syncing between Jira and Org-mode."
  '((emacs "24.5")
    (cl-lib "0.5")
    (request "0.2.0")
    (dash "2.14.1"))
  :commit "79aac66201e5fa1977f60fa432d2a71b1b37209e" :maintainer
  '("Matthew Carter" . "m@ahungry.com")
  :keywords
  '("ahungry" "jira" "org" "bug" "tracker")
  :url "https://github.com/ahungry/org-jira")
;; Local Variables:
;; no-byte-compile: t
;; End:
