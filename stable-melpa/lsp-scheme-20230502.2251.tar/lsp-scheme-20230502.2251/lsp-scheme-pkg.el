(define-package "lsp-scheme" "20230502.2251" "Scheme support for lsp-mode"
  '((emacs "26.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "2da775930450dd3d1038e62f1ebec0cdbc2f2e3c" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainers
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
