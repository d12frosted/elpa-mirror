;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cilk-mode" "20220807.1629"
  "Minor mode for Cilk code editing."
  '((emacs    "25.1")
    (flycheck "32-cvs"))
  :url "https://github.com/ailiop/cilk-mode"
  :commit "d5ba732a5a313a97a96085943cd7840b8e2d9c7c"
  :revdesc "d5ba732a5a31"
  :keywords '("c" "convenience" "faces" "languages")
  :authors '(("Alexandros-Stavros Iliopoulos" . "https://github.com/ailiop"))
  :maintainers '(("Alexandros-Stavros Iliopoulos" . "1577182+ailiop@users.noreply.github.com")))
