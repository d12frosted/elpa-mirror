(define-package "mybigword" "20220715.615" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "25.1"))
  :commit "6c35dd44369930b039a37f6174617bb6ab93be27" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
