(define-package "mybigword" "20220715.615" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "25.1"))
  :commit "de4c0e694ed3e8fcebb1854b5d3fc3f0d98b0767" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
