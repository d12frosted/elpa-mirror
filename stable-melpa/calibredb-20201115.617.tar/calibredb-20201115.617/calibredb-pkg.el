(define-package "calibredb" "20201115.617" "Yet another calibre client"
  '((emacs "25.1")
    (transient "0.1.0")
    (s "1.12.0")
    (dash "2.17.0"))
  :commit "3f4ed7868bed75f633a8bc86909251a7b070dd55" :keywords
  ("tools")
  :authors
  (("Damon Chan" . "elecming@gmail.com"))
  :maintainer
  ("Damon Chan" . "elecming@gmail.com")
  :url "https://github.com/chenyanming/calibredb.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
