(define-package "wordreference" "20230913.1045" "Interface for wordreference.com"
  '((emacs "28.1"))
  :commit "66e0e426b3696b4dec52b240cc15b828ed040b02" :authors
  '(("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainers
  '(("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainer
  '("Marty Hiatt <martianhiatus AT riseup.net>")
  :keywords
  '("convenience" "translate" "wp" "dictionary")
  :url "https://codeberg.org/martianh/wordreference.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
