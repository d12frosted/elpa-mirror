;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20241118.544"
  "Compile Emacs Lisp libraries automatically."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "4a9b5ee630855807afa85375234de93fd2af1a88"
  :revdesc "4a9b5ee63085"
  :keywords '("convenience"))
