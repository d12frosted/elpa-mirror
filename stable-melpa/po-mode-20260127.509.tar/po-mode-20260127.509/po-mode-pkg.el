;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "po-mode" "20260127.509"
  "Major mode for GNU gettext PO files."
  '((emacs "23"))
  :url "https://github.com/emacsmirror/po-mode"
  :commit "24d793df3cffd2fa7636be6f00c2f283577655d4"
  :revdesc "24d793df3cff"
  :keywords '("i18n" "gettext"))
