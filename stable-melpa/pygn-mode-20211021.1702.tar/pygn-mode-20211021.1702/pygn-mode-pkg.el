(define-package "pygn-mode" "20211021.1702" "Major-mode for chess PGN files, powered by Python"
  '((emacs "26.1")
    (tree-sitter "0.15.2")
    (tree-sitter-langs "0.10.7")
    (uci-mode "0.5.4")
    (nav-flash "1.0.0")
    (ivy "0.10.0"))
  :commit "d336b9dfb6ee602a18050dbdf14868c61e30a837" :authors
  '(("Dodge Coates and Roland Walker"))
  :maintainer
  '("Dodge Coates and Roland Walker")
  :keywords
  '("data" "games" "chess")
  :url "https://github.com/dwcoates/pygn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
