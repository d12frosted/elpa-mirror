;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-hatena-bookmark" "20250421.746"
  "Consult commands for the Hatena Bookmark."
  '((emacs   "27.1")
    (consult "2.0"))
  :url "https://github.com/Nyoho/consult-hatena-bookmark"
  :commit "84fed59694ce6535ed0879fc2211e68a3309d1af"
  :revdesc "84fed59694ce")
