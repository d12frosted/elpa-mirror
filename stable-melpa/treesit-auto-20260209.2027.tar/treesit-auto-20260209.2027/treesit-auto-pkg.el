;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "treesit-auto" "20260209.2027"
  "Automatically use tree-sitter enhanced major modes."
  '((emacs "29.0"))
  :url "https://github.com/renzmann/treesit-auto.git"
  :commit "433dac791c3a5c6f2aebddc70066f72940a12489"
  :revdesc "433dac791c3a"
  :keywords '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :authors '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers '(("Robb Enzmann" . "robbenzmann@gmail.com")))
