;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fastbuild-bff-mode" "20260411.905"
  "Major mode for FASTBuild BFF files."
  '((emacs "26.1"))
  :url "https://github.com/cyberkm/fastbuild-bff-mode"
  :commit "fa3ea52a7542b3110d0320ba4c48ed5cbfde100b"
  :revdesc "fa3ea52a7542"
  :keywords '("languages" "tools" "build")
  :authors '(("Pavel Bibergal" . "cyberkm@gmail.com"))
  :maintainers '(("Pavel Bibergal" . "cyberkm@gmail.com")))
