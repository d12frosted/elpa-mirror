(define-package "hl-indent-scope" "20221227.2353" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "32cc5e185515bf3cb746a61ee266a5184886527c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
