(define-package "modus-themes" "20211231.239" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "2b47e0c1e5546e934a7afd4b9d09af72c25e2f15" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
