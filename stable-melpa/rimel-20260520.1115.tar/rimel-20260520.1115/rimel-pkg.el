;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260520.1115"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "67cffc0d2870121d592ef287bb181a4c95cba505"
  :revdesc "67cffc0d2870"
  :keywords '("convenience" "chinese" "input-method" "rime"))
