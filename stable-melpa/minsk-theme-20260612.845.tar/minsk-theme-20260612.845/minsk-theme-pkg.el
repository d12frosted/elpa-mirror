;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minsk-theme" "20260612.845"
  "Minsk, a theme in deep muted greens."
  '((emacs "24"))
  :url "https://codeberg.org/loj/minsk-theme"
  :commit "7d1259165a1b7eaecc97d76fc288fa56f8736bef"
  :revdesc "7d1259165a1b"
  :keywords '("theme" "faces")
  :authors '(("June Lo" . "loh.ka.tsun@gmail.com"))
  :maintainers '(("June Lo" . "loh.ka.tsun@gmail.com")))
