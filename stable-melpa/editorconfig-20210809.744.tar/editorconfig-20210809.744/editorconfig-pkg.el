(define-package "editorconfig" "20210809.744" "EditorConfig Emacs Plugin"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (emacs "24"))
  :commit "1677c88f9062fe8084afd24be9c520be57cc192c" :authors
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainer
  '("EditorConfig Team" . "editorconfig@googlegroups.com")
  :url "https://github.com/editorconfig/editorconfig-emacs#readme")
;; Local Variables:
;; no-byte-compile: t
;; End:
