;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260125.1200"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "19c9c958dd530a1ba606fc1074a28523af40ec28"
  :revdesc "19c9c958dd53"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
