(define-package "selectrum" "20210222.1734" "Easily select item from list"
  '((emacs "25.1"))
  :commit "e7341f0995fd5fbd8b74c1025393afc9dc61c729" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
