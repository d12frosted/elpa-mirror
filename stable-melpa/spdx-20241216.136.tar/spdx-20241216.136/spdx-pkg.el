;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20241216.136"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "f5a46c7f446a2357060bbdd74f3a414e5701406b"
  :revdesc "f5a46c7f446a"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
