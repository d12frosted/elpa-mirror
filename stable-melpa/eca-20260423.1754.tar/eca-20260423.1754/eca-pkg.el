;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260423.1754"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "bd5a72aef67eca944a7ad0d9916eb0d0f0f11f9d"
  :revdesc "bd5a72aef67e"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
