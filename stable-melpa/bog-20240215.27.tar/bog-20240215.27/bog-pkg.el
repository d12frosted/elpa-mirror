;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bog" "20240215.27"
  "Extensions for research notes in Org mode."
  '((cl-lib "0.5"))
  :url "https://github.com/kyleam/bog"
  :commit "c8e7c8cb54b1787cc3d9383f0514eb76cadd4002"
  :revdesc "c8e7c8cb54b1"
  :keywords '("bib" "outlines")
  :authors '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainers '(("Kyle Meyer" . "kyle@kyleam.com")))
