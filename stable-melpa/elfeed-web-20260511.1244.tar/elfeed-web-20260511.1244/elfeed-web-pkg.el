;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-web" "20260511.1244"
  "Web interface to Elfeed."
  '((emacs        "28.1")
    (compat       "31")
    (elfeed       "3.4.2")
    (simple-httpd "1.5.1"))
  :url "https://github.com/emacs-elfeed/elfeed-web"
  :commit "b2693e6d310ced341566690843fe88ce7e6c26f4"
  :revdesc "b2693e6d310c"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
