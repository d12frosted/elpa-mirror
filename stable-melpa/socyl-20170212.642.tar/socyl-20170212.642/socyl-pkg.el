;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "socyl" "20170212.642"
  "Frontend for several search tools."
  '((s        "1.11.0")
    (dash     "2.12.0")
    (pkg-info "0.5.0")
    (cl-lib   "0.5"))
  :url "https://github.com/nlamirault/socyl"
  :commit "1ef2da42f66f3ab31a34131e51648f352416f0ba"
  :revdesc "1ef2da42f66f"
  :keywords '("ripgrep" "sift" "ack" "pt" "ag" "grep" "search")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
