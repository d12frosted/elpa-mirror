(define-package "apheleia" "20231126.1049" "Reformat buffer stably"
  '((emacs "27"))
  :commit "01ca22bcd7264fb4ec64397e049db8b52db4f0fc" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
