(define-package "modus-themes" "20220316.1159" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "87508b4c21343cac910040705fe14f84d2c70d70" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
