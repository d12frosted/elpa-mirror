(define-package "wildcharm-light-theme" "20231126.224" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "bcb68a77e410d2478e8ec1951077cb1ffdfa6d35" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
