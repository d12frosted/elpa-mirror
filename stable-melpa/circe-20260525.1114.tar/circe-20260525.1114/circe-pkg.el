;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "circe" "20260525.1114"
  "Client for IRC in Emacs."
  '((emacs  "25.1")
    (cl-lib "0.5"))
  :url "https://github.com/emacs-circe/circe"
  :commit "4bd1e964066fe8985d8112ed9172db3a1ecf58c8"
  :revdesc "4bd1e964066f"
  :keywords '("irc" "chat" "comm")
  :authors '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainers '(("Jorgen Schaefer" . "forcer@forcix.cx")))
