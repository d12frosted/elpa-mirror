;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20260805.1304"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "a3658f63d85b1558a9dbdec45f33eed8f0d56041"
  :revdesc "a3658f63d85b"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
