;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260605.255"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "8b8ec08997c6918c1d762ed2aeaa0a38871cb2ab"
  :revdesc "8b8ec08997c6"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
