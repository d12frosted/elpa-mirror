(define-package "netease-cloud-music" "20220211.1326" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "0738c875045072c277c85882330778fadd3d29f7" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
