;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "20251216.146"
  "Display diff's using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "3671e0508aaa6d7a86cb22aad71892399b56f22d"
  :revdesc "3671e0508aaa"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
