;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-visualstar" "20260926.1446"
  "Starts a * or # search from the visual selection."
  '((emacs "24.4")
    (evil  "0"))
  :url "https://github.com/bling/evil-visualstar"
  :commit "e9f043361c4fd0ab6b7e7a52801c39f05c1e52c3"
  :revdesc "e9f043361c4f"
  :keywords '("evil" "vim" "visualstar"))
