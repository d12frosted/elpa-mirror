;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260820.1501"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3e16991109f716afca249551651045cc799a6d64"
  :revdesc "3e16991109f7"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
