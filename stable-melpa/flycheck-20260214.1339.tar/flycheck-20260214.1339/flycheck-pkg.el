;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260214.1339"
  "On-the-fly syntax checking."
  '((emacs "27.1")
    (seq   "2.24"))
  :url "https://www.flycheck.org"
  :commit "0393305b8e2bb212473325271c6dba3eadbdf031"
  :revdesc "0393305b8e2b"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
