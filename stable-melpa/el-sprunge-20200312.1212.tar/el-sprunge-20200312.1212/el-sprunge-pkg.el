(define-package "el-sprunge" "20200312.1212" "Command line paste server with Emacs highlighting"
  '((web-server "20140105.2246")
    (htmlize "20130207.1202")
    (emacs "24.3"))
  :commit "e4365ea0bdf60969817619376bdcc98003fec33d")
;; Local Variables:
;; no-byte-compile: t
;; End:
