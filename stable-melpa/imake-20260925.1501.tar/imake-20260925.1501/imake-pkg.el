;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imake" "20260925.1501"
  "Simple, opinionated make target runner."
  '((emacs      "28.1")
    (compat     "31.0")
    (marginalia "2.12"))
  :url "https://github.com/tarsius/imake"
  :commit "2c795535ce577b09f8e0dac8da627a5230339586"
  :revdesc "2c795535ce57"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev")))
