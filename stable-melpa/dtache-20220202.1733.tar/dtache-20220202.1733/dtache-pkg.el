(define-package "dtache" "20220202.1733" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "ecf4c57d96eda400d9b2d5cfeaa9244993ae3603" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
