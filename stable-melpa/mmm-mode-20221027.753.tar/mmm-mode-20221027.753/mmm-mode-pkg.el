(define-package "mmm-mode" "20221027.753" "Allow Multiple Major Modes in a buffer"
  '((emacs "25.1")
    (cl-lib "0.2"))
  :commit "328b6a9c677e6f32f4a7729d122b77d3fb3ce04c" :authors
  '(("Michael Abraham Shulman" . "viritrilbia@gmail.com"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("convenience" "faces" "languages" "tools")
  :url "https://github.com/purcell/mmm-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
