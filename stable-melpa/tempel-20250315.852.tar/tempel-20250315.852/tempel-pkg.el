;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20250315.852"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "36841d2795e79fedc945c856c3c4d1368fdc1a88"
  :revdesc "36841d2795e7"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
