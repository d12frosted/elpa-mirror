;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-async" "20200105.1031"
  "Async support for ERT."
  '((emacs "24.1"))
  :url "https://github.com/rejeep/ert-async.el"
  :commit "948cf2faa10e085bda3739034ca5ea1912893433"
  :revdesc "948cf2faa10e"
  :keywords '("lisp" "test")
  :authors '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
