;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtual-ring" "20250915.2206"
  "Fixed size rings with virtual rotation."
  '((emacs "25.1"))
  :url "https://github.com/countvajhula/virtual-ring"
  :commit "66fd68b9c57c09f057f6607341024899c2520e90"
  :revdesc "66fd68b9c57c"
  :authors '(("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
