;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-todo" "20250123.1632"
  "Search hl-todo keywords in consult."
  '((emacs   "29.1")
    (consult "1.9")
    (hl-todo "3.8.2"))
  :url "https://github.com/liuyinz/consult-todo"
  :commit "af8016ff26a8ccd5b07fcf6896a95fa28fcfca8b"
  :revdesc "af8016ff26a8"
  :authors '(("liuyinz" . "liuyinz@gmail.com"))
  :maintainers '(("liuyinz" . "liuyinz@gmail.com")))
