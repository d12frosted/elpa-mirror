(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "4ebe87b25477dafe07a71278692748d312b4f37c" :authors
  (("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  ("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
