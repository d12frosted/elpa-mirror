(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "005b650d4e5b812e0655ebb4f0e714d046762d64" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
