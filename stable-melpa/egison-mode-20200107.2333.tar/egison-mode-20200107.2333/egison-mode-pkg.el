(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "6a83f224a3cbe2d97c1641d49e443c503e54ddb6" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
