(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "b5398dd4b59e08b3035aa8c9103b48d5f3174e1e" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
