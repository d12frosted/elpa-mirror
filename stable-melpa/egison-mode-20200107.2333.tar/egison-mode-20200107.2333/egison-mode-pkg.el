(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "8cf07b2d52aa9a916e8b64f2572b6aa8a4a8c3bd" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
