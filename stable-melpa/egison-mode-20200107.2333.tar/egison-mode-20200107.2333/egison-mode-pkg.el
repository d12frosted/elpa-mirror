(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "54fc2af0efdbb9e000667749bcfc9fda659304cf" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
