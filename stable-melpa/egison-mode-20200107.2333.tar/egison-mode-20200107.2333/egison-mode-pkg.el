(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "a874f97af30b59daefaf08e1b4b6846b2214d1a5" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
