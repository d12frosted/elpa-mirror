(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "6432f79a90baf2bdb3223c12e5a5660b1fe1a0d2" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
