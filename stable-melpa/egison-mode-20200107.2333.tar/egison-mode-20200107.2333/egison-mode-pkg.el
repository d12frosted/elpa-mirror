(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "bfcd0b0fa382a75d78cbc015486e115d2938fb31" :authors
  (("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  ("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
