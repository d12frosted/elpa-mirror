(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "1ef241fcc73b108565f63202f412c25cca74f5d7" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
