(define-package "egison-mode" "20200107.2333" "Egison editing mode" 'nil :commit "d5d587872288bf6c141c3297d17e6c61d9d9e0a7" :authors
  '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainer
  '("Satoshi Egi" . "egisatoshi@gmail.com")
  :url "https://github.com/egisatoshi/egison3/blob/master/elisp/egison-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
