;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251030.755"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "9dcee1a1787deaed5208d82f5426e2fdbf998fe8"
  :revdesc "9dcee1a1787d"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
