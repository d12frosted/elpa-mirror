;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kill-dollar-mode" "20241217.1947"
  "Remove leading $ from shell-script-like text."
  '((emacs "27.1"))
  :url "https://github.com/sandinmyjoints/kill-dollar-mode"
  :commit "e51c076f93605c5a651b549731ccfc85a2564aca"
  :revdesc "e51c076f9360"
  :keywords '("convenience" "tools"))
