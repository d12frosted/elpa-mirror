(define-package "x509-mode" "20220903.718" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "ce1bce34eaf2c8c21ac294195e92a6475ead714e" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
