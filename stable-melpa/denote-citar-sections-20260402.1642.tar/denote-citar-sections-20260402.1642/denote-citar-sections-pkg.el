;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-citar-sections" "20260402.1642"
  "Universal Sidecar sections for citar-denote."
  '((emacs             "26.1")
    (denote            "2.2.4")
    (universal-sidecar "1.5.0")
    (citar-denote      "2.2.2")
    (citar             "1.4"))
  :url "https://git.sr.ht/~swflint/denote-sections"
  :commit "c76659de2dd13f6e6f7358f96db6d2e067a42fbc"
  :revdesc "c76659de2dd1"
  :keywords '("convenience" "files" "hypermedia" "notes")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
