;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ssh-config-mode" "20260108.2149"
  "Mode for fontification of ~/.ssh/config."
  '((emacs "24.3"))
  :url "https://github.com/peterhoeg/ssh-config-mode-el"
  :commit "f21726d6f44a0e769a15f0a94620078a326774f7"
  :revdesc "f21726d6f44a"
  :keywords '("comm" "files")
  :authors '(("Harley Gorrell" . "harley@panix.com"))
  :maintainers '(("Peter Hoeg" . "peter@hoeg.com")))
