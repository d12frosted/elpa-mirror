(define-package "notmuch" "20210804.155" "run notmuch within emacs" 'nil :commit "c1f542d68ae843eedc2f5686203aa41dbb6a38e7" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
