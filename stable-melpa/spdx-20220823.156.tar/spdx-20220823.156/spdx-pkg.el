(define-package "spdx" "20220823.156" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "e1735648bbfadd9e888fcd7c760ab9fb636cbd03" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
