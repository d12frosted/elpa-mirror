;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-insert-plus" "20260124.1640"
  "Use insert and append as evil operators."
  '((emacs "24.4")
    (evil  "1.14.0"))
  :url "https://github.com/yad-tahir/evil-insert-plus"
  :commit "c238f682f6103b282c71c264f5e41b381289b837"
  :revdesc "c238f682f610"
  :keywords '("emulations" "textvim" "editing")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
