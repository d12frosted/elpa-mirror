;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241202.1042"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "4147b3fff9b2b2003fc3f9cef7f653a730b44ac7"
  :revdesc "4147b3fff9b2"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
