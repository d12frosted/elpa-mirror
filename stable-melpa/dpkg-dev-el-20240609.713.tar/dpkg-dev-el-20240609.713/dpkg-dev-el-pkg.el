(define-package "dpkg-dev-el" "20240609.713" "startup file for the elpa-dpkg-dev-el package"
  '((emacs "27.1")
    (debian-el "37.0"))
  :commit "28df6a839dad6b7e4105e5fde8459374a6bb9a03" :authors
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainer
  '("Peter S Galbraith" . "psg@debian.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
