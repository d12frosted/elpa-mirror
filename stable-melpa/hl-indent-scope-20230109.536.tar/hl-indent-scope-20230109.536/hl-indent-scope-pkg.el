(define-package "hl-indent-scope" "20230109.536" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "eae3da9de91b4e72b862cae3cef0d6c65b6c6f27" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
