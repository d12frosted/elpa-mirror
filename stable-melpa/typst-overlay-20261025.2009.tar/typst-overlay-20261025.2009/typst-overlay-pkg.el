;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typst-overlay" "20261025.2009"
  "Overlay Typst equations."
  '((emacs "29.1"))
  :url "https://github.com/hesampakdaman/typst-overlay"
  :commit "efa1824c23f8a79a525a5a6763b3d92f32ef17a4"
  :revdesc "efa1824c23f8"
  :keywords '("tools")
  :authors '(("Hesam Pakdaman" . "https://github.com/hesampakdaman"))
  :maintainers '(("Hesam Pakdaman" . "https://github.com/hesampakdaman")))
