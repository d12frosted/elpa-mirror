(define-package "kotlin-ts-mode" "20231110.1334" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "b9ccc4896c8af8e8b60a26eb16fffe8a185551d0" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
