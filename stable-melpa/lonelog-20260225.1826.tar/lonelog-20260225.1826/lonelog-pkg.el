;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lonelog" "20260225.1826"
  "Solo RPG notation support."
  '((emacs "27.1"))
  :url "https://github.com/enfors/lonelog"
  :commit "0b013df2611d13f88e59a5d3007677d2e34d7b5e"
  :revdesc "0b013df2611d"
  :keywords '("games" "convenience" "wp")
  :authors '(("Christer Enfors" . "christer.enfors@gmail.com"))
  :maintainers '(("Christer Enfors" . "christer.enfors@gmail.com")))
