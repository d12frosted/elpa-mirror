;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260511.1621"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (closql   "2.4")
    (emacsql  "4.3")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "7c3fa8bb6b29d931410d876a96dfd6f4aa6928e0"
  :revdesc "7c3fa8bb6b29"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
