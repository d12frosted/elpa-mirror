(define-package "file-info" "20230822.1634" "Show pretty information about current file"
  '((emacs "28.1")
    (hydra "0.15.0")
    (browse-at-remote "0.15.0"))
  :commit "5dcf0df5be52a264690e81d9911306879371e4d9" :authors
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainer
  '("Artur Yaroshenko" . "artawower@protonmail.com")
  :url "https://github.com/artawower/file-info.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
