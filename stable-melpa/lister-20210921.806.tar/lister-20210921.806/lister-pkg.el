(define-package "lister" "20210921.806" "Yet another list printer"
  '((emacs "26.1"))
  :commit "1228f43dfcca58363b500dc6527bf5d5d584bd3c" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
