;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ext" "20260915.1814"
  "VHDL Extensions."
  '((emacs        "29.1")
    (vhdl-ts-mode "0.3.3")
    (lsp-mode     "8.0.0")
    (rg           "2.3.0")
    (hydra        "0.15.0")
    (flycheck     "32")
    (async        "1.9.7"))
  :url "https://github.com/gmlarumbe/vhdl-ext"
  :commit "cf36dd1a1001e53af02e74f487a85194d6ba87ab"
  :revdesc "cf36dd1a1001"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
