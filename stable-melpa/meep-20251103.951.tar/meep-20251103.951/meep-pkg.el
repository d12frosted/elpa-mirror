;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251103.951"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "0ecb8e5daf8b507f5566fcf064e562586e887c08"
  :revdesc "0ecb8e5daf8b"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
