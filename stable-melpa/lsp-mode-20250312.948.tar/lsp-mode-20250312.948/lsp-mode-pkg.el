;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20250312.948"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "c4ec868242be17885597585962b9d562a698f1a7"
  :revdesc "c4ec868242be"
  :keywords '("languages"))
