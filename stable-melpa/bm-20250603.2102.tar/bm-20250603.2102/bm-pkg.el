;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bm" "20250603.2102"
  "Visible bookmarks in buffer."
  ()
  :url "https://github.com/joodland/bm"
  :commit "bb572a8fc90140d9c6012bcc11487dcc1f0861d7"
  :revdesc "bb572a8fc901"
  :keywords '("bookmark" "highlight" "faces" "persistent")
  :authors '(("Jo Odland" . "jo.odlandgmail.com"))
  :maintainers '(("Jo Odland" . "jo.odlandgmail.com")))
