;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260523.656"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "19c516c061868e1d883a46b682422a10949bf150"
  :revdesc "19c516c06186"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
