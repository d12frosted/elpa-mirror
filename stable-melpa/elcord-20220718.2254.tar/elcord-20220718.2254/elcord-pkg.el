(define-package "elcord" "20220718.2254" "Allows you to integrate Rich Presence from Discord"
  '((emacs "25.1"))
  :commit "f821107fdd82b67878be527323f2fa830e5375c0" :authors
  '(("heatingdevice")
    ("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com"))
  :maintainer
  '("heatingdevice")
  :keywords
  '("games")
  :url "https://github.com/Mstrodl/elcord")
;; Local Variables:
;; no-byte-compile: t
;; End:
