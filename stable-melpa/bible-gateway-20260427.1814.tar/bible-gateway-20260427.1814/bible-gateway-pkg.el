;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260427.1814"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "3eec026d3dbb24eba4d8f68f8486907be81f9a43"
  :revdesc "3eec026d3dbb"
  :keywords '("convenience" "comm" "hypermedia"))
