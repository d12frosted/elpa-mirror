(define-package "ros" "20230618.1116" "Package to write code for ROS systems"
  '((emacs "27.1")
    (s "0")
    (with-shell-interpreter "0")
    (kv "0")
    (cl-lib "0")
    (transient "0")
    (hydra "0")
    (grep "0")
    (string-inflection "0")
    (docker-tramp "0"))
  :commit "2776746295d7b0c12c18d4b95e0b8705287666a0" :authors
  '(("Max Beutelspacher <https://github.com/mtb>"))
  :maintainers
  '(("Max Beutelspacher" . "max@beutelspacher.eu"))
  :maintainer
  '("Max Beutelspacher" . "max@beutelspacher.eu")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/DerBeutlin/ros.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
