(define-package "gerrit" "20211210.1616" "Gerrit client"
  '((emacs "25.1")
    (hydra "0.15.0")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "b2e4ef23c2dd66d10526b58defcaea7beac7442f" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
