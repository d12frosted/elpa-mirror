(define-package "soothe-theme" "20220908.403" "A dark colorful theme"
  '((emacs "24.3")
    (autothemer "0.2"))
  :commit "548e8118f94dc7dc8b2085ec0e91c1f76f4167b9" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/emacs-soothe-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
