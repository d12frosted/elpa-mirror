(define-package "immaterial-theme" "20201202.1801" "A flexible theme based on material design principles"
  '((emacs "25"))
  :commit "d965b9b29e1ade16aa92b934ac888616409a95c5" :keywords
  ("themes")
  :authors
  (("Peter Gardfjäll"))
  :maintainer
  ("Peter Gardfjäll")
  :url "https://github.com/petergardfjall/emacs-immaterial-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
