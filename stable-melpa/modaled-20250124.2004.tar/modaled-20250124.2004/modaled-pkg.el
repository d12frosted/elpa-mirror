;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modaled" "20250124.2004"
  "Build your own minor modes for modal editing."
  '((emacs "25.1"))
  :url "https://github.com/DCsunset/modaled"
  :commit "d9ec83a00317ae7ed69a5d7b427c968495761e5c"
  :revdesc "d9ec83a00317"
  :keywords '("convenience" "modal-editing"))
