(define-package "burly" "20230831.558" "Save and restore frame/window configurations with buffers"
  '((emacs "27.1")
    (map "2.1"))
  :commit "3397eb2599bf76de1b96563e5a9201550e33a810" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
