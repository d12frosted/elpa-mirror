;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atom-one-dark-theme" "20260821.342"
  "Atom One Dark color theme."
  ()
  :url "https://github.com/jonathanchu/atom-one-dark-theme"
  :commit "7f2ea3d9cc09d41e96e239b6b1586a346e2418ef"
  :revdesc "7f2ea3d9cc09"
  :keywords '("faces")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
