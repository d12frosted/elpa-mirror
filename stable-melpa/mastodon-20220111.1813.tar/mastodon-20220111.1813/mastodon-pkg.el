(define-package "mastodon" "20220111.1813" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.2")
    (seq "1.0"))
  :commit "ef10fe596e394dac16d23df893d91e7d68989ffc" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://git.blast.noho.st/mouse/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
