(define-package "tok-theme" "20211216.2059" "My theme"
  '((emacs "24.3"))
  :commit "bbfc72238bb26f72dd79345647d86aa082acf8f2" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
