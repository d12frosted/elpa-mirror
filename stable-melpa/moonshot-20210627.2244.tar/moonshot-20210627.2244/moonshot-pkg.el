;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moonshot" "20210627.2244"
  "Run executable file, debug and build commands on project."
  '((emacs       "25.1")
    (cl-lib      "0.5")
    (f           "0.18")
    (s           "1.11.0")
    (projectile  "2.0.0")
    (counsel     "0.11.0")
    (realgud     "1.5.1")
    (seq         "2.20")
    (levenshtein "1.0"))
  :url "https://github.com/ageldama/moonshot"
  :commit "ec37a12825888047a90d9ee8131aa4bea348edf7"
  :revdesc "ec37a1282588"
  :keywords '("convenience" "files" "processes" "tools" "unix")
  :authors '(("Jong-Hyouk Yun" . "ageldama@gmail.com"))
  :maintainers '(("Jong-Hyouk Yun" . "ageldama@gmail.com")))
