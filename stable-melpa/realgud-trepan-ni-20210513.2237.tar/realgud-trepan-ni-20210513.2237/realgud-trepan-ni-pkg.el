(define-package "realgud-trepan-ni" "20210513.2237" "Realgud front-end to trepan-ni"
  '((load-relative "1.2")
    (realgud "1.5.0")
    (emacs "25"))
  :commit "0ec088ea343835e24ae73da09bea96bfb02a3130" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :url "https://github.com/realgud/realgud-trepan-ni")
;; Local Variables:
;; no-byte-compile: t
;; End:
