(define-package "helm" "20240908.306" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "4.0")
    (wfnames "1.2"))
  :commit "87db6ba09505d18e5c611041d03ae9f0d897e283" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
