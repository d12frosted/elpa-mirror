(define-package "eldev" "20210213.1731" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "fd065e68b332c78f9b65046ec1466748b8d31841" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
