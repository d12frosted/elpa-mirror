(define-package "mentor" "20211023.431" "Frontend for the rTorrent bittorrent client"
  '((emacs "25.1")
    (xml-rpc "1.6.15")
    (seq "1.11")
    (cl-lib "0.5")
    (async "1.9.3"))
  :commit "b68c47b3d898a441da2278e2e0636197397d755e" :authors
  '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainer
  '("Stefan Kangas" . "stefankangas@gmail.com")
  :keywords
  '("comm" "processes" "bittorrent"))
;; Local Variables:
;; no-byte-compile: t
;; End:
