;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261109.1633"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "b5865e39b58386f7fb4cf2f9897c640ac8e25431"
  :revdesc "b5865e39b583"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
