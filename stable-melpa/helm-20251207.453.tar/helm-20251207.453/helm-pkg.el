;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251207.453"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "724c2cc586fc5a40893edf64c1a79a3189ecb941"
  :revdesc "724c2cc586fc"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
