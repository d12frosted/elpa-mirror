;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mastodon" "20260228.2030"
  "Client for fediverse services using the Mastodon API."
  '((emacs   "29.1")
    (persist "0.8")
    (tp      "0.8"))
  :url "https://codeberg.org/martianh/mastodon.el"
  :commit "23a4c2227faa7892bd360721cfc8035a0543af7d"
  :revdesc "23a4c2227faa"
  :authors '(("Johnson Denen" . "johnson.denen@gmail.com")
             ("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
