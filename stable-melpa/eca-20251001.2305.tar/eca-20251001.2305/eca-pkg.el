;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251001.2305"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "c1deabc520240fd07005934d24c1f9c6016d5aa1"
  :revdesc "c1deabc52024"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
