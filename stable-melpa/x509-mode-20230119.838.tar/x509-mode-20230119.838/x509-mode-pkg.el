(define-package "x509-mode" "20230119.838" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "0118ac433f5aa0c4a7ea51709ba9da51388d644d" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
