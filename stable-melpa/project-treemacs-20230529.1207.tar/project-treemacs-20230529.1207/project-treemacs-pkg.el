;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-treemacs" "20230529.1207"
  "Simple treemacs backend for project.el."
  '((emacs    "28.1")
    (treemacs "3.1"))
  :url "https://github.com/cmccloud/project-treemacs"
  :commit "36bec1109ba0498c2d1ef29756c841d2e23b063e"
  :revdesc "36bec1109ba0")
