;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "20261123.2029"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "002a58170ee03b1adde695fb07d345ce12a5bcf4"
  :revdesc "002a58170ee0")
