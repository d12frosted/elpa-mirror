;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abc-mode" "20220713.1359"
  "Major mode for editing abc music files."
  ()
  :url "https://github.com/mkjunker/abc-mode"
  :commit "45193b67508861cf77da7e76b71711855c002caa"
  :revdesc "45193b675088"
  :keywords '("local" "docs")
  :authors '(("Matthew K. Junker" . "junker@alum.mit.edu"))
  :maintainers '(("Matthew K. Junker" . "junker@alum.mit.edu")))
