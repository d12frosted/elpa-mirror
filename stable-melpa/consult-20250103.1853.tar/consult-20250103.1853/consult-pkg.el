;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250103.1853"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "8c8520c303b6fb772550b167ac50900ef050b56d"
  :revdesc "8c8520c303b6"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
