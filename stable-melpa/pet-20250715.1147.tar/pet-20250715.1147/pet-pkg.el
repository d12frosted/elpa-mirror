;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pet" "20250715.1147"
  "Executable and virtualenv tracker for python-mode."
  '((emacs "26.1")
    (f     "0.6.0")
    (map   "3.3.1")
    (seq   "2.24"))
  :url "https://github.com/wyuenho/emacs-pet/"
  :commit "e4d6810c6324e7d9406df918613978f0257e27ae"
  :revdesc "e4d6810c6324"
  :keywords '("tools")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
