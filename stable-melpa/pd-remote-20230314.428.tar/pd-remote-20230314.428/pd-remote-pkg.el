;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pd-remote" "20230314.428"
  "Pd remote control helper."
  '((emacs      "24.3")
    (faust-mode "0.6")
    (lua-mode   "20210802"))
  :url "https://github.com/agraef/pd-remote"
  :commit "dcd68097d2b7468303517d91cb76682bfb47db63"
  :revdesc "dcd68097d2b7"
  :keywords '("multimedia" "pure-data")
  :authors '(("Albert Graef" . "aggraef@gmail.com"))
  :maintainers '(("Albert Graef" . "aggraef@gmail.com")))
