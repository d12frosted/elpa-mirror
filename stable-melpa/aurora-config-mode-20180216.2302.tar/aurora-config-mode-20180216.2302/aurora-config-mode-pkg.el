;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aurora-config-mode" "20180216.2302"
  "Major mode for Apache Aurora configuration files."
  ()
  :url "https://github.com/bdd/aurora-config.el"
  :commit "8273ec7937a21b469b9dbb6c11714255b890f410"
  :revdesc "8273ec7937a2"
  :keywords '("languages" "configuration")
  :authors '(("Berk D. Demir" . "bdd@mindcast.org"))
  :maintainers '(("Berk D. Demir" . "bdd@mindcast.org")))
