;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-current-directory" "20140101.2354"
  "Create new shell based on buffer directory."
  ()
  :url "https://github.com/metaperl/shell-current-directory"
  :commit "bf843771bf9a4aa05e054ade799eb8862f3be89a"
  :revdesc "bf843771bf9a"
  :keywords '("shell" "comint"))
