(define-package "mood-line" "20230126.703" "A minimal mode line inspired by doom-modeline"
  '((emacs "25.1"))
  :commit "60faca6943c790551ca90b34af72fe63781b81c4" :authors
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainer
  '("Jessie Hildebrandt <jessieh.net>")
  :keywords
  '("mode-line" "faces")
  :url "https://gitlab.com/jessieh/mood-line")
;; Local Variables:
;; no-byte-compile: t
;; End:
