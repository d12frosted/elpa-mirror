(define-package "epkg" "20220503.1115" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "28.1.1.0")
    (closql "20210927"))
  :commit "fb86b5edd910b2571fc21477d0dac90be97a8f61" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
