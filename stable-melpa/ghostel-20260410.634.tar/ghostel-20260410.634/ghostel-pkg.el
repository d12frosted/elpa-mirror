;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260410.634"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "21d8439e62ff4e164d72a71efc1c5df10ab5d111"
  :revdesc "21d8439e62ff"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
