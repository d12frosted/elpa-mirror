;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260305.1223"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "8f54242e15e0da76266ec3dbf0dd27fed76df0b6"
  :revdesc "8f54242e15e0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
