;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260425.1754"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "7858efad028ed7a326132a37c74f32e3644e6414"
  :revdesc "7858efad028e"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
