(define-package "cnfonts" "20211204.640" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "2fc76e013738de4fa466bd35ead88858e99d8bdd" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
