;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260326.728"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "4548ea007865706a1ee2d9e4c5caabd8685d131e"
  :revdesc "4548ea007865"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
