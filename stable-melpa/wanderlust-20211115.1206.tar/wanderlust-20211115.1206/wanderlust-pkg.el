(define-package "wanderlust" "20211115.1206" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "aef23d6e50b7e29ff4ff11d288f36f6ba03f29ac")
;; Local Variables:
;; no-byte-compile: t
;; End:
