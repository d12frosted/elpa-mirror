(define-package "vim-tab-bar" "20240702.257" "Vim-like tab bar"
  '((emacs "28.1"))
  :commit "d6d1f04f6c30e8d3a82915a869abc592f5245faa" :keywords
  '("frames")
  :url "https://github.com/jamescherti/vim-tab-bar.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
