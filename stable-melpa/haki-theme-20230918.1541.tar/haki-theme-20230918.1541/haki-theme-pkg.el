(define-package "haki-theme" "20230918.1541" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "3726a2884fa02fdb83c8a4f43acd11d4b0883c1d" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
