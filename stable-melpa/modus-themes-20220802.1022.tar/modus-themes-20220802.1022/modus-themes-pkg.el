(define-package "modus-themes" "20220802.1022" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "12e790f315d4ebabb49c2bac8dc6a867bc1eb02a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
