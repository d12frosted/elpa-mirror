(define-package "ekg" "20230924.1825" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.1.1"))
  :commit "40e854fe8fee461af1ebae2166c28733ad94ca30" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
