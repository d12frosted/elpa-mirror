;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kele" "20250112.1517"
  "Spritzy Kubernetes cluster management."
  '((emacs   "29.1")
    (async   "1.9.7")
    (dash    "2.19.1")
    (f       "0.20.0")
    (ht      "2.3")
    (memoize "0")
    (plz     "0.8.0")
    (s       "1.13.0")
    (yaml    "0.5.1"))
  :url "https://github.com/jinnovation/kele.el"
  :commit "c054b404a4e0f123b149ca904739ced4adb92a47"
  :revdesc "c054b404a4e0"
  :keywords '("kubernetes" "tools")
  :authors '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers '(("Jonathan Jin" . "me@jonathanj.in")))
