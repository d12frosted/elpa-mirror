(define-package "modus-themes" "20221023.826" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "d784a1591d9747d06c7485945d119745a9529085" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
