;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251122.941"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "26d60d3e6b34144f6b929702cea128413ab105e4"
  :revdesc "26d60d3e6b34"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
