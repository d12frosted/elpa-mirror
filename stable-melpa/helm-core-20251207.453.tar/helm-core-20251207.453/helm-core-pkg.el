;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251207.453"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "18d5350074e243f2455c013439fd826137d00925"
  :revdesc "18d5350074e2"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
