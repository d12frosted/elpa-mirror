(define-package "magik-mode" "20200217.1213" "mode for editing Magik + some utils." 'nil :commit "d280836c77fd263ee404273d7c21f47395a657f9" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
