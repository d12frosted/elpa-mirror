(define-package "annotate" "20230830.1428" "annotate files without changing them" 'nil :commit "dbdd2a4663c49581a9bca77d4ea08e6eb98dbdcc" :authors
  '(("Bastian Bechtold"))
  :maintainers
  '(("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it"))
  :maintainer
  '("Bastian Bechtold <bastibe.dev@mailbox.org>, cage" . "cage-dev@twistfold.it")
  :url "https://github.com/bastibe/annotate.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
