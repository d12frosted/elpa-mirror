;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-sidebar" "20260619.56"
  "Tree browser leveraging dired."
  '((emacs         "29.1")
    (dired-subtree "0.0.1")
    (compat        "30.0.0.0"))
  :url "https://github.com/jojojames/dired-sidebar"
  :commit "1852a0b17bf2619607f6b4dfc437e279ba04e93c"
  :revdesc "1852a0b17bf2"
  :keywords '("dired" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
