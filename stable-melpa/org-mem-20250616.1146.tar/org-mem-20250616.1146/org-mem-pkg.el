;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250616.1146"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "e66bb0908d3c15d2e4e73b950e40edb58ea17376"
  :revdesc "e66bb0908d3c"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
