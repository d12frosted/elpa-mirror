;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250415.509"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "35efe9357fd8a80ac6f9b175b24434b74dd5d516"
  :revdesc "35efe9357fd8"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
