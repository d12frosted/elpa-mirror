;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syncthing" "20250611.1817"
  "Client for Syncthing."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/emacs-syncthing"
  :commit "9e3b0876e0891ddc7ce8da56fe87ece44f1caa5b"
  :revdesc "9e3b0876e089"
  :keywords '("convenience" "syncthing" "sync" "client" "view")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
