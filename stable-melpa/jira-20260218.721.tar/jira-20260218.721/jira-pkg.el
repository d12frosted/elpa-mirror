;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20260218.721"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "b578426e7f4d6d4c41a41788053e88e6a5290f84"
  :revdesc "b578426e7f4d"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
