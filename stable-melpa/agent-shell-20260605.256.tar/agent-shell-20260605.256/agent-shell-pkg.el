;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260605.256"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b2badff2acc1274fac1648c7a07e0f11edf6d826"
  :revdesc "b2badff2acc1")
