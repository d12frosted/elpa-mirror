;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "workroom" "20230926.1631"
  "Named rooms for work without irrelevant distracting buffers."
  '((emacs   "25.1")
    (project "0.3.0")
    (compat  "28.1.2.2"))
  :url "https://codeberg.org/akib/emacs-workroom"
  :commit "cb8654191b23c9b02a79660c3d8c969709c6fcbe"
  :revdesc "cb8654191b23"
  :keywords '("tools" "convenience")
  :authors '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainers '(("Akib Azmain Turja" . "akib@disroot.org")))
