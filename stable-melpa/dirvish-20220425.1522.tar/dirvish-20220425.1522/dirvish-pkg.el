(define-package "dirvish" "20220425.1522" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "3e0a414df35742799759f71915443226574fc961" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
