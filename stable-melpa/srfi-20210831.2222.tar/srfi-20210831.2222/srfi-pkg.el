(define-package "srfi" "20210831.2222" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "37c85081a9d7c1c63e1f2f94b602d6db2e1dd257" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
