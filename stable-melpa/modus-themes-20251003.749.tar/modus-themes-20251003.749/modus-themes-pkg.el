;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251003.749"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "0648760267ab85195e8f0d2ab574b845e46454d3"
  :revdesc "0648760267ab"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
