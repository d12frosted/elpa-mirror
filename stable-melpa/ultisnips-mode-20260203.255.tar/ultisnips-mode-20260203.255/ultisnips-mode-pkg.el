;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "20260203.255"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "6b66405bb5e72e02d0f2df83d5918b499c564b2a"
  :revdesc "6b66405bb5e7"
  :keywords '("languages"))
