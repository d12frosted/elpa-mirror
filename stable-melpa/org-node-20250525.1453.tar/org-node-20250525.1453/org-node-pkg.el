;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250525.1453"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "1e89c6be92f9d4b2abd5c88ee56c0cf4432eb0d1"
  :revdesc "1e89c6be92f9"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
