;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quilt" "20190828.506"
  "Minor mode for working with files in quilt."
  '((emacs "26.0"))
  :url "https://github.com/jstranik/emacs-quilt"
  :commit "b56a1f1acc46cdf8655710e4c8f24f5f31f22c6a"
  :revdesc "b56a1f1acc46"
  :keywords '("extensions")
  :authors '(("Matt Mackall" . "mpm@selenic.com"))
  :maintainers '(("Jan Stranik" . "jan@stranik.org")))
