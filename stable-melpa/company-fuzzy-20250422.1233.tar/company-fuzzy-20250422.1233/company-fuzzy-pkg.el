;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-fuzzy" "20250422.1233"
  "Fuzzy matching for `company-mode'."
  '((emacs   "26.1")
    (company "0.8.12")
    (s       "1.12.0")
    (ht      "2.0"))
  :url "https://github.com/jcs-elpa/company-fuzzy"
  :commit "955c6b31f679fcf2af6af646339193730ac0b816"
  :revdesc "955c6b31f679"
  :keywords '("matching" "auto-complete" "complete" "fuzzy")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
