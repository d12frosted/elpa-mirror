;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251110.347"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "a33e1bb7cbd4a91894f28a66f9e28eb57dd5ea80"
  :revdesc "a33e1bb7cbd4"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
