;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250423.1026"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "51c7c4dc21d879587a11f893aed20583d27f3214"
  :revdesc "51c7c4dc21d8"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
