;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260524.2048"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.30.2")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "a6bc1e8eba6ba9f58198738cea1bcc8e43cbb628"
  :revdesc "a6bc1e8eba6b"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
