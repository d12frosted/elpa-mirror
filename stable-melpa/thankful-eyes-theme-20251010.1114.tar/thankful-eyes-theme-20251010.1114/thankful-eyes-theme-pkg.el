;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thankful-eyes-theme" "20251010.1114"
  "Theme for color blindness and visual impairments."
  '((emacs "24.1"))
  :url "https://github.com/tanrax/thankful-eyes-theme.el"
  :commit "2fdb4271ecb91c75408993b324e1edf8dd13702e"
  :revdesc "2fdb4271ecb9"
  :keywords '("faces")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
