;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-sanityinc-tomorrow" "20260105.1047"
  "A version of Chris Kempson's \"tomorrow\" themes."
  '((emacs "24.1"))
  :url "https://github.com/purcell/color-theme-sanityinc-tomorrow"
  :commit "22107d90816293c361b777b1f8dfd6ba0be00f7b"
  :revdesc "22107d908162"
  :keywords '("faces" "themes")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
