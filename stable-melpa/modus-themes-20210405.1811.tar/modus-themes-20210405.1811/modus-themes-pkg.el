(define-package "modus-themes" "20210405.1811" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "6829ac5ca8fe3252b192083fccb49a8dea077cff" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
