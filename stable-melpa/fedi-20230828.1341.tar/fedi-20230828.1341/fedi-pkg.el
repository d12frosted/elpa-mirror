(define-package "fedi" "20230828.1341" "Helper functions for fediverse clients"
  '((emacs "28.1"))
  :commit "132229e6634b64d01eb7e332c5f086fdc973a876" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
