;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20250915.1647"
  "BLUE build system interface."
  '((emacs "30.1"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "59b693ba0119dd48913d64b00fbf9dded9c84240"
  :revdesc "59b693ba0119"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
