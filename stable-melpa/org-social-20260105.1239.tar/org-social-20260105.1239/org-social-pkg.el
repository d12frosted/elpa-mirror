;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20260105.1239"
  "An Org-social client for Emacs."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "d4cfe777975519ae2908416eb58c4f1b4cb33b43"
  :revdesc "d4cfe7779755"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
