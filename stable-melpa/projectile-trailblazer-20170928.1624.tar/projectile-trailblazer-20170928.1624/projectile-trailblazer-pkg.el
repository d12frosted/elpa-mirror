;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-trailblazer" "20170928.1624"
  "Minor mode for Rails projects using trailblazer."
  '((emacs       "24.4")
    (projectile  "0.12.0")
    (inflections "1.1")
    (inf-ruby    "2.2.6")
    (f           "0.13.0")
    (rake        "0.3.2"))
  :url "https://github.com/micdahl/projectile-trailblazer"
  :commit "79299498d74876f2ac3fe8075716b39a5bdd04cd"
  :revdesc "79299498d748"
  :keywords '("rails" "projectile" "trailblazer" "languages")
  :authors '(("Michael Dahl" . "michael.dahl84@gmail.com"))
  :maintainers '(("Michael Dahl" . "michael.dahl84@gmail.com")))
