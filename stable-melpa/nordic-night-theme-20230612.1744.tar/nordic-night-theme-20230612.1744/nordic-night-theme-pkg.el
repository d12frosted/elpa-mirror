(define-package "nordic-night-theme" "20230612.1744" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "424a6eee0c3e1d18dacc60e4ae341d0816d95a49" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
