(define-package "consult" "20220214.1201" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "fd110782aaddbfe55b8565d112de07f9366337a3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
