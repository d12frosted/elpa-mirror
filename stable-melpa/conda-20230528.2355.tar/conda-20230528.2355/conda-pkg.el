(define-package "conda" "20230528.2355" "Work with your conda environments"
  '((emacs "25.1")
    (pythonic "0.1.0")
    (dash "2.13.0")
    (s "1.11.0")
    (f "0.18.2"))
  :commit "f3ea3876eecd00a1fca16fd7fd68e56e3beac87c" :authors
  '(("Rami Chowdhury" . "rami.chowdhury@gmail.com"))
  :maintainers
  '(("Rami Chowdhury" . "rami.chowdhury@gmail.com"))
  :maintainer
  '("Rami Chowdhury" . "rami.chowdhury@gmail.com")
  :keywords
  '("languages" "local" "tools" "python" "environment" "conda")
  :url "http://github.com/necaris/conda.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
