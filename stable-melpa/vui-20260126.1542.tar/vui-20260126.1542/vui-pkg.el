;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260126.1542"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "022f7e2359d738ead1c87384da1afc3a12147503"
  :revdesc "022f7e2359d7"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
