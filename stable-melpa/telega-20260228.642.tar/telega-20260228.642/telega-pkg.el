;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260228.642"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "3c905362b525037511c2f382fdc005c3f59d6929"
  :revdesc "3c905362b525"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
