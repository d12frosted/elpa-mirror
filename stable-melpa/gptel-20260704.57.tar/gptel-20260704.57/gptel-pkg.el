;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260704.57"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "f46da00402dbaece9523f8b5637053f9e6a24647"
  :revdesc "f46da00402db"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
