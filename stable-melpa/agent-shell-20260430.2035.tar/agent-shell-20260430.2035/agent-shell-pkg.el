;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260430.2035"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6e03b78a71fe2131df4128490cd18eca45e5d157"
  :revdesc "6e03b78a71fe")
