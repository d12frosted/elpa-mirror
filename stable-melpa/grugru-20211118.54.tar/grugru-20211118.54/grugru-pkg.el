(define-package "grugru" "20211118.54" "Rotate text at point"
  '((emacs "24.4"))
  :commit "527e8dc4c2d7fbc02420970cb429b580dc3c99ab" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
