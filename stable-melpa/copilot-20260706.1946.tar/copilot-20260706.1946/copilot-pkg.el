;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260706.1946"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "a2cdb6783eaaa74b266af3b1ee2acef0ce8060bc"
  :revdesc "a2cdb6783eaa"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
