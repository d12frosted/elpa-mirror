;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-chrome-textarea" "20200324.1513"
  "Edit Chrome Textarea."
  '((emacs     "25.1")
    (websocket "1.4"))
  :url "https://github.com/xuchunyang/edit-chrome-textarea.el"
  :commit "302659e92b7ef88824691905df3f926766f64729"
  :revdesc "302659e92b7e"
  :keywords '("tools"))
