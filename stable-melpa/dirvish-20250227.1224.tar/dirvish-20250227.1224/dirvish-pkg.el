;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250227.1224"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "3c41c40875e3eea98d7d2a647d4a0ef920f4f939"
  :revdesc "3c41c40875e3"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
