;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "equake" "20260102.58"
  "Drop-down console for (e)shell & terminal emulation."
  '((emacs "27.1")
    (dash  "2.14.1"))
  :url "https://github.com/emacsomancer/equake"
  :commit "dad70e0a290d2d7a5baa48bb513cd81e84b0dfd8"
  :revdesc "dad70e0a290d"
  :keywords '("convenience" "frames" "terminals" "tools" "window-system")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
