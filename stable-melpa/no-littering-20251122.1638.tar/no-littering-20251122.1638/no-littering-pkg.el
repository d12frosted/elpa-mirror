;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20251122.1638"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "c6f5d06cd131f62406185ec8c4f9237dde7e037c"
  :revdesc "c6f5d06cd131"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
