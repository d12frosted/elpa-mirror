;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260403.150"
  "XMPP/Jabber client."
  '((emacs "29.1")
    (fsm   "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-jabber"
  :commit "c83312c53d11e8de6de800ec4958623c632256e1"
  :revdesc "c83312c53d11"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
