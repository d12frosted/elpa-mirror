(define-package "modus-themes" "20211008.824" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "4548a334258b1a05dffc97f743c46957a4eefd61" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
