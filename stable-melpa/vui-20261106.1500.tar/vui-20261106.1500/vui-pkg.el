;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261106.1500"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "a90f3cd411cc1102981b43efe92556c9d821acd3"
  :revdesc "a90f3cd411cc"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
