(define-package "apdl-mode" "20210818.625" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "ea4e122294fe5d20d17fa118c190747efaa0d2b4" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
