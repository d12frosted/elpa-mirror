;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "brazilian-holidays" "20220828.2348"
  "Brazilian holidays."
  '((emacs "26"))
  :url "https://github.com/jadler/brazilian-holidays"
  :commit "03206ea673df49c91a8f924db799620713d86240"
  :revdesc "03206ea673df"
  :keywords '("calendar" "holidays" "brazilian")
  :authors '(("Jaguaraquem A. Reinaldo" . "jaguar.adler@gmail.com"))
  :maintainers '(("Jaguaraquem A. Reinaldo" . "jaguar.adler@gmail.com")))
