(define-package "spdx" "20220801.156" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "9e31a55c35e72dc92d0a727fc25e5fa6e21ef8ee" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
