;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260114.1604"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "97fe58317cfeac71aa4667c7ad548ed986f4eabd"
  :revdesc "97fe58317cfe"
  :keywords '("convenience"))
