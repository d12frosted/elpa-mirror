;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20261106.1858"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "1fe3b6d5c6eb6f5c940b6e50a651f1ce2655b419"
  :revdesc "1fe3b6d5c6eb"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
