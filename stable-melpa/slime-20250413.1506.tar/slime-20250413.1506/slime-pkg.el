;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20250413.1506"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "853c67080c9b00232f51d48d6330a1b82db3e64a"
  :revdesc "853c67080c9b"
  :keywords '("languages" "lisp" "slime"))
