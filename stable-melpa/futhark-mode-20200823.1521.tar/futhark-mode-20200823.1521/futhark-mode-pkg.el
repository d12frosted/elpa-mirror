(define-package "futhark-mode" "20200823.1521" "major mode for editing Futhark source files"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "88e7bb1eefbe01f781cc4958bc0431fea90b7d93" :keywords
  '("languages")
  :url "https://github.com/diku-dk/futhark-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
