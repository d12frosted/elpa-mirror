(define-package "modus-themes" "20210312.2029" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "ccca6b3369dd6c1ce90dac60d5b090c04f2ed885" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
