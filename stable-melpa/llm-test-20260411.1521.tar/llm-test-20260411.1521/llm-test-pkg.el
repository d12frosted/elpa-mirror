;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260411.1521"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "9ff0fd075a694551d3b4fdb50417c0e64aa7bf01"
  :revdesc "9ff0fd075a69"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
