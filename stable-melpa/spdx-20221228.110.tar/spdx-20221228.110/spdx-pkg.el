(define-package "spdx" "20221228.110" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "0bdd7e0501d9e432f3ae50d7ae1290a835503fda" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
