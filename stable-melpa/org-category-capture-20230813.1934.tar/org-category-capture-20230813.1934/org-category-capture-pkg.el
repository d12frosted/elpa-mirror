(define-package "org-category-capture" "20230813.1934" "Contextualy capture of org-mode TODOs."
  '((org "9.0.0")
    (emacs "24"))
  :commit "07a9e561f043cfa143f0f8f12a502c229ee96ae4" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "todo" "tools" "outlines")
  :url "https://github.com/IvanMalison/org-projectile")
;; Local Variables:
;; no-byte-compile: t
;; End:
