(define-package "dwim-shell-command" "20221017.603" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "8d994afaa76edbb43494c36668d6920ccefa0fc8" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
