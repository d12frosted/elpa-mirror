;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260522.2351"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "3a76fc36ac2c4aa7595151220c6de501ad1267e7"
  :revdesc "3a76fc36ac2c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
