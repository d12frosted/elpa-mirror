;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tp" "20260509.802"
  "Utilities for transient menus that POST to an API."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://codeberg.org/martianh/tp.el"
  :commit "a83cd422cca09bc863a7179f1c5b5a35435e0d32"
  :revdesc "a83cd422cca0"
  :keywords '("convenience" "api" "requests")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
