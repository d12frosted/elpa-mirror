(define-package "literate-calc-mode" "20230612.2332" "Inline results from calc"
  '((emacs "25.1")
    (s "1.12.0"))
  :commit "db1a6d69952335d9dec1bf17aef166ca21e6a7ea" :authors
  '(("Robin Schroer"))
  :maintainers
  '(("Robin Schroer"))
  :maintainer
  '("Robin Schroer")
  :keywords
  '("calc" "languages" "tools")
  :url "https://github.com/sulami/literate-calc-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
