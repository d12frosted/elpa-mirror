;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260713.1503"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "17b59d60a9bf8ea266aa7794f09faa5b8d3e2157"
  :revdesc "17b59d60a9bf"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
