(define-package "helm-core" "20240909.544" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.8"))
  :commit "4e4257afdb9fd2357dc73bf2de1f0d958c858da5" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
