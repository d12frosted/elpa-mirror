;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "20260901.1037"
  "Automatic capitalization with batteries included."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/abdulnafe-t/auto-capitalize.el"
  :commit "7a7d049c481a19990e38b9e0ed3ad004ee5f9691"
  :revdesc "7a7d049c481a"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
