;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260705.1325"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "1e6ebd112d3dc44e66f249be292e2abf4e994756"
  :revdesc "1e6ebd112d3d"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
