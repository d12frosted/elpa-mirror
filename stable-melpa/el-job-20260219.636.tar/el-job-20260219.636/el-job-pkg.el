;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20260219.636"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "62ff3fe5e570028c597a74e66269292503511398"
  :revdesc "62ff3fe5e570"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
