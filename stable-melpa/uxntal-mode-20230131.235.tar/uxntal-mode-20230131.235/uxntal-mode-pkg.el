(define-package "uxntal-mode" "20230131.235" "Major mode for Uxntal assembly"
  '((emacs "27.1"))
  :commit "aaaa7a7ac24eb142c68f691185166327ec1e4520" :authors
  '(("d_m" . "d_m@plastic-idolatry.com"))
  :maintainers
  '(("d_m" . "d_m@plastic-idolatry.com"))
  :maintainer
  '("d_m" . "d_m@plastic-idolatry.com")
  :url "https://github.com/non/uxntal-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
