(define-package "mb-url" "20210915.1924" "Multiple Backends for Emacs URL package"
  '((emacs "24.4"))
  :commit "9c706158e0a9825fc31a12c8eda5617edfb08120" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
