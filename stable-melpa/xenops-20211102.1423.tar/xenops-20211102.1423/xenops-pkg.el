(define-package "xenops" "20211102.1423" "A LaTeX editing environment for mathematical documents"
  '((emacs "26.1")
    (aio "1.0")
    (auctex "12.2.0")
    (avy "0.5.0")
    (dash "2.18.0")
    (f "0.20.0")
    (s "1.12.0"))
  :commit "ea25ae97f39032d237873067a5da8ebf18f2fd4d" :authors
  '(("Dan Davison" . "dandavison7@gmail.com"))
  :maintainer
  '("Dan Davison" . "dandavison7@gmail.com")
  :url "https://github.com/dandavison/xenops")
;; Local Variables:
;; no-byte-compile: t
;; End:
