;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260627.1130"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "dfce6762b7463b001b2cf5612537cd9b8bcbb3ad"
  :revdesc "dfce6762b746"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
