(define-package "lsp-java" "20240524.511" "Java support for lsp-mode"
  '((emacs "27.1")
    (lsp-mode "6.0")
    (markdown-mode "2.3")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.0")
    (request "0.3.0")
    (treemacs "2.5")
    (dap-mode "0.5"))
  :commit "968ddc179b4d0b51e6d7fcdef89c36937c664b25" :keywords
  '("languague" "tools")
  :url "https://github.com/emacs-lsp/lsp-java")
;; Local Variables:
;; no-byte-compile: t
;; End:
