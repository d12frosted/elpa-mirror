;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260807.630"
  "Manage multiple AI coding agents."
  '((emacs         "28.1")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (magit-section "3.3.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "18b7424fde49fd0257964065ff07841f6e21dec6"
  :revdesc "18b7424fde49"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
