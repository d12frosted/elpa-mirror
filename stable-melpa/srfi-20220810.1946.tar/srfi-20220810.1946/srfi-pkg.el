(define-package "srfi" "20220810.1946" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "82644b735bb3839459784efa8b1e1125f5ef1862" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
