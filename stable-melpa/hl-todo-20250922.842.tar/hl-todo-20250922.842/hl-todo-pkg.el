;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-todo" "20250922.842"
  "Highlight TODO and similar keywords."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/hl-todo"
  :commit "47a8e0a3f7251fdc822a47900cb434531873afda"
  :revdesc "47a8e0a3f725"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev")))
