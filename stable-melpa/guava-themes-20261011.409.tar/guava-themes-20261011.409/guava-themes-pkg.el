;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261011.409"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "839c2c57b65396f17a257c7b9317430baff6398b"
  :revdesc "839c2c57b653"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
