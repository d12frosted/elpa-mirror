(define-package "simple-call-tree" "20240706.944" "analyze source code based on font-lock text-properties"
  '((emacs "24.3")
    (anaphora "1.0.0"))
  :commit "418182a28dbceaae3db8f9afac171307c23fa02f" :authors
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers
  '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("programming")
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
