;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bbww" "20230502.2239"
  "Improved word-jumping functions."
  '((mwim  "1.0")
    (emacs "24.3"))
  :url "http://chud.wtf"
  :commit "9b4430f757e9c7fc7178541009676af1262c486b"
  :revdesc "9b4430f757e9"
  :keywords '("convenience" "files"))
