;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260303.2138"
  "Emacs frontend for pi coding agent."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "ff1301adf0f33f00e614d200ce290f7f76407961"
  :revdesc "ff1301adf0f3"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
