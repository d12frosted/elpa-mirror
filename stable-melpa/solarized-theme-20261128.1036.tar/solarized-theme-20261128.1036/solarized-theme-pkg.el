;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solarized-theme" "20261128.1036"
  "The Solarized color theme."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/solarized-emacs"
  :commit "d94f10e8d9e858f64d34ea454335378a18a9b8c3"
  :revdesc "d94f10e8d9e8"
  :keywords '("convenience" "themes" "solarized")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
