(define-package "dwim-shell-command" "20231010.1401" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "fee9ec7806e84442b333618352e148ce72223aee" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
