;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daml-mode" "20261104.2105"
  "Major mode for daml."
  '((emacs        "27.1")
    (haskell-mode "16.1"))
  :url "https://github.com/bartfaitamas/daml-mode"
  :commit "9e24743ff1c0c883f2c1b0db90e1acd6bdcb7593"
  :revdesc "9e24743ff1c0"
  :authors '(("Bártfai Tamás" . "tamas@bartfai.dev"))
  :maintainers '(("Bártfai Tamás" . "tamas@bartfai.dev")))
