;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-xcode" "20180122.651"
  "Flycheck extension for Apple's Xcode."
  '((emacs    "25.1")
    (flycheck "0.25"))
  :url "https://github.com/jojojames/flycheck-xcode"
  :commit "6147ab777e2c08e4f5ffdbd85d3013ca700fa835"
  :revdesc "6147ab777e2c"
  :keywords '("languages" "xcode")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
