;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moe-theme" "20260304.1519"
  "A colorful eye-candy theme. Moe, moe, kyun!."
  ()
  :url "https://github.com/kuanyui/moe-theme.el"
  :commit "075f91acc2a7ad722bdda0ab945a7fb0f7c4565f"
  :revdesc "075f91acc2a7"
  :keywords '("themes")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
