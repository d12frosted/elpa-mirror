;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lyrics-fetcher" "20261109.1822"
  "Fetch song lyrics and album covers."
  '((emacs   "27")
    (emms    "7.5")
    (f       "0.20.0")
    (request "0.3.2"))
  :url "https://github.com/SqrtMinusOne/lyrics-fetcher.el"
  :commit "de0de73399eac1e2f7eab5c264263dc9d8ba3ab9"
  :revdesc "de0de73399ea"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
