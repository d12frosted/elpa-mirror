(define-package "nexus" "20210903.1743" "REST Client for Nexus Maven Repository servers" 'nil :commit "5f38c5623620b23ce19b7f7168b6696586d911ac" :authors
  '(("Juergen Hoetzel" . "juergen@archlinux.org"))
  :maintainer
  '("Juergen Hoetzel" . "juergen@archlinux.org")
  :keywords
  '("comm"))
;; Local Variables:
;; no-byte-compile: t
;; End:
