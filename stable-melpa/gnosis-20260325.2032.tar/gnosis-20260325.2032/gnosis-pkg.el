;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260325.2032"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "ab86a5949ff43863184b69e1fcd02055af5d838a"
  :revdesc "ab86a5949ff4"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
