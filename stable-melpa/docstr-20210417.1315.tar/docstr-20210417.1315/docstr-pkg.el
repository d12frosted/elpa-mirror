(define-package "docstr" "20210417.1315" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "a05268a486330c0554a8fb78d566effb6c8604e9" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
