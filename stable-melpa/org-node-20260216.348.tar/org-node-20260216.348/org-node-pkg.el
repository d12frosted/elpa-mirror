;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260216.348"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "ddbc3ffaa97fff3676b2d7b14db74a69a8ecacaf"
  :revdesc "ddbc3ffaa97f"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
