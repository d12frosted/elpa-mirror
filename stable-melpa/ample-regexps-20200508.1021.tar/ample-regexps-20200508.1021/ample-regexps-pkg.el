(define-package "ample-regexps" "20200508.1021" "ample regular expressions for Emacs" 'nil :commit "153969ce547afe410b8986f01c9ed4087c9cd20b" :keywords
  ("regexps" "extensions" "tools")
  :authors
  (("immerrr" . "immerrr@gmail.com"))
  :maintainer
  ("immerrr" . "immerrr@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
