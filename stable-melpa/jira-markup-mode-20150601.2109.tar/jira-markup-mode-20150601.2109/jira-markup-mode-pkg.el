;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira-markup-mode" "20150601.2109"
  "Emacs Major mode for JIRA-markup-formatted text files."
  ()
  :url "https://github.com/mnuessler/jira-markup-mode"
  :commit "53bf083fdbece483f1351f32085b424b38c4c1f2"
  :revdesc "53bf083fdbec"
  :keywords '("jira" "markup")
  :authors '(("Matthias Nuessler" . "m.nuessler@web.de"))
  :maintainers '(("Matthias Nuessler" . "m.nuessler@web.de")))
