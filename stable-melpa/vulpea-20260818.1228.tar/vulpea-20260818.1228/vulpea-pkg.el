;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260818.1228"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "88343492d1067a6d61a088e9bc5607ed8753c3dc"
  :revdesc "88343492d106"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
