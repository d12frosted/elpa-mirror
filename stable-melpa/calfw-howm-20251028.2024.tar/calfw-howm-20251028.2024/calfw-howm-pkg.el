;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-howm" "20251028.2024"
  "Calendar view for howm."
  '((emacs "28.1")
    (calfw "2.0")
    (howm  "1.5.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "46a48d1cec5aa83e12eb07c6b215b1de8bf21482"
  :revdesc "46a48d1cec5a"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
