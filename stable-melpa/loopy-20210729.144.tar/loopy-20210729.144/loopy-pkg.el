(define-package "loopy" "20210729.144" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "b38817b9e161947ec6433c34952ac0af90ae88cd" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
