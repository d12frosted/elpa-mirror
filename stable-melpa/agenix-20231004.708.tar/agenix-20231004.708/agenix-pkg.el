(define-package "agenix" "20231004.708" "Decrypt and encrypt agenix secrets"
  '((emacs "27.1"))
  :commit "c3728c94626a857492a12b8a236f185b25874c7e" :authors
  '(("Tomasz Maciosowski" . "t4ccer@gmail.com"))
  :maintainers
  '(("Tomasz Maciosowski" . "t4ccer@gmail.com"))
  :maintainer
  '("Tomasz Maciosowski" . "t4ccer@gmail.com")
  :url "https://github.com/t4ccer/agenix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
