;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-view-log" "20140227.2039"
  "Major mode for viewing ERC logs."
  ()
  :url "https://github.com/Niluge-KiWi/erc-view-log/raw/master/erc-view-log.el"
  :commit "c5a25f0cbca84ed2e4f72068c02b66bd0ea3b266"
  :revdesc "c5a25f0cbca8"
  :keywords '("erc" "viewer" "logs" "colors")
  :authors '(("Thomas Riccardi" . "riccardi.thomas@gmail.com"))
  :maintainers '(("Thomas Riccardi" . "riccardi.thomas@gmail.com")))
