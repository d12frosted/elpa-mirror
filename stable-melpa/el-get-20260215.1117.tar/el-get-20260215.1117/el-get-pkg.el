;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-get" "20260215.1117"
  "Manage the external elisp bits and pieces you depend upon."
  ()
  :url "http://www.emacswiki.org/emacs/el-get"
  :commit "911c252afe763a5cd1cbd188c476d44353cd5271"
  :revdesc "911c252afe76"
  :keywords '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
