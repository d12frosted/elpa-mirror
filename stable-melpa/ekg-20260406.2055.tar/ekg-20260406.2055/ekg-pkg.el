;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260406.2055"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "e0be2dd6b48d815992d7e7a3a90e3edea2126aa8"
  :revdesc "e0be2dd6b48d"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
