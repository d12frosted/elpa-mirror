;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261011.1714"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "0be643ef0afbc0b3d8b802e72bb512dbf3972d6d"
  :revdesc "0be643ef0afb"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
