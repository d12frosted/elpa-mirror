;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient-extras" "20230721.839"
  "Extra features for transient."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/transient-extras.git"
  :commit "ca0d5c597382615f0ee8300ff8718f54f8214359"
  :revdesc "ca0d5c597382"
  :keywords '("convenience")
  :authors '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")
             ("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.ali@gmail.com")
                 ("Samuel W. Flint" . "swflint@flintfam.org")))
