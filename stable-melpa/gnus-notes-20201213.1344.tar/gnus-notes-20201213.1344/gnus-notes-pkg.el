(define-package "gnus-notes" "20201213.1344" "Keep handy notes of read Gnus articles with helm and org"
  '((emacs "27.1")
    (bbdb "3.1")
    (helm "3.1")
    (hydra "0.13.0")
    (org "8.3")
    (s "0.0")
    (lv "0.0")
    (async "1.9.1"))
  :commit "f34e5fc1077e2558e5059876d0a22b35331f7b93" :keywords
  ("convenience" "mail" "bbdb" "gnus" "helm" "org" "hydra")
  :authors
  (("Deus Max" . "deusmax@gmx.com"))
  :maintainer
  ("Deus Max" . "deusmax@gmx.com")
  :url "https://github.com/deusmax/gnus-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
