(define-package "mhc" "20201113.3" "Message Harmonized Calendaring system."
  '((calfw "20150703"))
  :commit "33d8ca1a1beb2b63e720e17525bdda3cc878e5ed" :authors
  '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainer
  '("Yoshinari Nomura" . "nom@quickhack.net")
  :keywords
  '("calendar")
  :url "http://www.quickhack.net/mhc")
;; Local Variables:
;; no-byte-compile: t
;; End:
