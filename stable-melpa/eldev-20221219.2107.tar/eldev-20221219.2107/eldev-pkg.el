(define-package "eldev" "20221219.2107" "Elisp development tool"
  '((emacs "24.4"))
  :commit "68faab734bff388f7e53d3dbea321878684002c8" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
