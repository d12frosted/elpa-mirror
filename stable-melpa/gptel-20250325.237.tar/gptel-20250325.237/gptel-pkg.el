;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250325.237"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "c5ffae2fe1ebfa43b157a017a7de5d60fa86eaa1"
  :revdesc "c5ffae2fe1eb"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
