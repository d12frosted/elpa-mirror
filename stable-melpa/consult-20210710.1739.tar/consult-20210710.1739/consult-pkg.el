(define-package "consult" "20210710.1739" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "48acf068da5120768873d2598481c7f27577c9de" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
