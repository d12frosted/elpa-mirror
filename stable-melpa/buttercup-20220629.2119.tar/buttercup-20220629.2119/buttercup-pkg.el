(define-package "buttercup" "20220629.2119" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "62176a39ee6aa990c96e97c13ee4992355f0a122" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
