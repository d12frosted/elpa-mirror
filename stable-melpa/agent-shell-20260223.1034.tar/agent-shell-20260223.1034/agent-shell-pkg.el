;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260223.1034"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "46fb6c1228910560e44b9b85dc01b47de99aa1d4"
  :revdesc "46fb6c122891")
