(define-package "racket-mode" "20221103.1411" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "d1caf10d1358a593950d9af65222a1f6f11a5d4c" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
