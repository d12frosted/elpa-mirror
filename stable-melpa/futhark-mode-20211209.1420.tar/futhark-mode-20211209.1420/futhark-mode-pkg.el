(define-package "futhark-mode" "20211209.1420" "major mode for editing Futhark source files"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "8cfa66dd2acfa4fdd7f969146ce40d7271f504a6" :keywords
  '("languages")
  :url "https://github.com/diku-dk/futhark-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
