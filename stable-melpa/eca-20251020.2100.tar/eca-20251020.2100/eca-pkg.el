;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251020.2100"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "fe0f6c27814cad750e581643b5c83235e67b9a24"
  :revdesc "fe0f6c27814c"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
