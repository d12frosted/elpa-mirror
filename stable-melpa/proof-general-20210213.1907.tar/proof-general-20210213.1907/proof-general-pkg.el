(define-package "proof-general" "20210213.1907" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.3"))
  :commit "bdb67820696b2bfec06fda72f2a39548c73dcaf7" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
