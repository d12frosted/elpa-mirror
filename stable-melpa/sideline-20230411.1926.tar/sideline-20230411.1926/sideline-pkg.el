(define-package "sideline" "20230411.1926" "Show information on the side"
  '((emacs "27.1"))
  :commit "77c363239e3edce287eb15d59e3c28b21d8ddb79" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/emacs-sideline/sideline")
;; Local Variables:
;; no-byte-compile: t
;; End:
