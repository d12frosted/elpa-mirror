(define-package "brutal-theme" "20211014.1701" "Brutalist theme"
  '((emacs "24.1"))
  :commit "3372542743140155223f16995bbd96819dc1b25f" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
