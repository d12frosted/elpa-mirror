(define-package "merlin" "20230919.1444" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "5f050e4ec4f60343bb3a3c5085d9ab558c734b3e" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainers
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
