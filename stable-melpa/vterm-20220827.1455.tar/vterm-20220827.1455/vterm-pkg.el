(define-package "vterm" "20220827.1455" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "45b5be43b3265c9f415d0eec68a606db1e863db1" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
