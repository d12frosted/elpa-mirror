;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261117.1215"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "ab1d536d576ed7d3838aeae19e5d455ed7e02ad2"
  :revdesc "ab1d536d576e"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
