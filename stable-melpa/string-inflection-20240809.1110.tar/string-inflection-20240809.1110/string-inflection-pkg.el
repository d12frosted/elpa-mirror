(define-package "string-inflection" "20240809.1110" "underscore -> UPCASE -> CamelCase -> lowerCamelCase conversion of names" 'nil :commit "be3808c9bbd3f732f94cea7e19ad68eac5f6dad0" :authors
  '(("akicho8" . "akicho8@gmail.com"))
  :maintainers
  '(("akicho8" . "akicho8@gmail.com"))
  :maintainer
  '("akicho8" . "akicho8@gmail.com")
  :keywords
  '("elisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
