;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "audio-notes-mode" "20170611.2159"
  "Play audio notes synced from somewhere else."
  ()
  :url "https://github.com/Bruce-Connor/audio-notes-mode"
  :commit "fa38350829c7e97257efc746a010471d33748a68"
  :revdesc "fa38350829c7"
  :keywords '("hypermedia" "convenience")
  :authors '(("Artur Malabarba" . "bruce.connor.am@gmail.com"))
  :maintainers '(("Artur Malabarba" . "bruce.connor.am@gmail.com")))
