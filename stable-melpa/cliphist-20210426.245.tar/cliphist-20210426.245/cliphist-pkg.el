(define-package "cliphist" "20210426.245" "Read data from clipboard managers at Linux and macOS"
  '((emacs "24.3")
    (ivy "0.9.0"))
  :commit "0d02d72fb63453ff5623b26234a63f66090da7ac" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("clipboard" "manager" "history")
  :url "http://github.com/redguardtoo/cliphist")
;; Local Variables:
;; no-byte-compile: t
;; End:
