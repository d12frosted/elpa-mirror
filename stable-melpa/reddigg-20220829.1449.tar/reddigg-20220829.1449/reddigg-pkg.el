(define-package "reddigg" "20220829.1449" "A reader for redditt"
  '((emacs "26.3")
    (promise "1.1")
    (ht "2.3")
    (request "0.3.0")
    (org "9.2"))
  :commit "7b5445d3101bd8c9fa4a456ad37a19bba840a2cb" :authors
  '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers
  '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainer
  '("Thanh Vuong" . "thanhvg@gmail.com")
  :url "https://github.com/thanhvg/emacs-reddigg")
;; Local Variables:
;; no-byte-compile: t
;; End:
