;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260607.2124"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "f8ffd7782623f7e102cf39e66e30b2abaf74d91c"
  :revdesc "f8ffd7782623"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
