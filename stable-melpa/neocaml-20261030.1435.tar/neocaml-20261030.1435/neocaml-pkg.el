;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261030.1435"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "480ccacfd03cad56c905876f2ce5a43039327f6d"
  :revdesc "480ccacfd03c"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
