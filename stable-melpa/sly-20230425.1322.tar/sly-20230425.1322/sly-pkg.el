(define-package "sly" "20230425.1322" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "5aee5cc872038a560235c70bf551cc11aaf9d845" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
