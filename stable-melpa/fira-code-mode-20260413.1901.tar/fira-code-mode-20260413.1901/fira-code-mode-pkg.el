;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fira-code-mode" "20260413.1901"
  "Minor mode for Fira Code ligatures using prettify-symbols."
  '((emacs "24.4"))
  :url "https://github.com/jming422/fira-code-mode"
  :commit "5a8e2e96c40822b8e11a8f16392bc3ccdd6c69fd"
  :revdesc "5a8e2e96c408"
  :keywords '("faces" "ligatures" "fonts" "programming-ligatures")
  :authors '(("Jonathan Ming" . "jming422@gmail.com"))
  :maintainers '(("Jonathan Ming" . "jming422@gmail.com")))
