;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20260124.2048"
  "Miasma: color theme inspired by the woods."
  ()
  :url "https://github.com/daut/miasma-theme.el"
  :commit "313678cfe8cb386f2240ed62d91495bb65e1fc2b"
  :revdesc "313678cfe8cb")
