;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260129.712"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "7a1e1fb60ed164b75cfa1f8c89f6a5ebd1b9269a"
  :revdesc "7a1e1fb60ed1"
  :keywords '("languages"))
