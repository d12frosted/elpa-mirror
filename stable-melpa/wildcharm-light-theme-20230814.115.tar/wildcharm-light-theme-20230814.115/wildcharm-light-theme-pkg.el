(define-package "wildcharm-light-theme" "20230814.115" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "85ac94c285d37f26e0eb45308ef17240c283f7c9" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
