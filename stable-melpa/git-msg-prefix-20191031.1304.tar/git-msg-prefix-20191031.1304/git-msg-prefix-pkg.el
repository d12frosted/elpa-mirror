;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-msg-prefix" "20191031.1304"
  "Insert commit message prefix (issue number)."
  '((emacs "24")
    (s     "1.10.0")
    (dash  "2.9.0"))
  :url "https://github.com/kidd/git-msg-prefix.el"
  :commit "43f6b31c1090371260a2f15b2117a7666920bee7"
  :revdesc "43f6b31c1090"
  :keywords '("vc" "tools")
  :authors '(("Raimon Grau" . "raimonster@gmail.com"))
  :maintainers '(("Raimon Grau" . "raimonster@gmail.com")))
