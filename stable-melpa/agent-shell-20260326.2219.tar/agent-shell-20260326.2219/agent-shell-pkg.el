;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260326.2219"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "9515f83129432ebfbb85a4b2710b7a98fad2f16a"
  :revdesc "9515f8312943")
