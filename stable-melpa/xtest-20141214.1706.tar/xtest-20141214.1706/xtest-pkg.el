;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xtest" "20141214.1706"
  "Simple Testing with Emacs & ERT."
  '((cl-lib "0.5"))
  :url "https://github.com/promethial/xtest"
  :commit "8099be9c2d856f98489834ddb20a01c6fd8922f1"
  :revdesc "8099be9c2d85"
  :keywords '("testing" "ert"))
