;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md-ts-mode" "20260904.930"
  "Major mode for Markdown using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/dnouri/md-ts-mode"
  :commit "e593fdeef5b8a9805c33af1f35041b5d501398ee"
  :revdesc "e593fdeef5b8"
  :keywords '("markdown" "languages" "tree-sitter")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
