(define-package "tmux-pane" "20200730.520" "Provide integration between emacs window and tmux pane"
  '((names "0.5")
    (emacs "24")
    (s "0"))
  :commit "923524efe8e6e5e0d269de6bb253b45e02d9a663" :keywords
  '("convenience" "terminals" "tmux" "window" "pane" "navigation" "integration")
  :url "https://github.com/laishulu/emacs-tmux-pane")
;; Local Variables:
;; no-byte-compile: t
;; End:
