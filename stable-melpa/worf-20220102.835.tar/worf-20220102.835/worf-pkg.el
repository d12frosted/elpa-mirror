;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "worf" "20220102.835"
  "A warrior does not press so many keys! (in org-mode)."
  '((swiper   "0.11.0")
    (ace-link "0.1.0")
    (hydra    "0.13.0")
    (zoutline "0.1.0"))
  :url "https://github.com/abo-abo/worf"
  :commit "8681241e118585824cd256e5b026978bf06c7e58"
  :revdesc "8681241e1185"
  :keywords '("lisp")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
