;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260228.2227"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "24.4")
    (dash  "2.9.0"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "8c97b2afc2c7940f377a192dbcff51f6a44f664e"
  :revdesc "8c97b2afc2c7"
  :keywords '("programming"))
