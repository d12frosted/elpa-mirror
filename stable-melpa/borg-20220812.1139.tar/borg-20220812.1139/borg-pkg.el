(define-package "borg" "20220812.1139" "Assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "d3cdc176ee72e3e3feac6dd6b527cff5dcf788eb" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
