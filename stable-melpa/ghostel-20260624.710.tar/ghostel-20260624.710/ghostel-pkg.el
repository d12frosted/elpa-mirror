;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260624.710"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "162cb0fa0fa24df2c92e4287e1307a0a6d570b8f"
  :revdesc "162cb0fa0fa2"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
