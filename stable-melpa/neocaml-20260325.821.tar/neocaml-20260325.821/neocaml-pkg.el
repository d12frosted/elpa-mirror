;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260325.821"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "963225f74f1af7ae1a8a23b9b2356be6952688ee"
  :revdesc "963225f74f1a"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
