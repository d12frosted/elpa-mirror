(define-package "srfi" "20210902.626" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "021239f0e2bcc60257b72916db9cdd110588ec28" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
