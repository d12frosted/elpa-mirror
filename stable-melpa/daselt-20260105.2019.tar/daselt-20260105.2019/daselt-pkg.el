;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260105.2019"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "5bdba90f2600fbe4c0ddf75d8b190fc9218a5476"
  :revdesc "5bdba90f2600"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
