;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20260718.226"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "400899b6636ff849138725354de18d59096487f7"
  :revdesc "400899b6636f"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
