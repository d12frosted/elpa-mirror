;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260721.1255"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "73123c8ae88695c93ea6e3421cffdc874cf01998"
  :revdesc "73123c8ae886"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
