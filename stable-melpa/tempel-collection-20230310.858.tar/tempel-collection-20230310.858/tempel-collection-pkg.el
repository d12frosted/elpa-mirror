(define-package "tempel-collection" "20230310.858" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "eeae3ba92612f09d468ac0bd8a15d979c54f8a0c" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
