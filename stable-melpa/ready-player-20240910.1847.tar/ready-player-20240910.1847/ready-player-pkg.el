(define-package "ready-player" "20240910.1847" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "1ad6fdc88e39bc83237b1e95188986a910be4943" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
