;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251026.1739"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "45caa062ce6723beb4acdfaf7084317c1077d4f9"
  :revdesc "45caa062ce67"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
