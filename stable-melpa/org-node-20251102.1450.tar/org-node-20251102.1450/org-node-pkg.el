;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20251102.1450"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "0379d1ac3cf22bef908fcfefec491b2971e38bb5"
  :revdesc "0379d1ac3cf2"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
