;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250416.2036"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "7568a2b88a972fcb33fdeb483c3cda410b99351d"
  :revdesc "7568a2b88a97"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
