;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cond-let" "20260117.2222"
  "Additional and improved binding conditionals."
  '((emacs "28.1"))
  :url "https://github.com/tarsius/cond-let"
  :commit "fdd6dd0a8c7a5d3f4c116946cab0f5921d438c2e"
  :revdesc "fdd6dd0a8c7a"
  :keywords '("extensions"))
