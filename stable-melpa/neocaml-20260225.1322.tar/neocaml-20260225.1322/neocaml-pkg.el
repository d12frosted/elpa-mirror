;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260225.1322"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "6ee2fcb1a9f14a3d0534950fed5c4a2a649a25e0"
  :revdesc "6ee2fcb1a9f1"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
