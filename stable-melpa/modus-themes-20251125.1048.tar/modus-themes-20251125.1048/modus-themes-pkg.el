;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251125.1048"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "1d0348fc64cfa9b6232b1325d73d55b6ff66ac84"
  :revdesc "1d0348fc64cf"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
