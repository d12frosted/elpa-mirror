(define-package "zk-index" "20230712.1103" "Index for zk"
  '((emacs "27.1")
    (zk "0.3"))
  :commit "5be59ca972f3f624d444b7b7d7ca75a06bcd2ce5" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/zk")
;; Local Variables:
;; no-byte-compile: t
;; End:
