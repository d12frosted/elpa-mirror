;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swift-mode" "20260510.540"
  "Major-mode for Apple's Swift programming language."
  '((emacs "25.2"))
  :url "https://github.com/swift-emacs/swift-mode"
  :commit "5782bb9ab0773b5c6abddc23a14b82e5356cc2db"
  :revdesc "5782bb9ab077"
  :keywords '("languages" "swift")
  :authors '(("taku0" . "mxxouy6x3m_github@tatapa.org")
             ("Chris Barrett" . "chris.d.barrett@me.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.com")
             ("Arthur Evstifeev" . "lod@pisem.net"))
  :maintainers '(("taku0" . "mxxouy6x3m_github@tatapa.org")))
