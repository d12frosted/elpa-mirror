;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cg" "20250430.943"
  "Major mode for editing Constraint Grammar files."
  '((emacs "26.1"))
  :url "https://edu.visl.dk/constraint_grammar.html"
  :commit "68d8d64703893d649b974b21af946b143f08a369"
  :revdesc "68d8d6470389"
  :keywords '("languages")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
