;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk" "20260704.2129"
  "Functions for working with Zettelkasten-style linked notes."
  '((emacs "28.1"))
  :url "https://github.com/localauthor/zk"
  :commit "c7039f3c74b32e5a6f548453aebb4f73bd29b572"
  :revdesc "c7039f3c74b3"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
