;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "20261009.2254"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "f5deabe3b490fa72365922ce76f6df3dd0b5a27c"
  :revdesc "f5deabe3b490"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
