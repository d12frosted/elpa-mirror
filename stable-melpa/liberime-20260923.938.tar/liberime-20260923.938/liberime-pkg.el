;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260923.938"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "61997ed192afa3a107c4cfe70c28f145e7368388"
  :revdesc "61997ed192af"
  :keywords '("convenience" "chinese" "input-method" "rime"))
