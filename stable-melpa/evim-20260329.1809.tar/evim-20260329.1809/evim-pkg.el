;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evim" "20260329.1809"
  "Evil Visual Multi - Multiple cursors for evil-mode."
  '((emacs "27.1")
    (evil  "1.14.0"))
  :url "https://github.com/Prgebish/evim"
  :commit "00dcc04bd41b3b4f276b077d29af376838471dee"
  :revdesc "00dcc04bd41b"
  :keywords '("convenience" "emulations")
  :authors '(("Vadim Pavlov" . "vadim198527@gmail.com"))
  :maintainers '(("Vadim Pavlov" . "vadim198527@gmail.com")))
