;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260715.552"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "812f4976fdfd204397aa670f6b9ef063fd46e652"
  :revdesc "812f4976fdfd"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
