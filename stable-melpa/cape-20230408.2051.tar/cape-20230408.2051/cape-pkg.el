(define-package "cape" "20230408.2051" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "2c2fa7f04a72590e82971c91e7617efcc7044cf6" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
