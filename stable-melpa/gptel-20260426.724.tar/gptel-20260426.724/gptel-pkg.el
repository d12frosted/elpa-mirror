;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260426.724"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "ecdf179b0bdcf0f9e74fe8fb1d9bc2d457adf844"
  :revdesc "ecdf179b0bdc"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
