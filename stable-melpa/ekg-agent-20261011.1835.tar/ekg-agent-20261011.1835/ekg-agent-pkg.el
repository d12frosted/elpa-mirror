;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20261011.1835"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.10.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "e326c19bb88e5afa5dd289635dcdfd9c6c1deebe"
  :revdesc "e326c19bb88e"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
