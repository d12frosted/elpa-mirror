(define-package "electric-ospl" "20230325.1518" "Electric OSPL Mode"
  '((emacs "26.1"))
  :commit "55fa59592d0d3e929bd8646ea691a592965a167a" :authors
  '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers
  '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainer
  '("Samuel W. Flint" . "swflint@flintfam.org")
  :keywords
  '("convenience" "text")
  :url "https://git.sr.ht/~swflint/electric-ospl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
