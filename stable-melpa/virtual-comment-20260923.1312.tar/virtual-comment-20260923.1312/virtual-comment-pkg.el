;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtual-comment" "20260923.1312"
  "Virtual Comments."
  '((emacs "26.1"))
  :url "https://github.com/thanhvg/emacs-virtual-comment"
  :commit "cfc627ccf5abe8ef0492652f9d6024612b2dc226"
  :revdesc "cfc627ccf5ab"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
