;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xresources-theme" "20261012.838"
  "Use your .Xresources as your emacs theme."
  ()
  :url "https://github.com/martenlienen/xresources-theme"
  :commit "3637f56a6ae06cdf1335ba3c14927e2f9b9ffc9c"
  :revdesc "3637f56a6ae0"
  :keywords '("xresources" "theme")
  :authors '(("Marten Lienen" . "marten.lienen@gmail.com"))
  :maintainers '(("Marten Lienen" . "marten.lienen@gmail.com")))
