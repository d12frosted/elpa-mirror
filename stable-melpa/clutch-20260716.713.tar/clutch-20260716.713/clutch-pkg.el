;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260716.713"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "e019f292800f8f1782eaa7d8368979420451a598"
  :revdesc "e019f292800f"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
