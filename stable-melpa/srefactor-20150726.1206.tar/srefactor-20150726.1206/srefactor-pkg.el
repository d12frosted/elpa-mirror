(define-package "srefactor" "20150726.1206" "A refactoring tool based on Semantic parser framework"
  '((emacs "24.4"))
  :commit "ecd40713f736b243285c07f4cfd77113794d4f9f" :authors
  '(("Tu, Do Hoang" . "tuhdo1710@gmail.com"))
  :maintainer
  '("Tu, Do Hoang")
  :keywords
  '("c" "languages" "tools")
  :url "https://github.com/tuhdo/semantic-refactor")
;; Local Variables:
;; no-byte-compile: t
;; End:
