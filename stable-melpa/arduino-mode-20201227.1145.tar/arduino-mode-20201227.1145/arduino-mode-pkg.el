(define-package "arduino-mode" "20201227.1145" "Major mode for editing Arduino code"
  '((emacs "25.1")
    (spinner "1.7.3"))
  :commit "b1bd5655937037554058465a6a2aefe47afed382" :maintainer
  ("stardiviner" . "numbchild@gmail.com")
  :keywords
  ("languages" "arduino")
  :url "https://github.com/stardiviner/arduino-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
