;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260621.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "fb0b04fe6c6c46ad59f8691668339f53c6d9da57"
  :revdesc "fb0b04fe6c6c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
