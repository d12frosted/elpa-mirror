;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bufferfile" "20260314.1907"
  "Rename/Delete/Copy Files and Associated Buffers."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/bufferfile.el"
  :commit "9130b90849f3c8f0f77918ba06c18cb144d93afa"
  :revdesc "9130b90849f3"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
