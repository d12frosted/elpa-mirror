(define-package "chee" "20171123.2230" "Interface to chee using dired and image-dired"
  '((dash "2.12.1")
    (s "1.10.0")
    (f "0.18.2"))
  :commit "beeaa5bb2ce92f1a745440c7ff7468e5f6524701" :url "https://github.com/eikek/chee/tree/release/0.3.0/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
