(define-package "cl-format" "20160413.45" "CL format routine." 'nil :commit "4380cb8009c47cc6d9098b383082b93b1aefa460")
;; Local Variables:
;; no-byte-compile: t
;; End:
