(define-package "fsharp-mode" "20211229.1121" "Support for the F# programming language"
  '((emacs "25")
    (s "1.3.1"))
  :commit "f6dec45d4c53c6193e61b299d0bf686567bf7f3b" :authors
  '(("1993-1997 Xavier Leroy, Jacques Garrigue and Ian T Zimmerman")
    ("2010-2011 Laurent Le Brun" . "laurent@le-brun.eu")
    ("2012-2014 Robin Neatherway" . "robin.neatherway@gmail.com")
    ("2017-2021 Jürgen Hötzel"))
  :maintainer
  '("Jürgen Hötzel")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
