(define-package "helm" "20240826.703" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "4.0")
    (wfnames "1.2"))
  :commit "c4d35c3c56ab770845f86d762298cc49dd97acff" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
