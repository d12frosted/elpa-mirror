;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-rhythmbox" "20160524.1158"
  "Control Rhythmbox's play queue via Helm."
  '((helm   "1.5.0")
    (cl-lib "0.5"))
  :url "https://github.com/mrBliss/helm-rhythmbox"
  :commit "c92e1ded34ddd4e62e7e9a558259c232e05193fa"
  :revdesc "c92e1ded34dd"
  :authors '(("Thomas Winant" . "dewinant@gmail.com"))
  :maintainers '(("Thomas Winant" . "dewinant@gmail.com")))
