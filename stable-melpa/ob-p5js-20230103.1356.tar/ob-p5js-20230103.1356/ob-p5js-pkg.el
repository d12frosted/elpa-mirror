(define-package "ob-p5js" "20230103.1356" "Support for p5js in org-babel"
  '((emacs "25.1"))
  :commit "c9f89c8b588cdb0c021a875b8f9fc91be7e39de8" :authors
  '(("Alejandro Gallo" . "aamsgallo@gmail.com"))
  :maintainers
  '(("Alejandro Gallo" . "aamsgallo@gmail.com"))
  :maintainer
  '("Alejandro Gallo" . "aamsgallo@gmail.com")
  :keywords
  '("javascript" "graphics" "multimedia" "p5js" "processing" "org-babel")
  :url "https://github.com/alejandrogallo/p5js")
;; Local Variables:
;; no-byte-compile: t
;; End:
