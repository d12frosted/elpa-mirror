;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260202.1649"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7d6aae0ac0086baaad4b7bc73b55eb991cc85ac3"
  :revdesc "7d6aae0ac008")
