(define-package "doom-modeline" "20220305.1637" "A minimal and modern mode-line"
  '((emacs "25.1")
    (all-the-icons "2.2.0")
    (shrink-path "0.2.0")
    (dash "2.11.0"))
  :commit "d902ce6620efdfb02e0ed8a506b41692b6e3bc0b" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
