;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250618.2124"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "841dae06defe1b5717f6102cd7dbaf9685a48abc"
  :revdesc "841dae06defe"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
