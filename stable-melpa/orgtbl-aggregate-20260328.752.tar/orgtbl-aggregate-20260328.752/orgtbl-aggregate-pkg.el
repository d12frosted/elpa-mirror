;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260328.752"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "a4e5669944e863d8edea63462b3de235dc11e7ea"
  :revdesc "a4e5669944e8"
  :keywords '("data" "extensions"))
