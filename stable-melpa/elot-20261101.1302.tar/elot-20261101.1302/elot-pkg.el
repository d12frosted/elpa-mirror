;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elot" "20261101.1302"
  "Emacs Literate Ontology Tool (ELOT)."
  '((emacs "30.1"))
  :url "https://github.com/johanwk/elot"
  :commit "33841c94352083b5372602858a9071e78d890400"
  :revdesc "33841c943520"
  :keywords '("languages" "outlines" "tools" "org" "ontology")
  :authors '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com"))
  :maintainers '(("Johan W. Klüwer" . "johan.w.kluwer@gmail.com")))
