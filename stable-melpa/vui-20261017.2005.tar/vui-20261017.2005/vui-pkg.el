;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261017.2005"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "16ed4e5545de0dcc9996f857b2c08fb7b5617288"
  :revdesc "16ed4e5545de"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
