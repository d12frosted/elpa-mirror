(define-package "meow" "20220430.2010" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "0f85569e9561c791608803cf019bdbf7d60a389d" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
