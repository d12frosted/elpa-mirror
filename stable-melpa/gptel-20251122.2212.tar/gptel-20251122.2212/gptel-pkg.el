;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251122.2212"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "6d9e4b8f8aebd79b8bb3742f051feb1e70eebd88"
  :revdesc "6d9e4b8f8aeb"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
