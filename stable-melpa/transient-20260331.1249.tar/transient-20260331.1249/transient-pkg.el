;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260331.1249"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "30.1")
    (cond-let "0.2")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "03c016db94392b3e1107a3f6265c91f6e1fe21e6"
  :revdesc "03c016db9439"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
