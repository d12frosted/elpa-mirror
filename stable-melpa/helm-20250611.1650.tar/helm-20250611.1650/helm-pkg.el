;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250611.1650"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.3")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "9abefea54206c6494f85da3b2f1eebd935801bc5"
  :revdesc "9abefea54206"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
