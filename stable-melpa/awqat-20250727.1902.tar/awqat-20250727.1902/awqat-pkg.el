;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awqat" "20250727.1902"
  "Islamic prayer times."
  '((emacs "27.1")
    (s     "1.13.0")
    (alert "1.2"))
  :url "https://github.com/zkry/awqat"
  :commit "52754b230c5796eb9c8aaeda87083855c4235f32"
  :revdesc "52754b230c57"
  :authors '(("Zachary Romero" . "zacromero@posteo.net"))
  :maintainers '(("Zachary Romero" . "zacromero@posteo.net")))
