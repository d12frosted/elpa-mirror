;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cloak-mode" "20260309.1455"
  "A minor mode to cloak sensitive values."
  '((emacs "27.1"))
  :url "https://github.com/erickgnavar/cloak-mode"
  :commit "ba182aafebe901aeb33f879058381866d0076186"
  :revdesc "ba182aafebe9"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
