(define-package "buffer-env" "20230929.613" "Buffer-local process environments"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "a15b608a3ef14db902803405f792b13f367ed24d" :authors
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers
  '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainer
  '("Augusto Stoffel" . "arstoffel@gmail.com")
  :keywords
  '("processes" "tools")
  :url "https://github.com/astoff/buffer-env")
;; Local Variables:
;; no-byte-compile: t
;; End:
