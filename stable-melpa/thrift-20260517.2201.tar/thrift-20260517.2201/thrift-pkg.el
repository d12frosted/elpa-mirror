;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260517.2201"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "672071b5dd8f32d41774b877501bfbc50661e9eb"
  :revdesc "672071b5dd8f"
  :keywords '("languages"))
