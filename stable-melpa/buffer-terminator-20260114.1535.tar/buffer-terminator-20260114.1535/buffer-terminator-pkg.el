;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260114.1535"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "543c96ff73e38f51543747aee4665649525b0cf2"
  :revdesc "543c96ff73e3"
  :keywords '("convenience"))
