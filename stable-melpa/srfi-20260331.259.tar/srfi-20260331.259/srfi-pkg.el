;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260331.259"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "052d487da3c6039463d682ddb5e80ce108b3b0e7"
  :revdesc "052d487da3c6"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
