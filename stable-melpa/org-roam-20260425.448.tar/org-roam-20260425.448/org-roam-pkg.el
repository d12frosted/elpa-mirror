;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam" "20260425.448"
  "A database abstraction layer for Org-mode."
  '((emacs         "26.1")
    (compat        "30.1")
    (org           "9.6")
    (emacsql       "4.1.0")
    (magit-section "3.0.0"))
  :url "https://github.com/org-roam/org-roam"
  :commit "6c1e65cc54e9fddd57c99494344a90bf950de5a6"
  :revdesc "6c1e65cc54e9"
  :keywords '("org-mode" "roam" "convenience")
  :authors '(("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainers '(("Jethro Kuan" . "jethrokuan95@gmail.com")))
