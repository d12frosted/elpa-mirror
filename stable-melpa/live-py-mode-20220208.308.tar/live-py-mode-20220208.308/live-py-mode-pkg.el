(define-package "live-py-mode" "20220208.308" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "df88bbde1d63abd59275301fc072d2bc9a360ad8" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
