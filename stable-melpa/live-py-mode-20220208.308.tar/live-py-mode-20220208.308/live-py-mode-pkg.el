(define-package "live-py-mode" "20220208.308" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "9d310b173c4128fdd7da876cd84b9ef888567773" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
