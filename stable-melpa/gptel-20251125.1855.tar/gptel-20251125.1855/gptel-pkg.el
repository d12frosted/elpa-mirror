;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251125.1855"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "8195d2f4a1a6de73ddbd8593ce7667c541ad713c"
  :revdesc "8195d2f4a1a6"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
