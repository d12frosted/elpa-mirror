(define-package "emacsql" "20230224.1201" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "7c533fb6c27c3a10b6ab05bddf663e37c109e459" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
