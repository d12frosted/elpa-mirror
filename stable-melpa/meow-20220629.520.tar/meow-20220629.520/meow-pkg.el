(define-package "meow" "20220629.520" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "dcc705b7aba3b7a194fb7f44923ab4a6ef0e0cf9" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
