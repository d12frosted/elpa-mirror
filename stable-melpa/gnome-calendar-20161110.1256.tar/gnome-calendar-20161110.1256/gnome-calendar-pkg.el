;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnome-calendar" "20161110.1256"
  "Integration with the GNOME Shell calendar."
  ()
  :url "https://github.com/NicolasPetton/gnome-calendar.el"
  :commit "668591bec95c23934c5e1ef100cec4824e7cb25d"
  :revdesc "668591bec95c"
  :keywords '("gnome" "calendar")
  :authors '(("Nicolas Petton" . "nicolas@petton.fr"))
  :maintainers '(("Nicolas Petton" . "nicolas@petton.fr")))
