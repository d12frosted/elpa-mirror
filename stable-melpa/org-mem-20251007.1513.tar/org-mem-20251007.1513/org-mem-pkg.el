;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20251007.1513"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.8")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "6bb9a0cc628750dcfb711bf38c196a68514ec8e9"
  :revdesc "6bb9a0cc6287"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
