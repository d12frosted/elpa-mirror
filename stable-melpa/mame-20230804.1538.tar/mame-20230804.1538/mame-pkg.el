(define-package "mame" "20230804.1538" "A MAME front-end"
  '((emacs "27.1"))
  :commit "2793335a9901bba6071abb94f5124d94c04343a5" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
