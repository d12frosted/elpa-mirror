;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260712.1054"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "fc4ccb86687c9f1bd65c8d0f07f36fcae381307f"
  :revdesc "fc4ccb86687c"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
