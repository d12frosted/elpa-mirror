;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsrs" "20261128.443"
  "Free Spaced Repetition Scheduler."
  '((emacs "25.1"))
  :url "https://github.com/open-spaced-repetition/lisp-fsrs"
  :commit "cecd530677cfd2e0c620d284f7a05152d5bfaa19"
  :revdesc "cecd530677cf"
  :keywords '("tools"))
