;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260324.203"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "ee855e7308d56bb63333099e35234520c4b108ec"
  :revdesc "ee855e7308d5"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
