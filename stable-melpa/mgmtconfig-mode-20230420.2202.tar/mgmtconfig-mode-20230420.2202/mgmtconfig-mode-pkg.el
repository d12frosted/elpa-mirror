(define-package "mgmtconfig-mode" "20230420.2202" "mgmt configuration management language"
  '((emacs "24.3"))
  :commit "c5efe7a17b5b66a4bf2096b6213998287637c64a" :authors
  '(("Peter Oliver" . "mgmtconfig@mavit.org.uk"))
  :maintainers
  '(("Mgmt contributors <https://github.com/purpleidea/mgmt>"))
  :maintainer
  '("Mgmt contributors <https://github.com/purpleidea/mgmt>")
  :keywords
  '("languages")
  :url "https://github.com/purpleidea/mgmt/misc/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
