;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-zola" "20260506.1952"
  "Org export to Zola static site generator."
  '((emacs   "27.2")
    (ox-hugo "0.8"))
  :url "https://github.com/gicrisf/ox-zola"
  :commit "c6ab97d53b471ed53803e44169ac5d3766d72cbe"
  :revdesc "c6ab97d53b47"
  :keywords '("wp" "hypermedia" "org" "zola")
  :authors '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com")))
