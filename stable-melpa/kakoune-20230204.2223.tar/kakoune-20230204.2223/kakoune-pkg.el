(define-package "kakoune" "20230204.2223" "A simulation, but not emulation, of kakoune"
  '((ryo-modal "0.45")
    (multiple-cursors "1.4")
    (expand-region "0.11.0")
    (emacs "25.1"))
  :commit "212da3adcfaa556cb956e99fa970bd1579c50e4a" :authors
  '(("Joseph Morag" . "jm4157@columbia.edu"))
  :maintainer
  '("Joseph Morag" . "jm4157@columbia.edu")
  :url "https://github.com/jmorag/kakoune.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
