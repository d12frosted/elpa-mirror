;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260201.2116"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "6c9ab433ad526d38b75b11c61275331e6cbf2703"
  :revdesc "6c9ab433ad52"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
