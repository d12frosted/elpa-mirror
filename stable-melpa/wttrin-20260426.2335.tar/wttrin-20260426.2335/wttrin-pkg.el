;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260426.2335"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "537b58c431946ba34146743fc8be4fd671aac6d4"
  :revdesc "537b58c43194"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
