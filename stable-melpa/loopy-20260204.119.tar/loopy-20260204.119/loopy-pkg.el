;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260204.119"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "73d39a0b36fd5f106ee7fb7ec407daa3680ac71d"
  :revdesc "73d39a0b36fd"
  :keywords '("extensions"))
