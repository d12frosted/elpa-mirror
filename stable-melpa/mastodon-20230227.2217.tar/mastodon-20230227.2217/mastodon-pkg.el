(define-package "mastodon" "20230227.2217" "Client for Mastodon, a federated social network"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4")
    (ts "0.3"))
  :commit "88544d10fbc97d4fa1bdc497aad89ac83593b440" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
