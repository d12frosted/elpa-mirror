;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clevercss" "20131229.155"
  "A major mode for editing CleverCSS files."
  ()
  :url "https://github.com/jschaf/CleverCSS-Mode"
  :commit "b8a3c0dd674367c62b1a1ffec84d88fe0c0219bc"
  :revdesc "b8a3c0dd6743"
  :keywords '("languages" "css")
  :authors '(("Joe Schafer" . "(joesmoe10@gmail.com)"))
  :maintainers '(("Joe Schafer" . "(joesmoe10@gmail.com)")))
