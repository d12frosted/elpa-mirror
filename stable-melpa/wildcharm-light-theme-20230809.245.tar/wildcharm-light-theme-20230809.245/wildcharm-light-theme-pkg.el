(define-package "wildcharm-light-theme" "20230809.245" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "8f4daf737a8126e6be781d59ea4bf65b14a8499d" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
