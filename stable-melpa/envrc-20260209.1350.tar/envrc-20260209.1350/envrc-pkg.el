;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "20260209.1350"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "27.1")
    (inheritenv "0.1")
    (seq        "2.24"))
  :url "https://github.com/purcell/envrc"
  :commit "d3289e92e0e2fc39a2be3f3bb382f99a9c5dc8e3"
  :revdesc "d3289e92e0e2"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
