(define-package "kmacro-x" "20230309.2034" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "83b54f219e50049ad7b61230cb8b5afd7467b9c9" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
