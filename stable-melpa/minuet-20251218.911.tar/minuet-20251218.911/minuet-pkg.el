;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20251218.911"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "8ac7e004c598067dad86181c34ca9a20d64ddf49"
  :revdesc "8ac7e004c598"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
