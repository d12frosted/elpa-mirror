(define-package "verb" "20220915.2159" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "f945690276fbf16e65ac97f53ba5da9f8b637546" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
