(define-package "tomatinho" "20180621.1748" "Simple and beautiful pomodoro timer" 'nil :commit "b53354b9b9f496c0388d6a573b06b7d6fc53d0bd" :keywords
  ("time" "productivity" "pomodoro technique")
  :authors
  (("Konrad Scorciapino" . "scorciapino@gmail.com"))
  :maintainer
  ("Konrad Scorciapino" . "scorciapino@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
