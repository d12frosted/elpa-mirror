;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250501.1729"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "5a222a8a6b5e453c762fda8b219102e29e706dde"
  :revdesc "5a222a8a6b5e"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
