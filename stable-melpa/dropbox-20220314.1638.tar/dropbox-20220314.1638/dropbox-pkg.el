;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dropbox" "20220314.1638"
  "Emacs backend for dropbox."
  '((request "0.3.0")
    (json    "1.2")
    (oauth   "1.0.3"))
  :url "https://github.com/pavpanchekha/dropbox.el"
  :commit "c048faad0be24e8fa31974f08b710a87cf5b668c"
  :revdesc "c048faad0be2"
  :keywords '("dropbox")
  :authors '(("Pavel Panchekha" . "me@pavpanchekha.com"))
  :maintainers '(("Pavel Panchekha" . "me@pavpanchekha.com")))
