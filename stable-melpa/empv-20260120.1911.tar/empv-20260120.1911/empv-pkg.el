;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260120.1911"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "89e6c630f28d6eb65890a62954af5ec2b2bbf7b7"
  :revdesc "89e6c630f28d"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
