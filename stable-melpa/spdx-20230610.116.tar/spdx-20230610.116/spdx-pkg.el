(define-package "spdx" "20230610.116" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "12ddafcb939594fb3c6542fc62c2a7da15071055" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
