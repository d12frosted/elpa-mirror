(define-package "green-is-the-new-black-theme" "20210203.1511" "A cool and minimalist green blackened theme engine" 'nil :commit "09f6908064dd1854379a072d7cdd706959256299" :authors
  '(("Fred Campos" . "fred.tecnologia@gmail.com"))
  :maintainers
  '(("Fred Campos" . "fred.tecnologia@gmail.com"))
  :maintainer
  '("Fred Campos" . "fred.tecnologia@gmail.com")
  :keywords
  '("faces" "themes")
  :url "https://github.com/fredcamps/green-is-the-new-black-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
