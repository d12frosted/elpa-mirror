;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark" "20260519.1705"
  "Conveniently act on minibuffer completions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/oantolin/embark"
  :commit "264b039ba78b2fec155971252de270a52c8177aa"
  :revdesc "264b039ba78b"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
