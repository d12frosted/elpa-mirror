;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260107.1344"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "6ca77667449b1e8504065d1e1c59226d95182298"
  :revdesc "6ca77667449b"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
