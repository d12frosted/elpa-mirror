(define-package "doom-modeline" "20220920.1807" "A minimal and modern mode-line"
  '((emacs "25.1")
    (compat "28.1.1.1")
    (shrink-path "0.2.0"))
  :commit "0310e74a92d96c689ed890021a906d56b01a153d" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
