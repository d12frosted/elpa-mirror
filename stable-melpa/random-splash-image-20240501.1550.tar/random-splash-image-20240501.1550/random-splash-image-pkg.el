;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "random-splash-image" "20240501.1550"
  "Randomly sets splash image to *GNU Emacs* buffer on startup."
  ()
  :url "https://github.com/kakakaya/random-splash-image"
  :commit "05a5cdb8315577536de5e425f6ef6cbb994c6282"
  :revdesc "05a5cdb83155"
  :keywords '("games")
  :authors '(("kakakaya" . "kakakayaATgmail.com"))
  :maintainers '(("kakakaya" . "kakakayaATgmail.com")))
