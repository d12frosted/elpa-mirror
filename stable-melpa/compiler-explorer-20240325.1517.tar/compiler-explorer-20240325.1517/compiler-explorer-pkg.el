(define-package "compiler-explorer" "20240325.1517" "Compiler explorer client (godbolt.org)"
  '((emacs "26.1")
    (request "0.3.0"))
  :commit "7f353b086c9d8fe301da483c44fd7317e51bab7b" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("c" "tools")
  :url "https://github.com/mkcms/compiler-explorer.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
