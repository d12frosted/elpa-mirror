;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mandm-theme" "20261012.717"
  "An M&M color theme."
  '((emacs "24.1"))
  :url "https://github.com/choppsv1/emacs-mandm-theme.git"
  :commit "4bec1d6526dfb0563e42b420db5ae71ebc8256b4"
  :revdesc "4bec1d6526df"
  :authors '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainers '(("Christian Hopps" . "chopps@gmail.com")))
