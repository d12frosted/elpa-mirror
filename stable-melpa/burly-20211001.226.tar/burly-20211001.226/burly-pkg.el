(define-package "burly" "20211001.226" "Save and restore frame/window configurations with buffers"
  '((emacs "26.3")
    (map "2.1"))
  :commit "f072d47aeb5a6c3249243889eb147ca23440d4ba" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/burly.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
