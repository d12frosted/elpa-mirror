;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260222.905"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "36107e509f9da67738e38e41531f046cedf67159"
  :revdesc "36107e509f9d"
  :keywords '("convenience" "text"))
