;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-docstring-mode" "20170304.1615"
  "Major mode for editing elisp docstrings."
  ()
  :url "https://github.com/Fuco1/elisp-docstring-mode"
  :commit "b135d95b158048927f12184e5cfb8fe01fc44713"
  :revdesc "b135d95b1580"
  :keywords '("languages")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
