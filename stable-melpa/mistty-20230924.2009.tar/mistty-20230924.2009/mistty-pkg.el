(define-package "mistty" "20230924.2009" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "b92b2bba023579d27ddc828c17b905cde45f2022" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
