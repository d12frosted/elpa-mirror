;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241217.813"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "2de6ac65925a0ff6162211dcdce19d907cfff2a1"
  :revdesc "2de6ac65925a"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
