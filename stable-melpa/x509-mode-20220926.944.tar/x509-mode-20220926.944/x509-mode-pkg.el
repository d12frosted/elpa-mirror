(define-package "x509-mode" "20220926.944" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "933b02832ca2e098f865d2080b9feb058afa008b" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
