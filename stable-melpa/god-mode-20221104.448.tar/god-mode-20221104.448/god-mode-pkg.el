(define-package "god-mode" "20221104.448" "Minor mode for God-like command entering"
  '((emacs "25.1"))
  :commit "c4aea10fb278d5ddbdd047c211444eb1b0b5da60" :authors
  '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainer
  '("Chris Done" . "chrisdone@gmail.com")
  :url "https://github.com/emacsorphanage/god-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
