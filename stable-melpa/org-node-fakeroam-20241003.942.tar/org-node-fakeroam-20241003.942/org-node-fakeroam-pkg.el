;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node-fakeroam" "20241003.942"
  "Stand-ins for org-roam-autosync-mode."
  '((emacs    "28.1")
    (compat   "30")
    (org-node "1.3.7")
    (org-roam "2.2.2")
    (emacsql  "4.0.3"))
  :url "https://github.com/meedstrom/org-node-fakeroam"
  :commit "167ef6b2c284816c28ef42e2aea7ec93a3d3c85f"
  :revdesc "167ef6b2c284"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
