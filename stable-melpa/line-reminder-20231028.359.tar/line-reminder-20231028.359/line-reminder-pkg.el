(define-package "line-reminder" "20231028.359" "Line annotation for changed and saved lines"
  '((emacs "25.1")
    (fringe-helper "1.0.1")
    (ov "1.0.6")
    (ht "2.0"))
  :commit "9e60c92b2495737d25407d79fb3a0e3d9909d5c9" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "annotation")
  :url "https://github.com/emacs-vs/line-reminder")
;; Local Variables:
;; no-byte-compile: t
;; End:
