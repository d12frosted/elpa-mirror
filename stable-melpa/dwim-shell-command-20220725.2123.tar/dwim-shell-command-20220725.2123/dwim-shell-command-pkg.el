(define-package "dwim-shell-command" "20220725.2123" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "848131455a2c3451108386861455e94de81ab9a6" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
