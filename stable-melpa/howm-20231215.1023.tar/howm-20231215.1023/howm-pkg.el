(define-package "howm" "20231215.1023" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "ffb0b18e32b7ccea534a8d75681328272d36714c" :authors
  '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com"))
  :maintainers
  '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com")
  :url "https://kaorahi.github.io/howm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
