(define-package "workroom" "20221128.2001" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0")
    (compat "28.1.2.2"))
  :commit "532835eda02c64a8b93437e8c3fb220e60859896" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
