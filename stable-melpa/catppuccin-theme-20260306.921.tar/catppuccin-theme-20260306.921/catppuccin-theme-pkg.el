;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "catppuccin-theme" "20260306.921"
  "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs."
  '((emacs "27.1"))
  :url "https://github.com/catppuccin/emacs"
  :commit "f5584703ac338767347eb2d59a666fcc8c705be5"
  :revdesc "f5584703ac33"
  :maintainers '(("Jeremy Baxter" . "jeremy@baxters.nz")))
