(define-package "hl-indent-scope" "20221212.2246" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "5fb3e24cd5b8797a0eece0eb24cdfeb586595ffc" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
