;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatu" "20250327.415"
  "Convert and insert any images to org-mode or markdown buffer."
  '((org           "9.6.6")
    (emacs         "29.1")
    (plantuml-mode "1.2.9"))
  :url "https://github.com/kimim/chatu"
  :commit "e74fd4f728756b08f2d01108772d5cc8abc48e61"
  :revdesc "e74fd4f72875"
  :keywords '("multimedia" "convenience")
  :authors '(("Kimi Ma" . "kimi.im@outlook.com"))
  :maintainers '(("Kimi Ma" . "kimi.im@outlook.com")))
