;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260606.1721"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "8b8c9aa1fcd6b1efa435a8ae4164ccb10de72d76"
  :revdesc "8b8c9aa1fcd6"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
