(define-package "modus-themes" "20220502.513" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "493c8e8cc6dbe2c0a4389d40df94540e3a5c96f3" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
