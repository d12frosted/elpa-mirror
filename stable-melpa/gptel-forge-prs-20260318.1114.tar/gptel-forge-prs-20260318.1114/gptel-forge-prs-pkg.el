;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-forge-prs" "20260318.1114"
  "Generate PR descriptions for forge using gptel."
  '((emacs "28.1")
    (magit "4.0")
    (forge "0.3")
    (gptel "0.9"))
  :url "https://github.com/ArthurHeymans/gptel-forge-prs"
  :commit "aed2bbd21a359770a7739f18f34837ec8d0add24"
  :revdesc "aed2bbd21a35"
  :keywords '("forge" "vc" "convenience" "llm" "pull-request"))
