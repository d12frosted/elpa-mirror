(define-package "cnfonts" "20211128.539" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "26a6a259ef0a767846a0823e48b7cec4d9b84fc6" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
