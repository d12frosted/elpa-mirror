;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-gwt" "20261123.620"
  "GWT-style BDD testing for ERT."
  '((emacs "29.4"))
  :url "https://github.com/OverbearingPearl/ert-gwt"
  :commit "c583fb8551fdf3a40c1c989918efb4652b2a38c7"
  :revdesc "c583fb8551fd"
  :keywords '("lisp" "tools")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
