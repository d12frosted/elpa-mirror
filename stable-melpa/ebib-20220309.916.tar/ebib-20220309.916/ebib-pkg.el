(define-package "ebib" "20220309.916" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "68c7c08df1f65c073837c4ce5f3e0374377ce3f9" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
