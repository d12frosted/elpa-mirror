(define-package "khoj" "20230609.1306" "AI personal assistant for your digital brain"
  '((emacs "27.1")
    (transient "0.3.0")
    (dash "2.19.1"))
  :commit "c68cde4803aa1e06ec4b402bdbf4c87e1fb6ee76" :authors
  '(("Debanjum Singh Solanky" . "debanjum@gmail.com"))
  :maintainers
  '(("Debanjum Singh Solanky" . "debanjum@gmail.com"))
  :maintainer
  '("Debanjum Singh Solanky" . "debanjum@gmail.com")
  :keywords
  '("search" "chat" "org-mode" "outlines" "markdown" "pdf" "beancount" "image")
  :url "https://github.com/debanjum/khoj/tree/master/src/interface/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
