(define-package "chatgpt-shell" "20231112.445" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.43.1"))
  :commit "80fb3cff64db39500da2020965dc073162576b01" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
