;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250920.1956"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "18607d8e93d7512e55fe31da5bbee76d60df3cbc"
  :revdesc "18607d8e93d7"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
