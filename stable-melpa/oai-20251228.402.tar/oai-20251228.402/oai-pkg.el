;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20251228.402"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "8449743654f608b1e582be0f105340c337673db6"
  :revdesc "8449743654f6"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
