(define-package "cg" "20230601.1159" "Major mode for editing Constraint Grammar files"
  '((emacs "26.1"))
  :commit "4c92ab6454b03b1bd3829bf79e22cb862fed11b5" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("languages")
  :url "https://visl.sdu.dk/constraint_grammar.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
