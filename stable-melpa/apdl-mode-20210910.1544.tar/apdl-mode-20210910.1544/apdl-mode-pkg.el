(define-package "apdl-mode" "20210910.1544" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "4579047d0073bfca2cf0d9eeed009fd5fe2d85e0" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
