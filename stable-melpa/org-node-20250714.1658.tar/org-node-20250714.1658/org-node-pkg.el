;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250714.1658"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.17.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "33864b1bc10682fa10f86450edb576075de027a9"
  :revdesc "33864b1bc106"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
