(define-package "cycle-at-point" "20220406.1340" "Cycle (rotate) the thing under the cursor"
  '((emacs "28.1")
    (recomplete "0.2"))
  :commit "dca019faf115965d219e9b3126549d8a1a1dbc24" :authors
  '(("Campbell Barton"))
  :maintainer
  '("Campbell Barton")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-cycle-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
