;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250531.2220"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "35b752f00bf22682659350f07b4ea5c2dfb9a36b"
  :revdesc "35b752f00bf2"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
