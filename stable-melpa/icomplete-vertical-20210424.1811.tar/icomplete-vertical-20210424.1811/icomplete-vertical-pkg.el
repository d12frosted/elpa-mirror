(define-package "icomplete-vertical" "20210424.1811" "Display icomplete candidates vertically"
  '((emacs "26.1"))
  :commit "d7ab5e5de18a027375666755e6610ea26c35ac16" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
