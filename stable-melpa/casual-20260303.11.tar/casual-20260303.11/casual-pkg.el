;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260303.11"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "0b04ad703efad2a53a3c756c02784e819d0f8b4e"
  :revdesc "0b04ad703efa"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
