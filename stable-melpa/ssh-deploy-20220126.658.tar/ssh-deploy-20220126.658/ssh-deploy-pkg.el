(define-package "ssh-deploy" "20220126.658" "Deployment via Tramp, global or per directory."
  '((emacs "25"))
  :commit "9311f9b4f8d25ce54fb7da9bf59d955fed366a4d" :authors
  '(("Christian Johansson" . "christian@cvj.se"))
  :maintainer
  '("Christian Johansson" . "christian@cvj.se")
  :keywords
  '("tools" "convenience")
  :url "https://github.com/cjohansson/emacs-ssh-deploy")
;; Local Variables:
;; no-byte-compile: t
;; End:
