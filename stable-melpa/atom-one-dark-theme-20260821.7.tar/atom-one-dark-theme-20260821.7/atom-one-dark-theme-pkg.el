;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atom-one-dark-theme" "20260821.7"
  "Atom One Dark color theme."
  ()
  :url "https://github.com/jonathanchu/atom-one-dark-theme"
  :commit "93234950f980d1f305d52fa82d426ad837715648"
  :revdesc "93234950f980"
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
