(define-package "haki-theme" "20230814.1414" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "bfa02d87b8b56965fbcc84d2662799a8e78198f6" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
