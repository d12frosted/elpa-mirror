;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260411.356"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a91b0a4c68071d7f43ce2f4be53f3eade6e65493"
  :revdesc "a91b0a4c6807"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
