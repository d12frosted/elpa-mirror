;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-summary-ext" "20180113.1316"
  "Extra limit and process mark commands for the gnus summary buffer."
  ()
  :url "https://github.com/vapniks/gnus-summary-ext"
  :commit "025fd853fe9280ae696a89ec2c2cac9befd010aa"
  :revdesc "025fd853fe92"
  :keywords '("comm")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
