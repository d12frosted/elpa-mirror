(define-package "howm" "20211230.1221" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "c381e50f0c771c38306bda37bd972a37a36a5db5" :authors
  '(("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
