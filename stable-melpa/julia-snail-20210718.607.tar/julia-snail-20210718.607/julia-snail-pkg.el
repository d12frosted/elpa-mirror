(define-package "julia-snail" "20210718.607" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (vterm "0.0.1"))
  :commit "fa5133be0a641883a17a559f27484b0672f80d28" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
