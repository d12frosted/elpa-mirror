(define-package "hl-indent-scope" "20221227.1151" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "fb86583e95453d685e626a06f63c8fdbfeb6d2f4" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
