;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-multi-all-the-icons" "20251004.2121"
  "Affixate `compile-multi' with icons."
  '((emacs                    "28.0")
    (all-the-icons-completion "0.0.1"))
  :url "https://github.com/mohkale/compile-multi"
  :commit "2976058c416b19f9761d5b8cf596210803afd2d7"
  :revdesc "2976058c416b"
  :keywords '("tools" "compile" "build")
  :authors '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("mohsin kaleem" . "mohkale@kisara.moe")))
