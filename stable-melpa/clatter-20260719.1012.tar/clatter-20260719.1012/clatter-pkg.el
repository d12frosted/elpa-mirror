;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260719.1012"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "b10547ca89e51914f5b43e85e5c9f4c67be6294b"
  :revdesc "b10547ca89e5"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
