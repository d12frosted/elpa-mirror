;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-mode" "20251121.6"
  "Major mode for General Algebraic Modeling System (GAMS)."
  '((emacs "25.1"))
  :url "https://github.com/ShiroTakeda/gams-mode"
  :commit "796feef9d9ea68b6a351b8dbb56878dd4d0a9730"
  :revdesc "796feef9d9ea"
  :keywords '("languages" "tools" "gams"))
