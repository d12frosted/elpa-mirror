;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20251110.1739"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "5120e98bc97c97dcf7763ee1244ac2d73973fa8b"
  :revdesc "5120e98bc97c")
