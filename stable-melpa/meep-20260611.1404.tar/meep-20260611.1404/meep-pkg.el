;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260611.1404"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "98256024c8729385211f5b1d9a9f2825dda725fc"
  :revdesc "98256024c872"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
