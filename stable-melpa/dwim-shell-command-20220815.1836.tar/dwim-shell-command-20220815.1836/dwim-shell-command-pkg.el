(define-package "dwim-shell-command" "20220815.1836" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "e4c756ce350671ea44e5072dae11af77d76c956c" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
