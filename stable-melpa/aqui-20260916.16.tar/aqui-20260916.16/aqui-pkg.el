;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aqui" "20260916.16"
  "Location update (optimized for macOS)."
  '((emacs   "30.1")
    (restlib "0.1.0"))
  :url "https://github.com/kickingvegas/aqui"
  :commit "8712e3e2ee611459c76dadf3b739be425e40ca28"
  :revdesc "8712e3e2ee61"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
