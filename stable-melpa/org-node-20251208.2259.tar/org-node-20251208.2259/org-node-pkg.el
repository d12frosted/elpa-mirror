;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20251208.2259"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "7e471062209f199878f4076040d9f212d88c0322"
  :revdesc "7e471062209f"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
