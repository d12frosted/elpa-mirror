;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guake" "20221029.1811"
  "Interact with Guake via DBus."
  '((emacs "27.1"))
  :url "https://github.com/juergenhoetzel/emacs-guake"
  :commit "2753ce833b95bd1f042ac0e4b7adfe34975a88ed"
  :revdesc "2753ce833b95"
  :keywords '("convenience")
  :authors '(("Jürgen Hötzel" . "juergen.hoetzel@hr.de"))
  :maintainers '(("Jürgen Hötzel" . "juergen.hoetzel@hr.de")))
