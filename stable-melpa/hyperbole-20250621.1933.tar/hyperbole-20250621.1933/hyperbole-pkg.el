;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250621.1933"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "d8637ea760a3609b52d64eca92e4c270f8b89f14"
  :revdesc "d8637ea760a3"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
