;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leadkey" "20260614.1622"
  "Translate leader keys to key sequences."
  '((emacs "30.1"))
  :url "https://github.com/jixiuf/emacs-leadkey"
  :commit "04d9dfde7dcfbd06d6dbd63bc2294cf91430029c"
  :revdesc "04d9dfde7dcf"
  :keywords '("convenience")
  :authors '(("jixiuf" . "https://github.com/jixiuf"))
  :maintainers '(("jixiuf" . "https://github.com/jixiuf")))
