;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261120.2120"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.19.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "0328d65a356051fde079b8ca8e29aa58cc5935cd"
  :revdesc "0328d65a3560"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
