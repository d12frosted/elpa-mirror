;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vmd-mode" "20210524.27"
  "Fast Github-flavored Markdown preview using a vmd subprocess."
  '((emacs "24.3"))
  :url "https://github.com/blak3mill3r/vmd-mode"
  :commit "b2bdf2ab54f8fc37780e6b473e4ad69c0e9ff4a6"
  :revdesc "b2bdf2ab54f8"
  :keywords '("markdown" "preview" "live" "vmd")
  :authors '(("Blake Miller" . "blak3mill3r@gmail.com"))
  :maintainers '(("Blake Miller" . "blak3mill3r@gmail.com")))
