;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20251215.1517"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "4bd9f37abed70e446c9b5c0fd164a63e6e2644a9"
  :revdesc "4bd9f37abed7"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
