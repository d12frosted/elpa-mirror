;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260714.1212"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "d75ae93b738fd92f6e3ba480898e89b5c4a44ff1"
  :revdesc "d75ae93b738f"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
