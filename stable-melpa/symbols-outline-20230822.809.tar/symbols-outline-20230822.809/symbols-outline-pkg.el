(define-package "symbols-outline" "20230822.809" "Display symbols (functions, variables, etc) in outline view"
  '((emacs "27.1"))
  :commit "642883677ed1b2a83c0801b8260980e9ad3edd49" :authors
  '(("Shihao Liu"))
  :maintainers
  '(("Shihao Liu"))
  :maintainer
  '("Shihao Liu")
  :keywords
  '("outlines")
  :url "https://github.com/liushihao456/symbols-outline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
