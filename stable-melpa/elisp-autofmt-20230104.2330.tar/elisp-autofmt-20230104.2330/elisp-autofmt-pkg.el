(define-package "elisp-autofmt" "20230104.2330" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "1e3ee9f3ba8aa50d5867d3beaf70949b0679e469" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
