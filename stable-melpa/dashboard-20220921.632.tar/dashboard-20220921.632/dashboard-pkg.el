(define-package "dashboard" "20220921.632" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "3a7205f4bc55b304421aea8d36366159c0f05fe5" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
