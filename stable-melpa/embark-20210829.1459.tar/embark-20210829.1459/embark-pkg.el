(define-package "embark" "20210829.1459" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "25be10cca5dc5c9354e99d0aca41ad0db80e7aac" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
