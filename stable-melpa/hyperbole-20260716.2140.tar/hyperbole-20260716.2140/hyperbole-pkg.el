;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260716.2140"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ac03a74dd61f2f672d44d0b46f437fa06a7d7fd0"
  :revdesc "ac03a74dd61f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
