(define-package "spdx" "20230426.109" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "debcb52a42518428fb0b1168b07a88681ed002c2" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
