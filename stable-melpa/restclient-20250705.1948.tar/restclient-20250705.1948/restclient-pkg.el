;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restclient" "20250705.1948"
  "An interactive HTTP client for Emacs."
  '((emacs "26.1"))
  :url "https://github.com/emacsorphanage/restclient"
  :commit "438ce85bb7fb42e3b6bd42e1b8bb2a7f26b22180"
  :revdesc "438ce85bb7fb"
  :keywords '("http" "comm" "tools")
  :authors '(("Pavel Kurnosov" . "pashky@gmail.com"))
  :maintainers '(("Peder O. Klingenberg" . "peder@klingenberg.no")))
