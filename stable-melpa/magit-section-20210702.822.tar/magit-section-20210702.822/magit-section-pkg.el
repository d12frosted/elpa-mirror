(define-package "magit-section" "20210702.822" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210330"))
  :commit "d3a729b19f269f843ea9e18454cc489a2ebc4822" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
