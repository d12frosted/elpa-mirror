(define-package "magit-section" "20210702.822" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210330"))
  :commit "70206b2de2aa650e8d3b287f8275adbf562a8eba" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
