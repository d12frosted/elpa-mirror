(define-package "magit-section" "20210702.822" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210330"))
  :commit "023b2fc28336c8e972ddd07fbf4b46c3999243b1" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
