(define-package "magit-section" "20210702.822" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210330"))
  :commit "e4556f037b8b5ed0c8d6c389e1278c008088009b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
