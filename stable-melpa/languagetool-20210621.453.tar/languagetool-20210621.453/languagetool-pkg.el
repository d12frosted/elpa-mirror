(define-package "languagetool" "20210621.453" "LanguageTool integration for grammar and spell check"
  '((emacs "25.1")
    (request "0.3.2"))
  :commit "feea3f9271ce920490a0d9dcd11e669e3eaad1d0" :authors
  '(("Joar Buitrago" . "jebuitragoc@unal.edu.co"))
  :maintainer
  '("Joar Buitrago" . "jebuitragoc@unal.edu.co")
  :keywords
  '("grammar" "text" "docs" "tools" "convenience" "checker")
  :url "https://github.com/PillFall/Emacs-LanguageTool.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
