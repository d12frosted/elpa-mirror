;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261102.1417"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "c17bbbcc890561a0b7a5bfb761642343f515cdb2"
  :revdesc "c17bbbcc8905"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
