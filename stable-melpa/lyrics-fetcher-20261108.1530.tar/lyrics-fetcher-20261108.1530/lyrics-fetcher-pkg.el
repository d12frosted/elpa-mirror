;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lyrics-fetcher" "20261108.1530"
  "Fetch song lyrics and album covers."
  '((emacs   "27")
    (emms    "7.5")
    (f       "0.20.0")
    (request "0.3.2"))
  :url "https://github.com/SqrtMinusOne/lyrics-fetcher.el"
  :commit "59a3b37e0fb3e72067367aa637745a561031009f"
  :revdesc "59a3b37e0fb3"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
