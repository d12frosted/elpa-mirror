(define-package "elisp-autofmt" "20230820.648" "Emacs lisp auto-format"
  '((emacs "29.1"))
  :commit "fb280f362a1ef5015841ac6b97697cba9784d86c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
