(define-package "robe" "20210521.2132" "Code navigation, documentation lookup and completion for Ruby"
  '((inf-ruby "2.5.1")
    (emacs "24.4"))
  :commit "763547a1e6fcaefb5e827ae07770b81978f560da" :authors
  '(("Dmitry Gutov"))
  :maintainer
  '("Dmitry Gutov")
  :keywords
  '("ruby" "convenience" "rails")
  :url "https://github.com/dgutov/robe")
;; Local Variables:
;; no-byte-compile: t
;; End:
