;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash" "20260223.1905"
  "Flash-style navigation."
  '((emacs "27.1"))
  :url "https://github.com/Prgebish/flash"
  :commit "f0915960739d79c0a94a2c4a1f5d1e3e3e927a5e"
  :revdesc "f0915960739d"
  :keywords '("convenience" "navigation")
  :authors '(("Vadim Pavlov" . "https://github.com/Prgebish"))
  :maintainers '(("Vadim Pavlov" . "https://github.com/Prgebish")))
