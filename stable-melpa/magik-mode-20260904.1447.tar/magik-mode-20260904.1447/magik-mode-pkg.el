;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260904.1447"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "7ddf1e4d62609fa807057d369d64c47a76a2aea9"
  :revdesc "7ddf1e4d6260"
  :keywords '("languages"))
