;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcomp" "20260501.1438"
  "Compare version strings."
  '((emacs "26.1"))
  :url "https://github.com/tarsius/vcomp"
  :commit "2227de68c2fc4d7a029bd30d188422429bb18d28"
  :revdesc "2227de68c2fc"
  :keywords '("versions")
  :authors '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
