;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restlib" "20261107.1941"
  "Utility library for building REST clients."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/restlib"
  :commit "d9948b64e53a78d2cdd6e91d05e402c6e9715485"
  :revdesc "d9948b64e53a"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
