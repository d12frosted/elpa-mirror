;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "walkman" "20260515.1746"
  "Write HTTP requests in Org mode."
  '((transient "0.1.0")
    (org       "8.3.5")
    (json-mode "1.6.0")
    (emacs     "26.3"))
  :url "https://github.com/abrochard/walkman"
  :commit "0328a6b8ca98926a4fed88e722eba66ddbc5b0a8"
  :revdesc "0328a6b8ca98"
  :keywords '("walkman" "http" "curl" "org" "comm"))
