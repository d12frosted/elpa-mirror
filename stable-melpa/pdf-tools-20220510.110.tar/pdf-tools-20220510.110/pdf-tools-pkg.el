(define-package "pdf-tools" "20220510.110" "Support library for PDF documents"
  '((emacs "24.3")
    (nadvice "0.3")
    (tablist "1.0")
    (let-alist "1.0.4"))
  :commit "ab61b0472980200f52e2e23782bc07255baebe72" :authors
  '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainer
  '("Vedang Manerikar" . "vedang.manerikar@gmail.com")
  :keywords
  '("files" "multimedia")
  :url "http://github.com/vedang/pdf-tools/")
;; Local Variables:
;; no-byte-compile: t
;; End:
