;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "typespec-ts-mode" "20251227.2213"
  "Major mode for TypeSpec (using tree-sitter)."
  '((emacs "29.1"))
  :url "https://github.com/pradyuman/typespec-ts-mode"
  :commit "fcd43e13568c61772dbb344c6391c2933bd0a72e"
  :revdesc "fcd43e13568c"
  :keywords '("languages" "tree-sitter" "typespec")
  :authors '(("Pradyuman Vig" . "me@pmn.co"))
  :maintainers '(("Pradyuman Vig" . "me@pmn.co")))
