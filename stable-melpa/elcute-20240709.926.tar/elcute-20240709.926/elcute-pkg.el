(define-package "elcute" "20240709.926" "Commands for marking and killing lines electrically"
  '((emacs "29.1"))
  :commit "8d5f38ee656552171c97facb2aec70a4ee142039" :keywords
  '("convenience")
  :url "https://codeberg.org/vilij/slurpbarf-elcute")
;; Local Variables:
;; no-byte-compile: t
;; End:
