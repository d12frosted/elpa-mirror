(define-package "llama" "20240920.1204" "Compact syntax for short lambda"
  '((emacs "26.1"))
  :commit "62b270fc1d062301515cc7309fc2fc33417a61da" :keywords
  '("extensions")
  :url "https://github.com/tarsius/llama")
;; Local Variables:
;; no-byte-compile: t
;; End:
