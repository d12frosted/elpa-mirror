;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261105.1655"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "ab7493d21c54c08b9d9721d33a983b43e714a565"
  :revdesc "ab7493d21c54"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
