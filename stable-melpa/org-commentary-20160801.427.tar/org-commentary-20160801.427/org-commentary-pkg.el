(define-package "org-commentary" "20160801.427" "generate or update conventional library headers using Org mode files"
  '((dash "2.0")
    (emacs "24.4")
    (org "8.0"))
  :commit "2eeeb0f506e30ef82263e67279d837a79cbde021" :authors
  '(("Sergei Maximov" . "s.b.maximov@gmail.com"))
  :maintainer
  '("Sergei Maximov" . "s.b.maximov@gmail.com")
  :keywords
  '("convenience" "docs" "tools")
  :url "https://github.com/smaximov/org-commentary")
;; Local Variables:
;; no-byte-compile: t
;; End:
