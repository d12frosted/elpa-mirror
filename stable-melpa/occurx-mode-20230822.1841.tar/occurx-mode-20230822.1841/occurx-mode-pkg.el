;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occurx-mode" "20230822.1841"
  "Occur-like filtering of buffers with rx patterns."
  '((emacs "27.1")
    (rbit  "0.1"))
  :url "https://github.com/k32/occurx-mode"
  :commit "71ecab6b1cdf6159a02cef3dd7d2610c45cbaf02"
  :revdesc "71ecab6b1cdf"
  :keywords '("matching"))
