(define-package "x509-mode" "20230818.634" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1")
    (compat "29.1.4.2"))
  :commit "fa9245fade7762c5550bac5608125dc64c93769e" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
