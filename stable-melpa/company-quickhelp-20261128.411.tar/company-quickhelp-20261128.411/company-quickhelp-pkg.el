;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-quickhelp" "20261128.411"
  "Popup documentation for completion candidates."
  '((emacs   "24.3")
    (company "1.1.0")
    (pos-tip "0.4.6"))
  :url "https://www.github.com/expez/company-quickhelp"
  :commit "bb4c3284440a6b4b9f10fe0446169a135ae2ca3c"
  :revdesc "bb4c3284440a"
  :keywords '("company" "popup" "documentation" "quickhelp")
  :authors '(("Lars Andersen" . "expez@expez.com"))
  :maintainers '(("Lars Andersen" . "expez@expez.com")))
