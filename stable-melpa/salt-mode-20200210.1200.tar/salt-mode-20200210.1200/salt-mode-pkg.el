;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "salt-mode" "20200210.1200"
  "Major mode for Salt States."
  '((emacs      "24.4")
    (yaml-mode  "0.0.12")
    (mmm-mode   "0.5.4")
    (mmm-jinja2 "0.1"))
  :url "https://github.com/glynnforrest/salt-mode"
  :commit "e76e78d93e4770d42bdde9367a11d0e0836a21c9"
  :revdesc "e76e78d93e47"
  :keywords '("languages")
  :authors '(("Ben Hayden" . "hayden767@gmail.com"))
  :maintainers '(("Glynn Forrest" . "me@glynnforrest.com")))
