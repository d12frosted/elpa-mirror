;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260501.40"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/elfeed"
  :commit "40f64ea8d8a43e6d05f696fb7ba6d287a567cea3"
  :revdesc "40f64ea8d8a4"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
