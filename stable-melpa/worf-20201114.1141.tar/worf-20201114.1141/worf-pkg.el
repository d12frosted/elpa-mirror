(define-package "worf" "20201114.1141" "A warrior does not press so many keys! (in org-mode)"
  '((swiper "0.11.0")
    (ace-link "0.1.0")
    (hydra "0.13.0")
    (zoutline "0.1.0"))
  :commit "a341c87ab6e696968436b38c1c34488d50764f48" :keywords
  ("lisp")
  :authors
  (("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  ("Oleh Krehel" . "ohwoeowho@gmail.com")
  :url "https://github.com/abo-abo/worf")
;; Local Variables:
;; no-byte-compile: t
;; End:
