(define-package "detached" "20220525.1709" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "11dbd0a990f51c310bb119ae713b0ca7b10efe82" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
