(define-package "meow" "20220210.1521" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "1729d897ee6e6bb12b599663e65ed3550589060b" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
