;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260209.1615"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "3f4d0fa11e63f415afaebf9b7352edafe494b5d8"
  :revdesc "3f4d0fa11e63"
  :keywords '("convenience"))
