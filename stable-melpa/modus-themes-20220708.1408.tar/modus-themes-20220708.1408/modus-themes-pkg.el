(define-package "modus-themes" "20220708.1408" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "2860a94f78154dfdd0b2d01bdf0af7992195f34c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
