(define-package "snakemake-mode" "20201224.1744" "Major mode for editing Snakemake files"
  '((emacs "24.5")
    (cl-lib "0.5")
    (magit-popup "2.4.0"))
  :commit "c657cfacc0201c7c298d7987b5b6a62b4d4a2284" :authors
  '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainer
  '("Kyle Meyer" . "kyle@kyleam.com")
  :keywords
  '("tools")
  :url "https://git.kyleam.com/snakemake-mode/about")
;; Local Variables:
;; no-byte-compile: t
;; End:
