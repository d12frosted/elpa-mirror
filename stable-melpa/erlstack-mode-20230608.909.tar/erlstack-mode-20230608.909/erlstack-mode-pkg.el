;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlstack-mode" "20230608.909"
  "Minor mode for analysing Erlang stacktraces."
  '((emacs "25.1")
    (dash  "2.12.0"))
  :url "https://github.com/k32/erlstack-mode"
  :commit "51e3cd10a2fe77eb8eb60643aba6f8178374b069"
  :revdesc "51e3cd10a2fe"
  :keywords '("tools" "erlang"))
