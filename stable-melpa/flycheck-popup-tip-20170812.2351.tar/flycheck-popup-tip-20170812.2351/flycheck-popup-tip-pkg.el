;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-popup-tip" "20170812.2351"
  "Display Flycheck error messages using popup.el."
  '((flycheck "0.22")
    (popup    "0.5")
    (emacs    "24"))
  :url "https://github.com/flycheck/flycheck-popup-tip/"
  :commit "ef86aad907f27ca076859d8d9416f4f7727619c6"
  :revdesc "ef86aad907f2"
  :keywords '("convenience" "tools" "flycheck" "tooltip")
  :authors '(("Saša Jovanić" . "sasa@simplify.ba"))
  :maintainers '(("Saša Jovanić" . "sasa@simplify.ba")))
