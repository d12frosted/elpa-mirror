;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20241102.921"
  "Copilot chat interface."
  '((request       "0.3.2")
    (markdown-mode "2.6")
    (emacs         "27.1")
    (chatgpt-shell "1.6.1")
    (magit         "4.0.0"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "3750ee87f08e3cea722c6ee712b9a2719574ec89"
  :revdesc "3750ee87f08e"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
