(define-package "mybigword" "20220526.1438" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "25.1"))
  :commit "ffbfa2a938a58c4e60ccc4c2ec0ae32a11eac485" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
