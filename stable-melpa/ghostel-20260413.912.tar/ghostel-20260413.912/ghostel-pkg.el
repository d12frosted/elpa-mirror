;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260413.912"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "cee26014ffbe73bc1211f8f5960717d7e5a3f9fa"
  :revdesc "cee26014ffbe"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
