(define-package "cnfonts" "20211225.406" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "e522eb680eae90254c22186ffc0f2bf5457945fd" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
