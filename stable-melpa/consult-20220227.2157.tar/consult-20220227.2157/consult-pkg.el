(define-package "consult" "20220227.2157" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9c90e35f5833d6fd1ab281c3cc9c4b78d8459b41" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
