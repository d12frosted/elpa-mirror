(define-package "consult" "20220227.2157" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "a33e057daaea57de384198e51d03f418877845c6" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
