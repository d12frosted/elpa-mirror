(define-package "consult" "20220227.2157" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "afe7992b84c4f501980af7be1cfd03e359b470cf" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
