;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260509.310"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "cc41e33ecd2505bf1b01f731798bc0adca83d491"
  :revdesc "cc41e33ecd25"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
