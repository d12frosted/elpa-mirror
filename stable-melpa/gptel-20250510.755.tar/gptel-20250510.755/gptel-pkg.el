;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250510.755"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "b891789c05d9e7b17c535d2d1a35392c3058808d"
  :revdesc "b891789c05d9"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
