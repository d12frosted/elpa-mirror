(define-package "libbcel" "20191216.641" "Library to connect to basecamp 3 API"
  '((emacs "26.1")
    (request "0.3.1"))
  :commit "1c73379d1462c54125480a79efe6cac1db929857" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://gitlab.petton.fr/bcel/libbcel")
;; Local Variables:
;; no-byte-compile: t
;; End:
