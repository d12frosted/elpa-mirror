;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20261012.908"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "aa9e9241284be0744aa2439ee756d8a027e5de72"
  :revdesc "aa9e9241284b"
  :keywords '("languages"))
