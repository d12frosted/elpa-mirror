;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20260925.1500"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "dc5f05b03e2d3fd57313861c91b616ec51e17aff"
  :revdesc "dc5f05b03e2d"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
