;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260214.1809"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "92eabdb6e473df70c7dd7343ed21ef0b435f15fc"
  :revdesc "92eabdb6e473"
  :keywords '("comm")
  :authors '(("Patrick Thomson" . "patrickt@github.com"))
  :maintainers '(("Patrick Thomson" . "patrickt@github.com")))
