(define-package "chatgpt-shell" "20231112.304" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.43.1"))
  :commit "f6c3bafe38a2ff2e43b1d0e7e0ba45bed9664733" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
