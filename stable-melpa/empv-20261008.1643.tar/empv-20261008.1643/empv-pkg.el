;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20261008.1643"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "8bc6a572a0f1b3be6ac02d6fd08e2ad0cc1942ec"
  :revdesc "8bc6a572a0f1"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
