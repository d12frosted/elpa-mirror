;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260515.1725"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "03d91d6533fdaf826f14886c81156a647dbfb7e3"
  :revdesc "03d91d6533fd"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
