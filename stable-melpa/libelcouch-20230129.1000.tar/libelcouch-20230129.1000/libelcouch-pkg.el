(define-package "libelcouch" "20230129.1000" "Communication with CouchDB"
  '((emacs "26.1")
    (request "0.3.0"))
  :commit "595697f4199519dd018fe489e885f237c54b0675" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("tools")
  :url "https://gitlab.petton.fr/elcouch/libelcouch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
