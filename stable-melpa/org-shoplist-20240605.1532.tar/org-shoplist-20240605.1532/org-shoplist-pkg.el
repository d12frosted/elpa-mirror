(define-package "org-shoplist" "20240605.1532" "Eat the world"
  '((emacs "25"))
  :commit "b7378a2b7032cd6388439d0a4fbc1f347d82c1c1" :authors
  '(("lordnik22"))
  :maintainers
  '(("lordnik22"))
  :maintainer
  '("lordnik22")
  :keywords
  '("extensions" "matching")
  :url "https://github.com/lordnik22")
;; Local Variables:
;; no-byte-compile: t
;; End:
