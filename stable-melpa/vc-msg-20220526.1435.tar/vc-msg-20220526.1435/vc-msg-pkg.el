(define-package "vc-msg" "20220526.1435" "Show commit information of current line"
  '((emacs "24.4")
    (popup "0.5.0"))
  :commit "153f493a50e64263bcfd5210c47bbeeac8a68a01" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("git" "vc" "svn" "hg" "messenger")
  :url "http://github.com/redguardtoo/vc-msg")
;; Local Variables:
;; no-byte-compile: t
;; End:
