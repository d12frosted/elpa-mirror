(define-package "eldev" "20220825.1958" "Elisp development tool"
  '((emacs "24.4"))
  :commit "9b3f351a7234901958d8bc4fc4623268aadb904b" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
