;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260219.2226"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "0758795ae8d43974983d19dee56398cd8c31a0cd"
  :revdesc "0758795ae8d4"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
