;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pandoc-mode" "20251029.902"
  "Minor mode for interacting with Pandoc."
  ()
  :url "http://joostkremers.github.io/pandoc-mode/"
  :commit "bc9abbc078ab3dfb7411a5a27aba0212bd27c6eb"
  :revdesc "bc9abbc078ab"
  :keywords '("text" "pandoc")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
