;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20261103.1619"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "38e919fdc68be7e925bbc1510d9814723ca98908"
  :revdesc "38e919fdc68b"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
