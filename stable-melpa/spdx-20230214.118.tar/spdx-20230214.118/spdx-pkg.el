(define-package "spdx" "20230214.118" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "e3ff5d9c6431149cebeefa1071ccd4fc1c079595" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
