(define-package "cnfonts" "20211206.50" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "46f710405c2614cc4285f2c6aad22c477b731353" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
