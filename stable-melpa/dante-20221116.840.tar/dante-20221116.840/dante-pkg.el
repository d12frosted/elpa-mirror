(define-package "dante" "20221116.840" "Development mode for Haskell"
  '((dash "2.12.0")
    (emacs "27.1")
    (f "0.19.0")
    (flycheck "0.30")
    (company "0.9")
    (flymake "1.0")
    (s "1.11.0")
    (lcr "1.5"))
  :commit "914d4f21252a66fe526abedebe24703bc73397d9" :authors
  '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainers
  '(("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com"))
  :maintainer
  '("Jean-Philippe Bernardy" . "jeanphilippe.bernardy@gmail.com")
  :keywords
  '("haskell" "tools")
  :url "https://github.com/jyp/dante")
;; Local Variables:
;; no-byte-compile: t
;; End:
