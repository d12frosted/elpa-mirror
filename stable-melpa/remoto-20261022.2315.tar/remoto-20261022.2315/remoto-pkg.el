;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261022.2315"
  "Browse GitHub repos without cloning."
  '((emacs "29.1")
    (ghub  "4.0.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "db53bb63ed29662d3d8e5b1cbdfa3f1cb947b127"
  :revdesc "db53bb63ed29"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
