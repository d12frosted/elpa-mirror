(define-package "apheleia" "20231129.1926" "Reformat buffer stably"
  '((emacs "27"))
  :commit "fe27888c6b3f546054b00e7da0b65f2f2f5d5d20" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
