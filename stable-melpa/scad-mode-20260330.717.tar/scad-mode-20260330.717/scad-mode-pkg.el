;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "20260330.717"
  "A major mode for editing OpenSCAD code."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "44481331536516e34940315f67fa58f99f62a589"
  :revdesc "444813315365"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
