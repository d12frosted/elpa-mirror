;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251031.251"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "a6ac58f9603b70a8582dd7a8af974d0f5cc3b7ab"
  :revdesc "a6ac58f9603b"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
