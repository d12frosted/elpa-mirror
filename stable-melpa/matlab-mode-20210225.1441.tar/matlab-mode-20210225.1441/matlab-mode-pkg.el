(define-package "matlab-mode" "20210225.1441" "Major mode for MATLAB(R) dot-m files" 'nil :commit "00e25f897c56c91a18bb821cd502270cad91fa0c")
;; Local Variables:
;; no-byte-compile: t
;; End:
