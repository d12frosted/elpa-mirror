;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ben" "20260617.1102"
  "Asynchronous buffer-local environments via `direnv'."
  '((emacs      "29.1")
    (inheritenv "0.1")
    (seq        "2.24"))
  :url "https://codeberg.org/pastor/ben.el"
  :commit "259f76f83efb03220e60bd799fb17fc49bddcda0"
  :revdesc "259f76f83efb"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com")
             ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")
                 ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
