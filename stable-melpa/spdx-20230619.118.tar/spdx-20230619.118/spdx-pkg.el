(define-package "spdx" "20230619.118" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "5c3374cb5b54159e20b658d4f0728db94e4389e1" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
