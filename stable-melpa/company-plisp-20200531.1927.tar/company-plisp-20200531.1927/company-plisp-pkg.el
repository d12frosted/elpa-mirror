(define-package "company-plisp" "20200531.1927" "Company mode backend for PicoLisp language"
  '((emacs "25")
    (s "1.2.0")
    (company "0.8.12")
    (dash "2.12.0")
    (cl-lib "0.5"))
  :commit "0e6941e1832faafb2176238339667edd482acd95" :authors
  '(("Fermin MF" . "fmfs@posteo.net"))
  :maintainer
  '("Fermin MF" . "fmfs@posteo.net")
  :keywords
  '("company" "plisp" "convenience" "auto-completion")
  :url "https://gitlab.com/sasanidas/company-plisp")
;; Local Variables:
;; no-byte-compile: t
;; End:
