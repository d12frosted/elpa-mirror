;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly-overlay" "20240828.910"
  "Overlay Common Lisp evaluation results."
  '((emacs "24.4")
    (sly   "1.0"))
  :url "https://github.com/fosskers/sly-overlay"
  :commit "d62945059035f8097a6f222ed2700cfd99609d11"
  :revdesc "d62945059035"
  :keywords '("lisp")
  :authors '(("Colin Woodbury" . "colin@fosskers.ca"))
  :maintainers '(("Colin Woodbury" . "colin@fosskers.ca")))
