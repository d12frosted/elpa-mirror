(define-package "helm-core" "20220503.622" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "24d6d9264689b7cb9fcedecde50c8f6eb5751538" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
