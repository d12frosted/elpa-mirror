;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260226.1128"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "0581530b665ea5c4b07ef84c47de957881924ae6"
  :revdesc "0581530b665e"
  :keywords '("data" "extensions"))
