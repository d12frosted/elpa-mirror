;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261114.2055"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "276ddadba70f80958687753c3a1ab604b9dbcd8c"
  :revdesc "276ddadba70f"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
