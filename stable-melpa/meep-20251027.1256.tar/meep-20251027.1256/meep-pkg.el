;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251027.1256"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "e02be1d565a4dfe82b1c5625167b4be8f86ce3e8"
  :revdesc "e02be1d565a4"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
