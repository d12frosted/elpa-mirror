(define-package "lister" "20210925.1423" "Yet another list printer"
  '((emacs "26.1"))
  :commit "9a806d3171101f5b379d524d0aac9eecea3de0de" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
