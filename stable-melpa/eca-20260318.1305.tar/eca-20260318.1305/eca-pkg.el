;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260318.1305"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "95ed4b496e39fe772a03ff4bf5d6737fd8ae7b34"
  :revdesc "95ed4b496e39"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
