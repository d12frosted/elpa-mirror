;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20261109.1253"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "9212fa7734264a8b980508f5b4f3438f21334afc"
  :revdesc "9212fa773426"
  :keywords '("erlang" "languages" "processes"))
