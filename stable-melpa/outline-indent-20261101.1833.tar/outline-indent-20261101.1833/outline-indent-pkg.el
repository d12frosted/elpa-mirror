;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20261101.1833"
  "Folding text based on indentation (origami alternative)."
  '((emacs    "26.1")
    (kirigami "1.0.5"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "8e45ae2d8c98cf0dfe30217461e2a7bc778640a1"
  :revdesc "8e45ae2d8c98"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
