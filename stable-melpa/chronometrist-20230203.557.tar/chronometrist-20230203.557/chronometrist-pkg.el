(define-package "chronometrist" "20230203.557" "Friendly and powerful personal time tracker and analyzer"
  '((emacs "27.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "f131e996320715238e8403439a18dbc016b09520" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
