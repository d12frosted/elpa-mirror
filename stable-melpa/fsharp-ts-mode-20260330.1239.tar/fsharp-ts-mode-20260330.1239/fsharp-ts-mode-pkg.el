;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsharp-ts-mode" "20260330.1239"
  "Major mode for F# code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/fsharp-ts-mode"
  :commit "7d1ddcdb31cb243191ad46b4c6c48b2f9f7a0783"
  :revdesc "7d1ddcdb31cb"
  :keywords '("languages" "fsharp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
