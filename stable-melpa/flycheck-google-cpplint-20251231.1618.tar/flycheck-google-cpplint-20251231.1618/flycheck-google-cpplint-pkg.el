;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-google-cpplint" "20251231.1618"
  "Help to comply with the Google C++ Style Guide."
  '((emacs    "27.1")
    (flycheck "0.20-cvs1"))
  :url "https://github.com/flycheck/flycheck-google-cpplint/"
  :commit "cf9d93a89073c3259fcebd46a7bdf1c0b4733b41"
  :revdesc "cf9d93a89073"
  :keywords '("flycheck" "c" "c++")
  :authors '(("Akiha Senda" . "senda.akiha@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
