;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260607.204"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "f799130938ef6a313ee49ce89552b4eb84917a15"
  :revdesc "f799130938ef"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
