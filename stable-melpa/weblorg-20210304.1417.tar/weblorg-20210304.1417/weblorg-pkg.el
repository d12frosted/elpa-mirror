(define-package "weblorg" "20210304.1417" "Static Site Generator for org-mode"
  '((templatel "0.1.5")
    (emacs "26.1"))
  :commit "ca8356130050e86767e75a290d70b97d20eee795" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
