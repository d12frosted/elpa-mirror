(define-package "outlook" "20180321.1921" "send emails in MS Outlook style"
  '((emacs "24.4"))
  :commit "5847c6f13b106cb54529080e9050be5b8b5be867" :authors
  '(("Andrew Savonichev"))
  :maintainer
  '("Andrew Savonichev")
  :keywords
  '("mail")
  :url "https://github.com/asavonic/outlook.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
