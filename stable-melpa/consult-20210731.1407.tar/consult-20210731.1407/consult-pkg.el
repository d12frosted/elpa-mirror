(define-package "consult" "20210731.1407" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "8adc66a37707b4616b59282cc6dbece7bbfbb272" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
