(define-package "helm-core" "20220704.1741" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "2a2a142fdfb004e2f93157468e101e780fb0c550" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
