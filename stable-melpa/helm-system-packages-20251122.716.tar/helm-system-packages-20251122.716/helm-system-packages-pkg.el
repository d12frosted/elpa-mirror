;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "20251122.716"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "7c90184b1ed962f09c6e81043ae66e4c555be00b"
  :revdesc "7c90184b1ed9"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
