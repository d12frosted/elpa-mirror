(define-package "memento-mori" "20190628.2147" "Reminder of mortality"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "52f95bd4cf6617b60dc204c9bccb8d8fa17d4f9e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("help")
  :url "https://github.com/lassik/emacs-memento-mori")
;; Local Variables:
;; no-byte-compile: t
;; End:
