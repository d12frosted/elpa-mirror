(define-package "wand" "20210511.725" "Magic wand for Emacs - Select and execute"
  '((dash "2.15.0")
    (s "0.1.1"))
  :commit "08c3d9156517a31dd98ea64bfc269fae730b643c" :authors
  '(("Ha-Duong Nguyen <cmpitgATgmail>"))
  :maintainer
  '("Ha-Duong Nguyen <cmpitgATgmail>")
  :keywords
  '("extensions" "tools")
  :url "https://github.com/cmpitg/wand")
;; Local Variables:
;; no-byte-compile: t
;; End:
