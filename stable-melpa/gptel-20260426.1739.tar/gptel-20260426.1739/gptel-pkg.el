;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260426.1739"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "260bc5980535be6e3b83efb1b82c75cf1ba47d65"
  :revdesc "260bc5980535"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
