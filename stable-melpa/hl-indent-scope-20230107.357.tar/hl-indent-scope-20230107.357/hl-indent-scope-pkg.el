(define-package "hl-indent-scope" "20230107.357" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "627eaf25011985e8c7de107cbcfa9a701f1a6632" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
