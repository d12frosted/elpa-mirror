(define-package "fennel-mode" "20211122.1847" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "54ed0792d0ac43a2d5db39741cf070c627368419" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://gitlab.com/technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
