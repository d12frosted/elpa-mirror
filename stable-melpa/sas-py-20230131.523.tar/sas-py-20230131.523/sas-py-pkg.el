;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sas-py" "20230131.523"
  "SAS with SASPy."
  '((emacs "28.1")
    (ess   "18.10.1"))
  :url "https://github.com/ShuguangSun/sas-py"
  :commit "76a2226eb49ec37f211904c6395ee066bd440560"
  :revdesc "76a2226eb49e"
  :keywords '("tools")
  :authors '(("Shuguang Sun" . "shuguang79@qq.com"))
  :maintainers '(("Shuguang Sun" . "shuguang79@qq.com")))
