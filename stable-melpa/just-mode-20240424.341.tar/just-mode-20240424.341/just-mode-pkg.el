(define-package "just-mode" "20240424.341" "Justfile editing mode"
  '((emacs "26.1"))
  :commit "11f5fd232f62b97714344e0aea89d5f815dc539d" :authors
  '(("Leon Barrett" . "leon@barrettnexus.com"))
  :maintainers
  '(("Leon Barrett" . "leon@barrettnexus.com"))
  :maintainer
  '("Leon Barrett" . "leon@barrettnexus.com")
  :keywords
  '("files" "languages" "tools")
  :url "https://github.com/leon-barrett/just-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
