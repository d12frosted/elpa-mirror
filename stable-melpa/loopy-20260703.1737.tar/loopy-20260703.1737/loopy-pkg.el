;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260703.1737"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://codeberg.org/okamsn/loopy"
  :commit "5cd39a76ed340c69f07e7d5116b1df2e297e31cd"
  :revdesc "5cd39a76ed34"
  :keywords '("extensions"))
