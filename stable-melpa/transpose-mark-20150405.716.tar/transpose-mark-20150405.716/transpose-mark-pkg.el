;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transpose-mark" "20150405.716"
  "Transpose data using the Emacs mark."
  ()
  :url "https://github.com/kwrooijen/transpose-mark"
  :commit "667327602004794de97214cf336ac61650ef75b7"
  :revdesc "667327602004"
  :keywords '("transpose" "convenience")
  :authors '(("Kevin W. van Rooijen" . "kevin.van.rooijen@attichacker.com"))
  :maintainers '(("Kevin W. van Rooijen" . "kevin.van.rooijen@attichacker.com")))
