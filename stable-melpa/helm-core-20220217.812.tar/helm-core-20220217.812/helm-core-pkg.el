(define-package "helm-core" "20220217.812" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "f0db55f8b4793f17897071e0f1fae2ac1c4dfe68" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
