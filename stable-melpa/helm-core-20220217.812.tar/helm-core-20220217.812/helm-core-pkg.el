(define-package "helm-core" "20220217.812" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "3b848f4ba2534053fe4dec633b9e762da16679e2" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
