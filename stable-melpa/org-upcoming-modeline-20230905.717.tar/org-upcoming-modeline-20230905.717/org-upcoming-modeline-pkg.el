(define-package "org-upcoming-modeline" "20230905.717" "Show next org event in mode line"
  '((emacs "26.1")
    (ts "0.2")
    (org-ql "0.6"))
  :commit "bacabc9368b11554c04216bd0a9c756ea9fd4ee6" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers
  '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")
  :keywords
  '("convenience" "calendar")
  :url "https://github.com/unhammer/org-upcoming-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
