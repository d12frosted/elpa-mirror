(define-package "apheleia" "20230420.1024" "Reformat buffer stably"
  '((emacs "26"))
  :commit "2d797a52e6e4b778f03324e288be74a425b533a5" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/raxod502/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
