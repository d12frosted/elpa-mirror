(define-package "merlin" "20210720.950" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "ab77e5bdc6bad11f94e7f04fbba21e9c489c76d4" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
