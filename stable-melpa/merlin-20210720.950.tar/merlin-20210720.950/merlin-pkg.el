(define-package "merlin" "20210720.950" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "30e437f65ffca48b962c023b0c9570ad8acd7647" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
