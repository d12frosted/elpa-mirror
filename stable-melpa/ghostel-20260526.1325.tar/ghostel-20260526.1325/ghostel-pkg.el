;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260526.1325"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "43cbfe64ebf2cb4fa4a2c9221cd69b15b1439908"
  :revdesc "43cbfe64ebf2"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
