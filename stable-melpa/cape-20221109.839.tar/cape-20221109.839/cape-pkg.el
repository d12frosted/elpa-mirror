(define-package "cape" "20221109.839" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "4b32036a6c667b445dcc001fd70a01eee8baa924" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
