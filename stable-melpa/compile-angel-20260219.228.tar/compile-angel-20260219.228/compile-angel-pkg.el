;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260219.228"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "eef45ed95775a0bb49837cf9d409a8ed93733d3c"
  :revdesc "eef45ed95775"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
