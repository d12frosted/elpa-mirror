;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exunit" "20260127.1521"
  "ExUnit test runner."
  '((s         "1.11.0")
    (emacs     "24.3")
    (f         "0.20.0")
    (transient "0.3.6")
    (project   "0.9.8"))
  :url "https://github.com/ananthakumaran/exunit.el"
  :commit "bef971bde5634992fc2e4c8436b3feaddd8d7ed6"
  :revdesc "bef971bde563"
  :keywords '("processes" "elixir" "exunit")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
