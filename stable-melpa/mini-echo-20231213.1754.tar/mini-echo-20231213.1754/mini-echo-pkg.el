(define-package "mini-echo" "20231213.1754" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "1db61d51f96cc42e6c75ffbae7cdedf407beebea" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
