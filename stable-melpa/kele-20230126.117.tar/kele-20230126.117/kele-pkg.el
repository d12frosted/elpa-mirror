(define-package "kele" "20230126.117" "Spritzy Kubernetes cluster management"
  '((emacs "28.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (plz "0.3")
    (s "1.13.0")
    (yaml "0.5.1"))
  :commit "2b98b649496ee8326b27d6555696d514ad72de94" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
