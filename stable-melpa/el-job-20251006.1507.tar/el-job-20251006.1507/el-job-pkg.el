;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20251006.1507"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "1a85e885bac1ed90108d7d23d12cc4aab4b0d05e"
  :revdesc "1a85e885bac1"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
