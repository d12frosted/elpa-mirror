;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260427.2355"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "2d0d3294d5277d2d86d6953c8bf4e8fa42e55362"
  :revdesc "2d0d3294d527"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
