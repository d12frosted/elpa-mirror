;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apparmor-mode" "20260505.56"
  "Major mode for editing AppArmor policy files."
  '((emacs "26.1"))
  :url "https://gitlab.com/apparmor/apparmor-mode"
  :commit "55ac8bf85cd859346450d32edc99370e429c6664"
  :revdesc "55ac8bf85cd8"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
