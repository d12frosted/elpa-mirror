;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260729.800"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "71e8f9c49384d78ca868efe41741cece17c2bc6c"
  :revdesc "71e8f9c49384"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
