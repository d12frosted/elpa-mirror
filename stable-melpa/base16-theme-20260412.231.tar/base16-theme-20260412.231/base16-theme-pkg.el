;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260412.231"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "dc3ae1cb5b4790d72124b1bd9ac11dc6669616c3"
  :revdesc "dc3ae1cb5b47"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
