(define-package "consult" "20210116.1558" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f6236b0179254ac7504de002b284a29fa2e58fe5" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
