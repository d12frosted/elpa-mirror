(define-package "cycle-at-point" "20230105.2302" "Cycle (rotate) the thing under the cursor"
  '((emacs "28.1")
    (recomplete "0.2"))
  :commit "6fc81fd111a9134c16bd463d2fd595d09b50a505" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-cycle-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
