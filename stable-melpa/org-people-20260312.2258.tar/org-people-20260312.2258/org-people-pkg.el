;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260312.2258"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "175f41593b631be68662df06b9bd54f89bdf72cd"
  :revdesc "175f41593b63"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
