;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260214.307"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "34ad48b404a91b4e88c750cefce9a53d402d3b70"
  :revdesc "34ad48b404a9"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
