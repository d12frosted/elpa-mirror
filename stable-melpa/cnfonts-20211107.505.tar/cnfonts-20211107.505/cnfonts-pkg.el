(define-package "cnfonts" "20211107.505" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "f8fa0fb305366bbaafae6d5738a87e8e90665d40" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
