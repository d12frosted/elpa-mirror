;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20250224.2257"
  "Miasma: color theme inspired by the woods."
  ()
  :url "http://github.com/daut/miasma-theme.el"
  :commit "9409792050e99f5ddb5c665b5bd78f8fad834472"
  :revdesc "9409792050e9")
