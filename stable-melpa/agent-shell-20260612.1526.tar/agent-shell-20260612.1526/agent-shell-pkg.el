;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260612.1526"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.1")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a07f1fd9027b61d7850ba1a4d0a0cc0e7de7db0f"
  :revdesc "a07f1fd9027b")
