(define-package "chronometrist-key-values" "20220401.632" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "25dd20f170085a913203b524365123c5089e7e2b" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
