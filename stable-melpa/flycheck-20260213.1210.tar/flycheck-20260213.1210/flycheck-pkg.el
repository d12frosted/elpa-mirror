;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260213.1210"
  "On-the-fly syntax checking."
  '((emacs "27.1")
    (seq   "2.24"))
  :url "https://www.flycheck.org"
  :commit "a3e57b179a574bafe4ca6d1f0bd39c0d3d3283ef"
  :revdesc "a3e57b179a57"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
