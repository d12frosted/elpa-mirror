;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-stars" "20260427.2355"
  "Outshine-style star headings for outline-minor-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/phmcc/outline-stars"
  :commit "a08f50d395a1a74406da97b22ab22d72ffc4df51"
  :revdesc "a08f50d395a1"
  :keywords '("outlines" "convenience")
  :authors '(("Paul Hsin-ti McClelland" . "PaulHMcClelland@protonmail.com"))
  :maintainers '(("Paul Hsin-ti McClelland" . "PaulHMcClelland@protonmail.com")))
