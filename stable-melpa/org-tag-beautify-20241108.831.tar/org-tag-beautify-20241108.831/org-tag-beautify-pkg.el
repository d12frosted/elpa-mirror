;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "20241108.831"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "40304a71dee0cd755d7e87d18fd5d54c7d7ed906"
  :revdesc "40304a71dee0"
  :keywords '("hypermedia"))
