(define-package "drupal-mode" "20170926.738" "Advanced minor mode for Drupal development"
  '((php-mode "1.5.0"))
  :commit "49ce63c659aa0af7a2daf0c9e74e58fbce6deb71" :authors
  '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainer
  '("Arne Jørgensen" . "arne@arnested.dk")
  :keywords
  '("programming" "php" "drupal")
  :url "https://github.com/arnested/drupal-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
