;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shellcop" "20220629.817"
  "Analyze info&error in shell-mode."
  '((emacs "25.1"))
  :url "https://github.com/redguardtoo/shellcop"
  :commit "3f051e42288ddfe4cd7cd0ee62efad90227de24b"
  :revdesc "3f051e42288d"
  :keywords '("unix" "tools")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
