;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "heroku-theme" "20150523.219"
  "Heroku color theme."
  ()
  :url "https://github.com/jonathanchu/color-theme-heroku"
  :commit "7c1e80f8b5087c37008fec687070344638cd4752"
  :revdesc "7c1e80f8b508"
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
