;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-languagetool" "20260101.535"
  "Flycheck support for LanguageTool."
  '((emacs    "27.1")
    (flycheck "0.14"))
  :url "https://github.com/emacs-languagetool/flycheck-languagetool"
  :commit "8889414ec50c3c4dfeef601900c63901a55a2237"
  :revdesc "8889414ec50c"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com")
             ("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Peter Oliver" . "git@mavit.org.uk")))
