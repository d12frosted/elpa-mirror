(define-package "good-scroll" "20210612.2058" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "7bbfc12b83ac231294ece1d5795408d99fb284da" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
