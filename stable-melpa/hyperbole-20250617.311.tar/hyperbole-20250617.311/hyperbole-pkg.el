;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250617.311"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "9d2da0f85447e9f6fc716395209a0b78f93e02f6"
  :revdesc "9d2da0f85447"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
