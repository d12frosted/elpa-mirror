;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "r-autoyas" "20140101.1510"
  "Provides automatically created yasnippets for R function argument lists."
  '((ess       "0")
    (yasnippet "0.8.0"))
  :url "https://github.com/mlf176f2/r-autoyas.el"
  :commit "d321a7da0ef2e94668d53e0807277da7b70ea678"
  :revdesc "d321a7da0ef2"
  :keywords '("r" "yasnippet"))
