(define-package "embark" "20220128.1819" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "f29e08a2a8bf15141b1845b610d66452d5057fca" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
