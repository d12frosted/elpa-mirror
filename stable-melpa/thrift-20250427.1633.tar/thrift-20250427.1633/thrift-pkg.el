;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20250427.1633"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "c31185426b963cdbda2839584910c996f954626d"
  :revdesc "c31185426b96"
  :keywords '("languages"))
