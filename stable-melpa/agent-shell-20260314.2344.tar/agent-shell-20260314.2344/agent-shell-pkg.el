;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260314.2344"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ff935495a78af8c93980d07ea34b07f8a268e705"
  :revdesc "ff935495a78a")
