(define-package "org-modern" "20240429.959" "Modern looks for Org"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "e9cfb3e2018e7c8c6504216660988b786f70b0d3" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "text")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
