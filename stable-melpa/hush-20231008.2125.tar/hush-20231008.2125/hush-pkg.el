;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hush" "20231008.2125"
  "Pluggable secret manager (auth-source alternative)."
  '((emacs "27.1"))
  :url "https://github.com/tirimia/hush"
  :commit "51c7960820de0576bbf0c3c286cb1264854d20aa"
  :revdesc "51c7960820de"
  :keywords '("extensions" "lisp" "local" "tools"))
