;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260608.706"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "fcf17e32ed675d42f8679fd443216fdf44a6bbc2"
  :revdesc "fcf17e32ed67"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
