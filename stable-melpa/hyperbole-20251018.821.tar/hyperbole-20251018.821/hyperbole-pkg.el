;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251018.821"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "0b829ed0e1e03765deca2b0c4f6e44b25c1997f5"
  :revdesc "0b829ed0e1e0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
