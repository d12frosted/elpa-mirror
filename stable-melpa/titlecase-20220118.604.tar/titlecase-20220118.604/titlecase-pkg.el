(define-package "titlecase" "20220118.604" "Title-case phrases"
  '((emacs "25.1"))
  :commit "d82f3d23c166db1c3ea9ae25adaf43d1eeb748dc" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://github.com/duckwork/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
