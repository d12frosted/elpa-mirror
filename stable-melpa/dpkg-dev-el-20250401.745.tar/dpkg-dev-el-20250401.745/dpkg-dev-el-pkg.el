;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dpkg-dev-el" "20250401.745"
  "Startup file for the elpa-dpkg-dev-el package."
  '((emacs     "27.1")
    (debian-el "37.0"))
  :commit "ce30b11acdf44f262bd0fd59074bdb87ef7484bc"
  :revdesc "ce30b11acdf4"
  :authors '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers '(("Peter S Galbraith" . "psg@debian.org")))
