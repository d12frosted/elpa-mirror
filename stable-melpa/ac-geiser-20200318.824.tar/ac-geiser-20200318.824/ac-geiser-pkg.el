;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-geiser" "20200318.824"
  "Emacs auto-complete backend for geiser."
  ()
  :url "https://github.com/xiaohanyu/ac-geiser"
  :commit "93818c936ee7e2f1ba1b315578bde363a7d43d05"
  :revdesc "93818c936ee7")
