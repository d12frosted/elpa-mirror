(define-package "buttercup" "20220619.2214" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "42df1faa653f2765941f478167dafac059dc3a57" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
