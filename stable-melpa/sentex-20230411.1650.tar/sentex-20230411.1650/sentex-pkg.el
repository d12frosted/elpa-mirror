;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sentex" "20230411.1650"
  "Regex-based sentence navigation rules."
  '((emacs "27.1"))
  :url "https://codeberg.org/martianh/sentex"
  :commit "ab96ee0e9856222aaad6b085cf4ca0c5dda73789"
  :revdesc "ab96ee0e9856"
  :keywords '("languages" "convenience" "translation" "sentences" "text" "wp")
  :authors '(("Marty Hiatt" . "martianhiatusATriseup.net"))
  :maintainers '(("Marty Hiatt" . "martianhiatusATriseup.net")))
