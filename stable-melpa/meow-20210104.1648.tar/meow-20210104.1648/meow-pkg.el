(define-package "meow" "20210104.1648" "Modal Editing On Wheel"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1")
    (s "1.12.0"))
  :commit "fbdcdf8dafb7ac435e8d3df06869f27223684421" :authors
  (("Shi Tianshu"))
  :maintainer
  ("Shi Tianshu")
  :keywords
  ("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
