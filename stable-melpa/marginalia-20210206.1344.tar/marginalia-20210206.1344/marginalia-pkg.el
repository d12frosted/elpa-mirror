(define-package "marginalia" "20210206.1344" "Enrich existing commands with completion annotations"
  '((emacs "26.1"))
  :commit "dcdcd5d615f2721118062328c23643897a0b18bc" :authors
  '(("Omar Antolín Camarena, Daniel Mendler"))
  :maintainer
  '("Omar Antolín Camarena, Daniel Mendler")
  :url "https://github.com/minad/marginalia")
;; Local Variables:
;; no-byte-compile: t
;; End:
