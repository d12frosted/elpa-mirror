(define-package "embark" "20210819.1048" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "bc4c179dd6611cd1fe3bed4d57871d77e1e4ef95" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
