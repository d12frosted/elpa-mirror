(define-package "projection" "20230529.1441" "Project type support for `project'"
  '((emacs "29")
    (project "0.9.8")
    (compat "29.1.4.1"))
  :commit "fb1de86f84bc0d46dbe6bbebf4bbf5880a56bdb9" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
