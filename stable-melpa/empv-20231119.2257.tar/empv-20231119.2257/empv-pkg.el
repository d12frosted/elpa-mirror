(define-package "empv" "20231119.2257" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0")
    (compat "29.1.4.4"))
  :commit "7826725fdd1c6c2416f0de76bb0b5ee10d39035a" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
