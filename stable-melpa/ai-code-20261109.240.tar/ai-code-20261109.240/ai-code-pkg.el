;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261109.240"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "495ec1e8f54898a97238e578412d0948fe9ed36c"
  :revdesc "495ec1e8f548"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
