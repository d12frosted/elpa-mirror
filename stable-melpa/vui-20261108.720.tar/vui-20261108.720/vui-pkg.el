;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261108.720"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "9e9ffa2f631cf5f99ef28bccc1a667922ddd71c5"
  :revdesc "9e9ffa2f631c"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
