(define-package "live-py-mode" "20230430.1540" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "c927feefa62f4ce9b3b5029063f9654a317267ef" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainers
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
