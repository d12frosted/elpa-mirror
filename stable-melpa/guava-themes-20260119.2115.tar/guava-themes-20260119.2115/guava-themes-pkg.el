;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260119.2115"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "http://github.com/bormoge/guava-themes"
  :commit "983154f6922571b2cb34730808d6b396417b10ba"
  :revdesc "983154f69225"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
