;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20251217.2049"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "b16fe8da14a90ee785d77d8c8c2af94df39a04bd"
  :revdesc "b16fe8da14a9"
  :keywords '("convenience" "comm" "hypermedia"))
