;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251009.1806"
  "BLUE build system interface."
  '((emacs "30.1"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "9cd313a345d974726ae286ca8baffc86d1f6379f"
  :revdesc "9cd313a345d9"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
