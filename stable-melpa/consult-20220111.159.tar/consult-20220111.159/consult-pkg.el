(define-package "consult" "20220111.159" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "12bc660313d28e81a18f5c89699cbe4149f52c45" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
