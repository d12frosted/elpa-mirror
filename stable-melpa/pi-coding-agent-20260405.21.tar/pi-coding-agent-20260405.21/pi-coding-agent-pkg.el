;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260405.21"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (md-ts-mode          "0.3.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "ce067c80306616cc7c3bdf38f4c32c1a1d276e57"
  :revdesc "ce067c803066"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
