;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260513.611"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "312cee75e36684e13f562d702da2c30879573bca"
  :revdesc "312cee75e366"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
