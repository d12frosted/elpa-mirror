(define-package "org-chef" "20220412.1423" "Cookbook and recipe management with org-mode."
  '((org "0")
    (emacs "24"))
  :commit "f244b33a5a42d2879b9a6f4fcfeedcefb3326b94" :authors
  '(("Calvin Beck" . "hobbes@ualberta.ca"))
  :maintainer
  '("Calvin Beck" . "hobbes@ualberta.ca")
  :keywords
  '("convenience" "abbrev" "outlines" "org" "food" "recipes" "cooking")
  :url "https://github.com/Chobbes/org-chef")
;; Local Variables:
;; no-byte-compile: t
;; End:
