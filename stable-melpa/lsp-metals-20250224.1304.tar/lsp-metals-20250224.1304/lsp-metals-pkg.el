;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-metals" "20250224.1304"
  "Scala Client settings."
  '((emacs        "27.1")
    (scala-mode   "0.23")
    (lsp-mode     "7.0")
    (lsp-treemacs "0.2")
    (dap-mode     "0.3")
    (dash         "2.18.0")
    (f            "0.20.0")
    (ht           "2.0")
    (treemacs     "3.1"))
  :url "https://github.com/emacs-lsp/lsp-metals"
  :commit "72752073ed06c84db4383f9497ec29ecb8a6bc6b"
  :revdesc "72752073ed06"
  :keywords '("languages" "extensions")
  :authors '(("Ross A. Baker" . "ross@rossabaker.com")
             ("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers '(("Ross A. Baker" . "ross@rossabaker.com")
                 ("Evgeny Kurnevsky" . "kurnevsky@gmail.com")))
