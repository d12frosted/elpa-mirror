(define-package "good-scroll" "20210522.151" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "c237000a506b3e2808406172970a14ba35f21c49" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
