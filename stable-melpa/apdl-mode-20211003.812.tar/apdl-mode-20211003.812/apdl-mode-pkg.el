(define-package "apdl-mode" "20211003.812" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "7a93beaff9c9b4f6eb91b9c5a2a219ce8cfd0be0" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
