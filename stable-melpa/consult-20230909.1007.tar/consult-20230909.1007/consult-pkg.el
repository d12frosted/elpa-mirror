(define-package "consult" "20230909.1007" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "44fc1236a2a4386ec7d2329807258f13dfed094a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
