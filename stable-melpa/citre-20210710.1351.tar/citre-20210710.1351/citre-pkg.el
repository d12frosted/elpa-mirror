(define-package "citre" "20210710.1351" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "37d8988f36cd902647c68c0bac6a5ca40a56a257" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
