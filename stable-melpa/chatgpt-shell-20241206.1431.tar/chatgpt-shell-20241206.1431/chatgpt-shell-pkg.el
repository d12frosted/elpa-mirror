;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241206.1431"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.74.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "76c939494c533366a671799125f25738ea2f15fa"
  :revdesc "76c939494c53")
