;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260416.1107"
  "Browse the Emacsmirror package database."
  '((emacs   "28.1")
    (compat  "30.1")
    (closql  "2.4")
    (emacsql "4.3")
    (llama   "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "f3f8d26401a7a9c49d4b670dbf463dd010c26fae"
  :revdesc "f3f8d26401a7"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
