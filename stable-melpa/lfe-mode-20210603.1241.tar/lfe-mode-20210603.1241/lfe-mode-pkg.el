(define-package "lfe-mode" "20210603.1241" "Lisp Flavoured Erlang mode" 'nil :commit "1feb8af64c977946b6184b7d63b436c49dbeb52d")
;; Local Variables:
;; no-byte-compile: t
;; End:
