(define-package "lfe-mode" "20210603.1241" "Lisp Flavoured Erlang mode" 'nil :commit "f39ec6a9b93f09e1a49ee84405d1e03e04adc7cf")
;; Local Variables:
;; no-byte-compile: t
;; End:
