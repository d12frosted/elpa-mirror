(define-package "lfe-mode" "20210603.1241" "Lisp Flavoured Erlang mode" 'nil :commit "3d2483d6a46552eaa832f8e6df5dc1162e58fc79")
;; Local Variables:
;; no-byte-compile: t
;; End:
