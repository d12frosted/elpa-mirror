;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20261101.2133"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "6476ac9f9df06089d57422cba5cc7c828e934d92"
  :revdesc "6476ac9f9df0"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
