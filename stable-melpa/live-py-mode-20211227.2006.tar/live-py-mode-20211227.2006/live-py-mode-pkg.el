(define-package "live-py-mode" "20211227.2006" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "2b61e97acddfcb67ff749d733cf259759ba24d91" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
