;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-spell" "20230906.1635"
  "Autocompleting spelling for Company."
  '((emacs   "24.4")
    (company "0.9.13"))
  :url "https://github.com/enzuru/company-spell"
  :commit "f25b592c271dd1098ebe06b233b6ebb6fbeed488"
  :revdesc "f25b592c271d"
  :keywords '("wp"))
