;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20261108.1910"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "6a220c61df607e56d42f6601be44e36ce41ccf2a"
  :revdesc "6a220c61df60"
  :keywords '("tools" "convenience" "text"))
