;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pickle" "20190923.354"
  "Major mode for editing cucumber gherkin files."
  '((emacs  "25.1")
    (cl-lib "0.6.1"))
  :url "https://github.com/ahungry/pickle-mode"
  :commit "3a0a717f2a24827667f34bc53830a3b81cd57460"
  :revdesc "3a0a717f2a24"
  :keywords '("ahungry" "languages" "cucumber" "gherkin")
  :authors '(("Matthew Carter" . "m@ahungry.com"))
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
