;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241015.1415"
  "ChatGPT shell + buffer insert commands."
  '((emacs       "27.1")
    (shell-maker "0.53.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "1bf788ebdd5aa0374972c1ab5ecb62ea5f82b320"
  :revdesc "1bf788ebdd5a")
