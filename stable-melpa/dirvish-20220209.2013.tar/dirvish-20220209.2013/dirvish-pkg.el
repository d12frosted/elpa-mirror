(define-package "dirvish" "20220209.2013" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "64aa48103099d9581dbf6fd2f10e02a78abd77df" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
