;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260313.657"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral DeepSeek OpenRouter Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "bf5db0771792348323c4f573d0b6ebf5be542342"
  :revdesc "bf5db0771792"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
