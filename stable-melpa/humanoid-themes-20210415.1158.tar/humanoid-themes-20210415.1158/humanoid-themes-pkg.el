(define-package "humanoid-themes" "20210415.1158" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "82fbd1d899b1bedf57c4dbf220b44c224235a40f" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
