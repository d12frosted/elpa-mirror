(define-package "ue" "20210928.703" "Minor mode for Unreal Engine projects"
  '((emacs "26.1")
    (projectile "2.5.0"))
  :commit "74ad5847bc933e08422f3c590130e1e9b2a44fda" :authors
  '(("Oleksandr Manenko" . "seidfzehsd@use.startmail.com"))
  :maintainer
  '("Oleksandr Manenko" . "seidfzehsd@use.startmail.com")
  :keywords
  '("unreal engine" "languages" "tools")
  :url "https://gitlab.com/unrealemacs/ue.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
