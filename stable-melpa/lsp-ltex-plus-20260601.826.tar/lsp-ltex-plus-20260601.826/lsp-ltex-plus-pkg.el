;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "20260601.826"
  "Grammar and spell checking for LaTeX, Markdown, Org and more."
  '((emacs    "27.1")
    (lsp-mode "6.0"))
  :url "https://github.com/ltex-plus/emacs-ltex-plus"
  :commit "770fd484a6b99869c2f5062abadb85dfc55c5060"
  :revdesc "770fd484a6b9"
  :keywords '("lsp" "grammar" "spelling" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
