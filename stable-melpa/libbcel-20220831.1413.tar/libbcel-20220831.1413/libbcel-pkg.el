(define-package "libbcel" "20220831.1413" "Library to connect to basecamp 3 API"
  '((emacs "26.1")
    (request "0.3.1"))
  :commit "4d5fd6399a6e758b038ae664adb06c4d9b9c29c8" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://gitlab.petton.fr/bcel/libbcel")
;; Local Variables:
;; no-byte-compile: t
;; End:
