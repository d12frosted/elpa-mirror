;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250529.1016"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "2625bf78c06bed8e6286c4cd061a4bbf865c70f9"
  :revdesc "2625bf78c06b"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
