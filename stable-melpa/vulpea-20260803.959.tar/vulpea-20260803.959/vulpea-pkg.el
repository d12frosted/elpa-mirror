;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260803.959"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "cff736f210d3dff6c3c4b3b170ed340d3d0f5318"
  :revdesc "cff736f210d3"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
