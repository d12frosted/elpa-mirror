;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260117.1041"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "de53433e648d4bfe1a3af4f711cc7bc9e847f027"
  :revdesc "de53433e648d"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
