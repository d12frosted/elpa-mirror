;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260128.2058"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "0368a5cc989476cdab2522f5abafaaecd8972cc2"
  :revdesc "0368a5cc9894"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
