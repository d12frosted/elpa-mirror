;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260724.426"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "410ed297157a205eeb1b2f79f74ae82910a81ecc"
  :revdesc "410ed297157a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
