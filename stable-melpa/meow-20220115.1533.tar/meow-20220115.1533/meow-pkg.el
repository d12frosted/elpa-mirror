(define-package "meow" "20220115.1533" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "b01c6a968e8be9990b1306ee62737dbf13525177" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
