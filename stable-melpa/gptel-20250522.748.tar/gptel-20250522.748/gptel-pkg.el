;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250522.748"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "02fa8250a3274c52d8dab91b525d193328b156e1"
  :revdesc "02fa8250a327"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
