(define-package "org-change" "20231026.451" "Annotate changes in org-mode files"
  '((emacs "26.1")
    (org "9.3"))
  :commit "3e0d2ea371d89e70544e769a32b0e96c15b6d24c" :keywords
  '("wp" "convenience")
  :url "https://github.com/drghirlanda/org-change")
;; Local Variables:
;; no-byte-compile: t
;; End:
