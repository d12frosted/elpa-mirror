;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260223.2338"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "a68d05609cc40905618b72b8cadbbdde833e428e"
  :revdesc "a68d05609cc4"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
