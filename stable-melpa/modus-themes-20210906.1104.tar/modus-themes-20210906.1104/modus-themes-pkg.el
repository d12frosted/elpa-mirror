(define-package "modus-themes" "20210906.1104" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "a30b42395cdfd8759b71193e2f0804c8e54926ad" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
