(define-package "sniem" "20231020.614" "Hands-eased united editing method"
  '((emacs "27.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "cf1e6ae475c053ec18c3722b4591b863a788adce" :authors
  '(("SpringHan"))
  :maintainers
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
