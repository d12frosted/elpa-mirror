;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260109.741"
  "Manage and navigate projects in Emacs easily."
  '((emacs "26.1"))
  :url "https://github.com/bbatsov/projectile"
  :commit "bdf31bc2c452b6ac0976f5cb67dcdab651c20b5a"
  :revdesc "bdf31bc2c452"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
