;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-desktop" "20250908.1240"
  "Desktop environment for zk."
  '((emacs    "27.1")
    (zk       "0.6")
    (zk-index "0.9"))
  :url "https://github.com/localauthor/zk"
  :commit "302e494324066d63f317b54c4db75d173914c521"
  :revdesc "302e49432406"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
