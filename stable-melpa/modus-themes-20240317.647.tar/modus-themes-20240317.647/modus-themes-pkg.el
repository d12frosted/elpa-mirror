(define-package "modus-themes" "20240317.647" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "51466b1355d73d90523ca6df81e18c786da85e96" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
