(define-package "eldev" "20220715.2010" "Elisp development tool"
  '((emacs "24.4"))
  :commit "0d2f46eb41180ada741725f9ea2e1272491591c4" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
