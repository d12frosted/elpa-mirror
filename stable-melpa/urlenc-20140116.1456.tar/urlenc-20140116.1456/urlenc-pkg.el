;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "urlenc" "20140116.1456"
  "URL encoding/decoding utility for Emacs."
  ()
  :url "https://github.com/buzztaiki/urlenc-el"
  :commit "835a6dcb783bbe84714bae87a3464aa0b128bfac"
  :revdesc "835a6dcb783b"
  :keywords '("url")
  :authors '(("Taiki SUGAWARA" . "buzz.taiki@gmail.com"))
  :maintainers '(("Taiki SUGAWARA" . "buzz.taiki@gmail.com")))
