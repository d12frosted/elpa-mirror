;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260508.1838"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4834c7e6a280bb6923c0bc5f10e8f314e632821f"
  :revdesc "4834c7e6a280")
