(define-package "tok-theme" "20220409.1346" "Simple dark theme with cyberpunk aesthetics"
  '((emacs "24.3"))
  :commit "126fc25d77c1d8480ae7f54638ec6cebffd33ef1" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
