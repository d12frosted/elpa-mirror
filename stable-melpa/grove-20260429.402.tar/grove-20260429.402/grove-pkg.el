;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "20260429.402"
  "Obsidian-like note-taking for org files."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "96606266d17d1c3d2c161731c55ecdfa93ee2cc1"
  :revdesc "96606266d17d"
  :keywords '("notes" "outlines" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
