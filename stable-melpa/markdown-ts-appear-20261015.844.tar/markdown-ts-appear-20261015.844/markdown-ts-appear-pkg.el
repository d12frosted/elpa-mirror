;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "20261015.844"
  "Reveal Markdown source at point."
  '((emacs               "31.1")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "20fb5694ffec23e1b6dfb96cf3a9539ea494b588"
  :revdesc "20fb5694ffec"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
