(define-package "lsp-dart" "20221217.1514" "Dart support lsp-mode"
  '((emacs "26.3")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (dart-mode "1.0.5")
    (jsonrpc "1.0.15")
    (ht "2.2"))
  :commit "d8c748ae0807b8060336baf20e8ff1be1fd3b106" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
