;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260511.1526"
  "Browse the Emacsmirror package database."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (closql   "2.4")
    (emacsql  "4.3")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "539615c970e2ca16e5ac10a73d7deaecdab147e4"
  :revdesc "539615c970e2"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
