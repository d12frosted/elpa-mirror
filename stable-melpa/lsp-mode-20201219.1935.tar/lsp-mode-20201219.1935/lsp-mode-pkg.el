(define-package "lsp-mode" "20201219.1935" "LSP mode"
  '((emacs "26.1")
    (dash "2.14.1")
    (dash-functional "2.14.1")
    (f "0.20.0")
    (ht "2.0")
    (spinner "1.7.3")
    (markdown-mode "2.3")
    (lv "0"))
  :commit "44f9f149d61c31f4beff3b91f5a768821a0dedbb" :keywords
  ("languages")
  :authors
  (("Vibhav Pant, Fangrui Song, Ivan Yonchovski"))
  :maintainer
  ("Vibhav Pant, Fangrui Song, Ivan Yonchovski")
  :url "https://github.com/emacs-lsp/lsp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
