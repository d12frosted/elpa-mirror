;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260816.111"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "17acf7f6efd7a73dadb902d2f5586aec4e32051e"
  :revdesc "17acf7f6efd7"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
