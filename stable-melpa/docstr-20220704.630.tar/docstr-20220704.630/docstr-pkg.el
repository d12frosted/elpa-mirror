(define-package "docstr" "20220704.630" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "ae851e805c27c0ec2952c30bedd95ae84bc90010" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "document" "string")
  :url "https://github.com/emacs-vs/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
