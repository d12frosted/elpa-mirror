(define-package "sticky-shell" "20240928.427" "Minor mode to keep track of previous prompt in your shell"
  '((emacs "25.1"))
  :commit "2aec19f60539faf21f567e89701a8e28492eccd1" :authors
  '(("Andrew De Angelis" . "bobodeangelis@gmail.com"))
  :maintainers
  '(("Andrew De Angelis" . "bobodeangelis@gmail.com"))
  :maintainer
  '("Andrew De Angelis" . "bobodeangelis@gmail.com")
  :keywords
  '("processes" "terminals" "tools")
  :url "https://github.com/andyjda/sticky-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
