;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260330.1542"
  "Highlight window and cursor at switching."
  '((emacs "26.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "ccf6687020dae9a6c36af4a5ae53e79d56ad8719"
  :revdesc "ccf6687020da"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
