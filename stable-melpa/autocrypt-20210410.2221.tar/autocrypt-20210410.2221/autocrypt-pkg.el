(define-package "autocrypt" "20210410.2221" "Autocrypt implementation"
  '((emacs "25.1")
    (cl-generic "0.3"))
  :commit "173d7616a8d2c0fb5a832fb01cd10bcf70c0a801" :authors
  '(("Philip K." . "philip@warpmail.net"))
  :maintainer
  '("Philip K." . "philip@warpmail.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~zge/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
