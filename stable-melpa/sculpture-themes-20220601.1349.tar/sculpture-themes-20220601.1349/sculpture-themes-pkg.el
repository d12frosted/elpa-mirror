(define-package "sculpture-themes" "20220601.1349" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "ff2fdd1c38cb9f3f1abf420b77d1ef3a2786ce57" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainers
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
