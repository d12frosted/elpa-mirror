;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260710.430"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "a4dfac80ebbf54df48f6fbf7936da0d6f1b6f321"
  :revdesc "a4dfac80ebbf"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
