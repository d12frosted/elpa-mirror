(define-package "helm-apt" "20210324.1929" "Helm interface for Debian/Ubuntu packages (apt-*)"
  '((helm "3.6")
    (emacs "25.1"))
  :commit "c952b5dc26015bc9c947973df99246212d276b63" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://github.com/emacs-helm/helm-apt")
;; Local Variables:
;; no-byte-compile: t
;; End:
