;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250303.1456"
  "Fast org-roam replacement."
  '((emacs         "28.1")
    (compat        "30.0.0.0")
    (el-job        "1.0.2")
    (llama         "0.5.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "67203470eba5cbb5f1e6ee259ea263f689364855"
  :revdesc "67203470eba5"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
