;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polymode" "20250531.738"
  "Extensible framework for multiple major modes."
  '((emacs "25"))
  :url "https://github.com/polymode/polymode"
  :commit "829a89c75a89c389de5d667ed56d3135c65a64f9"
  :revdesc "829a89c75a89"
  :keywords '("languages" "multi-modes" "processes")
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
