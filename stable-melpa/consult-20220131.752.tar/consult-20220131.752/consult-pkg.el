(define-package "consult" "20220131.752" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "e1e17965a98515a620c439be1eb28cd125f984a0" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
