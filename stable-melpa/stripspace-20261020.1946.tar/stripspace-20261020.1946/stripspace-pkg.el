;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20261020.1946"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "7b8e2824a556be1b04cf62253aefdedddf63f816"
  :revdesc "7b8e2824a556"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
