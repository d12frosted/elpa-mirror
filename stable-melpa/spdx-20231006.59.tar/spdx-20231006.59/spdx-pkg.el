(define-package "spdx" "20231006.59" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "cbf9c05210de72dda2705ea14d64581eb6bc695b" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
