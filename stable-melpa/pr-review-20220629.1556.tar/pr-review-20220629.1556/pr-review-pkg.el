(define-package "pr-review" "20220629.1556" "Review github PR"
  '((emacs "27.1")
    (magit-section "3.2")
    (magit "3.2")
    (markdown-mode "2.5")
    (ghub "3.5"))
  :commit "7a4ede64ebc731793f3ffb81f5882d26d1e07af3" :authors
  '(("Yikai Zhao" . "yikai@z1k.dev"))
  :maintainer
  '("Yikai Zhao" . "yikai@z1k.dev")
  :keywords
  '("tools")
  :url "https://github.com/blahgeek/emacs-pr-review")
;; Local Variables:
;; no-byte-compile: t
;; End:
