;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250425.721"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.2")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "294e7a103fe10cb121c7849e3dd2dd17ab2b2d60"
  :revdesc "294e7a103fe1"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
