;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260228.1152"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "17d8009f5c09c14a0f11f4267f6dc081ae161b6d"
  :revdesc "17d8009f5c09")
