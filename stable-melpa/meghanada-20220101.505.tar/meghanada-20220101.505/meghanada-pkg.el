;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meghanada" "20220101.505"
  "A better java development mode."
  '((emacs     "24.3")
    (yasnippet "0.6.1")
    (company   "0.9.0")
    (flycheck  "0.23"))
  :url "https://github.com/mopemope/meghanada-emacs"
  :commit "59c46cabb7eee715fe810ce59424934a1286df84"
  :revdesc "59c46cabb7ee"
  :keywords '("languages" "java")
  :authors '(("Yutaka Matsubara" . "(yutaka.matsubara@gmail.com)"))
  :maintainers '(("Yutaka Matsubara" . "(yutaka.matsubara@gmail.com)")))
