(define-package "citre" "20221019.1409" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "2e42117682988b93ab56fd92572f1f9e0c6f7d11" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
