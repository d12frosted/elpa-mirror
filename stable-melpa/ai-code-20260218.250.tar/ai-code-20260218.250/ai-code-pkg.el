;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260218.250"
  "Unified interface for AI coding backends such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, agent-shell, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9e4d5cb2dc08337d0823af2a96086f91e9a858dc"
  :revdesc "9e4d5cb2dc08"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
