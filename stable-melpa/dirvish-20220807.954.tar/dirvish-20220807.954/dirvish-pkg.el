(define-package "dirvish" "20220807.954" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "b9969e27ab13d1ee6ec05cc892b95df0eeb05383" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
