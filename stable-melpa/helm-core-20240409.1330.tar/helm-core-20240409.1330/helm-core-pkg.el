(define-package "helm-core" "20240409.1330" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "ba4914730975ded2d540df5dddd26fedfbdd6a37" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
