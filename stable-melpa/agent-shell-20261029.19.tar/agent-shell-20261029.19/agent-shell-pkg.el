;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261029.19"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.2")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8b0839ddf753b9254e559d63f55540f1c1582635"
  :revdesc "8b0839ddf753")
