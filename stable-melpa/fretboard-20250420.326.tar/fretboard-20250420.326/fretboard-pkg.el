;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fretboard" "20250420.326"
  "Visualize guitar scales and chord shapes on a fretboard."
  '((emacs "27.1")
    (s     "1.13.0")
    (dash  "2.19.0"))
  :url "https://github.com/skyefreeman/fretboard.el"
  :commit "064aeb7553c9bef86cf3de8d3c124809f1b3b381"
  :revdesc "064aeb7553c9"
  :keywords '("music" "guitar" "tools"))
