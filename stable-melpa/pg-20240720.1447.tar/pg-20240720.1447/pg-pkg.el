(define-package "pg" "20240720.1447" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "28.1")
    (peg "1.0"))
  :commit "229bfc5ae50814a908c055d6bae0bfe16fa70155" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
