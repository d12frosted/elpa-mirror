;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tinkerer" "20200914.1756"
  "Elisp wrapper for Tinkerer Blogging Engine."
  '((s "1.2.0"))
  :url "https://github.com/yyr/tinkerer.el"
  :commit "7cedeb264a44cd62bcd9c778dca52316d09e07e5"
  :revdesc "7cedeb264a44"
  :keywords '("tinkerer" "blog" "wrapper")
  :authors '(("Yagnesh Raghava Yakkala" . "hi@yagnesh.org"))
  :maintainers '(("Yagnesh Raghava Yakkala" . "hi@yagnesh.org")))
