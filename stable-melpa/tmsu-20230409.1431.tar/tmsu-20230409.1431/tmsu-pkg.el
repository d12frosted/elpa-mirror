(define-package "tmsu" "20230409.1431" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "900ac41f6cf4943ea9f154e900e0f1aaab124211" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
