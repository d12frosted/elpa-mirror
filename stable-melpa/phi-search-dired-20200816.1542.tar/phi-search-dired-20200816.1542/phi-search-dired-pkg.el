;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-search-dired" "20200816.1542"
  "Interactive filtering for dired powered by phi-search."
  '((phi-search "2.2.0"))
  :url "http://hins11.yu-yake.com/"
  :commit "f014a9fb0b6a94af2df0e22f91ef79ce6996afd7"
  :revdesc "f014a9fb0b6a")
