(define-package "org-ehtml" "20220110.1917" "Export Org-mode files as editable web pages"
  '((web-server "20140109.2200")
    (emacs "24.3"))
  :commit "4db3756249b069310dabc0db43c7d9bbe55fb233" :authors
  '(("Eric Schulte" . "schulte.eric@gmail.com"))
  :maintainer
  '("Eric Schulte" . "schulte.eric@gmail.com")
  :keywords
  '("org" "web-server" "javascript" "html"))
;; Local Variables:
;; no-byte-compile: t
;; End:
