(define-package "bqn-mode" "20230405.201" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "e36681b5723e598f8db9e12c528336a10d339401" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
