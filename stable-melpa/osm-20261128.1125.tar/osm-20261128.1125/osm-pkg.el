;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20261128.1125"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/osm"
  :commit "dbe09dba6d53bce3d79b73f42041d2ba220d5245"
  :revdesc "dbe09dba6d53"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
