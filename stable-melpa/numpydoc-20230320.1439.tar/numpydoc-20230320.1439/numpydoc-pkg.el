(define-package "numpydoc" "20230320.1439" "NumPy style docstring insertion"
  '((emacs "25.1")
    (s "1.12.0")
    (dash "2.18.0"))
  :commit "f9ec92558a2ac293ab9a2f0611624b6c7d2d5658" :authors
  '(("Doug Davis" . "ddavis@ddavis.io"))
  :maintainers
  '(("Doug Davis" . "ddavis@ddavis.io"))
  :maintainer
  '("Doug Davis" . "ddavis@ddavis.io")
  :keywords
  '("convenience")
  :url "https://github.com/douglasdavis/numpydoc.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
