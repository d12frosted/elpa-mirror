;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260622.756"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "510d713b6ebef63e7c4f41fc8039e3be4da0c28d"
  :revdesc "510d713b6ebe"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
