;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20261028.2311"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "87f4fb3606381f194fd15c39bdeff3ddd6ea8535"
  :revdesc "87f4fb360638"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
