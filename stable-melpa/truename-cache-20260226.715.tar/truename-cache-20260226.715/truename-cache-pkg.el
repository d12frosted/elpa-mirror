;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260226.715"
  "Efficiently de-dup file-names."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "779e535639f64bc803b4611ee66ad645bef7d4ff"
  :revdesc "779e535639f6"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
