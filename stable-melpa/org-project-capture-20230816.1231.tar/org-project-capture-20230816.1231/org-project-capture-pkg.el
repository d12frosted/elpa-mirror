(define-package "org-project-capture" "20230816.1231" "Repository todo capture and management for org-mode"
  '((dash "2.10.0")
    (emacs "28")
    (s "1.9.0")
    (org-category-capture "1.0.0"))
  :commit "418ec0311ff3dde2578930d834cdb507158797e7" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "todo" "tools" "outlines" "project" "capture")
  :url "https://github.com/colonelpanic8/org-project-capture")
;; Local Variables:
;; no-byte-compile: t
;; End:
