;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fennel-mode" "20260408.1529"
  "A major-mode for editing Fennel code."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~technomancy/fennel-mode"
  :commit "c963b4701e4668717df083c8a4591c93e6b1dc8d"
  :revdesc "c963b4701e46"
  :keywords '("languages" "tools"))
