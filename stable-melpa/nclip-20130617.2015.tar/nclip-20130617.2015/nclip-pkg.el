(define-package "nclip" "20130617.2015" "Network (HTTP) Clipboard" 'nil :commit "af88e38b1f04be02bf2e57affc662dbd0f828e67" :keywords
  ("nclip" "clipboard" "network")
  :authors
  (("Marian Schubert" . "marian.schubert@gmail.com"))
  :maintainer
  ("Marian Schubert" . "marian.schubert@gmail.com")
  :url "http://www.github.com/maio/nclip.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
