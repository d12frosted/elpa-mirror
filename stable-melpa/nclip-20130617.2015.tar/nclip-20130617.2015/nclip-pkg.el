;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nclip" "20130617.2015"
  "Network (HTTP) Clipboard."
  ()
  :url "http://www.github.com/maio/nclip.el"
  :commit "af88e38b1f04be02bf2e57affc662dbd0f828e67"
  :revdesc "af88e38b1f04"
  :keywords '("nclip" "clipboard" "network")
  :authors '(("Marian Schubert" . "marian.schubert@gmail.com"))
  :maintainers '(("Marian Schubert" . "marian.schubert@gmail.com")))
