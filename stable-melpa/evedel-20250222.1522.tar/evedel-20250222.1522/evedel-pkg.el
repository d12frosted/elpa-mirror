;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evedel" "20250222.1522"
  "Instructed LLM programmer/assistant."
  '((emacs "29.1")
    (gptel "0.9.0"))
  :url "https://github.com/daedsidog/evedel"
  :commit "899ca0c01c24f601739820d081b9e222dcc36a0a"
  :revdesc "899ca0c01c24"
  :keywords '("convenience" "tools")
  :authors '(("daedsidog" . "contact@daedsidog.com"))
  :maintainers '(("daedsidog" . "contact@daedsidog.com")))
