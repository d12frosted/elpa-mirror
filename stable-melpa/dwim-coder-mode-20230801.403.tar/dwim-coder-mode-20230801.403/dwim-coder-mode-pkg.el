(define-package "dwim-coder-mode" "20230801.403" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "271d9c06ecdfadf19e0eaa788c8b90626090d4c1" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
