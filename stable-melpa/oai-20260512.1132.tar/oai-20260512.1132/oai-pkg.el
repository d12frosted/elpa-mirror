;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260512.1132"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "1127ada1297cce832d244ef18835761026a16c50"
  :revdesc "1127ada1297c"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
