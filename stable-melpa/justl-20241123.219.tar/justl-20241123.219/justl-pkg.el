;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "justl" "20241123.219"
  "Major mode for driving just files."
  '((transient  "0.1.0")
    (emacs      "27.1")
    (s          "1.2.0")
    (f          "0.20.0")
    (inheritenv "0.2"))
  :url "https://github.com/psibi/justl.el"
  :commit "e04f656ebb1699985ccfb313c541bc4b0fa07bc8"
  :revdesc "e04f656ebb16"
  :keywords '("just" "justfile" "tools" "processes"))
