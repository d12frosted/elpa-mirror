;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241016.659"
  "ChatGPT shell + buffer insert commands."
  '((emacs       "27.1")
    (shell-maker "0.53.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "a0e67fa2c66f960f734d900f7b02fe1d5f92676f"
  :revdesc "a0e67fa2c66f")
