(define-package "blackjack" "20230518.1824" "The game of Blackjack"
  '((emacs "26.2"))
  :commit "beb4676c8d61fe18a13b4e366aa175c079fb60b6" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
