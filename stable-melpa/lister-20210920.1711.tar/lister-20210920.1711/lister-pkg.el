(define-package "lister" "20210920.1711" "Yet another list printer"
  '((emacs "26.1"))
  :commit "6cdd5e9ddb6dc689851b00b3fd929eb996e97357" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
