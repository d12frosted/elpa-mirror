;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20241118.1404"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "f4f957253093a449c806397fd6157e19d84a7c02"
  :revdesc "f4f957253093"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
