;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260523.1749"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "a27017ddcc2bb701b990d9e21d6b72c75ec05016"
  :revdesc "a27017ddcc2b"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
