(define-package "consult" "20220423.417" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "8fab8a0061e030bf1d0d583f5b4da687df564d14" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
