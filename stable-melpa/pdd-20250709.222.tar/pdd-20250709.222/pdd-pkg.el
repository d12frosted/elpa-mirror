;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250709.222"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "ea97a4b23d9cebc6107dc83cd2fcee32106bf667"
  :revdesc "ea97a4b23d9c"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
