(define-package "dwim-shell-command" "20221001.2114" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "7085b789f0e6f6239e621b372d05dbf5850956e7" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
