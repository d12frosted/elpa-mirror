(define-package "detached" "20220923.1411" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "4d63d7d6aa4668fb7bd141c9701075f2dc7d67a5" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
