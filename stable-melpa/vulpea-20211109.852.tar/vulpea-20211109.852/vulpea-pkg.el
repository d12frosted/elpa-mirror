(define-package "vulpea" "20211109.852" "A collection of org-roam note-taking functions"
  '((emacs "27.1")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12"))
  :commit "98b1e96bce1fda333a92ed0d1158b2ee70117803" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
