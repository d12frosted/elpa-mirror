(define-package "beeminder" "20200610.2311" "Emacs interface for Beeminder"
  '((org "7"))
  :commit "8f86ae34ebd17324d98146a2b3a532d56dd1cdd0" :authors
  (("Phil Newton" . "phil@sodaware.net"))
  :maintainer
  ("Phil Newton" . "phil@sodaware.net")
  :keywords
  ("beeminder")
  :url "http://www.philnewton.net/code/beeminder-el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
