(define-package "detached" "20220920.1610" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "c80f56061514a5e480592527a1ccec699b522ae7" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
