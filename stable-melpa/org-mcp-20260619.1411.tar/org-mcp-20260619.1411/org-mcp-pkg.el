;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260619.1411"
  "MCP server for Org-mode."
  '((emacs          "27.1")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "04ac7ef5f031b4c078a31d78317cfe547d947659"
  :revdesc "04ac7ef5f031"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
