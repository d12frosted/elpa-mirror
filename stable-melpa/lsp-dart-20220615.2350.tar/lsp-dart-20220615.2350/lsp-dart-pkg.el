(define-package "lsp-dart" "20220615.2350" "Dart support lsp-mode"
  '((emacs "26.3")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (dart-mode "1.0.5"))
  :commit "dc6b71457fd096596889a6488c3c137e2a4a4bc3" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
