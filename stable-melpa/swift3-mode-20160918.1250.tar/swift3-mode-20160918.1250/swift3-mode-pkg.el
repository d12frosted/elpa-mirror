;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swift3-mode" "20160918.1250"
  "Major-mode for Apple's Swift programming language."
  '((emacs "24.4"))
  :url "https://github.com/taku0/swift3-mode"
  :commit "ea34d46bf9a4293e75ffdac9500d34989316d9e9"
  :revdesc "ea34d46bf9a4"
  :keywords '("languages" "swift")
  :authors '(("Chris Barrett" . "chris.d.barrett@me.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.com")
             ("Arthur Evstifeev" . "lod@pisem.net"))
  :maintainers '(("Chris Barrett" . "chris.d.barrett@me.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.com")
                 ("Arthur Evstifeev" . "lod@pisem.net")))
