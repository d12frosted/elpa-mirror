(define-package "magit-section" "20210224.1417" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "c7364e169648f454dc73fe50596d827fbf1f0fb7" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
