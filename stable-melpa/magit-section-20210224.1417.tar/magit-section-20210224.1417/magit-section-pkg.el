(define-package "magit-section" "20210224.1417" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "3db9e0a9821e5d9d9c6aacf5cc1d8ae1a6546ba7" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
