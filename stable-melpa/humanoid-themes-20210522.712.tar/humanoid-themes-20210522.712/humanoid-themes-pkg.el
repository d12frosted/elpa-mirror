(define-package "humanoid-themes" "20210522.712" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "1d0d1446bb293e8f509700626719158e7d976b08" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
