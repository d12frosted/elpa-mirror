;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awqat" "20260607.1404"
  "Islamic prayer times."
  '((emacs "28.1")
    (alert "1.2"))
  :url "https://github.com/zkry/awqat"
  :commit "8aa6b390f935f7471fe233905c6755f6e7354b5f"
  :revdesc "8aa6b390f935"
  :authors '(("Zachary Romero" . "zacromero@posteo.net"))
  :maintainers '(("Zachary Romero" . "zacromero@posteo.net")))
