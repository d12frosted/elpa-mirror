(define-package "citeproc" "20221216.1238" "A CSL 1.0.2 Citation Processor"
  '((emacs "26")
    (dash "2.13.0")
    (s "1.12.0")
    (f "0.18.0")
    (queue "0.2")
    (string-inflection "1.0")
    (org "9")
    (parsebib "2.4"))
  :commit "3cb83db147bdda208520246e82dbf9878fa3cbd0" :authors
  '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainer
  '("András Simonyi" . "andras.simonyi@gmail.com")
  :keywords
  '("bib")
  :url "https://github.com/andras-simonyi/citeproc-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
