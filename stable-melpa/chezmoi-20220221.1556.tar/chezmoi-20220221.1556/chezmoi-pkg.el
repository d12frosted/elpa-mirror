(define-package "chezmoi" "20220221.1556" "A package for interacting with chezmoi"
  '((emacs "26.1"))
  :commit "96d3448ae1e2293855e93633faf4b959726ded99" :authors
  '(("Harrison Pielke-Lombardo"))
  :maintainer
  '("Harrison Pielke-Lombardo")
  :keywords
  '("vc")
  :url "http://www.github.com/tuh8888/chezmoi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
