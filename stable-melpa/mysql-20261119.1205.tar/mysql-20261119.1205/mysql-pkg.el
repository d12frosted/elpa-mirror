;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20261119.1205"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "5091428189a564440ac1de0657e2b306d3117c67"
  :revdesc "5091428189a5"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
