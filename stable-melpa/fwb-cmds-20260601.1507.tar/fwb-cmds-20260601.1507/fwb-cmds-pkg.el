;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fwb-cmds" "20260601.1507"
  "Misc frame, window and buffer commands."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/fwb-cmds"
  :commit "bb62a32dbd3febdd2e644af25a22e56259ed060d"
  :revdesc "bb62a32dbd3f"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.fwb-cmds@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.fwb-cmds@jonas.bernoulli.dev")))
