;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xmlunicode" "20230820.814"
  "Unicode support for XML."
  ()
  :url "https://github.com/ndw/xmlunicode"
  :commit "5f1c3e48b90588eb56cec67d3efc869a4e95b03a"
  :revdesc "5f1c3e48b905"
  :keywords '("utf-8" "unicode" "xml" "characters")
  :authors '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainers '(("Norman Walsh" . "ndw@nwalsh.com")))
