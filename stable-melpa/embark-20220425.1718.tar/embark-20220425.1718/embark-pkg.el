(define-package "embark" "20220425.1718" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "19e0de0786f7d5db196ff1d5a459d39e265b2960" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
