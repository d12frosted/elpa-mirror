(define-package "guess-language" "20201124.1136" "Robust automatic language detection"
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "6aa88cf267593f85b63a770a890bb93f04dd53c2" :authors
  (("Titus von der Malsburg" . "malsburg@posteo.de"))
  :maintainer
  ("Titus von der Malsburg" . "malsburg@posteo.de")
  :keywords
  ("wp")
  :url "https://github.com/tmalsburg/guess-language.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
