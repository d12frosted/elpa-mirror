;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260318.1950"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "68b8c394a4838fb54f7dbfc70cee38e7310f03a3"
  :revdesc "68b8c394a483")
