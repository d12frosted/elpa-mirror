;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mocker" "20260204.1045"
  "Mocking framework for emacs."
  '((emacs "25.1"))
  :url "https://github.com/sigma/mocker.el"
  :commit "462e4aa140db1f0589ab71dd07ee509e5425e2ff"
  :revdesc "462e4aa140db"
  :keywords '("lisp" "testing")
  :authors '(("Yann Hodique" . "yann.hodique@gmail.com"))
  :maintainers '(("Yann Hodique" . "yann.hodique@gmail.com")))
