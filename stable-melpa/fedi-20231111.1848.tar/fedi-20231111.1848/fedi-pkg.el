(define-package "fedi" "20231111.1848" "Helper functions for fediverse clients"
  '((emacs "28.1")
    (markdown-mode "2.7alpha"))
  :commit "c23a9f52a7a41e73abde0a3cdb6ddb9bd041b93b" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
