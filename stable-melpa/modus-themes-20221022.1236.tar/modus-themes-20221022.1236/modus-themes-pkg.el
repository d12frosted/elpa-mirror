(define-package "modus-themes" "20221022.1236" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "cbd33fbd17ebb5d129ffaf5a0cbd759c5eebc826" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
