(define-package "detached" "20220603.719" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "670433a5ab47ab3a093b0441088311e30be9a993" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
