;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20250423.210"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "cf518a3af9209eb750556d7042e76ee11789df63"
  :revdesc "cf518a3af920"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
