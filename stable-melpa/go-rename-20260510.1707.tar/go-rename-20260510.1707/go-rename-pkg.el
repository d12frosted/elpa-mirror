;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-rename" "20260510.1707"
  "Integration of the 'gorename' tool into Emacs."
  '((go-mode "1.3.1"))
  :url "https://github.com/dominikh/go-mode.el"
  :commit "144dc7d312d260f8dad7dfa6168537ae57f8e436"
  :revdesc "144dc7d312d2"
  :keywords '("tools"))
