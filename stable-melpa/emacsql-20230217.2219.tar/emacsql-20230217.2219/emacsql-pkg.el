(define-package "emacsql" "20230217.2219" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "176fd090115b3c2aea46ec9bf24401503f337a9d" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
