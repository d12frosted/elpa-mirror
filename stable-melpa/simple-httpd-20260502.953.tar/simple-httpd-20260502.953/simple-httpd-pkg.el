;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260502.953"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "31"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "eaa2d858591f0ef268871eb50307c9aa0c8aabdf"
  :revdesc "eaa2d858591f"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
