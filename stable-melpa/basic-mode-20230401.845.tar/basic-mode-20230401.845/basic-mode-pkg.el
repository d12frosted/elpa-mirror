(define-package "basic-mode" "20230401.845" "Major mode for editing BASIC code"
  '((seq "2.20")
    (emacs "25.1"))
  :commit "2971591510f08ab1645ed8a238b6ad086750f994" :authors
  '(("Johan Dykstrom"))
  :maintainers
  '(("Johan Dykstrom"))
  :maintainer
  '("Johan Dykstrom")
  :keywords
  '("basic" "languages")
  :url "https://github.com/dykstrom/basic-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
