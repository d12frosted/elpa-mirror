(define-package "electric-operator" "20230827.1400" "Automatically add spaces around operators"
  '((dash "2.10.0")
    (emacs "24.4"))
  :commit "8a88a933ff8b21f973df91d87430144450080d66" :authors
  '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers
  '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainer
  '("David Shepherd" . "davidshepherd7@gmail.com")
  :keywords
  '("electric")
  :url "https://github.com/davidshepherd7/electric-operator")
;; Local Variables:
;; no-byte-compile: t
;; End:
