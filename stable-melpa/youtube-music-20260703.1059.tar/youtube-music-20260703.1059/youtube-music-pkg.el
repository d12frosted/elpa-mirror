;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youtube-music" "20260703.1059"
  "YouTube Music client."
  '((emacs "29.1"))
  :url "https://github.com/cyberkm/emacs-youtube-music"
  :commit "fe58339e78761712ddbbb70914ec981c94f2ef02"
  :revdesc "fe58339e7876"
  :keywords '("multimedia" "youtube" "music")
  :authors '(("Pavel Bibergal" . "pavel@keewano.com"))
  :maintainers '(("Pavel Bibergal" . "pavel@keewano.com")))
