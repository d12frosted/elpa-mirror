(define-package "vulpea" "20220714.1856" "A collection of org-roam note-taking functions"
  '((emacs "27.2")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12")
    (dash "2.19"))
  :commit "8070a599583f0126a089f386e35df62451e51a91" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
