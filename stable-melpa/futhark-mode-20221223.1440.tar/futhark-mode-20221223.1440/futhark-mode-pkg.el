(define-package "futhark-mode" "20221223.1440" "major mode for editing Futhark source files"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "942450534547e2081a3ce6c13b6ccfbb4d6c05f4" :keywords
  '("languages")
  :url "https://github.com/diku-dk/futhark-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
