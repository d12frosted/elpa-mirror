(define-package "grugru" "20210116.1019" "Rotate text at point"
  '((emacs "24.4"))
  :commit "297e608dfc113bf9e7ab936db027b66a0eb00097" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
