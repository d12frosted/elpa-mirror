;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20251110.1457"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "0574c3247ce50cfce6bf9127ac568684be1e2ada"
  :revdesc "0574c3247ce5"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
