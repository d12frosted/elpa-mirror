;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251028.2025"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "81d3d0fc800498430485d4ac84a3e803dcbb5d18"
  :revdesc "81d3d0fc8004"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
