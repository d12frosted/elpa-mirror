;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dracula-theme" "20260907.2019"
  "Dracula Theme."
  '((emacs "24.3"))
  :url "https://github.com/dracula/emacs"
  :commit "73ff45fdd8e1de784156b77d124e99cdbbc39104"
  :revdesc "73ff45fdd8e1"
  :maintainers '(("tienne Deparis" . "etienne@depar.is")))
