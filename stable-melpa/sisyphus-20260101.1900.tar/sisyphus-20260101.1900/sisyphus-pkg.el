;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "20260101.1900"
  "Create releases of Emacs packages."
  '((emacs    "30.1")
    (compat   "30.1")
    (cond-let "0.2")
    (elx      "2.3")
    (llama    "1.0")
    (magit    "4.5"))
  :url "https://github.com/magit/sisyphus"
  :commit "7774ea7030fb7b2793eff41a8cae1e80c2ed955a"
  :revdesc "7774ea7030fb"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
