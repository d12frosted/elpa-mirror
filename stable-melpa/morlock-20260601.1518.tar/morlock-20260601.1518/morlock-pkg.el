;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "morlock" "20260601.1518"
  "More font-lock keywords for elisp."
  '((emacs "29.1"))
  :url "https://github.com/tarsius/morlock"
  :commit "1fd3cc79b1fa1f69386d6b2fa058e2477d35a4e7"
  :revdesc "1fd3cc79b1fa"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.morlock@jonas.bernoulli.dev")))
