(define-package "helm-core" "20220607.927" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "8387864d5a4e7393b0657d07ba2ce391de7bed21" :authors
  '(("Thierry Volpiatto "))
  :maintainer
  '("Thierry Volpiatto ")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
