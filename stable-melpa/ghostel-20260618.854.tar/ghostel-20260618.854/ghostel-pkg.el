;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260618.854"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "d77e36bb78137a5781a90a1b71b030fc1a2e8fb6"
  :revdesc "d77e36bb7813"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
