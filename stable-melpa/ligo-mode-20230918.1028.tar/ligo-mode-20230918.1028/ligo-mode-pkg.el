(define-package "ligo-mode" "20230918.1028" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "663b4474fd7bd242c1909a6a3251f0c5b44e3e32" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
