;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250616.346"
  "AI assisted programming with Aider and LLM."
  '((emacs         "26.1")
    (transient     "0.9.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "0170ea0621e46f9fa6dd5cbcd0187141f5605183"
  :revdesc "0170ea0621e4"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
