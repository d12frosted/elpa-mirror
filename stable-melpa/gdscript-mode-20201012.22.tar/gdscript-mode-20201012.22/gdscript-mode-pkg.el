(define-package "gdscript-mode" "20201012.22" "Major mode for Godot's GDScript language"
  '((emacs "26.3"))
  :commit "ef7a7f2789d0708a624a93b0f7037dd057cd8532" :authors
  '(("Nathan Lovato <nathan@gdquest.com>, Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainer
  '(nil . "nathan@gdquest.com")
  :keywords
  '("languages")
  :url "https://github.com/GDQuest/emacs-gdscript-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
