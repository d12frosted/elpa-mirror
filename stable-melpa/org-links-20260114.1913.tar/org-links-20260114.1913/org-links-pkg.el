;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260114.1913"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "9a2f804524de1981f81987f2cb6c3bd36b6fde1e"
  :revdesc "9a2f804524de"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
