(define-package "soccer" "20211023.827" "Fixtures, results, table etc for soccer"
  '((emacs "26.1")
    (dash "2.19.1"))
  :commit "84f1d1dcea6c40c5b6fc6622296c9892f493b16e" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("games" "soccer" "football")
  :url "https://github.com/md-arif-shaikh/soccer")
;; Local Variables:
;; no-byte-compile: t
;; End:
