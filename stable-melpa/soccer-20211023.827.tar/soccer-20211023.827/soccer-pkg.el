(define-package "soccer" "20211023.827" "Fixtures, results, table etc for soccer"
  '((emacs "26.1")
    (dash "2.19.1"))
  :commit "c55d23f12a690ce2629bec5072176a406fee97e2" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("games" "soccer" "football")
  :url "https://github.com/md-arif-shaikh/soccer")
;; Local Variables:
;; no-byte-compile: t
;; End:
