(define-package "tempel-collection" "20230419.1521" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "8ae3c3e8a1122600965749545b478e6db55bf37e" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
