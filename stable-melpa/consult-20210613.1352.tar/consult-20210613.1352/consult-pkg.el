(define-package "consult" "20210613.1352" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f42741f9af45242cebd69348db705be3e95b05fe" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
