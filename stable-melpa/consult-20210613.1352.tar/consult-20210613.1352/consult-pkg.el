(define-package "consult" "20210613.1352" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "1f64c06c6feb544628cdfb780d5ecbb3facff23f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
