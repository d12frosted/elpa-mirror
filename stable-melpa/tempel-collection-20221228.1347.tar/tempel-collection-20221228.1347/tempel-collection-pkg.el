(define-package "tempel-collection" "20221228.1347" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "4a49cebd0be30115f132a217b00bd0d55d58daa6" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
