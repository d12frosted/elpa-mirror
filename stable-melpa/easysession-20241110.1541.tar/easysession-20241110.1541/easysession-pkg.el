;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20241110.1541"
  "Easily persist and restore your editing sessions."
  '((emacs "25.1")
    (f     "0.18.2"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "ae18204e7ce53ff82bc63f923337dd7178e5fdae"
  :revdesc "ae18204e7ce5"
  :keywords '("convenience"))
