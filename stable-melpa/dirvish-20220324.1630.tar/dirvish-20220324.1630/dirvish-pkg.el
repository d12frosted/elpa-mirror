(define-package "dirvish" "20220324.1630" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "66a9508255e5405796be3a5824884f2804057c4b" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
