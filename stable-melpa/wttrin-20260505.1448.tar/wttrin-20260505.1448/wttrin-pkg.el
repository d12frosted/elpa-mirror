;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260505.1448"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "ec00dbe1c03527ec46a0faa20545a7acd382da84"
  :revdesc "ec00dbe1c035"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
