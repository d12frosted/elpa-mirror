(define-package "f3" "20180130.1158" "a helm interface to find"
  '((emacs "24.3")
    (helm "2.8.8")
    (cl-lib "0.5"))
  :commit "000009ce4adf7a57eae80512f29c4ec2a1391ce5" :keywords
  ("find" "file" "files" "helm" "fast" "finder")
  :authors
  (("Danny McClanahan"))
  :maintainer
  ("Danny McClanahan")
  :url "https://github.com/cosmicexplorer/f3")
;; Local Variables:
;; no-byte-compile: t
;; End:
