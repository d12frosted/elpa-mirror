(define-package "srfi" "20231114.32" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "3e19e23948bb746e6c3a09c4531fbf904b50a0f3" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
