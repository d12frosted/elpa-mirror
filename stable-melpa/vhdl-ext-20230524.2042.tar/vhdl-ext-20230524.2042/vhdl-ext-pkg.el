(define-package "vhdl-ext" "20230524.2042" "VHDL Extensions"
  '((emacs "28.1")
    (eglot "1.9")
    (lsp-mode "8.0.1")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "33snapshot"))
  :commit "39938bdbdf93e924e9612cc527bc099b97231daa" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
