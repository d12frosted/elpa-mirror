(define-package "stimmung-themes" "20220325.1623" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "bc642a59157a0a857f93eb54ff33e5723413415c" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
