(define-package "gnuplot" "20230218.1717" "Major-mode and interactive frontend for gnuplot"
  '((emacs "25.1"))
  :commit "663a89d263d4f26b996796d01b6a3b783449e0f5" :authors
  '(("Jon Oddie, Bruce Ravel, Phil Type"))
  :maintainer
  '("Maxime Tréca <maxime@gmail.com>, Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("data" "gnuplot" "plotting")
  :url "https://github.com/emacs-gnuplot/gnuplot")
;; Local Variables:
;; no-byte-compile: t
;; End:
