;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20261126.2011"
  "Advent of Code mode."
  '((emacs "30.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "b10007850442d1b6296398b208b6b0b4d61b1596"
  :revdesc "b10007850442"
  :keywords '("tools")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
