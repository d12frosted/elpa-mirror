;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260827.939"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ccd9d27408752172c4abdb5a6fc7f94b50666752"
  :revdesc "ccd9d2740875"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
