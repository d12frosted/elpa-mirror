;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mpv-notes" "20260224.1801"
  "Take notes in org mode while watching videos in mpv."
  '((emacs "28.1"))
  :url "https://github.com/bpanthi977/org-mpv-notes"
  :commit "bb0e6b2dd5a9dd51d8f3dfa95302f245934391db"
  :revdesc "bb0e6b2dd5a9"
  :authors '(("Bibek Panthi" . "bpanthi977@gmail.com"))
  :maintainers '(("Bibek Panthi" . "bpanthi977@gmail.com")))
