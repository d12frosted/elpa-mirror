(define-package "workgroups2" "20211222.12" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "a1ebdce7a897ae6f75f8090f22cb6d33783f7bcb" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
