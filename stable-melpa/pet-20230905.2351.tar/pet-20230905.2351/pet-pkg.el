(define-package "pet" "20230905.2351" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0")
    (map "3.3.1")
    (seq "2.24"))
  :commit "479a4371e518592c9f2e128f3b3e66e607090653" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
