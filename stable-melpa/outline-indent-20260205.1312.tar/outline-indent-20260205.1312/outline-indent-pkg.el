;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260205.1312"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "8bc2d23d8a490f6abf80c43c809dfbd95d296c62"
  :revdesc "8bc2d23d8a49"
  :keywords '("outlines"))
