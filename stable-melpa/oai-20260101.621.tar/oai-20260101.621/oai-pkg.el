;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260101.621"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "43917fd0a7cf1e87a7f356c93a4d6f83ebeeef4c"
  :revdesc "43917fd0a7cf"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
