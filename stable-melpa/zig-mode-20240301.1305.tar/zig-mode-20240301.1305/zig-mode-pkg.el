(define-package "zig-mode" "20240301.1305" "A major mode for the Zig programming language"
  '((emacs "26.1")
    (reformatter "0.6"))
  :commit "5ca49c9e4ee9b773f414c6259f1428a09c6129c2" :authors
  '(("Andrea Orru" . "andreaorru1991@gmail.com")
    ("Andrew Kelley" . "superjoe30@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("zig" "languages")
  :url "https://github.com/zig-lang/zig-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
