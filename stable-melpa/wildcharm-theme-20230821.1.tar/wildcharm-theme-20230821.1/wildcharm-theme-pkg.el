(define-package "wildcharm-theme" "20230821.1" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "297c72eef2b4ec48abc8cb99640c101e4e164c94" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
