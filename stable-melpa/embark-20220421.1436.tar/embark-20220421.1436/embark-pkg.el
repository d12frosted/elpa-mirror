(define-package "embark" "20220421.1436" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c7b6a00bb864082658029474a5d5457ed0a49135" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
