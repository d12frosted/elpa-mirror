;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emojify-logos" "20180814.917"
  "Add logos to emojify."
  '((emojify "0.4"))
  :url "https://github.com/mxgoldstein/emojify-logos"
  :commit "a3e78bcbdf863092d4c9b026ac08bf7d1c7c0e8b"
  :revdesc "a3e78bcbdf86"
  :authors '(("mxgoldstein" . "m_goldstein@gmx.net"))
  :maintainers '(("mxgoldstein" . "m_goldstein@gmx.net")))
