(define-package "elpher" "20210730.1236" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "2f0cf000c8bdcf18f8622e99a070d74502ed8093" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
