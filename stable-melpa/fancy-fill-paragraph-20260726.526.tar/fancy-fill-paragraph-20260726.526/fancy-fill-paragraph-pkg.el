;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-fill-paragraph" "20260726.526"
  "Fancy paragraph fill."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-fancy-fill-paragraph"
  :commit "3af940b027a08a4a5e2d8fca157eb0377e2f40ff"
  :revdesc "3af940b027a0"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
