(define-package "lpy" "20220818.1613" "A lispy interface to Python"
  '((emacs "25.1")
    (lispy "0.27.0"))
  :commit "ce78a4613458790cc785c1687af7eed8f0d8d66c" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("python" "lisp")
  :url "https://github.com/abo-abo/lpy")
;; Local Variables:
;; no-byte-compile: t
;; End:
