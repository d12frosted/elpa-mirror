;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260124.953"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "b32f0a340a767560abfc8981091e2eeca5102393"
  :revdesc "b32f0a340a76"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
