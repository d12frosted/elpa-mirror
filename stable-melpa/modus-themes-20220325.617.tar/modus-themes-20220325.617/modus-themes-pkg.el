(define-package "modus-themes" "20220325.617" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "03f7046dff86c5342af778ad3f9850af7e950aed" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
