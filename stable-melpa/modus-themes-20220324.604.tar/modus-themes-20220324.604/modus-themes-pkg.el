(define-package "modus-themes" "20220324.604" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "69acc6148f002490800f6b6c7fb52dcfb27e974c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
