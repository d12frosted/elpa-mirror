;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260926.1221"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "cda0f2f563606ba6bd07ba3dbeb2c249d7850a29"
  :revdesc "cda0f2f56360"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
