;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-autotask" "20260824.747"
  "Email automation for mu4e."
  '((emacs "29.1"))
  :url "https://github.com/laurynas-biveinis/mu4e-autotask"
  :commit "2175192cdd6289d35d2e85e8cc97dfc83e8a9c51"
  :revdesc "2175192cdd62"
  :keywords '("mail")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
