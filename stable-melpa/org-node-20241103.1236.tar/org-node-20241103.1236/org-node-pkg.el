;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241103.1236"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "29ee2f1a6ed14061516ab72b27b691f4a1012ba4"
  :revdesc "29ee2f1a6ed1"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
