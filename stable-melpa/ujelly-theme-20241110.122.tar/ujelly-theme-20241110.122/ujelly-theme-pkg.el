;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ujelly-theme" "20241110.122"
  "Ujelly theme for GNU Emacs 24 (deftheme)."
  ()
  :url "https://github.com/marktran/color-theme-ujelly"
  :commit "5dbd7c380f8c6f474f08262aaf8dc7641ee603eb"
  :revdesc "5dbd7c380f8c"
  :authors '(("Mark Tran" . "mark.tran@gmail.com"))
  :maintainers '(("Mark Tran" . "mark.tran@gmail.com")))
