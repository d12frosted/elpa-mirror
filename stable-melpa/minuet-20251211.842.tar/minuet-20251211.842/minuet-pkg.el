;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20251211.842"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "4d2c3014085e122ff9012697f378c127790e412c"
  :revdesc "4d2c3014085e"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
