;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sideline-lsp" "20260503.1235"
  "Show lsp information with sideline."
  '((emacs    "29.1")
    (sideline "0.1.0")
    (lsp-mode "6.0")
    (dash     "2.18.0")
    (ht       "2.4")
    (s        "1.12.0"))
  :url "https://github.com/emacs-sideline/sideline-lsp"
  :commit "393459a7a947a62eb3f1d587fe576937afefb63f"
  :revdesc "393459a7a947"
  :keywords '("convenience" "lsp")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
