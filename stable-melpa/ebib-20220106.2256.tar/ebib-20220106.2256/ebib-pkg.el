(define-package "ebib" "20220106.2256" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "e2fee50b6589a52b5f45de45d19370cf0eb1f805" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
