(define-package "org-ref" "20240220.127" "citations, cross-references and bibliographies in org-mode"
  '((org "9.4")
    (dash "0")
    (s "0")
    (f "0")
    (htmlize "0")
    (hydra "0")
    (avy "0")
    (parsebib "0")
    (bibtex-completion "0")
    (citeproc "0")
    (ox-pandoc "0")
    (request "0"))
  :commit "c08713a99c89a64ed0cdf60ad08ef5c158e5b8ae" :authors
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainers
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainer
  '("John Kitchin" . "jkitchin@andrew.cmu.edu")
  :keywords
  '("org-mode" "cite" "ref" "label")
  :url "https://github.com/jkitchin/org-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
