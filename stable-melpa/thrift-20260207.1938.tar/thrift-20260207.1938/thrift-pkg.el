;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260207.1938"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "4022aedee5acd37660c37faf125ce5b4ec7f44ae"
  :revdesc "4022aedee5ac"
  :keywords '("languages"))
