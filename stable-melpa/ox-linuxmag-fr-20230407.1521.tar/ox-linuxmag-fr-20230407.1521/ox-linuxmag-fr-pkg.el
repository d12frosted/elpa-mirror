(define-package "ox-linuxmag-fr" "20230407.1521" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "3cec81690345b3e53a0a21ecae70bbf3dccde086" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
