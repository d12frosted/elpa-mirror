;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250116.535"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "450903f71a52a8ec13ac20a5a633b0162d771b53"
  :revdesc "450903f71a52"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
