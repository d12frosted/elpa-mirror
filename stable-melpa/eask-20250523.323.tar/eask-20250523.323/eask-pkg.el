;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20250523.323"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "7d88cb0626e99920ff98499f2e456bc0178e3cbc"
  :revdesc "7d88cb0626e9"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
