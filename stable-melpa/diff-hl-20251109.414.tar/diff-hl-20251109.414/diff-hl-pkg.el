;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20251109.414"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "f61c3ec888ee5451cb8753f67aa54ae06f23274d"
  :revdesc "f61c3ec888ee"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
