;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260217.1345"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "0182193715eab0498eb23fef75f14095da2ebf6a"
  :revdesc "0182193715ea"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
