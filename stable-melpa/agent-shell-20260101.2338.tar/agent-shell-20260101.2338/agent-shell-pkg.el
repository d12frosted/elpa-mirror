;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260101.2338"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "57a7947632f4a2cd94cce034f60a8da0c3ca77d6"
  :revdesc "57a7947632f4")
