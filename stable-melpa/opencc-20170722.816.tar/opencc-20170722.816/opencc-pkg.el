;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "opencc" "20170722.816"
  "中文简繁转换 <-> 中文簡繁轉換 (Convert Chinese with OpenCC)."
  '((emacs "24.4"))
  :url "https://github.com/xuchunyang/emacs-opencc"
  :commit "959d9ffbae095752182026e3bd9b8fd61178c39f"
  :revdesc "959d9ffbae09"
  :keywords '("chinese")
  :authors '((nil . "mail@xuchunyang.me"))
  :maintainers '((nil . "mail@xuchunyang.me")))
