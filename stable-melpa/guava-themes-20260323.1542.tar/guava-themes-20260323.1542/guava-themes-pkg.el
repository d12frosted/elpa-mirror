;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260323.1542"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "a3c298d66b8b8c3d2b6af768cb8a6447f1159473"
  :revdesc "a3c298d66b8b"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
