(define-package "org-projectile" "20230814.159" "Repository todo capture and management for org-mode with projectile"
  '((projectile "2.3.0")
    (dash "2.10.0")
    (org-category-capture "1.0.0"))
  :commit "ae8a474700298b5f8a511eb6952fa69647b4fa04" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "projectile" "todo" "tools" "outlines" "project" "capture")
  :url "https://github.com/colonelpanic8/org-project-capture")
;; Local Variables:
;; no-byte-compile: t
;; End:
