;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-grimoire" "20260812.1624"
  "Emacs-native static site generator."
  '((emacs "30.2")
    (org   "9.7.11"))
  :url "https://github.com/spiperac/org-grimoire"
  :commit "23075cbdacc65e1fbc22dd7a3c0b3ced4d96a74d"
  :revdesc "23075cbdacc6"
  :keywords '("files" "hypermedia" "outlines" "text")
  :authors '(("Strahinja Piperac" . "sp@spiperac.dev"))
  :maintainers '(("Strahinja Piperac" . "sp@spiperac.dev")))
