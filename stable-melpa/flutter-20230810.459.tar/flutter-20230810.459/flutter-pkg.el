(define-package "flutter" "20230810.459" "Tools for working with Flutter SDK"
  '((emacs "25.1"))
  :commit "3ff50b77e35951e93fd1e23f113b861d398d0c1b" :authors
  '(("Aaron Madlon-Kay"))
  :maintainers
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("languages")
  :url "https://github.com/amake/flutter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
