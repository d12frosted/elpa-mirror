;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260201.454"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "3a573b95fd254994215aa4e91313140398eba5d8"
  :revdesc "3a573b95fd25"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
