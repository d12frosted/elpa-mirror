;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261102.725"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "458dee0da612c2c6edde865ba04965bd0ab6cd0f"
  :revdesc "458dee0da612"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
