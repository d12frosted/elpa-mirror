;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20251231.1559"
  "Unified interface for multiple AI coding CLI tool."
  '((emacs     "26.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "cd41ee6fb285af36e9e1ff9bfd261f3d7dbe415a"
  :revdesc "cd41ee6fb285"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
