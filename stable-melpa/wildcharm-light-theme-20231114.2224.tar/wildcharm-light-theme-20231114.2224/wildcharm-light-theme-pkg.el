(define-package "wildcharm-light-theme" "20231114.2224" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "7ccee2953001b76f251a087e941f227c1f63bfec" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
