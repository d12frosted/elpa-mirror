;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-tree-sitter" "20250710.1152"
  "Provides evil textobjects using tree-sitter."
  '((emacs "25.1"))
  :url "https://github.com/meain/evil-textobj-tree-sitter"
  :commit "569602a7eca7421afe06255f89ffe13f6f496627"
  :revdesc "569602a7eca7"
  :keywords '("evil" "tree-sitter" "text-object" "convenience"))
