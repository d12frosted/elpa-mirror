;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250603.1816"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.14.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "4bcf8f5dce18dfe4d1099129e34bf9955216e4fe"
  :revdesc "4bcf8f5dce18"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
