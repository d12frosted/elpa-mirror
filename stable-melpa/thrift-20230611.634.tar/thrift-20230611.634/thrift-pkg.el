(define-package "thrift" "20230611.634" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "2e9248b8d7617a471133e109924c0f4bc96377c4" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
