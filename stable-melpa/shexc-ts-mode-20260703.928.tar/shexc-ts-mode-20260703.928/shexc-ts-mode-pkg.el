;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "20260703.928"
  "Tree-sitter major mode for ShExC."
  '((emacs     "29.1")
    (transient "0.5.0")
    (compat    "29.1.4.4"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "74204f28991ed1d37e08ef74fbba2df7351508f6"
  :revdesc "74204f28991e"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
