(define-package "sniem" "20210813.1326" "Simple united editing method"
  '((emacs "26.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "6ca9af9cf9191c3752f1870166532ee32a98fb0e" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
