(define-package "dired-duplicates" "20231109.1353" "Find duplicate files locally and remotely"
  '((emacs "27.1"))
  :commit "349eebbd8b3fc10fa2a4551426769d20744e2eb2" :authors
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainers
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainer
  '("Harald Judt" . "h.judt@gmx.at")
  :keywords
  '("files")
  :url "https://codeberg.org/hjudt/dired-duplicates")
;; Local Variables:
;; no-byte-compile: t
;; End:
