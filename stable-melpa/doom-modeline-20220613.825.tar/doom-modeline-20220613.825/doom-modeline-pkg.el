(define-package "doom-modeline" "20220613.825" "A minimal and modern mode-line"
  '((emacs "25.1")
    (shrink-path "0.2.0")
    (dash "2.11.0"))
  :commit "3783e86a4e616b720f7d6c73b8372eae6471280a" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
