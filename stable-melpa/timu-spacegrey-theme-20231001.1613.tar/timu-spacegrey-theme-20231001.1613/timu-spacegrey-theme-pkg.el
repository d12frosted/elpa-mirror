(define-package "timu-spacegrey-theme" "20231001.1613" "Color theme inspired by the Spacegray theme in Sublime Text"
  '((emacs "26.1"))
  :commit "a8b06a6a083ad1e23b53d8e5b53f1c0a93498c03" :authors
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers
  '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainer
  '("Aimé Bertrand" . "aime.bertrand@macowners.club")
  :keywords
  '("faces" "themes")
  :url "https://gitlab.com/aimebertrand/timu-spacegrey-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
