(define-package "racket-mode" "20211027.1615" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "a093a4483dac8565fd2dcb7e401e00791091975d" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
