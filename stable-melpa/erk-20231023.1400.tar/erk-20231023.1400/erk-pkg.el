(define-package "erk" "20231023.1400" "Elisp (GitHub) Repository Kit"
  '((emacs "28.1")
    (auto-compile "1.2.0")
    (dash "2.18.0"))
  :commit "a982619ef62e403fed47136333b8762556c39a64" :authors
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainers
  '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainer
  '("Positron Solutions" . "contact@positron.solutions")
  :keywords
  '("convenience" "programming")
  :url "http://github.com/positron-solutions/elisp-repo-kit")
;; Local Variables:
;; no-byte-compile: t
;; End:
