;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "20261119.2016"
  "IDE features made available out of the box."
  '((emacs "28.2"))
  :url "https://forge.tedomum.net/hjuvi/eide"
  :commit "bfe7e33b8f62c476842ab7a57e9186a816f6209a"
  :revdesc "bfe7e33b8f62"
  :authors '(("Cédric Marie" . "hjuvi@tedomum.fr"))
  :maintainers '(("Cédric Marie" . "hjuvi@tedomum.fr")))
