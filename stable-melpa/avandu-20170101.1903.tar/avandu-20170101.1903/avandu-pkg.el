(define-package "avandu" "20170101.1903" "Gateway to Tiny Tiny RSS" 'nil :commit "f44588d8e747fa880411cb4542cc39962252b90a" :authors
  '(("Tom Willemse" . "tom@ryuslash.org"))
  :maintainer
  '("Tom Willemse" . "tom@ryuslash.org")
  :keywords
  '("net"))
;; Local Variables:
;; no-byte-compile: t
;; End:
