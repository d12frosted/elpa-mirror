(define-package "avandu" "20170101.1903" "Gateway to Tiny Tiny RSS" 'nil :commit "f44588d8e747fa880411cb4542cc39962252b90a" :keywords
  ("net")
  :authors
  (("Tom Willemse" . "tom@ryuslash.org"))
  :maintainer
  ("Tom Willemse" . "tom@ryuslash.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
