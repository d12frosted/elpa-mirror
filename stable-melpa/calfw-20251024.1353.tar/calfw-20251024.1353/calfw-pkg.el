;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251024.1353"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "a450ce625c0b0d778995d094cd17605e1abc8de8"
  :revdesc "a450ce625c0b"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
