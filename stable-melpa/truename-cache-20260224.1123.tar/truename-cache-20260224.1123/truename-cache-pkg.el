;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260224.1123"
  "Efficiently de-dup file-names."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "6536896f9b16218c0b85fc624b160e2b7f169f0d"
  :revdesc "6536896f9b16"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
