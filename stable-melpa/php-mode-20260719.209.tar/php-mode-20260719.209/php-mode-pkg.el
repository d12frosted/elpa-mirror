;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20260719.209"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "6ebe4a618aa64db3e15f809b036c1b1a6d05c030"
  :revdesc "6ebe4a618aa6"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
