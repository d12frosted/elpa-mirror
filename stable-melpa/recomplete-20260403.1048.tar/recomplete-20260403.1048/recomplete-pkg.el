;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recomplete" "20260403.1048"
  "Immediately (re)complete actions."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-recomplete"
  :commit "c0b1a38cceb3cd65c8e6004f527eba293caafeef"
  :revdesc "c0b1a38cceb3"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
