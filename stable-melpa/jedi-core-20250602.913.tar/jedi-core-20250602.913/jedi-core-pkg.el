;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jedi-core" "20250602.913"
  "Common code of jedi.el and company-jedi.el."
  '((emacs              "24")
    (epc                "0.1.0")
    (python-environment "0.0.2")
    (cl-lib             "0.5"))
  :url "https://github.com/tkf/emacs-jedi"
  :commit "61a3856b2761482dbd0bb59ecf500facb7cdead7"
  :revdesc "61a3856b2761"
  :authors '(("Takafumi Arakaki" . "aka.tkfatgmail.com"))
  :maintainers '(("Takafumi Arakaki" . "aka.tkfatgmail.com")))
