(define-package "matlab-mode" "20221008.1623" "Major mode for MATLAB(R) dot-m files" 'nil :commit "e0d127935c7a45b1178182a43ab000f41a9f73d7")
;; Local Variables:
;; no-byte-compile: t
;; End:
