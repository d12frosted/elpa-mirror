;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "20260107.2102"
  "IDE features made available out of the box."
  '((emacs "26.1"))
  :url "https://forge.tedomum.net/hjuvi/eide"
  :commit "9918d623124fdb4111faf0cf6c3f55be43a6b070"
  :revdesc "9918d623124f"
  :authors '(("Cédric Marie" . "hjuvi@tedomum.fr"))
  :maintainers '(("Cédric Marie" . "hjuvi@tedomum.fr")))
