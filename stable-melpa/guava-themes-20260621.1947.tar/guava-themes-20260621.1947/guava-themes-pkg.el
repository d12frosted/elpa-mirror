;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260621.1947"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "550247dca3bf268d68a703affd25e1aaa72665f5"
  :revdesc "550247dca3bf"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
