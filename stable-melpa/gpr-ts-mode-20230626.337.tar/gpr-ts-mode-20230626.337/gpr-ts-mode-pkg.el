(define-package "gpr-ts-mode" "20230626.337" "Major mode for GNAT project files using Tree-Sitter"
  '((emacs "29"))
  :commit "c3ef169ff86dbd13b3d538219acc1d17da133688" :authors
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainer
  '("Troy Brown" . "brownts@troybrown.dev")
  :keywords
  '("gpr" "gnat" "ada" "languages" "tree-sitter")
  :url "https://github.com/brownts/gpr-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
