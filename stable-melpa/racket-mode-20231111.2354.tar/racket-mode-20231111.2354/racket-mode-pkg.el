(define-package "racket-mode" "20231111.2354" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "1069f268a2d212b4fbac7dc8ac328982f0a9ee38" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
