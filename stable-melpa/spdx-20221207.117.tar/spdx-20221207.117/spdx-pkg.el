(define-package "spdx" "20221207.117" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "67a25c09d5783f077cea894693e61fd0d37e8492" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
