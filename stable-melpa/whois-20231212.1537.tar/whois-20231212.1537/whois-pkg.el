(define-package "whois" "20231212.1537" "Syntax highlighted domain name queries using system whois"
  '((emacs "24"))
  :commit "0ebaf5be65db1ece8a43ede973aa20893d90f72e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("network" "comm")
  :url "https://github.com/lassik/emacs-whois")
;; Local Variables:
;; no-byte-compile: t
;; End:
