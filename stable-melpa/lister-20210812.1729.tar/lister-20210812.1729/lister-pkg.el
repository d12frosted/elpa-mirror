(define-package "lister" "20210812.1729" "Yet another list printer"
  '((emacs "26.1"))
  :commit "6cf957f22a94a2dd7671a69b53f359e29da92959" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("hypermedia")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
