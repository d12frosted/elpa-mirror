(define-package "fedi" "20230812.1530" "Helper functions for fediverse clients"
  '((emacs "28.1"))
  :commit "b898abb1d9b29f386b586d72f62596d298392987" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
