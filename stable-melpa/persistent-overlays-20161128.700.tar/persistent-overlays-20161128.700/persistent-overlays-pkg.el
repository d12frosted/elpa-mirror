;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persistent-overlays" "20161128.700"
  "Minor mode to store selected overlays to be loaded later."
  ()
  :url "https://github.com/mneilly/Emacs-Persistent-Overlays"
  :commit "f563c8b966edc78c9d806661c4eb80e4781c4eab"
  :revdesc "f563c8b966ed"
  :keywords '("overlays" "persistent")
  :authors '(("Michael Neilly" . "mneilly@yahoo.com"))
  :maintainers '(("Michael Neilly" . "mneilly@yahoo.com")))
