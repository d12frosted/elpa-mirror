(define-package "mini-echo" "20231118.957" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "d0c3021cc7d0c3f1e8d4878f61c11c20bcc6af64" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
