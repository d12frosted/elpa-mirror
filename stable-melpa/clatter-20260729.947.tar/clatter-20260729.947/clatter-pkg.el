;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260729.947"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "b5a8c948d4f2026618f2206ff354417f83223888"
  :revdesc "b5a8c948d4f2"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
