(define-package "compiler-explorer" "20221108.825" "Compiler explorer client (godbolt.org)"
  '((emacs "26.1")
    (request "0.3.0"))
  :commit "36a2cbf0863d4563096546c38ff26db3d7a3e18c" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("c" "tools")
  :url "https://github.com/mkcms/compiler-explorer.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
