;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260723.243"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "cdb798d6c5e235c26059b73e6a4e26d5d9241519"
  :revdesc "cdb798d6c5e2"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
