;;; tok-faces.el --- Face definitions for my theme -*- lexical-binding: t; -*-

;; Copyright (C) 2021, Topi Kettunen <topi@topikettunen.com>

;; Author: Topi Kettunen <topi@topikettunen.com>
;; URL: https://github.com/topikettunen/tok-theme
;; Version: 0.1
;; Package-Requires: ((emacs "24.3"))

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <http://www.gnu.org/licenses/>.

;; This file is not part of Emacs.

;;; Commentary:

;; Face definition for my theme

;;; Code: 

(defvar tok-definition
  '((custom-theme-set-faces
     theme-name
     `(default ((,class (:background ,bg :foreground ,fg))))
     `(highlight ((,class (:foreground ,fg-highlight :background ,bg-highlight))))
     `(hl-line ((,class (:background  ,hl-line))))
     `(fringe ((,class (:background ,bg :foreground ,fg))))
     `(cursor ((,class (:background ,fg))))
     `(mode-line ((,class (:foreground ,fg-active :background ,bg-active :box (:line-width 1 :color ,fg-highlight)))))
     (when (>= emacs-major-version 29)
       `(mode-line-active ((,class :inherit mode-line))))
     `(mode-line-inactive ((,class (:foreground ,fg-inactive :background ,bg-inactive :box (:line-width 1 :color ,fg-highlight)))))
     `(font-lock-comment-face ((,class (:foreground ,comment))))
     (when (>= emacs-major-version 26)
       `(line-number-current-line ((,class (:background ,hl-line)))))
     `(org-block ((,class (:foreground ,fg :extend t :inherit (fixed-pitch shadow)))))
     `(terraform--resource-name-face ((,class (:inherit ,font-lock-keyword-face)))))))

(provide 'tok-faces)

;;; tok-faces.el ends here
