;;; tok-palettes.el --- Palettes for my theme -*- lexical-binding: t; -*-

;; Copyright (C) 2021, Topi Kettunen <topi@topikettunen.com>

;; Author: Topi Kettunen <topi@topikettunen.com>
;; URL: https://github.com/topikettunen/tok-theme
;; Version: 0.1
;; Package-Requires: ((emacs "24.3"))

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program. If not, see <http://www.gnu.org/licenses/>.

;; This file is not part of Emacs.

;;; Commentary:

;; Color palettes for the my theme.

;;; Code:

(defvar tok-dark-color-palette-alist
  '((fg . "#ffffff")
    (fg-highlight . "#b8b8b8")
    (bg . "#000000")
    (bg-highlight . "#808080")
    (hl-line . "#333333")
    (bg-inactive . "#323232")
    (fg-inactive . "#f4f4f4")
    (bg-active . "#1e1e1e")
    (fg-active . "#bfc0c4")
    (comment . "#999999"))
  "Dark palette")

(defvar tok-light-color-palette-alist
  '((fg . "#000000")
    (fg-highlight . "#515151")
    (bg . "#ffffff")
    (bg-highlight . "#808080")
    (hl-line . "#cccccc")
    (bg-inactive . "#d7d7d7")
    (fg-inactive . "#0a0a0a")
    (bg-active . "#efefef")
    (fg-active . "#404148")
    (comment . "#999999"))
  "Light palette")

(provide 'tok-palettes)

;;; tok-palettes.el ends here
