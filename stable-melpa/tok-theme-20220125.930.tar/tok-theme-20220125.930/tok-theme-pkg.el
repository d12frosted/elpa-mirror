(define-package "tok-theme" "20220125.930" "My theme"
  '((emacs "24.3"))
  :commit "1f9709697c02f705b509bdd8aa4898d2d85a006e" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
