(define-package "modus-themes" "20220508.909" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "4da9042dbcf003986dcabcdbccd5cd8f9b583f76" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
