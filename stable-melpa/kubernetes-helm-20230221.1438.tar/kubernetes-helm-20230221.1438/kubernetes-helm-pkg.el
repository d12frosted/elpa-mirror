;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubernetes-helm" "20230221.1438"
  "Extension for helm, the package manager for kubernetes."
  '((yaml-mode "0.0.13")
    (emacs     "25.3"))
  :url "https://github.com/abrochard/kubernetes-helm"
  :commit "f70e2efa6ef869143ccb2f158f4ab7df91dcc58f"
  :revdesc "f70e2efa6ef8"
  :keywords '("kubernetes" "helm" "k8s" "tools" "processes"))
