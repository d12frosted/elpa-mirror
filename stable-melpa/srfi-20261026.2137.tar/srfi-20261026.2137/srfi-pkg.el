;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20261026.2137"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "01701cc9fa197c50627d87e7f5f0a3ea8b1ea22e"
  :revdesc "01701cc9fa19"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
