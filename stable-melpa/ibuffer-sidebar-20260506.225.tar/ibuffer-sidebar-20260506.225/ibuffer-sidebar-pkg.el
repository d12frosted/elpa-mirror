;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-sidebar" "20260506.225"
  "Sidebar for `ibuffer'."
  '((emacs "25.1"))
  :url "https://github.com/jojojames/ibuffer-sidebar"
  :commit "c634bcbf03bc81035bbc3e9f85e75b5419f16a35"
  :revdesc "c634bcbf03bc"
  :keywords '("ibuffer" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
