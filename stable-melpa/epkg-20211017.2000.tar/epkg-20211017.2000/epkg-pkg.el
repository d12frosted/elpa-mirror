(define-package "epkg" "20211017.2000" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "9be7c61fe119d9d984d8f3a91139c794300a77f2" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
