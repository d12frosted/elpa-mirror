(define-package "epkg" "20211017.2000" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "8fa633c278241df577200c6c94102a0fa07bf8a5" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
