(define-package "helm-core" "20230913.1624" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "6bf5f5a20f062ce56312044e972bf49f457578dc" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
