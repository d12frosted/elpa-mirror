(define-package "journalctl-mode" "20231112.1045" "Sample major mode for  viewing output journalctl"
  '((emacs "27.1"))
  :commit "aef9162171118ef8e6ab411b26b763c9c6ea9e2f" :authors
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainers
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainer
  '("Sebastian Meisel" . "sebastian.meisel@gmail.com")
  :keywords
  '("unix")
  :url "https://github.com/SebastianMeisel/journalctl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
