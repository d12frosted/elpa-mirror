;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260824.908"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "df51a184951f35867bd73428c5d0b2b8151dd0b0"
  :revdesc "df51a184951f"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
