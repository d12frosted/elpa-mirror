(define-package "nordic-night-theme" "20230605.2045" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "e935956392bc78cf895eaa5df9f4c8f5da76dc8d" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
