(define-package "buttercup" "20230119.2337" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "07a52c99695845a0089e828d43da154c0ba0c178" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
