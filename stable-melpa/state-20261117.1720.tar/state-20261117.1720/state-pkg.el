;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "state" "20261117.1720"
  "Quick navigation between workspaces."
  '((emacs "24"))
  :url "https://github.com/thisirs/state.git"
  :commit "6d95661bfbb680f4fb2ad2de78ac877ef03909bd"
  :revdesc "6d95661bfbb6"
  :keywords '("convenience" "workspaces")
  :authors '(("Sylvain Rousseau" . "thisirsatgmaildotcom"))
  :maintainers '(("Sylvain Rousseau" . "thisirsatgmaildotcom")))
