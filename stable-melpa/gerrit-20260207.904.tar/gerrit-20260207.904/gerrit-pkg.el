;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gerrit" "20260207.904"
  "Gerrit client."
  '((emacs "29.1")
    (magit "2.13.1")
    (s     "1.12.0")
    (dash  "0.2.15"))
  :url "https://github.com/twmr/gerrit.el"
  :commit "2f6d4dd16678fafd8e49a247f7b9da23507e9994"
  :revdesc "2f6d4dd16678"
  :keywords '("extensions")
  :authors '(("Thomas Wimmer" . "thomaswimmer@posteo.com"))
  :maintainers '(("Thomas Wimmer" . "thomaswimmer@posteo.com")))
