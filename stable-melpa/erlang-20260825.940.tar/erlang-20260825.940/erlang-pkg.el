;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20260825.940"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "9b155fcc2bc05efa1bc8aa05db540852151c5a11"
  :revdesc "9b155fcc2bc0"
  :keywords '("erlang" "languages" "processes"))
