(define-package "ztree" "20210409.1841" "Text mode directory tree"
  '((cl-lib "0"))
  :commit "c9ad9136d52ca5a81475693864e255d29448f43f" :authors
  '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com"))
  :maintainer
  '("Alexey Veretennikov" . "alexey.veretennikov@gmail.com")
  :keywords
  '("files" "tools")
  :url "https://github.com/fourier/ztree")
;; Local Variables:
;; no-byte-compile: t
;; End:
