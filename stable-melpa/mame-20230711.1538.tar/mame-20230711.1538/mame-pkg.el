(define-package "mame" "20230711.1538" "A MAME front-end"
  '((emacs "27.1"))
  :commit "43b78e098aaf1fd87a710e033d339137f2c16b11" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
