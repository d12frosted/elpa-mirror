;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260617.2228"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "328b34cedbceff88fd8fbf096e6230deb0ac3dcb"
  :revdesc "328b34cedbce"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
