;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260311.2348"
  "Emacs frontend for pi coding agent."
  '((emacs      "29.1")
    (transient  "0.9.0")
    (md-ts-mode "0.3.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "362b6f36f28449e38d825cdbf32842f141ecb6d7"
  :revdesc "362b6f36f284"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
