(define-package "citar" "20211121.2320" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (s "1.12")
    (parsebib "3.0")
    (org "9.5"))
  :commit "41ec5d4d5d625f7d784b4de20d14b7bceaf1730c" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
