;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-gwt" "20261123.439"
  "GWT-style BDD testing for ERT."
  '((emacs "29.4"))
  :url "https://github.com/OverbearingPearl/ert-gwt"
  :commit "66255d6656a23fba6901c4187dc48a5ec4dc79bc"
  :revdesc "66255d6656a2"
  :keywords '("lisp" "tools")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
