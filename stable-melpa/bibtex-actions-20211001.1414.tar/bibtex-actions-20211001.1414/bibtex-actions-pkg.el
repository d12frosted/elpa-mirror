(define-package "bibtex-actions" "20211001.1414" "Bibliographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0")
    (parsebib "3.0"))
  :commit "8130de52d9bf246d56bda0299ffea08108f0463b" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
