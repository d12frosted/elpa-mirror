;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250608.1328"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "e499b3102a5b7c3968e7e3b44082950874885ae0"
  :revdesc "e499b3102a5b"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
