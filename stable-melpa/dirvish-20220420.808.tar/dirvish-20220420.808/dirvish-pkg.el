(define-package "dirvish" "20220420.808" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "11a60d45c7bfba65951ac839976cfdf5386a8cb8" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
