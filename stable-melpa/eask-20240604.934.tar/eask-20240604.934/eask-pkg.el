(define-package "eask" "20240604.934" "Core Eask APIs, for Eask CLI development"
  '((emacs "26.1"))
  :commit "dd366eef582e5f59b9a23976919d6f8e19c99049" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("lisp" "eask" "api")
  :url "https://github.com/emacs-eask/eask")
;; Local Variables:
;; no-byte-compile: t
;; End:
