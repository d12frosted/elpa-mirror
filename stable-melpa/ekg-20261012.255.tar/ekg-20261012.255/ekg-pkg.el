;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261012.255"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "0b49be62e2be268f358ed586172f404f56e5266d"
  :revdesc "0b49be62e2be"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
