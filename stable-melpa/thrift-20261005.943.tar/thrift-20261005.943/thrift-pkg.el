;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20261005.943"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "ee4b51d9751f36e732d2ac9312fa67b3a78e3cfe"
  :revdesc "ee4b51d9751f"
  :keywords '("languages"))
