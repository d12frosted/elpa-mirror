;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260612.909"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.1")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7bd3913c5c486e80d199bfbaf1ac8968a6b636d2"
  :revdesc "7bd3913c5c48")
