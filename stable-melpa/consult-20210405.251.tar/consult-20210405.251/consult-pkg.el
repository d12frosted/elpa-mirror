(define-package "consult" "20210405.251" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f424025d03cd0f49898a7c888fe3edfb82257f1f" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
