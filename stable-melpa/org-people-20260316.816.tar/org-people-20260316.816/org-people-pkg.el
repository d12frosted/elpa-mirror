;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260316.816"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "c7dc540c26b5c47912b2dfd54905225df0aa4fe9"
  :revdesc "c7dc540c26b5"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
