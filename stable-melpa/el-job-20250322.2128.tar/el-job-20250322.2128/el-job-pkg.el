;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250322.2128"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "6956cef553f477cc35b1c4035423bfc9797957c3"
  :revdesc "6956cef553f4"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
