(define-package "hyperbole" "20240414.1812" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.1"))
  :commit "de692018b3cae9b6d35f9f52fcfee4f7fde8f604" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Mats Lidell" . "matsl@gnu.org"))
  :maintainer
  '("Mats Lidell" . "matsl@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
