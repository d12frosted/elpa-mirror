;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit-forge" "20260330.1127"
  "Org links to Forge issue buffers."
  '((emacs    "29.1")
    (compat   "30.1")
    (cond-let "0.2")
    (forge    "0.6")
    (magit    "4.5")
    (org      "9.7")
    (orgit    "2.1"))
  :url "https://github.com/magit/orgit-forge"
  :commit "cc9161102291b20db0ef3ed809079ae0c257dfaf"
  :revdesc "cc9161102291"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit-forge@jonas.bernoulli.dev")))
