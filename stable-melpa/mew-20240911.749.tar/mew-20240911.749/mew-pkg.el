(define-package "mew" "20240911.749" "Messaging in the Emacs World" 'nil :commit "c46d8ee784d098244abaf162660073d1d4787b60")
;; Local Variables:
;; no-byte-compile: t
;; End:
