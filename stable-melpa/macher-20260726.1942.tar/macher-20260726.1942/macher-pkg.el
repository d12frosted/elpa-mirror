;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20260726.1942"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "fe3622449d73d5404cd34d3e5cdc3419c624b81e"
  :revdesc "fe3622449d73"
  :keywords '("convenience" "gptel" "llm"))
