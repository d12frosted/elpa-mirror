;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260510.1904"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "b55085f410d5ab445def5abad1d5079512d2da86"
  :revdesc "b55085f410d5"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
