;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260325.210"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "4c84da293cec47222ae86ea8077b266c62f7f393"
  :revdesc "4c84da293cec"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
