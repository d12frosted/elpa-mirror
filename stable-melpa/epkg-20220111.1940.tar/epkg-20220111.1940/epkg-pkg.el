(define-package "epkg" "20220111.1940" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "eb23aebbfdb65e0cf21d28daf6c91a15346b78ee" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
