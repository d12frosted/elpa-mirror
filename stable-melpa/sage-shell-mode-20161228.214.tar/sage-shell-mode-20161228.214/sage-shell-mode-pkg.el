(define-package "sage-shell-mode" "20161228.214" "A front-end for Sage Math"
  '((cl-lib "0.5")
    (emacs "24.1")
    (let-alist "1.0.4")
    (deferred "0.4.0"))
  :commit "e8bc089e8dfd76f688160e2ac77aee985afeade7" :authors
  '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainer
  '("Sho Takemori" . "stakemorii@gmail.com")
  :keywords
  '("sage" "math")
  :url "https://github.com/sagemath/sage-shell-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
