;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "firstly-search" "20260220.2320"
  "Search with any key: Dired, Package, Buffer menu modes."
  '((emacs  "29.1")
    (compat "30.1"))
  :url "https://codeberg.org/Anoncheg/firstly-search"
  :commit "3d4599dcda4a2f761212ef5107260013ad73c101"
  :revdesc "3d4599dcda4a"
  :keywords '("matching" "isearch" "navigation" "dired" "packagemenu")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
