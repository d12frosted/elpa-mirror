;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "async1" "20260421.2116"
  "Unroll chain of async callbacks, parallel and sequencial."
  '((emacs  "24.1")
    (compat "30.1"))
  :url "https://github.com/Anoncheg1/emacs-async1"
  :commit "88cccffe14bdd0a61dbb2e33edf8c335706f24dc"
  :revdesc "88cccffe14bd"
  :keywords '("tools" "async" "callback" "lisp" "extensions")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
