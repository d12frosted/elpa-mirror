(define-package "arxiv-citation" "20220816.542" "Utility functions for dealing with arXiv papers"
  '((emacs "25.1")
    (dash "2.19.1")
    (s "1.12.0"))
  :commit "e41d5b90a00b79849cd2fd405b2af75a53b15abe" :authors
  '(("Tony Zorman" . "soliditsallgood@mailbox.org"))
  :maintainers
  '(("Tony Zorman" . "soliditsallgood@mailbox.org"))
  :maintainer
  '("Tony Zorman" . "soliditsallgood@mailbox.org")
  :keywords
  '("convenience")
  :url "https://gitlab.com/slotThe/arXiv-citation")
;; Local Variables:
;; no-byte-compile: t
;; End:
