;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "20260718.2159"
  "Explore and visualise Denote files."
  '((emacs         "29.1")
    (denote        "4.0")
    (dash          "2.19.1")
    (denote-regexp "20250415.2202"))
  :url "https://github.com/pprevos/denote-explore/"
  :commit "3523841e40e184c8590dde2fe61d7060924e01b6"
  :revdesc "3523841e40e1"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
