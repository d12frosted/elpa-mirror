;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alert-toast" "20220312.229"
  "Windows 10 toast notifications."
  '((emacs "25.1")
    (alert "1.2")
    (f     "0.20.0")
    (s     "1.12.0"))
  :url "https://github.com/gkowzan/alert-toast"
  :commit "96c88c93c1084de681700f655223142ee0eb944a"
  :revdesc "96c88c93c108"
  :authors '(("Grzegorz Kowzan" . "grzegorz@kowzan.eu"))
  :maintainers '(("Grzegorz Kowzan" . "grzegorz@kowzan.eu")))
