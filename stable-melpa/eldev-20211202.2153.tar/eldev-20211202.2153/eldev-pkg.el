(define-package "eldev" "20211202.2153" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "f9ad00d2670cae9573c0d6c11c82252eee1085fa" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
