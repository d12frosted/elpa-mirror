;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kixtart-mode" "20260125.12"
  "Major mode for editing KiXtart scripts."
  '((emacs "28.1")
    (eldoc "1.14.0"))
  :url "https://git.sr.ht/~mew/kixtart-mode"
  :commit "01265a2f086a0fa8d89da9a9988f12fa99592c53"
  :revdesc "01265a2f086a"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
