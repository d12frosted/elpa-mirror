(define-package "magit-libgit" "20220130.2007" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "0b3b18452cf7b72e067451a453c55c44cf1d8c89" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
