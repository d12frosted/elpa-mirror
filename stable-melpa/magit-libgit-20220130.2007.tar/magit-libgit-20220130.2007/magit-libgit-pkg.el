(define-package "magit-libgit" "20220130.2007" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "16b313ba47872613c735863e9ece4193d4fc0ec4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
