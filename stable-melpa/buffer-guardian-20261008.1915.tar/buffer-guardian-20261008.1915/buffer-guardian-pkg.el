;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20261008.1915"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "ef8adffbaa2ff2ce6498cbe4b2a510972d9a5595"
  :revdesc "ef8adffbaa2f"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
