(define-package "dwim-coder-mode" "20230625.244" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "498c28d6d74cd347352001b4f56715e7170fb473" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
