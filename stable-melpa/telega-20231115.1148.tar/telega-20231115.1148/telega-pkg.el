(define-package "telega" "20231115.1148" "Telegram client (unofficial)"
  '((emacs "27.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "140c044e6caf4206d8843c48fce5633c77c758d0" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
