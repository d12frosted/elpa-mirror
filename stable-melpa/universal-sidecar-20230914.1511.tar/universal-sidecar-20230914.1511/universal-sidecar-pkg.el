(define-package "universal-sidecar" "20230914.1511" "A universal sidecar buffer"
  '((emacs "26.1")
    (magit-section "3.0.0"))
  :commit "2c627a8862ade31f3836b1bc34f9c5f3130fad01" :authors
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainer
  '("Samuel W. Flint" . "me@samuelwflint.com")
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar")
;; Local Variables:
;; no-byte-compile: t
;; End:
