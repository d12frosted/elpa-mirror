;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260428.1022"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "4e536002d97a2c0a2b589486e2eeaad2cd295a97"
  :revdesc "4e536002d97a"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
