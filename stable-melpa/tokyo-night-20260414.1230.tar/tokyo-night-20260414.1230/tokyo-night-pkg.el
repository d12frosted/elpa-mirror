;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20260414.1230"
  "Shared infrastructure for Tokyo Night themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "3e7eaaae8a4ec4871aa06552be4b13abc99cd07a"
  :revdesc "3e7eaaae8a4e"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
