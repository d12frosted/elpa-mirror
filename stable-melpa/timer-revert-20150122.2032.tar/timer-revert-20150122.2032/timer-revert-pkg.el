;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timer-revert" "20150122.2032"
  "Minor mode to revert buffer for a given time interval."
  ()
  :url "https://github.com/yyr/timer-revert"
  :commit "615c91dec8b440d2b9b7c725dd733d7432564e45"
  :revdesc "615c91dec8b4"
  :keywords '("timer" "revert" "auto-revert.")
  :maintainers '((nil . "hi@yagnesh.org")))
