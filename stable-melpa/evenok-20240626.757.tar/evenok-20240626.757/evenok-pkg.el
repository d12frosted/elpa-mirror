(define-package "evenok" "20240626.757" "Themes with perceptively evenly distributed colors"
  '((emacs "28.1"))
  :commit "80ba81d380fe2cf953c27d228686851245d8e4b6" :authors
  '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers
  '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainer
  '("Mekeor Melire" . "mekeor@posteo.de")
  :keywords
  '("faces" "theme")
  :url "https://codeberg.org/mekeor/evenok")
;; Local Variables:
;; no-byte-compile: t
;; End:
