(define-package "doom-modeline" "20230921.646" "A minimal and modern mode-line"
  '((emacs "25.1")
    (compat "29.1.4.2")
    (nerd-icons "0.0.1")
    (shrink-path "0.3.1"))
  :commit "ec62bcd3bacdd77114ab09a0c60e3d4c6227f61a" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
