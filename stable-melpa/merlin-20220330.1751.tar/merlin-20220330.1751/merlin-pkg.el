(define-package "merlin" "20220330.1751" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "5d59c7065938ea9c9b52f368b97a50bc8bf6d65b" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
