(define-package "tree-sitter" "20210912.1211" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.15.2"))
  :commit "4d9871d23999fe5f8de821e23c9ec576df2b2738" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
