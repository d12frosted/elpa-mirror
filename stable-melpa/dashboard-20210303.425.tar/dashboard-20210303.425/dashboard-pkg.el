(define-package "dashboard" "20210303.425" "A startup screen extracted from Spacemacs"
  '((emacs "25.3")
    (page-break-lines "0.11"))
  :commit "d778a65bc8c685d9175cf3be4c1d59765916a4b7" :authors
  '(("Rakan Al-Hneiti"))
  :maintainer
  '("Rakan Al-Hneiti")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
