(define-package "humanoid-themes" "20201208.1625" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "d1d12a59daa4ba542854e9b59d73f1763219fb54" :keywords
  ("faces" "color" "theme")
  :authors
  (("Thomas Friese"))
  :maintainer
  ("Thomas Friese")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
