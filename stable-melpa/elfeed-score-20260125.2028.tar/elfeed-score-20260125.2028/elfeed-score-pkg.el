;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-score" "20260125.2028"
  "Gnus-style scoring for Elfeed."
  '((emacs  "26.1")
    (elfeed "3.3.0"))
  :url "https://github.com/sp1ff/elfeed-score"
  :commit "f6ef83c472e6f01d0f60130ecac768462c5a20b7"
  :revdesc "f6ef83c472e6"
  :keywords '("news")
  :authors '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainers '(("Michael Herstine" . "sp1ff@pobox.com")))
