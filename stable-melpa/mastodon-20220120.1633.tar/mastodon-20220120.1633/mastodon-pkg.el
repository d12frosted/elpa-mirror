(define-package "mastodon" "20220120.1633" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.2")
    (seq "1.0"))
  :commit "6d9473d8a098a23d40e9fcf2c85ccedcbc1721d2" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://git.blast.noho.st/mouse/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
