(define-package "loopy" "20210828.1741" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "e5e0380e59d751b51ff7bc0c926caea5ec22033f" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
