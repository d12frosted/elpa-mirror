;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260721.25"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "b2d7b875afb9e877061664ec9aa480355e5775c4"
  :revdesc "b2d7b875afb9"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
