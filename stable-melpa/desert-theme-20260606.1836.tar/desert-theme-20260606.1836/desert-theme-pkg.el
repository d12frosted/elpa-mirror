;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "desert-theme" "20260606.1836"
  "A warm earthy port of Vim's desert theme."
  '((emacs "27.1"))
  :url "https://github.com/bkc39/desert-theme"
  :commit "a334abfe4d624cb37bb4a2dc309f8623f42b74d1"
  :revdesc "a334abfe4d62"
  :keywords '("faces" "theme" "vim" "desert")
  :authors '(("Ben Carriel" . "notthefather@pm.me"))
  :maintainers '(("Ben Carriel" . "notthefather@pm.me")))
