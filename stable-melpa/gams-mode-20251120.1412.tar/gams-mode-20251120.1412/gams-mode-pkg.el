;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-mode" "20251120.1412"
  "Major mode for General Algebraic Modeling System (GAMS)."
  '((emacs "25.1"))
  :url "https://github.com/ShiroTakeda/gams-mode"
  :commit "ddadad84089c0dabf198585cc16592aed91a6c18"
  :revdesc "ddadad84089c"
  :keywords '("languages" "tools" "gams"))
