;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260319.843"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "cc2d54122201f1acb3c8fc459e244f12b42ddf00"
  :revdesc "cc2d54122201")
