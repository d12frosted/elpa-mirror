;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-psalm" "20211002.1555"
  "Flycheck integration for Psalm."
  '((emacs    "24.3")
    (flycheck "26")
    (psalm    "0.6.0"))
  :url "https://github.com/emacs-php/psalm.el"
  :commit "28d546a79cb865a78b94cd7e929d66d720505faa"
  :revdesc "28d546a79cb8"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
