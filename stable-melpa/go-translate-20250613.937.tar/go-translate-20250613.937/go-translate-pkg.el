;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250613.937"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.1"))
  :url "https://github.com/lorniu/go-translate"
  :commit "7e0e124f8956b0de8c031170dfae0b05dcf5c36f"
  :revdesc "7e0e124f8956"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
