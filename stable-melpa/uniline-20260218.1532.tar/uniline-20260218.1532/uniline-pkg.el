;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260218.1532"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "78bf8ffdf8c38020d5256a51a00dcabf6fc88eba"
  :revdesc "78bf8ffdf8c3"
  :keywords '("convenience" "text"))
