(define-package "merlin" "20220630.1249" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "60518062c77e1d27a7d135a24a7c31bbf27290ba" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
