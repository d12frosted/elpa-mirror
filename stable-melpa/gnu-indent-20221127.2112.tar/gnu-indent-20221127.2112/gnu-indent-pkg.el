;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnu-indent" "20221127.2112"
  "Indent your code with GNU Indent."
  '((emacs "25.1"))
  :url "https://codeberg.org/akib/emacs-gnu-indent"
  :commit "f31dbe60478b6270bb57b6b05998df8eec56f801"
  :revdesc "f31dbe60478b"
  :keywords '("tools" "c")
  :authors '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainers '(("Akib Azmain Turja" . "akib@disroot.org")))
