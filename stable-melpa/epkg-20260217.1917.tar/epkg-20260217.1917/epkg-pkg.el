;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260217.1917"
  "Browse the Emacsmirror package database."
  '((emacs   "28.1")
    (compat  "30.1")
    (closql  "2.4")
    (emacsql "4.3")
    (llama   "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "f0ae7cd28d036850fe6cb18b47742b8e892e5c09"
  :revdesc "f0ae7cd28d03"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
