(define-package "consult-tex" "20231027.1150" "Consult powered completion for tex"
  '((emacs "28.2")
    (consult "0.35"))
  :commit "a799f1a548e71151b5c0f625c9a532b670c07eb9" :authors
  '(("Titus Pinta"))
  :maintainers
  '(("Titus Pinta" . "titus.pinta@gmail.com"))
  :maintainer
  '("Titus Pinta" . "titus.pinta@gmail.com")
  :keywords
  '("consult" "tex" "latex")
  :url "https://gitlab.com/titus.pinta/consult-TeX")
;; Local Variables:
;; no-byte-compile: t
;; End:
