(define-package "racket-mode" "20220803.1446" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "89238bde54b3e9b6c85c6ce8437aa44a73fb71e1" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
