;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241022.1240"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "5543ee3cdbfe17d8bf281ebde7bf660c96562b77"
  :revdesc "5543ee3cdbfe"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
