(define-package "elixir-ts-mode" "20231025.640" "Major mode for Elixir with tree-sitter support"
  '((emacs "29.1")
    (heex-ts-mode "1.3"))
  :commit "cb536ff3e70b70004687bbf583757f6929ce0238" :authors
  '(("Wilhelm H Kirschbaum"))
  :maintainers
  '(("Wilhelm H Kirschbaum"))
  :maintainer
  '("Wilhelm H Kirschbaum")
  :keywords
  '("elixir" "languages" "tree-sitter")
  :url "https://github.com/wkirschbaum/elixir-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
