(define-package "reazon" "20210831.1208" "miniKanren for Emacs"
  '((emacs "26"))
  :commit "d697c0dfe38ac7483e453e8ce8056acf95c89ba2" :authors
  '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainer
  '("Nick Drozd" . "nicholasdrozd@gmail.com")
  :keywords
  '("languages" "extensions" "lisp")
  :url "https://github.com/nickdrozd/reazon")
;; Local Variables:
;; no-byte-compile: t
;; End:
