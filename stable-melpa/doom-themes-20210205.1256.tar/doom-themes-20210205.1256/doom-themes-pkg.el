(define-package "doom-themes" "20210205.1256" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "73775868fc67ae9cbc5807cb97f5b23038dc629f" :authors
  '(("Henrik Lissner <http://github/hlissner>"))
  :maintainer
  '("Henrik Lissner" . "henrik@lissner.net")
  :keywords
  '("dark" "light" "blue" "atom" "one" "theme" "neotree" "icons" "faces" "nova")
  :url "https://github.com/hlissner/emacs-doom-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
