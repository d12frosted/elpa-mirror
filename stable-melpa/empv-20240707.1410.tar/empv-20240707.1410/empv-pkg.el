(define-package "empv" "20240707.1410" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0")
    (compat "29.1.4.4"))
  :commit "631299ae2a918b4af17ae94eddcde4c9451235bb" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
