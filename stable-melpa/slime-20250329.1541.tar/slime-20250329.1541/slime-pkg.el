;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20250329.1541"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "62f4a5bd11480229f1aceb6bf810a995da511a0b"
  :revdesc "62f4a5bd1148"
  :keywords '("languages" "lisp" "slime"))
