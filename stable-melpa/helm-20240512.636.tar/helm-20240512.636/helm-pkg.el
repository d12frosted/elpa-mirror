(define-package "helm" "20240512.636" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.8")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "a8a2de5e2863fd3fa06f34984cfd7a36aac178b8" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
