;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260820.803"
  "MCP server for Org-mode."
  '((emacs          "28.2")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "b02d20d190ecaa6c40f044d04a1502576cdca7bb"
  :revdesc "b02d20d190ec"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
