;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dropbox" "20150114.509"
  "Move Dropbox notes from phone into org-mode datetree."
  '((dash  "2.2")
    (names "20150000")
    (emacs "24"))
  :url "https://github.com/heikkil/org-dropbox"
  :commit "2dc677a770c9e82f928ad8e97a7707eb368e58ed"
  :revdesc "2dc677a770c9"
  :keywords '("dropbox" "android" "notes" "org-mode")
  :authors '(("Heikki Lehvaslaiho" . "heikki.lehvaslaiho@gmail.com"))
  :maintainers '(("Heikki Lehvaslaiho" . "heikki.lehvaslaiho@gmail.com")))
