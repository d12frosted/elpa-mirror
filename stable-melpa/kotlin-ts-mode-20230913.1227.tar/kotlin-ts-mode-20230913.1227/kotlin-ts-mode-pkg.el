(define-package "kotlin-ts-mode" "20230913.1227" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "6b807fcf0eac023b493730349703a256ed4eb7d5" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
