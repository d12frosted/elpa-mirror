(define-package "cape" "20220414.505" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "c404b0df4a25a0fd1de852b3e0783610dba9a349" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
