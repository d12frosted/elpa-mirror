;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-indent-textobject" "20130831.2219"
  "Evil textobjects based on indentation."
  '((evil "0"))
  :url "https://github.com/cofi/evil-indent-textobject"
  :commit "70a1154a531b7cfdbb9a31d6922482791e20a3a7"
  :revdesc "70a1154a531b"
  :keywords '("convenience" "evil")
  :authors '(("Michael Markert" . "markert.michael@gmail.com"))
  :maintainers '(("Michael Markert" . "markert.michael@gmail.com")))
