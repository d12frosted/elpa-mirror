(define-package "embark" "20220918.133" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "4f924a0246120b26902dd6b047a5c843c82416f7" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
