(define-package "ox-hugo" "20220119.1939" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "b6f6e13af6a44f02ea3ab16726267038e7b5c64f" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
