(define-package "mandm-theme" "20231102.1929" "An M&M color theme." 'nil :commit "b173b41743d3e9668df2ec59df0378d8295d9902" :authors
  '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainers
  '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainer
  '("Christian Hopps" . "chopps@gmail.com")
  :url "https://github.com/choppsv1/emacs-mandm-theme.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
