;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20261128.1703"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "36038349094d916b99e0e107d85246ecd8b72015"
  :revdesc "36038349094d"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
