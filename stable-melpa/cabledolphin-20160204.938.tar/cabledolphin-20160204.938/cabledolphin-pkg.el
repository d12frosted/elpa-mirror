;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cabledolphin" "20160204.938"
  "Capture Emacs network traffic."
  '((emacs "24.4")
    (seq   "1.0"))
  :url "https://github.com/legoscia/cabledolphin"
  :commit "fffc192cafa61558e924323d6da8166fe5f2a6f9"
  :revdesc "fffc192cafa6"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "magnus.henoch@gmail.com"))
  :maintainers '(("Magnus Henoch" . "magnus.henoch@gmail.com")))
