(define-package "geiser" "20240705.1352" "GNU Emacs and Scheme talk to each other"
  '((emacs "27.1")
    (project "0.8.1"))
  :commit "410a3a50d724c0aaf8d209d6a620976828854881" :authors
  '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers
  '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
