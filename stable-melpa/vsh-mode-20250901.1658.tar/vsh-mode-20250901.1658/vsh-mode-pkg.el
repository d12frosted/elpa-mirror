;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vsh-mode" "20250901.1658"
  "Alternate PTY interface for complex terminal sessions."
  '((emacs "30.0"))
  :url "https://github.com/hardenedapple/vsh"
  :commit "47c35e3062a20418340c8150c8d5ad41c1e7d6b4"
  :revdesc "47c35e3062a2"
  :keywords '("processes")
  :authors '(("Matthew Malcomson" . "hardenedapple@gmail.com"))
  :maintainers '(("Matthew Malcomson" . "hardenedapple@gmail.com")))
