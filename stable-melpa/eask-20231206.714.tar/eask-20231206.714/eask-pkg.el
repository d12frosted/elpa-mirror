(define-package "eask" "20231206.714" "Core Eask APIs, for Eask CLI development"
  '((emacs "26.1")
    (dash "2.14.1"))
  :commit "5e5dc8f571edbe46bda778f407fc0b3f527e79e6" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("lisp" "eask" "api")
  :url "https://github.com/emacs-eask/eask")
;; Local Variables:
;; no-byte-compile: t
;; End:
