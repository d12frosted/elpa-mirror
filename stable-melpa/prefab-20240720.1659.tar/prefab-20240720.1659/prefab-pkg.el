(define-package "prefab" "20240720.1659" "Integration for project generation tools like cookiecutter"
  '((emacs "27.1")
    (f "0.2.0")
    (transient "0.3.7"))
  :commit "dbd17e8c9e5f93d3eb8e1998fa0dc170039507ca" :url "https://github.com/laurencewarne/prefab.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
