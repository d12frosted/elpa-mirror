(define-package "osx-trash" "20160520.1300" "System trash for OS X"
  '((emacs "24.1"))
  :commit "0f1dc052d0a750b8c75f14530a4897f5d4324b4e" :keywords
  ("files" "convenience" "tools" "unix")
  :authors
  (("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainer
  ("Sebastian Wiesner" . "swiesner@lunaryorn.com")
  :url "https://github.com/lunaryorn/osx-trash.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
