(define-package "citre" "20210623.1203" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "4661c9eaf95ccdd9635e3e69c6c45081d2f3df36" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
