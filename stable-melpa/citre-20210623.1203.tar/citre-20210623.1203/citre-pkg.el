(define-package "citre" "20210623.1203" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "46aa1494ceb44d13ff824a90c0afa7aa9bc7cf42" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
