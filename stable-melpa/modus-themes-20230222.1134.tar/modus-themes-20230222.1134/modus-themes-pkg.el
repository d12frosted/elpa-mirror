(define-package "modus-themes" "20230222.1134" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "d9d8463713d499aac714be84d736cb01854a02f4" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
