;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-athena" "20250706.213"
  "Run AWS Athena queries from Org Babel."
  '((emacs "26.1"))
  :url "https://github.com/will-abb/aws-athena-babel"
  :commit "2d7c289f9110fd48c4f726cd70ecd3480106b0c6"
  :revdesc "2d7c289f9110"
  :keywords '("aws" "athena" "org" "babel" "sql" "tools")
  :authors '(("Williams Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Williams Bosch-Bello" . "williamsbosch@gmail.com")))
