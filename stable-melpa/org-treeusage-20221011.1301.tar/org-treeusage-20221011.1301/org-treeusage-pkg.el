;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-treeusage" "20221011.1301"
  "Examine the usage of org headings in a tree-like manner."
  '((emacs "26.1")
    (dash  "2.17.0")
    (org   "9.1.6"))
  :url "https://github.com/mtekman/org-treeusage.el"
  :commit "c561b3d468aa35e70a43d9a18a4f505996ae882d"
  :revdesc "c561b3d468aa"
  :keywords '("outlines"))
