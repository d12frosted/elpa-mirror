;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "solaire-mode" "20260829.1703"
  "Make certain buffers grossly incandescent."
  '((emacs  "27.1")
    (cl-lib "0.5"))
  :url "https://github.com/hlissner/emacs-solaire-mode"
  :commit "702bbd3d097a1ba29a395ad0d66d22ee54985d2e"
  :revdesc "702bbd3d097a"
  :keywords '("dim" "bright" "window" "buffer" "faces")
  :authors '(("Henrik Lissner" . "http://github/hlissner"))
  :maintainers '(("Henrik Lissner" . "contact@henrik.io")))
