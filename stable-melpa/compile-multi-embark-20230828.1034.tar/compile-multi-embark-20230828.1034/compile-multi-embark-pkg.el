(define-package "compile-multi-embark" "20230828.1034" "Integration for `compile-multi' and `embark'"
  '((emacs "28.1")
    (compile-multi "0.4")
    (embark "0.22.1"))
  :commit "870baff1d9e0ab199bfa7dfd3f54c2a81ee5ba46" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/compile-multi")
;; Local Variables:
;; no-byte-compile: t
;; End:
