(define-package "rmsbolt" "20220324.1757" "A compiler output viewer"
  '((emacs "25.1"))
  :commit "d09d72f463cde47b6f861c8e20f90c6bb082c44f" :authors
  '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainer
  '("Jay Kamat" . "jaygkamat@gmail.com")
  :keywords
  '("compilation" "tools")
  :url "http://gitlab.com/jgkamat/rmsbolt")
;; Local Variables:
;; no-byte-compile: t
;; End:
