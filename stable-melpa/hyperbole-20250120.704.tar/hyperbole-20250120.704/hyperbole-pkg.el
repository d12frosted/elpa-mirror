;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250120.704"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "c91b74554fce7cb73ebe7b030f445d3bbd990974"
  :revdesc "c91b74554fce"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
