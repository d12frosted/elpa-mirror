(define-package "redshank" "20180730.407" "Common Lisp Editing Extensions"
  '((paredit "21"))
  :commit "d059c5841044aa163664f8bf87c1d981bf0a04fe" :keywords
  ("languages" "lisp")
  :authors
  (("Michael Weber" . "michaelw@foldr.org"))
  :maintainer
  ("Michael Weber" . "michaelw@foldr.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
