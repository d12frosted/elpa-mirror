(define-package "affe" "20210805.1329" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.7"))
  :commit "d8f67ceec7a6da69bfda435213dbaa2f928ebbf7" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
