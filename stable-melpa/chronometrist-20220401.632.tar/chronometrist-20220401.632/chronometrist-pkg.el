(define-package "chronometrist" "20220401.632" "Friendly and powerful personal time tracker and analyzer"
  '((emacs "27.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "25dd20f170085a913203b524365123c5089e7e2b" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
