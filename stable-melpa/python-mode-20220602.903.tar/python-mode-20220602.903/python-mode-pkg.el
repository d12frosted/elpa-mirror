(define-package "python-mode" "20220602.903" "Python major mode" 'nil :commit "b5b84cab162caf0b89ccba454d45d1dba094ecf9" :authors
  '(("2015-2021 https://gitlab.com/groups/python-mode-devs")
    ("2003-2014 https://launchpad.net/python-mode")
    ("1995-2002 Barry A. Warsaw")
    ("1992-1994 Tim Peters"))
  :maintainer
  '(nil . "python-mode@python.org")
  :keywords
  '("languages" "processes" "python" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
