;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260317.1137"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7766b11166ebe8f37afe8445973e17dedca6d591"
  :revdesc "7766b11166eb")
