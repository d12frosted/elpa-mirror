;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20251017.248"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "99188e78a061a8d05a33e07bbad3d8f16740446d"
  :revdesc "99188e78a061"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
