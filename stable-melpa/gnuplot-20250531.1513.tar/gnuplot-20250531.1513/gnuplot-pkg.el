;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250531.1513"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "ce57ddaeb3b8ca78bf198eb893481457034e1ab1"
  :revdesc "ce57ddaeb3b8"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
