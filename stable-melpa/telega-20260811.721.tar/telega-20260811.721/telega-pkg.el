;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260811.721"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "bc46f93733e63b20a4d95eb13a49b99b3b309ca6"
  :revdesc "bc46f93733e6"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
