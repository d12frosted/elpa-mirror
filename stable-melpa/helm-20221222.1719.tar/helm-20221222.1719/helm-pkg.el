(define-package "helm" "20221222.1719" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.0")
    (popup "0.5.3"))
  :commit "a0f2a47e11fe90b67e384d7d610dd4beed611cfe" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
