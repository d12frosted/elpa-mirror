;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250304.836"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "81c387a37f1462a356715c2b6dfeb6dd91c499c6"
  :revdesc "81c387a37f14"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
