;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260126.1201"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "ea2ac648acd54bc05f4a2bce8b04322010eca281"
  :revdesc "ea2ac648acd5"
  :keywords '("data" "extensions"))
