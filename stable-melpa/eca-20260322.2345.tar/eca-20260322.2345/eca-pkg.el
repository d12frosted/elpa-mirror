;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260322.2345"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "71c0a6ef5a8a8c2b554ec41c8130bce2358e2808"
  :revdesc "71c0a6ef5a8a"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
