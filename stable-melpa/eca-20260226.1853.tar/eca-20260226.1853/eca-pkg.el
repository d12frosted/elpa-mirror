;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260226.1853"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "a8bbca6caafe8c7bdda0e214f1cb7ee75bd27bf7"
  :revdesc "a8bbca6caafe"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
