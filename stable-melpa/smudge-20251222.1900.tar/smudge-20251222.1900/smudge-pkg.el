;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smudge" "20251222.1900"
  "Control the Spotify app."
  '((emacs        "27.1")
    (simple-httpd "1.5.1")
    (request      "0.3")
    (oauth2       "0.18"))
  :url "https://github.com/danielfm/smudge"
  :commit "75d9b7801783f27977531d35a1a515b2d50d97e6"
  :revdesc "75d9b7801783"
  :keywords '("multimedia" "music" "spotify" "smudge"))
