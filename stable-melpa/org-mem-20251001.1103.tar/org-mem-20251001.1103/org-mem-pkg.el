;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20251001.1103"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "bc52b62723c9d4661a0f44879953a4a09cc8f011"
  :revdesc "bc52b62723c9"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
