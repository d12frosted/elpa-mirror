;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-bar-buffers" "20260511.1927"
  "Use tab-bar-mode as a buffer manager."
  '((emacs "28.1"))
  :url "https://github.com/ajrosen/tab-bar-buffers"
  :commit "12f52b896eedd7a871df4ef985430b53bcd6c08b"
  :revdesc "12f52b896eed"
  :keywords '("convenience" "frames")
  :authors '(("Andy Rosen" . "ajr@corp.mlfs.org"))
  :maintainers '(("Andy Rosen" . "ajr@corp.mlfs.org")))
