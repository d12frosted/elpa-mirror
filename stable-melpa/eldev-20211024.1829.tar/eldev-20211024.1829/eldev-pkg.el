(define-package "eldev" "20211024.1829" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "f42b01907ff9f40bcc2cfe04808ad9477314f83c" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
