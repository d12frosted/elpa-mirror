(define-package "reazon" "20210807.1604" "miniKanren for Emacs"
  '((emacs "26"))
  :commit "1d46be4bab06cf91c7b5884e588551853fcc1eb6" :authors
  '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainer
  '("Nick Drozd" . "nicholasdrozd@gmail.com")
  :keywords
  '("languages" "extensions" "lisp")
  :url "https://github.com/nickdrozd/reazon")
;; Local Variables:
;; no-byte-compile: t
;; End:
