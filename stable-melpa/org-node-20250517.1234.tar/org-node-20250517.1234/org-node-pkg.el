;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250517.1234"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.8.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "268a60ec2e024923af1ca0156ac2edc06ab79bba"
  :revdesc "268a60ec2e02"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
