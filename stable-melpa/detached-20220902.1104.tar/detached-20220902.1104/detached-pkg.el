(define-package "detached" "20220902.1104" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "982443b3638e697fbe859faaa95eef502c13339d" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
