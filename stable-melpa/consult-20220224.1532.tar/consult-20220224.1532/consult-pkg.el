(define-package "consult" "20220224.1532" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "95d1851567637325425c0956adbf711c801dd45c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
