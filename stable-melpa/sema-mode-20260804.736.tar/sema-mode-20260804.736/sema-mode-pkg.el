;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sema-mode" "20260804.736"
  "Major mode for editing Sema files."
  '((emacs "25.1"))
  :url "https://github.com/sema-lisp/emacs-sema"
  :commit "5cbff7191883ed305b73f3f1533983acf863a935"
  :revdesc "5cbff7191883"
  :keywords '("languages" "lisp")
  :authors '(("Helge Sverre" . "helge.sverre@gmail.com"))
  :maintainers '(("Helge Sverre" . "helge.sverre@gmail.com")))
