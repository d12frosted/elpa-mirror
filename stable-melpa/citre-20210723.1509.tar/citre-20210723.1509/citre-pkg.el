(define-package "citre" "20210723.1509" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "2bcdddb60cb1a5fc0dbd00ab441efde0a1cbaee5" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
