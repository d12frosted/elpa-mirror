;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260717.842"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "65253bde9ccb69235c86797c7609c6c1d4f131f0"
  :revdesc "65253bde9ccb")
