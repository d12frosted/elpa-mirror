;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-manage" "20260626.2233"
  "Manage buffers."
  '((emacs          "26.1")
    (choice-program "0.13")
    (dash           "2.17.0"))
  :url "https://github.com/plandes/buffer-manage"
  :commit "d2b17b2556a69ec40f454f6b6b0f37b439288e04"
  :revdesc "d2b17b2556a6"
  :keywords '("internal" "maint"))
