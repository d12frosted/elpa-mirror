;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-guile" "20260511.2225"
  "Guile and Geiser talk to each other."
  '((emacs     "27.1")
    (transient "0.3")
    (geiser    "0.33"))
  :url "https://gitlab.com/emacs-geiser/guile"
  :commit "9689499699a11ac36c2b5284624d41e3e47cebd9"
  :revdesc "9689499699a1"
  :keywords '("languages" "guile" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
