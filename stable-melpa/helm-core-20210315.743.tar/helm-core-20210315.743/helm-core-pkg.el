(define-package "helm-core" "20210315.743" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "a6b15e86fdac310cdd2d8dda1cef6f330a717d75")
;; Local Variables:
;; no-byte-compile: t
;; End:
