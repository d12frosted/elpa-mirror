;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fast-scroll" "20191016.327"
  "Some utilities for faster scrolling over large buffers."
  '((emacs  "25.1")
    (cl-lib "0.6.1"))
  :url "https://github.com/ahungry/fast-scroll"
  :commit "3f6ca0d5556fe9795b74714304564f2295dcfa24"
  :revdesc "3f6ca0d5556f"
  :keywords '("ahungry" "convenience" "fast" "scroll" "scrolling")
  :authors '(("Matthew Carter" . "m@ahungry.com"))
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
