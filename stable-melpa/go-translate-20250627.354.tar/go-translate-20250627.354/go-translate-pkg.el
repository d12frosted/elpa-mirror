;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250627.354"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "7368860c208a9640c9e4baca09dd1db4f764d053"
  :revdesc "7368860c208a"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
