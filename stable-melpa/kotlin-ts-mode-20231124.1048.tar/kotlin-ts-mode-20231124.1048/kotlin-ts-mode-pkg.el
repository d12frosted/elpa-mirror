(define-package "kotlin-ts-mode" "20231124.1048" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "69c43fe95f3bd2d8432957f658ef3337c84ae769" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
