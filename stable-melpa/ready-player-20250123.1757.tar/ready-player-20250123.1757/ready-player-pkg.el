;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "20250123.1757"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "e195aacad1a230409dbfea6e756f5eb08a550df8"
  :revdesc "e195aacad1a2")
