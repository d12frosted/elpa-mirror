;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frameshot" "20260504.1722"
  "Take screenshots of a frame."
  '((emacs  "26.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/frameshot"
  :commit "81eafb63ac17b5cf1074c447021d6037fbce602c"
  :revdesc "81eafb63ac17"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.frameshot@jonas.bernoulli.dev")))
