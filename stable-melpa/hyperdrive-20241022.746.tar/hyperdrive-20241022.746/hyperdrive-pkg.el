;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperdrive" "20241022.746"
  "P2P filesystem."
  '((emacs              "28.1")
    (map                "3.0")
    (compat             "30.0.0.0")
    (org                "9.7.6")
    (plz                "0.9.1")
    (persist            "0.6.1")
    (taxy-magit-section "0.14")
    (transient          "0.7.7"))
  :url "https://git.sr.ht/~ushin/hyperdrive.el"
  :commit "c7cc221c5840b354921081e3a3b8fa430855f63f"
  :revdesc "c7cc221c5840"
  :authors '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht")))
