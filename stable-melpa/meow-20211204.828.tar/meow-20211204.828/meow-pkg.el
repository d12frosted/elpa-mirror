(define-package "meow" "20211204.828" "Yet Another modal editing"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1")
    (s "1.12.0"))
  :commit "62a077ca99b94ea9b20994eec38a6f3df330ae91" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
