;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250220.245"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f44525349c8672bad11f176c63adf076ec78c90b"
  :revdesc "f44525349c86"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
