;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241105.305"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "0f173bace51c0f68d0dc3667a340355996b418f0"
  :revdesc "0f173bace51c"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
