;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260503.59"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "056487eb1a59baa7d95d71c3ed5d30aacbfe1d8f"
  :revdesc "056487eb1a59"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
