(define-package "wildcharm-light-theme" "20231103.700" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "ab0ed9cc5b4a285cddef52b193c26a979e1dcd08" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
