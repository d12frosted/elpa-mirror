;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20241109.855"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "0368bae5646193d421a04130ed5e046fe47946d3"
  :revdesc "0368bae56461"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
