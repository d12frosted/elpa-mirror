(define-package "repeatable-motion" "20170620.1848" "Make repeatable versions of motions"
  '((emacs "24"))
  :commit "f29effdc4121c2dc7e3fec9b3a62debce29cda9d" :authors
  (("William Hatch" . "willghatch@gmail.com"))
  :maintainer
  ("William Hatch" . "willghatch@gmail.com")
  :keywords
  ("motion" "repeatable")
  :url "https://github.com/willghatch/emacs-repeatable-motion")
;; Local Variables:
;; no-byte-compile: t
;; End:
