(define-package "dwim-shell-command" "20230730.1153" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "e91cd45b1bd0173e6d6a90079a86f13f2bfd79b7" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
