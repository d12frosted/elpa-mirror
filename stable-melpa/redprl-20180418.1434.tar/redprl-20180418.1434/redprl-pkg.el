;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "redprl" "20180418.1434"
  "Major mode for editing RedPRL proofs and interacting with RedPRL."
  '((emacs "24.3"))
  :url "https://github.com/RedPRL/sml-redprl"
  :commit "4abdbdeda4604ff30ce19c0df3f43e34faf60bd7"
  :revdesc "4abdbdeda460"
  :keywords '("languages")
  :authors '(("Jonathan Sterling" . "jon@jonmsterling.com"))
  :maintainers '(("Jonathan Sterling" . "jon@jonmsterling.com")))
