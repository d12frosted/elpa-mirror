;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ct" "20260908.1343"
  "Color Tools - a color api."
  '((emacs "26.1")
    (dash  "2.18.0")
    (hsluv "1.0.0"))
  :url "https://github.com/neeasade/ct.el"
  :commit "6c74ed036abf6c5d6caf2cae249d2f1832a25471"
  :revdesc "6c74ed036abf"
  :keywords '("convenience" "color" "theming" "background" "rgb" "hsv" "hsl" "hct" "lab" "oklab" "oklch"))
