;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-mock" "20220625.1949"
  "Tiny Mock and Stub framework in Emacs Lisp."
  ()
  :url "https://github.com/rejeep/el-mock.el"
  :commit "6cfbc9de8f1927295dca6864907fe4156bd71910"
  :revdesc "6cfbc9de8f19"
  :keywords '("lisp" "testing" "unittest")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("Johan Andersson" . "johan.rejeep@gmail.com")))
