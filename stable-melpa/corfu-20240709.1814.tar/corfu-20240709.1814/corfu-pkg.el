(define-package "corfu" "20240709.1814" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "30"))
  :commit "03558e1935156e2ca5181b5706ffb0177faa6148" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "text")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
