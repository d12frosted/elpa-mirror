(define-package "el-get" "20210613.815" "Manage the external elisp bits and pieces you depend upon" 'nil :commit "bffcd8e90bc5fbe025486f5e735bd7b57a4740dc" :authors
  '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainer
  '("Dimitri Fontaine" . "dim@tapoueh.org")
  :keywords
  '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :url "http://www.emacswiki.org/emacs/el-get")
;; Local Variables:
;; no-byte-compile: t
;; End:
