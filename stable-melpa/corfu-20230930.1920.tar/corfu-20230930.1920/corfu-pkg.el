(define-package "corfu" "20230930.1920" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "4da6c58b777b9aedfc5960f5ce492a03745f3042" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
