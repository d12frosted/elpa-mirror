(define-package "blog-minimal" "20181021.849" "A simple static site generator based on org mode"
  '((ht "1.5")
    (simple-httpd "1.4.6")
    (mustache "0.22")
    (s "1.11.0")
    (org "9.0.3"))
  :commit "a634a2db0b80cb445ef0b072d1a1482ced91f9ad" :authors
  '(("Thank Fly" . "thiefuniverses@gmail.com"))
  :maintainers
  '(("Thank Fly" . "thiefuniverses@gmail.com"))
  :maintainer
  '("Thank Fly" . "thiefuniverses@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/thiefuniverse/blog-minimal")
;; Local Variables:
;; no-byte-compile: t
;; End:
