(define-package "doom-themes" "20210709.1718" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "fb0b5c2e22f29b8113fdb4dd0217b17cf3bda888" :authors
  '(("Henrik Lissner <https://github.com/hlissner>"))
  :maintainer
  '("Henrik Lissner" . "henrik@lissner.net")
  :keywords
  '("custom themes" "faces")
  :url "https://github.com/hlissner/emacs-doom-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
