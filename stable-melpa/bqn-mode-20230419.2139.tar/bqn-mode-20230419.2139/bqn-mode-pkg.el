(define-package "bqn-mode" "20230419.2139" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "a2494b456c4cb280f6baca7808afef386d5553ca" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
