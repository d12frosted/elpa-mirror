;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shades-of-purple-theme" "20230421.2059"
  "A theme with bold shades of purple."
  ()
  :url "https://github.com/arturovm/shades-of-purple-emacs"
  :commit "8757594c5f6265b09d156cf9f8671f78863b25db"
  :revdesc "8757594c5f62"
  :authors '(("Arturo Vergara" . "hello@dead.computer"))
  :maintainers '(("Arturo Vergara" . "hello@dead.computer")))
