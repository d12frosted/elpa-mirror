(define-package "agtags" "20221004.1701" "A frontend to GNU Global"
  '((emacs "25"))
  :commit "1a989711602366447d424ed6596a1c491a6cbb96" :authors
  '(("Vietor Liu" . "vietor.liu@gmail.com"))
  :maintainer
  '("Vietor Liu" . "vietor.liu@gmail.com")
  :keywords
  '("tools" "convenience")
  :url "https://github.com/vietor/agtags")
;; Local Variables:
;; no-byte-compile: t
;; End:
