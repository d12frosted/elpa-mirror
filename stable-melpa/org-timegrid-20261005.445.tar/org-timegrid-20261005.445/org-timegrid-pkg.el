;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261005.445"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "ee2b167d3b241d9621272cba9db04995bd8ad340"
  :revdesc "ee2b167d3b24"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
