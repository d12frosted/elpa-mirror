(define-package "ctune" "20190914.1305" "Tune out CC Mode Noise Macros"
  '((emacs "26.1"))
  :commit "d7643461f5aa33cc04e4d808123e4ed1d85500ee" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("c" "convenience")
  :url "https://github.com/maurooaranda/ctune")
;; Local Variables:
;; no-byte-compile: t
;; End:
