;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "browse-url-dwim" "20140731.1922"
  "Context-sensitive external browse URL or Internet search."
  '((string-utils "0.3.2"))
  :url "https://github.com/rolandwalker/browse-url-dwim"
  :commit "11f1c53126619c7ef1bb5f5d6914ce0b3cce0e30"
  :revdesc "11f1c5312661"
  :keywords '("hypermedia")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
