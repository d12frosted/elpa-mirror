;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restclient-test" "20240207.1415"
  "Run tests with restclient.el."
  '((emacs      "26.1")
    (restclient "0"))
  :url "https://github.com/simenheg/restclient-test.el"
  :commit "5a364b93779eb3b4566dd6d843d7637983fcc949"
  :revdesc "5a364b93779e"
  :authors '(("Simen Heggestøyl" . "simenheg@runbox.com"))
  :maintainers '(("Simen Heggestøyl" . "simenheg@runbox.com")))
