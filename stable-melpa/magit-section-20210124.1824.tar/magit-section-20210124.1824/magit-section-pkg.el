(define-package "magit-section" "20210124.1824" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "59a87436bd8443e55d28f43bc396ec740aab20b3" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
