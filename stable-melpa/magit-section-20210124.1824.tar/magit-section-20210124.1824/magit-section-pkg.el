(define-package "magit-section" "20210124.1824" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "5182f3e88011b2ae6277dd0fbf8cdfa14afe7ddc" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
