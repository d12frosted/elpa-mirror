(define-package "magit-section" "20210124.1824" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "affec7fc12a3f1315c2312848421b0820de861e7" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
