(define-package "modus-themes" "20210327.2018" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "b39cc9898fe65c39c1b6d23df304bc17b106a8fb" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
