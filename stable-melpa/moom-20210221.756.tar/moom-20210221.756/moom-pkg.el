(define-package "moom" "20210221.756" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "63ea1b869622f71d06a8326c875a7df84e7a48ca" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
