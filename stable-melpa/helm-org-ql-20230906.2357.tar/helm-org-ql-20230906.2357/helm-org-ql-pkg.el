(define-package "helm-org-ql" "20230906.2357" "Helm support for org-ql"
  '((emacs "26.1")
    (dash "2.18.1")
    (s "1.12.0")
    (helm-org "1.0")
    (org-ql "0.6pre"))
  :commit "d776e205d53adccd1d66a9c666fd885a2334262e" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :url "https://github.com/alphapapa/org-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
