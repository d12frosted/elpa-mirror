(define-package "meow" "20211209.2203" "Yet Another modal editing"
  '((emacs "27.1")
    (dash "2.12.0")
    (s "1.12.0"))
  :commit "3fead7de4de01c13253ddcc6c79b16153f4d8a0e" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
