;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260215.449"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b1f4e77103dc17147379b5a742782acd0a74c247"
  :revdesc "b1f4e77103dc"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
