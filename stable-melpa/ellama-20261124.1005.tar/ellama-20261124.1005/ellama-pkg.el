;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20261124.1005"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.33.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "58958a0290de0437724e1de01a4e352fe4a33cdf"
  :revdesc "58958a0290de"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
