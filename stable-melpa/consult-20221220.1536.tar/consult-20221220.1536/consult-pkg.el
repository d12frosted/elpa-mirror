(define-package "consult" "20221220.1536" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "ac515e5157cc4a8ee2bdac5ae0c713b80fb34593" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
