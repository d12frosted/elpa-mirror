(define-package "apropospriate-theme" "20230409.2349" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "ce636368dd6aed6f268cc325cb55feb30b4a1345" :authors
  '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainer
  '("Justin Talbott" . "justin@waymondo.com")
  :url "http://github.com/waymondo/apropospriate-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
