;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mongo" "20150315.1219"
  "MongoDB driver for Emacs Lisp."
  ()
  :url "https://github.com/emacsorphanage/mongo"
  :commit "595529ddd70ecb9fab8b11daad2c3929941099d6"
  :revdesc "595529ddd70e"
  :keywords '("convenience")
  :authors '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com"))
  :maintainers '(("Tomohiro Matsuyama" . "m2ym.pub@gmail.com")))
