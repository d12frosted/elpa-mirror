(define-package "emacsc" "20220420.1042" "helper for emacsc(1)" 'nil :commit "199c08147ebe98da1004c478c92ba8866950b637" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("tools")
  :url "https://github.com/knu/emacsc")
;; Local Variables:
;; no-byte-compile: t
;; End:
