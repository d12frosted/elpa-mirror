;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260413.321"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "77a3c9af5f7805acbb46fcb662abfeea80f0c15a"
  :revdesc "77a3c9af5f78"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
