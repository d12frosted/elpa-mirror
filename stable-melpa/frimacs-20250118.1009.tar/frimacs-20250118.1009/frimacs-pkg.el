;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frimacs" "20250118.1009"
  "An environment for the FriCAS computer algebra system."
  '((emacs "26.1"))
  :url "https://github.com/pdo/frimacs"
  :commit "b7df4fd128a8432d40e8e9034e03e27ff26493d3"
  :revdesc "b7df4fd128a8"
  :keywords '("fricas" "computer algebra" "extensions" "tools")
  :authors '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainers '(("Paul Onions" . "paul.onions@acm.org")))
