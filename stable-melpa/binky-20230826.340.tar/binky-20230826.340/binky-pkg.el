(define-package "binky" "20230826.340" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "a7850d15a8c516f62e58d5e54c339a8c5e8cd0d4" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
