(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "bf98643761924d6fdc1bdae8df1ac84559e5e881" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
