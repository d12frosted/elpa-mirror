(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "635a71df74d755113f26a6c6d9ae48ccb485393d" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
