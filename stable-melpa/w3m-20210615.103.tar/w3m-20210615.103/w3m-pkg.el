(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "d9f075523f43262f4916c6750b874d078b42a8d7" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
