(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "99761034b3d8e12aa8c09fac7ee2aafe444630bf" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
