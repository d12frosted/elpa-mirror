(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "b2506cd5b6f0d3124927208bf4e8bd204671f355" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
