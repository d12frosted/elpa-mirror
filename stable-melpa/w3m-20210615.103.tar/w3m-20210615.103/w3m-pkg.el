(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "d11ea554a674f4faada3452b617f1c1066423a2f" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
