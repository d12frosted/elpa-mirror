(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "57276289ab1cb9ce83b18bdfc0564b9385d5d827" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
