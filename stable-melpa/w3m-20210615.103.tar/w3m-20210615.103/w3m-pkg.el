(define-package "w3m" "20210615.103" "an Emacs interface to w3m" 'nil :commit "f098fd7539b33506646bf38f767fe2a33ca1754f" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
