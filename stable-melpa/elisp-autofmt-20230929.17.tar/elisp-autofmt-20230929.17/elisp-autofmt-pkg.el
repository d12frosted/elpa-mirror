(define-package "elisp-autofmt" "20230929.17" "Emacs lisp auto-format"
  '((emacs "29.1"))
  :commit "9263ed12f653872c70dfef537848e4b3e4a1c4a6" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
