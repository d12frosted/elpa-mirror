(define-package "humanoid-themes" "20211130.1450" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "33c7f8dd55e30c255c2535647fee4126268f8dd8" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
