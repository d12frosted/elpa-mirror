(define-package "hass" "20221220.2340" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3")
    (websocket "1.13"))
  :commit "cbe701e2765588594c89c24192a86f96e079d827" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
