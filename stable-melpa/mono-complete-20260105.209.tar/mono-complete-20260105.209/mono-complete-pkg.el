;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mono-complete" "20260105.209"
  "Completion suggestions with multiple back-ends."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-mono-complete"
  :commit "12eb3f326f49212787be6e34a69e830652c8a9be"
  :revdesc "12eb3f326f49"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
