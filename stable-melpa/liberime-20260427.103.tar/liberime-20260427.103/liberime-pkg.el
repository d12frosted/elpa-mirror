;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260427.103"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "7def02cbd2e6fb4e3cbcd6fed540c7eebd56e2df"
  :revdesc "7def02cbd2e6"
  :keywords '("convenience" "chinese" "input-method" "rime"))
