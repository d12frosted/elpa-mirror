;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20261027.1725"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "2acd5697407863cf902b3f1af52725b08b152b2e"
  :revdesc "2acd56974078"
  :keywords '("files"))
