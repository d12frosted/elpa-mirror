;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260227.1801"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "d7bd01e3f0f3c214cacf109c306d5369a9ce74d0"
  :revdesc "d7bd01e3f0f3"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
