;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglotx" "20260911.1047"
  "Native LSP multiplexer for Eglot."
  '((emacs   "29.1")
    (eglot   "1.24")
    (jsonrpc "1.0.29"))
  :url "https://github.com/cxa/eglotx"
  :commit "35375c8d4aac8d4515cc8e43ab052a053b897eb5"
  :revdesc "35375c8d4aac"
  :keywords '("tools" "languages")
  :authors '(("CHEN Xian'an" . "xianan.chen@gmail.com"))
  :maintainers '(("CHEN Xian'an" . "xianan.chen@gmail.com")))
