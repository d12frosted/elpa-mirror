(define-package "dired-rsync" "20221214.1215" "Allow rsync from dired buffers"
  '((s "1.12.0")
    (dash "2.0.0")
    (emacs "24"))
  :commit "c0e2168b80df00116ab9071bb214cf05ed943d73" :authors
  '(("Alex Bennée" . "alex@bennee.com"))
  :maintainer
  '("Alex Bennée" . "alex@bennee.com")
  :url "https://github.com/stsquad/dired-rsync")
;; Local Variables:
;; no-byte-compile: t
;; End:
