;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ir-black-theme" "20130303.755"
  "Port of ir-black theme."
  ()
  :url "https://github.com/jmdeldin/ir-black-theme.el"
  :commit "ee6078bc67cbc15184e64e0f1fc8542d4079d55f"
  :revdesc "ee6078bc67cb"
  :keywords '("faces")
  :authors '(("Jon-Michael Deldin" . "dev@jmdeldin.com"))
  :maintainers '(("Jon-Michael Deldin" . "dev@jmdeldin.com")))
