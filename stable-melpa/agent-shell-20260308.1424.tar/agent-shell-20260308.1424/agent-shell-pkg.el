;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260308.1424"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.86.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "08b0b54848964e9954439923d594b066562e2f03"
  :revdesc "08b0b5484896")
