;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250605.1654"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.14.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "8eba4906c042d8bfa19f9069cf51d82397daa87d"
  :revdesc "8eba4906c042"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
