(define-package "docstr" "20210301.1350" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "a60b49ed37345c5f47604e857c97978a93e314bf" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
