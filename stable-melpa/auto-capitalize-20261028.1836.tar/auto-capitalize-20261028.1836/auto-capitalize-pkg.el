;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "20261028.1836"
  "Automatic capitalization with batteries included."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/abdulnafe-t/auto-capitalize.el"
  :commit "8cc735d165694841e73c75260b755cda4cc56c86"
  :revdesc "8cc735d16569"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
