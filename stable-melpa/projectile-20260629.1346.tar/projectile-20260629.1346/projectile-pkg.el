;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260629.1346"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "e8c266ddebd1200ead1aa3c5878d7ab0d2fdf8e7"
  :revdesc "e8c266ddebd1"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
