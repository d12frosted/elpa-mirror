;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgsql" "20260817.136"
  "Native PostgreSQL protocol client."
  '((emacs "29.1"))
  :url "https://github.com/LuciusChen/pgsql.el"
  :commit "165636b76fa63232a2d560ff04013aae0ff9e8a9"
  :revdesc "165636b76fa6"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
