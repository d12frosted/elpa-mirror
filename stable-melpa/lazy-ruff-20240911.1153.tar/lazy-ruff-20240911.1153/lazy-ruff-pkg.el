(define-package "lazy-ruff" "20240911.1153" "Integration with the Ruff Python linter/formatter"
  '((emacs "24.3")
    (org "9.1"))
  :commit "4739e87a9ceccf6bb45006b7adf01ed31e2caa1a" :keywords
  '("languages" "tools")
  :url "http://github.com/christophermadsen/emacs-lazy-ruff")
;; Local Variables:
;; no-byte-compile: t
;; End:
