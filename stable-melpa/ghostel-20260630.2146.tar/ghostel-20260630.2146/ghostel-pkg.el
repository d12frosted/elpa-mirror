;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260630.2146"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "4ceef34b6c4f659c612bd11fb885c05cfe42a881"
  :revdesc "4ceef34b6c4f"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
