;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250524.1443"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "b4163a774137c3fb4a967ff7867c633aba828e9d"
  :revdesc "b4163a774137"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
