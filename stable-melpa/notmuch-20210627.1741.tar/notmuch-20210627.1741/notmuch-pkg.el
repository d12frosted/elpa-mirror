(define-package "notmuch" "20210627.1741" "run notmuch within emacs" 'nil :commit "37f84d6d2181e26eb2f1413df774cc7922ddd018" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
