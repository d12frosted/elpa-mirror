(define-package "snakemake-mode" "20220222.515" "Major mode for editing Snakemake files"
  '((emacs "26.1")
    (transient "0.3.0"))
  :commit "f6abb59d4f3b97d9519b075157f4bb19efac494b" :authors
  '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainer
  '("Kyle Meyer" . "kyle@kyleam.com")
  :keywords
  '("tools")
  :url "https://git.kyleam.com/snakemake-mode/about")
;; Local Variables:
;; no-byte-compile: t
;; End:
