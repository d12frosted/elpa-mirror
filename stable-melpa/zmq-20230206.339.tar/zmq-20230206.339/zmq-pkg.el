(define-package "zmq" "20230206.339" "ZMQ bindings in elisp"
  '((cl-lib "0.5")
    (emacs "26"))
  :commit "4166424e3615147b1e9361a0588c1fb6b81cb5e5" :authors
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainer
  '("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")
  :keywords
  '("comm")
  :url "https://github.com/nnicandro/emacs-zmq")
;; Local Variables:
;; no-byte-compile: t
;; End:
