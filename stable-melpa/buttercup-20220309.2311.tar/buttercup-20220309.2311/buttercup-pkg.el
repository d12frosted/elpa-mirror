(define-package "buttercup" "20220309.2311" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "09459403f54783ddff9337010d9536da25ca7818" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
