(define-package "stimmung-themes" "20220411.703" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "19023d8b81c43cbaea62a87017b8762b8b190bbb" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
