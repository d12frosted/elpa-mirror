;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20260409.735"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "d1688d8d4c0a9cc5ffa7f880138f9fb09d205e64"
  :revdesc "d1688d8d4c0a"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
