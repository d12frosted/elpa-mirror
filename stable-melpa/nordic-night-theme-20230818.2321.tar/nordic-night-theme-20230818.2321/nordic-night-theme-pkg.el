(define-package "nordic-night-theme" "20230818.2321" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "012dc83458dd3d453106806b2590058d5d0f1fdd" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
