(define-package "embark" "20220107.1501" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "1fc0d6385da5f3be9d19a4081b81ec0bedd0b71f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
