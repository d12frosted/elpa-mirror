(define-package "darkman" "20230312.2217" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "31cf4b6f5000a394d14a73b0286b9a83f8c943a9" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://grtcdr.tn/darkman.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
