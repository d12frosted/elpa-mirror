;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250716.1415"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "890b2a152c2368e69e75a3f21e8896800d7ae53b"
  :revdesc "890b2a152c23"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
