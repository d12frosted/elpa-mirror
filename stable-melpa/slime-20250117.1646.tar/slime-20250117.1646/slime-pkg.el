;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20250117.1646"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "7f6194c8257f399e6b67b5d0147e4a857882cca2"
  :revdesc "7f6194c8257f"
  :keywords '("languages" "lisp" "slime"))
