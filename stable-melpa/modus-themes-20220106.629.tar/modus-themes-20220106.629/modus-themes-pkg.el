(define-package "modus-themes" "20220106.629" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "38236a925ef34f8e8c51babee587b594e77dffbe" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
