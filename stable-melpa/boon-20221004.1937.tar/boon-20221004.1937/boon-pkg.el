(define-package "boon" "20221004.1937" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "520f68699e2a5a8e022c058992d3d39737c32753")
;; Local Variables:
;; no-byte-compile: t
;; End:
