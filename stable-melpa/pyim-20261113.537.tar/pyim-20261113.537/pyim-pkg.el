;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim" "20261113.537"
  "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "27.1")
    (async "1.6")
    (xr    "1.13"))
  :url "https://github.com/tumashu/pyim"
  :commit "c680aa65dc2104aa15fe9a8f7e9ff97fe682b2f1"
  :revdesc "c680aa65dc21"
  :keywords '("convenience" "chinese" "pinyin" "input-method")
  :authors '(("Ye Wenbin" . "wenbinye@163.com")
             ("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
