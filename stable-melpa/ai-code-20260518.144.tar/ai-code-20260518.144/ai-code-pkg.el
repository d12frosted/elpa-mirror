;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260518.144"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3f1b1becde52f3508b9ab45fae72c9efb5dd2b3a"
  :revdesc "3f1b1becde52"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
