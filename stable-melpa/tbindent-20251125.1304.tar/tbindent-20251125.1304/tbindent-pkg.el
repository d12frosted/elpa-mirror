;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tbindent" "20251125.1304"
  "Edit space-indented file in tab-indented buffer."
  '((emacs "24.3"))
  :url "https://github.com/pierre-rouleau/tab-based-indent"
  :commit "5e83d2ff760c79363f5bc3045fdfe59038f9eb32"
  :revdesc "5e83d2ff760c"
  :keywords '("convenience" "languages")
  :authors '(("Pierre Rouleau" . "prouleau001@gmail.com"))
  :maintainers '(("Pierre Rouleau" . "prouleau001@gmail.com")))
