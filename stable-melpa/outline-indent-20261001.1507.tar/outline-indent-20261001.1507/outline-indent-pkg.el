;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20261001.1507"
  "Folding text based on indentation (origami alternative)."
  '((emacs    "26.1")
    (kirigami "1.0.5"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "7e8a277cd70aa4b66ab768b6eeb30084bea2d1fd"
  :revdesc "7e8a277cd70a"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
