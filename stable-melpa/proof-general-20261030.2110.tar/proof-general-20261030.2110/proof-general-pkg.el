;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261030.2110"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "e0a6d4f042c083018896bc831234589abb33b915"
  :revdesc "e0a6d4f042c0"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
