(define-package "org-jira" "20210804.2307" "Syncing between Jira and Org-mode."
  '((emacs "24.5")
    (cl-lib "0.5")
    (request "0.2.0")
    (dash "2.14.1"))
  :commit "7b3fbf2c7e9cc2abac77c494feb405e2879067f3" :maintainer
  '("Matthew Carter" . "m@ahungry.com")
  :keywords
  '("ahungry" "jira" "org" "bug" "tracker")
  :url "https://github.com/ahungry/org-jira")
;; Local Variables:
;; no-byte-compile: t
;; End:
