;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260702.2042"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "a45f98cc30734008cac03f1e9b50ece4aa9e9c3d"
  :revdesc "a45f98cc3073"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
