;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corg" "20260406.1951"
  "Header completion for org-mode."
  '((emacs  "27.1")
    (s      "1.13.1")
    (compat "30"))
  :url "https://github.com/isamert/corg.el"
  :commit "0eeb4255b0c47a1e3c46513ae3fa2ffe749400b8"
  :revdesc "0eeb4255b0c4"
  :keywords '("abbrev" "convenience" "completion" "matching")
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
