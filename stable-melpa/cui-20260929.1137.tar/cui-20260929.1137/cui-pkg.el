;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260929.1137"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "cdafcf62ec4df36b1cae24a2245c18d24b8d738e"
  :revdesc "cdafcf62ec4d"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
