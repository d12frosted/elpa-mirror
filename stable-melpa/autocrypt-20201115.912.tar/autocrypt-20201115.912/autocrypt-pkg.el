(define-package "autocrypt" "20201115.912" "Autocrypt implementation"
  '((emacs "25.1"))
  :commit "050d4967162dff6de5ef480db8a22c5896d483c7" :keywords
  ("comm")
  :authors
  (("Philip K." . "philip@warpmail.net"))
  :maintainer
  ("Philip K." . "philip@warpmail.net")
  :url "https://git.sr.ht/~zge/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
