(define-package "fiplr" "20130704.426" "Fuzzy Search for Files in Projects"
  '((grizzl "0.1.0"))
  :commit "100dfc33f43da8c49e50e8a2222b9d95532f6e24" :authors
  '(("Chris Corbyn" . "chris@w3style.co.uk"))
  :maintainer
  '("Chris Corbyn" . "chris@w3style.co.uk")
  :keywords
  '("convenience" "usability" "project")
  :url "https://github.com/d11wtq/fiplr")
;; Local Variables:
;; no-byte-compile: t
;; End:
