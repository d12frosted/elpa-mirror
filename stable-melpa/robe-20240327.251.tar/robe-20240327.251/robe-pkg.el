(define-package "robe" "20240327.251" "Code navigation, documentation lookup and completion for Ruby"
  '((inf-ruby "2.5.1")
    (emacs "25.1"))
  :commit "ef3134a4d80a8c70f387699082f42a8d320908ce" :authors
  '(("Dmitry Gutov"))
  :maintainers
  '(("Dmitry Gutov"))
  :maintainer
  '("Dmitry Gutov")
  :keywords
  '("ruby" "convenience" "rails")
  :url "https://github.com/dgutov/robe")
;; Local Variables:
;; no-byte-compile: t
;; End:
