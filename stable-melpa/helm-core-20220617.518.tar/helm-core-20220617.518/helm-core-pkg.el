(define-package "helm-core" "20220617.518" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "0f905a6c626de2fd103dac699afcd252e43b1161" :authors
  '(("Thierry Volpiatto "))
  :maintainer
  '("Thierry Volpiatto ")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
