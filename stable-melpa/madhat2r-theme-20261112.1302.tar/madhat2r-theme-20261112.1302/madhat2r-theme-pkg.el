;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "madhat2r-theme" "20261112.1302"
  "Dark color theme that is easy on the eyes."
  '((emacs "24"))
  :url "https://github.com/madhat2r/madhat2r-theme"
  :commit "a1db9bdca1f388e09d5e32fdc0b4f243d08c45d4"
  :revdesc "a1db9bdca1f3"
  :keywords '("color" "theme"))
