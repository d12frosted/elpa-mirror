;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260222.258"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "076224656203ec26a83d7fbb8ec79b5d29fe11f6"
  :revdesc "076224656203"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
