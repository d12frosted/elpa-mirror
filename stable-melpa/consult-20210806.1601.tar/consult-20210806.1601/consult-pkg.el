(define-package "consult" "20210806.1601" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "363eef61495d0ce018d99236470fafc846a482f0" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
