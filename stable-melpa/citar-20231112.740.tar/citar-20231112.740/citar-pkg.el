(define-package "citar" "20231112.740" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "4.2")
    (org "9.5")
    (citeproc "0.9"))
  :commit "1cf91846a34b94cc7e069352fb8451e270d16b5b" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainers
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/emacs-citar/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
