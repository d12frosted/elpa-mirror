;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261111.1813"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "fae12d3ec5cb7f5718478d42ae2eaf330e07c49a"
  :revdesc "fae12d3ec5cb"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
