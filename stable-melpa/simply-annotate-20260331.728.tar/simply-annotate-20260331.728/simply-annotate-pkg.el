;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260331.728"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "d017013a47d5dc137fda1c6e74bb2dcd72efa915"
  :revdesc "d017013a47d5"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
