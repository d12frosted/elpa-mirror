;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20260304.1415"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (markdown-mode  "2.0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "9115af2d96c7b81c7aef3dbaa18c058c66945a14"
  :revdesc "9115af2d96c7"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
