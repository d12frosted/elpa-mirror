(define-package "transient" "20220806.1321" "Transient commands"
  '((emacs "25.1")
    (compat "28.1.1.0"))
  :commit "a5562cbc8d01fa6684487b71cf520cf348d10047" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
