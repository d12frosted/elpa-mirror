(define-package "mastodon" "20220803.1937" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.2")
    (seq "1.0"))
  :commit "a74340a72789ed12011d3f8618449bbe515a7e77" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
