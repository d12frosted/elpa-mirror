(define-package "notmuch" "20220613.1106" "run notmuch within emacs" 'nil :commit "fb4a0967cab7df737d5d53199a48a0e79c429b61" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
