;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jemdoc-mode" "20170704.2027"
  "Major mode for editing jemdoc files."
  '((emacs "24.3"))
  :url "https://github.com/drdv/jemdoc-mode"
  :commit "529b4d4681e1198b9892f340fdd6c3f1592a047a"
  :revdesc "529b4d4681e1"
  :keywords '("convenience" "usability")
  :authors '(("Dimitar Dimitrov" . "mail.mitko@gmail.com"))
  :maintainers '(("Dimitar Dimitrov" . "mail.mitko@gmail.com")))
