(define-package "eshell-prompt-extras" "20230815.1251" "Display extra information for your eshell prompt."
  '((emacs "25"))
  :commit "f490ab511a36166f09b97811495b09d72c9d37f9" :authors
  '(("zwild" . "judezhao@outlook.com"))
  :maintainers
  '(("Xu Chunyang" . "xuchunyang56@gmail.com"))
  :maintainer
  '("Xu Chunyang" . "xuchunyang56@gmail.com")
  :keywords
  '("eshell" "prompt")
  :url "https://github.com/zwild/eshell-prompt-extras")
;; Local Variables:
;; no-byte-compile: t
;; End:
