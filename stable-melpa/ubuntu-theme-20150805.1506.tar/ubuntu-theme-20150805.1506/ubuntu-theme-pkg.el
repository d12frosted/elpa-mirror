;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ubuntu-theme" "20150805.1506"
  "A theme inspired by the default terminal colors in Ubuntu."
  ()
  :url "https://github.com/rocher/ubuntu-theme"
  :commit "88b0eefc75d4cbcde103057e1c5968d4c3052f69"
  :revdesc "88b0eefc75d4"
  :authors '(("Francesc Rocher" . "francesc.rocher@gmail.com"))
  :maintainers '(("Francesc Rocher" . "francesc.rocher@gmail.com")))
