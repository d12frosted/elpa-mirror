(define-package "hl-prog-extra" "20221228.438" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "693af03f48f2382ff90d7357af366a71f7440343" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
