;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "google-translate" "20260415.1227"
  "Emacs interface to Google Translate."
  '((emacs "24.3")
    (popup "0.5.8"))
  :url "https://github.com/atykhonov/google-translate"
  :commit "6187fd22611b2e2f49ac4a72781115c9f5e78748"
  :revdesc "6187fd22611b"
  :keywords '("convenience")
  :authors '(("Oleksandr Manzyuk" . "manzyuk@gmail.com"))
  :maintainers '(("Andrey Tykhonov" . "atykhonov@gmail.com")))
