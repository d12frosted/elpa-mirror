(define-package "org-sliced-images" "20240324.32" "Sliced inline images in org-mode"
  '((emacs "29.1")
    (org "9.6.15"))
  :commit "db64e31ad4decc30599638e63dbe69bf18e78dcb" :authors
  '(("Jacob Fong" . "jacobcfong@gmail.com"))
  :maintainers
  '(("Jacob Fong" . "jacobcfong@gmail.com"))
  :maintainer
  '("Jacob Fong" . "jacobcfong@gmail.com")
  :url "https://github.com/jcfk/org-sliced-images")
;; Local Variables:
;; no-byte-compile: t
;; End:
