;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cycle-at-point" "20260111.1240"
  "Cycle (rotate) the word at point."
  '((emacs      "29.1")
    (recomplete "0.2"))
  :url "https://codeberg.org/ideasman42/emacs-cycle-at-point"
  :commit "0af1fa35f49d320960870b9dbcb4d03440139fdf"
  :revdesc "0af1fa35f49d"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
