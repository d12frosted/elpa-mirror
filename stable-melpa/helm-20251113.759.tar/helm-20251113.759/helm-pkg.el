;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251113.759"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "86e6f83790d90c41474108a9c8f57712a4a54d47"
  :revdesc "86e6f83790d9"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
