;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "20260110.206"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "3c5b6b00973d90107f80e3ee9c80c2a742359afc"
  :revdesc "3c5b6b00973d"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
