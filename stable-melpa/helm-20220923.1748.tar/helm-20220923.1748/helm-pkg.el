(define-package "helm" "20220923.1748" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.7")
    (popup "0.5.3"))
  :commit "cca7fecf207ede339844908baf15a6a508ce096f" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
