;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20260927.1623"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.11.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "bdbbc648cbcbf9fefb2bc238a1aebbc9fb8c8ffa"
  :revdesc "bdbbc648cbcb"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
