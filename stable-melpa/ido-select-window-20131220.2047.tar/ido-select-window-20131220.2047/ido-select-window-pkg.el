;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-select-window" "20131220.2047"
  "Select a window using ido and buffer names."
  '((emacs "24.1"))
  :url "https://github.com/pjones/ido-select-window"
  :commit "946db3db7a3fec582cc1a0097877f1250303b53a"
  :revdesc "946db3db7a3f"
  :authors '(("Peter Jones" . "pjones@devalot.com"))
  :maintainers '(("Peter Jones" . "pjones@devalot.com")))
