(define-package "popper" "20211011.113" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "8592573f3380acb2beb3c611787c939008c81b2b" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
