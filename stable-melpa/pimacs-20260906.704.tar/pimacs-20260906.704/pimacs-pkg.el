;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260906.704"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "b5e1650d27ead47084605ca6ce5c8e1214c4a5d3"
  :revdesc "b5e1650d27ea"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
