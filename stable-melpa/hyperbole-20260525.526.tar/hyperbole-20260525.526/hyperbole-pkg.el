;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260525.526"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "242dbb232b6cd812a1f66cabb12059f429e735a9"
  :revdesc "242dbb232b6c"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
