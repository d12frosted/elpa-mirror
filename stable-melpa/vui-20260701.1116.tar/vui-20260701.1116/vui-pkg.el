;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260701.1116"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "e965148970cd8bc711d05c0dbbf9ea3695f21629"
  :revdesc "e965148970cd"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
