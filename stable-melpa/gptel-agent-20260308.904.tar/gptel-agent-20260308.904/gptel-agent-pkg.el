;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260308.904"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "0e574a655aad18164f3e87ade35bca5777c90b03"
  :revdesc "0e574a655aad"
  :keywords '("comm"))
