;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250426.1504"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "540c4a3d746ac9bc7f1fd6ed9dcb002ca8692312"
  :revdesc "540c4a3d746a"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
