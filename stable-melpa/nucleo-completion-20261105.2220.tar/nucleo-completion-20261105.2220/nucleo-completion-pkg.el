;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20261105.2220"
  "Nucleo-backed completion style."
  '((emacs "29.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "6553110f6ad5cc1754508b5c18e531bedafc3a02"
  :revdesc "6553110f6ad5"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
