;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-latex" "20261021.1002"
  "Preview LaTeX math as SVG in LaTeX buffers."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.25.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "7383bea4ae0c4cb6c8a45f7f9c87ff2d54dbfe87"
  :revdesc "7383bea4ae0c"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
