(define-package "pyim-wbdict" "20200910.1445" "Some wubi dicts for pyim"
  '((pyim "1.0"))
  :commit "8b1f0dfa1c5f5f8e5fb110a0963603ee08d60932" :keywords
  ("convenience" "chinese" "pinyin" "input-method" "complete")
  :authors
  (("Feng Shu" . "tumashu@163.com"))
  :maintainer
  ("Feng Shu" . "tumashu@163.com")
  :url "https://github.com/tumashu/pyim-wbdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
