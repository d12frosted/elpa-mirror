(define-package "dirvish" "20220507.425" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "fa5f3475eff20a67ce4c4446b3c2d74cd6f1f92c" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
