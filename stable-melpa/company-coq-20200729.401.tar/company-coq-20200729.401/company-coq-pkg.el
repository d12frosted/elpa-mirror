(define-package "company-coq" "20200729.401" "A collection of extensions for Proof General's Coq mode"
  '((cl-lib "0.5")
    (dash "2.12.1")
    (yasnippet "0.11.0")
    (company "0.8.12")
    (company-math "1.1"))
  :commit "4da7b41e25943c0e30171ed25c761c5311999f0d" :url "https://github.com/cpitclaudel/company-coq" :keywords
  ("convenience" "languages")
  :maintainer
  ("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :authors
  (("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
;; Local Variables:
;; no-byte-compile: t
;; End:
