;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260316.742"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "f11d4436f7e39dfaf82020a390917102e3fd8d27"
  :revdesc "f11d4436f7e3"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
