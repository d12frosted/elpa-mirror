;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250715.1008"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.17.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "d6b37b478bc1154b4b09f1468a63b796c1ec5313"
  :revdesc "d6b37b478bc1"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
