;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260201.1101"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4b2dadba4369985c7c04f242a9df0db1d5c8d0c6"
  :revdesc "4b2dadba4369")
