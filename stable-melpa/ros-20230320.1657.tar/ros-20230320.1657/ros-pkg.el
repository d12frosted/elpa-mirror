(define-package "ros" "20230320.1657" "Package to write code for ROS systems"
  '((emacs "27.1"))
  :commit "5702a76a055cc0801bc16d50f32973311b894676" :authors
  '(("Max Beutelspacher <https://github.com/mtb>"))
  :maintainers
  '(("Max Beutelspacher" . "max@beutelspacher.eu"))
  :maintainer
  '("Max Beutelspacher" . "max@beutelspacher.eu")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/DerBeutlin/ros.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
