;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260124.1233"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "2d6e1302b457468b9becdde9549ce4b5d10116ab"
  :revdesc "2d6e1302b457")
