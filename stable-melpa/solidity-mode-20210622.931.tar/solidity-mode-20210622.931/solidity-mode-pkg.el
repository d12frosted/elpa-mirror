(define-package "solidity-mode" "20210622.931" "Major mode for ethereum's solidity language" 'nil :commit "5f6ef3156fadae5af6f381d674d20535529a20e4" :authors
  '(("Lefteris Karapetsas " . "lefteris@refu.co"))
  :maintainer
  '("Lefteris Karapetsas " . "lefteris@refu.co")
  :keywords
  '("languages" "solidity"))
;; Local Variables:
;; no-byte-compile: t
;; End:
