;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261017.2232"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "8258ebc360e364e3ab7ca37eb976341486f8abae"
  :revdesc "8258ebc360e3"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
