;;; helm-sql-connect.el --- Choose a database to connect to via Helm.
;; Copyright 2017 Eric Hansen
;;
;; Author: Eric Hansen <hansen.c.eric@gmail.com>
;; Maintainer: Eric Hansen <hansen.c.eric@gmail.com>
;; Keywords: tools convenience comm
;; URL: https://github.com/eric-hansen/helm-sql-connect
;; Created: 1st March 2017
;; Package-Version: 20170319.1251
;; Package-Revision: 5aead55b6f86
;; Package-Requires: ((helm "0.0.0"))

;;; Commentary:
;;
;; Provides the command `helm-sql-connect', which uses helm to prompt
;; for and connect to a database connection in `sql-connection-alist'.

;;; Code:

(require 'sql)
(require 'helm)

(defun helm-sql-connect-to ()
  "Populate helm buffer with connection string names from a populated `sql-connection-alist'."
  (with-helm-current-buffer
    (mapcar 'car sql-connection-alist)))

(defvar helm-sql-connect-pool
  '((name . "SQL Connections")
    (candidates . helm-sql-connect-to)
    (action . #'sql-connect)))

;;;###autoload
(defun helm-sql-connect ()
  "Helm directive to call when wanting to list SQL connections to connect to."
  (interactive)
  (helm :sources '(helm-sql-connection-pool)
        :buffer "*helm-sql-connect*"))

(provide 'helm-sql-connect)

;;; helm-sql-connect.el ends here
