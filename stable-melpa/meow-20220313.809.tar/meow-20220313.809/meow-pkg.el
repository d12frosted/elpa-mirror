(define-package "meow" "20220313.809" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "57656a69d3c29ddb0d18697491f80674e1097eaf" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
