;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "splunk-mode" "20241002.1040"
  "Major Mode for editing Splunk SPL source code."
  '((emacs "27.1"))
  :url "https://github.com/jakewilliami/splunk-mode/"
  :commit "bc0ad3ed26e2f6d46c430a3f1ab86c93c4483403"
  :revdesc "bc0ad3ed26e2"
  :keywords '("languages" "splunk" "mode" "query")
  :authors '(("Jake Ireland" . "jakewilliami@icloud.com"))
  :maintainers '(("Jake Ireland" . "jakewilliami@icloud.com")))
