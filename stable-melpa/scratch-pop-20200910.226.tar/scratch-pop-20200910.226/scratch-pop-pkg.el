;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratch-pop" "20200910.226"
  "Generate, popup (& optionally backup) scratch buffer(s)."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "545badcd840dd50b39dd7dfa37459c6f71d02ea6"
  :revdesc "545badcd840d")
