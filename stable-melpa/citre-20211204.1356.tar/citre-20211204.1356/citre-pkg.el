(define-package "citre" "20211204.1356" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "b9e274b180fcda981eec35dae0355d9d1305ad42" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
