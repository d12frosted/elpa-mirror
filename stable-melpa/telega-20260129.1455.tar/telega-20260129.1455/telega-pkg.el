;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260129.1455"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "d101957cb36ad287bf06ebe3aa9d8f43068447ca"
  :revdesc "d101957cb36a"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
