(define-package "geiser" "20210404.430" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "45c49052eecebaa0f180538c855f610a94b0e01d" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
