(define-package "fennel-mode" "20230123.432" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "0aa919db3ea959977747685c65413e0c6636a9ad" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
