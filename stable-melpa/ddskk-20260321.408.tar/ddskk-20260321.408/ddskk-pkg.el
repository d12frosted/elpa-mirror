;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk" "20260321.408"
  "Daredevil SKK (Simple Kana to Kanji conversion program)."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :url "https://github.com/skk-dev/ddskk"
  :commit "af3e22463dac6253648b13ad6fa68ba92d706d4e"
  :revdesc "af3e22463dac"
  :keywords '("japanese" "mule" "input method")
  :authors '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp")))
