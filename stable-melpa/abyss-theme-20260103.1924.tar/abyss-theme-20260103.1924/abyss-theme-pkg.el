;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abyss-theme" "20260103.1924"
  "A dark theme with contrasting colours."
  '((emacs "24"))
  :url "https://github.com/mgrbyte/emacs-abyss-theme"
  :commit "e8326ed9955d0897cc68fb38d488985a045c868c"
  :revdesc "e8326ed9955d"
  :keywords '("theme" "dark" "contrasting colours")
  :authors '(("Matt Russell" . "m.russell@bangor.ac.uk"))
  :maintainers '(("Matt Russell" . "m.russell@bangor.ac.uk")))
