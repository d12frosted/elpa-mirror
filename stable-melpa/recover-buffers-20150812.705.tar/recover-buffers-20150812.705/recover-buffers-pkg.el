(define-package "recover-buffers" "20150812.705" "revisit all buffers from an auto-save file" 'nil :commit "a1db7f084977697081da3497628e3514e032b966" :authors
  '(("era eriksson <http://www.iki.fi/era>"))
  :maintainer
  '("era eriksson <http://www.iki.fi/era>"))
;; Local Variables:
;; no-byte-compile: t
;; End:
