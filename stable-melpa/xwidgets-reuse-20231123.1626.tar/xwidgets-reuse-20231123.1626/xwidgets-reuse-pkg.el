(define-package "xwidgets-reuse" "20231123.1626" "Reuse xwidgets sessions to reduce resource consumption"
  '((emacs "26.1"))
  :commit "9add364dbdd60bb40fefcecafb95ca8090d7d524" :authors
  '(("Boris Glavic" . "lordpretzel@gmail.com"))
  :maintainers
  '(("Boris Glavic" . "lordpretzel@gmail.com"))
  :maintainer
  '("Boris Glavic" . "lordpretzel@gmail.com")
  :keywords
  '("hypermedia")
  :url "https://github.com/lordpretzel/xwidgets-reuse")
;; Local Variables:
;; no-byte-compile: t
;; End:
