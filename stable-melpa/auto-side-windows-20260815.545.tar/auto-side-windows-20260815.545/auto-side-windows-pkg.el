;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-side-windows" "20260815.545"
  "Simplified buffer management for side windows."
  '((emacs "30.1"))
  :url "https://github.com/MArpogaus/auto-side-windows"
  :commit "af2bfcefeffc2fc46e3660cbd8c1b6bc6790d246"
  :revdesc "af2bfcefeffc"
  :keywords '("convenience" "windows" "buffers")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
