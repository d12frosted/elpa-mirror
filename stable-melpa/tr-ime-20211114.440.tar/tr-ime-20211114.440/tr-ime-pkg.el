(define-package "tr-ime" "20211114.440" "Emulator of IME patch for Windows"
  '((emacs "27.1")
    (w32-ime "0.0.1"))
  :commit "c35be849f2cf5470e9d9cc40ff54e285e5170e93" :authors
  '(("Masamichi Hosoda" . "trueroad@trueroad.jp"))
  :maintainer
  '("Masamichi Hosoda" . "trueroad@trueroad.jp")
  :url "https://github.com/trueroad/tr-emacs-ime-module")
;; Local Variables:
;; no-byte-compile: t
;; End:
