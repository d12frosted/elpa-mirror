(define-package "elisp-autofmt" "20230101.1229" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "0460b1381724ee1dae5f53cbb505c00b14b5ed9d" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
