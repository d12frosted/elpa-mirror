(define-package "python-mode" "20220531.2002" "Python major mode" 'nil :commit "d3f236aeb3c29bf4a3b1cd16f4c17bfe07c8bb9a" :authors
  '(("2015-2021 https://gitlab.com/groups/python-mode-devs")
    ("2003-2014 https://launchpad.net/python-mode")
    ("1995-2002 Barry A. Warsaw")
    ("1992-1994 Tim Peters"))
  :maintainer
  '(nil . "python-mode@python.org")
  :keywords
  '("languages" "processes" "python" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
