(define-package "dirvish" "20220511.1714" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "20fae2733e5d9dd30a371b39f4fa2dc39ad19f83" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
