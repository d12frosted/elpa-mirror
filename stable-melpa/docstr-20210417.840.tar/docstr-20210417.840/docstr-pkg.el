(define-package "docstr" "20210417.840" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "386b5d3e81027a8f8d712bb26fd63df08ce3eafd" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
