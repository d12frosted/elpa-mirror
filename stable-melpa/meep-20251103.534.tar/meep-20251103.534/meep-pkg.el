;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251103.534"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "d62fa2d44b0641c31bf26691a7d10c82388009e6"
  :revdesc "d62fa2d44b06"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
