;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocp-indent" "20260805.738"
  "Automatic indentation with ocp-indent."
  ()
  :url "http://www.typerex.org/ocp-indent.html"
  :commit "d5f0d27b3caf7ae2397f8b26ecc5776997643945"
  :revdesc "d5f0d27b3caf"
  :keywords '("ocaml" "languages"))
