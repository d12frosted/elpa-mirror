;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-autofmt" "20260328.53"
  "Emacs lisp auto-format."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt"
  :commit "3557cf2d2d21eb4a659d299d76c6a44fbe290824"
  :revdesc "3557cf2d2d21"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
