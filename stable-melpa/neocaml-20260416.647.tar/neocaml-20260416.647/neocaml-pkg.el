;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260416.647"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "06794d8d9ae1180a37b71b02ed8eadd464129b73"
  :revdesc "06794d8d9ae1"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
