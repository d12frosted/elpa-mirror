(define-package "diredc" "20240414.746" "Midnight Commander features (plus) for dired"
  '((emacs "26.1")
    (key-assist "1.0"))
  :commit "0ff2424aa226228c72e47a635f3b5379c424c891" :keywords
  '("files")
  :url "https://github.com/Boruch-Baum/emacs-diredc")
;; Local Variables:
;; no-byte-compile: t
;; End:
