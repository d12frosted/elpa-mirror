;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250624.327"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "b2942d9cde63d295ca21907d0c8a16e6b9c53964"
  :revdesc "b2942d9cde63"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
