(define-package "jinx" "20230429.752" "Enchanted Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "fd0ec59222c6e26234c5f347477bef69e563e46d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "wp")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
