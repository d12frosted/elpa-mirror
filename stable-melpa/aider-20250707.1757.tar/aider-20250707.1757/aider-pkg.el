;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250707.1757"
  "AI assisted programming with Aider and LLM."
  '((emacs         "26.1")
    (transient     "0.9.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "dfe64d0361024631e1d2c3565ce1b4638994b854"
  :revdesc "dfe64d036102"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
