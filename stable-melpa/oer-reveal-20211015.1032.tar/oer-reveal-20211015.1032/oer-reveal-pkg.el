(define-package "oer-reveal" "20211015.1032" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "12a795417f9ec0d06245a71de595b7aaba86c3df" :authors
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
