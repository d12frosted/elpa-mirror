;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260201.1053"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "5392b43459374c612d54db94bf278b98d0e73a49"
  :revdesc "5392b4345937"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
