;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260704.1146"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8d97dd46046d7aa639742efde75dcbb719ed3b38"
  :revdesc "8d97dd46046d")
