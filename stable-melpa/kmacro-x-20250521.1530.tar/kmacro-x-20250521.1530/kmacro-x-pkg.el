;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kmacro-x" "20250521.1530"
  "Keyboard macro helpers and extensions."
  '((emacs "29.1"))
  :url "https://github.com/vifon/kmacro-x.el"
  :commit "da859b6b8b31c4fdfd3028996a02e5a70d9fff6b"
  :revdesc "da859b6b8b31"
  :keywords '("convenience"))
