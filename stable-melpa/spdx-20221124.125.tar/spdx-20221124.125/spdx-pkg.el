(define-package "spdx" "20221124.125" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "0ea967f546b807db0b38bf50c5175efe4c519017" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
