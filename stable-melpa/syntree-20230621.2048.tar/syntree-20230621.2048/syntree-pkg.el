;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syntree" "20230621.2048"
  "Draw plain text constituency trees."
  '((emacs "27.1")
    (org   "9.2"))
  :url "https://github.com/enricoflor/syntree"
  :commit "7bbbd4904b0ffe452ec39630042dbc85a7a0b233"
  :revdesc "7bbbd4904b0f"
  :authors '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers '(("Enrico Flor" . "enrico@eflor.net")))
