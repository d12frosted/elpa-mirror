;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20260702.1623"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "852f6db3875e75dd83f446dba8f4f8eb76dc2d43"
  :revdesc "852f6db3875e"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
