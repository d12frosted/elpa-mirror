;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260519.111"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "13fb314a795951b9190c53c59ef281abf7a2cb4f"
  :revdesc "13fb314a7959"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
