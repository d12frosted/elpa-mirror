;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "handlebars-sgml-mode" "20130623.2333"
  "Add Handlebars contextual indenting support to sgml-mode."
  ()
  :url "https://github.com/jacott/handlebars-sgml-mode"
  :commit "005282c33dfb6dbd2cfd46a4147d261504e8323c"
  :revdesc "005282c33dfb"
  :authors '(("Geoff Jacobsen" . "geoffjacobsen@gmail.com"))
  :maintainers '(("Geoff Jacobsen" . "geoffjacobsen@gmail.com")))
