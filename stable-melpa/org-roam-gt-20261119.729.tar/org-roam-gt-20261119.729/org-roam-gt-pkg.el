;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-gt" "20261119.729"
  "Improvements for org-roam."
  '((emacs    "30.1")
    (org      "9.8")
    (org-roam "2.2.2"))
  :url "https://github.com/dmgerman/org-roam-gt"
  :commit "01e8adc4938b4fc5fabd85dad97f08e71ab9168e"
  :revdesc "01e8adc4938b"
  :keywords '("outlines" "hypermedia")
  :authors '(("Daniel M. German" . "dmg@turingmachine.org"))
  :maintainers '(("Daniel M. German" . "dmg@turingmachine.org")))
