;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260514.403"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "1d1841fd76cd9bb7259d03d6306783c7b3593882"
  :revdesc "1d1841fd76cd"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
