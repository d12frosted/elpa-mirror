;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "commentary-theme" "20240620.1307"
  "A minimal theme with contrasting comments."
  '((emacs "24"))
  :url "https://github.com/pzel/commentary-theme"
  :commit "31e3724631d20fe5854cf522443a31fc12245ce3"
  :revdesc "31e3724631d2"
  :authors '(("Amirreza Ghaderi" . "amirreza.blog@gmail.com")
             ("Simon Zelazny" . "zelazny@mailbox.org"))
  :maintainers '(("Amirreza Ghaderi" . "amirreza.blog@gmail.com")
                 ("Simon Zelazny" . "zelazny@mailbox.org")))
