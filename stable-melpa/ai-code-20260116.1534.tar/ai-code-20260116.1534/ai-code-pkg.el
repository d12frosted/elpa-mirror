;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260116.1534"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "007fd8f7e19b37f1969035480823ef759215140c"
  :revdesc "007fd8f7e19b"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
