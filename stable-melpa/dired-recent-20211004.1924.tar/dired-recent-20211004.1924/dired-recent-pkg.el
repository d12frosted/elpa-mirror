;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-recent" "20211004.1924"
  "Dired visited paths history."
  '((emacs "24"))
  :url "https://github.com/vifon/dired-recent.el"
  :commit "a376f53e42fdca80c3286e8111578c65c64b0711"
  :revdesc "a376f53e42fd"
  :keywords '("files")
  :authors '(("Wojciech Siewierski" . "wojciechdotsiewierskiatonetdotpl"))
  :maintainers '(("Wojciech Siewierski" . "wojciechdotsiewierskiatonetdotpl")))
