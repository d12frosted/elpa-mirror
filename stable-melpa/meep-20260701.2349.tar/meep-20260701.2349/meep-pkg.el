;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260701.2349"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "83238b8ff8204c1bdcba595064300df691266e8a"
  :revdesc "83238b8ff820"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
