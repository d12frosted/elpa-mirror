;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251216.1246"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "040ed5aeb6905e7e5b869f703dc363ca31ca799b"
  :revdesc "040ed5aeb690"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
