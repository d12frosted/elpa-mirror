;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260226.1459"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "0e24b230e2851a57ed74266facac69fbe2ba2d6a"
  :revdesc "0e24b230e285"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
