;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polymode" "20250525.1030"
  "Extensible framework for multiple major modes."
  '((emacs "25"))
  :url "https://github.com/polymode/polymode"
  :commit "789ba7340e352bcdb4b51bb91fda523f7fa2bb9b"
  :revdesc "789ba7340e35"
  :keywords '("languages" "multi-modes" "processes")
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
