;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260514.52"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "091530ef760c19795f91c3596eb657a246578ae4"
  :revdesc "091530ef760c"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
