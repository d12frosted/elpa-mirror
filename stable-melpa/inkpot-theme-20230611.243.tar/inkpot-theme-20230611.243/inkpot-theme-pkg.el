(define-package "inkpot-theme" "20230611.243" "A port of vim's inkpot theme"
  '((emacs "24.1"))
  :commit "7eb83235047b3b126e07023b0a897be62f362c74" :authors
  '(("Sarah Iovan" . "sarah@hwaetageek.com")
    ("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Sarah Iovan" . "sarah@hwaetageek.com"))
  :maintainer
  '("Sarah Iovan" . "sarah@hwaetageek.com")
  :url "https://codeberg.org/ideasman42/emacs-inkpot-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
