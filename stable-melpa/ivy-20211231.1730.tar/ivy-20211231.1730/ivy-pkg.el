(define-package "ivy" "20211231.1730" "Incremental Vertical completYon"
  '((emacs "24.5"))
  :commit "5ff652c3020c5c510011018ca6805a4d65339e32" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("matching")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
