;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260329.2331"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "aeb8028eefb291d25c9c6ed867b740d4f3e30067"
  :revdesc "aeb8028eefb2"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
