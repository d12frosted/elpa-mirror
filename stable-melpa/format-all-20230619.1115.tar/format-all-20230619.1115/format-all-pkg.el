(define-package "format-all" "20230619.1115" "Auto-format C, C++, JS, Python, Ruby and 50 other languages"
  '((emacs "24.4")
    (inheritenv "0.1")
    (language-id "0.19"))
  :commit "cf303daef7adb03ecf2dcb250458c54ad9df5db7" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/lassik/emacs-format-all-the-code")
;; Local Variables:
;; no-byte-compile: t
;; End:
