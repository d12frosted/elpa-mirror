(define-package "smudge" "20231205.1242" "Control the Spotify app"
  '((emacs "27.1")
    (simple-httpd "20230821.1458")
    (request "0.3")
    (oauth2 "0.16"))
  :commit "5f4cf019b102294033e47f0f1b63f0ee7eb3a8f9" :keywords
  '("multimedia" "music" "spotify" "smudge")
  :url "https://github.com/danielfm/smudge")
;; Local Variables:
;; no-byte-compile: t
;; End:
