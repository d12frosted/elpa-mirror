;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260430.1153"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "1a285a4a19d3e311bb4eea0b21b6a28d80ec2a9c"
  :revdesc "1a285a4a19d3"
  :keywords '("languages" "lisp" "slime"))
