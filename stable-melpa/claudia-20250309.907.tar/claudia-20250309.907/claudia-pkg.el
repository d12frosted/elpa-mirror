;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claudia" "20250309.907"
  "Claude AI integration."
  '((emacs         "29.1")
    (uuidgen       "0.3")
    (markdown-mode "2.3"))
  :url "https://github.com/mzacho/claudia"
  :commit "536eb7433f3655fbd85fea34260c8d7e752b83a7"
  :revdesc "536eb7433f36"
  :keywords '("ai" "tools" "productivity" "codegen")
  :authors '(("Martin Zacho" . "hi@martinzacho.net"))
  :maintainers '(("Martin Zacho" . "hi@martinzacho.net")))
