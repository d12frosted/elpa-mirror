(define-package "lister" "20211122.1946" "Yet another list printer"
  '((emacs "26.1"))
  :commit "c83ef72ebda794315b5d827087f554baf9e4abb0" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
