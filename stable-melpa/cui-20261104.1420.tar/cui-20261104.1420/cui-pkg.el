;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261104.1420"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "fc91203c0012d172b23ff21f4fa9151ec85b7d31"
  :revdesc "fc91203c0012"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
