;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "code-awareness" "20260212.1934"
  "Kawa Code collaboration package."
  '((emacs "27.1"))
  :url "https://github.com/CodeAwareness/ca.emacs"
  :commit "ef24e5c4fc7b75fbe1d0c34b11821dd67f2ad40c"
  :revdesc "ef24e5c4fc7b"
  :keywords '("tools" "convenience" "vc")
  :authors '(("Mark Vasile" . "mark@code-awareness.com"))
  :maintainers '(("Mark Vasile" . "mark@code-awareness.com")))
