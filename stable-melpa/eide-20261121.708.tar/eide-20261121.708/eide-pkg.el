;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eide" "20261121.708"
  "IDE features made available out of the box."
  '((emacs "28.2"))
  :url "https://forge.tedomum.net/hjuvi/eide"
  :commit "8ce1113c05e193195d0208657e1d303262edbea5"
  :revdesc "8ce1113c05e1"
  :authors '(("Cédric Marie" . "hjuvi@tedomum.fr"))
  :maintainers '(("Cédric Marie" . "hjuvi@tedomum.fr")))
