(define-package "consult" "20221202.517" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "b96eb9944b433300c7e9ac5a856293821d93c549" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
