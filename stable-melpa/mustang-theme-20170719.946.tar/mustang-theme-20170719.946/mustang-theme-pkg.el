;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mustang-theme" "20170719.946"
  "Port of vim's mustang theme."
  ()
  :url "https://github.com/mswift42/mustang-theme"
  :commit "dda6d04803f1c9b196b620ef564e7768fee15de2"
  :revdesc "dda6d04803f1")
