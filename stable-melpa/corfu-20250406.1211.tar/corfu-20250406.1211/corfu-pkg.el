;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250406.1211"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "ab3de89622462d2c45e1914a4f07b266b613e4fd"
  :revdesc "ab3de8962246"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
