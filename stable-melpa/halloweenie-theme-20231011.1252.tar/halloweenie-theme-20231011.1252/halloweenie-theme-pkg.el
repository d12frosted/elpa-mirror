;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "halloweenie-theme" "20231011.1252"
  "Dark and spooky Halloween color theme."
  '((emacs      "27.1")
    (autothemer "0.2"))
  :url "https://cicadas.surf/cgit/halloweenie-theme.git"
  :commit "db39ff0516e071aa890585c39fe411ea355e8b06"
  :revdesc "db39ff0516e0"
  :keywords '("faces" "theme" "halloween" "pumpkin")
  :authors '(("Colin Okay" . "colin@cicadas.surf"))
  :maintainers '(("Colin Okay" . "colin@cicadas.surf")))
