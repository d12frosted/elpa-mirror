(define-package "i-ching" "20211112.1528" "The Book of Changes"
  '((emacs "25.1")
    (request "0.3"))
  :commit "39fd7daf1efd761336616c870cc5b8871422d95e" :authors
  '(("nik gaffney" . "nik@fo.am"))
  :maintainer
  '("nik gaffney" . "nik@fo.am")
  :keywords
  '("games" "divination" "stochastism" "cleromancy" "change")
  :url "https://github.com/zzkt/i-ching")
;; Local Variables:
;; no-byte-compile: t
;; End:
