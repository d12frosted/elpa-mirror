(define-package "dashboard" "20220809.1358" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "f6ac4a2ba87bd669d196bd4f53ac59191b789dcd" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
