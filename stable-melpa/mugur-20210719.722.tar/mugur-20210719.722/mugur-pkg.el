(define-package "mugur" "20210719.722" "Configurator for QMK compatible keyboards"
  '((emacs "26.1")
    (s "1.12.0")
    (anaphora "1.0.4")
    (dash "2.18.1")
    (cl-lib "1.0"))
  :commit "63a0377ac1ad48171621c9f0c719b62ec9395d35" :authors
  '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers
  '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainer
  '("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")
  :keywords
  '("multimedia")
  :url "https://github.com/mihaiolteanu/mugur")
;; Local Variables:
;; no-byte-compile: t
;; End:
