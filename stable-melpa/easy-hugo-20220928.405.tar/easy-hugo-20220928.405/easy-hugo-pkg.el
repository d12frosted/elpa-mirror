(define-package "easy-hugo" "20220928.405" "Write blogs made with hugo by markdown or org-mode"
  '((emacs "25.1")
    (popup "0.5.3")
    (request "0.3.0")
    (transient "0.3.6"))
  :commit "31e2f6d6d11be17576e135dd28d5ed441462d77d" :authors
  '(("Masashi Miyaura"))
  :maintainer
  '("Masashi Miyaura")
  :url "https://github.com/masasam/emacs-easy-hugo")
;; Local Variables:
;; no-byte-compile: t
;; End:
