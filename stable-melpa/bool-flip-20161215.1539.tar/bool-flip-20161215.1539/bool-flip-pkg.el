;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bool-flip" "20161215.1539"
  "Flip the boolean under the point."
  '((emacs "24.3"))
  :url "https://github.com/michaeljb/bool-flip/"
  :commit "0f7cc9b387429239fb929896511727d4e49a795b"
  :revdesc "0f7cc9b38742"
  :keywords '("boolean" "convenience" "usability")
  :authors '(("Michael Brandt" . "michaelbrandt5@gmail.com"))
  :maintainers '(("Michael Brandt" . "michaelbrandt5@gmail.com")))
