;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-rcirc" "20150215.2118"
  "Ibuffer integration for rcirc."
  '((cl-lib "0.2"))
  :url "https://github.com/fgallina/ibuffer-rcirc"
  :commit "8a4409b1c679d65c819dee4085faf929840e79f8"
  :revdesc "8a4409b1c679"
  :keywords '("buffer" "convenience" "comm")
  :authors '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Fabián Ezequiel Gallina" . "fgallina@gnu.org")))
