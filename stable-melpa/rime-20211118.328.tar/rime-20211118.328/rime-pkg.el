(define-package "rime" "20211118.328" "Rime input method"
  '((emacs "26.3")
    (dash "2.17.0")
    (cl-lib "0.6.1")
    (popup "0.5.3")
    (posframe "0.1.0"))
  :commit "4ee9d7a9b35571264be9b6eae96d7e1302c3e16c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "input-method")
  :url "https://www.github.com/DogLooksGood/emacs-rime")
;; Local Variables:
;; no-byte-compile: t
;; End:
