;;; lsp-ltex-plus-settings.el --- Settings and word lists for lsp-ltex-plus -*- lexical-binding: t; -*-

;; Author: Andrea Alberti <a.alberti82@gmail.com>
;; Maintainer: Andrea Alberti <a.alberti82@gmail.com>
;; Keywords: lsp, grammar, spelling, convenience
;; URL: https://github.com/ltex-plus/emacs-ltex-plus

;; This Source Code Form is subject to the terms of the Mozilla Public
;; License, v. 2.0. If a copy of the MPL was not distributed with this
;; file, You can obtain one at http://mozilla.org/MPL/2.0/.

;;; Commentary:
;;
;; The part of `lsp-ltex-plus' that knows nothing about the wire: every
;; user-facing setting, the debug log, the four language-keyed word lists
;; with their on-disk mirrors and merged views, a project's own copies of
;; those lists read through `.dir-locals.el', and the decision of where an
;; accepted suggestion is written.
;;
;; Nothing here talks to a server or to a protocol library.  The client
;; layer in `lsp-ltex-plus.el' reads these variables when it answers the
;; server's configuration requests and calls into this file when a code
;; action adds an entry to a list.  Keeping the two apart is what lets the
;; settings be tested, and reasoned about, without a connection.

;;; Code:

(require 'seq)
(require 'cl-lib)
(require 'lsp-ltex-plus-bootstrap)

;;;; -- Customization ----------------------------------------------------------

(defgroup lsp-ltex-plus nil
  "Customization group for the LTEX+ grammar checker."
  :group 'text
  :prefix "lsp-ltex-plus-")

;; Directory-local safety, modelled on AUCTeX (and on Emacs core, which declares
;; `fill-column' safe for an integer and `indent-tabs-mode' for a boolean).  The
;; package vouches for a setting with `:safe' and a predicate rather than
;; leaving every user to answer the same question in every project:
;;
;;   - Settings that can only change how text is checked are declared safe on a
;;     type check alone.  The worst a `.dir-locals.el' can do with them is check
;;     in the wrong language, or accept a word you did not choose.
;;   - Settings naming a file this package *writes* are held to more than a type
;;     check: see `lsp-ltex-plus--project-file-safe-p', which follows AUCTeX's
;;     `TeX--output-dir-safe-p' in accepting only a name that cannot lead
;;     outside the tree its `.dir-locals.el' governs.
;;   - Four live settings are deliberately left unvouched for, so that Emacs
;;     asks before a repository you cloned can set them.  Do not "complete"
;;     the set by adding `:safe' to them:
;;
;;     The line is drawn at security threats, not at configurations a user
;;     might find surprising -- those are the user's responsibility.  So the
;;     LanguageTool credentials are vouched for (a `.dir-locals.el' can only
;;     set a variable, never read one, so a repository cannot learn a key
;;     this way; substituting its own is visible in its own file), and so is
;;     the n-gram model directory, whose worst case is that its extra rules
;;     do not work.
;;
;;     `lsp-ltex-plus-lt-server-uri' is the middle case: it names the host
;;     every document you edit is sent to, so it is vouched for by an
;;     allowlist of destinations rather than by a type check.  Unset and
;;     LanguageTool Premium pass; any other host still asks.  See
;;     `lsp-ltex-plus--lt-server-uri-safe-p'.
;;
;;     Settings read only at server start or at client setup carry no `:safe'
;;     either — not because they are dangerous, but because a project-local
;;     value would silently do nothing, and vouching for it would imply
;;     otherwise.

(defcustom lsp-ltex-plus-ls-plus-executable "ltex-ls-plus"
  "The name or path of the ltex-ls-plus executable."
  :type 'string
  :group 'lsp-ltex-plus)

(defconst lsp-ltex-plus-minimum-server-version "18.7.0"
  "Oldest `ltex-ls-plus' this package works against.

Deliberately not a user option.  This is a fact about what the package
requires, not a preference: making it settable would mostly offer a way
to silence a real problem, and a silenced version mismatch reappears as
a diagnostic that never arrives.

An older server does not fail outright, it lacks features this package
assumes, so falling short is reported rather than refused.

Only the leading numbers are compared, so a pre-release such as
\"18.7.1-alpha.32+2026-08-26.g7977ac67\" counts as 18.7.1.")

(defcustom lsp-ltex-plus-require-minimum-server-version t
  "Whether to refuse a server older than the recommended floor.

`lsp-ltex-plus-minimum-server-version' is not a matter of taste: it is
the oldest `ltex-ls-plus' this package is written against.  With this
option at its default, `lsp-ltex-plus-mode' declines to start against
anything older and says so, rather than running with features that
quietly do not work.

Setting it to nil is allowed, not encouraged.  Installing an older
server is occasionally the only way round a bug in a newer one, and
being pushed onto a broken release is no better than being held on a
stale one -- which of the two you are facing is not something this
package can tell.  So the escape hatch exists; taking it means some
features may not work, and the version is still reported once.

Nothing is refused when the version cannot be determined at all."
  :type 'boolean
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-debug nil
  "When non-nil, log what the client does to `*lsp-ltex-plus log*\\='.
Which buffer it decided to check and why not, the documents it opened,
the diagnostics it kept or dropped, where an added word was saved.

This is the only thing the option does.  The three other records each
have their own setting, so that turning this one on cannot start a file
or a flood nobody asked for: `lsp-ltex-plus-events-buffer-size\\=' for the
messages exchanged with the server, `lsp-ltex-plus-server-log-file\\=' for
the whole exchange written to a file by the server itself, and
`lsp-ltex-plus-ltex-ls-log-level\\=' for how much the server narrates into
`*ltex-ls-plus stderr*\\='."
  :type 'boolean
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-events-buffer-size 0
  "Characters of the exchange with the server to keep in the events buffer.
Handed to jsonrpc, which keeps that record in `*ltex-ls-plus events*\\=' and
eats the oldest lines to stay within the number given here.  Characters
rather than bytes: jsonrpc measures with `buffer-size\\='.

Zero, the default, records nothing: the buffer is created and stays
empty.  A grammar checker sends the whole document on every pause in
typing, so there is nothing here a writer needs, and on a 50 KB document
the record would grow by 50 KB every few seconds.  A positive number is
useful to watch the conversation and its latency; 200000 holds a good
while of it.  nil is jsonrpc\='s own default, which is no limit at all --
the buffer then grows for as long as Emacs runs.

Read when the server starts; `lsp-ltex-plus-restart-server\\=' applies a
change.  See also `lsp-ltex-plus-events-buffer-format\\='."
  :type '(choice (const :tag "Record nothing" 0)
                 (integer :tag "Bytes to keep")
                 (const :tag "No limit (jsonrpc\='s default)" nil))
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-events-buffer-format 'short
  "How much of each message to write in the events buffer.
`short\=' is one line per message: the time, the direction, the method
and the id.  `full\=' adds the message\='s JSON to that line, which for a
`textDocument/didChange\=' is the whole document.

Only meaningful when `lsp-ltex-plus-events-buffer-size\\=' records
something.  Emacs 29\='s jsonrpc has no such choice -- it takes a size and
nothing else -- so this is ignored there, and what it writes is its own
pretty-printed rendering of every message.

Read when the server starts; `lsp-ltex-plus-restart-server\\=' applies a
change."
  :type '(choice (const :tag "One line per message" short)
                 (const :tag "One line per message, with its JSON" full))
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-server-log-file nil
  "Where the server should tee the whole exchange, or nil for nowhere.
Passed to `ltex-ls-plus\=' as its own `--log-file\=' option, so the file is
written by the server, not by Emacs: both directions of the conversation
and the server\='s log, in one file, in order.  \=`${PID}\=' in the name is
replaced by the server\='s process id, and an existing directory is given
a file named for the process inside it.  The parent directory must
exist.

This is a maintainer\='s instrument.  Reach for it when the suspicion is a
bug in the conversation with the server -- a request the server refuses,
a check that never comes back -- and send the file with the report.  It
grows for as long as the server runs, and it is written from the moment
the server starts, whatever `lsp-ltex-plus-debug\\=' says.

Read when the server starts; `lsp-ltex-plus-restart-server\\=' applies a
change."
  :type '(choice (const :tag "No file" nil) (file :tag "File"))
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-check-programming-languages nil
  "When non-nil, enable grammar checking in programming language comments.

By default this is nil, matching LTeX+\\='s own default: only markup languages
\(LaTeX, Markdown, Org, …) are checked automatically.  Setting this to t lets
the dispatcher activate `lsp-ltex-plus-mode\\=' in buffers whose `major-mode\\='
is flagged as a programming language in `lsp-ltex-plus-major-modes\\=',
enabling comment checking in 30+ languages.

This flag only affects client-side activation.  The `ltex.enabled\\='
list sent to the server always contains every supported language ID from
`lsp-ltex-plus-major-modes\\='; the dispatcher is the authoritative
gate.  Explicit interactive calls (M-x `lsp-ltex-plus-mode\\=') always
proceed regardless of this flag, so on-demand grammar checks work in any
supported buffer without toggling this global setting.

Note: LTeX+ is selective about which comments it checks — the exact rule
is not documented and has to be read off the server source.  What is
verified empirically: standalone comment lines (the delimiter is the
first non-whitespace on the line) followed by a space before the text
are checked; trailing/inline comments after code on the same line are
*not*.  Other cases remain to be explored in the server's comment
regex tables.  The common effect is to minimise false positives from
commented-out code.  Python comments are parsed as reStructuredText;
all others are parsed as Markdown."
  :type 'boolean
  :safe #'booleanp
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-language "en-US"
  "The language (e.g., \"en-US\") LanguageTool should check against.
If possible, use a specific variant like \"en-US\" or \"de-DE\" instead of the
generic language code like \"en\" or \"de\" to obtain spelling corrections (in
addition to grammar corrections).

When using the language code \"auto\", LTeX+ will try to detect the language of
the document.  This is not recommended, as only generic languages like \"en\" or
\"de\" will be detected and thus no spelling errors might be reported."
  :type 'string
  :safe #'stringp
  :group 'lsp-ltex-plus)

(defun lsp-ltex-plus--symbol-keyed-alist-p (value)
  "Non-nil when VALUE is an alist of symbol keys with string or boolean values.
The shape the parser tables take — `lsp-ltex-plus-bibtex-fields',
`-latex-commands', `-latex-environments', `-markdown-nodes'.  Used as
their `:safe' predicate: such a value only changes how a document is
parsed before it is checked, so a project may set one without asking."
  (and (listp value)
       (seq-every-p (lambda (cell)
                      (and (consp cell)
                           (symbolp (car cell))
                           (or (stringp (cdr cell))
                               (memq (cdr cell) '(t nil)))))
                    value)))

(defun lsp-ltex-plus--language-plist-p (value)
  "Non-nil when VALUE is a language-keyed plist of vectors of strings.
The shape the four language-keyed settings take, e.g.
\\='(:en-US [\"foo\"] :de-DE [\"bar\"]).  Used as the `:safe' predicate for
those settings: a value of this shape only ever adds words or rule
names to a check, so a project may set one without confirmation."
  (and (listp value)
       (cl-evenp (length value))
       (cl-loop for (key val) on value by #'cddr
                always (and (keywordp key)
                            (vectorp val)
                            (seq-every-p #'stringp val)))))

(defcustom lsp-ltex-plus-dictionary nil
  "Additional words accepted as correctly spelled, per language.
This setting is language-specific, so use a plist of the form
\\='(:en-US [\"WORD1\" \"WORD2\"] :de-DE [\"WORD1\" ...]) where the key is
the language code and the value is a vector of words.

Provides the user-seeded counterpart to entries added at runtime via the
_ltex.addToDictionary code action; the two sources are kept separate
and merged on the fly for the server.  For large, hand-curated word
lists, prefer editing the on-disk file (see the External settings
section in the README) rather than stuffing everything into this
variable."
  :type 'plist
  :safe #'lsp-ltex-plus--language-plist-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-enabled-rules nil
  "Lists of rules that should be enabled (if disabled by default).
This setting is language-specific, so use an object of the format
\\='(:en-US [\"RULE1\" \"RULE2\"] :de-DE [\"RULE1\" ...]) where the key is
the language code and the value is a vector of rule IDs."
  :type 'plist
  :safe #'lsp-ltex-plus--language-plist-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-disabled-rules nil
  "Lists of rules that should be disabled (if enabled by default).
This setting is language-specific, so use an object of the format
\\='(:en-US [\"RULE1\" \"RULE2\"] :de-DE [\"RULE1\" ...]) where the key is
the language code and the value is a vector of rule IDs."
  :type 'plist
  :safe #'lsp-ltex-plus--language-plist-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-hidden-false-positives nil
  "False-positive diagnostics that should be hidden from reports.
This setting is language-specific, so use a plist of the form
\\='(:en-US [\"<jsonObject1>\" ...] :de-DE [\"<jsonObject1>\" ...]) where
each string is a JSON object of the form
`{\"rule\":\"RULE_ID\",\"sentence\":\"REGEX\"}' that matches a diagnostic's
rule ID and surrounding sentence regex.

Provides the user-seeded counterpart to entries added at runtime via the
_ltex.hideFalsePositives code action; the two sources are kept
separate and merged on the fly for the server.  See the LTeX+
documentation for the feature:
https://ltex-plus.github.io/ltex-plus/advanced-usage.html#hiding-false-positives-with-regular-expressions"
  :type 'plist
  :safe #'lsp-ltex-plus--language-plist-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-bibtex-fields nil
  "List of BibTeX fields whose values are to be checked in BibTeX files.
This setting is an object with the field names as keys and Booleans as values,
where true means that the field value should be checked and false means that
the field value should be ignored.  Field names are listed as symbols
\(e.g., `title')."
  :type 'alist
  :safe #'lsp-ltex-plus--symbol-keyed-alist-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-latex-commands nil
  "List of LaTeX commands to be handled by the LaTeX parser.
This setting is an object with the commands as keys and corresponding
actions as values (\"default\", \"ignore\", \"dummy\", \"pluralDummy\",
\"vowelDummy\"). Commands are listed as symbols (not strings) with empty
arguments and the initial backslash doubled, e.g. `\\\\ref{}',
`\\\\documentclass[]{}'."
  :type 'alist
  :safe #'lsp-ltex-plus--symbol-keyed-alist-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-latex-environments nil
  "List of names of LaTeX environments to be handled by the LaTeX parser.
This setting is an object with the environment names as keys and corresponding
actions as values (\"default\", \"ignore\").  Environment names are listed as
symbols (e.g., `lstlisting')."
  :type 'alist
  :safe #'lsp-ltex-plus--symbol-keyed-alist-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-markdown-nodes nil
  "List of Markdown node types to be handled by the Markdown parser.
This setting is an object with the node types as keys and corresponding
actions as values (\"default\", \"ignore\", \"dummy\", \"pluralDummy\",
\"vowelDummy\").  Node types are listed as symbols (e.g., `CodeBlock')."
  :type 'alist
  :safe #'lsp-ltex-plus--symbol-keyed-alist-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-additional-rules-enable-picky-rules nil
  "Enable LanguageTool rules that are marked as picky.
These are disabled by default, e.g., rules about passive voice, sentence length,
etc., at the cost of more false positives."
  :type 'boolean
  :safe #'booleanp
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-additional-rules-mother-tongue nil
  "Optional mother tongue of the user (e.g., \"de-DE\").
If set, additional rules will be checked to detect false friends. Picky rules
may need to be enabled in order to see an effect.  nil means unset."
  :type '(choice (const :tag "Unset" nil) (string :tag "Language code"))
  :safe #'string-or-null-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-additional-rules-language-model nil
  "Optional path to a directory of n-gram language model rules.
Set this to the parent directory that contains subdirectories for
languages.  nil means unset."
  :type '(choice (const :tag "Unset" nil) (directory :tag "Directory"))
  :safe #'string-or-null-p
  :group 'lsp-ltex-plus)

(defconst lsp-ltex-plus--vouched-lt-server-uris
  '("https://api.languagetoolplus.com"
    "https://api.languagetoolplus.com/")
  "LanguageTool endpoints a project may select without being asked.
Only LanguageTool's own Premium service.  Everything reached through
this setting receives the full text of every document you edit, so the
list is an allowlist of destinations, not a syntax check: any other
host stays subject to Emacs' usual confirmation.")

(defun lsp-ltex-plus--lt-server-uri-safe-p (value)
  "Non-nil when VALUE is an endpoint safe to accept from a `.dir-locals.el'.
Unset (nil, or the empty string an older config may still carry) means
the local built-in LanguageTool and sends nothing anywhere.  The only
remote destination vouched for is LanguageTool's own Premium service;
see `lsp-ltex-plus--vouched-lt-server-uris'.  Between them these are
what nearly every configuration uses, so the prompt is reserved for the
case that genuinely warrants one: a project pointing your prose at some
other host."
  (or (null value)
      (and (stringp value)
           (or (equal value "")
               (member value lsp-ltex-plus--vouched-lt-server-uris)))))

(defcustom lsp-ltex-plus-lt-server-uri nil
  "Base URI for the LanguageTool HTTP server.
When nil (default), ltex-ls-plus uses its local, built-in LanguageTool.
To use an online service, set this to e.g.,
\"https://api.languagetoolplus.com\".
Note: ltex-ls-plus appends /v2/check to this, so omit the /v2 suffix here.

Whatever this points at receives the full text of every document you
edit.  A project may therefore select the built-in checker or
LanguageTool Premium through its `.dir-locals.el' without being asked,
but any other host goes through Emacs' usual confirmation; see
`lsp-ltex-plus--lt-server-uri-safe-p'."
  :type '(choice (const :tag "Local (Built-in)" nil)
                 (string :tag "Remote URI"))
  :safe #'lsp-ltex-plus--lt-server-uri-safe-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-lt-username nil
  "Username/email as used to log in at languagetool.org for Premium API access.
Only relevant if `lsp-ltex-plus-lt-server-uri' is set.  nil means unset."
  :type '(choice (const :tag "Unset" nil) (string :tag "Username/email"))
  :safe #'string-or-null-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-lt-api-key nil
  "API key for Premium API access.
Only relevant if `lsp-ltex-plus-lt-server-uri' is set.  nil means unset."
  :type '(choice (const :tag "Unset" nil) (string :tag "API key"))
  :safe #'string-or-null-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-ltex-ls-path nil
  "Path to the root directory of ltex-ls-plus.
It contains bin and lib subdirectories.  nil (or empty) means the
bundled version is used."
  :type '(choice (const :tag "Bundled" nil) (directory :tag "Directory"))
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-ltex-ls-log-level "fine"
  "Logging level (verbosity) of the ltex-ls-plus server log.
The levels in descending order are \"severe\", \"warning\", \"info\",
\"config\", \"fine\", \"finer\", and \"finest\"."
  :type '(choice (const "severe") (const "warning") (const "info")
                 (const "config") (const "fine") (const "finer")
                 (const "finest"))
  :group 'lsp-ltex-plus)

(define-obsolete-variable-alias 'lsp-ltex-plus-java-path
  'lsp-ltex-plus-java-home "1.1.0")

(defcustom lsp-ltex-plus-java-home nil
  "Java installation to start the server with, or nil for none.
Exactly what you would put in the JAVA_HOME environment variable, and
what it is passed to the launcher script as.

nil leaves the environment as Emacs has it: the launcher then uses the
JAVA_HOME it inherits, if Emacs has one, and otherwise the `java\=' it
finds on the path -- often the runtime bundled with the server."
  :type '(choice (const :tag "Unset" nil) (directory :tag "Directory"))
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-java-initial-heap nil
  "Initial size of the Java heap in megabytes, or nil to let the JVM decide.
Passed to the server's launcher as -Xms when set.  Read when the server
starts; `lsp-ltex-plus-restart-server' applies a change."
  :type '(choice (const :tag "JVM default" nil) integer)
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-java-max-heap nil
  "Maximum size of the Java heap in megabytes, or nil to let the JVM decide.
Passed to the server's launcher as -Xmx when set.  The JVM's own default
is a quarter of the machine's memory, which is what the server has
always run with from this client and is ample; a fixed cap is for
machines where that is too much.  512 is too little for a server that
checks in two languages at once -- it never finishes loading the second.
Read when the server starts; `lsp-ltex-plus-restart-server' applies a
change."
  :type '(choice (const :tag "JVM default" nil) integer)
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-sentence-cache-size 0
  "Size of the LanguageTool ResultCache in sentences.
The default and recommended value is 0, which disables the local
LanguageTool server's own cache entirely.  ltex-ls-plus keeps its own
per-paragraph cache, which supersedes LanguageTool's caching.
Use a positive value to turn it back on, but be aware that this is
redundant and only adds CPU and memory overhead with no additional
benefit.  To go back to LanguageTool's caching instead of the
per-paragraph cache, set this to a positive value and also set
`lsp-ltex-plus-paragraph-cache-enabled' to nil."
  :type 'integer
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-max-request-size 20000
  "Largest amount of text, in characters, sent to LanguageTool in one request.
ltex-ls-plus caches results per paragraph and re-checks only the
paragraphs you edited.  When several changed paragraphs sit next to
each other they are batched into a single request (typically the
first, whole-document check); text larger than this is split across
several requests, but an individual paragraph is never split.  The
default fits within the per-request character limit of the free
remote LanguageTool service.  If you use a local server
\(`lsp-ltex-plus-lt-server-uri' is nil) or have a Premium account,
consider raising it to 60000.  This does not affect caching granularity,
which is always per paragraph."
  :type 'integer
  :safe #'integerp
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-paragraph-cache-ttl-minutes 30
  "How long, in minutes, a document's cached results are kept unused.
The per-paragraph cache lets ltex-ls-plus reuse the results of
unchanged paragraphs after an edit.  Entries for the file you are
actively editing stay warm; a document left untouched for longer than
this is dropped from the cache.  A document's cache is also cleared as
soon as the file is closed."
  :type 'integer
  :safe #'integerp
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-paragraph-cache-enabled t
  "Whether ltex-ls-plus reuses cached results for unchanged paragraphs.
When non-nil (the default and recommended), each paragraph's result is
stored and reused, so an edit only re-checks the paragraphs that
changed.  Set to nil to disable reuse of results, so every paragraph is
re-checked on each pass.  This does not affect
`lsp-ltex-plus-max-request-size': the text is always sliced into
paragraphs, which in turn are batched into requests.  If disabled,
sliced paragraphs are just never stored or served from the cache.
Disabling this and setting `lsp-ltex-plus-sentence-cache-size' to a
positive value restores LanguageTool's own caching instead."
  :type 'boolean
  :safe #'booleanp
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-completion-enabled nil
  "Whether the server offers word completion.
Not available in 1.0.0: the client does not yet request completions.
Planned for a future release; until then the setting has no visible
effect, though it is still sent to the server."
  :type 'boolean
  :safe #'booleanp
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-diagnostic-severity "warning"
  "Severity of the diagnostics corresponding to the grammar and spelling errors.
Possible severities are \"error\", \"warning\", \"information\", and \"hint\"."
  :type '(choice (const "error") (const "warning") (const "information") (const "hint"))
  :safe #'stringp
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-check-frequency "edit"
  "Controls when documents should be checked.
- \"edit\": checked when opened or edited (on every keystroke).
- \"save\": checked when opened or saved.
- \"manual\": use commands to manually trigger checks."
  :type '(choice (const "edit") (const "save") (const "manual"))
  :safe #'stringp
  :group 'lsp-ltex-plus)

(define-obsolete-variable-alias 'lsp-ltex-plus-change-delay
  'lsp-ltex-plus-idle-delay "1.1.0")

;; `safe-local-variable' does not follow an alias, so a project whose
;; `.dir-locals.el' still names the old variable would start asking the
;; user to approve a value this package has always vouched for.
(put 'lsp-ltex-plus-change-delay 'safe-local-variable #'numberp)

(defcustom lsp-ltex-plus-idle-delay 0.5
  "Seconds of quiet after an edit before the buffer is sent to the server.
Every edit restarts the wait, so a burst of typing is sent once, when it
pauses.  The server re-checks the whole document on each send, so this
is the one knob that trades responsiveness against work: lower it for
quicker feedback, raise it on a slow machine or for very large files.

Idle in the ordinary sense -- you stopped typing -- not
`run-with-idle-timer\='.  The wait is a plain timer, restarted at every
edit, because Emacs counts as idle only when it is waiting for the
user, which a batch Emacs never does and a buffer receiving output from
a process need not."
  :type 'number
  :safe #'numberp
  :group 'lsp-ltex-plus)


(defcustom lsp-ltex-plus-clear-diagnostics-when-closing-file t
  "If set to true, diagnostics of a file are cleared when the file is closed."
  :type 'boolean
  :safe #'booleanp
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-check-fileless-buffers t
  "When non-nil, grammar-check buffers that have no backing file.
File-less buffers (e.g. *scratch*, capture buffers) in a recognized major
mode are opened on the server under an identity the client invents;
nothing is written to disk, and the one server of the session checks
them like any file.

This is orthogonal to `lsp-ltex-plus-check-programming-languages': a
file-less buffer in a programming mode (such as *scratch*, which uses
`lisp-interaction-mode') is still auto-activated only when programming
checks are also enabled, but an explicit \\[lsp-ltex-plus-mode] always
works."
  :type 'boolean
  :safe #'booleanp
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-disable-flyspell nil
  "When non-nil, switch `flyspell-mode\\=' off in a buffer LTeX+ is checking.
Flyspell checks spelling word by word against the system dictionary;
in a document LTeX+ checks, it flags macro names, identifiers and every
proper noun it does not know, and its dictionary is not the one you
maintain through this package.  With this option on, turning
`lsp-ltex-plus-mode\\=' on in a buffer where flyspell is active turns
flyspell off, and turning the mode off brings flyspell back -- only
where this package stopped it.  Off by default: a package should not
switch another mode off unasked, and some people want flyspell for the
code around the comments LTeX+ checks."
  :type 'boolean
  :safe #'booleanp
  :group 'lsp-ltex-plus)

(defun lsp-ltex-plus--diagnostics-provider-p (value)
  "Non-nil when VALUE is one of the `lsp-ltex-plus-diagnostics-provider' choices."
  (memq value '(flymake flycheck)))

(defcustom lsp-ltex-plus-diagnostics-provider 'flymake
  "Which front-end shows the server's diagnostics: `flymake' or `flycheck'.
Flymake, the default, is part of Emacs and needs nothing installed.
Flycheck must be installed separately; when it is chosen but cannot be
loaded, flymake is used and a warning says so, once per session.  Read
when the mode is turned on in a buffer, so a change applies to the
buffers checked from then on; turning `lsp-ltex-plus-mode' off and on
again moves a buffer that is already being checked."
  :type '(choice (const :tag "Flymake (part of Emacs)" flymake)
                 (const :tag "Flycheck" flycheck))
  :safe #'lsp-ltex-plus--diagnostics-provider-p
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-check-comint-input t
  "When non-nil, grammar-check the active input region of comint buffers.
In a `comint-mode' buffer (e.g. `agent-shell-mode', a shell, a REPL) only
the editable input the user is currently typing — the region from the
process mark to the end of the buffer — is sent to LTEX+.  Previously
submitted input and all process/agent output are never checked.

A comint buffer visits no file, so it is opened under an invented
identity like any file-less buffer; what is sent as the document is the
input region alone, and while the program is producing output nothing
is sent at all.  See `lsp-ltex-plus-comint.el'."
  :type 'boolean
  :safe #'booleanp
  :group 'lsp-ltex-plus)

(defvar lsp-ltex-plus-trace-server "off"
  "Debug setting to log the communication between language client and server.
- \"off\": Don't log any communication.
- \"messages\": Log the type of requests and responses.
- \"verbose\": Log the type and contents of requests and responses.

Sent to the server in the `initialize' request, so what it asks for
comes back over the wire and lands wherever the exchange is recorded --
which by default is nowhere, see `lsp-ltex-plus-events-buffer-size'.
Nothing sets this on your behalf.")

;;;; -- Internal State & Logging -----------------------------------------------

(defvar lsp-ltex-plus--start-time nil
  "Timestamp of when `lsp-ltex-plus--setup' was executed.")

(defvar-local lsp-ltex-plus--fileless-uri nil
  "The synthetic URI this file-less buffer is known by, or nil.
Invented the first time the buffer is opened on the server and kept
while the buffer lives, so that turning the mode off and on reuses the
same identity; cleared when the buffer is saved to a file, after which
the file's own URI takes over.")

(defvar lsp-ltex-plus--fileless-counter 0
  "Monotonic counter for generating unique file-less buffer URIs.
Combined with the Emacs PID so synthetic identities never collide within
or across sessions; see `lsp-ltex-plus--make-fileless-uri'.")

(defvar-local lsp-ltex-plus--comint-active nil
  "Non-nil when this comint buffer's input region is being checked.
Set by the comint activation branch of `lsp-ltex-plus-mode' and cleared
by `lsp-ltex-plus--comint-teardown'.  Gates the submit re-sync and
tear-down so they no-op in buffers that never opted in.")

(defvar lsp-ltex-plus--dictionary-stored nil
  "The words accepted through suggestions, as read from and written to disk.
The in-memory mirror of `lsp-ltex-plus-dictionary-file'.  Kept apart from
the defcustom `lsp-ltex-plus-dictionary' so that a `:custom' value is
never written to disk; the server is shown the merge of the two, made
when it asks (see `lsp-ltex-plus--global-plist').")

(defvar lsp-ltex-plus--enabled-rules-stored nil
  "The rules enabled by hand-editing the file, as read from disk.
The in-memory mirror of `lsp-ltex-plus-enabled-rules-file'; no
suggestion writes here.  Merged with `lsp-ltex-plus-enabled-rules' when
the server asks.")

(defvar lsp-ltex-plus--disabled-rules-stored nil
  "The rules disabled through suggestions, as read from and written to disk.
The in-memory mirror of `lsp-ltex-plus-disabled-rules-file'.  Merged
with `lsp-ltex-plus-disabled-rules' when the server asks.")

(defvar lsp-ltex-plus--hidden-false-positives-stored nil
  "The false positives hidden through suggestions, kept on disk.
The in-memory mirror of `lsp-ltex-plus-hidden-false-positives-file'.
Merged with `lsp-ltex-plus-hidden-false-positives' when the server asks.")

(defvar lsp-ltex-plus--project-file-cache (make-hash-table :test #'equal)
  "Cache of project settings files: absolute path -> (MTIME . PLIST).
The server pulls settings on every check, so the files behind that pull
are read only when their modification time has moved.  MTIME is nil for
a file that does not exist, which is itself cached — creating the file
later moves the time off nil and the entry is refreshed.  Filled and
consulted by `lsp-ltex-plus--load-project-plist'; see the
`lsp-ltex-plus-project-*-file' settings.")

(defvar lsp-ltex-plus--server-name nil
  "Name the connected ltex-ls-plus gave in its `serverInfo\\=', or nil.
Set by `lsp-ltex-plus--enforce-server-version\\=' once the handshake has
completed; nil against a server that omits `serverInfo\\='.")

(defvar lsp-ltex-plus--server-version nil
  "Version of the ltex-ls-plus the session last connected to, or nil.
Set by `lsp-ltex-plus--enforce-server-version\\=' from the `serverInfo\\='
the server sent in its `initialize\\=' reply; nil against a server that
gave none.  Stored verbatim, build metadata and all, e.g.
\"18.7.1-alpha.32+2026-08-26.g7977ac67\".")

;; -- JSON-serialization helpers -----------------------------------------------
;;
;; In Elisp `nil' is overloaded: it is `false', the empty list, the empty plist,
;; and the empty alist all at once.  `json-serialize' resolves this to JSON
;; `null'.  Several settings the server reads must be either a JSON object or a
;; JSON boolean — never `null'.  These helpers normalize the value at the
;; protocol boundary so that an unset Elisp variable serializes correctly.

(defvar lsp-ltex-plus--empty-ht (make-hash-table :test 'equal)
  "Shared, read-only empty hash-table used for nil object-typed settings.
Substituted for nil so `json-serialize' emits {} instead of null
for fields whose JSON type is a (possibly empty) object.  Pre-allocated
once and shared across all call sites: the structure is only ever read
by the JSON serializer, never mutated.")

(defsubst lsp-ltex-plus--obj-or-empty (val)
  "Return VAL if non-nil, else `lsp-ltex-plus--empty-ht'.
For settings whose JSON type is an object — they must never serialize
as null.  An empty hash-table is unambiguously a JSON object."
  (or val lsp-ltex-plus--empty-ht))

(defsubst lsp-ltex-plus--bool (val)
  "Return JSON-correct boolean for VAL: t for non-nil, `:json-false' otherwise.
For settings whose JSON type is a boolean.  Without this, a nil
defcustom would serialize as JSON null rather than false."
  (if val t :json-false))

(defsubst lsp-ltex-plus--str (val)
  "Return VAL if non-nil, else the empty string \"\".
For string-typed settings.  Storing nil for \"unset\" is the
Emacs-idiomatic choice; the server expects a string, so nil is
translated to \"\" at the protocol boundary.  An explicit \"\" left in
an existing user config passes through unchanged."
  (or val ""))

(defun lsp-ltex-plus--elapsed ()
  "Return seconds (float) since `lsp-ltex-plus--start-time' or Emacs init."
  (float-time (time-subtract (current-time)
                             (or lsp-ltex-plus--start-time before-init-time))))

(defun lsp-ltex-plus--log-to-buffer (msg)
  "Write MSG with a timestamp to the *lsp-ltex-plus log* buffer."
  (with-current-buffer (get-buffer-create "*lsp-ltex-plus log*")
    (let ((inhibit-read-only t))
      (goto-char (point-max))
      (insert (format "[%10.3f] %s\n" (lsp-ltex-plus--elapsed) msg))
      (setq buffer-read-only t))))

(defmacro lsp-ltex-plus--log (fmt &rest args)
  "Log a formatted message if `lsp-ltex-plus-debug' is enabled.
FMT is the format string, and ARGS are the arguments for it."
  `(when lsp-ltex-plus-debug
     (lsp-ltex-plus--log-to-buffer (format ,fmt ,@args))))

;;;; -- Dictionary Management --------------------------------------------------

(defcustom lsp-ltex-plus-dictionary-file
  (locate-user-emacs-file "lsp-ltex-plus/stored-dictionary.eld")
  "Path to the external dictionary file (plist format).
Set this before the package loads, or run
`lsp-ltex-plus-reload-settings\=' afterwards.  An existing file is not
moved for you."
  :type 'file
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-enabled-rules-file
  (locate-user-emacs-file "lsp-ltex-plus/enabled-rules.eld")
  "Path to the external enabled rules file (plist format).
Set it like `lsp-ltex-plus-dictionary-file\='."
  :type 'file
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-disabled-rules-file
  (locate-user-emacs-file "lsp-ltex-plus/disabled-rules.eld")
  "Path to the external disabled rules file (plist format).
Set it like `lsp-ltex-plus-dictionary-file\='."
  :type 'file
  :group 'lsp-ltex-plus)

(defcustom lsp-ltex-plus-hidden-false-positives-file
  (locate-user-emacs-file "lsp-ltex-plus/hidden-false-positives.eld")
  "Path to the external hidden false positives file (plist format).
Set it like `lsp-ltex-plus-dictionary-file\='."
  :type 'file
  :group 'lsp-ltex-plus)

(defun lsp-ltex-plus--load-plist (file-path)
  "Load a plist from FILE-PATH.  Return nil if it doesn't exist or fails."
  (lsp-ltex-plus--log "Loading plist from %s" file-path)
  (if (not (file-exists-p file-path))
      (progn (lsp-ltex-plus--log "File not found: %s" file-path) nil)
    (condition-case err
        (with-temp-buffer
          (insert-file-contents file-path)
          (read (current-buffer)))
      (error
       (message "[lsp-ltex-plus] Failed to read %s: %S" file-path err)
       nil))))

(defun lsp-ltex-plus--save-plist (plist file-path)
  "Save PLIST to FILE-PATH."
  (lsp-ltex-plus--log "Saving plist to %s" file-path)
  (make-directory (file-name-directory file-path) t)
  (with-temp-file file-path
    (let ((print-length nil)
          (print-level nil))
      (prin1 plist (current-buffer)))))

;; TODO(2027-05): Remove `lsp-ltex-plus--migrate-extensionless-file'
;; and its caller in `lsp-ltex-plus--setup' once existing installs
;; have migrated to the .eld extension.
(defun lsp-ltex-plus--migrate-extensionless-file (current-path default-path)
  "Move the pre-.eld counterpart of DEFAULT-PATH into place.
Acts only when CURRENT-PATH equals DEFAULT-PATH — i.e. the user has not
explicitly customised the file location.  Users who have chosen their
own path are not affected.

When CURRENT-PATH equals DEFAULT-PATH and the extensionless
sibling of DEFAULT-PATH exists on disk:

- if DEFAULT-PATH does not yet exist, rename the old file into
  place;
- if DEFAULT-PATH also exists, emit a message asking the user to
  merge the two files manually; downstream code keeps reading
  DEFAULT-PATH."
  (when (equal current-path default-path)
    (let ((old-path (file-name-sans-extension default-path)))
      (when (file-exists-p old-path)
        (if (file-exists-p default-path)
            (message "[lsp-ltex-plus] Cannot migrate %s -> %s: both files exist; please merge them manually."
                     old-path default-path)
          (rename-file old-path default-path)
          (message "[lsp-ltex-plus] Migrated %s -> %s" old-path default-path))))))

(defun lsp-ltex-plus--merge-plists (p1 p2)
  "Merge plist P2 into P1 and return the result.
Items in vectors are merged and deduplicated using `string=`."
  (let ((res (copy-sequence p1)))
    (cl-loop for (key val) on p2 by #'cddr do
             (let* ((v1 (plist-get res key))
                    (l1 (if (vectorp v1) (append v1 nil) nil))
                    (l2 (if (vectorp val) (append val nil) nil))
                    (merged (vconcat (seq-uniq (append l1 l2) #'string=))))
               (setq res (plist-put res key merged))))
    res))

(defun lsp-ltex-plus--add-to-plist (plist-sym file-path lang items)
  "Add ITEMS for LANG to the plist stored in PLIST-SYM and save to FILE-PATH."
  (lsp-ltex-plus--log "Adding items for %s to %s: %S" lang (symbol-name plist-sym) items)
  (let* ((key (intern (concat ":" lang)))
         (new-data (list key (vconcat items)))
         (merged (lsp-ltex-plus--merge-plists (symbol-value plist-sym) new-data)))
    (set plist-sym merged)
    (lsp-ltex-plus--save-plist merged file-path)))

(defun lsp-ltex-plus-list-dictionary ()
  "Show the accepted words in force for the document in this buffer.

That is what the server is actually told: the global list -- the
defcustom `lsp-ltex-plus-dictionary\=' merged with the file
`lsp-ltex-plus-dictionary-file\=' names -- and, in a project keeping a
dictionary of its own, that project\='s words folded in on top.  The
project file is named in the output, so a word you did not expect can be
traced to the list it came from.

Called where no project dictionary applies -- outside a project, or in a
buffer with no file, such as `*scratch*\=' -- this is simply the global
list."
  (interactive)
  (let ((effective (lsp-ltex-plus--effective-plist 'dictionary))
        (project-file (lsp-ltex-plus--project-file-for 'dictionary)))
    (if project-file
        (message "[lsp-ltex-plus] Dictionary (global + %s): %S"
                 (abbreviate-file-name project-file) effective)
      (message "[lsp-ltex-plus] Dictionary (global): %S" effective))))

;;;; -- Project-local settings -------------------------------------------------

;; A project can keep its own word list and rule lists beside the global ones
;; under `user-emacs-directory'.  The four variables below mirror the global
;; `lsp-ltex-plus-*-file' ones and are normally set from a project's
;; `.dir-locals.el'; each names a file whose contents are merged with the
;; corresponding global list for documents in that project.  Neither side
;; shadows the other: a word present in either list is accepted, so a project
;; adds its jargon on top of the vocabulary you carry everywhere.  Each is
;; independent, so a project can bring its own dictionary while still using
;; your global rule lists.
;;
;; The project boundary is Emacs' own.  `.dir-locals.el' already decides which
;; files a setting governs, and the per-document handlers answer each pull from
;; the buffer the server named, so a document is checked against exactly the
;; lists that apply to it.  Nothing here needs a notion of "project root".
;;
;; Buffers with no file — `*scratch*', comint input — have no directory-local
;; variables and therefore no project files, so they see the global lists
;; alone.  That is the right answer: they belong to no project.

(defun lsp-ltex-plus--project-file-safe-p (value)
  "Non-nil when VALUE is safe as a directory-local project settings file.
Safe means nil, or a relative name with no `..' component — one that
cannot reach outside the tree its `.dir-locals.el' governs.  This package
creates and writes these files, so a name that could escape that tree is
left for the user to confirm in the usual way.  Modelled on AUCTeX's
`TeX--output-dir-safe-p', which applies the same rule to `TeX-output-dir'
for the same reason."
  (or (null value)
      (and (stringp value)
           (not (file-name-absolute-p value))
           (not (member ".." (split-string value "/" t))))))

(defmacro lsp-ltex-plus--define-project-file (name file description)
  "Define NAME as the project counterpart of a global settings file.
FILE is the suggested basename shown in the docstring and DESCRIPTION
names what the file holds."
  `(defcustom ,name nil
     ,(format "File holding this project's %s, or nil for none.

Set this from a project's `.dir-locals.el' to give the project its own
list, merged with — never replacing — the global one:

  ((nil . ((%s
            . \"%s\"))))

A relative name is resolved against the directory holding the
`.dir-locals.el' that set it, so every file in the project agrees on one
location however deep it sits, and moving the project moves the setting
with it.  An absolute name (or one starting with `~') is used as given,
but is not treated as safe: Emacs will ask before applying it.

The format is the same plist the global files use — language codes as
keyword keys, vectors of strings as values, e.g.

  (:en-US [\"Wittgenstein\"] :de-DE [\"Widerspiegelung\"])"
              description name file)
     :type '(choice (const :tag "None" nil) file)
     :safe #'lsp-ltex-plus--project-file-safe-p
     :group 'lsp-ltex-plus))

(lsp-ltex-plus--define-project-file lsp-ltex-plus-project-dictionary-file
                                    ".ltex/dictionary.eld"
                                    "additional accepted words")
(lsp-ltex-plus--define-project-file lsp-ltex-plus-project-enabled-rules-file
                                    ".ltex/enabled-rules.eld"
                                    "rules to enable")
(lsp-ltex-plus--define-project-file lsp-ltex-plus-project-disabled-rules-file
                                    ".ltex/disabled-rules.eld"
                                    "rules to disable")
(lsp-ltex-plus--define-project-file lsp-ltex-plus-project-hidden-false-positives-file
                                    ".ltex/hidden-false-positives.eld"
                                    "false positives to hide")

(defconst lsp-ltex-plus--setting-kinds
  '((dictionary
     :custom        lsp-ltex-plus-dictionary
     :stored        lsp-ltex-plus--dictionary-stored
     :global-file lsp-ltex-plus-dictionary-file
     :project-file  lsp-ltex-plus-project-dictionary-file
     :command       "_ltex.addToDictionary"
     :argument-key  :words)
    (enabled-rules
     :custom        lsp-ltex-plus-enabled-rules
     :stored        lsp-ltex-plus--enabled-rules-stored
     :global-file lsp-ltex-plus-enabled-rules-file
     :project-file  lsp-ltex-plus-project-enabled-rules-file
     :command       nil
     :argument-key  nil)
    (disabled-rules
     :custom        lsp-ltex-plus-disabled-rules
     :stored        lsp-ltex-plus--disabled-rules-stored
     :global-file lsp-ltex-plus-disabled-rules-file
     :project-file  lsp-ltex-plus-project-disabled-rules-file
     :command       "_ltex.disableRules"
     :argument-key  :ruleIds)
    (hidden-false-positives
     :custom        lsp-ltex-plus-hidden-false-positives
     :stored        lsp-ltex-plus--hidden-false-positives-stored
     :global-file lsp-ltex-plus-hidden-false-positives-file
     :project-file  lsp-ltex-plus-project-hidden-false-positives-file
     :command       "_ltex.hideFalsePositives"
     :argument-key  :falsePositives))
  "The four language-keyed settings, by kind.
Each entry maps a kind to the variables behind it:

  :custom         the defcustom, the user's own list, never written to
  :stored         the in-memory mirror of the global file
  :global-file  the global file under `user-emacs-directory'
  :project-file   the setting naming a project's own file, if it has one
  :command        the server command whose suggestion writes here, or nil
                  for `enabled-rules', which no suggestion writes to
  :argument-key   the key under which that command carries its entries,
                  in a map from language code to entries")

(defun lsp-ltex-plus--kind-get (kind property)
  "Return PROPERTY of KIND from `lsp-ltex-plus--setting-kinds'."
  (plist-get (alist-get kind lsp-ltex-plus--setting-kinds) property))

(defun lsp-ltex-plus--load-external-settings ()
  "Read the four global files from disk into their `-stored' mirrors.
The defcustoms are never touched; the server is shown the merge of a
defcustom and its mirror when it asks."
  (pcase-dolist (`(,kind . ,_) lsp-ltex-plus--setting-kinds)
    (set (lsp-ltex-plus--kind-get kind :stored)
         (lsp-ltex-plus--load-plist
          (symbol-value (lsp-ltex-plus--kind-get kind :global-file)))))
  ;; Project files carry their own modification-time check, so this only
  ;; matters for an edit that left the time untouched — but a reload is
  ;; meant to be the blunt instrument that always works.
  (clrhash lsp-ltex-plus--project-file-cache))

(defun lsp-ltex-plus--kind-for-command (command)
  "Return the settings kind COMMAND writes to, or nil if it writes to none.
COMMAND is a server command name.  A nil COMMAND — an action carrying a
command object with no name, which a malformed server can send — matches
nothing: `enabled-rules\=' has a nil `:command\=' because no suggestion
writes to it, and answering with it here would let this package claim an
action that is not its own."
  (and command
       (car (seq-find (lambda (entry)
                        (equal command (plist-get (cdr entry) :command)))
                      lsp-ltex-plus--setting-kinds))))

(defun lsp-ltex-plus--dir-locals-directory ()
  "Return the directory whose `.dir-locals.el' governs the current buffer.
Falls back to `default-directory' when the buffer has no file or no
directory-local variables apply, which is the sensible base for a value
that was set globally rather than per project."
  (or (when-let* ((file (buffer-file-name))
                  (found (dir-locals-find-file file)))
        ;; `dir-locals-find-file' answers with the directory itself, or with
        ;; (DIR CLASS MTIME) when the entry is already cached.
        (file-name-as-directory (if (consp found) (car found) found)))
      default-directory))

(defun lsp-ltex-plus--project-file (variable)
  "Return the absolute path VARIABLE names for the current buffer, or nil.
VARIABLE is one of the `lsp-ltex-plus-project-*-file' settings; a
relative value resolves against the directory holding the
`.dir-locals.el' that set it."
  (when-let* ((value (symbol-value variable)))
    (expand-file-name value (lsp-ltex-plus--dir-locals-directory))))

(defun lsp-ltex-plus--load-project-plist (path)
  "Return the plist stored at PATH, re-reading it only when it has changed."
  (let ((mtime (file-attribute-modification-time (file-attributes path)))
        (entry (gethash path lsp-ltex-plus--project-file-cache)))
    (if (and entry (equal (car entry) mtime))
        (cdr entry)
      (let ((plist (and mtime (lsp-ltex-plus--load-plist path))))
        (puthash path (cons mtime plist) lsp-ltex-plus--project-file-cache)
        plist))))

(defun lsp-ltex-plus--global-plist (kind)
  "Return KIND's global list: the user's defcustom merged with the file's.
Made when asked rather than cached, so a `setq' of the defcustom is in
force at the next check with nothing to refresh.  KIND is a key of
`lsp-ltex-plus--setting-kinds'."
  (lsp-ltex-plus--merge-plists
   (symbol-value (lsp-ltex-plus--kind-get kind :custom))
   (symbol-value (lsp-ltex-plus--kind-get kind :stored))))

(defun lsp-ltex-plus--effective-plist (kind)
  "Return KIND as the server should see it for the document in this buffer.
The global list, `lsp-ltex-plus--global-plist', extended with this
project's file, if it has one."
  (let ((global (lsp-ltex-plus--global-plist kind))
        (file (lsp-ltex-plus--project-file-for kind)))
    (if file
        (lsp-ltex-plus--merge-plists
         global
         (lsp-ltex-plus--load-project-plist file))
      global)))

(defun lsp-ltex-plus--project-file-for (kind)
  "Return this buffer's project file for KIND, or nil if it has none."
  (lsp-ltex-plus--project-file (lsp-ltex-plus--kind-get kind :project-file)))

;;;; -- Where a suggestion's addition is saved ----------------------------------

;; Accepting a suggestion — a word to accept, a rule to switch off, a false
;; positive to hide — adds an entry to one of the lists.  Reading always
;; merges the global and project lists; this only decides which file a *new*
;; entry is written to.  Being an ordinary setting, it can itself be set from
;; a project's `.dir-locals.el', so one project can depart from the habit you
;; keep everywhere else.

(defun lsp-ltex-plus--save-additions-to-p (value)
  "Non-nil when VALUE is one of the `lsp-ltex-plus-save-additions-to' choices."
  (memq value '(globally-defined per-project-when-specified
                either-allowing-user-choice)))

(defcustom lsp-ltex-plus-save-additions-to 'either-allowing-user-choice
  "Where an addition goes when you accept one of LTeX+'s suggestions.

This never affects what is *read*: a document is always checked against
the union of your own lists and the project's.  It decides only where a
newly accepted word, silenced rule or hidden false positive is written.

  `globally-defined'
      Always your own file under `user-emacs-directory', even in a
      project that keeps its own list.  Choose this to have a project's
      list read but only ever edited by hand.

  `per-project-when-specified'
      The project's file when this project keeps one for that kind of
      entry, and your own file otherwise.  A project that configures
      only a dictionary therefore collects words while your global
      rule choices stay global.  Set this once you know which you
      want and would rather not be asked.

  `either-allowing-user-choice' (default)
      Decide each time.  Where a project keeps its own list, the two
      possibilities appear side by side among the suggestions, one
      saving everywhere and one saving to this project only, and you
      pick as you accept.  The entry is written to one of them, never
      to both.

      This is the default because it is also how the choice announces
      itself: a project that keeps its own lists is one you set up
      deliberately, and seeing both destinations offered is how you
      find out the choice exists.  If you always want the same one,
      say so with one of the two values above -- in your init file, or
      in a single project's `.dir-locals.el' if only that one differs.

Nothing changes for a project that keeps no lists of its own: all three
values then write to your own files, since there is nowhere else to
write."
  :type '(choice (const :tag "Always my own files" globally-defined)
                 (const :tag "This project's files when it has them"
                        per-project-when-specified)
                 (const :tag "Offer both and let me choose each time"
                        either-allowing-user-choice))
  :safe #'lsp-ltex-plus--save-additions-to-p
  :group 'lsp-ltex-plus)

;; Marker carried on the copies of a suggestion that
;; `either-allowing-user-choice' splits in two, naming which file that copy
;; saves to.  It rides on the client-side command object and is never sent
;; anywhere: these commands are handled entirely by this package, the server
;; never receives them back.
(defconst lsp-ltex-plus--target-marker :ltexPlusSaveTo)

(defun lsp-ltex-plus--addition-target (kind command)
  "Return `project' or `global': where KIND's addition from COMMAND goes.
A COMMAND carrying the marker left by `lsp-ltex-plus--split-suggestion'
says so itself; otherwise `lsp-ltex-plus-save-additions-to' decides.
Falls back to `global' whenever the project offers no file for KIND,
so a suggestion is never a dead end."
  (let ((marker (and command (plist-get command lsp-ltex-plus--target-marker)))
        (project (lsp-ltex-plus--project-file-for kind)))
    (cond
     ((not project) 'global)
     ((equal marker "project") 'project)
     ((equal marker "global") 'global)
     ((eq lsp-ltex-plus-save-additions-to 'globally-defined) 'global)
     ((eq lsp-ltex-plus-save-additions-to 'per-project-when-specified) 'project)
     ;; `either-allowing-user-choice' with no marker: the suggestion was not
     ;; split (or arrived from elsewhere), so keep the conservative file.
     (t 'global))))

(defun lsp-ltex-plus--save-addition (kind lang items command)
  "Add ITEMS for LANG to KIND's list, in the file COMMAND's target names.
Writing to the global file goes through the `-stored' mirror.  Writing
to a project file updates the file and refreshes its cache entry, so the
next check sees the new entry without waiting for a modification-time
comparison."
  (if (eq (lsp-ltex-plus--addition-target kind command) 'project)
      (let* ((path (lsp-ltex-plus--project-file-for kind))
             (key (intern (concat ":" lang)))
             (merged (lsp-ltex-plus--merge-plists
                      (lsp-ltex-plus--load-project-plist path)
                      (list key (vconcat items)))))
        (lsp-ltex-plus--log "Saving %s for %s to project file %s" items lang path)
        (lsp-ltex-plus--save-plist merged path)
        (puthash path
                 (cons (file-attribute-modification-time (file-attributes path))
                       merged)
                 lsp-ltex-plus--project-file-cache))
    (lsp-ltex-plus--add-to-plist (lsp-ltex-plus--kind-get kind :stored)
                                 (symbol-value (lsp-ltex-plus--kind-get kind :global-file))
                                 lang items)))

;;;; -- Values handed to the server ---------------------------------------------

;; The two pieces of the configuration replies that are pure functions of the
;; settings above.  They live here, beside the lists they read, so that the
;; client layer that answers the server has nothing of its own to say about
;; which words a document is checked against.

(defun lsp-ltex-plus--mode-entry (mode)
  "Return the `lsp-ltex-plus-major-modes' entry that applies to MODE.
MODE itself when it is listed, otherwise its *nearest* listed ancestor,
otherwise nil.  The chain is walked from MODE outwards, one
`derived-mode-parent' at a time, rather than the table being scanned for
something MODE derives from: `org-mode' derives from `text-mode', and both
are listed, so a scan would answer with whichever the table happens to
name first -- the alphabet deciding what a document is written in.

This says what a buffer is, never whether it is checked.  Activation is
the dispatcher's exact `memq' against `lsp-ltex-plus--enabled-modes', so a
derived mode is still only ever checked when the user lists it, calls
`lsp-ltex-plus-mode' by name, or is in a buffer this package made itself."
  (or (assq mode lsp-ltex-plus-major-modes)
      (let ((parent (get mode 'derived-mode-parent)))
        (and parent (lsp-ltex-plus--mode-entry parent)))))

(defun lsp-ltex-plus--language-id (&optional buffer)
  "Return the LSP language id for BUFFER (default the current buffer).
Read from `lsp-ltex-plus-major-modes' through `lsp-ltex-plus--mode-entry',
so a mode derived from a listed one is sent under its parent's id; a mode
with no listed ancestor is sent as plain text, which the server checks as
prose."
  (or (cadr (lsp-ltex-plus--mode-entry
             (buffer-local-value 'major-mode (or buffer (current-buffer)))))
      "plaintext"))

(defun lsp-ltex-plus--workspace-specific-entry ()
  "Return the language-keyed settings for the document in the current buffer.

The four fields are JSON objects per VS Code's TS type
`LanguageSpecificSettingValue' — never nullable.  `lsp-ltex-plus--obj-or-empty'
substitutes the shared empty hash-table for nil so `json-serialize' emits
`{}' rather than `null'; see that helper's docstring for the underlying
ambiguity.

Each value comes from `lsp-ltex-plus--effective-plist', so a project that
sets any of the `lsp-ltex-plus-project-*-file' settings has its own lists
folded in on top of the global ones."
  (list :dictionary           (lsp-ltex-plus--obj-or-empty (lsp-ltex-plus--effective-plist 'dictionary))
        :disabledRules        (lsp-ltex-plus--obj-or-empty (lsp-ltex-plus--effective-plist 'disabled-rules))
        :enabledRules         (lsp-ltex-plus--obj-or-empty (lsp-ltex-plus--effective-plist 'enabled-rules))
        :hiddenFalsePositives (lsp-ltex-plus--obj-or-empty (lsp-ltex-plus--effective-plist 'hidden-false-positives))))

(defun lsp-ltex-plus--settings-object ()
  "Return the `ltex' settings object, read in the current buffer.
The nested object the server expects under the `ltex' section, built
straight from the defcustoms so that a buffer-local or directory-local
value is what goes out when this is called in the document's buffer.

Every JSON type is made explicit at this boundary: an unset string is
sent as \"\", a boolean as true or false rather than null, and an empty
object as `{}'.

Only what the server reads is here (checked against its source, 18.7.0).
The four language-keyed lists are absent: once the client has advertised
the custom capability the server takes them from
`ltex/workspaceSpecificConfiguration' alone, see
`lsp-ltex-plus--workspace-specific-entry'.  The executable's path, the
Java path and heap sizes, and the trace level are the client's own
business -- the launcher and the `initialize' request see them -- and
the server would drop them unread."
  ;; `enabled' is the server's own filter: it silently skips a document
  ;; whose language id is not in the set, and its default set holds no
  ;; programming language.  Which buffers are checked is decided on this
  ;; side, so the answer for a document is simply that document's id:
  ;; the client opened it, it is enabled.  Read in the document's buffer,
  ;; as every pull is; the global push, read in none, says plain text,
  ;; which the server never skips and nothing is checked against.
  (list :enabled (vector (lsp-ltex-plus--language-id))
        :language lsp-ltex-plus-language
        :bibtex (list :fields (lsp-ltex-plus--obj-or-empty lsp-ltex-plus-bibtex-fields))
        :latex (list :commands (lsp-ltex-plus--obj-or-empty lsp-ltex-plus-latex-commands)
                     :environments (lsp-ltex-plus--obj-or-empty lsp-ltex-plus-latex-environments))
        :markdown (list :nodes (lsp-ltex-plus--obj-or-empty lsp-ltex-plus-markdown-nodes))
        :additionalRules (list :enablePickyRules (lsp-ltex-plus--bool
                                                  lsp-ltex-plus-additional-rules-enable-picky-rules)
                               :motherTongue (lsp-ltex-plus--str
                                              lsp-ltex-plus-additional-rules-mother-tongue)
                               :languageModel (lsp-ltex-plus--str
                                               lsp-ltex-plus-additional-rules-language-model))
        :languageToolHttpServerUri (lsp-ltex-plus--str lsp-ltex-plus-lt-server-uri)
        ;; `languageToolOrg.apiKey' is the key the server reads first; the
        ;; `ltex-ls.languageToolOrgApiKey' this client sent up to 1.0.0 has
        ;; been the deprecated fallback since server 14.1.0.
        :languageToolOrg (list :username (lsp-ltex-plus--str lsp-ltex-plus-lt-username)
                               :apiKey (lsp-ltex-plus--str lsp-ltex-plus-lt-api-key))
        :ltex-ls (list :logLevel lsp-ltex-plus-ltex-ls-log-level)
        :sentenceCacheSize lsp-ltex-plus-sentence-cache-size
        :maxRequestSize lsp-ltex-plus-max-request-size
        :paragraphCacheTtlMinutes lsp-ltex-plus-paragraph-cache-ttl-minutes
        :paragraphCacheEnabled (lsp-ltex-plus--bool lsp-ltex-plus-paragraph-cache-enabled)
        :completionEnabled (lsp-ltex-plus--bool lsp-ltex-plus-completion-enabled)
        :diagnosticSeverity lsp-ltex-plus-diagnostic-severity
        :checkFrequency lsp-ltex-plus-check-frequency
        :clearDiagnosticsWhenClosingFile (lsp-ltex-plus--bool
                                          lsp-ltex-plus-clear-diagnostics-when-closing-file)))

(provide 'lsp-ltex-plus-settings)
;;; lsp-ltex-plus-settings.el ends here
