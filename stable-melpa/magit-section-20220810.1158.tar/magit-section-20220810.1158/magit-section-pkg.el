(define-package "magit-section" "20220810.1158" "Sections for read-only buffers."
  '((emacs "25.1")
    (compat "28.1.1.2")
    (dash "20210826"))
  :commit "1bb0d5a503a01abf754eb49f4074b245aa5023ab" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
