(define-package "bibtex-actions" "20210808.2133" "Biblographic commands based on completing-read"
  '((emacs "26.3")
    (bibtex-completion "1.0"))
  :commit "12d81ac5dadcddc51569efc6ac87739214370129" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/bibtex-actions")
;; Local Variables:
;; no-byte-compile: t
;; End:
