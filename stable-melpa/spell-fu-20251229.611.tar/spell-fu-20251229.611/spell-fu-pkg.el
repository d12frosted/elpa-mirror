;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spell-fu" "20251229.611"
  "Fast & light spelling highlighter."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spell-fu"
  :commit "ab256835ea9d2c2fe346d0386c7b3acf2700f335"
  :revdesc "ab256835ea9d"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
