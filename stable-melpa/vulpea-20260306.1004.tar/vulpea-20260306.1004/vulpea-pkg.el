;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260306.1004"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "e2330e8ff04590913570773ddcb87355427ffbb7"
  :revdesc "e2330e8ff045"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
