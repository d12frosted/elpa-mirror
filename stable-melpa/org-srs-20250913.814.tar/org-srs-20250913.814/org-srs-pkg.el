;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20250913.814"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "1bc391a109baec68a79a0f64cd69a79bd34778e1"
  :revdesc "1bc391a109ba"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
