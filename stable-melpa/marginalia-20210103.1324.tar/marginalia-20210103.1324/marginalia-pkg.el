(define-package "marginalia" "20210103.1324" "Enrich existing commands with completion annotations"
  '((emacs "26.1"))
  :commit "51b6dbf61f0ed65689e0685da6ab0b59d0220b58" :authors
  (("Omar Antolín Camarena, Daniel Mendler"))
  :maintainer
  ("Omar Antolín Camarena, Daniel Mendler")
  :url "https://github.com/minad/marginalia")
;; Local Variables:
;; no-byte-compile: t
;; End:
