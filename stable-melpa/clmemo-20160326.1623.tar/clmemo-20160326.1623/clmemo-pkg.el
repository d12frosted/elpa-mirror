(define-package "clmemo" "20160326.1623" "Change Log MEMO" 'nil :commit "846a81b984d71edf8278a4d9f9b886e44d5b8365" :keywords
  ("convenience")
  :authors
  (("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainer
  ("Masayuki Ataka" . "masayuki.ataka@gmail.com")
  :url "https://github.com/ataka/clmemo")
;; Local Variables:
;; no-byte-compile: t
;; End:
