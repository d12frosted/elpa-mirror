;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260504.850"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "105353a9dd0234b6d9badfa78d9cff5b19f594f6"
  :revdesc "105353a9dd02"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
