;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260210.2341"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "4fef5ad244862ab88f80795eefd10e7ae08989e9"
  :revdesc "4fef5ad24486"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
