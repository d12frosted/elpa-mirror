(define-package "emr" "20210110.1928" "Emacs refactoring system."
  '((s "1.3.1")
    (dash "1.2.0")
    (cl-lib "0.2")
    (popup "0.5.0")
    (emacs "24.1")
    (list-utils "0.3.0")
    (paredit "24.0.0")
    (projectile "0.9.1")
    (clang-format "0.0.1")
    (iedit "0.97"))
  :commit "d0540df81c1b5f9f75f69ff92331bbf4b16f2e2c" :authors
  '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainer
  '("Chris Barrett" . "chris.d.barrett@me.com")
  :keywords
  '("tools" "convenience" "refactoring")
  :url "https://github.com/Wilfred/emacs-refactor")
;; Local Variables:
;; no-byte-compile: t
;; End:
