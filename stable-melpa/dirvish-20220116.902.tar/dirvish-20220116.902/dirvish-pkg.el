(define-package "dirvish" "20220116.902" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "9ab1d7da2d26701da8fe723ea52c9747b5b27e18" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
