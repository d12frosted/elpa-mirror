(define-package "consult" "20220503.2229" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "ea30b4dc8b25b65082ab9a2d56d2c6035d63b31e" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
