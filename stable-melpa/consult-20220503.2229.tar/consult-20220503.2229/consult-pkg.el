(define-package "consult" "20220503.2229" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "822928a8609730e8c22e068b04d7908312706cfd" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
