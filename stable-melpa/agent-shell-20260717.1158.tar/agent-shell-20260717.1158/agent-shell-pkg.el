;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260717.1158"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0b65bb4b39b0caad954d470de79aef687b73dc7d"
  :revdesc "0b65bb4b39b0")
