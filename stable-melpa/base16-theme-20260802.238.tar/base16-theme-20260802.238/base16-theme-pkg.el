;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260802.238"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "53a8b553b364964ffb97c5f84de34f01e4d5b2eb"
  :revdesc "53a8b553b364"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
