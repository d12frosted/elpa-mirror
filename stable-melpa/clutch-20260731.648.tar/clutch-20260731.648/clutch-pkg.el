;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260731.648"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "d26c7d330e6aa43094651e2af62dc11015d32882"
  :revdesc "d26c7d330e6a"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
