;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250623.1634"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "711e81da4b9a344076a6c3b45577a17f0628a760"
  :revdesc "711e81da4b9a"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
