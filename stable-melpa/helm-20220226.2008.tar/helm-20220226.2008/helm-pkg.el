(define-package "helm" "20220226.2008" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.4")
    (popup "0.5.3"))
  :commit "e4fe41bbca936ca43a51103626fe33e87a47b0f6" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
