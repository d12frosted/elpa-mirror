;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "20261109.228"
  "Reveal Markdown source at point."
  '((emacs "31.1"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "39cc0f95f1f32d85acd7e4887539bb2ea0f3590f"
  :revdesc "39cc0f95f1f3"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
