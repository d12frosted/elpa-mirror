;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-accent-mode" "20261109.1356"
  "Accent Selected Window."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/selected-window-accent-mode"
  :commit "3f6e32a8593d5306e124b5ee914d33276dcb51f5"
  :revdesc "3f6e32a8593d"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
