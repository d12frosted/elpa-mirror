;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20251121.2150"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "9b0a3e60e9dac97fcb0a3a937d4c1f0c637e15b8"
  :revdesc "9b0a3e60e9da"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
