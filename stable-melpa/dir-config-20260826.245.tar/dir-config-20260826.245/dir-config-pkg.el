;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "20260826.245"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "08aed2f99b1d9670bc9d4e7a5b3ffded4d7dfe3b"
  :revdesc "08aed2f99b1d"
  :keywords '("convenience" "files" "lisp")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
