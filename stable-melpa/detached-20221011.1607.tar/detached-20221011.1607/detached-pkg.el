(define-package "detached" "20221011.1607" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "4e7cff1163b1485295f549c0d1ae9cf49d126967" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
