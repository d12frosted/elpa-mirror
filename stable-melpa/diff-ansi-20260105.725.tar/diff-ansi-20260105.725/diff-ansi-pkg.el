;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "20260105.725"
  "Display diffs using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "96ce9486c1b6e507d3c5dd64383211366c7909cd"
  :revdesc "96ce9486c1b6"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
