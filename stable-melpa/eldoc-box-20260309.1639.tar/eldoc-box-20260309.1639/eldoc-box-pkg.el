;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-box" "20260309.1639"
  "Display documentation in childframe."
  '((emacs "27.1"))
  :url "https://github.com/casouri/eldoc-box"
  :commit "8847b1aac2133e8a8211e728807fdd20d332298c"
  :revdesc "8847b1aac213"
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
