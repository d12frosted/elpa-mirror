;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20251122.58"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "f0d227bec906b00cfc88eeb87b184c2a5827798f"
  :revdesc "f0d227bec906"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
