;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-browse-url-in-article" "20260503.1942"
  "Smarter browse-url for Gnus articles."
  '((emacs "27.1"))
  :url "https://github.com/jmibanez/gnus-browse-url-in-article"
  :commit "dd6655cb758054c03d8e62f3d60b587e88f48c22"
  :revdesc "dd6655cb7580"
  :keywords '("convenience" "mail" "gnus")
  :authors '(("JM Ibañez" . "jm@jmibanez.com"))
  :maintainers '(("JM Ibañez" . "jm@jmibanez.com")))
