(define-package "languagetool" "20230122.121" "LanguageTool integration for grammar and spell check"
  '((emacs "27.0"))
  :commit "57af28a0c370866945988461a259b6551a1c4074" :authors
  '(("Joar Buitrago" . "jebuitragoc@unal.edu.co"))
  :maintainer
  '("Joar Buitrago" . "jebuitragoc@unal.edu.co")
  :keywords
  '("grammar" "text" "docs" "tools" "convenience" "checker")
  :url "https://github.com/PillFall/Emacs-LanguageTool.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
