;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260327.2139"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "37713ddf484ae3e01ad0b435a8edbe0f33237eb8"
  :revdesc "37713ddf484a"
  :keywords '("languages" "lisp" "slime"))
