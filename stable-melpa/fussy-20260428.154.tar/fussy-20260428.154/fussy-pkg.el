;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260428.154"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "a5a7aed4f05bd9cb56216bfde2c5d86c06b5505d"
  :revdesc "a5a7aed4f05b"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
