;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260318.224"
  "A q editing mode."
  '((emacs "24"))
  :url "https://github.com/psaris/q-mode"
  :commit "5fe6f9854d1c2bf34bd649a3703e4dd0c79d8ede"
  :revdesc "5fe6f9854d1c"
  :keywords '("faces" "files" "q"))
