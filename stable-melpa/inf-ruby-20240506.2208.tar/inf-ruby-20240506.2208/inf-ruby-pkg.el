(define-package "inf-ruby" "20240506.2208" "Run a Ruby process in a buffer"
  '((emacs "26.1"))
  :commit "37f4ec0f021c4ed5909f4b72a05b0927ee4876d4" :authors
  '(("Yukihiro Matsumoto")
    ("Nobuyoshi Nakada")
    ("Cornelius Mika" . "cornelius.mika@gmail.com")
    ("Dmitry Gutov" . "dgutov@yandex.ru")
    ("Kyle Hargraves" . "pd@krh.me"))
  :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("languages" "ruby")
  :url "http://github.com/nonsequitur/inf-ruby")
;; Local Variables:
;; no-byte-compile: t
;; End:
