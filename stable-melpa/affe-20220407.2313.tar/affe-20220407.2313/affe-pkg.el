(define-package "affe" "20220407.2313" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.16"))
  :commit "a61d593d0cbff65a93111be96b9f53d3e640cf8d" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
