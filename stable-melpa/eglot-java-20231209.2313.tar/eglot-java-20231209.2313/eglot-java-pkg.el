(define-package "eglot-java" "20231209.2313" "Java extension for the eglot LSP client"
  '((emacs "26.1")
    (eglot "1.0")
    (jsonrpc "1.0.0"))
  :commit "f85818a978c47020bd65e4c1924d324fa62bb2f3" :authors
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainers
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainer
  '("Yves Zoundi" . "yves_zoundi@hotmail.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/yveszoundi/eglot-java")
;; Local Variables:
;; no-byte-compile: t
;; End:
