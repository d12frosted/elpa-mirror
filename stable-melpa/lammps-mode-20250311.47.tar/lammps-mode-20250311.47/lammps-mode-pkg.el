;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lammps-mode" "20250311.47"
  "Basic syntax highlighting for LAMMPS files."
  '((emacs "24.4"))
  :url "https://github.com/lammps/lammps/tree/master/tools/emacs"
  :commit "92d262c755c3aedf02bbe19743ba761ccdc7c0c2"
  :revdesc "92d262c755c3"
  :keywords '("languages" "faces")
  :authors '(("Aidan Thompson" . "athompsatsandia.gov"))
  :maintainers '(("Rohit Goswami" . "r95g10atgmail.com")))
