;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ext" "20260225.1300"
  "SystemVerilog Extensions."
  '((emacs           "29.1")
    (verilog-mode    "2024.3.1.121933719")
    (verilog-ts-mode "0.5.0")
    (lsp-mode        "8.0.0")
    (ag              "0.48")
    (ripgrep         "0.4.0")
    (hydra           "0.15.0")
    (apheleia        "3.1")
    (yasnippet       "0.14.0")
    (flycheck        "32")
    (async           "1.9.7"))
  :url "https://github.com/gmlarumbe/verilog-ext"
  :commit "e2217561bc6ee84b4e925951ef3794957048bf73"
  :revdesc "e2217561bc6e"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
