(define-package "loopy" "20210731.1953" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "976723ed521a4c7afb14d8f5fca3fa087dff3e4c" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
