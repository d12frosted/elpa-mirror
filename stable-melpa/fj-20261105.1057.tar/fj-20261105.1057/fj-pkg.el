;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20261105.1057"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.5")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "9217d66c5fc796d607fa492d1528b338252e0023"
  :revdesc "9217d66c5fc7"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
