;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-autotask" "20261109.1551"
  "Email automation for mu4e."
  '((emacs "29.1"))
  :url "https://github.com/laurynas-biveinis/mu4e-autotask"
  :commit "d3ab4662bcba4f12cc384c1ffa86da21cedfb031"
  :revdesc "d3ab4662bcba"
  :keywords '("mail")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
