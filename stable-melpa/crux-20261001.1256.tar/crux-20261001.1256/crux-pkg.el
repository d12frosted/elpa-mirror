;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crux" "20261001.1256"
  "A Collection of Ridiculously Useful eXtensions."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/crux"
  :commit "3298e8db6d5346f78c9408df8b869636faf1d990"
  :revdesc "3298e8db6d53"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
