;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-helm" "20160319.233"
  "Helm interface for auto-complete."
  '((helm          "1.6.3")
    (auto-complete "1.4.0")
    (popup         "0.5.0")
    (cl-lib        "0.5"))
  :url "https://github.com/yasuyk/ac-helm"
  :commit "baf2b1e04bcffa835084389c0fab415f26efbf32"
  :revdesc "baf2b1e04bcf"
  :keywords '("completion" "convenience" "helm")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org")
             ("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
