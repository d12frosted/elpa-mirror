;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-ascii-plot" "20260122.1125"
  "Unicode-art bar plots in org-mode tables."
  ()
  :url "https://github.com/tbanel/orgtblasciiplot"
  :commit "b4e5098ec0ab21e175ca86bbf4853a53ab08f844"
  :revdesc "b4e5098ec0ab"
  :keywords '("org" "table" "ascii" "plot"))
