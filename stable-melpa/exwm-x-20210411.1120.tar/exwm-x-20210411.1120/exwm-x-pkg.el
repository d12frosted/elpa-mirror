(define-package "exwm-x" "20210411.1120" "A derivative wm based on EXWM (emacs x window manager)"
  '((cl-lib "0.5")
    (async "1.6")
    (exwm "0.22")
    (switch-window "0.10")
    (swiper "0.9.0")
    (bind-key "1.0")
    (counsel "0.9.0")
    (ivy "0.9.0"))
  :commit "7bc7a930998117a714cf1f2940dcab12bcac9b73" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("window-manager" "exwm")
  :url "https://github.com/tumashu/exwm-x")
;; Local Variables:
;; no-byte-compile: t
;; End:
