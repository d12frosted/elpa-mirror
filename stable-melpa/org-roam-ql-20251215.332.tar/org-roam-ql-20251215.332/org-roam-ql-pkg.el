;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "20251215.332"
  "Interface to query and view results from org-roam."
  '((emacs            "28")
    (org-roam         "2.2.0")
    (s                "1.12.0")
    (magit-section    "3.3.0")
    (transient        "0.4")
    (org-super-agenda "1.2")
    (dash             "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "104a5f915bcb402501063ae28bcd2b95bbf93e2c"
  :revdesc "104a5f915bcb")
