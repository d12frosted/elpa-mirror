;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flx-isearch" "20191119.515"
  "Fuzzy incremental searching for emacs."
  '((emacs  "24")
    (flx    "20140821")
    (cl-lib "0.5"))
  :url "https://github.com/pythonnut/flx-isearch"
  :commit "a44097fb8f539a193c2f09a37ea52a68f2c51839"
  :revdesc "a44097fb8f53"
  :keywords '("convenience" "search" "flx")
  :authors '(("PythonNut" . "pythonnut@pythonnut.com"))
  :maintainers '(("PythonNut" . "pythonnut@pythonnut.com")))
