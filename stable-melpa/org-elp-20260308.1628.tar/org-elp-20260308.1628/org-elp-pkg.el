;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-elp" "20260308.1628"
  "Preview latex equations in org mode while editing."
  '((emacs "27.1"))
  :url "https://github.com/guanyilun/org-elp"
  :commit "4a80371945c529a8765552cb589720518d2e3c3b"
  :revdesc "4a80371945c5"
  :keywords '("lisp" "tex" "org"))
