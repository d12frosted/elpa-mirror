;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260309.6"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "3ddf5d39a76416aa46b95c1d207b117f91e400d1"
  :revdesc "3ddf5d39a764"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
