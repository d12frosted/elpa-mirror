(define-package "vhdl-ext" "20230906.2221" "VHDL Extensions"
  '((emacs "29.1")
    (vhdl-ts-mode "0.0.0")
    (eglot "1.9")
    (lsp-mode "8.0.1")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "33snapshot")
    (company "0.9.13")
    (outshine "3.1pre")
    (async "1.9.7"))
  :commit "95e5fe68ab1a40d60f6b4e15b1ec0c02d8f31555" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
