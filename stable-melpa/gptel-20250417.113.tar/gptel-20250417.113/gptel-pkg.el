;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250417.113"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "8e20fae2ce03bc12d9ad2dcf695b16bb2c2cd9e7"
  :revdesc "8e20fae2ce03"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
