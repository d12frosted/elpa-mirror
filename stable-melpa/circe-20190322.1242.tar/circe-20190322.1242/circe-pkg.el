(define-package "circe" "20190322.1242" "Client for IRC in Emacs"
  '((cl-lib "0.5"))
  :commit "6ccd4b494cbae9d28091217654f052eaea321007" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :keywords
  '("irc" "chat")
  :url "https://github.com/jorgenschaefer/circe")
;; Local Variables:
;; no-byte-compile: t
;; End:
