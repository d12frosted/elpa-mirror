(define-package "magit-section" "20210615.1036" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210330"))
  :commit "341e3c8995fc445694f31c96ec113b63dc488b17" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
