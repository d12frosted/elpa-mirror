(define-package "spdx" "20230926.100" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "6e1ee06915bcc1728ea1d841f6c592b100482d08" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
