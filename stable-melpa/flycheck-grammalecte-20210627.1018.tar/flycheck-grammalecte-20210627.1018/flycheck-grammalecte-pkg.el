(define-package "flycheck-grammalecte" "20210627.1018" "Integrate Grammalecte with Flycheck"
  '((emacs "26.1")
    (flycheck "26"))
  :commit "fab1b5071b7fe7a34869ffb8672abad38948c047" :authors
  '(("Guilhem Doulcier" . "guilhem.doulcier@espci.fr")
    ("Étienne Deparis" . "etienne@depar.is"))
  :maintainer
  '("Étienne Deparis" . "etienne@depar.is")
  :keywords
  '("i18n" "text")
  :url "https://git.umaneti.net/flycheck-grammalecte/")
;; Local Variables:
;; no-byte-compile: t
;; End:
