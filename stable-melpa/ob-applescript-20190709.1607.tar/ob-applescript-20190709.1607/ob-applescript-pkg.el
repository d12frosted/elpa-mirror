;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-applescript" "20190709.1607"
  "Org-babel functions for AppleScript."
  ()
  :url "https://github.com/stig/ob-applescript.el"
  :commit "2b07b77b75bd02f2102f62e6d52ffdd0f921439a"
  :revdesc "2b07b77b75bd"
  :keywords '("literate programming" "reproducible research" "mac"))
