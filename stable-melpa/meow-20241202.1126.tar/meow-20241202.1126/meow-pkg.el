;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241202.1126"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "1f8fccab8c1f7533fdbd0cc11c8a6e9f887b9811"
  :revdesc "1f8fccab8c1f"
  :keywords '("convenience" "modal-editing"))
