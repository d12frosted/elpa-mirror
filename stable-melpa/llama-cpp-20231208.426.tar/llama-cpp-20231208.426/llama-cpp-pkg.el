(define-package "llama-cpp" "20231208.426" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "4ca0eb54d7555ee47fd0c8080e0ac9bba1630a34" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
