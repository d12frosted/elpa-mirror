;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "current-word-highlight" "20210323.1401"
  "Highlight the current word minor mode."
  ()
  :url "https://github.com/kijimaD/current-word-highlight"
  :commit "d860f4e170ffa4cef840da93647f458cc409d554"
  :revdesc "d860f4e170ff"
  :keywords '("highlight" "face" "convenience" "word")
  :authors '(("Kijima Daigo" . "norimaking777@gmail.com"))
  :maintainers '(("Kijima Daigo" . "norimaking777@gmail.com")))
