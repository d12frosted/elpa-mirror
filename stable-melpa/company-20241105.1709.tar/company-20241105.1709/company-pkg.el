;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20241105.1709"
  "Modular text completion framework."
  '((emacs "25.1"))
  :url "https://github.com/company-mode/company-mode"
  :commit "e8a9d38e5332912433712947bab28af5adb27d7c"
  :revdesc "e8a9d38e5332"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
