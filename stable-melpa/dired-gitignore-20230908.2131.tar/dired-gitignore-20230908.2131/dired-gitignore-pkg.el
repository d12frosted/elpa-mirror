(define-package "dired-gitignore" "20230908.2131" "A minor mode to hide gitignored files in a dired buffer"
  '((emacs "27.1"))
  :commit "30b458d16bb89cc292648c27def812eb17050876" :authors
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainer
  '("Johannes Mueller" . "github@johannes-mueller.org")
  :keywords
  '("dired" "convenience" "git")
  :url "https://github.com/johannes-mueller/dired-gitignore.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
