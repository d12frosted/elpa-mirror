;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260330.745"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "7a60cba3f26681c4c57ebb79593ff9a8d587db5c"
  :revdesc "7a60cba3f266"
  :keywords '("data" "extensions"))
