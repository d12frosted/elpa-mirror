(define-package "nix-mode" "20221030.2329" "Major mode for editing .nix files"
  '((emacs "25.1")
    (magit-section "0")
    (transient "0.3"))
  :commit "5efb5383aba571a35e59660f68bad02ec70fdd98" :maintainer
  '("Matthew Bauer" . "mjbauer95@gmail.com")
  :keywords
  '("nix" "languages" "tools" "unix")
  :url "https://github.com/NixOS/nix-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
