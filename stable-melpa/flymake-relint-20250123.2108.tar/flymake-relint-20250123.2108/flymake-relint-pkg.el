;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-relint" "20250123.2108"
  "A relint Flymake backend."
  '((emacs  "26.1")
    (relint "1.23"))
  :url "https://github.com/eki3z/flymake-relint"
  :commit "7fd3dabe4fdc258aaf18abbe70e46f49f2fe6b69"
  :revdesc "7fd3dabe4fdc"
  :keywords '("lisp")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
