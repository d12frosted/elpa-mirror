(define-package "docstr" "20220616.1838" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "e63373e8af519823f366aadbdd1521b2408206b7" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("document" "string")
  :url "https://github.com/emacs-vs/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
