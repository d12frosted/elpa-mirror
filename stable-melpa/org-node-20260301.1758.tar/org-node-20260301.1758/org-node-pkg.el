;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260301.1758"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.32.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "aa775a91ad0f3cad913be79d7854f3a714375b5b"
  :revdesc "aa775a91ad0f"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
