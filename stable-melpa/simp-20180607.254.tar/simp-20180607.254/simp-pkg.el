(define-package "simp" "20180607.254" "Simple project definition, chiefly for file finding, and grepping" 'nil :commit "d4d4b8547055347828bedccbeffdb4fd2d5a5d34" :keywords
  ("project" "grep" "find")
  :authors
  (("atom smith"))
  :maintainer
  ("atom smith")
  :url "https://github.com/re5et/simp")
;; Local Variables:
;; no-byte-compile: t
;; End:
