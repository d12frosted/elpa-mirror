(define-package "simp" "20180607.254" "Simple project definition, chiefly for file finding, and grepping" 'nil :commit "d4d4b8547055347828bedccbeffdb4fd2d5a5d34" :authors
  '(("atom smith"))
  :maintainer
  '("atom smith")
  :keywords
  '("project" "grep" "find")
  :url "https://github.com/re5et/simp")
;; Local Variables:
;; no-byte-compile: t
;; End:
