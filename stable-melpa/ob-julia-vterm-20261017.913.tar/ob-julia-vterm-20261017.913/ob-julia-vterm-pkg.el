;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-julia-vterm" "20261017.913"
  "Babel functions for Julia that work with julia-vterm."
  '((emacs       "26.1")
    (julia-vterm "0.26")
    (queue       "0.2"))
  :url "https://github.com/shg/ob-julia-vterm.el"
  :commit "2fa1a512b0291b6e1ea5c38818242ba5d450da0f"
  :revdesc "2fa1a512b029"
  :keywords '("julia" "org" "outlines" "literate programming" "reproducible research"))
