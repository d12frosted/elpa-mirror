(define-package "racket-mode" "20211223.1535" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "25247b6af039b6029ee89d77c50720666025a8cb" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
