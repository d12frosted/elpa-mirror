(define-package "helm-core" "20210504.1723" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "0efdfd24845a679e43fc42c8f68ae4c2a0730bc0")
;; Local Variables:
;; no-byte-compile: t
;; End:
