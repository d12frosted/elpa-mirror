(define-package "consult" "20220926.2046" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "2105d0bbace14f22a9e1864920af84e5f9c454d9" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
