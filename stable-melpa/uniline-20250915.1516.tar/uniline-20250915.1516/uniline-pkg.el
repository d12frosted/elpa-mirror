;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250915.1516"
  "Add▶ ╭╴UNICODE based diagrams╶╮ to→ ╭╴text files╶╮."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "5bbd3c3619f43bc8c7a6f023ede312d409abe3e5"
  :revdesc "5bbd3c3619f4"
  :keywords '("convenience" "text"))
