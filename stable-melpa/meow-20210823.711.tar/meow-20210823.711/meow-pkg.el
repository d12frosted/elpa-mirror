(define-package "meow" "20210823.711" "Modal Editing On Wheel"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1")
    (s "1.12.0"))
  :commit "8d11a4f83008d2ff133971d3c6eca31e391ae416" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
