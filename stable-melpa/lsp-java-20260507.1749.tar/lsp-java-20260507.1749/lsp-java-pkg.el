;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-java" "20260507.1749"
  "Java support for lsp-mode."
  '((emacs         "29.1")
    (lsp-mode      "6.0")
    (markdown-mode "2.3")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.0")
    (request       "0.3.0")
    (treemacs      "2.5")
    (dap-mode      "0.5"))
  :url "https://github.com/emacs-lsp/lsp-java"
  :commit "6e65d51c9a6759108b6751eef3a3d8e02bb74a9c"
  :revdesc "6e65d51c9a67"
  :keywords '("languague" "tools"))
