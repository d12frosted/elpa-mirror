(define-package "flymake-flycheck" "20230824.531" "Use flycheck checkers as flymake backends"
  '((flycheck "31")
    (emacs "26.1"))
  :commit "f124ecc2c35c7d1257aa842ea74ac7e4a568f697" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://github.com/purcell/flymake-flycheck")
;; Local Variables:
;; no-byte-compile: t
;; End:
