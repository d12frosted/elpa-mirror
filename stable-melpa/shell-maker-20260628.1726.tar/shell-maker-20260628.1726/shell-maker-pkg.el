;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260628.1726"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "83f3712d3d7c54f81ee73cc88abaff46410489db"
  :revdesc "83f3712d3d7c")
