;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260816.2109"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "8809cd88d3bb0add97eb37e5f9194c388f511ff8"
  :revdesc "8809cd88d3bb"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
