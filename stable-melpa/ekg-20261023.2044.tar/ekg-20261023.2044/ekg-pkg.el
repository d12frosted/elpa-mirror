;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261023.2044"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "5240155fb7efc3c8f7cdc7a1678a604198711248"
  :revdesc "5240155fb7ef"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
