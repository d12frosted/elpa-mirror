;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250618.116"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "098de7c9a265cfed9dab5858b90d0b29a01163ed"
  :revdesc "098de7c9a265"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
