(define-package "helm" "20240328.743" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.7")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "d22d3db849d3e457f18d9ff2f9e98b33bf29261d" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
