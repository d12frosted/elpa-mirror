;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260216.1807"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "4b3ca9ce8375191bd93308d2a75e1d0e9a5ee32b"
  :revdesc "4b3ca9ce8375"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
