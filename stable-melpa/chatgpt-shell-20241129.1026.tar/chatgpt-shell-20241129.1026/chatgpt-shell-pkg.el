;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241129.1026"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini, Ollama) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.72.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "f4229cbbd68ec5525eaf6bab59cf8f209b654d58"
  :revdesc "f4229cbbd68e")
