(define-package "easy-hugo" "20230314.2207" "Write blogs made with hugo by markdown or org-mode"
  '((emacs "25.1")
    (popup "0.5.3")
    (request "0.3.0")
    (transient "0.3.6"))
  :commit "0893cfbc94bb6ca6d8c3218b79f9a4013892d0cb" :authors
  '(("Masashi Miyaura"))
  :maintainer
  '("Masashi Miyaura")
  :url "https://github.com/masasam/emacs-easy-hugo")
;; Local Variables:
;; no-byte-compile: t
;; End:
