(define-package "binky-mode" "20230120.1708" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "04f1132ea1945861da0081cb2ad08076d20cea57" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
