;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260601.1621"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "f27234fa0214801b54eb35f6ad2e910b07d80811"
  :revdesc "f27234fa0214"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
