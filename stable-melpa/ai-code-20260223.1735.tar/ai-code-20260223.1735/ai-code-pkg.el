;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260223.1735"
  "Unified interface for AI coding backends such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "628c9d868c5f986121225ff787d0c30fe83b280c"
  :revdesc "628c9d868c5f"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
