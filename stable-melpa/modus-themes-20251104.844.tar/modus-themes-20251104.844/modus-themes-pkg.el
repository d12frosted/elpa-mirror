;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251104.844"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "11329d1c4924d262bd6e0aa94966587e63b4fd3a"
  :revdesc "11329d1c4924"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
