;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260524.443"
  "Major mode for Godot's GDScript language."
  '((emacs "28.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "dde79a17f62ec5b2592ea40be606a42a2ab9a7be"
  :revdesc "dde79a17f62e"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
