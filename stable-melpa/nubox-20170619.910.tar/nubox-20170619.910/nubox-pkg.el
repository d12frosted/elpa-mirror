(define-package "nubox" "20170619.910" "Nubox color theme (dark, light and tty versions)" 'nil :commit "84aa965f0cb4bde293237e4cc586643d1f662f83" :authors
  '(("Martijn Terpstra" . "bigmartijn@gmail.com"))
  :maintainer
  '("Martijn Terpstra" . "bigmartijn@gmail.com")
  :keywords
  '("faces"))
;; Local Variables:
;; no-byte-compile: t
;; End:
