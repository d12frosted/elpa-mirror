;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-iedit-state" "20220219.1432"
  "Evil states to interface iedit mode."
  '((evil  "1.0.9")
    (iedit "0.9.9.9"))
  :url "https://github.com/syl20bnr/evil-iedit-state"
  :commit "44c64c71692e5b2f608ad3e3c537ec0a0e0ea0f8"
  :revdesc "44c64c71692e"
  :keywords '("convenience" "editing" "evil" "iedit" "mnemonic")
  :authors '(("Sylvain Benner" . "sylvain.benner@gmail.com"))
  :maintainers '(("Sylvain Benner" . "sylvain.benner@gmail.com")))
