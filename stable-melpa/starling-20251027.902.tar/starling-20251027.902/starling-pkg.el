;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "starling" "20251027.902"
  "Starling bank interaction."
  '((emacs "29.1")
    (plz   "0.7.2"))
  :url "https://codeberg.org/draxil/starling-el"
  :commit "85f5b7723a048869f7c301042b55693f9f3ae5c8"
  :revdesc "85f5b7723a04"
  :keywords '("data" "applications" "banking")
  :authors '(("Joe Higton" . "draxil@gmail.com"))
  :maintainers '(("Joe Higton" . "draxil@gmail.com")))
