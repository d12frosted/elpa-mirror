(define-package "vulpea" "20211114.904" "A collection of org-roam note-taking functions"
  '((emacs "27.1")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12"))
  :commit "5f5f2c892c99091a6d3703686754240ebd4936da" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
