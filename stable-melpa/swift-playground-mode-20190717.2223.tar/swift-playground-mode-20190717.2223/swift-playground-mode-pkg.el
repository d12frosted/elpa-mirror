(define-package "swift-playground-mode" "20190717.2223" "Run Apple's playgrounds in Swift buffers"
  '((emacs "24.4")
    (seq "2.2.0"))
  :commit "d24a2c6b78f6abda22356fd6152f9d5a185cda3d" :keywords
  '("languages" "swift")
  :url "https://gitlab.com/michael.sanders/swift-playground-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
