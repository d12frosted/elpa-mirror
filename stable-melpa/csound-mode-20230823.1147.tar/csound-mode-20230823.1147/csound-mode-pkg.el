(define-package "csound-mode" "20230823.1147" "A major mode for interacting and coding Csound"
  '((emacs "25")
    (shut-up "0.3.2")
    (multi "2.0.1")
    (dash "2.16.0")
    (highlight "0"))
  :commit "6a30595594d86a049e25af2cc35c6ca032c3c4cf" :authors
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainer
  '("Hlöðver Sigurðsson" . "hlolli@gmail.com")
  :url "https://github.com/hlolli/csound-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
