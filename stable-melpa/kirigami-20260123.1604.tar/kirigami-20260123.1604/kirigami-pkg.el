;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260123.1604"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "2449503af34628652e1ec77d0868fdd927f9c82b"
  :revdesc "2449503af346"
  :keywords '("convenience"))
