(define-package "speed-type" "20220810.1246" "Practice touch and speed typing"
  '((emacs "25.1"))
  :commit "52aaaa4af46d4bab4b83e38e1a5205fe40f285db" :authors
  '(("Gunther Hagleitner"))
  :maintainer
  '("Daniel Kraus" . "daniel@kraus.my")
  :keywords
  '("games")
  :url "https://github.com/dakra/speed-type")
;; Local Variables:
;; no-byte-compile: t
;; End:
