(define-package "caml" "20231007.1835" "Caml mode for GNU Emacs"
  '((emacs "24.4"))
  :commit "c9d7ca91e20360020d3532b788d91db2e3014cf6" :authors
  '(("Jacques Garrigue" . "garrigue@kurims.kyoto-u.ac.jp")
    ("Ian T Zimmerman" . "itz@rahul.net")
    ("Damien Doligez" . "damien.doligez@inria.fr"))
  :maintainers
  '(("Christophe Troestler" . "Christophe.Troestler@umons.ac.be"))
  :maintainer
  '("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
  :keywords
  '("ocaml")
  :url "https://github.com/ocaml/caml-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
