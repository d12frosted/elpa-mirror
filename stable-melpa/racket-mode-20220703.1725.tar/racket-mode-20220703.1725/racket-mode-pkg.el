(define-package "racket-mode" "20220703.1725" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "7bcedccbd96578cb581199d89ea05406c2c2fc87" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
