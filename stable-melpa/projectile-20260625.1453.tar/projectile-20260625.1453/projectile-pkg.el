;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260625.1453"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "4119e3eebe0f3c22d31820c1c5483199e5678c01"
  :revdesc "4119e3eebe0f"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
