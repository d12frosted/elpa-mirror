;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251014.413"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "1bdaba8f6e27426963fde0afb352ce2556a58520"
  :revdesc "1bdaba8f6e27"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
