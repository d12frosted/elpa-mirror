;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "db-pg" "20130131.1902"
  "A PostgreSQL adapter for emacs-db."
  '((pg "0.12")
    (db "0.0.6"))
  :url "https://github.com/nicferrier/emacs-db-pg"
  :commit "7d5ab86b74b05fe003b3b434d4835f37f3f3eded"
  :revdesc "7d5ab86b74b0"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Nic Ferrier" . "nic@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nic@ferrier.me.uk")))
