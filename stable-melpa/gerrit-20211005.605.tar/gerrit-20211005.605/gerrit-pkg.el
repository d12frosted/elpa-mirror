(define-package "gerrit" "20211005.605" "Gerrit client"
  '((emacs "25.1")
    (hydra "0.15.0")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "3de210e2bcf9a7ce9a2a448cd910ffe477de8432" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
