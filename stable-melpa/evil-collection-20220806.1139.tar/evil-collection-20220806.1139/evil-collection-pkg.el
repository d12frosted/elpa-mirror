(define-package "evil-collection" "20220806.1139" "A set of keybindings for Evil mode"
  '((emacs "26.3")
    (evil "1.2.13")
    (annalist "1.0"))
  :commit "b8096342f8b51728d29295724b00abd742a88e98" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("evil" "tools")
  :url "https://github.com/emacs-evil/evil-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
