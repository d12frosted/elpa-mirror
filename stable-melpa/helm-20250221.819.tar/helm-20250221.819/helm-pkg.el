;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250221.819"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.1")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "52e1a7f952db47b7118773048a41fe05873114e3"
  :revdesc "52e1a7f952db"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
