(define-package "tracking" "20201101.1045" "Buffer modification tracking" 'nil :commit "2798a75d625677402b01f138ebac6eb53337d9d6" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
