(define-package "tracking" "20201101.1045" "Buffer modification tracking" 'nil :commit "9c91a59ee7bce123181358e254232a7a92b56418" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
