(define-package "tracking" "20201101.1045" "Buffer modification tracking" 'nil :commit "0472cda711252b06fc07be184449b31933578148" :authors
  (("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  ("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
