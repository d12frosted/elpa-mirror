(define-package "tracking" "20201101.1045" "Buffer modification tracking" 'nil :commit "31ac6ba777a92715ce8b0150854a38586de491ff" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/jorgenschaefer/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
