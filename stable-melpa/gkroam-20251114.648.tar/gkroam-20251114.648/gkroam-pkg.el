;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gkroam" "20251114.648"
  "A lightweight org-mode Roam Research replica."
  '((emacs   "26.3")
    (db      "0.0.6")
    (company "0.9.10"))
  :url "https://github.com/Kinneyzhang/gkroam"
  :commit "b2b580731ce5c92d6682cfbd17361129a5cea4ca"
  :revdesc "b2b580731ce5"
  :keywords '("org" "convenience")
  :authors '(("Kinney Zhang" . "kinneyzhang666@gmail.com"))
  :maintainers '(("Kinney Zhang" . "kinneyzhang666@gmail.com")))
