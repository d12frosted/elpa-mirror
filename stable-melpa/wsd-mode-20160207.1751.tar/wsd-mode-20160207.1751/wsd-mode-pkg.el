(define-package "wsd-mode" "20160207.1751" "Emacs major-mode for www.websequencediagrams.com" 'nil :commit "b5e8ea0daeaa52f2ea6349e09902bd3216e96258" :authors
  '(("Jostein Kjønigsen" . "jostein@gmail.com"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("wsd" "diagrams" "design" "process" "modelling" "uml")
  :url "https://github.com/josteink/wsd-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
