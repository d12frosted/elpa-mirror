;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-vterm-interaction" "20250122.1511"
  "A mode for Python REPL using vterm."
  '((emacs  "27.1")
    (vterm  "0.0.2")
    (python "0.28"))
  :url "https://github.com/vale981/py-vterm-interaction.el"
  :commit "6b39ac33fcb622cfc4245f5ec27c708c9fe000b5"
  :revdesc "6b39ac33fcb6"
  :keywords '("languages" "python")
  :maintainers '(("Valentin Boettcher" . "hiroatprotagon.space")))
