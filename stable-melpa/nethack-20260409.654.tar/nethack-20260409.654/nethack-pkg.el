;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20260409.654"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "419a67872a3fee18032e2223cb193efbdc0aaa2d"
  :revdesc "419a67872a3f"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
