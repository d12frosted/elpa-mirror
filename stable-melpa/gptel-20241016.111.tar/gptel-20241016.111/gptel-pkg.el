;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241016.111"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "110eb18478da497b8c2c6c0caa642e684d39da02"
  :revdesc "110eb18478da"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
