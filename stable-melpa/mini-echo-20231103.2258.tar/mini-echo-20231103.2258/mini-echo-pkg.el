(define-package "mini-echo" "20231103.2258" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "89061feace09249a93e8bdaf2474cc953eee604b" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
