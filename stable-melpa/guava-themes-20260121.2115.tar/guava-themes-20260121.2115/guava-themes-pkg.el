;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260121.2115"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "http://github.com/bormoge/guava-themes"
  :commit "38ca52de6b8b9a70ca0e1f5344d3f4caa4d81a3a"
  :revdesc "38ca52de6b8b"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
