(define-package "consult" "20210120.2250" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "20e69f50856589e5c558f28366bad3b54be85bdf" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
