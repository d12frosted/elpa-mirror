;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elixir-iex" "20260412.1946"
  "IEx REPL via eat terminal emulator."
  '((emacs "29.1")
    (eat   "0.9"))
  :url "https://github.com/mojochao/elixir-iex"
  :commit "a82808ebb91b9668329459e808a75552d698433d"
  :revdesc "a82808ebb91b"
  :keywords '("elixir" "languages" "processes" "tools")
  :authors '(("Allen Gooch" . "allen.gooch@gmail.com"))
  :maintainers '(("Allen Gooch" . "allen.gooch@gmail.com")))
