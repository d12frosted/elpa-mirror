(define-package "consult" "20210905.1657" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "c89fd0a1299f8bd6a123427c6ce48239702dfe84" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
