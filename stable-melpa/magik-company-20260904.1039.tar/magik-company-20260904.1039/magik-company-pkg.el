;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-company" "20260904.1039"
  "Magik backend for company-mode."
  '((emacs      "29.1")
    (magik-mode "0.6.5")
    (company    "1.0.2")
    (yasnippet  "0.14.0"))
  :url "https://github.com/reinierkof/magik-company"
  :commit "96fbd0c04fb392d20bbf8e82934dc561ed47509f"
  :revdesc "96fbd0c04fb3"
  :keywords '("convenience")
  :authors '(("Reinier Koffijberg" . "reinierkof@gmail.com"))
  :maintainers '(("Reinier Koffijberg" . "reinierkof@gmail.com")))
