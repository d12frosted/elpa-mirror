(define-package "org-zettelkasten" "20230423.1135" "A Zettelkasten mode leveraging Org"
  '((emacs "25.1")
    (org "9.3"))
  :commit "50c092f0a22981e2e447dd421aa474fbc9b384ba" :authors
  '(("Yann Herklotz" . "yann@ymhg.org"))
  :maintainer
  '("Yann Herklotz" . "yann@ymhg.org")
  :keywords
  '("files" "hypermedia" "org" "notes")
  :url "https://sr.ht/~ymherklotz/org-zettelkasten")
;; Local Variables:
;; no-byte-compile: t
;; End:
