;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250616.1008"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "48ddef4c5cfce995a1327f8b93c9ea31b9d71d0f"
  :revdesc "48ddef4c5cfc"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
