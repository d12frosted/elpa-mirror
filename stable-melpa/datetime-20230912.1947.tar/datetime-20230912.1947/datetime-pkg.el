(define-package "datetime" "20230912.1947" "Parsing, formatting and matching timestamps"
  '((emacs "24.4")
    (extmap "1.1.1"))
  :commit "ecc98a0b2d9b465c30f8417f2f532cc22881064b" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
