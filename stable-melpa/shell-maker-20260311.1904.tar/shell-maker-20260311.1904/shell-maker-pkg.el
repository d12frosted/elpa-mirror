;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260311.1904"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "8c64f0b5b6855670db040e747e9af71062160d7e"
  :revdesc "8c64f0b5b685")
