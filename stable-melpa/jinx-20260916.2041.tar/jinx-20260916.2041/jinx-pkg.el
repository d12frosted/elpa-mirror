;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260916.2041"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "5693530bcf3cca835a15be07838dffb00cdfa885"
  :revdesc "5693530bcf3c"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
