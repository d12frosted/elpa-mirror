;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250523.412"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "727498e375e8320723f8adb3814163ce22e23c34"
  :revdesc "727498e375e8"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
