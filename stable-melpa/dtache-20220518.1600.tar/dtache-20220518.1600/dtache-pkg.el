(define-package "dtache" "20220518.1600" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "02651e47d3142deb675dceb42b76822d72584070" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
