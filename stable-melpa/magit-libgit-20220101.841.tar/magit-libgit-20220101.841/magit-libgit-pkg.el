(define-package "magit-libgit" "20220101.841" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "7f03f572d55400899d1e48cfc115e3baf5639021" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
