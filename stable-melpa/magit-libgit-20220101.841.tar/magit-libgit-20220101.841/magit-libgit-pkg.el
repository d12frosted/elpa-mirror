(define-package "magit-libgit" "20220101.841" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "0ac05f39624d1d8f2cd6cb2d2f1aa2e387a9c70a" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
