;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nice-org-html" "20241219.746"
  "Prettier org-to-html export."
  '((emacs   "25.1")
    (s       "1.13.0")
    (dash    "2.19.1")
    (htmlize "1.58")
    (uuidgen "1.0"))
  :url "https://github.com/ewantown/nice-org-html"
  :commit "becbcedc216ce64c12da1821ceca37913e7fe8cb"
  :revdesc "becbcedc216c"
  :keywords '("org" "org-export" "html" "css" "js" "tools")
  :authors '(("Ewan Townshend" . "ewan@etown.dev"))
  :maintainers '(("Ewan Townshend" . "ewan@etown.dev")))
