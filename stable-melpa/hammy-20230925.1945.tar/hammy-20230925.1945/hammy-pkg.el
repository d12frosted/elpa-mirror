(define-package "hammy" "20230925.1945" "Programmable, interactive interval timers"
  '((emacs "28.1")
    (svg-lib "0.2.5")
    (ts "0.2.2"))
  :commit "116ce41c36d065f47918e3fde7bb6f1ee5976ac0" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/hammy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
