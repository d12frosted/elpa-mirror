;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "myterminal-controls" "20210904.516"
  "Quick toggle controls at a key-stroke."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "http://ismail.teamfluxion.com"
  :commit "c635868e13ee898ec77925d98b36421640e22aa4"
  :revdesc "c635868e13ee"
  :keywords '("convenience" "shortcuts")
  :authors '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com"))
  :maintainers '(("Mohammed Ismail Ansari" . "team.terminal@gmail.com")))
