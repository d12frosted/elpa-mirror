;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261013.621"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.14.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "b9cf5af2471f06e24fb14ca2fefc41fb3a404b5d"
  :revdesc "b9cf5af2471f"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
