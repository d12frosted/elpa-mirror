(define-package "meow" "20220423.1957" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "115d078221bc9d9235c6bcb651146d099ac30ccf" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
