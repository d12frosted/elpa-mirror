;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260624.1606"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "4ab1e2c0fa70ed5be2343495134e77f8ccf2b303"
  :revdesc "4ab1e2c0fa70"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
