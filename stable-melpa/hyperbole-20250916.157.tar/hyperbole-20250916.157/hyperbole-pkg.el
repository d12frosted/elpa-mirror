;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250916.157"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "62caa5835046ef41828b0c7d1452afb9ed8f3330"
  :revdesc "62caa5835046"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
