;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260902.1739"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.7"))
  :url "https://github.com/jojojames/fzfa"
  :commit "dba133b5348aab3dc429603e37523f62cf629875"
  :revdesc "dba133b5348a"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
