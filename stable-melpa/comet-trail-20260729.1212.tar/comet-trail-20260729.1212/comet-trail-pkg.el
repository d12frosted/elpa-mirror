;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comet-trail" "20260729.1212"
  "Cursor comet trail effect."
  '((emacs "29.1"))
  :url "https://git.andros.dev/andros/comet-trail.el"
  :commit "5456810234d7236be8fb8b17a9ac7b270d6f4718"
  :revdesc "5456810234d7"
  :keywords '("faces" "convenience")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
