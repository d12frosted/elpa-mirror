(define-package "popper" "20211011.435" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "1ffc269afa46a9e7a5c1e5511752e49cfcb3aad4" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
