(define-package "popper" "20211011.435" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "9e368e1d20cfe47ec374ade5b96567ae7cab7864" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
