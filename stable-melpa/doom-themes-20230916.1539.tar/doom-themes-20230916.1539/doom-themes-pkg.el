(define-package "doom-themes" "20230916.1539" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "78d009284d9702ee66ce68ddb2ee88c5c3a3e44b" :authors
  '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainers
  '(("Henrik Lissner" . "contact@henrik.io"))
  :maintainer
  '("Henrik Lissner" . "contact@henrik.io")
  :keywords
  '("themes" "faces")
  :url "https://github.com/doomemacs/themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
