(define-package "exwm-firefox-evil" "20231002.1316" "evil-mode implementation of exwm-firefox-core"
  '((emacs "24.4")
    (exwm "0.16")
    (evil "1.0.0")
    (exwm-firefox-core "1.0"))
  :commit "fe1e30029b7e44eae2a2b0bbab8719dd8a9457db" :authors
  '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers
  '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainer
  '("Sebastian Wålinder" . "s.walinder@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/walseb/exwm-firefox-evil")
;; Local Variables:
;; no-byte-compile: t
;; End:
