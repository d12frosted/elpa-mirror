(define-package "leetcode" "20240806.1834" "An leetcode client"
  '((emacs "26.1")
    (s "1.13.0")
    (dash "2.16.0")
    (aio "1.0")
    (log4e "0.3.3"))
  :commit "997c890b777741a516abcc1f435538fedab4df7a" :authors
  '(("Wang Kai" . "kaiwkx@gmail.com"))
  :maintainers
  '(("Wang Kai" . "kaiwkx@gmail.com"))
  :maintainer
  '("Wang Kai" . "kaiwkx@gmail.com")
  :keywords
  '("extensions" "tools")
  :url "https://github.com/kaiwk/leetcode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
