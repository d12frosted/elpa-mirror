;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20250424.1405"
  "Create an Org Mode aggregated table from another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "cac4ef72131918060e162e7e54fd813cb0a5d642"
  :revdesc "cac4ef721319"
  :keywords '("data" "extensions"))
