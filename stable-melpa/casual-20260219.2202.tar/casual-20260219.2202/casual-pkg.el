;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260219.2202"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "8c9a494b3b690c0ac7a4964989d777553bea9419"
  :revdesc "8c9a494b3b69"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
