(define-package "hyperdrive" "20231104.653" "P2P filesystem"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5")
    (taxy-magit-section "0.12.1")
    (transient "0.4.3"))
  :commit "e775c9704cd8443d7616ec84d24b16a9aca1637c" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
