;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toggle-window" "20141207.1548"
  "Toggle current window size between half and full."
  ()
  :url "https://github.com/deadghost/toggle-window"
  :commit "e82c60e543933880402ede11e9423e48a17dde53"
  :revdesc "e82c60e54393"
  :keywords '("hide" "window"))
