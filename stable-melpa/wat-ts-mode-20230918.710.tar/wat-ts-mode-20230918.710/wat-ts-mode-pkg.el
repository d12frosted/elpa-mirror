(define-package "wat-ts-mode" "20230918.710" "Major mode for webassembly text format"
  '((emacs "29.1"))
  :commit "40c35ae388f44fbe60056e4f0f5f09c076a548ab" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("wasm" "wat" "wast" "languages" "tree-sitter")
  :url "https://github.com/nverno/wat-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
