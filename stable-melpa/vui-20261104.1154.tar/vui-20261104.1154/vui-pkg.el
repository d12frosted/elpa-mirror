;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261104.1154"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "e3f1795e898e572657f5f5271d3602c5e526978f"
  :revdesc "e3f1795e898e"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
