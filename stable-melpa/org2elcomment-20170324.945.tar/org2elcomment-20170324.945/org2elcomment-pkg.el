;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2elcomment" "20170324.945"
  "Convert Org file to Elisp comments."
  '((org "8.3.4"))
  :url "https://github.com/cute-jumper/org2elcomment"
  :commit "c88a75d9587c484ead18f7adf08592b09c1cceb0"
  :revdesc "c88a75d9587c"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
