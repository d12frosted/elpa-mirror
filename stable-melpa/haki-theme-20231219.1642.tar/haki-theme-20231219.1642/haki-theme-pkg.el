(define-package "haki-theme" "20231219.1642" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "67961b9b5c436a996974cd07354e3e7cfb6d0eb6" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
