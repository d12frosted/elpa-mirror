;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pure-light-theme" "20260613.824"
  "A light colored theme for e-ink color monitors."
  '((emacs "27.1"))
  :url "https://github.com/nyrell/pure-light-eink-color"
  :commit "0cf41b8cb0ec95efd363889f8877d7f65514e4ad"
  :revdesc "0cf41b8cb0ec"
  :keywords '("faces" "theme")
  :authors '(("Mattias Nyrell" . "mattias@nyrell.se"))
  :maintainers '(("Mattias Nyrell" . "mattias@nyrell.se")))
