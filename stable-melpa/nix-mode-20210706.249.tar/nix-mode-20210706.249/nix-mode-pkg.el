(define-package "nix-mode" "20210706.249" "Major mode for editing .nix files"
  '((emacs "25.1")
    (f "0.20.0"))
  :commit "1fdf8e654a22adc3d23d9ee01dda15f0574fc6d8" :maintainer
  '("Matthew Bauer" . "mjbauer95@gmail.com")
  :keywords
  '("nix" "languages" "tools" "unix")
  :url "https://github.com/NixOS/nix-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
