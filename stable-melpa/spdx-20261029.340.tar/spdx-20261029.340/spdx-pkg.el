;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20261029.340"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "94f24a0008ca6197d844da7ab2da7096d0cd80f9"
  :revdesc "94f24a0008ca"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
