(define-package "consult" "20210410.1817" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "8362f9befce145714e6d8f084f0547c72d3a6439" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
