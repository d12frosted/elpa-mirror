(define-package "leo" "20211221.1538" "Interface for dict.leo.org"
  '((emacs "27.1"))
  :commit "bf3ca048479058023a7b109a5b84e84d24feecf7" :authors
  '(("M.T. Enders <michael AT michael-enders.com>")
    ("Marty Hiatt <martianhiatus AT riseup.net>"))
  :maintainer
  '("M.T. Enders <michael AT michael-enders.com>")
  :keywords
  '("convenience" "translate")
  :url "https://github.com/mtenders/emacs-leo")
;; Local Variables:
;; no-byte-compile: t
;; End:
