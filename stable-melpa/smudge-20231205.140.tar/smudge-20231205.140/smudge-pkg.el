(define-package "smudge" "20231205.140" "Control the Spotify app"
  '((emacs "27.1")
    (simple-httpd "20230821.1458")
    (request "0.3")
    (oauth2 "0.16"))
  :commit "dc74e41e51ad916c7fe1091e61574e5eb29f3601" :keywords
  '("multimedia" "music" "spotify" "smudge")
  :url "https://github.com/danielfm/smudge")
;; Local Variables:
;; no-byte-compile: t
;; End:
