(define-package "dwim-coder-mode" "20230830.635" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "2563673502c5ca53a5032671aef51d0ec6ecf18a" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
