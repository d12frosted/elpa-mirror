;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260228.648"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.32.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "889766c41c1724c46a32038c6ce62d9c3fa8bbb7"
  :revdesc "889766c41c17"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
