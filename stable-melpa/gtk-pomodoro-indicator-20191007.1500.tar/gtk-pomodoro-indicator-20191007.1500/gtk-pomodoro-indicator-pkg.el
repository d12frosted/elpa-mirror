(define-package "gtk-pomodoro-indicator" "20191007.1500" "A pomodoro indicator for the GTK tray" 'nil :commit "cb026a595de8a9244b16e06876f10c60dce18676" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("convenience" "pomodoro")
  :url "https://github.com/abo-abo/gtk-pomodoro-indicator")
;; Local Variables:
;; no-byte-compile: t
;; End:
