(define-package "clojure-ts-mode" "20230907.1327" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "2225190ee57ef667d69f2cd740e0137810bc38e7" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
