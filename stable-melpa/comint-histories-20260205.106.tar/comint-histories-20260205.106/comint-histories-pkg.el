;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comint-histories" "20260205.106"
  "Many comint histories."
  '((emacs "25.1")
    (f     "0.21.0"))
  :url "https://github.com/NicholasBHubbard/comint-histories"
  :commit "12cd14d64d7396def51397ca1f0756357afd41f3"
  :revdesc "12cd14d64d73"
  :keywords '("convenience" "processes" "terminals")
  :authors '(("Nicholas Hubbard" . "nicholashubbard@posteo.net"))
  :maintainers '(("Nicholas Hubbard" . "nicholashubbard@posteo.net")))
