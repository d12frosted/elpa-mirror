(define-package "racket-mode" "20210707.2354" "Racket editing, REPL, and more"
  '((emacs "25.1")
    (faceup "0.0.2")
    (pos-tip "20191127.1028"))
  :commit "7aa74f1c5930159f36c4863012d50d98f3912fe8" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
