;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "20260701.850"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.23"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "929c431d4157eea0540c47a53b349565cf7aaf11"
  :revdesc "929c431d4157"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
