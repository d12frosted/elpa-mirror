;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260128.1500"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "bf1d52be6216c9079805f8889544ac256529d5e8"
  :revdesc "bf1d52be6216"
  :keywords '("data" "extensions"))
