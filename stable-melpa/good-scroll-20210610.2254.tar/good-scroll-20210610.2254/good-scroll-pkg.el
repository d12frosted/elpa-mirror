(define-package "good-scroll" "20210610.2254" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "90b5829b3b545110d02a0dff9b862359cc41abfa" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
