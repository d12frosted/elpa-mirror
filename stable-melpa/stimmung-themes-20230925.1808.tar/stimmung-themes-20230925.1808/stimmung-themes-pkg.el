(define-package "stimmung-themes" "20230925.1808" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "6d0f9b34eba1abde6ee72e10c2b4dfdd18712065" :authors
  '(("Love Lagerkvist"))
  :maintainers
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
