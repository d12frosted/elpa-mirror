(define-package "projection" "20230901.2015" "Project type support for `project'"
  '((emacs "29.1")
    (project "0.9.8")
    (compat "29.1.4.1")
    (f "0.20"))
  :commit "0861adba96ceaf9a17c3985429d6961e96753ecd" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
