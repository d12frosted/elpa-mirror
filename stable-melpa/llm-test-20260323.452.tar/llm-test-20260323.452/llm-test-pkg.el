;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260323.452"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "1eb9875451480ff382306044e4afaf3da84d8e30"
  :revdesc "1eb987545148"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
