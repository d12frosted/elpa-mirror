;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bray" "20250225.540"
  "Lightweight modal editing."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-bray"
  :commit "9e180de63022ce61ccdd5510d06513c410fc4054"
  :revdesc "9e180de63022"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
