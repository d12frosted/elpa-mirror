;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260313.2345"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "134a17f3e56c55ade6d5476ca812b354fabfe0e8"
  :revdesc "134a17f3e56c"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
