;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260321.1321"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "77d7ef684515c1b93ae23f52c450e7496ac4eb14"
  :revdesc "77d7ef684515"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
