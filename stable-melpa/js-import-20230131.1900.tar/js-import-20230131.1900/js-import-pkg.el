;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "js-import" "20230131.1900"
  "Import Javascript files from your current project or dependencies."
  '((emacs      "24.4")
    (f          "0.19.0")
    (projectile "0.14.0")
    (dash       "2.13.0"))
  :url "https://github.com/jakoblind/js-import"
  :commit "9f8b6bc4f080c7146ce7ee5dd5a6572aeb6f1cc7"
  :revdesc "9f8b6bc4f080"
  :keywords '("tools")
  :authors '(("Jakob Lind" . "karl.jakob.lind@gmail.com"))
  :maintainers '(("Jakob Lind" . "karl.jakob.lind@gmail.com")))
