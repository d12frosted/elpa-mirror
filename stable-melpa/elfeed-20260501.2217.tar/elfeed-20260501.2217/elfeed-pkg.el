;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260501.2217"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "f382462a6a6334a3a48acab7c200e86ee34efb29"
  :revdesc "f382462a6a63"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
