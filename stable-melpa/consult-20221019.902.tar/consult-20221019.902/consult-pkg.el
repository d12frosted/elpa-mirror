(define-package "consult" "20221019.902" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "82a41d35291fe17fe3b89ccc6e2cf2b2589e8eef" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
