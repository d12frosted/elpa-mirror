(define-package "modus-themes" "20211114.659" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "bf132a59ea2c97d61481b303726a61f5a28cfb00" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
