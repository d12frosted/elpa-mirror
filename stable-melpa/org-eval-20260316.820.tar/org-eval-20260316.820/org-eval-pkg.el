;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-eval" "20260316.820"
  "Execute named org-mode blocks on load/save."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-eval"
  :commit "013ecc4a6aca3527e1bd0faa44ea88ad4c02ecf1"
  :revdesc "013ecc4a6aca"
  :keywords '("org" "outlines")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
