(define-package "mistty" "20230923.1043" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "c1f73167f010e0961acfd919ead5b6a211518ecc" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
