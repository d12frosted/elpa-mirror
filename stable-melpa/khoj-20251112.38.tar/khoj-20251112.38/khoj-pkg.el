;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "khoj" "20251112.38"
  "Your Second Brain."
  '((emacs     "27.1")
    (transient "0.3.0")
    (dash      "2.19.1"))
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs"
  :commit "d7e936678d4f73b1c7ab036d495229198156dbb1"
  :revdesc "d7e936678d4f"
  :keywords '("search" "chat" "ai" "org-mode" "outlines" "markdown" "pdf" "image")
  :authors '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
             ("Saba Imran" . "saba@khoj.dev"))
  :maintainers '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
                 ("Saba Imran" . "saba@khoj.dev")))
