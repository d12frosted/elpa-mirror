;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mic" "20240806.1655"
  "Minimal and combinable configuration manager."
  '((emacs "26.1"))
  :url "https://github.com/ROCKTAKEY/mic"
  :commit "f552ddf397e899e9c2b96ef4e56a08cc8804a1c5"
  :revdesc "f552ddf397e8"
  :keywords '("convenience")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
