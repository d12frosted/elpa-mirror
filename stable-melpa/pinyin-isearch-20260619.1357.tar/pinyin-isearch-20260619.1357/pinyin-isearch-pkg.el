;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260619.1357"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "71d7b7bf9e93e90155391ebc26c285152cd2beb5"
  :revdesc "71d7b7bf9e93"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
