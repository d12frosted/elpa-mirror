(define-package "posframe" "20211026.1623" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "981ab87d11cd2c07db4980c8c7e5e4b87cf171fb" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
