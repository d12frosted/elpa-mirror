;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-jira" "20250930.140"
  "Syncing between Jira and Org-mode."
  '((emacs   "24.5")
    (cl-lib  "0.5")
    (request "0.2.0")
    (dash    "2.14.1"))
  :url "https://github.com/ahungry/org-jira"
  :commit "326609425acc3813ca17da769247cd4f6987e55a"
  :revdesc "326609425acc"
  :keywords '("ahungry" "jira" "org" "bug" "tracker")
  :maintainers '(("Matthew Carter" . "m@ahungry.com")))
