(define-package "w3m" "20210201.2305" "an Emacs interface to w3m" 'nil :commit "d22d266caf7d99940a4aacacfb9cc2dbbb49504d" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
