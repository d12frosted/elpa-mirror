(define-package "company" "20210616.1055" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "ac13eabd79ee0a963082af835e6bc3fb4d01bb81" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
