;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260614.1337"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "ed7cd8e93d3e1cbc5996650a7e8b58262e1fbbc3"
  :revdesc "ed7cd8e93d3e"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
