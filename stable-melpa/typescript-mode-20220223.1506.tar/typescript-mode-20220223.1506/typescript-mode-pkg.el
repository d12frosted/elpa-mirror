(define-package "typescript-mode" "20220223.1506" "Major mode for editing typescript"
  '((emacs "24.3"))
  :commit "694a168492781587a4cd6f51e4c835de7c84ae24" :keywords
  '("typescript" "languages")
  :url "http://github.com/ananthakumaran/typescript.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
