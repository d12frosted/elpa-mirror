(define-package "humanoid-themes" "20230308.2129" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "d6d41b365501650c18939c3394762bc163c87e40" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
