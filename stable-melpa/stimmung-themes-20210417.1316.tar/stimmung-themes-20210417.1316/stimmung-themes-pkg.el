(define-package "stimmung-themes" "20210417.1316" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "b2546bfd05b6dc625d9c6628933b4dd6c31b8091" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
