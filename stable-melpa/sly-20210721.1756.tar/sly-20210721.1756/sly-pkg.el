(define-package "sly" "20210721.1756" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "e8f57c09cb4cc857887310e61eed7325500e9998" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
