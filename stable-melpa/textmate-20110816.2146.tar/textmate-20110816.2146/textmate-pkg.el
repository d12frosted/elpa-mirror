;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "textmate" "20110816.2146"
  "TextMate minor mode for Emacs."
  ()
  :url "https://github.com/defunkt/textmate.el"
  :commit "350918b070148f0ace6d9d3cd4ebcaf15c1a8781"
  :revdesc "350918b07014"
  :keywords '("textmate" "osx" "mac")
  :authors '(("Chris Wanstrath" . "chris@ozmm.org"))
  :maintainers '(("Chris Wanstrath" . "chris@ozmm.org")))
