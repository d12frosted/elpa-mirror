;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "20250427.1549"
  "Run REPLs in a terminal backend."
  '((emacs "29"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "7d8ae55b5b694de1a129ee0a2f9b8735d6ebf1a1"
  :revdesc "7d8ae55b5b69"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
