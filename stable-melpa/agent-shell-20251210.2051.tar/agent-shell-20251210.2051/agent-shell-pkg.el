;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251210.2051"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.2")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4cdee4c062010d3a76665a40cf3942af680d9351"
  :revdesc "4cdee4c06201")
