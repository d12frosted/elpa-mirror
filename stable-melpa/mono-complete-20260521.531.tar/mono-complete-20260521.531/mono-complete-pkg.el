;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mono-complete" "20260521.531"
  "Completion suggestions with multiple back-ends."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-mono-complete"
  :commit "51a521f3b69100388a22500c59f887c6e6cf56bd"
  :revdesc "51a521f3b691"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
