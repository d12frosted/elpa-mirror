;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260122.253"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "94a5f5e14c626786d834331625282cfe06d1b810"
  :revdesc "94a5f5e14c62"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
