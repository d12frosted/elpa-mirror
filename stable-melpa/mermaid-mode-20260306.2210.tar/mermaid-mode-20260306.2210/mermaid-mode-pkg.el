;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mermaid-mode" "20260306.2210"
  "Major mode for working with mermaid graphs."
  '((emacs "25.3"))
  :url "https://github.com/abrochard/mermaid-mode"
  :commit "127fad71666faacf4e962a1498f3fe08910cc6c4"
  :revdesc "127fad71666f"
  :keywords '("mermaid" "graphs" "tools" "processes"))
