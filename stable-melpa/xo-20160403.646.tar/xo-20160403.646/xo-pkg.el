;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xo" "20160403.646"
  "XO linter integration with compilation mode."
  ()
  :url "https://github.com/j-em/xo-emacs"
  :commit "72fcd867cfa332fdb82f732925cf8977e690af78"
  :revdesc "72fcd867cfa3"
  :keywords '("processes")
  :authors '(("J.A" . "jer.github@gmail.com"))
  :maintainers '(("J.A" . "jer.github@gmail.com")))
