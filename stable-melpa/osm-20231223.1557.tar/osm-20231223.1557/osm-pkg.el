(define-package "osm" "20231223.1557" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "dcb9616543ecadb57c63cfbc1a06587a197a18db" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
