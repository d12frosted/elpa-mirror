(define-package "ado-mode" "20221023.1422" "Major mode for editing Stata-related files"
  '((emacs "25.1"))
  :commit "5610074e29ce08631c5210f1873938c3bcd9cbde" :authors
  '(("Bill Rising" . "brising@alum.mit.edu"))
  :maintainer
  '("Bill Rising" . "brising@alum.mit.edu")
  :keywords
  '("tools" "languages" "files" "convenience" "stata" "mata" "ado")
  :url "https://github.com/louabill/ado-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
