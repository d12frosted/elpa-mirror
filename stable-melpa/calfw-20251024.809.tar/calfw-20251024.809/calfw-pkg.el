;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251024.809"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "f7b214cd1a49625aca4d23d68019fadb6bb3950e"
  :revdesc "f7b214cd1a49"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
