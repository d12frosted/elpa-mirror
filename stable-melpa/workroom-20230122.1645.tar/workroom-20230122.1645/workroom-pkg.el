(define-package "workroom" "20230122.1645" "Named rooms for work without irrelevant distracting buffers"
  '((emacs "25.1")
    (project "0.3.0")
    (compat "28.1.2.2"))
  :commit "b6b06463ee7b5d66ec56fc1195836c0c27c6b6f4" :authors
  '(("Akib Azmain Turja" . "akib@disroot.org"))
  :maintainer
  '("Akib Azmain Turja" . "akib@disroot.org")
  :keywords
  '("tools" "convenience")
  :url "https://codeberg.org/akib/emacs-workroom")
;; Local Variables:
;; no-byte-compile: t
;; End:
