;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-todo" "20261001.1547"
  "Highlight TODO and similar keywords."
  '((emacs    "28.1")
    (compat   "31.1")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/hl-todo"
  :commit "d25aa5a2e78f70331de2b3455d8ef85bd945356b"
  :revdesc "d25aa5a2e78f"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.hl-todo@jonas.bernoulli.dev")))
