(define-package "projection" "20230621.2205" "Project type support for `project'"
  '((emacs "29")
    (project "0.9.8")
    (compat "29.1.4.1"))
  :commit "8049a00d04d62970cc8d567972c398e84fd19a6b" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
