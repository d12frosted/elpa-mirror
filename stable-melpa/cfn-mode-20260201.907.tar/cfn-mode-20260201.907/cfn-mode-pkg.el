;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260201.907"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "f8480ec4bb55c67ebece27193b4f2a4b6be5a938"
  :revdesc "f8480ec4bb55"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
