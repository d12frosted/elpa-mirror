;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20241115.1854"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "6ff8203a2f208c0d0cd070e07f785f62f438aeae"
  :revdesc "6ff8203a2f20"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
