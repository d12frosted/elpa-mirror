(define-package "osm" "20220509.1109" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "86610105769729eda4c2609b4b724903bcdabb88" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
