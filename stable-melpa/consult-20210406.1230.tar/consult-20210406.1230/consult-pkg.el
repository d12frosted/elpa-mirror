(define-package "consult" "20210406.1230" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "3121b34e207222b2db6ac96a655d68c0edf1a449" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
