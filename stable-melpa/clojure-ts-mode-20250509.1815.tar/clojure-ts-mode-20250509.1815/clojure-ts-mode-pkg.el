;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20250509.1815"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "http://github.com/clojure-emacs/clojure-ts-mode"
  :commit "c7a355588755d35144f64b0a4a8061bdd47cae45"
  :revdesc "c7a355588755"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
