;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vector-utils" "20140508.2041"
  "Vector-manipulation utility functions."
  ()
  :url "https://github.com/rolandwalker/vector-utils"
  :commit "5f9ced3960a318d611c3d20ffdc9ca74054fa8b7"
  :revdesc "5f9ced3960a3"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
