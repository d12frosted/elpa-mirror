;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "neut-mode" "20240929.553"
  "A major mode for Neut."
  '((emacs "29"))
  :url "https://github.com/vekatze/neut-mode"
  :commit "4c2d56fdd6295589439ffef214666452cc45c7d6"
  :revdesc "4c2d56fdd629"
  :authors '(("vekatze" . "vekatze@icloud.com"))
  :maintainers '(("vekatze" . "vekatze@icloud.com")))
