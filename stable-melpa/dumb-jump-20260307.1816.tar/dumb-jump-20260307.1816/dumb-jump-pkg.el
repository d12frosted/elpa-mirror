;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260307.1816"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "26.1"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "d1a1501a34911b67ff2138dd913fbd0c20b97af0"
  :revdesc "d1a1501a3491"
  :keywords '("programming"))
