;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "20260726.648"
  "Batppuccin (Catppuccin) color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "41a0b7c6c57530eb04add1cc892845303c14a294"
  :revdesc "41a0b7c6c575"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
