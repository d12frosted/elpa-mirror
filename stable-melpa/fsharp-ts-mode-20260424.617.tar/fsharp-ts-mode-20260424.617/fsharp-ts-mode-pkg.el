;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fsharp-ts-mode" "20260424.617"
  "Major mode for F# code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/fsharp-ts-mode"
  :commit "415dcaf2cb83d98af86ae072a11eae2558047c6c"
  :revdesc "415dcaf2cb83"
  :keywords '("languages" "fsharp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
