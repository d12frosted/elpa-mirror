(define-package "calibredb" "20230809.927" "Yet another calibre client"
  '((emacs "25.1")
    (org "9.3")
    (transient "0.1.0")
    (s "1.12.0")
    (dash "2.17.0")
    (request "0.3.3")
    (esxml "0.3.7"))
  :commit "588039aeb471c0bdabea36dab5e1c37441d38fed" :authors
  '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers
  '(("Damon Chan" . "elecming@gmail.com"))
  :maintainer
  '("Damon Chan" . "elecming@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/chenyanming/calibredb.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
