;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20260126.1714"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.0.0")
    (vui    "0.1"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "c9a3fbc62e0c5b03f557b13fd68aafa609ae9d8b"
  :revdesc "c9a3fbc62e0c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
