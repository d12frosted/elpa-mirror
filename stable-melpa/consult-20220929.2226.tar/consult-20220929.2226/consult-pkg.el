(define-package "consult" "20220929.2226" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "1a75e15b87690d107a82bc3f7ba8a135fd0438eb" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
