;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260401.316"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "380d28d5a7094cc93ed6a1e38481d59276e290f6"
  :revdesc "380d28d5a709"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
