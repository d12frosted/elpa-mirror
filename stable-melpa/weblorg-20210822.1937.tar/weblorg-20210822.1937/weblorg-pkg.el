(define-package "weblorg" "20210822.1937" "Static Site Generator for org-mode"
  '((templatel "0.1.5")
    (emacs "26.1"))
  :commit "cc095820669c7c2e77b06a86a887ecec70ae4853" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
