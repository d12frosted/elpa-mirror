(define-package "emr" "20190414.2015" "Emacs refactoring system."
  '((s "1.3.1")
    (dash "1.2.0")
    (cl-lib "0.2")
    (popup "0.5.0")
    (emacs "24.1")
    (list-utils "0.3.0")
    (paredit "24.0.0")
    (projectile "0.9.1")
    (clang-format "0")
    (iedit "0.97"))
  :commit "2b3606252d2dd29898d0ef702918eb13081b6c1a" :authors
  '(("Chris Barrett" . "chris.d.barrett@me.com"))
  :maintainer
  '("Chris Barrett" . "chris.d.barrett@me.com")
  :keywords
  '("tools" "convenience" "refactoring"))
;; Local Variables:
;; no-byte-compile: t
;; End:
