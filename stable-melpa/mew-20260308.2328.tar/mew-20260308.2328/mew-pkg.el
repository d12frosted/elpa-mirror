;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260308.2328"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "c0cb37388b5c58cf961d15aa34878153638f212e"
  :revdesc "c0cb37388b5c")
