;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260322.2139"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0a75dba5894776437bc3496eeaf0223bfffa2de0"
  :revdesc "0a75dba58947")
