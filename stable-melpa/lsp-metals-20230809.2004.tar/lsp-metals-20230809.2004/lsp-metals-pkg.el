(define-package "lsp-metals" "20230809.2004" "Scala Client settings"
  '((emacs "27.1")
    (scala-mode "1.1")
    (lsp-mode "7.0")
    (lsp-treemacs "0.2")
    (dap-mode "0.3")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.0")
    (treemacs "2.5")
    (posframe "1.4.1"))
  :commit "7f0a724b316b26496bc42b23c4fb00f7533ea76b" :authors
  '(("Ross A. Baker" . "ross@rossabaker.com")
    ("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Ross A. Baker" . "ross@rossabaker.com"))
  :maintainer
  '("Ross A. Baker" . "ross@rossabaker.com")
  :keywords
  '("languages" "extensions")
  :url "https://github.com/emacs-lsp/lsp-metals")
;; Local Variables:
;; no-byte-compile: t
;; End:
