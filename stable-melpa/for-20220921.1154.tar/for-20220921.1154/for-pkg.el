(define-package "for" "20220921.1154" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "1dc29a8c2b0f79fee256c50b16f5cee0ed75ffcf" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
