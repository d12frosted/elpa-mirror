;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260527.1808"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "7c082d878b824a5a0a7f778c039c319aed84be89"
  :revdesc "7c082d878b82"
  :keywords '("extensions"))
