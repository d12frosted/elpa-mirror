;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flatui-dark-theme" "20261019.2101"
  "Dark color theme with colors from https://flatuicolors.com/."
  '((emacs "24"))
  :url "https://github.com/theasp/flatui-dark-theme"
  :commit "3cf2c1dbe107f0de8aaac8c7290a89d376b6056a"
  :revdesc "3cf2c1dbe107"
  :keywords '("color" "theme" "dark" "flatui" "faces")
  :authors '(("Andrew Phillips" . "theasp@gmail.com"))
  :maintainers '(("Andrew Phillips" . "theasp@gmail.com")))
