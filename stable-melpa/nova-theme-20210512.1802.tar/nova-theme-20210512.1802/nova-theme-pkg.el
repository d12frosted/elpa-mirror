(define-package "nova-theme" "20210512.1802" "A dark, pastel color theme"
  '((emacs "24.3"))
  :commit "1498f756a4c1c9ea9740cd3208f74d071283b930" :authors
  '(("Muir Manders" . "muir+emacs@mnd.rs"))
  :maintainers
  '(("Muir Manders" . "muir+emacs@mnd.rs"))
  :maintainer
  '("Muir Manders" . "muir+emacs@mnd.rs")
  :keywords
  '("theme" "dark" "nova" "pastel" "faces")
  :url "https://github.com/muirmanders/emacs-nova-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
