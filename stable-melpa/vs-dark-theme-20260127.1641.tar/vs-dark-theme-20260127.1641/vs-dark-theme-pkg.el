;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vs-dark-theme" "20260127.1641"
  "Visual Studio IDE dark theme."
  '((emacs "24.1"))
  :url "https://github.com/emacs-vs/vs-dark-theme"
  :commit "ac0daa04be6ff339ffb9af29ee0f6ce1eed0c458"
  :revdesc "ac0daa04be6f"
  :keywords '("faces"))
