(define-package "embark" "20210802.1555" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "61a301dfdad74adfff2bd9b20764c944f9880250" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
