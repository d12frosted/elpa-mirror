;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cql-mode" "20190315.225"
  "Major mode for editting CQLs."
  '((emacs "24"))
  :url "https://github.com/Yuki-Inoue/cql-mode"
  :commit "d400c046850d3cf404778b2c47d6be4ff84ca04b"
  :revdesc "d400c046850d"
  :keywords '("cql" "cassandra")
  :authors '(("Yuki Inoue" . "inouetakahirokiatgmail.com"))
  :maintainers '(("Yuki Inoue" . "inouetakahirokiatgmail.com")))
