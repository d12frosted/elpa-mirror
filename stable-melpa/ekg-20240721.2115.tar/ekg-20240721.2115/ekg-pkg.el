(define-package "ekg" "20240721.2115" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.17.0"))
  :commit "06bb92c28938ebe0cf08901a211538b288da3278" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
