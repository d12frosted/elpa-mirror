(define-package "django-snippets" "20131229.1611" "Yasnippets for django"
  '((yasnippet "0.8.0"))
  :commit "f1e6fea8878bebc9bc0b761376a14cd5c9feda0f" :authors
  '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainer
  '("Yasuyuki Oka" . "yasuyk@gmail.com")
  :url "https://github.com/myfreeweb/django-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
