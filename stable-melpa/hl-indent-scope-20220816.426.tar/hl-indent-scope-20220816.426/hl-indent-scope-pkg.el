(define-package "hl-indent-scope" "20220816.426" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "243b6e4202502439f39ab2a485e4ecf8ea50edbe" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
