;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynamic-graphs" "20260905.1626"
  "Manipulation with graphviz graphs."
  '((emacs "26.1"))
  :url "https://github.com/zellerin/dynamic-graphs"
  :commit "eeca8fa68dc404af127382ebdc9f0397b4c364f1"
  :revdesc "eeca8fa68dc4"
  :keywords '("tools")
  :authors '(("Tomas Zellerin" . "tomas@zellerin.cz"))
  :maintainers '(("Tomas Zellerin" . "tomas@zellerin.cz")))
