;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260101.609"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "767fc34ae90f5af64d9fb5cb42129cdf8755ff26"
  :revdesc "767fc34ae90f"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
