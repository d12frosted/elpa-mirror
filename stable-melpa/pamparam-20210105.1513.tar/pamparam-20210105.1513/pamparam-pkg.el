(define-package "pamparam" "20210105.1513" "Simple and fast flashcards."
  '((emacs "26.1")
    (lispy "0.27.0")
    (worf "0.1.0")
    (ivy-posframe "0.5.5"))
  :commit "0ba91149095bee8c43688c68f83f4d365fbe6771" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("outlines" "hypermedia" "flashcards" "memory")
  :url "https://github.com/abo-abo/pamparam")
;; Local Variables:
;; no-byte-compile: t
;; End:
