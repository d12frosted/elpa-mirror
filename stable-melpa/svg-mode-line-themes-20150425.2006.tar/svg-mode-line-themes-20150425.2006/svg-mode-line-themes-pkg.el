;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "svg-mode-line-themes" "20150425.2006"
  "SVG-based themes for mode-line."
  '((xmlgen "0.4"))
  :url "https://github.com/sabof/svg-mode-line-themes"
  :commit "80a0e01839cafbd66899202e7764c33231974259"
  :revdesc "80a0e01839ca")
