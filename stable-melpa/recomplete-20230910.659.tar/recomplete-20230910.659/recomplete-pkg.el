(define-package "recomplete" "20230910.659" "Immediately (re)complete actions"
  '((emacs "26.1"))
  :commit "b5451170ef924644d6f3565b75b83b934e7f7d6d" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-recomplete")
;; Local Variables:
;; no-byte-compile: t
;; End:
