;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260409.549"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "2eeeb94b649ef42871b31a4225ac8f3932837e3f"
  :revdesc "2eeeb94b649e"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
