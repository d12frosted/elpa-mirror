;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bank-buddy" "20250426.815"
  "Financial analysis and reporting."
  '((emacs "26.1")
    (async "1.9.4"))
  :url "https://github.com/captainflasmr/bank-buddy"
  :commit "41d681d7d189afa75d80815d95f03d2ee1a54334"
  :revdesc "41d681d7d189"
  :keywords '("matching")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
