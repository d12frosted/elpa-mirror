(define-package "editorconfig" "20201122.1542" "EditorConfig Emacs Plugin"
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "998d5b58f9291b37bbefb72d11770f7c0090802b" :authors
  (("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainer
  ("EditorConfig Team" . "editorconfig@googlegroups.com")
  :url "https://github.com/editorconfig/editorconfig-emacs#readme")
;; Local Variables:
;; no-byte-compile: t
;; End:
