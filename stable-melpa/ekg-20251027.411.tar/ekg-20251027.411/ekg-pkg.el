;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20251027.411"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "54d0f985daddbbf0e6dbac85eb483e97f579cdb0"
  :revdesc "54d0f985dadd"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
