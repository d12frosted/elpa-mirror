;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yaml-pro" "20241223.715"
  "Parser-aided YAML editing features."
  '((emacs "26.1")
    (yaml  "0.5.1"))
  :url "https://github.com/zkry/yaml-pro"
  :commit "42fdc069f41dadd086cf84578112717d4af9e1a8"
  :revdesc "42fdc069f41d"
  :keywords '("tools"))
