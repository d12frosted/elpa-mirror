;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260905.1509"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "da9e39e1008bcbe8f2510345ec19bdab5002f87c"
  :revdesc "da9e39e1008b"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
