;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "format-all" "20260620.1415"
  "Auto-format C, C++, JS, Python, Ruby and 50 other languages."
  '((emacs       "24.4")
    (inheritenv  "0.1")
    (language-id "0.20"))
  :url "https://github.com/lassik/emacs-format-all-the-code"
  :commit "ea09b47d50da21784ebea16fd973838f8ce20abe"
  :revdesc "ea09b47d50da"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
