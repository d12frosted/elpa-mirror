;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20260410.1603"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "e2e59ea7de18360d937860c86d3eb3abb6d8605f"
  :revdesc "e2e59ea7de18"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
