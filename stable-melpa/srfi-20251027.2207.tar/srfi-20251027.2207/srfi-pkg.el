;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20251027.2207"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "8236380e43d26f878ad9b4ef5612483d6f98e23d"
  :revdesc "8236380e43d2"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
