(define-package "dirvish" "20220108.1136" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "42b7e6ee74569c528b0280eb2f1122afc28be5ac" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
