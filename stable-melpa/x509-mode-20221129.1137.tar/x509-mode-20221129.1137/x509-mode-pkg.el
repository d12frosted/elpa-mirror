(define-package "x509-mode" "20221129.1137" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "c025535316cd2b41d3dafc00ea5c127bf9813a1d" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
