;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250625.1818"
  "Add ╭─╴UNICODE╶─╮ based ╭─╴diagrams╶─╮ to ╭▶╴text files╶●╮."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "995948de4ae411229b249e5ba4c102ae1928af0a"
  :revdesc "995948de4ae4"
  :keywords '("convenience" "text"))
