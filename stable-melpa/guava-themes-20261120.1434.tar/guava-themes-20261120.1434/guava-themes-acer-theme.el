;;; guava-themes-acer-theme.el --- A theme inspired by maple colors -*- lexical-binding: t; -*-

;; Copyright (C) 2025-2026

;; Author: Geralld Borbón <geralldborbon@gmail.com>
;; Created: Jan 12, 2026
;; Keywords: themes, faces, color
;; URL: http://github.com/bormoge/guava-themes
;; Package-Requires: ((emacs "24.1"))
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; A theme inspired by maple colors.
;;
;;; Code:

(require 'guava-themes)

(deftheme guava-themes-acer "A theme inspired by maple colors.")

(let* (
      (acer-class '((class color) (min-colors 257)))
      (acer-black                     "#000000")
      (acer-white                     "#FFFFFF")

      (acer-green                     "#237c34")
      (acer-green-cyan                "#277a6a")
      (acer-deep-green                "#006041")

      (acer-orange                    "#e76144")
      ;; (acer-deep-orange               "#d44400")
      (acer-orange-pink               "#cd475f")
      (acer-autumn                    "#ff8c4e")

      (acer-cream                     "#dca56e")
      (acer-deep-brown                "#8c695a")

      (acer-light-blue                "#3a9187")
      (acer-blue                      "#2134d5")
      (acer-deep-blue                 "#1B3B4D")

      (acer-purple                    "#8a618a")
      (acer-deep-purple               "#60366e")
      (acer-purple-red                "#9b234b")
      (acer-purple-pink               "#5f2258")

      (acer-fg-1                      "#000000")
      (acer-fg-2                      "#3c3c3c")
      (acer-bg-1                      "#f7bb78")
      (acer-highlight                 "#e3a764")
      (acer-shadow                    "#717171")
      (acer-tooltip                   "#ffffe0")
      (acer-region-1                  "#c88550")
      (acer-region-2                  "#a07150")

      (acer-error                     "#d70000")
      (acer-warning                   "#b4a000")
      (acer-success                   "#28823c")
      (acer-change                    "#2134d5")

      (acer-mode-line                 "#e76144")
      (acer-mode-line-inactive        "#eb8c4e")
      (acer-mode-line-modified        "#CEB2D7")
      (acer-bell                      "#4478E7")

      (acer-tab-1                     acer-mode-line)
      (acer-tab-2                     acer-mode-line-inactive)
      (acer-tab-3                     acer-cream)

      (acer-fl-comment                acer-deep-green)
      (acer-fl-string                 acer-deep-brown)
      (acer-fl-keyword                acer-deep-purple)
      (acer-fl-builtin                acer-orange)
      (acer-fl-type                   acer-green)
      (acer-fl-function-name          acer-purple-red)
      (acer-fl-variable-name          acer-orange-pink)
      (acer-fl-constant               acer-green-cyan)
      (acer-fl-warning                acer-warning)
      (acer-fl-punctuation            acer-fg-2)
      (acer-fl-negation-char          acer-light-blue)

      (acer-diff-added                "#c8f0c8")
      (acer-diff-removed              "#f0c8c8")
      (acer-diff-refine-added         "#78f078")
      (acer-diff-refine-removed       "#f07878")
      (acer-diff-header               "#b4b4b4")
      (acer-diff-file-header          "#8c8c8c")
      (acer-diff-context              "#dcdcdc")
      (acer-smerge-base               "#C8C8F0")

      (acer-complementary-a-0         "#4680DE")
      (acer-complementary-a-1         "#DE4680")

      (acer-tetradic-a-0              acer-mode-line-modified)
      (acer-tetradic-a-1              "#D7BBB2")
      (acer-tetradic-a-2              "#B2CED7")
      (acer-tetradic-a-3              "#BBD7B2")

      (acer-tetradic-b-0              "#9D50B4")
      (acer-tetradic-b-1              "#67B450")
      (acer-tetradic-b-2              "#B46B50")
      (acer-tetradic-b-3              "#5099B4"))

  (custom-theme-set-faces
   'guava-themes-acer

   ;; built-in faces
   ;; with unique colors

   ;; default
   `(default ((,acer-class (:foreground ,acer-fg-1 :background ,acer-bg-1))))

   ;; error, warning, success
   `(error ((,acer-class (:foreground ,acer-error :weight bold))))
   `(warning ((,acer-class (:foreground ,acer-warning :weight bold))))
   `(success ((,acer-class (:foreground ,acer-success :weight bold))))

   ;; highlight
   `(highlight ((,acer-class (:background ,acer-highlight))))

   ;; shadow
   `(shadow ((,acer-class (:foreground ,acer-shadow))))

   ;; tooltip
   `(tooltip ((,acer-class (:weight bold :foreground ,acer-black :background ,acer-tooltip :inherit variable-pitch))))

   ;; region
   `(region ((,acer-class (:background ,acer-region-1 :extend t))))
   `(secondary-selection ((,acer-class (:background ,acer-region-2 :extend t))))

   ;; font-lock
   `(font-lock-comment-face ((,acer-class (:foreground ,acer-fl-comment :weight medium))))
   `(font-lock-string-face ((,acer-class (:foreground ,acer-fl-string :weight medium))))
   `(font-lock-keyword-face ((,acer-class (:foreground ,acer-fl-keyword :weight medium))))
   `(font-lock-builtin-face ((,acer-class (:foreground ,acer-fl-builtin :weight medium))))
   `(font-lock-type-face ((,acer-class (:foreground ,acer-fl-type :weight medium))))
   `(font-lock-function-name-face ((,acer-class (:foreground ,acer-fl-function-name :weight medium))))
   `(font-lock-variable-name-face ((,acer-class (:foreground ,acer-fl-variable-name :weight medium))))
   `(font-lock-constant-face ((,acer-class (:foreground ,acer-fl-constant :weight medium))))
   `(font-lock-warning-face ((,acer-class (:foreground ,acer-fl-warning :weight bold))))
   `(font-lock-punctuation-face ((,acer-class (:foreground ,acer-fl-punctuation :weight medium))))
   `(font-lock-negation-char-face ((,acer-class (:foreground ,acer-fl-negation-char :weight medium))))

   ;; built-in faces
   ;; with non-unique colors

   ;; cursor
   `(cursor ((,acer-class (:foreground ,acer-black :background ,acer-mode-line))))

   ;; fringe
   `(fringe ((,acer-class (:foreground ,acer-fl-builtin :background ,acer-bg-1))))
   `(diff-hl-change ((,acer-class (:foreground ,acer-change :background ,acer-change))))
   `(diff-hl-insert ((,acer-class (:foreground ,acer-success :background ,acer-success))))
   `(diff-hl-delete ((,acer-class (:foreground ,acer-error :background ,acer-error))))

   ;; line-number
   `(line-number ((,acer-class (:foreground ,acer-fg-1 :inherit default))))
   `(line-number-current-line ((,acer-class (:foreground ,acer-mode-line :weight bold :inherit (highlight line-number)))))
   `(line-number-minor-tick ((,acer-class (:foreground ,acer-white :background ,acer-tab-2 :inherit line-number))))
   `(line-number-major-tick ((,acer-class (:foreground ,acer-white :background ,acer-tab-3 :inherit line-number))))

   ;; mode-line
   `(mode-line ((,acer-class (:foreground ,acer-white :background ,acer-mode-line
                                          :box ,(if guava-themes-boxed-mode-line
                                                    '(:line-width -1 :style released-button)
                                                  'unspecified)))))
   `(mode-line-inactive ((,acer-class (:background ,acer-mode-line-inactive :inherit mode-line))))
   `(mode-line-emphasis ((,acer-class (:weight bold))))
   `(mode-line-highlight ((,acer-class (:foreground unspecified :background unspecified :box (:line-width 2 :color "grey40" :style released-button)))))
   `(guava-themes-visible-bell ((,acer-class (:foreground ,acer-white :background ,acer-bell))))

   ;; minibuffer
   `(minibuffer-prompt ((,acer-class (:weight bold :foreground ,acer-mode-line))))

   ;; borders
   `(vertical-border ((,acer-class (:foreground ,acer-mode-line))))

   ;; header-line
   `(header-line ((,acer-class (:background ,acer-tab-1 :inherit mode-line))))
   `(which-func ((,acer-class (:weight bold :foreground ,acer-mode-line-modified))))

   ;; tab-bar
   `(tab-bar ((,acer-class (:foreground ,acer-white :background ,acer-tab-2 :weight bold :inherit mode-line))))
   `(tab-bar-tab ((,acer-class (:foreground ,acer-white :background ,acer-tab-1 :inherit tab-bar))))
   `(tab-bar-tab-inactive ((,acer-class (:foreground ,acer-white :background ,acer-tab-2 :inherit tab-bar-tab))))

   ;; tab-line
   `(tab-line ((,acer-class (:foreground ,acer-white :background ,acer-tab-2 :weight bold :inherit mode-line))))
   `(tab-line-tab ((,acer-class (:foreground ,acer-white :background ,acer-tab-2 :inherit tab-line))))
   `(tab-line-tab-current ((,acer-class (:foreground ,acer-white :background ,acer-tab-1 :inherit tab-line-tab))))
   `(tab-line-tab-inactive ((,acer-class (:foreground ,acer-white :background ,acer-tab-2 :inherit tab-line-tab))))
   `(tab-line-tab-inactive-alternate ((,acer-class (:foreground ,acer-white :background ,acer-tab-3 :inherit tab-line-tab))))
   `(tab-line-tab-modified ((,acer-class (:foreground ,acer-mode-line-modified :weight bold))))
   `(tab-line-tab-special ((,acer-class (:slant italic :weight bold))))
   `(tab-line-highlight ((,acer-class (:foreground unspecified :background unspecified :box (:line-width 2 :style released-button)))))

   ;; parentheses
   `(show-paren-match ((,acer-class (:foreground ,acer-black :background ,acer-bell))))
   `(show-paren-mismatch ((,acer-class (:foreground ,acer-black :background ,acer-error :inherit show-paren-match))))

   ;; trailing whitespaces
   `(trailing-whitespace ((,acer-class (:background ,acer-error))))

   ;; links
   `(link ((,acer-class (:foreground ,acer-green-cyan :underline t :weight bold))))
   `(link-visited ((,acer-class (:foreground ,acer-blue :underline t :weight bold))))

   ;; outline
   `(outline-1 ((,acer-class (:foreground ,acer-purple-red :weight medium))))
   `(outline-2 ((,acer-class (:foreground ,acer-deep-green :weight medium))))
   `(outline-3 ((,acer-class (:foreground ,acer-purple :weight medium))))
   `(outline-4 ((,acer-class (:foreground ,acer-deep-blue :weight medium))))
   `(outline-5 ((,acer-class (:inherit outline-1))))
   `(outline-6 ((,acer-class (:inherit outline-2))))
   `(outline-7 ((,acer-class (:inherit outline-3))))
   `(outline-8 ((,acer-class (:inherit outline-4))))

   ;; homoglyph, escape-glyph, nobreak-space (C-x 8 RET "FORM FEED") (C-x 8 RET "NO-BREAK SPACE")
   `(homoglyph ((,acer-class (:foreground ,acer-blue))))
   `(escape-glyph ((,acer-class (:inherit homoglyph))))
   `(nobreak-space ((,acer-class (:box (:line-width (2 . 2)) :inherit homoglyph))))
   `(nobreak-hyphen ((,acer-class (:inherit homoglyph))))

   ;; pulse-highlight-start-face
   ;; M-: (pulse-momentary-highlight-region (point-min) (point-max))
   `(pulse-highlight-start-face ((,acer-class (:background ,acer-light-blue))))

   ;; help-key-binding
   `(help-key-binding ((,acer-class (:foreground ,acer-blue :background "grey96" :box (:line-width (-1 . -1) :color "grey80") :inherit fixed-pitch))))

   ;; diff
   `(diff-added ((,acer-class (:foreground ,acer-black :background ,acer-diff-added :extend t :inherit diff-changed))))
   `(diff-removed ((,acer-class (:foreground ,acer-black :background ,acer-diff-removed :extend t :inherit diff-changed))))
   `(diff-refine-added ((,acer-class (:foreground ,acer-black :background ,acer-diff-refine-added :inherit diff-refine-changed))))
   `(diff-refine-removed ((,acer-class (:foreground ,acer-black :background ,acer-diff-refine-removed :inherit diff-refine-changed))))
   `(diff-header ((,acer-class (:foreground ,acer-black :background ,acer-diff-header :extend t))))
   `(diff-file-header ((,acer-class (:weight bold :foreground ,acer-black :background ,acer-diff-file-header :extend t))))
   `(diff-context ((,acer-class (:foreground ,acer-black :background ,acer-diff-context :extend t))))

   ;; smerge
   `(smerge-lower ((,acer-class (:extend t :inherit diff-added))))
   `(smerge-upper ((,acer-class (:extend t :inherit diff-removed))))
   `(smerge-markers ((,acer-class (:extend t :inherit diff-context))))
   `(smerge-refined-added ((,acer-class (:extend t :inherit diff-refine-added))))
   `(smerge-refined-removed ((,acer-class (:extend t :inherit diff-refine-removed))))
   `(smerge-base ((,acer-class (:foreground ,acer-black :background ,acer-smerge-base :extend t))))

   ;; completions
   `(completions-common-part ((,acer-class (:foreground ,acer-change :weight bold))))
   `(completions-first-difference ((,acer-class (:foreground ,acer-error :weight bold))))

   ;; org-faces
   `(org-todo ((,acer-class (:foreground ,acer-error :weight bold))))
   `(org-done ((,acer-class (:foreground ,acer-success :weight bold))))
   `(org-hide ((,acer-class (:foreground ,acer-bg-1))))
   `(org-table ((,acer-class (:foreground ,acer-deep-green))))
   `(org-table-header ((,acer-class (:inverse-video t :inherit org-table))))
   `(org-date ((,acer-class (:foreground ,acer-light-blue))))
   `(org-date-selected ((,acer-class (:foreground unspecified :inverse-video t :inherit org-date))))
   `(org-headline-todo ((,acer-class (:foreground ,acer-tetradic-b-0))))
   `(org-headline-done ((,acer-class (:foreground ,acer-tetradic-b-3))))
   `(org-document-title ((,acer-class (:inherit font-lock-keyword-face))))
   `(org-document-info-keyword ((,acer-class (:inherit shadow))))
   `(org-meta-line ((,acer-class (:inherit font-lock-comment-face))))

   ;; window-divider
   `(window-divider ((,acer-class (:foreground ,acer-tab-3))))
   `(window-divider-first-pixel ((,acer-class (:inherit window-divider))))
   `(window-divider-last-pixel ((,acer-class (:inherit window-divider))))

   ;; isearch (use "M-x isearch-forward-regexp foo-\([0-9]+\)\([a-z]+\)\([0-9]+\)" to check the group faces)
   `(isearch ((,acer-class (:foreground ,acer-white :background ,acer-tetradic-b-2))))
   `(isearch-fail ((,acer-class (:foreground ,acer-white :background ,acer-error))))
   `(lazy-highlight ((,acer-class (:foreground ,acer-white :background ,acer-tetradic-b-3))))
   `(isearch-group-1 ((,acer-class (:foreground ,acer-white :background ,acer-tetradic-b-0))))
   `(isearch-group-2 ((,acer-class (:foreground ,acer-white :background ,acer-tetradic-b-1))))

   ;; replace (use "M-x occur" to check the match face)
   `(query-replace ((,acer-class (:inherit isearch))))
   `(match ((,acer-class (:inherit lazy-highlight))))

   ;; re-builder
   `(reb-match-0 ((,acer-class (:background ,acer-tetradic-b-0 :foreground ,acer-white))))
   `(reb-match-1 ((,acer-class (:background ,acer-tetradic-b-1 :foreground ,acer-white))))
   `(reb-match-2 ((,acer-class (:background ,acer-tetradic-b-2 :foreground ,acer-white))))
   `(reb-match-3 ((,acer-class (:background ,acer-tetradic-b-3 :foreground ,acer-white))))

   ;; custom
   ;; (progn (setopt custom-raised-buttons nil) (setq mouse-highlight t))
   `(custom-button ((,acer-class (:foreground ,acer-white :background ,acer-mode-line :box (:line-width 2 :style released-button)))))
   `(custom-button-pressed ((,acer-class (:foreground ,acer-white :background ,acer-mode-line :box (:line-width 2 :style pressed-button)))))
   `(custom-button-mouse ((,acer-class (:foreground ,acer-white :background ,acer-tab-3 :box (:line-width 2 :style released-button)))))
   `(custom-button-unraised ((,acer-class (:foreground ,acer-mode-line :inherit underline))))
   `(custom-button-pressed-unraised ((,acer-class (:foreground ,acer-bell :inherit custom-button-unraised))))
   `(custom-comment ((,acer-class (:background ,acer-tab-3))))
   `(custom-variable-tag ((,acer-class (:weight bold :foreground ,acer-tab-2))))
   `(custom-group-tag ((,acer-class (:height 1.2 :inherit (custom-variable-tag variable-pitch)))))
   `(custom-state ((,acer-class (:foreground ,acer-fl-keyword))))

   ;; widget
   `(widget-field ((,acer-class (:background ,acer-tab-3 :box (:line-width (1 . -1) :color "gray46") :extend t))))
   `(widget-single-line-field ((,acer-class (:background ,acer-tab-3))))

   ;; package
   `(package-status-dependency ((,acer-class (:inherit (font-lock-string-face)))))

   ;; icomplete
   `(icomplete-selected-match ((,acer-class (:weight bold :foreground ,acer-mode-line :inherit (highlight)))))
   `(icomplete-first-match ((,acer-class (:weight bold :foreground ,acer-mode-line :inherit (highlight)))))

   ;; bookmark
   `(bookmark-face ((,acer-class (:foreground ,acer-mode-line :distant-foreground unspecified))))
   `(bookmark-menu-bookmark ((,acer-class (:weight bold :inherit bookmark-face))))

   ;; flymake
   `(flymake-note ((,acer-class (:underline (:style wave :color ,acer-success)))))
   `(flymake-warning ((,acer-class (:underline (:style wave :color ,acer-warning)))))
   `(flymake-error ((,acer-class (:underline (:style wave :color ,acer-error)))))

   ;; eww
   `(eww-valid-certificate ((,acer-class (:weight bold :foreground ,acer-success))))
   `(eww-invalid-certificate ((,acer-class (:weight bold :foreground ,acer-error))))
   ;; Example of eww-form-text: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-text ((,acer-class (:foreground ,acer-fg-1 :background ,acer-tab-3 :box (:line-width 1)))))
   ;; Example of eww-form-file: https://html.com/input-type-file/
   `(eww-form-file ((,acer-class (:foreground ,acer-fg-1 :background ,acer-tab-2 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-select: http://savannah.gnu.org/projects/emacs/
   ;; Example of eww-form-select: https://git.kernel.org/pub/scm/editors/uemacs/uemacs.git/
   `(eww-form-select ((,acer-class (:foreground ,acer-fg-1 :background ,acer-tab-1 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-submit: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-submit ((,acer-class (:foreground ,acer-fg-1 :background ,acer-tab-2 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-checkbox: https://en.wikipedia.org/wiki/Main_Page
   `(eww-form-checkbox ((,acer-class (:foreground ,acer-fg-1 :background ,acer-tab-1 :box (:line-width 2 :style released-button)))))
   ;; Example of eww-form-textarea: https://en.wikipedia.org/w/index.php?title=Main_Page&action=edit
   `(eww-form-textarea ((,acer-class (:foreground ,acer-fg-1 :background ,acer-tab-3 :box (:line-width 1 :color ,acer-tab-1)))))


   ;; external packages

   ;; elfeed
   `(elfeed-search-tag-face ((,acer-class (:foreground ,acer-orange-pink))))
   `(elfeed-search-date-face ((,acer-class (:foreground ,acer-deep-green))))
   `(elfeed-search-feed-face ((,acer-class (:foreground ,acer-purple))))
   `(elfeed-search-title-face ((,acer-class (:foreground ,acer-deep-brown))))
   `(elfeed-search-unread-title-face ((,acer-class (:weight bold :foreground ,acer-deep-purple))))
   `(elfeed-search-filter-face ((,acer-class (:weight bold :foreground ,acer-tetradic-a-1))))
   `(elfeed-search-last-update-face ((,acer-class (:weight bold :foreground ,acer-tetradic-a-1))))
   `(elfeed-search-unread-count-face ((,acer-class (:weight bold :foreground ,acer-tetradic-a-1))))

   `(elfeed-show-header-face ((,acer-class (:inherit elfeed-search-date-face))))
   `(elfeed-show-author-face ((,acer-class (:inherit elfeed-search-unread-title-face))))
   `(elfeed-show-title-face ((,acer-class (:inherit elfeed-search-unread-title-face))))
   `(elfeed-show-date-face ((,acer-class (:inherit elfeed-search-feed-face))))
   `(elfeed-show-feed-face ((,acer-class (:inherit elfeed-search-feed-face))))
   `(elfeed-show-tags-face ((,acer-class (:inherit elfeed-search-tag-face))))

   `(elfeed-log-info-level-face ((,acer-class (:foreground ,acer-success))))
   `(elfeed-log-debug-level-face ((,acer-class (:foreground ,acer-change))))
   `(elfeed-log-warn-level-face ((,acer-class (:foreground ,acer-warning))))
   `(elfeed-log-error-level-face ((,acer-class (:foreground ,acer-error))))

   ;; doom-modeline
   ;; doom-modeline-buffer-file-name-style
   `(doom-modeline-project-name ((,acer-class (:foreground ,acer-tetradic-a-3 :inherit (doom-modeline bold italic)))))
   `(doom-modeline-project-dir ((,acer-class (:foreground ,acer-tetradic-a-3 :inherit (doom-modeline bold)))))
   `(doom-modeline-project-root-dir ((,acer-class (:foreground ,acer-tetradic-a-2 :inherit (doom-modeline bold)))))
   `(doom-modeline-project-parent-dir ((,acer-class (:foreground ,acer-tetradic-a-2 :inherit (doom-modeline bold)))))
   `(doom-modeline-buffer-minor-mode ((,acer-class (:foreground ,acer-tetradic-a-1 :inherit (doom-modeline)))))
   `(doom-modeline-buffer-modified ((,acer-class (:foreground ,acer-tetradic-a-0 :inherit (doom-modeline warning bold)))))

   ;; corfu
   `(corfu-default ((,acer-class (:foreground ,acer-fg-1 :background ,acer-bg-1))))
   `(corfu-current ((,acer-class (:foreground unspecified :background unspecified :extend t :inherit highlight))))
   `(corfu-bar ((,acer-class (:background ,acer-shadow))))
   `(corfu-border ((,acer-class (:background ,acer-shadow))))

   ;; orderless
   `(orderless-match-face-0 ((,acer-class (:foreground ,acer-tetradic-b-0 :weight bold))))
   `(orderless-match-face-1 ((,acer-class (:foreground ,acer-tetradic-b-1 :weight bold))))
   `(orderless-match-face-2 ((,acer-class (:foreground ,acer-tetradic-b-2 :weight bold))))
   `(orderless-match-face-3 ((,acer-class (:foreground ,acer-tetradic-b-3 :weight bold))))

   ;; prescient (vertico-prescient-enable-filtering, corfu-prescient-enable-filtering)
   `(prescient-primary-highlight ((,acer-class (:foreground ,acer-complementary-a-0 :weight bold))))
   `(prescient-secondary-highlight ((,acer-class (:foreground ,acer-complementary-a-1 :underline t :weight bold))))

   ;; envrc
   `(envrc-mode-line-error-face ((,acer-class (:inherit error))))
   `(envrc-mode-line-denied-face ((,acer-class (:inherit warning))))
   `(envrc-mode-line-on-face ((,acer-class (:inherit success))))
   `(envrc-mode-line-none-face ((,acer-class (:inherit warning))))
   `(envrc-mode-line-running-face ((,acer-class (:inherit warning))))

   ;; devdocs
   `(devdocs-code-block ((,acer-class (:weight bold :background ,acer-highlight :extend t))))

   ;; pdf-tools
   `(pdf-view-region ((,acer-class (:foreground ,acer-white :background ,acer-tetradic-b-3 :inherit region))))

   ;; idle-highlight
   `(idle-highlight ((,acer-class (:foreground ,acer-white :background ,acer-fl-builtin :inherit region))))

   ;; keycast
   `(keycast-command ((,acer-class (:weight bold))))
   `(keycast-key ((,acer-class (:foreground ,acer-white :background ,acer-tab-3 :box (:line-width -3 :style released-button) :inherit fixed-pitch))))

   ;; nerd-icons
   ;; nerd-icons-completion
   `(nerd-icons-completion-dir-face ((,acer-class (:foreground unspecified :inherit font-lock-function-name-face))))))

(provide-theme 'guava-themes-acer)

;; Local Variables:
;; no-byte-compile: t
;; indent-tabs-mode: nil
;; eval: (when (featurep 'package-lint-flymake) (package-lint-flymake-setup))
;; End:

;;; guava-themes-acer-theme.el ends here
