;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261120.1434"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "eb80476630a4f46741aff932d6a638abd3f19442"
  :revdesc "eb80476630a4"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
