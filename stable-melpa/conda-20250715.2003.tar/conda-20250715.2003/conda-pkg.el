;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conda" "20250715.2003"
  "Work with your conda environments."
  '((emacs    "25.1")
    (pythonic "0.1.0")
    (dash     "2.13.0")
    (s        "1.11.0")
    (f        "0.18.2"))
  :url "http://github.com/necaris/conda.el"
  :commit "1fb984f4d5a72c6a4f87afeefc4007d2b0496000"
  :revdesc "1fb984f4d5a7"
  :keywords '("languages" "local" "tools" "python" "environment" "conda")
  :authors '(("Rami Chowdhury" . "rami.chowdhury@gmail.com"))
  :maintainers '(("Rami Chowdhury" . "rami.chowdhury@gmail.com")))
