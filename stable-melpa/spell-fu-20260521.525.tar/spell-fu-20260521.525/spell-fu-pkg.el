;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spell-fu" "20260521.525"
  "Fast & light spelling highlighter."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spell-fu"
  :commit "e1bb525d726eab0146f112a9c80ec79d1e6be3d9"
  :revdesc "e1bb525d726e"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
