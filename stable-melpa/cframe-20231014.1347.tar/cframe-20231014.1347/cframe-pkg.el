(define-package "cframe" "20231014.1347" "Customize a frame and fast switch size and positions"
  '((emacs "26")
    (buffer-manage "0.11")
    (dash "2.17.0"))
  :commit "054f4f8f69a56cce3f834daa9ecf9d13bc348055" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("frames")
  :url "https://github.com/plandes/cframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
