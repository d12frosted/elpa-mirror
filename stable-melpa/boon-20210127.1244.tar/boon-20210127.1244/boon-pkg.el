(define-package "boon" "20210127.1244" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (expand-region "0.10.0")
    (dash "2.12.0")
    (multiple-cursors "1.3.0"))
  :commit "347e26a212c9c533f111c97978a951747ea8474b")
;; Local Variables:
;; no-byte-compile: t
;; End:
