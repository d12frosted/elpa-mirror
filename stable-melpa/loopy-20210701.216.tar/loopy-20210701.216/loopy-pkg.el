(define-package "loopy" "20210701.216" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "27df47157a0a1753065172a346a2ffeb1778a99c" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
