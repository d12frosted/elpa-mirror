;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-travis" "20140405.2327"
  "Insert/Export the link of Travis CI on org-mode."
  '((org "7"))
  :url "https://github.com/aki2o/org-link-travis"
  :commit "596615ad8373d9090bd4138da683524f0ad0bda5"
  :revdesc "596615ad8373"
  :keywords '("org")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
