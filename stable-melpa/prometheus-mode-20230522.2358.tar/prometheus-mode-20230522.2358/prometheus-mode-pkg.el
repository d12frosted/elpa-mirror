;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prometheus-mode" "20230522.2358"
  "Major modes for Prometheus files."
  '((emacs "26.1"))
  :url "https://gitlab.com/peterhoeg/prometheus-mode"
  :commit "df7f1b13a432594594a967f0b2ff0f3b1ba41656"
  :revdesc "df7f1b13a432"
  :keywords '("languages")
  :authors '(("Peter Hoeg" . "(peter@hoeg.com)"))
  :maintainers '(("Peter Hoeg" . "(peter@hoeg.com)")))
