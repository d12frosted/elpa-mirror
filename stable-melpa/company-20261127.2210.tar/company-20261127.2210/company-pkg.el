;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20261127.2210"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "0ad4a43c43ce56c029bc81ff50f567702d98ebf3"
  :revdesc "0ad4a43c43ce"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
