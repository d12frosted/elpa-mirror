;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20250527.1330"
  "Support for Org links to Magit buffers."
  '((emacs  "27.1")
    (compat "30.0.2.0")
    (magit  "4.3.2")
    (org    "9.7.26"))
  :url "https://github.com/magit/orgit"
  :commit "85b074a3e7069a07f5c0bb042d544de9349a4ea0"
  :revdesc "85b074a3e706"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
