;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20261015.1713"
  "30 new custom blocks & 34 link types for Org-mode."
  '((s     "1.13.1")
    (dash  "2.18.1")
    (emacs "27.1")
    (org   "9.6")
    (lf    "26.10.1")
    (seq   "2.0"))
  :url "https://alhassy.github.io/org-special-block-extras"
  :commit "f3f51c58da0c63515730e8e56aa5f1859645482f"
  :revdesc "f3f51c58da0c"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
