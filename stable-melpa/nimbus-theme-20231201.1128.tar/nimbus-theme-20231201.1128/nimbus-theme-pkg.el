(define-package "nimbus-theme" "20231201.1128" "Nimbus dark theme"
  '((emacs "24.1"))
  :commit "623c458d30a038ca36c3267030982ed6c9e92f7d" :authors
  '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers
  '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainer
  '("Marcin Swieczkowski" . "marcin@realemail.net")
  :keywords
  '("faces")
  :url "https://github.com/mrcnski/nimbus-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
