;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dim-autoload" "20260101.1826"
  "Dim or hide autoload cookie lines."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/dim-autoload"
  :commit "503eee682c2fcc24e05a765ac28e847be950bad9"
  :revdesc "503eee682c2f"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.dim-autoload@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.dim-autoload@jonas.bernoulli.dev")))
