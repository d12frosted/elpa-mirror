;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20241220.1052"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "3836cff15393fe1dc1addb4fe46b11878dab4891"
  :revdesc "3836cff15393"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
