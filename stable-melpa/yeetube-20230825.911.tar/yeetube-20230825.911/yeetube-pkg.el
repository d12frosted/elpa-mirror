(define-package "yeetube" "20230825.911" "YouTube & Invidious Front End"
  '((emacs "27.2"))
  :commit "e8a362738396e7c6821e424950d634a58bde0adc" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
