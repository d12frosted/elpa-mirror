(define-package "spdx" "20220919.207" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "36ae026d53a782dc90cc7079ef107a4c80095b01" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
