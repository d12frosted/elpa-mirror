;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql-to-org" "20210622.447"
  "Minor mode to output the results of mysql queries to org tables."
  '((emacs "24.3")
    (s     "1.11.0"))
  :url "https://github.com/mallt/mysql-to-org-mode"
  :commit "c5eefc71200f2e1d0d67a13ed897b3cdfa835117"
  :revdesc "c5eefc71200f"
  :authors '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com"))
  :maintainers '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com")))
