;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20261128.1346"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "3eea9eb5353dbe8c25db76990fb0f4875daeb610"
  :revdesc "3eea9eb5353d"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
