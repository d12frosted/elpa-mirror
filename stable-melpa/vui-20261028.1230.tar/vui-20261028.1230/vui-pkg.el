;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261028.1230"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "b05a8c1fa96669fdaf251c206dd6348c934a5484"
  :revdesc "b05a8c1fa966"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
