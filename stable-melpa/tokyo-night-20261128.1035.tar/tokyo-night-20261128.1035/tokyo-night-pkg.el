;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20261128.1035"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "043338621fe63142f43a65fc98f4684a91fbece9"
  :revdesc "043338621fe6"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
