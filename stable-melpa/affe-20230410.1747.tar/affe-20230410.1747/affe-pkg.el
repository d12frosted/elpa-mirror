(define-package "affe" "20230410.1747" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.33"))
  :commit "765c176573af3878797655fa27c7977c85c61bbf" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
