;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260725.1321"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "bedf71257b29a693be9fe03faadd9a1070c3dc5d"
  :revdesc "bedf71257b29"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
