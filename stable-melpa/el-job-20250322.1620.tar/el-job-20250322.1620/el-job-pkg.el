;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250322.1620"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "23a698822e44c73843a59180745bbf0a9b6712a6"
  :revdesc "23a698822e44"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
