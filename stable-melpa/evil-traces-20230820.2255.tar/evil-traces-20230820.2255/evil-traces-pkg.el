;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-traces" "20230820.2255"
  "Visual hints for `evil-ex'."
  '((emacs "25.1")
    (evil  "1.2.13"))
  :url "https://github.com/mamapanda/evil-traces"
  :commit "3b4e08c522d1a4c6f458ab5dc21914fd307333a1"
  :revdesc "3b4e08c522d1"
  :keywords '("emulations" "evil" "visual")
  :authors '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainers '(("Daniel Phan" . "daniel.phan36@gmail.com")))
