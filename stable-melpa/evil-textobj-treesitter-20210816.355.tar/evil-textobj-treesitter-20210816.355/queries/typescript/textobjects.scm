; inherits: (javascript)
