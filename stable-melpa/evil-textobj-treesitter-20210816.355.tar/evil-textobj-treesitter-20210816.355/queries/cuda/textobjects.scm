; inherits: cpp
