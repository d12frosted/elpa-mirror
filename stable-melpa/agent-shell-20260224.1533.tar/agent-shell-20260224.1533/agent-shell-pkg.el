;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260224.1533"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7f9e67da4593ed927901bbf2ae5025da25e98979"
  :revdesc "7f9e67da4593")
