;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260616.503"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "1ec19332b30c8f96c8983c538d831b82ea850891"
  :revdesc "1ec19332b30c"
  :keywords '("data" "extensions"))
