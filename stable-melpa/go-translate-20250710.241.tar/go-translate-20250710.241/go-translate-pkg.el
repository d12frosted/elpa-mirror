;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250710.241"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "b93c7a0e1c307dda58cda3a1f324af4b10165f7e"
  :revdesc "b93c7a0e1c30"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
