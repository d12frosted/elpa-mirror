(define-package "helm-core" "20220405.2028" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "501d12109c91afe1d82b5bfcd63da6a3ab79e24a" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
