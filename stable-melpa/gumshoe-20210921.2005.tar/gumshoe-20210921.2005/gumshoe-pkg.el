(define-package "gumshoe" "20210921.2005" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "c79d92c3335329524362cb309a1a7c12d7f57617" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
