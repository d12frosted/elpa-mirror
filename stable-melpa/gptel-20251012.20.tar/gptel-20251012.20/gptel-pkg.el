;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251012.20"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "1b15f3065e2c4646790a0727ee45ccb6c2d0804b"
  :revdesc "1b15f3065e2c"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
