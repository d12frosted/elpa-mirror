;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20261104.204"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "dff1c73e97959a21d5c00b4b2bc5fd2a72ba9fb2"
  :revdesc "dff1c73e9795"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
