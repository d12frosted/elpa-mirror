;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiki-nav" "20230304.2212"
  "Simple file navigation using [[WikiStrings]]."
  '((button-lock "1.0.2")
    (nav-flash   "1.0.0"))
  :url "https://github.com/rolandwalker/button-lock"
  :commit "1f7a89ca05b6167af7d1337ad23a5d923486caac"
  :revdesc "1f7a89ca05b6"
  :keywords '("mouse" "button" "hypermedia" "navigation")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
