(define-package "helm" "20230812.727" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.3")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "8ca4af16d7f8b79f667a3d1f2259eb5cc4a24886" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
