;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seml-mode" "20260516.826"
  "Major-mode for SEML, S-Expression Markup Language, file."
  '((emacs          "27.1")
    (impatient-mode "1.1")
    (htmlize        "1.5")
    (web-mode       "16.0"))
  :url "https://github.com/conao3/seml-mode.el"
  :commit "ec1efc3fb1a3d831a744bdaa0beb4ac5fcf59d2c"
  :revdesc "ec1efc3fb1a3"
  :keywords '("lisp" "html")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
