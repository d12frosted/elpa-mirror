(define-package "clojure-ts-mode" "20230830.1529" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "4e18177a568027b464ea794c166d2eb4ebe080fc" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
