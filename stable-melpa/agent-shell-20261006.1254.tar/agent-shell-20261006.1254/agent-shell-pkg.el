;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261006.1254"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "f44c96b2ab577065d5f5409629b4df588af88433"
  :revdesc "f44c96b2ab57")
