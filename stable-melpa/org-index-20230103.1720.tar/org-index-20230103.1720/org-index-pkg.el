(define-package "org-index" "20230103.1720" "No description available."
  '((org "9.3")
    (dash "2.12")
    (s "1.12")
    (emacs "26.3"))
  :commit "d919b9e2ef8c0f814455b82ffea080e872b89c72" :authors
  '(("Marc Ihm" . "1@2484.de"))
  :maintainers
  '(("Marc Ihm" . "1@2484.de"))
  :maintainer
  '("Marc Ihm" . "1@2484.de")
  :url "https://github.com/marcIhm/org-index")
;; Local Variables:
;; no-byte-compile: t
;; End:
