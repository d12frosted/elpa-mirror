(define-package "forge" "20230216.1755" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "29.1.3.4")
    (closql "1.2.0")
    (dash "2.19.1")
    (emacsql-sqlite "3.0.0")
    (ghub "20220621")
    (let-alist "1.0.6")
    (magit "20220621")
    (markdown-mode "2.4")
    (transient "0.3.6")
    (yaml "0.3.5"))
  :commit "f4aceb35f9d87277e23ee2017e49d11ef89bb7a5" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
