(define-package "gptel" "20230411.549" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "f218388d4dcd88aa339872c797f4805a66d10217" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
