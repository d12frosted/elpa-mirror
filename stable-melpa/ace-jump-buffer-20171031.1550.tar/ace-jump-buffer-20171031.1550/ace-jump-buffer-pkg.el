;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ace-jump-buffer" "20171031.1550"
  "Fast buffer switching extension to `avy'."
  '((avy  "0.4.0")
    (dash "2.4.0"))
  :url "https://github.com/waymondo/ace-jump-buffer"
  :commit "ae5be0415c823f7bb66833aa4af2180d4cf99cef"
  :revdesc "ae5be0415c82"
  :authors '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainers '(("Justin Talbott" . "justin@waymondo.com")))
