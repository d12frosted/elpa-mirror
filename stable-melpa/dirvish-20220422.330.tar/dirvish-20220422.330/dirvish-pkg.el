(define-package "dirvish" "20220422.330" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "a7f3759a2dd5333e0bd8def3a73fb9b681b77374" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
