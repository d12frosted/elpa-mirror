(define-package "embark" "20210127.2047" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "562c6c8541702beac711768f2d78fb0027e3f78e" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
