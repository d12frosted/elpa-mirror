;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260714.2214"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.2"))
  :url "https://github.com/jojojames/fzfa"
  :commit "809f87b988a9ef0f061addff4fcef7d85902515c"
  :revdesc "809f87b988a9"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
