;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rewriting-pcase" "20230419.23"
  "Support for rewriting sexps in source code."
  '((emacs "27.1"))
  :url "https://github.com/owinebar/emacs-rewriting-pcase"
  :commit "3a2efb79bfc68629bd20a8bc1770c8f6d24575fa"
  :revdesc "3a2efb79bfc6"
  :keywords '("extensions" "lisp"))
