;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260319.424"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e275cf8d8e50c6e59cb93e5c77b9930d6a8687e2"
  :revdesc "e275cf8d8e50"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
