(define-package "company" "20230104.1704" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "a1c66c5bc57728a3597015ebe5e169146f8620d1" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
