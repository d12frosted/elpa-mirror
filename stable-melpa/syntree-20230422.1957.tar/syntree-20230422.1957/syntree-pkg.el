(define-package "syntree" "20230422.1957" "Draw plain text constituency trees"
  '((emacs "27.1")
    (org "9.2"))
  :commit "21ca247722e0d82e8f6eeb280014c61b2ded7f27" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/syntree")
;; Local Variables:
;; no-byte-compile: t
;; End:
