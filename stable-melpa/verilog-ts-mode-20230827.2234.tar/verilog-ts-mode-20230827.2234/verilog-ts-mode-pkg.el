(define-package "verilog-ts-mode" "20230827.2234" "Verilog Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "e7e1a3270c75aaa95a11e39d6f3d951306555aa1" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
