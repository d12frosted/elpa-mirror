(define-package "magit-section" "20220502.2245" "Sections for read-only buffers."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (dash "20210826"))
  :commit "547ad9e39341c9a9dc37b2c88acb487d737a8e3b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
