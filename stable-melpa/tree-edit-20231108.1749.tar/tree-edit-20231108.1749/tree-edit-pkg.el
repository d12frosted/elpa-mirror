(define-package "tree-edit" "20231108.1749" "A library for structural refactoring and editing"
  '((emacs "29.0")
    (dash "2.19")
    (reazon "0.4.0")
    (s "0.0.0"))
  :commit "5f12ca6f366aad2c311bac09817f079900dce8d2" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainers
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
