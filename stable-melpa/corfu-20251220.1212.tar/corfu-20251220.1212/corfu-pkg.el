;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251220.1212"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "edd990d7411cbd1c1ab19c16b4ed4112ad5e1d41"
  :revdesc "edd990d7411c"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
