(define-package "loopy" "20210612.214" "A looping macro"
  '((emacs "27.1"))
  :commit "fc3613f0d596013e6f697d957ff2c01839e81db1" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
