;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260516.1435"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "d932119b4cfca4826c3ab44c6080e2bc17b31493"
  :revdesc "d932119b4cfc"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
