;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260204.1724"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "e8bb43adf1e7d8c0fb55bda9414a0591e2b42054"
  :revdesc "e8bb43adf1e7"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
