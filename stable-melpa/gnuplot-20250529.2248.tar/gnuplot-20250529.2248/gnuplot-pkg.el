;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250529.2248"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "5a72806bac991a7dcc5a12529d4698fc01f33a8d"
  :revdesc "5a72806bac99"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
