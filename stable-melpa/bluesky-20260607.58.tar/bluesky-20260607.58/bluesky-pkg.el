;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesky" "20260607.58"
  "A Bluesky client."
  '((emacs "30.1")
    (plz   "0.9.0")
    (futur "1.7")
    (vui   "1.0.0"))
  :url "https://github.com/ahyatt/emacs-bluesky"
  :commit "9e08a916a921526651a40165924ce3ab77047e17"
  :revdesc "9e08a916a921"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
