(define-package "evil-matchit" "20210819.5" "Vim matchit ported to Evil"
  '((evil "1.14.0")
    (emacs "25.1"))
  :commit "24a95751f48fb64246de15278734e0179c9f622f" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
