(define-package "lfe-mode" "20230102.1421" "Lisp Flavoured Erlang mode" 'nil :commit "c119a9216f1028ead780b7ae2b03746295ce8aad")
;; Local Variables:
;; no-byte-compile: t
;; End:
