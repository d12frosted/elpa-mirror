(define-package "mini-echo" "20240529.702" "Echo buffer status in minibuffer window"
  '((emacs "29.1")
    (dash "2.19.1")
    (hide-mode-line "1.0.3"))
  :commit "029ce410aff7f8c15424c837853acfafc35b732f" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
