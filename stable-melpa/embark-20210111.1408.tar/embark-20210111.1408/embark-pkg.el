(define-package "embark" "20210111.1408" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "e694898021459c6e9e4fd0127c948fcb35817036" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
