(define-package "boon" "20230410.1115" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "9b4260fbab2d3cc6f58a5c1360a235a03de4f0e1")
;; Local Variables:
;; no-byte-compile: t
;; End:
