(define-package "ph" "20130312.1837" "A global minor mode for managing multiple projects."
  '((emacs "24.3"))
  :commit "ed45c371642e313810b56c45af08fdfbd71a7dfe")
;; Local Variables:
;; no-byte-compile: t
;; End:
