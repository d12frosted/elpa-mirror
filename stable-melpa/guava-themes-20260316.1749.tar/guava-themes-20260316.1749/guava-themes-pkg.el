;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260316.1749"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "41745d822315baf572f08365145d037962731681"
  :revdesc "41745d822315"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
