;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251029.706"
  "An Org-social client."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "b5882bf072f649b9c976d48c63734b4b0644c059"
  :revdesc "b5882bf072f6"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
