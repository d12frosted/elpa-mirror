;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gpastel" "20231030.713"
  "Integrates GPaste with the kill-ring."
  '((emacs "25.1"))
  :url "https://github.com/DamienCassou/gpastel"
  :commit "d35505abb1e38ddda61440b033ebd4decac7a25c"
  :revdesc "d35505abb1e3"
  :keywords '("tools")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
