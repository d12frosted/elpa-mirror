(define-package "zotra" "20230922.255" "Library to use Zotero translators"
  '((emacs "27.1"))
  :commit "632ddc6aa43b8dd8394ce5c88024f5f260b6f213" :authors
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainers
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainer
  '("Mohammad Pedramfar <https://github.com/mpedramfar>")
  :url "https://github.com/mpedramfar/zotra")
;; Local Variables:
;; no-byte-compile: t
;; End:
