(define-package "teleport" "20230912.2229" "Integration for tsh (goteleport.com)"
  '((emacs "27.1")
    (dash "2.18.0"))
  :commit "831db908f35f2d398be39845bbb1a8400b1dd3bd" :authors
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainers
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainer
  '("Caramel Hooves" . "caramel.hooves@protonmail.com")
  :keywords
  '("tools")
  :url "https://github.com/caramelhooves/teleport.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
