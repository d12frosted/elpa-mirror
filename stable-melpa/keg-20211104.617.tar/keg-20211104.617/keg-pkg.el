(define-package "keg" "20211104.617" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "bf2457d128dca207b3fb00a2660eb662327f877b" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
