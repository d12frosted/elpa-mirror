;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260724.1851"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "7600a4309440a7448fcd37d040eb6d0b41e4cdb6"
  :revdesc "7600a4309440"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
