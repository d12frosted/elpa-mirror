;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "terraform-docs" "20241216.649"
  "Generate Terraform modules documentation with terraform-docs."
  '((emacs "27.1"))
  :url "https://github.com/loispostula/terraform-docs.el"
  :commit "c70d19c4007d81244b276b9d150cdfe3c2e7b8dd"
  :revdesc "c70d19c4007d"
  :keywords '("terraform" "tools" "docs")
  :authors '(("Lois Postula" . "lois@postu.la"))
  :maintainers '(("Lois Postula" . "lois@postu.la")))
