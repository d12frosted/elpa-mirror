;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-nl-break-undo" "20240921.953"
  "Break evil's undo sequence on CR."
  '((evil "0"))
  :url "https://github.com/VanLaser/evil-nl-break-undo"
  :commit "fabd063c097f1b23112a29936dc5be5214153a0d"
  :revdesc "fabd063c097f"
  :authors '(("VanLaser" . "Gabriel.Lazar@com.utcluj.ro"))
  :maintainers '(("VanLaser" . "Gabriel.Lazar@com.utcluj.ro")))
