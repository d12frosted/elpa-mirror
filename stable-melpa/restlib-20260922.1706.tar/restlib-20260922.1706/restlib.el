;;; restlib.el --- Utility library for building REST clients -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Charles Y. Choi

;; Author: Charles Y. Choi <kickingvegas@gmail.com>
;; URL: https://github.com/kickingvegas/restlib
;; Keywords: tools
;; Package-Version: 20260922.1706
;; Package-Revision: b1da37d9296c
;; Package-Requires: ((emacs "30.1"))

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; restlib is a utility library to support building REST clients in GNU Emacs.

;; The functions provided by restlib are organized into the following areas:

;; - Network communication
;; - URL components
;; - JSON handling

;; Refer to the info “restlib API Reference” for more information.

;;; Code:

(require 'url)
(require 'url-http)
(require 'map)

(defvar url-http-end-of-headers)


;;; Network

(defun restlib-fetch-json (url)
  "Synchronously fetch the URL returning a deserialized JSON response.

- URL: string or URL object

The following is done with a URL whose response is in JSON:

1. Synchronously fetch the URL.

2. Upon success, deserialize the JSON into an Elisp `hash-table', with
JSON null values converted to nil.

3. Return the JSON `hash-table' object.

Any failure in the HTTP request will raise an `error' message. Refer to
the Info node `(elisp) Handling Errors' for guidance on handling this
condition."
  (let ((data-buffer (url-retrieve-synchronously url)))
    (if (not data-buffer)
        (error "Failed to fetch data from %s" url)
      (unwind-protect
          (with-current-buffer data-buffer
            ;; Move point past the HTTP metadata headers
            (goto-char url-http-end-of-headers)
            ;; Parse the remaining JSON buffer into a hash-table
            (json-parse-buffer :object-type 'hash-table
                               :null-object nil))
        ;; Always kill the downloaded network buffer to prevent memory leaks
        (kill-buffer data-buffer)))))


;;; URL Components

(defun restlib-url-add-query-items (url items &optional obj-result semicolons keep-empty)
  "Add query ITEMS to URL.

- URL: string or URL object
- ITEMS: list of lists as specified for `url-build-query-string'
- OBJ-RESULT: if non-nil then return URL object, else string
- SEMICOLONS: if non-nil then use ‘;’ as separator
- KEEP-EMPTY: if non-nil then render ‘key=’ instead of ‘key’

In ITEMS, values are expected to not be URL encoded as
`url-build-query-string' will do the encoding.

If URL has an existing query fragment, then ITEMS will be naively
appended to it, with no regard for duplicate keys."

  (let* ((url (restlib-url-parse url))
         (old-items (restlib-url-query-items url))
         (items (if old-items
                    (append old-items items)
                  items))
         (query (url-build-query-string items semicolons keep-empty))
         (url (restlib-url-remove-query url t))
         (filename (url-filename url))
         (new-filename (if filename
                           (format "%s?%s" filename query)
                         (format "?%s" query))))
    (setf (url-filename url) new-filename)

    (if obj-result
        url
      (url-recreate-url url))))

(defun restlib-url-parse (url)
  "Convenience function to return a parsed object given URL string.

- URL: string or URL object

If the URL is already a parsed object then it will pass through."
  (if (stringp url)
      (url-generic-parse-url url)
    url))

(defun restlib-url-filename (url)
  "Get URL filename.

- URL: string or URL object

Extract filename via `url-filename'."
  (let ((url (restlib-url-parse url)))
    (url-filename url)))

(defun restlib-url-path (url)
  "Get URL path.

- URL: string or URL object

Extract only path from URL, omitting query parameters and fragment."
  (let* ((filename (restlib-url-filename url))
         (has-query (string-search "?" filename)))
    (if has-query
        (substring filename 0 has-query)
      filename)))

(defun restlib-url-query (url)
  "Get URL query.

- URL: string or URL object

Extract query as string from URL."
  (let* ((filename (restlib-url-filename url))
         (has-query (string-search "?" filename)))
    (if has-query
        (substring filename (+ has-query 1)))))

(defun restlib-url-query-items (url)
  "Extract query items from URL.

- URL: string or URL object

Extract query items using `url-parse-query-string'."
  (let ((query (restlib-url-query url)))
    (if query
        (url-parse-query-string query))))

(defun restlib-url-remove-query (url &optional obj-result)
  "Remove query from URL.

- URL: string or URL object
- OBJ-RESULT: if non-nil then return URL object"

  (let* ((url (restlib-url-parse url))
         (filename (url-filename url))
         (index (string-search "?" filename)))
    (if index
        (setf (url-filename url) (substring filename 0 index)))

    (if obj-result
        url
      (url-recreate-url url))))


;;; JSON

(defun restlib-json-empty-string-to-nil (obj key)
  "Convert empty string value for KEY to nil in OBJ."
  (let ((value (map-elt obj key)))
    (if (and value (stringp value) (string-equal value ""))
        (map-put! obj key nil)
      (map-put! obj key value))))


(provide 'restlib)
;;; restlib.el ends here
