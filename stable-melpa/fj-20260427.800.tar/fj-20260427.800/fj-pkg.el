;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20260427.800"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "c4030fda8a7b52ebb290069028655dfb00a65dfb"
  :revdesc "c4030fda8a7b"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
