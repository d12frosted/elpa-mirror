;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trashed" "20261103.1218"
  "Viewing/editing system trash can."
  '((emacs "27.1"))
  :url "https://github.com/shingo256/trashed"
  :commit "518fb5e15e27b80721d20e5095924bc110e0a131"
  :revdesc "518fb5e15e27"
  :keywords '("files" "convenience" "unix")
  :authors '(("Shingo Tanaka" . "shingo.fg8@gmail.com"))
  :maintainers '(("Shingo Tanaka" . "shingo.fg8@gmail.com")))
