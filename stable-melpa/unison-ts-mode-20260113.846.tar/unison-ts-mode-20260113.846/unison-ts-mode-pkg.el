;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-ts-mode" "20260113.846"
  "Tree-sitter support for Unison."
  '((emacs "29.1"))
  :url "https://github.com/fmguerreiro/unison-ts-mode"
  :commit "7f0ed7c03d98fefc88c420bc49c423c66db186d7"
  :revdesc "7f0ed7c03d98"
  :keywords '("languages" "unison" "tree-sitter")
  :authors '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com"))
  :maintainers '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com")))
