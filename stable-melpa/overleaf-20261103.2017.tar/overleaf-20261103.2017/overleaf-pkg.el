;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20261103.2017"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "20123a6b8d4fc697690b8f97e0bff9448ea6ff0b"
  :revdesc "20123a6b8d4f"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
