(define-package "caml" "20210824.904" "OCaml code editing commands for Emacs"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "f04c2e495c0bdb388dd7302f345235980c962ada" :authors
  '(("Jacques Garrigue" . "garrigue@kurims.kyoto-u.ac.jp")
    ("Ian T Zimmerman" . "itz@rahul.net")
    ("Damien Doligez" . "damien.doligez@inria.fr"))
  :maintainer
  '("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
  :keywords
  '("ocaml")
  :url "https://github.com/ocaml/caml-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
