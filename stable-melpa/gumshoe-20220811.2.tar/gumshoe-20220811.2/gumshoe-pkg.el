(define-package "gumshoe" "20220811.2" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "f3cb8bad6d688f3892d70a9b0f8d6acf0380bfff" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
