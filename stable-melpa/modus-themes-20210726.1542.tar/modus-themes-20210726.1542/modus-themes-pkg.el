(define-package "modus-themes" "20210726.1542" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "114ba80b96c0bfbf619a1919af8db6023ee60f7c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
