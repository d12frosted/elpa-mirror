(define-package "fanyi" "20211011.1204" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "ad02e1d76629e9b0c24c46f6705f3bcba26eaaea" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
