;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260619.1917"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "27eace47ca483c24c5b404e2407e1972e01aad60"
  :revdesc "27eace47ca48"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
