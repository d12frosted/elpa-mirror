;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20260105.1850"
  "An Org-social client for Emacs."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "f3e9f25da7c0325d05f370470e948e53edd4d5f9"
  :revdesc "f3e9f25da7c0"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
