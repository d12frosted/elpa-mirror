(define-package "rmsbolt" "20220427.1619" "A compiler output viewer"
  '((emacs "25.1"))
  :commit "f3fe3d24dbc8f7d0a166385c8cdadc92e22575a7" :authors
  '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainer
  '("Jay Kamat" . "jaygkamat@gmail.com")
  :keywords
  '("compilation" "tools")
  :url "http://gitlab.com/jgkamat/rmsbolt")
;; Local Variables:
;; no-byte-compile: t
;; End:
