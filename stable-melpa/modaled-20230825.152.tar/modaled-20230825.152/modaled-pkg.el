(define-package "modaled" "20230825.152" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "98f58e6857877bc1b593e86ee0ee61ad64daaf24" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
