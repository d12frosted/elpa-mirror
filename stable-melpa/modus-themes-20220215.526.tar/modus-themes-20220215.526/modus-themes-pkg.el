(define-package "modus-themes" "20220215.526" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "802041636904df5fa463df579cf89bcdc2a1b410" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
