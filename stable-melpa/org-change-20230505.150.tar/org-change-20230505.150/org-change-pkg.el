(define-package "org-change" "20230505.150" "Annotate changes in org-mode files"
  '((emacs "26.1")
    (org "9.3"))
  :commit "45898a67701ade93f310db8e5820b8bfc4a28846" :keywords
  '("wp" "convenience")
  :url "https://github.com/drghirlanda/org-change")
;; Local Variables:
;; no-byte-compile: t
;; End:
