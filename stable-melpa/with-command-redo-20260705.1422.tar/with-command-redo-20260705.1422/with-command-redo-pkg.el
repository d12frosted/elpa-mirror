;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-command-redo" "20260705.1422"
  "Repeat commands with automatic undo."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-with-command-redo"
  :commit "a792d4880627bff5b229b2cad58cc56b9f559325"
  :revdesc "a792d4880627"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
