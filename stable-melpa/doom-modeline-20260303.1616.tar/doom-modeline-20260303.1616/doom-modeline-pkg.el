;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260303.1616"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "bcf8cc0365f23da96cb05cba06faa954cfac7d24"
  :revdesc "bcf8cc0365f2"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
