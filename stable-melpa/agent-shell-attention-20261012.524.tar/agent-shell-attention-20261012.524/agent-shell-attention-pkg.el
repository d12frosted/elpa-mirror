;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-attention" "20261012.524"
  "Mode-line attention tracker for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.47.1"))
  :url "https://github.com/ultronozm/agent-shell-attention.el"
  :commit "aaf599121445ead597a14da62bad580c8897ee6c"
  :revdesc "aaf599121445"
  :keywords '("convenience")
  :authors '(("Paul D. Nelson" . "ultrono@gmail.com"))
  :maintainers '(("Paul D. Nelson" . "ultrono@gmail.com")))
