;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bitpack" "20230417.2032"
  "Bit packing functions."
  '((emacs "24.3"))
  :url "https://github.com/skeeto/bitpack"
  :commit "38d000646b81ce52fcb90a0747059a15264e112b"
  :revdesc "38d000646b81"
  :keywords '("c" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
