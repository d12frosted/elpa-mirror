;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260202.1618"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "b1a8e91221abd86b5bfa4b83104e6cbc5f1702aa"
  :revdesc "b1a8e91221ab"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
