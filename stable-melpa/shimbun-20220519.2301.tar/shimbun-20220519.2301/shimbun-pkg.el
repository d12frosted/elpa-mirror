(define-package "shimbun" "20220519.2301" "interfacing with web newspapers" 'nil :commit "98086b3e23b483e28221b5e3de0b1bdd429e6a72" :authors
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
    ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
    ("Yuuichi Teranishi " . "teranisi@gohome.org")
    ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainer
  '("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  '("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
