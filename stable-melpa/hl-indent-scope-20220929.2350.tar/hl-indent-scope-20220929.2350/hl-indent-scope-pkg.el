(define-package "hl-indent-scope" "20220929.2350" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "6220879d7b8b8fdb2274555b401890f7ae8d48c0" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
