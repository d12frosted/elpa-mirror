(define-package "helm-perldoc" "20140702.133" "perldoc with helm interface"
  '((helm "1.0")
    (deferred "0.3.1")
    (cl-lib "0.5"))
  :commit "18645f2065a07acce2c6b50a2f9d7a2554e532a3" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-helm-perldoc")
;; Local Variables:
;; no-byte-compile: t
;; End:
