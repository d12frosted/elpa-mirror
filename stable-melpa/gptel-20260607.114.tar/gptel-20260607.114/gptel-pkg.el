;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260607.114"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "c35b7d83ad9ee66d86c3139b47e588965efe21cc"
  :revdesc "c35b7d83ad9e"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
