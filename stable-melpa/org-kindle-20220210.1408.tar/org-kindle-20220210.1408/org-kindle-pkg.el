;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-kindle" "20220210.1408"
  "Send org link file to ebook reader."
  '((emacs  "25")
    (cl-lib "0.5")
    (seq    "2.20"))
  :url "https://repo.or.cz/org-kindle.git"
  :commit "fadcfd62e254d0c45e87d63128a82a08ae21869a"
  :revdesc "fadcfd62e254"
  :keywords '("org" "link" "ebook" "kindle" "epub" "azw3" "mobi")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
