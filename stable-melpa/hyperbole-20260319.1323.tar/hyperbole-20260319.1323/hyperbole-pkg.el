;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260319.1323"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "fd1c0b04c2ca6b6a62e0bd311a31e0221200834b"
  :revdesc "fd1c0b04c2ca"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
