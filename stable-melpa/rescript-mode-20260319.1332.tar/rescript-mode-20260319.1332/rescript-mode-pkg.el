;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rescript-mode" "20260319.1332"
  "A major mode for editing ReScript."
  '((emacs "26.1"))
  :url "https://github.com/jjlee/rescript-mode"
  :commit "b69440f23faae21cfc3530008b440df88840619a"
  :revdesc "b69440f23faa"
  :keywords '("languages" "rescript")
  :authors '(("Karl Landstrom" . "karl.landstrom@brgeight.se")
             ("Daniel Colascione" . "dancol@dancol.org")
             ("John Lee" . "jjl@pobox.com"))
  :maintainers '(("John Lee" . "jjl@pobox.com")))
