;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "navigel" "20251125.1931"
  "Facilitate the creation of tabulated-list based UIs."
  '((emacs   "25.1")
    (tablist "1.0"))
  :url "https://github.com/DamienCassou/navigel"
  :commit "539fe2d9542b01824869b98cde000079a1159b9f"
  :revdesc "539fe2d9542b"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
