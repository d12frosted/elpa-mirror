(define-package "dirvish" "20220109.1831" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "8b16bc3b307786c517edc2bc3740cb82c5dd2b44" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
