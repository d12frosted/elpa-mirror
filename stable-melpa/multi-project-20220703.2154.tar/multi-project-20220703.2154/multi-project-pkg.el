(define-package "multi-project" "20220703.2154" "Find files, compile, and search for multiple projects."
  '((emacs "25"))
  :commit "43a30f9578dc2f5acd4fc2941bedaa031b942b81" :authors
  '(("Shawn Ellis" . "shawn.ellis17@gmail.com"))
  :maintainers
  '(("Shawn Ellis" . "shawn.ellis17@gmail.com"))
  :maintainer
  '("Shawn Ellis" . "shawn.ellis17@gmail.com")
  :keywords
  '("convenience" "project" "management")
  :url "https://hg.osdn.net/view/multi-project/multi-project")
;; Local Variables:
;; no-byte-compile: t
;; End:
