(define-package "lsp-mode" "20231031.1319" "LSP mode"
  '((emacs "27.1")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.3")
    (spinner "1.7.3")
    (markdown-mode "2.3")
    (lv "0")
    (eldoc "1.11"))
  :commit "3abe0e2ffbab40107d2e68bf968b7a497d783839" :authors
  '(("Vibhav Pant, Fangrui Song, Ivan Yonchovski"))
  :maintainers
  '(("Vibhav Pant, Fangrui Song, Ivan Yonchovski"))
  :maintainer
  '("Vibhav Pant, Fangrui Song, Ivan Yonchovski")
  :keywords
  '("languages")
  :url "https://github.com/emacs-lsp/lsp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
