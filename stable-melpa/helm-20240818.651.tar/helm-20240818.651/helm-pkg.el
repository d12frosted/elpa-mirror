(define-package "helm" "20240818.651" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.9")
    (wfnames "1.2"))
  :commit "7e554e338438cb7ed01dca933c179b544b15ed3b" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
