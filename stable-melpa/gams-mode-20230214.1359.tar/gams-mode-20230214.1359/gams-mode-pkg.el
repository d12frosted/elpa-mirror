(define-package "gams-mode" "20230214.1359" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "a50a290e5559e9f099e2bbbcecacac9e484ef4d9" :authors
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
