;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261013.1318"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "7de74d4ab208eb6f93b6bf79e02770e841bb4a53"
  :revdesc "7de74d4ab208"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
