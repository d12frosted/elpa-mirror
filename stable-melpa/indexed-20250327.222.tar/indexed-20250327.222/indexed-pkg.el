;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250327.222"
  "Cache metadata on all Org files."
  '((emacs   "29.1")
    (el-job  "2.4.2")
    (emacsql "4.2.0")
    (llama   "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "9c34dd4af09f761c246a5f66a55f0cfb83b9cf2c"
  :revdesc "9c34dd4af09f"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
