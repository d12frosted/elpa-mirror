(define-package "base16-theme" "20221216.2146" "Collection of themes built on combinations of 16 base colors" 'nil :commit "a3ec04b034c3d2158d3862b3672e36655850eb03" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/tinted-theming/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
