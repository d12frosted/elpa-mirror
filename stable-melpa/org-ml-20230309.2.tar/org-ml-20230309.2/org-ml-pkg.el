(define-package "org-ml" "20230309.2" "Functional Org Mode API"
  '((emacs "27.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "90ce9ba627422b768449d397986e4d2c7944de15" :authors
  '(("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  '("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :keywords
  '("org-mode" "outlines")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
