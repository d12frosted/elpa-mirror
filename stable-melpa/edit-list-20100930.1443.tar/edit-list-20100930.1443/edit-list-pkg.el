;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "edit-list" "20100930.1443"
  "Edit a single list."
  ()
  :url "http://mwolson.org/static/dist/elisp/edit-list.el"
  :commit "f460d3f9e208a4e606fe6ded307f1b011916ca71"
  :revdesc "f460d3f9e208"
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
