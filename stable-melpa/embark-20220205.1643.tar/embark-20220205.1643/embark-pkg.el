(define-package "embark" "20220205.1643" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "e8ef9424b3d8852935f7c547093bc2ebc23aeab5" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
