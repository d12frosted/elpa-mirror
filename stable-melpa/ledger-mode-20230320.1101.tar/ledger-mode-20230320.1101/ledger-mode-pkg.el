(define-package "ledger-mode" "20230320.1101" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "d7ca4279a149f98d4e5e4660356b9d1c8a706330")
;; Local Variables:
;; no-byte-compile: t
;; End:
