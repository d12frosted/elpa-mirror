(define-package "kubel" "20230905.2159" "Control Kubernetes with limited permissions"
  '((transient "0.1.0")
    (emacs "25.3")
    (dash "2.12.0")
    (s "1.2.0")
    (yaml-mode "0.0.14"))
  :commit "f7eb9e3ba4d0fad567c9ddf19faaa74129b3fbf7" :authors
  '(("Adrien Brochard"))
  :maintainers
  '(("Adrien Brochard"))
  :maintainer
  '("Adrien Brochard")
  :keywords
  '("kubernetes" "k8s" "tools" "processes")
  :url "https://github.com/abrochard/kubel")
;; Local Variables:
;; no-byte-compile: t
;; End:
