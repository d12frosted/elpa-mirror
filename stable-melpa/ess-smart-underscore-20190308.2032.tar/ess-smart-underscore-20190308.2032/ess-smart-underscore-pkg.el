(define-package "ess-smart-underscore" "20190308.2032" "Ess Smart Underscore"
  '((ess "0"))
  :commit "ed4b37e8976124a182196a721068a8e334b6aa97" :authors
  '(("Matthew L. Fidler"))
  :maintainer
  '("Matthew Fidler")
  :keywords
  '("ess" "underscore")
  :url "http://github.com/mlf176f2/ess-smart-underscore.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
