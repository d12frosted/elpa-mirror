;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "20260126.928"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "6f6a7e7e045d5f784bf6d23a11d97c163a2652e9"
  :revdesc "6f6a7e7e045d"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
