(define-package "forge" "20240701.2012" "Access Git forges from Magit."
  '((emacs "27.1")
    (compat "29.1.4.5")
    (closql "20240701")
    (dash "2.19.1")
    (emacsql "20240124")
    (ghub "20240507")
    (let-alist "1.0.6")
    (magit "20240701")
    (markdown-mode "2.6")
    (seq "2.24")
    (transient "20240421")
    (yaml "0.5.5"))
  :commit "c8e915d1b811b3dcc4f50eaadccd412abeaf1c4e" :authors
  '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
