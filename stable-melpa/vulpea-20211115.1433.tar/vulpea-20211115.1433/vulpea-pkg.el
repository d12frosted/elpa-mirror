(define-package "vulpea" "20211115.1433" "A collection of org-roam note-taking functions"
  '((emacs "27.2")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12"))
  :commit "0c16e1c1adb45e8aaa32f06edc604e18d39179eb" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
