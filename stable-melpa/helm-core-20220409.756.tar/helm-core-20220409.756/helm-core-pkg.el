(define-package "helm-core" "20220409.756" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "7c1b872d267d4b78b9e1b48974b4f98183587354" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
