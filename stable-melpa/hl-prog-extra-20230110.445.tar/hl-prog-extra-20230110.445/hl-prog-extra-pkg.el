(define-package "hl-prog-extra" "20230110.445" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "04dcab2741a96cd273ce12e881a43063876ee806" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
