(define-package "brutalist-theme" "20181023.1222" "Brutalist theme" 'nil :commit "d30c44b55a6e4797fc96a34e74dc3deba01f654c" :authors
  '(("Gergely Nagy"))
  :maintainer
  '("Gergely Nagy")
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
