(define-package "expand-region" "20210701.1935" "Increase selected region by semantic units." 'nil :commit "09ebc2df5ce3aac05e82367b2e42e7d0f3ff1656" :authors
  '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainer
  '("Magnar Sveen" . "magnars@gmail.com")
  :keywords
  '("marking" "region"))
;; Local Variables:
;; no-byte-compile: t
;; End:
