;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "20260526.1750"
  "A set of eye pleasing themes."
  '((emacs      "26.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "88850479c4630a72ead454508738f4d96733c6d9"
  :revdesc "88850479c463"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
