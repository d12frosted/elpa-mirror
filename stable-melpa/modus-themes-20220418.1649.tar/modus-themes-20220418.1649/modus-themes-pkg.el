(define-package "modus-themes" "20220418.1649" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "9928e20172882554641bd30bf30d5d52a0c88d32" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
