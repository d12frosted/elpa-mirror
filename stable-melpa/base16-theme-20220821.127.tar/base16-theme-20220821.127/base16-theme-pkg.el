(define-package "base16-theme" "20220821.127" "Collection of themes built on combinations of 16 base colors" 'nil :commit "d70a96152a3d2d66776012ec7e578f93d7c6aa2c" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/base16-project/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
