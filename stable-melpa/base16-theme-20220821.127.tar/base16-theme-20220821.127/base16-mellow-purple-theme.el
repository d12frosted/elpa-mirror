;; base16-mellow-purple-theme.el -- A base16 colorscheme

;;; Commentary:
;; Base16: (https://github.com/base16-project/base16)

;;; Authors:
;; Scheme: gidsi
;; Template: Kaleb Elwert <belak@coded.io>

;;; Code:

(require 'base16-theme)

(defvar base16-mellow-purple-theme-colors
  '(:base00 "#1e0528"
    :base01 "#1a092d"
    :base02 "#331354"
    :base03 "#320f55"
    :base04 "#873582"
    :base05 "#ffeeff"
    :base06 "#ffeeff"
    :base07 "#f8c0ff"
    :base08 "#00d9e9"
    :base09 "#aa00a3"
    :base0A "#955ae7"
    :base0B "#05cb0d"
    :base0C "#b900b1"
    :base0D "#550068"
    :base0E "#8991bb"
    :base0F "#4d6fff")
  "All colors for Base16 Mellow Purple are defined here.")

;; Define the theme
(deftheme base16-mellow-purple)

;; Add all the faces to the theme
(base16-theme-define 'base16-mellow-purple base16-mellow-purple-theme-colors)

;; Mark the theme as provided
(provide-theme 'base16-mellow-purple)

(provide 'base16-mellow-purple-theme)

;;; base16-mellow-purple-theme.el ends here
