;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260318.709"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "33a391871596c997c3dbce7f9f14457a94dd6c3c"
  :revdesc "33a391871596"
  :keywords '("comm"))
