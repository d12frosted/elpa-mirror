;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261012.1316"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "74007dcb20872c51c7a9b948aef2cedf9a61ccaf"
  :revdesc "74007dcb2087"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
