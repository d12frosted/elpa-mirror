(define-package "mini-echo" "20231107.1317" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "9d89e352b73ff2222d62b43b8944206582723fef" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
