;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250928.832"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "e33c03735948048ed4170d7aa2cc136fa5c2c0ce"
  :revdesc "e33c03735948"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
