;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-lint" "20261122.905"
  "Async indentation checker."
  '((emacs       "27.1")
    (async-await "1.1")
    (async       "1.9.7")
    (promise     "1.1"))
  :url "https://github.com/conao3/indent-lint.el"
  :commit "4fa48adb3d98cf22480ee7503fa37cc158cec41b"
  :revdesc "4fa48adb3d98"
  :keywords '("tools")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
