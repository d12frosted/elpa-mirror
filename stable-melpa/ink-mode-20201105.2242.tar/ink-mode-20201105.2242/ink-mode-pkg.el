(define-package "ink-mode" "20201105.2242" "Major mode for writing interactive fiction in Ink"
  '((emacs "26.1"))
  :commit "71d215712067729eb92e766a3b2067e7f3254183" :authors
  '(("Erik Sjöstrand")
    ("Damien Picard"))
  :maintainer
  '("Damien Picard")
  :keywords
  '("languages" "wp" "hypermedia")
  :url "https://github.com/Kungsgeten/ink-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
