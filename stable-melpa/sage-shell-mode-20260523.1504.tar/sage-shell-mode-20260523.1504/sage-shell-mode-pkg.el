;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sage-shell-mode" "20260523.1504"
  "A front-end for Sage Math."
  '((cl-lib    "0.6.1")
    (emacs     "24.4")
    (let-alist "1.0.5")
    (deferred  "0.5.1"))
  :url "https://github.com/sagemath/sage-shell-mode"
  :commit "bb59cd559a9d7639d9ef16addbb0809ea4790392"
  :revdesc "bb59cd559a9d"
  :keywords '("sage" "math")
  :authors '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers '(("Sho Takemori" . "stakemorii@gmail.com")))
