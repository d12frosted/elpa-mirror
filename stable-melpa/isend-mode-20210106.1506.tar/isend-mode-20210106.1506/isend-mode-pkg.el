;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "isend-mode" "20210106.1506"
  "Interactively send parts of an Emacs buffer to an interpreter."
  ()
  :url "https://github.com/ffevotte/isend-mode.el"
  :commit "ea855f63be7febc15bd08aec6229fab9407734fb"
  :revdesc "ea855f63be7f"
  :authors '(("François Févotte" . "fevotte@gmail.com"))
  :maintainers '(("François Févotte" . "fevotte@gmail.com")))
