;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-walk" "20251127.2141"
  "Send email addresses for a walk."
  '((emacs "29.1"))
  :url "https://codeberg.org/timmli/mu4e-walk"
  :commit "5aa752daa1d166e282535df48ad657a431d7428c"
  :revdesc "5aa752daa1d1"
  :keywords '("convenience" "mail")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
