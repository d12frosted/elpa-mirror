;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20260514.534"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "b9594f31d612937a652d619e35ba27632f72e805"
  :revdesc "b9594f31d612"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
