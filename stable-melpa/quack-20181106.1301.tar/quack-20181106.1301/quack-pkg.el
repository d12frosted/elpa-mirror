;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quack" "20181106.1301"
  "Enhanced support for editing and running Scheme code."
  ()
  :url "https://github.com/emacsmirror/quack"
  :commit "2146805ce2b5a9b155d73929986f11e713787e26"
  :revdesc "2146805ce2b5")
