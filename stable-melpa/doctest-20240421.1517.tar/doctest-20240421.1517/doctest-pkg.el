;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doctest" "20240421.1517"
  "Doctests for Emacs Lisp."
  '((emacs "28.1"))
  :url "https://github.com/ag91/doctest"
  :commit "0620ab6283a4e4302761ac415354b0b2b889dcda"
  :revdesc "0620ab6283a4"
  :keywords '("lisp" "maint" "docs" "help")
  :authors '(("Chris Rayner" . "(dchrisrayner@gmail.com)")
             ("Andrea -- current maintainer" . "(andrea-dev@hotmail.com) "))
  :maintainers '(("Chris Rayner" . "(dchrisrayner@gmail.com)")
                 ("Andrea -- current maintainer" . "(andrea-dev@hotmail.com) ")))
