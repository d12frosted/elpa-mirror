;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260630.2041"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "d2fd1206733931dc7b9f9d92b24486e58b135ddc"
  :revdesc "d2fd12067339"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
