;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20260429.1901"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "30.1")
    (cond-let "0.2")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "7c79841951ef521c542ebbb66f51b144115ce6a9"
  :revdesc "7c79841951ef"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
