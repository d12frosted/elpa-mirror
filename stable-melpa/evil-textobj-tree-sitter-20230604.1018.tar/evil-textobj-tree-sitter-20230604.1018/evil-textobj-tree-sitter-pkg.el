(define-package "evil-textobj-tree-sitter" "20230604.1018" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.15.0"))
  :commit "7f310147cc9d9d8a2f2bdb732976fa08688e4f65" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
