;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250929.924"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.20.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "2aa74a387268236d2ff9e67654b3e7f7e7df3b92"
  :revdesc "2aa74a387268"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
