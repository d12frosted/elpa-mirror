;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260816.1543"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "303fa461f40ed82113392b62c7912ec9af41062d"
  :revdesc "303fa461f40e"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
