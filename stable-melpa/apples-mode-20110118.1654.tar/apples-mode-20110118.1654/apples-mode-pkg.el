(define-package "apples-mode" "20110118.1654" "Major mode for editing and executing AppleScript code" 'nil :commit "fac47b6255e79a373c5d5e1abe66ea5d74588e9f" :authors
  '(("tequilasunset" . "tequilasunset.mac@gmail.com"))
  :maintainer
  '("tequilasunset" . "tequilasunset.mac@gmail.com")
  :keywords
  '("applescript" "languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
