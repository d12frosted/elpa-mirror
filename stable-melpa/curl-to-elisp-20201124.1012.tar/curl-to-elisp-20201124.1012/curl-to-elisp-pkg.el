;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "curl-to-elisp" "20201124.1012"
  "Convert cURL command to Emacs Lisp code."
  '((emacs "25.1"))
  :url "https://github.com/xuchunyang/curl-to-elisp"
  :commit "63d8d9c6d5efb8af8aa88042bfc0690ba699ef64"
  :revdesc "63d8d9c6d5ef"
  :keywords '("lisp"))
