;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-jump-out" "20251215.247"
  "Use tab to jump out of delimiter pairs."
  '((emacs "24.4"))
  :url "https://github.com/mkleehammer/tab-jump-out"
  :commit "6287177b67cec1dc5c938841ce8f97c86f48ef5e"
  :revdesc "6287177b67ce"
  :keywords '("convenience")
  :authors '(("Zhang Kai Yu" . "yeannylam@gmail.com"))
  :maintainers '(("Michael Kleehammer" . "michael@kleehammer.com")))
