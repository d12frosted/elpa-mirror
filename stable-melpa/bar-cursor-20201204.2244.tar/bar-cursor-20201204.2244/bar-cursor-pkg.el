;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bar-cursor" "20201204.2244"
  "Package used to switch block cursor to a bar."
  ()
  :url "https://github.com/ajsquared/bar-cursor"
  :commit "78f195b6db63459033c4f1c7e7add5d82f3ce424"
  :revdesc "78f195b6db63"
  :keywords '("files")
  :authors '(("Joe Casadonte" . "(emacs@northbound-train.com)"))
  :maintainers '(("Andrew Johnson" . "(andrew@andrewjamesjohnson.com)")))
