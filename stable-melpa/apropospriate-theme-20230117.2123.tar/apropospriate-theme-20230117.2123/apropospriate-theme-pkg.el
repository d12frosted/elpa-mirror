(define-package "apropospriate-theme" "20230117.2123" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "1257880637e03efb885893afbcb88b7a8b20965a" :authors
  '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainer
  '("Justin Talbott" . "justin@waymondo.com")
  :url "http://github.com/waymondo/apropospriate-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
