;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dakrone-light-theme" "20170808.2140"
  "Dakrone's custom light theme."
  ()
  :url "https://github.com/dakrone/dakrone-light-theme"
  :commit "06f198dc8b4ca7421990b30a23d89c8e0b8c5de4"
  :revdesc "06f198dc8b4c"
  :keywords '("color" "themes" "faces")
  :authors '(("Lee Hinman" . "lee_AT_writequit.org"))
  :maintainers '(("Lee Hinman" . "lee_AT_writequit.org")))
