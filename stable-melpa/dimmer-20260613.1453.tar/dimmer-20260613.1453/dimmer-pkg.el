;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dimmer" "20260613.1453"
  "Visually highlight the selected buffer."
  '((emacs "27.1"))
  :url "https://github.com/gonewest818/dimmer.el"
  :commit "237791624116b05895a0154107b46d963f82c5c3"
  :revdesc "237791624116"
  :keywords '("faces" "editing"))
