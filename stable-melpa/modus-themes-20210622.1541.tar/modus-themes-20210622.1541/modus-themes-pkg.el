(define-package "modus-themes" "20210622.1541" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "875c47d1174303316be4886dbca88d582477da9f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
