(define-package "biome" "20230725.1253" "Bountiful Interface to Open Meteo for Emacs"
  '((emacs "27.1")
    (transient "0.3.7")
    (ct "0.2")
    (request "0.3.3")
    (compat "29.1.4.1"))
  :commit "aee39851e2827329f955d657a2bdf7d4874e97ae" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/biome")
;; Local Variables:
;; no-byte-compile: t
;; End:
