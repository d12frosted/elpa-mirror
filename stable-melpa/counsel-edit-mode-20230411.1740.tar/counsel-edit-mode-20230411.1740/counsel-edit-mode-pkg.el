;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-edit-mode" "20230411.1740"
  "Edit results of counsel commands in-place."
  '((emacs   "26.1")
    (ht      "2.3")
    (s       "1.12.0")
    (counsel "0.10.0"))
  :url "https://github.com/tyler-dodge/counsel-edit-mode"
  :commit "8ff508a864d0fe4cac32c6868420df2ad77f041b"
  :revdesc "8ff508a864d0"
  :keywords '("convenience" "matching"))
