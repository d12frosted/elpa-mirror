(define-package "keepass-mode" "20210628.729" "Mode for KeePass DB."
  '((emacs "27"))
  :commit "fd7d380b762c888f25435d0c241012cdabf6e288" :authors
  '(("Ignasi Fosch" . "natx@y10k.ws"))
  :maintainer
  '("Ignasi Fosch" . "natx@y10k.ws")
  :keywords
  '("data" "files" "tools")
  :url "https://github.com/ifosch/keepass-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
