;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flash" "20260222.536"
  "Flash-style navigation."
  '((emacs "27.1"))
  :url "https://github.com/Prgebish/flash"
  :commit "f93bc5baf60f23c96239d8bfe154d2c6727c8c66"
  :revdesc "f93bc5baf60f"
  :keywords '("convenience" "navigation")
  :authors '(("Vadim Pavlov" . "https://github.com/Prgebish"))
  :maintainers '(("Vadim Pavlov" . "https://github.com/Prgebish")))
