(define-package "consult" "20220224.1109" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f0e696dd0d3e8caa23ff0f1b9a960e0dcbcdcf83" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
