;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250608.352"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "45f8a4ae87a3d0980146610de1a981b62540a1c2"
  :revdesc "45f8a4ae87a3"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
