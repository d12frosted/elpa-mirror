(define-package "notmuch" "20201225.1832" "run notmuch within emacs" 'nil :commit "a12bf2a52a560cc27503add26e9c3087929b60ec" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
