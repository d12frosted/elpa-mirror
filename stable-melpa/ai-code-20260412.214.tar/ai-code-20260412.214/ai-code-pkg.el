;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260412.214"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "297188da3d4545679466d313e40eeac5f3e6a56e"
  :revdesc "297188da3d45"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
