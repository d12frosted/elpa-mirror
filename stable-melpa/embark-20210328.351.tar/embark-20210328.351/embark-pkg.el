(define-package "embark" "20210328.351" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "91882fca9a354375ec8e9b856c88df97d9470187" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
