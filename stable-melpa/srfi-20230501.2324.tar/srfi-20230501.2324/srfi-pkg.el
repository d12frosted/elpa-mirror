(define-package "srfi" "20230501.2324" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "34917fc6522aaa70d03025329b18ac0a2aebd46c" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
