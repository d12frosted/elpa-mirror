;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bookmark-frecency" "20250220.1407"
  "Sort bookmarks by frecency."
  '((emacs "27.1"))
  :url "https://github.com/akirak/bookmark-frecency.el"
  :commit "c0a4dae3ff23a548538716cbd2ad533680dc7e9e"
  :revdesc "c0a4dae3ff23"
  :keywords '("convenience")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
