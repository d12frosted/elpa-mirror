(define-package "chronometrist-key-values" "20220212.1611" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "1b6c21d52937fa3ff0a8adabda5e95223f7f39ab" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
