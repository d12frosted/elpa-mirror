(define-package "autocrypt" "20220521.810" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "ff87f73f00689689f023e39f4cee2fd97caf458b" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
