;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-languagetool" "20260214.1911"
  "Flycheck support for LanguageTool."
  '((emacs    "27.1")
    (flycheck "0.14"))
  :url "https://github.com/emacs-languagetool/flycheck-languagetool"
  :commit "a8dab49fdb1f85c19700a39c4ee01f6208ef06e1"
  :revdesc "a8dab49fdb1f"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com")
             ("Peter Oliver" . "git@mavit.org.uk"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Peter Oliver" . "git@mavit.org.uk")))
