(define-package "helm" "20230820.1712" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.4")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "9e748c6acc7547a6225b8ad8733950342ee2a7d9" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
