(define-package "nim-mode" "20171024.1431" "A major mode for the Nim programming language"
  '((emacs "24.4")
    (epc "0.1.1")
    (let-alist "1.0.1")
    (commenter "0.5.1")
    (flycheck "28"))
  :commit "86abed21b9b718ac65cc167f208e0bd5b92c79ed" :authors
  '(("Simon Hafner"))
  :maintainer
  '("Simon Hafner" . "hafnersimon@gmail.com")
  :keywords
  '("nim" "languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
