(define-package "icomplete-vertical" "20210209.1322" "Display icomplete candidates vertically"
  '((emacs "25.1"))
  :commit "c7d96c57c66fa01dd1fbf9df64a619b0f8741193" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
