(define-package "meow" "20231217.43" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "53b7059636faa4baa5432bc3b7bd522a7c9909c7" :authors
  '(("Shi Tianshu"))
  :maintainers
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
