(define-package "ddskk" "20220210.2155" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "eede626d70953715d2405b325dcb151b7cb597e7")
;; Local Variables:
;; no-byte-compile: t
;; End:
