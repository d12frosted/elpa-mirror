(define-package "simple-indentation" "20221127.1232" "Simplify writing indentation functions, alternative to SMIE"
  '((emacs "24.3")
    (dash "2.18.0")
    (s "1.12.0"))
  :commit "74efe02aa6c1612ae9b32b88f97b7d6d309726b2" :authors
  '(("Semen Khramtsov" . "hrams205@gmail.com"))
  :maintainer
  '("Semen Khramtsov" . "hrams205@gmail.com")
  :url "https://github.com/semenInRussia/simple-indentation.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
