;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-duckdb" "20251220.1924"
  "Org Babel integration for DuckDB CLI."
  '((emacs "28.1")
    (org   "9.5"))
  :url "https://github.com/gggion/ob-duckdb"
  :commit "c50b3168dc40ba646f137e8f090a2272f611d135"
  :revdesc "c50b3168dc40"
  :keywords '("languages" "org" "babel" "duckdb" "sql" "data" "analytics")
  :maintainers '(("gggion" . "gggion123@gmail.com")))
