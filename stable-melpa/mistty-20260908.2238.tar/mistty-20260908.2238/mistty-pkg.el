;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20260908.2238"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "87211c9752fa4c40b92d5ca5a816a2f9cfeec59b"
  :revdesc "87211c9752fa"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
