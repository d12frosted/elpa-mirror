;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "20260906.2310"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "a63a44020f48cd178c762a30104d09f0cfa584fa"
  :revdesc "a63a44020f48"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
