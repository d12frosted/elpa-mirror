(define-package "modus-themes" "20220211.910" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "bcabb3bc1e6dce8492fd78345290dcd63ef864b9" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
