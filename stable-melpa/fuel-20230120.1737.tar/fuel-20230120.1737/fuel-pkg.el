(define-package "fuel" "20230120.1737" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "25236d56df9b39c607a6af75d4e16273201031bd")
;; Local Variables:
;; no-byte-compile: t
;; End:
