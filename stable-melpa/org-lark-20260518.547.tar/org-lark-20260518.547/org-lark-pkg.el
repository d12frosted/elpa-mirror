;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "20260518.547"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "9672109da8aa8505ebf3a8764559d54853bfc021"
  :revdesc "9672109da8aa"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
