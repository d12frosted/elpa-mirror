(define-package "elisp-autofmt" "20230112.2341" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "0748b49b9145fd050e27425079fbad2dcfbf4a9f" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
