;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recomplete" "20260429.613"
  "Immediately (re)complete actions."
  '((emacs             "29.1")
    (with-command-redo "0.1"))
  :url "https://codeberg.org/ideasman42/emacs-recomplete"
  :commit "bbe2b779958a07162e1be4498a48df3a2390ce0e"
  :revdesc "bbe2b779958a"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
