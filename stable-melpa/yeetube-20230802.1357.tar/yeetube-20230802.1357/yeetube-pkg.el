(define-package "yeetube" "20230802.1357" "YouTube/Invidious Front End"
  '((emacs "27.2"))
  :commit "231d381cb2ec19439b783654184d509e0a5333f0" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos" "invidious")
  :url "https://git.sr.ht/~thanosapollo/yeetube.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
