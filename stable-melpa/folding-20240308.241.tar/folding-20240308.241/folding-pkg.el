(define-package "folding" "20240308.241" "A folding-editor-like minor mode." 'nil :commit "36927bd3599328b9febf7a78591a9f7f691f3eb2" :maintainers
  '(("Jari Aalto <jari aalto A T cante dt net>"))
  :maintainer
  '("Jari Aalto <jari aalto A T cante dt net>")
  :keywords
  '("tools"))
;; Local Variables:
;; no-byte-compile: t
;; End:
