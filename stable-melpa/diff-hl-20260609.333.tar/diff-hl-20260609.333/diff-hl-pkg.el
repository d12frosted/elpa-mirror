;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260609.333"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "759e7f18bf8c92fdf742e678d360d660f6d41f10"
  :revdesc "759e7f18bf8c"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
