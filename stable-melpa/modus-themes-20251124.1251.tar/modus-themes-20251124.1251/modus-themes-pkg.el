;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251124.1251"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "ec8f8a80b18e70a5c2ebef7fbc5ce0253def22d2"
  :revdesc "ec8f8a80b18e"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
