(define-package "boon" "20210301.1954" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "116d72fb8731249b7b64e764919ea9d0d414342c")
;; Local Variables:
;; no-byte-compile: t
;; End:
