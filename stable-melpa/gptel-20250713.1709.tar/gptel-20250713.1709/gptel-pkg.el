;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250713.1709"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "7af9ed8fc13ba1c9cbdb6ab7d47ddfa5aee2d455"
  :revdesc "7af9ed8fc13b"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
