(define-package "catppuccin-theme" "20221224.1835" "Catppuccin Theme"
  '((emacs "25.1"))
  :commit "86b16248ef2ce450def4a00a0ca5170c102da623" :authors
  '(("pspiagicw"))
  :maintainer
  '("Name" . "namesexistsinemails@gmail.com")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
