;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-php" "20261028.426"
  "A company back-end for PHP."
  '((cl-lib      "0.5")
    (ac-php-core "2.0")
    (company     "0.9"))
  :url "https://github.com/xcwen/ac-php"
  :commit "619cb3c999719cd6ea0e784249811c2660980e79"
  :revdesc "619cb3c99971"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")))
