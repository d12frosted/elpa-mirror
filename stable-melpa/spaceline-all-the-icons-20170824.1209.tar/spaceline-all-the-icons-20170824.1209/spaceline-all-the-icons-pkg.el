(define-package "spaceline-all-the-icons" "20170824.1209" "A Spaceline theme using All The Icons"
  '((emacs "24.4")
    (all-the-icons "2.6.0")
    (spaceline "2.0.0")
    (memoize "1.0.1"))
  :commit "7eafe2d7a81f8d10e03498bdcc3bec0ea50f905d" :authors
  '(("Dominic Charlesworth" . "dgc336@gmail.com"))
  :maintainer
  '("Dominic Charlesworth" . "dgc336@gmail.com")
  :keywords
  '("convenience" "lisp" "tools")
  :url "https://github.com/domtronn/spaceline-all-the-icons.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
