(define-package "fxrd-mode" "20170728.1801" "Major mode for editing fixed field width files"
  '((s "1.2"))
  :commit "795b969346982b75e24b5c8619b46197982fbb4d" :authors
  '(("Marc Sherry" . "msherry@gmail.com"))
  :maintainer
  '("Marc Sherry" . "msherry@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/msherry/fxrd-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
