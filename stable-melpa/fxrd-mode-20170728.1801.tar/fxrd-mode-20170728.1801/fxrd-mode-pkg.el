(define-package "fxrd-mode" "20170728.1801" "Major mode for editing fixed field width files"
  '((s "1.2"))
  :commit "18a603474abb5a786a8d9f20c283d5f7beed3540" :keywords
  ("convenience")
  :authors
  (("Marc Sherry" . "msherry@gmail.com"))
  :maintainer
  ("Marc Sherry" . "msherry@gmail.com")
  :url "https://github.com/msherry/fxrd-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
