;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260212.954"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "deaeeb116ba4c4294d85038808f10c304bdd55ee"
  :revdesc "deaeeb116ba4"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
