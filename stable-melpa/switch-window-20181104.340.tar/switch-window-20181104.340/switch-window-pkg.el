(define-package "switch-window" "20181104.340" "A *visual* way to switch window"
  '((emacs "24"))
  :commit "204f9fc1a39868a2d16ab9370a142c8c9c7a0943" :authors
  '(("Dimitri Fontaine" . "dim@tapoueh.org")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Dimitri Fontaine" . "dim@tapoueh.org")
  :keywords
  '("convenience")
  :url "https://github.com/dimitri/switch-window")
;; Local Variables:
;; no-byte-compile: t
;; End:
