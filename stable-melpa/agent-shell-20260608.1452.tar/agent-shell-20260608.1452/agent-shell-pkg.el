;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260608.1452"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d72f4b728d0d9bd4acee4539d484a395aa75873a"
  :revdesc "d72f4b728d0d")
