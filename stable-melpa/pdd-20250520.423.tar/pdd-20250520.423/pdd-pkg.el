;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250520.423"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "4381cb47523bf4b308181bbad3162bafbf10f5d2"
  :revdesc "4381cb47523b"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
