;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260720.611"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "4bcf1e3b6a0462a31787c3e47acc176249ef6d1c"
  :revdesc "4bcf1e3b6a04"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
