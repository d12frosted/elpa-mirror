(define-package "phpactor" "20180808.1417" "Interface to Phpactor"
  '((emacs "24.3")
    (cl-lib "0.5")
    (f "0.17"))
  :commit "61e4eab638168b7034eef0f11e35a89223fa7687" :authors
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("tools" "php")
  :url "https://github.com/emacs-php/phpactor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
