;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "card-games" "20260816.1451"
  "Play card games (console + SVG)."
  '((emacs "26.1"))
  :url "https://code.bru.st/corwin/card-game.el"
  :commit "1a5d23d39eb3d7dfcdeabc8e99c2673fd4937434"
  :revdesc "1a5d23d39eb3"
  :keywords '("games")
  :authors '(("Corwin Brust" . "corwin@bru.st"))
  :maintainers '(("Corwin Brust" . "corwin@bru.st")))
