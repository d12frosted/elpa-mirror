;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260526.1303"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "3b1e8665ac12c03a86c0144c37ad74c470dd63ce"
  :revdesc "3b1e8665ac12"
  :keywords '("convenience" "chinese" "input-method" "rime"))
