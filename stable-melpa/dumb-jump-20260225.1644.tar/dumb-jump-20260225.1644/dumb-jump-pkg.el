;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260225.1644"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "24.4")
    (dash  "2.9.0"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "215e2ed9abdcc4bb547f10ea4fe9e384904e817d"
  :revdesc "215e2ed9abdc"
  :keywords '("programming"))
