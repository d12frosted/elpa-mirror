(define-package "spdx" "20221201.137" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "55597ce8bc515ec41a28a3377111a24946fa5a30" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
