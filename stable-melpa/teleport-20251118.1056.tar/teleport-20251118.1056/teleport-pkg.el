;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "teleport" "20251118.1056"
  "Integration for tsh (goteleport.com)."
  '((emacs "28.1")
    (dash  "2.18.0"))
  :url "https://github.com/caramelhooves/teleport.el"
  :commit "0ff615c4b2f19019c9438075c75e0f94b4cec53c"
  :revdesc "0ff615c4b2f1"
  :keywords '("tools")
  :authors '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainers '(("Caramel Hooves" . "caramel.hooves@protonmail.com")))
