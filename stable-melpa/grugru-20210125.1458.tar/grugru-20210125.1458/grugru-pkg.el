(define-package "grugru" "20210125.1458" "Rotate text at point"
  '((emacs "24.4"))
  :commit "e7f0fca4bfd4815e5ed794f13f89b1e28ce57d26" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
