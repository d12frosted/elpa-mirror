;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260729.925"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c57c11ceb39e364e5f85086a781b73f776c17a8e"
  :revdesc "c57c11ceb39e")
