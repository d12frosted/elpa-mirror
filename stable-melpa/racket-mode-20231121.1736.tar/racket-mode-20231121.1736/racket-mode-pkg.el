(define-package "racket-mode" "20231121.1736" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "6b832a34bd8d3fae40b8c02a71c74123f81e75b9" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
