(define-package "tree-sitter-langs" "20210809.1122" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.15.0"))
  :commit "7c964f4de5ddef9f0a582d7742e61f9a4b778bfc" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/tree-sitter-langs")
;; Local Variables:
;; no-byte-compile: t
;; End:
