;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250121.938"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "cd8f06a73ee4f56ae03c7d712c16661eabf2443b"
  :revdesc "cd8f06a73ee4"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
