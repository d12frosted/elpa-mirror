;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "20260629.536"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.0"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "5bfe0be64da8d5f8d156a399101cecc5e9037ddd"
  :revdesc "5bfe0be64da8"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
