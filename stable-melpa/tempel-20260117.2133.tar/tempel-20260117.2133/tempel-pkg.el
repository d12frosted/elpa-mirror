;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260117.2133"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "759721c84cef53403cd9c865d04c98ed212632cd"
  :revdesc "759721c84cef"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
