;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "boron-theme" "20170808.1308"
  "An Emacs 24 theme based on Boron (tmTheme)."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/tmtheme-to-deftheme"
  :commit "87ae1a765e07429fec25d2f29b004f84b52d2e0a"
  :revdesc "87ae1a765e07")
