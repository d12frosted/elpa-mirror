;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260625.41"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "727b1b3da1a5705d7ea7ce91373d45d1c0e3cc72"
  :revdesc "727b1b3da1a5"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
