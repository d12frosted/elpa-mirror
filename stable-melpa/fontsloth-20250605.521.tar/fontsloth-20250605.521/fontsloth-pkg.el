;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontsloth" "20250605.521"
  "Elisp otf/ttf font loader/renderer."
  '((f      "0.20.0")
    (logito "0.1")
    (pcache "0.5")
    (stream "2.2.5")
    (emacs  "28.1"))
  :url "https://github.com/jollm/fontsloth"
  :commit "70b92129b52631eed248f71429a887901306451a"
  :revdesc "70b92129b526"
  :keywords '("data" "font" "rasterization" "ttf" "otf")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")))
