;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "soccer" "20260811.1723"
  "Fixtures, results, table etc for soccer."
  '((emacs "29.1"))
  :url "https://github.com/md-arif-shaikh/soccer"
  :commit "fd00b49d63faef7137f883d571f2ed692337cd68"
  :revdesc "fd00b49d63fa"
  :keywords '("games" "soccer" "football")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
