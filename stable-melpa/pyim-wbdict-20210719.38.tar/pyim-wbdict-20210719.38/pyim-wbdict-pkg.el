(define-package "pyim-wbdict" "20210719.38" "Some wubi dicts for pyim"
  '((pyim "3.7"))
  :commit "4812f93ee00196b8fee9f434aa5cd77fabcf90d1" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/tumashu/pyim-wbdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
