;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260725.33"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "31b9dd9f8f15ed4b48b72efe370792dc532ec957"
  :revdesc "31b9dd9f8f15"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
