;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "20260316.2218"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "892560e050a7faa343bc5fa6d7b73c602d86b85f"
  :revdesc "892560e050a7"
  :keywords '("languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
