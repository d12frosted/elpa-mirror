;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261005.8"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "434d42dfad5e9d6b6e400d29df50f34d151f2d34"
  :revdesc "434d42dfad5e"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
