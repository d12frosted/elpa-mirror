(define-package "proof-general" "20201226.2208" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.3"))
  :commit "2d94aa0aabf0aa7087f8833e1c61d95a034e2d13" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
