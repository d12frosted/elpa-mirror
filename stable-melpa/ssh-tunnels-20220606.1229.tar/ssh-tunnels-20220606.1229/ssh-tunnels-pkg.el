(define-package "ssh-tunnels" "20220606.1229" "Manage SSH tunnels"
  '((cl-lib "0.5")
    (emacs "24"))
  :commit "191013b83f3ec3214394a1ed698c4cf38e4d9047" :authors
  '(("death <github.com/death>"))
  :maintainer
  '("death <github.com/death>")
  :keywords
  '("tools" "convenience")
  :url "http://github.com/death/ssh-tunnels")
;; Local Variables:
;; no-byte-compile: t
;; End:
