;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260430.1303"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "837c21a076cde3be6d652fc269e2d845a79db24b"
  :revdesc "837c21a076cd"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
