;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gh" "20260215.351"
  "GitHub CLI integration for Magit."
  '((emacs     "29.1")
    (magit     "4.0.0")
    (transient "0.5.0"))
  :url "https://github.com/jonathanchu/magit-gh"
  :commit "b984e84d0d11565c8b7771552f1500b51cdef639"
  :revdesc "b984e84d0d11"
  :keywords '("git" "tools" "vc" "github")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
