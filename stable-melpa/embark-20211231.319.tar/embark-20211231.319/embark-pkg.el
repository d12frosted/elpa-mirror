(define-package "embark" "20211231.319" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "e1a0422cca599be81084cee35681601a5503c359" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
