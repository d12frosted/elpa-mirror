;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "finito" "20241026.1642"
  "View and collect books."
  '((emacs     "27.1")
    (dash      "2.19.1")
    (request   "0.3.2")
    (f         "0.2.0")
    (s         "1.12.0")
    (transient "0.3.0")
    (graphql   "0.1.1")
    (async     "1.9.3"))
  :url "https://github.com/LaurenceWarne/finito.el"
  :commit "126c51089d91de79fa9d5d15b957a36ec00edd92"
  :revdesc "126c51089d91"
  :keywords '("outlines"))
