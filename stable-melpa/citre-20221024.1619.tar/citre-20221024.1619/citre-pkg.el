(define-package "citre" "20221024.1619" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "050bb7cafc2a89379406f363f7120ac56177ede7" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
