;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20260716.1952"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "2e1b2a84f7d671ad21234b98c5e66ccc7ae1a409"
  :revdesc "2e1b2a84f7d6"
  :keywords '("convenience" "gptel" "llm"))
