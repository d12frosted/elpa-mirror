;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emoji-display" "20140117.1013"
  "Emoji displaying module."
  ()
  :url "https://github.com/ikazuhiro/emoji-display"
  :commit "bb4217f6400151a9cfa6d4524b8427f01feb5193"
  :revdesc "bb4217f64001"
  :keywords '("emoji")
  :authors '(("Kazuhiro Ito" . "kzhr@d1.dion.ne.jp"))
  :maintainers '(("Kazuhiro Ito" . "kzhr@d1.dion.ne.jp")))
