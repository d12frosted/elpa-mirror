(define-package "dired-collapse" "20240629.1754" "Collapse unique nested paths in dired listing"
  '((f "0.19.0")
    (s "1.13.1")
    (dired-hacks-utils "0.0.1"))
  :commit "dab22a3dcf3b40c3be0f981eff872199a552800b" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("files"))
;; Local Variables:
;; no-byte-compile: t
;; End:
