(define-package "notmuch" "20210624.2026" "run notmuch within emacs" 'nil :commit "4b0c6fb2f1ba989fee554cb8fa2612046d6414a8" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
