(define-package "notmuch" "20210624.2026" "run notmuch within emacs" 'nil :commit "2c96956b3b5d60ae25885f4fa06cbc98e567d263" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
