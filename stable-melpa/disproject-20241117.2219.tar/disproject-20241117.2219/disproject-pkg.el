;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20241117.2219"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.7.8"))
  :url "https://github.com/aurtzy/disproject"
  :commit "645d67bf86fd5b72e534c9220e4da23e9eea5db8"
  :revdesc "645d67bf86fd"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
