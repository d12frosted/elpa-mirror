;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-ltex-plus" "20260829.2114"
  "Grammar and spell checking for LaTeX, Markdown, Org and more."
  '((emacs    "27.1")
    (lsp-mode "6.0"))
  :url "https://github.com/ltex-plus/emacs-ltex-plus"
  :commit "291716a1e74de5ac7a8df063c1e4c0685855ca9d"
  :revdesc "291716a1e74d"
  :keywords '("lsp" "grammar" "spelling" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
