(define-package "detached" "20221014.2120" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "05c974b1c1b9c58613ec46a3dded5f6d22741e17" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
