(define-package "cm-mode" "20240419.1050" "Minor mode for CriticMarkup"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "8ec04c9baca5742064686b64651aa25551cbbbcc" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "markdown"))
;; Local Variables:
;; no-byte-compile: t
;; End:
