;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enlightened-theme" "20210220.2327"
  "A theme based on enlightened."
  ()
  :url "https://hg.sr.ht/~slondr/enlightened"
  :commit "1bfebd8f47e8a8357c9e557cf6e95d7027861e6d"
  :revdesc "1bfebd8f47e8")
