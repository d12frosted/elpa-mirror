(define-package "tree-sitter" "20201209.1538" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.12.1"))
  :commit "43fc289dd1a8ba63bb97e5b09750bc9f211eadb5" :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
