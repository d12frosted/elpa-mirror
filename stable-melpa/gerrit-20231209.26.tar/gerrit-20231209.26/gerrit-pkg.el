(define-package "gerrit" "20231209.26" "Gerrit client"
  '((emacs "25.1")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "8acf7416beec47cd09eae0dceb134f9bcf57b1d4" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainers
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
