(define-package "consult" "20230325.1639" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "38ddf8489dc0ed70038fa40ddba16bed7a293c4b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
