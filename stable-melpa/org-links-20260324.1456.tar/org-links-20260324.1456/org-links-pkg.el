;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260324.1456"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "0bb6bfd474ab00c1a7254024329f5dde5c1499ae"
  :revdesc "0bb6bfd474ab"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
