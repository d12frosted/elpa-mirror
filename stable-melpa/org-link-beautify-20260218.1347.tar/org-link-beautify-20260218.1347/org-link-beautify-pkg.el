;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260218.1347"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "68183f5f8ca66ac0c5636132a4ed72807daa6f95"
  :revdesc "68183f5f8ca6"
  :keywords '("hypermedia"))
