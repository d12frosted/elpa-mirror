;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251013.1804"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "9e0ad95a65e1a0a94c2be7d1295ea40ead26972e"
  :revdesc "9e0ad95a65e1"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
