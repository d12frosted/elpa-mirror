;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260609.612"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "530d22dcc6e59e01bcd00429ba3bf7cef82c85dc"
  :revdesc "530d22dcc6e5"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
