;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250313.1508"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f6f319eb4012d6eaaec83bc0351d0bb4d5fd699a"
  :revdesc "f6f319eb4012"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
