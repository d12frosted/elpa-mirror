;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260503.1846"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "f915a8bba57fcd4fe7d92bf2bbcec17e5bbfa25b"
  :revdesc "f915a8bba57f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
