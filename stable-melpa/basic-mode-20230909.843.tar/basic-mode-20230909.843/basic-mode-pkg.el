(define-package "basic-mode" "20230909.843" "Major mode for editing BASIC code"
  '((seq "2.20")
    (emacs "25.1"))
  :commit "5bcefd47c2b97b0482cb02d3d9012f334a1535b1" :authors
  '(("Johan Dykstrom"))
  :maintainers
  '(("Johan Dykstrom"))
  :maintainer
  '("Johan Dykstrom")
  :keywords
  '("basic" "languages")
  :url "https://github.com/dykstrom/basic-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
