;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskjuggler-mode" "20260503.1955"
  "Major mode for TaskJuggler project files."
  '((emacs "27.1"))
  :url "https://github.com/devrintalen/taskjuggler-mode.el"
  :commit "a93aaf4293eb9eea1bd6de415595427763fcfabf"
  :revdesc "a93aaf4293eb"
  :keywords '("languages" "project-management")
  :authors '(("Devrin Talen" . "devrin@fastmail.com"))
  :maintainers '(("Devrin Talen" . "devrin@fastmail.com")))
