;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250519.1933"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "c03e4f3a4768c46cc7c581e52ee130e76a2e0173"
  :revdesc "c03e4f3a4768"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
