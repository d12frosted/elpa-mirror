(define-package "modus-themes" "20211117.1517" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "1ac72499c930435bb86fa9c2205e4c4b6c2699bc" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
