(define-package "cfn-mode" "20231030.957" "AWS cloudformation mode"
  '((emacs "26.0")
    (f "0.20.0")
    (s "1.12.0")
    (yaml-mode "0.0.13"))
  :commit "6dcf0869b1e201c0d87e0e88b170de5b919c3e1c" :authors
  '(("William Orr" . "will@worrbase.com"))
  :maintainers
  '(("William Orr" . "will@worrbase.com"))
  :maintainer
  '("William Orr" . "will@worrbase.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://gitlab.com/worr/cfn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
