;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250524.258"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "20d4e8570beb46c33460112e6692af781f87aa0f"
  :revdesc "20d4e8570beb"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
