;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ztree" "20260722.2128"
  "Text mode directory tree."
  '((cl-lib "0"))
  :url "https://github.com/fourier/ztree"
  :commit "05794afc97a14505c05bee2601b90fa04027bfe0"
  :revdesc "05794afc97a1"
  :keywords '("files" "tools")
  :authors '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com"))
  :maintainers '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com")))
