(define-package "weblorg" "20230703.2141" "Static Site Generator for org-mode"
  '((templatel "0.1.6")
    (emacs "26.1"))
  :commit "9af2294cc0e512b28d1248dd4ad8a0994458df3e" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainers
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
