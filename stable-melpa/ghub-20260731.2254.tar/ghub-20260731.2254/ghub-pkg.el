;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20260731.2254"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "cba5666d8b999e2733aefac369a4e0def3be7fc9"
  :revdesc "cba5666d8b99"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
