(define-package "loopy" "20210706.155" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "37b681b9c0dfc7012210502f4c6862a8018f2b2b" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
