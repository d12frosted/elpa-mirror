;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250225.711"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "d4e5acb876dbf2b55879a22c4b8cd88f614de072"
  :revdesc "d4e5acb876db"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
