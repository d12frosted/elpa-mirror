;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "feed-discovery" "20200714.1118"
  "Discover feed url by RSS/Atom autodiscovery."
  '((emacs "25.1")
    (dash  "2.16.0"))
  :url "https://github.com/HKey/feed-discovery"
  :commit "3812439c845c184eaf164d3ac8935de135259855"
  :revdesc "3812439c845c"
  :authors '(("Hiroki YAMAKAWA" . "s06139@gmail.com"))
  :maintainers '(("Hiroki YAMAKAWA" . "s06139@gmail.com")))
