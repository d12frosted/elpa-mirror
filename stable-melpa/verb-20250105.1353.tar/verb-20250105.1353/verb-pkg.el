;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verb" "20250105.1353"
  "Organize and send HTTP requests."
  '((emacs "26.3"))
  :url "https://github.com/federicotdn/verb"
  :commit "759d258ccd2548b087ca8ca2db56ef0fe6cf4333"
  :revdesc "759d258ccd25"
  :keywords '("tools")
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
