(define-package "elixir-mode" "20210320.1919" "Major mode for editing Elixir files"
  '((emacs "25")
    (pkg-info "0.6"))
  :commit "4745cac297b8d1d0e8153b43f59d2a3650f6f066" :keywords
  '("languages" "elixir")
  :url "https://github.com/elixir-editors/emacs-elixir")
;; Local Variables:
;; no-byte-compile: t
;; End:
