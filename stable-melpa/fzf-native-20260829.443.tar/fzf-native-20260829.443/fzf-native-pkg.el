;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260829.443"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "6c5d4be5fb28afb00cb1aea0a3a6c4e2291957c3"
  :revdesc "6c5d4be5fb28"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
