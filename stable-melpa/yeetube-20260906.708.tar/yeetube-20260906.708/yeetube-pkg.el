;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260906.708"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "b1bd707084b224b52511da69d467086fda7d2d06"
  :revdesc "b1bd707084b2"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
