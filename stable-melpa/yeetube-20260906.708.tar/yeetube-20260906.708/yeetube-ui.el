;;; yeetube-ui.el --- Display layer for yeetube  -*- lexical-binding: t; -*-

;; Copyright (C) 2023-2024  Thanos Apollo

;; Author: Thanos Apollo <public@thanosapollo.org>
;; Keywords: extensions youtube videos
;; URL: https://thanosapollo.org/projects/yeetube/

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;;; Commentary:

;; Display layer for yeetube.  Owns all display concerns: plist-to-vector
;; conversion, faces, sort functions, tabulated-list setup, and thumbnail
;; fetching/rendering.

;;; Code:

(require 'cl-lib)
(require 'image)
(require 'mm-decode)
(require 'tabulated-list)
(require 'url-queue)

;; Forward declarations -- variables from yeetube.el
(defvar yeetube-display-thumbnails-p)
(defvar yeetube-thumbnail-size)
(defvar yeetube-default-sort-column)
(defvar yeetube-default-sort-ascending)
(defvar yeetube-request-headers)

;; Forward declarations -- functions from yeetube.el
(declare-function yeetube--queue-retrieve "yeetube" (url callback cbargs))

(defvar-local yeetube-content nil
  "Tabulated-list rows (ID VECTOR) pairs.")


;;; Faces

(defgroup yeetube-faces nil
  "Faces used by yeetube."
  :group 'yeetube
  :tag "Yeetube Faces"
  :prefix "yeetube-face-")

(defface yeetube-face-header-query
  '((t :inherit font-lock-function-name-face))
  "Face used for the search query header.")

(defface yeetube-face-duration
  '((t :inherit font-lock-string-face))
  "Face used for the video duration.")

(defface yeetube-face-view-count
  '((t :inherit font-lock-keyword-face))
  "Face used for the video view count.")

(defface yeetube-face-title
  '((t :inherit font-lock-variable-use-face))
  "Face used for video title.")

(defface yeetube-face-channel
  '((t :inherit font-lock-function-call-face))
  "Face used for video channel name.")

(defface yeetube-face-date
  '((t :inherit font-lock-doc-face))
  "Face used for published date.")


;;; View count formatting

(defun yeetube-ui--views-number (views-string)
  "Return the numeric view count represented by VIEWS-STRING."
  (let ((case-fold-search t))
    (if (string-match
         "\\([0-9]+\\(?:\\.[0-9]+\\)?\\)[[:space:]]*\\([KMB]\\)"
         views-string)
        (round (* (string-to-number (match-string 1 views-string))
                  (pcase (upcase (match-string 2 views-string))
                    ("K" 1000)
                    ("M" 1000000)
                    ("B" 1000000000))))
      (string-to-number
       (replace-regexp-in-string "[^0-9]" "" views-string)))))

(defun yeetube-ui--format-views (views-string)
  "Format VIEWS-STRING as a comma-separated numeric view count."
  (let* ((views (yeetube-ui--views-number views-string))
         (digits (number-to-string views)))
    (if (not (string-match-p "[0-9]" views-string))
        ""
      (let ((len (length digits)))
        (string-join
         (nreverse
          (cl-loop for i from 0 below len by 3
                   collect (substring digits
                                      (max 0 (- len i 3))
                                      (- len i))))
         ",")))))


;;; Column index helper

(defun yeetube-ui--column-index (name)
  "Return the vector index for column NAME.
Accounts for the thumbnail column offset when thumbnails are enabled."
  (let ((offset (if yeetube-display-thumbnails-p 1 0))
        (base (pcase name
                ("title"    0)
                ("views"    1)
                ("duration" 2)
                ("date"     3)
                ("channel"  4)
                (_ (error "Unknown column: %s" name)))))
    (+ base offset)))


;;; Plist-to-vector conversion

(defun yeetube-ui--entry-to-row (entry)
  "Convert plist ENTRY to a tabulated-list row (ID VECTOR).
The vector layout depends on `yeetube-display-thumbnails-p'."
  (let* ((id (plist-get entry :id))
         (title (plist-get entry :title))
         (views (plist-get entry :views))
         (duration (plist-get entry :duration))
         (date (plist-get entry :date))
         (channel (plist-get entry :channel))
         (playlistp (eq (plist-get entry :type) 'playlist))
         (title-str (propertize (if playlistp
                                    (concat "Playlist: " title)
                                  title)
                                'face 'yeetube-face-title))
         (views-str (propertize (yeetube-ui--format-views (or views ""))
                                'face 'yeetube-face-view-count))
         (duration-str (propertize (or duration "")
                                   'face 'yeetube-face-duration))
         (date-str (propertize (or date "") 'face 'yeetube-face-date))
         (channel-str (propertize (or channel "")
                                  'face 'yeetube-face-channel))
         (fields (list title-str views-str duration-str
                       date-str channel-str)))
    (list id (if yeetube-display-thumbnails-p
                 (apply #'vector (format "[[%s.jpg]]" id) fields)
               (apply #'vector fields)))))


;;; Sort helpers

(defun yeetube-ui--duration-to-seconds (duration)
  "Convert HMS DURATION string to total seconds.
Accepts `H:MM:SS', `M:SS', or bare seconds.  Non-HMS labels such as
playlist counts (`3 videos'), `LIVE', or empty strings return 0 so
duration sort treats them as unknown rather than a small positive
value."
  (if (or (not (stringp duration))
          (string-empty-p duration)
          (not (string-match-p "\\`[0-9]+\\(?::[0-9][0-9]\\)*\\'" duration)))
      0
    (pcase (mapcar #'string-to-number (split-string duration ":"))
      (`(,h ,m ,s) (+ (* h 3600) (* m 60) s))
      (`(,m ,s) (+ (* m 60) s))
      (`(,s) s)
      (_ 0))))

(defun yeetube-ui--parse-relative-date (date &optional now)
  "Convert DATE to comparable epoch seconds (older before newer).

Handles two formats produced by the RSS and HTML sources:

  * ISO-8601 timestamps like \"2026-05-01T12:00:00+00:00\"
    (RSS items), converted with `date-to-time'.
  * Relative strings like \"2 days ago\" (scraper items), converted
    to an approximate absolute epoch by subtracting the age from NOW,
    which defaults to `float-time'.

Unparseable relative units return 0."
  (if (string-match-p "\\`[0-9]\\{4\\}-" date)
      (float-time (date-to-time date))
    (let* ((split-date (split-string date " "))
           (value (string-to-number (nth 0 split-date)))
           (unit (nth 1 split-date))
           (seconds-per-unit
            (pcase unit
              ((or "second" "seconds") 1)
              ((or "minute" "minutes") 60)
              ((or "hour" "hours")     3600)
              ((or "day" "days")       86400)
              ((or "week" "weeks")     604800)
              ((or "month" "months")   2592000)
              ((or "year" "years")     31536000)
              (_ 0))))
      (if (zerop seconds-per-unit)
          0
        (- (or now (float-time)) (* value seconds-per-unit))))))

(defun yeetube-ui--sort-views (a b)
  "Sort entries A and B by view count."
  (let* ((idx (yeetube-ui--column-index "views"))
         (views-a (yeetube-ui--views-number (aref (cadr a) idx)))
         (views-b (yeetube-ui--views-number (aref (cadr b) idx))))
    (< views-a views-b)))

(defun yeetube-ui--sort-duration (a b)
  "Sort entries A and B by duration."
  (let* ((idx (yeetube-ui--column-index "duration"))
         (dur-a (yeetube-ui--duration-to-seconds (aref (cadr a) idx)))
         (dur-b (yeetube-ui--duration-to-seconds (aref (cadr b) idx))))
    (< dur-a dur-b)))

(defun yeetube-ui--sort-date (a b)
  "Sort entries A and B by relative date."
  (let* ((idx (yeetube-ui--column-index "date"))
         (now (float-time))
         (date-a (yeetube-ui--parse-relative-date (aref (cadr a) idx) now))
         (date-b (yeetube-ui--parse-relative-date (aref (cadr b) idx) now)))
    (< date-a date-b)))


;;; Tabulated-list setup

(defun yeetube-ui--tabulated-list-format ()
  "Return the `tabulated-list-format' vector."
  (let* ((w (window-width))
         (thumb-col `("Thumbnail" ,(ceiling (/ (float (car yeetube-thumbnail-size))
                                               (frame-char-width)))
                      nil))
         (columns `[,@(when yeetube-display-thumbnails-p (list thumb-col))
                    ("Title"    ,(/ w 3) t)
                    ("Views"    ,(/ w 10) yeetube-ui--sort-views)
                    ("Duration" ,(/ w 10) yeetube-ui--sort-duration)
                    ("Date"     ,(/ w 8) yeetube-ui--sort-date)
                    ("Channel"  ,(/ w 8) t)]))
    columns))

(defvar-local yeetube-ui--render-owner nil
  "Identity of the current complete results rendering.")

(defun yeetube-ui-render (items)
  "Convert ITEMS (list of plists) to tabulated-list rows and display."
  (let ((rows (mapcar #'yeetube-ui--entry-to-row items)))
    (setf yeetube-ui--render-owner (list 'render)
          yeetube-content rows
          tabulated-list-format (yeetube-ui--tabulated-list-format)
          tabulated-list-entries yeetube-content
          tabulated-list-sort-key
          (when yeetube-default-sort-column
            (cons yeetube-default-sort-column
                  (not yeetube-default-sort-ascending))))
    (tabulated-list-init-header)
    (tabulated-list-print t)))

(defun yeetube-ui-append (items)
  "Append ITEMS to the current yeetube buffer."
  (let* ((yeetube-display-thumbnails-p
          (equal (car (aref tabulated-list-format 0)) "Thumbnail"))
         (new-rows (mapcar #'yeetube-ui--entry-to-row items)))
    (setf yeetube-content (append yeetube-content new-rows)
          tabulated-list-entries yeetube-content)
    (tabulated-list-print t)))


;;; Thumbnail fetching

(defun yeetube-ui--extract-image (status)
  "Extract thumbnail image from the current URL callback buffer.
Return the image sized per `yeetube-thumbnail-size', or nil on error.
STATUS is the URL retrieval callback status plist."
  (unless (plist-get status :error)
    (when-let* ((handle (mm-dissect-buffer t)))
      (unwind-protect
          (when-let* ((image (mm-get-image handle)))
            (setf (image-property image :max-width) (car yeetube-thumbnail-size)
                  (image-property image :max-height) (cdr yeetube-thumbnail-size))
            image)
        (mm-destroy-parts handle)))))

(defun yeetube-ui--image-owned-p (buffer owner layout row)
  "Return non-nil if BUFFER still owns OWNER, LAYOUT and ROW."
  (and (buffer-live-p buffer)
       (with-current-buffer buffer
         (and (derived-mode-p 'yeetube-mode)
              owner (eq owner yeetube-ui--render-owner)
              (eq layout tabulated-list-format)
              (equal (car (aref layout 0)) "Thumbnail")
              (memq row yeetube-content)))))

(defun yeetube-ui--image-callback (status buffer owner layout row)
  "Handle STATUS for BUFFER's thumbnail with OWNER, LAYOUT and ROW.
Discard results when any captured display identity has changed."
  (let ((url-buffer (current-buffer)))
    (unwind-protect
        (when (yeetube-ui--image-owned-p buffer owner layout row)
          (when-let* ((image (yeetube-ui--extract-image status)))
            (when (yeetube-ui--image-owned-p buffer owner layout row)
              (with-current-buffer buffer
                (let ((vec (cadr row)))
                  (aset vec 0 (propertize (aref vec 0) 'display image)))
                (with-silent-modifications
                  (save-excursion
                    (goto-char (point-min))
                    (while (not (eobp))
                      (when (equal (tabulated-list-get-id) (car row))
                        (let ((end (line-end-position)))
                          (when (search-forward
                                 (format "[[%s.jpg]]" (car row)) end t)
                            (add-text-properties (match-beginning 0) (match-end 0)
                                                 `(display ,image)))))
                      (forward-line 1))))))))
      (when (buffer-live-p url-buffer) (kill-buffer url-buffer)))))

(defun yeetube-ui-fetch-thumbnails (items buffer)
  "Fetch thumbnails for ITEMS and display them in BUFFER.
Each element in ITEMS is a plist with at least :id and :thumbnail-url."
  (when-let* ((buffer (get-buffer buffer)))
    (with-current-buffer buffer
      (when (and yeetube-ui--render-owner
                 (equal (car (aref tabulated-list-format 0)) "Thumbnail"))
        (let ((url-request-extra-headers yeetube-request-headers))
          (dolist (item items)
            (let ((url (plist-get item :thumbnail-url))
                  (row (assoc (plist-get item :id) yeetube-content)))
              (when (and row url (not (string-empty-p url)))
                (yeetube--queue-retrieve
                 url #'yeetube-ui--image-callback
                 (list buffer yeetube-ui--render-owner
                       tabulated-list-format row))))))))))

(provide 'yeetube-ui)
;;; yeetube-ui.el ends here
