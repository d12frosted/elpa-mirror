(define-package "wucuo" "20210915.1113" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "cf4cfbcdc8e756986b927224a42a9006d070f36a" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
