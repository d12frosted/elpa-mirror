;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250604.437"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.9.0")
    (magit         "2.1.0")
    (markdown-mode "2.5")
    (s             "1.13.0"))
  :url "https://github.com/tninja/aider.el"
  :commit "a7da9146ace92f4fee04e883c16746778ebf281a"
  :revdesc "a7da9146ace9"
  :keywords '("ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
