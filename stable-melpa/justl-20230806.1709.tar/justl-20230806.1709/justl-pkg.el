(define-package "justl" "20230806.1709" "Major mode for driving just files"
  '((transient "0.1.0")
    (emacs "25.3")
    (s "1.2.0")
    (f "0.20.0"))
  :commit "537323a0e7a1463ac99cebfb324126edfe0a1e80" :authors
  '(("Sibi Prabakaran"))
  :maintainers
  '(("Sibi Prabakaran"))
  :maintainer
  '("Sibi Prabakaran")
  :keywords
  '("just" "justfile" "tools" "processes")
  :url "https://github.com/psibi/justl.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
