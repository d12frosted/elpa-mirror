;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260702.930"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "7961a8b7da8108b76b62033d7cda7b731d4fc3a3"
  :revdesc "7961a8b7da81"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
