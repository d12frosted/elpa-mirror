(define-package "exercism" "20230822.1147" "Unofficial https://exercism.org integration"
  '((emacs "27.1")
    (dash "2.19.1")
    (a "1.0.0")
    (s "1.13.1")
    (request "0.3.2")
    (async "1.9.6")
    (async-await "1.1")
    (persist "0.5")
    (transient "0.3.7"))
  :commit "6b3d7ba0347aeb17098eb6d7656176a91280f88b" :authors
  '(("Rafael Nicdao <https://github.com/anonimito>"))
  :maintainers
  '(("Rafael Nicdao" . "nicdaoraf@gmail.com"))
  :maintainer
  '("Rafael Nicdao" . "nicdaoraf@gmail.com")
  :keywords
  '("exercism" "convenience")
  :url "https://github.com/anonimitoraf/exercism.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
