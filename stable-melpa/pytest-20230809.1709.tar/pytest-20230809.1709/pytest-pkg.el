(define-package "pytest" "20230809.1709" "Easy Python test running in Emacs"
  '((s "1.9.0"))
  :commit "6ac179a8ddafa8b2193f19467e347fd966470358" :keywords
  '("pytest" "python" "testing")
  :url "https://github.com/ionrock/pytest-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
