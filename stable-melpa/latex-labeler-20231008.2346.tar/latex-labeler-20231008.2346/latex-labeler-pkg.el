(define-package "latex-labeler" "20231008.2346" "Simplify equation labeling in LaTeX"
  '((emacs "28.1"))
  :commit "deac33bd167f638d8695920e97b9c0df9b4f337e" :authors
  '(("X9hRRDys"))
  :maintainers
  '(("X9hRRDys"))
  :maintainer
  '("X9hRRDys")
  :keywords
  '("tools")
  :url "https://github.com/X9hRRDys/latex-labeler")
;; Local Variables:
;; no-byte-compile: t
;; End:
