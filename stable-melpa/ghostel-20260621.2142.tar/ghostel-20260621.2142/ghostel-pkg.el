;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260621.2142"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "0194b15ec957a6ce4be2ff49c4c485f648f86d0d"
  :revdesc "0194b15ec957"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
