(define-package "dwim-shell-command" "20231024.1346" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "19be1c2f3792c95f04fd369cb931a52f7df9cfd5" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
