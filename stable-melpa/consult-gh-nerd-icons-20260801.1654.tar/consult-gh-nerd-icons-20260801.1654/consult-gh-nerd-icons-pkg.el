;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-nerd-icons" "20260801.1654"
  "Nerd icons integration for consult-gh."
  '((emacs      "29.4")
    (nerd-icons "0.1.0")
    (consult-gh "3.1"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "c8707e86d36ea4ec38e177ca8fa0313a5374a0a9"
  :revdesc "c8707e86d36e"
  :keywords '("matching" "git" "repositories" "completion"))
