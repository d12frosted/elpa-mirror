;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260521.631"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "fb07ea87f0c50bd2b1cecbad8a80164f66e0a358"
  :revdesc "fb07ea87f0c5"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
