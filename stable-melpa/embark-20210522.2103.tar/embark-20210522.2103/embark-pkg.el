(define-package "embark" "20210522.2103" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "f52f9a34893a0dda493e22326aa859545a56bfe8" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
