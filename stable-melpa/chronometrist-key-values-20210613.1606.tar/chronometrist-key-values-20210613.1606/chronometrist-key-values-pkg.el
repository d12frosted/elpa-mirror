(define-package "chronometrist-key-values" "20210613.1606" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "86d2739e4f5f965c58f75aa68697f809ee9e0776" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
