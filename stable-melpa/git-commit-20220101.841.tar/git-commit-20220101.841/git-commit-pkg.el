(define-package "git-commit" "20220101.841" "Edit Git commit messages."
  '((emacs "25.1")
    (dash "20210826")
    (transient "20210920")
    (with-editor "20211001"))
  :commit "a6ab38b7017d14aa62d0d2b95b7a8a4668781ab0" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li")
    ("Sebastian Wiesner" . "lunaryorn@gmail.com")
    ("Florian Ragwitz" . "rafl@debian.org")
    ("Marius Vollmer" . "marius.vollmer@gmail.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
