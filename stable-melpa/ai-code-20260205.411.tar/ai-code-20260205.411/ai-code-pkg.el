;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260205.411"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "83707d0d102772329ee7ab385fcdf808d7d8412c"
  :revdesc "83707d0d1027"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
