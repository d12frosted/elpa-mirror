;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260218.1919"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "f1cd680918d6e3c28247b54fb199e186ef9cfd9d"
  :revdesc "f1cd680918d6"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
