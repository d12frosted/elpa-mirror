;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy" "20250322.1554"
  "Incremental Vertical completYon."
  '((emacs "24.5"))
  :url "https://github.com/abo-abo/swiper"
  :commit "847ba97f6b089dba659730929b23900e824d9aab"
  :revdesc "847ba97f6b08"
  :keywords '("matching")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
