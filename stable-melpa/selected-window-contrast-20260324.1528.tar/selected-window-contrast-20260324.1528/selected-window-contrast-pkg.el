;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260324.1528"
  "Highlight window and cursor at switching."
  '((emacs "26.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "3e675bac6348adfb93e67a8259366dc085c6a49f"
  :revdesc "3e675bac6348"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
