;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260804.607"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "64738d458214bbacef85b0cc4f14712d065bc049"
  :revdesc "64738d458214")
