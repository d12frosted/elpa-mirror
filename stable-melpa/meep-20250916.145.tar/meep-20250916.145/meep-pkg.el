;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250916.145"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a439625b7174faff1c793ba167bec2557ca86de1"
  :revdesc "a439625b7174"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
