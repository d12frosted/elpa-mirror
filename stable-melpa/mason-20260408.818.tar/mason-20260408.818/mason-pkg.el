;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20260408.818"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/mason-org/mason.el"
  :commit "04bbb755f00dd81862364a501247d113f237788f"
  :revdesc "04bbb755f00d"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
