;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260511.24"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "130990866e89084d46f4ab91ac69a8c1a80540ba"
  :revdesc "130990866e89")
