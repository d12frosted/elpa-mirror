;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250311.622"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "4edf81cb7ad680280549e2fcf63ba4e4dc7e51d5"
  :revdesc "4edf81cb7ad6"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
