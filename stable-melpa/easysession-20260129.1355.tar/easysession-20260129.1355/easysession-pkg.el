;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260129.1355"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "8a2405c0fdcec5fdcac7992e72a08f4ea7d88173"
  :revdesc "8a2405c0fdce"
  :keywords '("convenience"))
