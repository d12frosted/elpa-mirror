;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20241202.1540"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "abf9a7f5c709943243a940491ab386d43b26e61c"
  :revdesc "abf9a7f5c709"
  :keywords '("outlines"))
