;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20251217.639"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "7d70f29a6005bb403696c0b29ddd267339208c3e"
  :revdesc "7d70f29a6005"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
