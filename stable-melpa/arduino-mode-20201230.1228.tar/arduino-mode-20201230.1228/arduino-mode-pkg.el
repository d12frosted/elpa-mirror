(define-package "arduino-mode" "20201230.1228" "Major mode for editing Arduino code"
  '((emacs "25.1")
    (spinner "1.7.3"))
  :commit "b1e264568688a1225126c7b9e522bcdc394f354c" :maintainer
  ("stardiviner" . "numbchild@gmail.com")
  :keywords
  ("languages" "arduino")
  :url "https://github.com/stardiviner/arduino-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
