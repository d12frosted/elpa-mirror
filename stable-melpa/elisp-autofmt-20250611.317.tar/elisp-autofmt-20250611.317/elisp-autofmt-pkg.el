;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-autofmt" "20250611.317"
  "Emacs lisp auto-format."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt"
  :commit "36dc2c5125e65b63614c1a9fe8bf3de6b47f06c9"
  :revdesc "36dc2c5125e6"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
