(define-package "bug-reference-github" "20180128.1314" "Set `bug-reference-url-format' in Github repos" 'nil :commit "f570a0532bfb44f095b42cf68ab1f69799101137" :authors
  '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainer
  '("Arne Jørgensen" . "arne@arnested.dk")
  :keywords
  '("programming" "tools")
  :url "https://github.com/arnested/bug-reference-github")
;; Local Variables:
;; no-byte-compile: t
;; End:
