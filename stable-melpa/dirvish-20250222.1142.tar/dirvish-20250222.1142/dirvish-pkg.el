;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250222.1142"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "c867162cc9c0764b183fcf16e2db467165942135"
  :revdesc "c867162cc9c0"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
