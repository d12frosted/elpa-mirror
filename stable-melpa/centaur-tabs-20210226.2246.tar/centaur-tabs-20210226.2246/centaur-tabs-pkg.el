(define-package "centaur-tabs" "20210226.2246" "Aesthetic, modern looking customizable tabs plugin"
  '((emacs "24.4")
    (powerline "2.4")
    (cl-lib "0.5"))
  :commit "bee1c09ce48a604ff1cf1fe6f15183baba94c2f4" :authors
  '(("Emmanuel Bustos" . "ema2159@gmail.com"))
  :maintainer
  '("Emmanuel Bustos" . "ema2159@gmail.com")
  :url "https://github.com/ema2159/centaur-tabs")
;; Local Variables:
;; no-byte-compile: t
;; End:
