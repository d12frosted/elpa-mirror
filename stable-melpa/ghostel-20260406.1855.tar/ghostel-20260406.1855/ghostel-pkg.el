;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260406.1855"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "20acc2181d40e6a819c9b76a65fdb6ecfbc3426e"
  :revdesc "20acc2181d40"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
