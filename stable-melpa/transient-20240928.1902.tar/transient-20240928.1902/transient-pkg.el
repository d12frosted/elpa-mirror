(define-package "transient" "20240928.1902" "Transient commands"
  '((emacs "26.1")
    (compat "30.0.0.0")
    (seq "2.24"))
  :commit "683e5104a0dd724b080043af078030db521858b1" :authors
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
