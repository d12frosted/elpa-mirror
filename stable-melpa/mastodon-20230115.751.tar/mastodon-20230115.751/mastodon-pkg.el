(define-package "mastodon" "20230115.751" "Client for Mastodon, a federated social network"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4")
    (ts "0.3"))
  :commit "c366effc9b602f7d5c5e0fdf37233c83f5028e08" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
