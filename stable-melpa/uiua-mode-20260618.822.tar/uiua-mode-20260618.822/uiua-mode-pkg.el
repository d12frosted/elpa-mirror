;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uiua-mode" "20260618.822"
  "Uiua integration."
  '((emacs       "27.1")
    (reformatter "0.8"))
  :url "https://github.com/crmsnbleyd/uiua-mode"
  :commit "4194e877aef707f8475c3632390179b03571d091"
  :revdesc "4194e877aef7"
  :keywords '("languages" "uiua"))
