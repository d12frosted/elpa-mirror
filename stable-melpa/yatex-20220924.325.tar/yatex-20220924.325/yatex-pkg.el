(define-package "yatex" "20220924.325" "Yet Another tex-mode for emacs //野鳥//" 'nil :commit "86ceef677ca2804f00cb966b538a27928a28fe77")
;; Local Variables:
;; no-byte-compile: t
;; End:
