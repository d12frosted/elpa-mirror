(define-package "osm" "20220330.2019" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "a0191917fa672636da916fb2ba119ad6cdf77e11" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
