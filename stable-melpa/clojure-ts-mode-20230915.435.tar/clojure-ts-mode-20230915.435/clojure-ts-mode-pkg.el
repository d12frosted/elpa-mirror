(define-package "clojure-ts-mode" "20230915.435" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "5e7506e61401f92df1f86677051b55fec0ad6ce8" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
