(define-package "detached" "20220825.1830" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "a453de761b02e118d231bb6e31c8398cb2180ac3" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
