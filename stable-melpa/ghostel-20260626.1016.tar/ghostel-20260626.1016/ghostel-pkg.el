;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260626.1016"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b896dddff2a7b8e2217883bd27d452e1902f3011"
  :revdesc "b896dddff2a7"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
