;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260304.1943"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "0cdd2a93b2def8b432348f183dc583e9ebdbd709"
  :revdesc "0cdd2a93b2de"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
