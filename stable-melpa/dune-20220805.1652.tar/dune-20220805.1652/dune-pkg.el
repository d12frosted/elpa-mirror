(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "53b44274499ca26cd35362d20521ba14b3d18310" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
