(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "912a314496710b252b57836081bb6c88df161ef5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
