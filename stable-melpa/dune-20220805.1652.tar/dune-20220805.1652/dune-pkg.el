(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "5226892d224c88e9cd5e33e4ba9cde8b5b63c5ba" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
