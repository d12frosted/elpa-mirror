(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "fcb7897122e337da04b8d579fa20dda4073f8c97" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
