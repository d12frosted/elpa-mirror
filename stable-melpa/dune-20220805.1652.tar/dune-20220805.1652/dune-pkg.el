(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "c1e91da50d5131b1f64646b3e3c0febf91851735" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
