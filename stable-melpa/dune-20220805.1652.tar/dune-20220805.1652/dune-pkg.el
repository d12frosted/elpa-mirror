(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "69fde058a1a338fc7ff968c2d4dd6790be029284" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
