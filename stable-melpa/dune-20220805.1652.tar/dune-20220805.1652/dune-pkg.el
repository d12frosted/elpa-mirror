(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "5f57885f01175c239ec6bf2dc7c828c74361e64e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
