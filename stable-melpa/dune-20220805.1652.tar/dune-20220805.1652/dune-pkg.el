(define-package "dune" "20220805.1652" "Integration with the dune build system" 'nil :commit "79d6602296f28d2b817f3659354482be48bacd8e" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
