;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251016.216"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "c2a4a14a8393e24c847ecbd841e2cdd68738915f"
  :revdesc "c2a4a14a8393"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
