;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20261014.1800"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "31c2a36f00dd5d232b07efa7745a2b387e237b85"
  :revdesc "31c2a36f00dd"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
