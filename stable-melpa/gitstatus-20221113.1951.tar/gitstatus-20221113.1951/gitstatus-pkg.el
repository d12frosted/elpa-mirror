(define-package "gitstatus" "20221113.1951" "Common front-end for `gitstatusd'"
  '((emacs "25.1"))
  :commit "c3e30341d0add9728010e566b9eb031c76414b47" :authors
  '(("Igor Epstein" . "igorepst@gmail.com"))
  :maintainer
  '("Igor Epstein" . "igorepst@gmail.com")
  :keywords
  '("tools" "processes")
  :url "https://github.com/igorepst/gitstatus-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
