(define-package "autocrypt" "20210412.1127" "Autocrypt implementation"
  '((emacs "25.1")
    (cl-generic "0.3"))
  :commit "40b7576aad14eb52a24638358ed8519f8217c47a" :authors
  '(("Philip K." . "philip@warpmail.net"))
  :maintainer
  '("Philip K." . "philip@warpmail.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~zge/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
