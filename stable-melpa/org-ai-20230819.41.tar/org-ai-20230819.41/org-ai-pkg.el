(define-package "org-ai" "20230819.41" "Your AI assistant with ChatGPT, DALL-E, Whisper, Stable Diffusion"
  '((emacs "27"))
  :commit "ff17ddddb6f37647cbb39878261661372012c5f5" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
