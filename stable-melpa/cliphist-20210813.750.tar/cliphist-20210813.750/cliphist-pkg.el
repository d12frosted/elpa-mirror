(define-package "cliphist" "20210813.750" "paste from clipboard managers"
  '((emacs "25.1"))
  :commit "a794c95e2f70a9b042af7bd07e2483fde75f2a2e" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("clipboard" "manager" "history")
  :url "http://github.com/redguardtoo/cliphist")
;; Local Variables:
;; no-byte-compile: t
;; End:
