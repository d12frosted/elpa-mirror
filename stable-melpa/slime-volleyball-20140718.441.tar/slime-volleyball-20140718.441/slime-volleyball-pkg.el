(define-package "slime-volleyball" "20140718.441" "An SVG Slime Volleyball Game" 'nil :commit "159b5c0f40b109e3854e94b89ec5383854c46ae3" :authors
  '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
  :maintainer
  '("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")
  :keywords
  '("games"))
;; Local Variables:
;; no-byte-compile: t
;; End:
