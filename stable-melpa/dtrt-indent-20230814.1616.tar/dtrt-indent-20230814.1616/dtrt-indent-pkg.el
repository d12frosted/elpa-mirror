(define-package "dtrt-indent" "20230814.1616" "Adapt to foreign indentation offsets" 'nil :commit "6b16cb5e4a01a3d88c3566d15d23a5d6a1d0693f" :authors
  '(("Julian Scheid" . "julians37@googlemail.com"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("convenience" "files" "languages" "c"))
;; Local Variables:
;; no-byte-compile: t
;; End:
