(define-package "cbor" "20230606.1150" "CBOR utilities"
  '((emacs "25.1"))
  :commit "cf85424b305e8f89debb756dc67eebc84639f711" :authors
  '(("Oscar Najera <https://oscarnajera.com>"))
  :maintainers
  '(("Oscar Najera" . "hi@oscarnajera.com"))
  :maintainer
  '("Oscar Najera" . "hi@oscarnajera.com")
  :url "https://github.com/Titan-C/cardano.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
