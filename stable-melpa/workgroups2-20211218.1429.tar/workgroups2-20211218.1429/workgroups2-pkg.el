(define-package "workgroups2" "20211218.1429" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "fdc97541808de449efecc7f2ce726c5de4abeb57" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
