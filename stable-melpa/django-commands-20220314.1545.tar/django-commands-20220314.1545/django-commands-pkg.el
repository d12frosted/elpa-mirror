;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "django-commands" "20220314.1545"
  "Run django commands."
  '((emacs "25.1"))
  :url "https://github.com/muffinmad/emacs-django-commands"
  :commit "7510c0f068bf214ad012c203d68e03ff4262efdf"
  :revdesc "7510c0f068bf"
  :keywords '("tools")
  :authors '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com"))
  :maintainers '(("Andrii Kolomoiets" . "andreyk.mad@gmail.com")))
