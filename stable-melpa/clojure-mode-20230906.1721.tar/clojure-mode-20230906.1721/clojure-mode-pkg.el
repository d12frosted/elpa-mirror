(define-package "clojure-mode" "20230906.1721" "Major mode for Clojure code"
  '((emacs "25.1"))
  :commit "e18a1bf4b931a31f857fd1a873264a04eb4b1a39" :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.dev")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "https://github.com/clojure-emacs/clojure-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
