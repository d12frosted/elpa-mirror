;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260714.448"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "14cfe870eec4a3963ff66201ad439e1757118190"
  :revdesc "14cfe870eec4"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
