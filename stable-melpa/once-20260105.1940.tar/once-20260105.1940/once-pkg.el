;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "once" "20260105.1940"
  "Add-hook and eval-after-load, but only once."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/once"
  :commit "65c654a18855df21a2f8f4721e2beabab4d29949"
  :revdesc "65c654a18855"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
