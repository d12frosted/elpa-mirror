;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shoulda" "20140616.1833"
  "Shoulda test support for ruby."
  '((cl-lib "0.5"))
  :url "https://github.com/marcwebbie/shoulda.el"
  :commit "24dc6b6138a06edde9c8d13a6aaa1654d1d7de54"
  :revdesc "24dc6b6138a0"
  :keywords '("ruby" "tests" "shoulda")
  :authors '(("Marcwebbie" . "marcwebbie@gmail.com"))
  :maintainers '(("Marcwebbie" . "marcwebbie@gmail.com")))
