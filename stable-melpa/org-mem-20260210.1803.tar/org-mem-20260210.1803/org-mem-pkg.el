;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260210.1803"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "c73491a8522bafbc915e9b7d6a91eb3ce51e4382"
  :revdesc "c73491a8522b"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
