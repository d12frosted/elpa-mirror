(define-package "cangjie" "20211201.2307" "Retrieve cangjie code for han characters"
  '((emacs "24.4")
    (s "1.12.0")
    (dash "2.14.1")
    (f "0.2.0"))
  :commit "87408d79b73a69194842a8848de6d7708e98c3a4" :keywords
  '("convenience" "writing")
  :url "https://github.com/kisaragi-hiu/cangjie.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
