;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260311.1756"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "5ae161e111ada2526c479d4b8f7de8ff84ba5353"
  :revdesc "5ae161e111ad"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
