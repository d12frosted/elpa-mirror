;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gruvbox-theme" "20261110.242"
  "A retro-groove colour theme for Emacs."
  '((autothemer "0.2.19"))
  :url "https://github.com/greduan/emacs-theme-gruvbox"
  :commit "351a3ced876fe0b294398ef6bb37c8b7b8a246a7"
  :revdesc "351a3ced876f"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
