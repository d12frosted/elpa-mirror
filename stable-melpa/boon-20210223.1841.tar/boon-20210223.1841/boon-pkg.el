(define-package "boon" "20210223.1841" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "a8bd0b8fab4cbe3d20009e89a6888926de1a4145")
;; Local Variables:
;; no-byte-compile: t
;; End:
