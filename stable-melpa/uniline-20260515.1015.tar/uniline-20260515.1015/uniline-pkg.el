;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260515.1015"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "b49f334c2dd4d58d717a57ebdead8a9f343e748b"
  :revdesc "b49f334c2dd4"
  :keywords '("convenience" "text"))
