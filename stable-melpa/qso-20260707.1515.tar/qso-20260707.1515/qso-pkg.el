;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qso" "20260707.1515"
  "Amateur radio QSO logging."
  '((emacs "25.1"))
  :url "https://github.com/K6SM/Emacs-QSO-Logger"
  :commit "a3b0d1f0b103cd00e0980637d75b6e3092d07b48"
  :revdesc "a3b0d1f0b103"
  :keywords '("lisp"))
