;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260718.1216"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "8e81e61bafc00d72a14b1450330392f896b4c2b3"
  :revdesc "8e81e61bafc0"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
