(define-package "embark" "20210303.449" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "4bb320a56530b33c5d550d0c72d9c9e300a50081" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
