(define-package "boon" "20210213.2153" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "7085e68c26b869fd89c4c51114a6988113c24dac")
;; Local Variables:
;; no-byte-compile: t
;; End:
