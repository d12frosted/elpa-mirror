;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabbar-ruler" "20260426.1441"
  "Pretty tabbar, autohide, use both tabbar/ruler."
  '((tabbar     "2.0.1")
    (powerline  "2.3")
    (mode-icons "0.4.0")
    (cl-lib     "0.5"))
  :url "https://github.com/mlf176f2/tabbar-ruler.el"
  :commit "306fc4f8e450704c68fca23791cfa50f2f9f99db"
  :revdesc "306fc4f8e450"
  :keywords '("tabbar" "ruler mode" "menu" "tool bar."))
