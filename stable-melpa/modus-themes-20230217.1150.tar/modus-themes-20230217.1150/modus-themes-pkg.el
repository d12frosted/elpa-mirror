(define-package "modus-themes" "20230217.1150" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "39ac76907ca1ffb33167c72036b35814c07e9587" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
