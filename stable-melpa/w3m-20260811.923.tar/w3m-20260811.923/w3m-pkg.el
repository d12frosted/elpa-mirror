;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "w3m" "20260811.923"
  "An Emacs interface to w3m."
  ()
  :url "https://github.com/emacs-w3m/emacs-w3m"
  :commit "bb01ba0329ee5b02c2ff260d8881bbc6f389d80a"
  :revdesc "bb01ba0329ee"
  :keywords '("w3m" "www" "hypermedia")
  :authors '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
             ("Shun-ichi GOTO" . "gotoh@taiyo.co.jp")
             ("Satoru Takabayashi" . "satoru-t@is.aist-nara.ac.jp")
             ("Hideyuki SHIRAI" . "shirai@meadowy.org")
             ("Keisuke Nishida" . "kxn30@po.cwru.edu")
             ("Yuuichi Teranishi" . "teranisi@gohome.org")
             ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
             ("Katsumi Yamaoka" . "yamaoka@jpl.org")
             ("Tsuyoshi CHO" . "Tsuyoshi.CHO@Gmail.com"))
  :maintainers '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
                 ("Shun-ichi GOTO" . "gotoh@taiyo.co.jp")
                 ("Satoru Takabayashi" . "satoru-t@is.aist-nara.ac.jp")
                 ("Hideyuki SHIRAI" . "shirai@meadowy.org")
                 ("Keisuke Nishida" . "kxn30@po.cwru.edu")
                 ("Yuuichi Teranishi" . "teranisi@gohome.org")
                 ("Akihiro Arisawa" . "ari@mbf.sphere.ne.jp")
                 ("Katsumi Yamaoka" . "yamaoka@jpl.org")
                 ("Tsuyoshi CHO" . "Tsuyoshi.CHO@Gmail.com")))
