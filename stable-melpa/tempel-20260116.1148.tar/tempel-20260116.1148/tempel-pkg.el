;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260116.1148"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "ee27b68dfde00bc8d47054812ab17a7c0aad0e75"
  :revdesc "ee27b68dfde0"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
