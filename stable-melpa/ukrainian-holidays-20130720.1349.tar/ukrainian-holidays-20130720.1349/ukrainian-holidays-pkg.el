;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ukrainian-holidays" "20130720.1349"
  "Ukrainian holidays for Emacs calendar."
  ()
  :url "https://github.com/abo-abo/ukrainian-holidays"
  :commit "e52b0c92843e9f4d0415a7ba3b8559785497d23d"
  :revdesc "e52b0c92843e"
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
