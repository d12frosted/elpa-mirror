;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shen-elisp" "20221211.1313"
  "Shen implementation in Elisp."
  '((emacs "24.4"))
  :url "https://github.com/deech/shen-elisp"
  :commit "957ab44654fc7a7cc1b78181d244fa25166f9b09"
  :revdesc "957ab44654fc"
  :authors '(("Aditya Siram" . "aditya.siram@gmail.com"))
  :maintainers '(("Aditya Siram" . "aditya.siram@gmail.com")))
