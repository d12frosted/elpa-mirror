(define-package "consult" "20221220.2150" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "4ff45b378210ce4bc942eb366011ee647f575506" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
