;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260303.701"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.86.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4ad3dc9ec384a098d54f2868900c4ec48b82678c"
  :revdesc "4ad3dc9ec384")
