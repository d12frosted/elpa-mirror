;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flx-ido" "20261017.750"
  "Flx integration for ido."
  '((emacs "24.3")
    (flx   "0.6.4"))
  :url "https://github.com/lewang/flx"
  :commit "be738f439fa779c5a5def44569202d2d7c6b0547"
  :revdesc "be738f439fa7")
