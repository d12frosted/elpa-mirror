(define-package "elisp-autofmt" "20221228.438" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "d1d3dab81bf27a51dfbd2c288ffcd322ac1a602f" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
