(define-package "whois" "20231212.1853" "Syntax highlighted domain name queries using system whois"
  '((emacs "24"))
  :commit "6030a2fad9df7e2668bfd9d4d7a8e633c4ceaa9a" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("network" "comm")
  :url "https://github.com/lassik/emacs-whois")
;; Local Variables:
;; no-byte-compile: t
;; End:
