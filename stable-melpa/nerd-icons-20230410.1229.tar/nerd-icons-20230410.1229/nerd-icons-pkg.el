(define-package "nerd-icons" "20230410.1229" "Emacs Nerd Font Icons Library"
  '((emacs "24.3"))
  :commit "a945a14c76b205da44cbe51d1e56a3d2d98ec504" :authors
  '(("Hongyu Ding <rainstormstudio@yahoo.com>, Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Hongyu Ding <rainstormstudio@yahoo.com>, Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/rainstormstudio/nerd-icons.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
