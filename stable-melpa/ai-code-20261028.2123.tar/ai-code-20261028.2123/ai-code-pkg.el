;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261028.2123"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "ac8978c9e9d18a14d4dad3b1cc9d18affc20b761"
  :revdesc "ac8978c9e9d1"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
