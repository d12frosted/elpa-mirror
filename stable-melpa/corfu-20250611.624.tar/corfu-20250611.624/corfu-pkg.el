;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250611.624"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "4ec58942e12f6808d45b4deab15c1ecec277ceaa"
  :revdesc "4ec58942e12f"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
