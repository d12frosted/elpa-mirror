(define-package "proof-general" "20210820.2321" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "25.1"))
  :commit "f84e634c99d0c6bad17e8840baf7b6173563188f" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
