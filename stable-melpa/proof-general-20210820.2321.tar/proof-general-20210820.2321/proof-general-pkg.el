(define-package "proof-general" "20210820.2321" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "25.1"))
  :commit "cc5bfd0b5524313313c8e394656cdb5321b62a42" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
