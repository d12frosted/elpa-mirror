(define-package "catppuccin-theme" "20221011.147" "Catppuccin Theme"
  '((emacs "25.1"))
  :commit "005a9765678078908c2e77ba17a08db3e87ca265" :authors
  '(("pspiagicw"))
  :maintainer
  '("pspiagicw" . "pspiagicw@gmail.com")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
