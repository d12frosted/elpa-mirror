;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260523.926"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "07b3bf5c438a847902ca44a7d73d116fccf677a2"
  :revdesc "07b3bf5c438a"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
