(define-package "recursion-indicator" "20230410.1753" "Recursion indicator"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "95eb885d8719e5e31a42fc99a6a76812fd38df8d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience")
  :url "https://github.com/minad/recursion-indicator")
;; Local Variables:
;; no-byte-compile: t
;; End:
