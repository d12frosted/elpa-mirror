;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-explorer" "20260306.522"
  "Provide Explorer-like file selection in Dired."
  '((emacs "24.3"))
  :url "https://github.com/jidaikobo-shibata/dired-explorer"
  :commit "4d36d3ad18a310843f96bd35ff3aabc4406b4854"
  :revdesc "4d36d3ad18a3"
  :keywords '("dired" "explorer"))
