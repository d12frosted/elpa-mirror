(define-package "posframe" "20220107.1307" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "0b1a82539c4fa08e2b97c733c64dfd259bb4bbda" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
