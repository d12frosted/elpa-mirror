(define-package "notmuch" "20221105.1730" "run notmuch within emacs" 'nil :commit "82aa1acc0c6a66eb3b771357e513eb4d16f9f276" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
