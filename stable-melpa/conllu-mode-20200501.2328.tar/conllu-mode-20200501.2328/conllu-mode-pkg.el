;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conllu-mode" "20200501.2328"
  "Editing mode for CoNLL-U files."
  '((emacs    "25")
    (cl-lib   "0.5")
    (flycheck "30")
    (hydra    "0.13.0")
    (s        "1.0"))
  :url "https://github.com/odanoburu/conllu-mode"
  :commit "0db3063572b0de08874822e20570bb153747e6ed"
  :revdesc "0db3063572b0"
  :keywords '("extensions")
  :authors '(("bruno cuconato" . "bcclaro+emacs@gmail.com"))
  :maintainers '(("bruno cuconato" . "bcclaro+emacs@gmail.com")))
