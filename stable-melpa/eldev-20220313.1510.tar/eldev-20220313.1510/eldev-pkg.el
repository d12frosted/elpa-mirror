(define-package "eldev" "20220313.1510" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "bdc729893ccfc52b2b7369624111cc175e4ce0b9" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
