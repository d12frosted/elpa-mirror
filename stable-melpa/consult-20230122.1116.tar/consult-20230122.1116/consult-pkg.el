(define-package "consult" "20230122.1116" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "234b131a699f51350e26b41af5a42ade8e6ff1f6" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
