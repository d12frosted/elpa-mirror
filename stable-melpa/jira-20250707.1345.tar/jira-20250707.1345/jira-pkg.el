;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20250707.1345"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "7d501dad3a07df7db63d4de0f04ebe3119fc1b1c"
  :revdesc "7d501dad3a07"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
