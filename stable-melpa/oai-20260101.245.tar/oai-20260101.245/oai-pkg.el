;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260101.245"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "0e642ab5dd0556267cd111c07363f389ea0432ef"
  :revdesc "0e642ab5dd05"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
