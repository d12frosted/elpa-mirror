;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-runbook" "20230503.319"
  "Org mode for runbooks."
  '((emacs    "27.1")
    (seq      "2.3")
    (f        "0.20.0")
    (s        "1.12.0")
    (dash     "2.17.0")
    (mustache "0.24")
    (ht       "0.9")
    (ivy      "0.8.0"))
  :url "https://github.com/tyler-dodge/org-runbook"
  :commit "7ada3903a56266d60541d59ae92410e8ab6fe836"
  :revdesc "7ada3903a562"
  :keywords '("convenience" "processes" "terminals" "files"))
