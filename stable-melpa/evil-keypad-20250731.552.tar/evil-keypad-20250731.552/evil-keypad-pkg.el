;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-keypad" "20250731.552"
  "Modal command dispatch for evil-mode."
  '((emacs "30.1")
    (evil  "1.0.0"))
  :url "https://github.com/achyudh/evil-keypad"
  :commit "f384b88180154f86bf70adf5f018faed6c68a509"
  :revdesc "f384b8818015"
  :keywords '("convenience" "emulation")
  :authors '(("Achyudh Ram" . "mail@achyudh.me"))
  :maintainers '(("Achyudh Ram" . "mail@achyudh.me")))
