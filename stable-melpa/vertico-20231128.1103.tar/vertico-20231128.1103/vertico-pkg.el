(define-package "vertico" "20231128.1103" "VERTical Interactive COmpletion"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "43c09021dd90fa566eea12c2fbde57b186a44bf2" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "files" "matching" "completion")
  :url "https://github.com/minad/vertico")
;; Local Variables:
;; no-byte-compile: t
;; End:
