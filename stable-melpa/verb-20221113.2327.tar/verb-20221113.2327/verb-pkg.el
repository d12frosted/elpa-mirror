(define-package "verb" "20221113.2327" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "b8ff1a0bbf84920fe26c56b9658bd289f43ad100" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
