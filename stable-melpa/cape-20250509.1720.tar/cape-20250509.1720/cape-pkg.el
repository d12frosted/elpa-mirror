;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20250509.1720"
  "Completion At Point Extensions."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "383fab93cbba6ef0a6a389b1a0e01f88a3d7e2d5"
  :revdesc "383fab93cbba"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
