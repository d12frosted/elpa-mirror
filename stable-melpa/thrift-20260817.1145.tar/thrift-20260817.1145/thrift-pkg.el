;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260817.1145"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "aa5b04ae9fbcbfde46a7ea6e9b405fe38a8c8592"
  :revdesc "aa5b04ae9fbc"
  :keywords '("languages"))
