(define-package "evil-matchit" "20220524.1108" "Vim matchit ported to Evil"
  '((emacs "25.1"))
  :commit "15de058e005e62efdfd553dfdd4a644c5751b755" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
