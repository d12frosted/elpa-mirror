;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-consult" "20261105.513"
  "Consult UI for agent-shell."
  '((emacs       "29.1")
    (agent-shell "0.83.4")
    (acp         "0.18.1")
    (consult     "3.0"))
  :url "https://github.com/Gleek/agent-shell-consult"
  :commit "78a1056275cd26a7a8675f43e1499bd8d0a7aa53"
  :revdesc "78a1056275cd"
  :keywords '("convenience" "processes" "tools")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
