;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-semantic" "20261021.1032"
  "Search org notes by meaning, or by word."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/org-semantic"
  :commit "d528cab5bad303afa9fd96b4cdfc6e7c962de405"
  :revdesc "d528cab5bad3"
  :keywords '("outlines" "matching" "convenience")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
