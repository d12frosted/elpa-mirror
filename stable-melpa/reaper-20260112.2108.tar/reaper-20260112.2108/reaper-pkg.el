;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reaper" "20260112.2108"
  "Interact with Harvest time tracking app."
  '((emacs "26.2"))
  :url "https://github.com/xendk/reaper"
  :commit "5e8a5b185cb4ebdc5ab45d2782bee59cca011dd3"
  :revdesc "5e8a5b185cb4"
  :keywords '("tools")
  :authors '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers '(("Thomas Fini Hansen" . "xen@xen.dk")))
