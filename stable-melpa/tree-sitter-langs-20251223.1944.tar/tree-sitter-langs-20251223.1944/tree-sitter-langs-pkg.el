;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-langs" "20251223.1944"
  "Grammar bundle for tree-sitter."
  '((emacs       "26.1")
    (tree-sitter "0.15.0"))
  :url "https://github.com/emacs-tree-sitter/tree-sitter-langs"
  :commit "fd2d33a49697ab6d65d5aa055085d4f390dc159e"
  :revdesc "fd2d33a49697"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
