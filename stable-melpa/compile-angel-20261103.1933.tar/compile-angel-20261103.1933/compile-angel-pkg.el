;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20261103.1933"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "9cc150dfbab0665e047ad0476c9e8f33ddaa1f10"
  :revdesc "9cc150dfbab0"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
