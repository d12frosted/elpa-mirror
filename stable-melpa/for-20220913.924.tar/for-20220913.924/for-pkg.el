(define-package "for" "20220913.924" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "89e3eac132dc8f5d2ae7616ec7cccf2e78fd4134" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
