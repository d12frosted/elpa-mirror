;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250923.2232"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "4e7850c48c08405c8fb8a4132fe7e52e49692c6e"
  :revdesc "4e7850c48c08"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
