;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20260507.1213"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "da08ad0847b044cf23f3e83fbe417b58d6ea7767"
  :revdesc "da08ad0847b0"
  :keywords '("docs" "startdict" "sdcv"))
