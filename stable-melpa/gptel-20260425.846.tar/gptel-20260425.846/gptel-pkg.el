;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260425.846"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "101904a1a8568fe42df49f0f1acd4ddab39ae1f8"
  :revdesc "101904a1a856"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
