(define-package "test-cockpit" "20231024.1724" "A command center to run tests of a software project"
  '((emacs "28.1")
    (projectile "2.7")
    (toml "20230411.1449"))
  :commit "5bb054649369b04b7c8f2c97d110133ce991f00f" :authors
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainer
  '("Johannes Mueller" . "github@johannes-mueller.org")
  :url "https://github.com/johannes-mueller/test-cockpit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
