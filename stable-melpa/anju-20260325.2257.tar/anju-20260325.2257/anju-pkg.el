;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260325.2257"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (magit         "4.4.0")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "ff3beabb0c8ff8950e8515042931687ddbf994ea"
  :revdesc "ff3beabb0c8f"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
