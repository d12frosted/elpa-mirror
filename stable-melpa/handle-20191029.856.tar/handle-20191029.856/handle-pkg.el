;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "handle" "20191029.856"
  "A handle for major-mode generic functions."
  '((emacs       "25.1")
    (parent-mode "2.3"))
  :url "https://gitlab.com/jjzmajic/handle"
  :commit "e27b2d0b229923f81a2c8afa3e9c65ae9e84a0da"
  :revdesc "e27b2d0b2299"
  :keywords '("convenience"))
