;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260320.726"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "09fbd4bf0254b1f1f8d6fe7021d1d41293862d7a"
  :revdesc "09fbd4bf0254"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
