;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "20260729.409"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "29faab8fb32ca34ac21e736bb60b7267dc424209"
  :revdesc "29faab8fb32c"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
