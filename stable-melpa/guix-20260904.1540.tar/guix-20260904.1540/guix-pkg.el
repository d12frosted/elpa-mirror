;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guix" "20260904.1540"
  "Interface for GNU Guix."
  '((emacs         "24.3")
    (dash          "2.11.0")
    (geiser        "0.8")
    (bui           "1.2.0")
    (transient     "0.3.0")
    (edit-indirect "0.1.4")
    (magit-popup   "2.13.3"))
  :url "https://codeberg.org/guix/emacs-guix"
  :commit "c70d2fd14e1d88df937affb7cc0972df5b4e7d3d"
  :revdesc "c70d2fd14e1d"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
