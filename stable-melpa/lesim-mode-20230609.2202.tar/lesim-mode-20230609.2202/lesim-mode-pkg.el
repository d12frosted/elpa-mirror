(define-package "lesim-mode" "20230609.2202" "Major mode for Learning Simulator scripts"
  '((emacs "28.1"))
  :commit "2e3be0e7b00996ac52e9f3b4b5b08f319b3ef6dd" :authors
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainer
  '("Stefano Ghirlanda" . "drghirlanda@gmail.com")
  :keywords
  '("languages" "faces")
  :url "https://github.com/drghirlanda/lesim-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
