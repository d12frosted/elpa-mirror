;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260314.139"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "cfc2f2fec915737e7abf904896d50c62dd283b60"
  :revdesc "cfc2f2fec915"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
