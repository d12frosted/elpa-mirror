(define-package "modus-themes" "20221001.752" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "ad5cb41daf57456dc28d54b07f9a1dcb2c55cbd4" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
