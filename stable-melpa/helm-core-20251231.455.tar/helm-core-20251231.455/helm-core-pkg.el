;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251231.455"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "5f8ba191b01c3a113acfe5df003fdd3152f1770f"
  :revdesc "5f8ba191b01c"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
