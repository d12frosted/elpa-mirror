(define-package "consult" "20210108.1439" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "0e91d8d0a217c507a50e4c47e2b862229ee9f7e2" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
