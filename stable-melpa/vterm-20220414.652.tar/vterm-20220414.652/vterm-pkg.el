(define-package "vterm" "20220414.652" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "9a6dbeb383332394adfea3d76fb19ebf1e69f541" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
