;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260131.114"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "cc749d327fcb88cfffe20a7ce63977c211d4ce1e"
  :revdesc "cc749d327fcb"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
