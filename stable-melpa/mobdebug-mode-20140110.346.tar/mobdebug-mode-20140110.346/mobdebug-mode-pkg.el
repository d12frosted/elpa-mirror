;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mobdebug-mode" "20140110.346"
  "Major mode for MobDebug."
  '((lua-mode "20130419")
    (emacs    "24"))
  :url "https://github.com/deftsp/mobdebug-mode"
  :commit "e1d483bc4e341c762bc5c0a8c52306a8d01ea0da"
  :revdesc "e1d483bc4e34"
  :authors '(("Shihpin Tseng" . "deftsp@gmail.com"))
  :maintainers '(("Shihpin Tseng" . "deftsp@gmail.com")))
