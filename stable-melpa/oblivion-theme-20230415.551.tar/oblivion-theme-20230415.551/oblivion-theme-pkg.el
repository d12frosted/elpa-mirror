(define-package "oblivion-theme" "20230415.551" "A port of GEdit oblivion theme"
  '((emacs "24.1"))
  :commit "f0b180eeb5ed19bacbce9d6a39e3123f4751f54b" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-oblivion-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
