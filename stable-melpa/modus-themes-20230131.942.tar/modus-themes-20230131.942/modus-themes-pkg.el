(define-package "modus-themes" "20230131.942" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "4346ab5ed55a612df98b4eeb6e5f8bc067922b98" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
