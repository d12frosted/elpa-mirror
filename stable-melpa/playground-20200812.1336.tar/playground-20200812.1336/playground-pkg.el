;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "playground" "20200812.1336"
  "Manage sandboxes for alternative configurations."
  '((emacs "24.4"))
  :url "https://github.com/akirak/emacs-playground"
  :commit "77d2faab0bc3f6e1f2c65c66644c52167304610d"
  :revdesc "77d2faab0bc3"
  :keywords '("maint")
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
