;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260622.936"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "ec7c66604d76cad77448fe2d4b45c54d24a65c03"
  :revdesc "ec7c66604d76"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
