(define-package "hl-indent-scope" "20221213.420" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "78205e9ea48f064a81d6be6c766e8ce9e680f59a" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
