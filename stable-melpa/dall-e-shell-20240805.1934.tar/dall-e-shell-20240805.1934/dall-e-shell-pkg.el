(define-package "dall-e-shell" "20240805.1934" "Interaction mode for DALL-E"
  '((emacs "27.1")
    (shell-maker "0.49.1"))
  :commit "fe75c5d516b149c635cda97627e8f920f277d36e" :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
