(define-package "consult" "20210218.1354" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "d6a35fc958adc62eefc1421d87c02a2bf8130e33" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
