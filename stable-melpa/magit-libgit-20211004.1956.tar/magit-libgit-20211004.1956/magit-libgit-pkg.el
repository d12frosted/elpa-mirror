(define-package "magit-libgit" "20211004.1956" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "4c469037756ace8b0cc42c05da0dd1864c5bc2a4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
