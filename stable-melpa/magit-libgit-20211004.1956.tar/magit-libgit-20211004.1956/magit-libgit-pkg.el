(define-package "magit-libgit" "20211004.1956" "."
  '((emacs "25.1")
    (libgit "0")
    (magit "20211004"))
  :commit "b1ad283941ecbcf382f69e807c04f5cb872e842c" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
