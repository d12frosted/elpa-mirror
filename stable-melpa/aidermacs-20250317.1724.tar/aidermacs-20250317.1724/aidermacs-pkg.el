;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250317.1724"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "c55f325bc7bc8aba2ffb513b2548d1b90a92c94b"
  :revdesc "c55f325bc7bc"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
