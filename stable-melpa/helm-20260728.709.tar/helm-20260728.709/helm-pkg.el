;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20260728.709"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "c438a08d1bbc2286e13891e4de812ef1b5190628"
  :revdesc "c438a08d1bbc"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
