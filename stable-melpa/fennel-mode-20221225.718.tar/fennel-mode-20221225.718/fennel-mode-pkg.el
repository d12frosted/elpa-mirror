(define-package "fennel-mode" "20221225.718" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "36f27507357c74c91be9199202f279d8c791d6a8" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
