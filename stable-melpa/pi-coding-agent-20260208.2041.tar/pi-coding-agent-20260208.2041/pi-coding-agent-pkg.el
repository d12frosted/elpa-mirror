;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260208.2041"
  "Emacs frontend for pi coding agent."
  '((emacs         "28.1")
    (markdown-mode "2.6")
    (transient     "0.9.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "0cbe4849507897ebd6b5ec349da935dad81b85f1"
  :revdesc "0cbe48495078"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
