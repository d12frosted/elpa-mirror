(define-package "wildcharm-theme" "20230817.804" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "cc3904efb525415c70fdf68b5138b719fd452c2c" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
