(define-package "pet" "20240707.2202" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0")
    (map "3.3.1")
    (seq "2.24"))
  :commit "b1b925d135608b1a2ddc60b977df43a8b4e3e030" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
