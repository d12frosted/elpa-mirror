;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260502.951"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "ee590b2278f26ac6cbbb80ab687628a704ddd2b2"
  :revdesc "ee590b2278f2"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
