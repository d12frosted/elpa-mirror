(define-package "timonier" "20160928.1122" "Timonier, Manage Kubernetes Applications from Emacs"
  '((s "1.11.0")
    (dash "2.12.0")
    (pkg-info "0.5.0")
    (hydra "0.13.6")
    (request "0.2.0")
    (all-the-icons "2.0.0"))
  :commit "33ca5887a1d1b63349177237e9edfb73546511a5" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("kubernetes" "docker")
  :url "https://github.com/nlamirault/timonier")
;; Local Variables:
;; no-byte-compile: t
;; End:
