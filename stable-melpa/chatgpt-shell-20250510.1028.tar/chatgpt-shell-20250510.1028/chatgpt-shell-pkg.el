;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250510.1028"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.76.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "efed530f1cfc9eec878331abc9284b7893dce008"
  :revdesc "efed530f1cfc")
