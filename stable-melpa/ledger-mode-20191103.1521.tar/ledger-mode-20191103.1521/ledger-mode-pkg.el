(define-package "ledger-mode" "20191103.1521" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "24.3"))
  :commit "964630f80e0e80dad83134a3660f56948390173a")
;; Local Variables:
;; no-byte-compile: t
;; End:
