;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibslurp" "20151202.2346"
  "Retrieve BibTeX entries from NASA ADS."
  '((s    "1.6.0")
    (dash "1.5.0"))
  :url "https://github.com/mkmcc/bibslurp"
  :commit "aeba96368f2a06959e4fe945375ce2a54d34b189"
  :revdesc "aeba96368f2a"
  :keywords '("bibliography" "nasa ads")
  :authors '(("Mike McCourt" . "mkmcc@astro.berkeley.edu"))
  :maintainers '(("Mike McCourt" . "mkmcc@astro.berkeley.edu")))
