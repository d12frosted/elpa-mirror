;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20251110.2005"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "a9583228771df8ab16058c00a978b823e8a08adf"
  :revdesc "a9583228771d")
