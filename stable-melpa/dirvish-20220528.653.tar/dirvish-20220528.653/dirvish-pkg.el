(define-package "dirvish" "20220528.653" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "753f033801a06f090e56b18fd0da3c949cd6bc98" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
