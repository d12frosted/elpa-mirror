(define-package "typst-mode" "20230819.928" "A major mode for working with Typst typesetting system"
  '((polymode "0.2.2")
    (emacs "24.3"))
  :commit "bbc08e88b5454849debb1c4022af56ff3a7f916e" :authors
  '(("Ziqi Yang"))
  :maintainers
  '(("Ziqi Yang"))
  :maintainer
  '("Ziqi Yang")
  :keywords
  '("outlines")
  :url "https://github.com/Ziqi-Yang/typst-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
