;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shift-number" "20250218.1129"
  "Increase/decrease the number at point."
  '((emacs "24.1"))
  :url "https://github.com/alezost/shift-number.el"
  :commit "3143a0ec886f68d3cc112528d63eb4ae83a4b073"
  :revdesc "3143a0ec886f"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
