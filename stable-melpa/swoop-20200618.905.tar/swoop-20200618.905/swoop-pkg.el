(define-package "swoop" "20200618.905" "Peculiar buffer navigation"
  '((emacs "24.3")
    (ht "2.0")
    (pcre2el "1.5")
    (async "1.1"))
  :commit "828ae0f17f3beaea50ee66d06c500f4847ccc7dd" :authors
  '(("Shingo Fukuyama - http://fukuyama.co"))
  :maintainer
  '("Shingo Fukuyama - http://fukuyama.co")
  :keywords
  '("tools" "swoop" "inner" "buffer" "search" "navigation")
  :url "https://github.com/ShingoFukuyama/emacs-swoop")
;; Local Variables:
;; no-byte-compile: t
;; End:
