;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-latex-subfigure" "20200326.919"
  "Subfigure for latex export."
  '((emacs "24.4")
    (org   "9.0"))
  :url "https://github.com/linktohack/ox-latex-subfigure"
  :commit "be0a0dde62fde8cdf8d72b6968344906aa8c6f54"
  :revdesc "be0a0dde62fd"
  :keywords '("convenience" "ox" "latex" "subfigure" "org" "org-mode")
  :authors '(("Quang Linh LE" . "linktohack@gmail.com"))
  :maintainers '(("Quang Linh LE" . "linktohack@gmail.com")))
