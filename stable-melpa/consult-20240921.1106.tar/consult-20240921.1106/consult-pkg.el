(define-package "consult" "20240921.1106" "Consulting completing-read"
  '((emacs "28.1")
    (compat "30"))
  :commit "0557ff36c0e868c92ebac078e7c3ef3bad61f055" :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
