;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-latte" "20260125.540"
  "Auto-highlight unlinked Org-roam references."
  '((emacs    "27.1")
    (org-roam "2.0"))
  :url "https://github.com/yad-tahir/org-roam-latte"
  :commit "fbcdad953e1b84441fcc9c7e33f809c648de5ae2"
  :revdesc "fbcdad953e1b"
  :keywords '("hypermedia" "outlines" "org-roam" "convenience")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
