;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-spotify" "20160905.2147"
  "Control Spotify with Helm."
  '((helm  "0.0.0")
    (multi "2.0.0"))
  :url "https://github.com/krisajenkins/helm-spotify"
  :commit "f7a62d1ff88e3127de9be7cd3e818b0a92268ab3"
  :revdesc "f7a62d1ff88e"
  :keywords '("helm" "spotify")
  :authors '(("Kris Jenkins" . "krisajenkins@gmail.com"))
  :maintainers '(("Kris Jenkins" . "krisajenkins@gmail.com")))
