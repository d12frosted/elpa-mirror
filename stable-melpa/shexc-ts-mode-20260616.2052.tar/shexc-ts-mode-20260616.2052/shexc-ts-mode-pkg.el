;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "20260616.2052"
  "Tree-sitter major mode for ShExC."
  '((emacs "29.1"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "1a47df99d07526bdd91ceb08e3ff6c9b56ff825a"
  :revdesc "1a47df99d075"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
