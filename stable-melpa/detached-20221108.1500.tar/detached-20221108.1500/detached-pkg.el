(define-package "detached" "20221108.1500" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "beaa9e1258e659adec65fd168897a0a829e63962" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
