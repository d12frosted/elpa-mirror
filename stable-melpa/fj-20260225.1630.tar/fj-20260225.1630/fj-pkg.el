;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20260225.1630"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (fedi      "0.2")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "e6615985e2968825a06069aad00733a2399336da"
  :revdesc "e6615985e296"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
