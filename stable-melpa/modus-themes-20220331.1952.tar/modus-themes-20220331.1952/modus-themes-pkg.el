(define-package "modus-themes" "20220331.1952" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "7aec1013f43de28e7ad82d45c1611dca666765a1" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
