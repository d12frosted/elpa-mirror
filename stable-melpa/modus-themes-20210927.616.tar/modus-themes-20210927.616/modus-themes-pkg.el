(define-package "modus-themes" "20210927.616" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "21dafbebaf6cd4b0d9e20d82670bd936f9dd6f8b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
