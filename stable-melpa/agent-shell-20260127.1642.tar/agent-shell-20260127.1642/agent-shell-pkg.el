;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260127.1642"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8952d260ae3733e2f0e23b0678042ea22e728134"
  :revdesc "8952d260ae37")
