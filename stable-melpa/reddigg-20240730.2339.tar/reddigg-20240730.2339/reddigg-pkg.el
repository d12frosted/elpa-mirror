;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "20240730.2339"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "4d22e06a6e2523fe6d83c0280847d3bde19fabb5"
  :revdesc "4d22e06a6e25"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
