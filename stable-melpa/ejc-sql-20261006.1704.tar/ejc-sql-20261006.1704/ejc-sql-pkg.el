;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20261006.1704"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "26.3")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "db21d60790e67f4bc41582d15188bc72b41ed048"
  :revdesc "db21d60790e6"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
