(define-package "gruvbox-theme" "20220819.754" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "ea49242ac449d1263c274cd85f356148b5aca1cf" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
