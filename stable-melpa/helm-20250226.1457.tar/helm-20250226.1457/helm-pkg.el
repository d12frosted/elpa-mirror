;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250226.1457"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.2")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "818802ab06f5ac47d774af7c52d17a2677dfa806"
  :revdesc "818802ab06f5"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
