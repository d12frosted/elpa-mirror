(define-package "binky" "20231204.846" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "d692f3a3551ae412b0b3fc71d14b7d3991255084" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
