(define-package "webdriver" "20231004.1311" "WebDriver local end implementation"
  '((emacs "27.1"))
  :commit "48e238fdde3eb5fcfcddab78cabecd48b6b51388" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/mauroaranda/emacs-webdriver")
;; Local Variables:
;; no-byte-compile: t
;; End:
