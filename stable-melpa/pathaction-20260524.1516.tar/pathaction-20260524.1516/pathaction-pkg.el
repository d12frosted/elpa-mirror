;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260524.1516"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "40cea28725ec025f9f4e5e277a6312f8916508b9"
  :revdesc "40cea28725ec"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
