;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250424.1707"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "82cf1aef02237d34b72b3616e7aaa0f919c810bd"
  :revdesc "82cf1aef0223"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
