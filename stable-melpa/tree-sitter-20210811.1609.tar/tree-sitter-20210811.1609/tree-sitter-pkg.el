(define-package "tree-sitter" "20210811.1609" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.15.1"))
  :commit "13a4fff0c017313ede1900f972f6a805243a17f7" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
