;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251011.1031"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "9759bece9d2069d4eb2f17a61ca2cb36dbf3d368"
  :revdesc "9759bece9d20"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
