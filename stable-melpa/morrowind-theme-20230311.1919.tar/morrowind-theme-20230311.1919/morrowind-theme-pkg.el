(define-package "morrowind-theme" "20230311.1919" "Theme"
  '((emacs "24.1"))
  :commit "5253d03e4aba8fe4f9d30c1483c2189616ce8990" :authors
  '(("Samuel Banya"))
  :maintainers
  '(("Samuel Banya"))
  :maintainer
  '("Samuel Banya")
  :url "https://github.com/samuelbanya/morrowind-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
