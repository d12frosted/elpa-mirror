(define-package "cnfonts" "20240430.257" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "67a3c7d799b27006827f2c976bc2b2545c6b04fa" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainers
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
