(define-package "sketch-themes" "20210826.1816" "Sketch color themes"
  '((emacs "26.1"))
  :commit "50fd9fe9caf24f42dc481560e1f41addc3a06dbb" :authors
  '(("Daw-Ran Liou" . "hi@dawranliou.com"))
  :maintainer
  '("Daw-Ran Liou" . "hi@dawranliou.com")
  :keywords
  '("faces")
  :url "https://github.com/dawranliou/sketch-themes/")
;; Local Variables:
;; no-byte-compile: t
;; End:
