;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grip-mode" "20250425.1734"
  "Instant GitHub-flavored Markdown/Org preview using grip."
  '((emacs "24.4"))
  :url "https://github.com/seagle0128/grip-mode"
  :commit "678ef46b3d2c7679383b9f3548946eff6e1466fe"
  :revdesc "678ef46b3d2c"
  :keywords '("convenience" "markdown" "preview")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
