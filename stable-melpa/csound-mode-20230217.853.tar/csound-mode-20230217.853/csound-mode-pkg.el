(define-package "csound-mode" "20230217.853" "A major mode for interacting and coding Csound"
  '((emacs "25")
    (shut-up "0.3.2")
    (multi "2.0.1")
    (dash "2.16.0")
    (highlight "0"))
  :commit "a4dceb1febd3e7587e89158caf207d5da5624f51" :authors
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainer
  '("Hlöðver Sigurðsson" . "hlolli@gmail.com")
  :url "https://github.com/hlolli/csound-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
