;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-qmd" "20260504.1718"
  "Qiita Markdown Back-End for Org Export Engine."
  '((emacs     "27.2")
    (request   "0.3.3")
    (mimetypes "1.0"))
  :url "https://github.com/0x60df/ox-qmd"
  :commit "c0025e73607fab9800ff02a28c90c6239f3bc593"
  :revdesc "c0025e73607f"
  :keywords '("wp")
  :authors '(("0x60DF" . "0x60DF@gmail.com"))
  :maintainers '(("0x60DF" . "0x60DF@gmail.com")))
