(define-package "proof-general" "20211125.1302" "PG init file for package.el and ELPA compatibility"
  '((emacs "25.1"))
  :commit "20412f10d4dbc7b276e8001e7eedaa0da73e8d2a" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
