(define-package "clojure-ts-mode" "20230906.337" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "bd61a7fb281b7b0b1d2e20d19ab5d46cbcdc6c1e" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
