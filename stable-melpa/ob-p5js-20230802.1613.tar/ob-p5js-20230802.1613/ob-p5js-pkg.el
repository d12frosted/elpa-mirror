;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-p5js" "20230802.1613"
  "Support for p5js in org-babel."
  '((emacs "25.1"))
  :url "https://github.com/alejandrogallo/p5js"
  :commit "6a1684a02f5baf6c433bfaf700b8c33b0f6ff12e"
  :revdesc "6a1684a02f5b"
  :keywords '("javascript" "graphics" "multimedia" "p5js" "processing" "org-babel")
  :authors '(("Alejandro Gallo" . "aamsgallo@gmail.com"))
  :maintainers '(("Alejandro Gallo" . "aamsgallo@gmail.com")))
