(define-package "kurecolor" "20220818.818" "color editing goodies"
  '((emacs "24.1")
    (s "1.12"))
  :commit "6abff43eab3937aca5c4516a078515be32e89339" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
