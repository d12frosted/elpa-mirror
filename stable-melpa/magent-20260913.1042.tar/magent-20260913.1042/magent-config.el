;;; magent-config.el --- Configuration for Magent  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Jamie Cui
;; SPDX-License-Identifier: GPL-3.0-or-later
;; Assisted-by: Codex:GPT-5.6, Magent:deepseek-v4-pro

;; Author: Jamie Cui <jamie.cui@outlook.com>
;; Keywords: tools, ai

;;; Commentary:

;; Configuration module for Magent using Emacs customize groups.
;; LLM provider, model, and API key settings are managed by gptel.
;; See `gptel-backend', `gptel-model', and `gptel-api-key'.

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'project)
(require 'magent-log)
(require 'magent-prompt)
(require 'subr-x)

(declare-function magent-action-builtins-register "magent-action-builtins")

(defgroup magent nil
  "Magent AI coding agent for Emacs."
  :prefix "magent-"
  :group 'tools
  :link '(url-link :tag "GitHub" "https://github.com/jamie-cui/magent"))

(defcustom magent-enable-logging t
  "Whether to write Magent diagnostics to `magent-log-buffer-name'."
  :type 'boolean
  :group 'magent)

(defcustom magent-log-level 'info
  "Minimum severity written to the Magent diagnostic log buffer."
  :type '(choice (const :tag "Debug" debug)
                 (const :tag "Info" info)
                 (const :tag "Warn" warn)
                 (const :tag "Error" error))
  :group 'magent)

(defcustom magent-log-buffer-name "*magent-log*"
  "Name of the buffer used for Magent diagnostic logging."
  :type 'string
  :group 'magent)

(defcustom magent-system-prompt
  (magent-prompt-read "system.org")
  "System prompt for the AI agent.
The default value is read from prompts/system.org in the package."
  :type 'string
  :group 'magent)

(defcustom magent-context-provider-functions nil
  "Trusted functions that contribute request-local system context.

Each function is called with three arguments: the user prompt, the current
`magent-request-context' (or nil), and the current project root (or nil).  It
must return either a non-empty string containing one self-contained context
block or nil.  Providers run as trusted local Elisp; failures and invalid
return values are logged and ignored so an optional provider cannot break the
agent turn.  Context blocks are inserted in list order before active skills
and the final runtime trust policy."
  :type '(repeat function)
  :group 'magent)

(defcustom magent-skill-search-endpoint "https://skills.sh/api/search"
  "HTTP endpoint used by `magent-find-skill'."
  :type 'string
  :group 'magent)

(defcustom magent-web-search-provider 'bing
  "Search source used by `web_search', independently of the gptel model.
The default `bing' uses public RSS and needs no API key.  `duckduckgo'
uses HTML search, while `tavily' uses its official API with a key.
Additional sources can use `magent-web-register-search-provider'.
Errors never cause an implicit switch to another provider."
  :type 'symbol
  :group 'magent)

(defcustom magent-web-tavily-api-key nil
  "Tavily API key or zero-argument function returning one.
When nil, use TAVILY_API_KEY from the Emacs environment, then auth-source
with host api.tavily.com and user apikey.  Never send a key in chat."
  :type '(choice (const :tag "Environment or auth-source" nil)
                 (function :tag "Key function") (string :tag "API key"))
  :group 'magent)

(defcustom magent-web-timeout 45
  "Maximum seconds for one web operation, including redirects and parsing."
  :type 'natnum
  :group 'magent)

(defcustom magent-web-max-response-bytes (* 10 1024 1024)
  "Maximum bytes downloaded or extracted by one web operation."
  :type 'natnum
  :group 'magent)

(defcustom magent-skill-search-limit 10
  "Maximum number of results displayed by `magent-find-skill'."
  :type 'natnum
  :group 'magent)

(defcustom magent-skill-search-timeout 15
  "Seconds before a pending `magent-find-skill' request is cancelled."
  :type 'natnum
  :group 'magent)

(defcustom magent-skill-install-max-files 500
  "Maximum number of files accepted in one installed skill."
  :type 'natnum
  :group 'magent)

(defcustom magent-skill-install-max-bytes (* 10 1024 1024)
  "Maximum total byte size accepted in one installed skill."
  :type 'natnum
  :group 'magent)

(defcustom magent-enable-tools
  '(read write edit grep glob bash emacs_eval emacs_eval_live agent plan web_search)
  "List of enabled tools.
Available tools: read, write, edit, grep, glob, bash, emacs_eval,
emacs_eval_live, agent, plan, web_search."
  :type '(set (const :tag "Read files" read)
              (const :tag "Write files" write)
              (const :tag "Edit files" edit)
              (const :tag "Search content (grep)" grep)
              (const :tag "Find files (glob)" glob)
              (const :tag "Run shell commands" bash)
              (const :tag "Evaluate Elisp in a child Emacs" emacs_eval)
              (const :tag "Evaluate Elisp in the live Emacs" emacs_eval_live)
              (const :tag "Coordinate child agents" agent)
              (const :tag "Update the task plan" plan)
              (const :tag "Search the web" web_search))
  :group 'magent)

(defcustom magent-project-root-function nil
  "Function to find project root directory.
The function should take no arguments and return the project root
path as a string.  If nil, try `projectile-project-root', then
`project-current' from project.el, and finally fall back to
`default-directory'."
  :type '(choice (function :tag "Custom function")
                 (const :tag "Default" nil))
  :group 'magent)

(defcustom magent-max-history 100
  "Target maximum number of messages to keep in session history.
Keep whole turns, including their goals and tools.  The newest turn is always
retained, even when it alone exceeds this target."
  :type 'integer
  :group 'magent)

(defcustom magent-request-timeout 120
  "Timeout in seconds for LLM requests.
If no callback activity occurs within this period, the request
transitions to an error state.  Set to 0 to disable."
  :type 'integer
  :group 'magent)

(defcustom magent-stream-retry-limit 2
  "Maximum retries for a truncated stream before assistant text is emitted.
Retries preserve the same provider input and completed tool results.  They
are announced in the conversation and count toward the sampling limit.
Set to zero to disable retries.  Only incomplete Chat Completions streams
without a finish reason are eligible, including curl partial-transfer
errors (exit 18).  Explicit provider errors and token limits are not retried."
  :type 'natnum
  :group 'magent)

(defcustom magent-max-sampling-requests 0
  "Safety guard for model sampling requests in one turn.
Magent normally follows Codex-style turn continuation and does not impose a
per-turn sampling limit.  When this value is positive, the initial request
counts as one and tool-output continuations count as additional requests; the
turn fails directly when the next continuation would exceed the limit.  No
extra provider request is made.  Set to 0 to disable."
  :type 'integer
  :group 'magent)

(defconst magent-effort-values '(minimal low medium high xhigh)
  "Canonical Magent reasoning effort values sent to providers.")

(defconst magent-effort-option-values
  (cons 'auto magent-effort-values)
  "Reasoning effort values exposed to user-facing selectors.
`auto' means provider or model default and is not sent as a request
parameter.")

(defcustom magent-default-effort nil
  "Default reasoning effort for Magent requests.
Nil means provider or model default.  Per-session agent-shell settings,
request context, and agent definitions can override this value."
  :type '(choice (const :tag "Provider default" nil)
                 (const :tag "Minimal" minimal)
                 (const :tag "Low" low)
                 (const :tag "Medium" medium)
                 (const :tag "High" high)
                 (const :tag "Extra high" xhigh))
  :group 'magent)

(defcustom magent-effort-unsupported-policy 'warn-and-downgrade
  "How Magent handles an effort level unsupported by a provider adapter.
`warn-and-downgrade' downgrades `xhigh' to `high' when a known request
shape supports effort but not `xhigh', and otherwise logs and ignores
unsupported effort settings.  `ignore' silently omits unsupported effort
parameters.  `error' signals an error before sending the request."
  :type '(choice (const :tag "Warn and downgrade when possible" warn-and-downgrade)
                 (const :tag "Ignore" ignore)
                 (const :tag "Error" error))
  :group 'magent)

(defun magent-effort-normalize-option (effort)
  "Return EFFORT as a canonical option symbol, or nil when absent.
Recognized option symbols are `auto', `minimal', `low', `medium',
`high', and `xhigh'.  String values are accepted for file-backed and
wire-protocol configuration."
  (let* ((raw (cond
               ((null effort) nil)
               ((symbolp effort) (symbol-name effort))
               ((stringp effort) effort)
               (t (format "%s" effort))))
         (key (and raw
                   (downcase
                    (replace-regexp-in-string
                     "[_[:space:]]+" "-"
                     (string-trim raw))))))
    (pcase key
      ((or 'nil "") nil)
      ((or "auto" "default" "provider-default") 'auto)
      ("minimal" 'minimal)
      ("low" 'low)
      ("medium" 'medium)
      ("high" 'high)
      ((or "xhigh" "x-high" "extra-high" "extra-highest") 'xhigh)
      (_ (error "Invalid Magent effort value: %S" effort)))))

(defun magent-effort-option-or-auto (effort)
  "Return normalized EFFORT option, defaulting nil to `auto'."
  (or (magent-effort-normalize-option effort) 'auto))

(defun magent-effort-effective (effort)
  "Return provider-facing EFFORT symbol, or nil for `auto'/absent."
  (let ((option (magent-effort-normalize-option effort)))
    (unless (eq option 'auto)
      option)))

(defun magent-effort-option-string (effort)
  "Return EFFORT option as an ACP/frontmatter string."
  (symbol-name (magent-effort-option-or-auto effort)))

(defconst magent-thinking-values '(enabled disabled)
  "Canonical explicit Magent thinking modes sent to providers.")

(defconst magent-thinking-option-values
  (cons 'auto magent-thinking-values)
  "Thinking modes exposed to user-facing selectors.
`auto' means provider or model default and is not sent as a request
parameter.")

(defcustom magent-default-thinking nil
  "Default thinking mode for Magent requests.
Nil means provider or model default.  Per-session settings, request context,
Action Steps, and agent definitions can override this value.  Explicit
`disabled' suppresses any configured reasoning effort for that request."
  :type '(choice (const :tag "Provider default" nil)
                 (const :tag "Enabled" enabled)
                 (const :tag "Disabled" disabled))
  :group 'magent)

(defun magent-thinking-normalize-option (thinking)
  "Return THINKING as a canonical option symbol, or nil when absent.
Recognized option symbols are `auto', `enabled', and `disabled'.  String
values are accepted for file-backed and wire-protocol configuration."
  (let* ((raw (cond
               ((null thinking) nil)
               ((symbolp thinking) (symbol-name thinking))
               ((stringp thinking) thinking)
               (t (format "%s" thinking))))
         (key (and raw
                   (downcase
                    (replace-regexp-in-string
                     "[_[:space:]]+" "-"
                     (string-trim raw))))))
    (pcase key
      ((or 'nil "") nil)
      ((or "auto" "default" "provider-default") 'auto)
      ((or "enabled" "enable" "on") 'enabled)
      ((or "disabled" "disable" "off") 'disabled)
      (_ (error "Invalid Magent thinking mode: %S" thinking)))))

(defun magent-thinking-option-or-auto (thinking)
  "Return normalized THINKING option, defaulting nil to `auto'."
  (or (magent-thinking-normalize-option thinking) 'auto))

(defun magent-thinking-effective (thinking)
  "Return provider-facing THINKING symbol, or nil for `auto'/absent."
  (let ((option (magent-thinking-normalize-option thinking)))
    (unless (eq option 'auto)
      option)))

(defun magent-thinking-option-string (thinking)
  "Return THINKING option as an ACP/frontmatter string."
  (symbol-name (magent-thinking-option-or-auto thinking)))

(defcustom magent-bypass-permission nil
  "DANGEROUS: Bypass ordinary Magent tool permission checks.
When non-nil, exposed tools ignore agent permission rules and user-defined
overrides.  Tools with a once-only approval policy, including `emacs_eval'
and `emacs_eval_live', still require a fresh confirmation.  This flag does
not expose globally disabled tools or tools omitted from an Action's exact
allowlist.  Enable it only in trusted environments for debugging or
automation.

This variable is the canonical permission bypass flag used by
`magent-toggle-bypass-permission' and permission checks."
  :type 'boolean
  :group 'magent
  :risky t)

(defcustom magent-audit 'buffer
  "Destination for permission and sensitive-action audit records.
Set this to `buffer' to retain records only in the live audit buffer, which is
the default.  Set it to a string naming a file to append compact JSONL records
to that file.  Relative file names are resolved against
`user-emacs-directory'.  Set it to nil to disable audit recording."
  :type '(choice (const :tag "Disable audit recording" nil)
                 (const :tag "Live audit buffer only" buffer)
                 (file :tag "Append JSONL records to file"))
  :group 'magent)

(defcustom magent-default-agent "build"
  "The default agent to use for new sessions.
Should match one of the registered agent names."
  :type 'string
  :group 'magent)

(defcustom magent-agent-shell-session-strategy 'prompt
  "Agent Shell session strategy used by Magent buffers.
The setting applies both to Magent entry commands and to Magent selected from
the generic agent-shell picker.  By default, agent-shell prompts to start a new
session or load a saved session from the current scope.  Set this to `new' to
start immediately or `latest' to load the most recent session automatically."
  :type '(choice (const :tag "Always start new session" new)
                 (const :tag "Load latest session" latest)
                 (const :tag "Prompt for session" prompt))
  :group 'magent)

(defcustom magent-load-custom-agents t
  "Whether to load custom agents from .magent/agent/*.md files."
  :type 'boolean
  :group 'magent)

(defcustom magent-agent-directory ".magent/agent"
  "Relative path (from project root) to the custom agent directory."
  :type 'string
  :group 'magent)

(defcustom magent-session-directory
  (expand-file-name "magent/sessions" user-emacs-directory)
  "Directory where session files are stored."
  :type 'directory
  :group 'magent)

(defun magent-action--set-enabled-builtins (symbol value)
  "Set SYMBOL to VALUE and refresh initialized built-in Actions."
  (set-default symbol value)
  (when (and (bound-and-true-p magent--initialized)
             (fboundp 'magent-action-builtins-register))
    (magent-action-builtins-register value)))

(defcustom magent-action-enabled-builtins '(doctor)
  "Optional built-in Action groups registered by Magent.

The `doctor' entry controls the Doctor Action.  Other bundled prompt and
session-control Actions are always registered.

Changes made through Customize or `setopt' take effect immediately for future
Action discovery and invocation.  An Action already in progress is allowed to
finish."
  :type '(set (const :tag "Doctor diagnostics" doctor))
  :set #'magent-action--set-enabled-builtins
  :group 'magent)

(defcustom magent-action-session-directory nil
  "Directory where isolated Magent Action session files are stored.
When nil, Action sessions are stored under
`magent-session-directory'/actions."
  :type '(choice (const :tag "Use magent-session-directory/actions" nil)
                 directory)
  :group 'magent)

(defcustom magent-audit-buffer-name "*magent-audit*"
  "Name of the buffer used for the Magent audit browser."
  :type 'string
  :group 'magent)

(defcustom magent-audit-preview-length 120
  "Maximum display width for normalized audit previews."
  :type 'integer
  :group 'magent)

(defcustom magent-audit-flush-delay 0.25
  "Idle delay before queued file audit records are flushed to disk.
File writes are batched and deferred so permission and tool event handlers do
not block the main Emacs thread on every record.  This setting has no effect
when `magent-audit' is `buffer' or nil."
  :type 'number
  :group 'magent)

(defcustom magent-audit-default-days 1
  "Number of recent days loaded by default in the audit browser.
When nil or non-positive, show all available audit records."
  :type '(choice (const :tag "All available audit records" nil)
                 integer)
  :group 'magent)

(defcustom magent-audit-max-records 200
  "Maximum number of audit records rendered in the audit browser.
Older matching records remain in the configured audit destination and can be
reached by widening the time window or lowering filters in future UI
extensions."
  :type 'integer
  :group 'magent)

(defcustom magent-grep-program "rg"
  "Preferred ripgrep executable used by the grep tool on the project host.
The name is resolved independently on local and TRAMP project hosts.  An
explicit path therefore names a path on whichever host owns the project.
If it cannot be resolved there, Magent falls back to `git grep --no-index'
on the same host.  It never falls back to a process on another host."
  :type 'string
  :group 'magent)

(defcustom magent-grep-max-matches 100
  "Maximum number of matches to return from grep searches."
  :type 'integer
  :group 'magent)

(defcustom magent-glob-max-results 500
  "Maximum number of matching paths returned by one glob call."
  :type 'integer
  :group 'magent)

(defcustom magent-glob-max-files-scanned 50000
  "Maximum number of filesystem entries inspected by one glob call."
  :type 'integer
  :group 'magent)

(defcustom magent-glob-batch-size 500
  "Maximum filesystem entries processed per glob event-loop slice."
  :type 'integer
  :group 'magent)

(defcustom magent-bash-program "bash"
  "Bash-compatible executable used by the bash tool.
Commands run with pipefail enabled and errexit disabled.  If this executable
cannot be resolved, bash tool calls fail without affecting other Magent tools."
  :type 'string
  :group 'magent)

(defcustom magent-bash-timeout 300
  "Positive host-controlled timeout in seconds for Bash commands."
  :type 'integer
  :group 'magent)

(defcustom magent-emacs-eval-timeout 10
  "Default timeout in seconds for emacs_eval operations."
  :type 'integer
  :group 'magent)

(defcustom magent-emacs-read-max-characters 12000
  "Maximum characters returned by one structured emacs_read call."
  :type 'natnum
  :group 'magent)

(defcustom magent-tool-output-spill-session-max-bytes (* 64 1024 1024)
  "Maximum bytes retained for spilled tool results in one session."
  :type 'natnum
  :group 'magent)

(defcustom magent-tool-output-spill-ttl (* 24 60 60)
  "Seconds spilled tool results remain available after their last write."
  :type 'natnum
  :group 'magent)

(defcustom magent-tool-output-spill-page-characters 8000
  "Maximum body characters returned by one read_tool_output page."
  :type 'natnum
  :group 'magent)

(defcustom magent-tool-result-model-max-length 12000
  "Maximum tool output body characters kept in model-visible history.
Longer bodies are truncated before they are recorded in the session ledger,
transcript and provider projections, and subsequent gptel prompts.  Structured
failure status headers are always retained outside this limit."
  :type '(choice (const :tag "Do not truncate tool results" nil)
                 integer)
  :group 'magent)

(defcustom magent-tool-result-model-preview-length 10000
  "Body characters retained when a tool result is truncated.
Successful results keep a prefix.  Failed results keep a short prefix and a
longer diagnostic suffix.  The final record also includes a compact truncation
notice; structured failure status headers are not part of this budget."
  :type 'integer
  :group 'magent)

(defcustom magent-action-buffer-context-max-chars 24000
  "Maximum total buffer-content characters attached by one Action turn.
The budget is shared by the buffers matched by a standard Action turn in
declaration and `buffer-list' order.  Longer content is retained around each
buffer's point and receives a model-visible truncation notice.  Nil disables
Magent-owned truncation for Action buffer context."
  :type '(choice (const :tag "Do not truncate Action buffer context" nil)
                 natnum)
  :group 'magent)

(defcustom magent-action-process-timeout 300
  "Default timeout in seconds for Action Workflow process Steps.
Nil disables the default timeout.  Individual Steps may override this value."
  :type '(choice (const :tag "No timeout" nil)
                 number)
  :group 'magent)

(defcustom magent-action-step-output-max-chars 24000
  "Maximum process output characters persisted for one Workflow Step.
The Workflow receives the complete process result.  Only the durable activity
copy is bounded, retaining the tail with a truncation marker.  Nil disables
this persistence limit."
  :type '(choice (const :tag "Do not truncate Step output" nil)
                 natnum)
  :group 'magent)

(defcustom magent-session-save-idle-delay 0.25
  "Idle delay in seconds before UI-triggered session saves run.
Explicit calls to `magent-session-save-for-session' remain synchronous."
  :type 'number
  :group 'magent)

(defcustom magent-session-journal-max-events 2000
  "Maximum recent ledger events persisted beside a session snapshot.
The in-memory journal remains append-only.  Saved session files retain a
bounded replay/audit tail because the materialized snapshot already contains
all state through its `last-event-seq'.  Nil keeps the full journal."
  :type '(choice (const :tag "Keep the full journal" nil)
                 (natnum :tag "Recent events"))
  :group 'magent)

(defcustom magent-child-agent-max-depth 1
  "Maximum depth for recursive child-agent spawning.
A value of 1 allows the visible root agent to spawn direct child agents,
but prevents those children from spawning their own children.  Set to nil
to disable the depth guard."
  :type '(choice (const :tag "No child-agent depth limit" nil)
                 (natnum :tag "Maximum child-agent depth"))
  :group 'magent)

(defcustom magent-include-reasoning t
  "How to handle LLM reasoning/thinking blocks.
If t, display reasoning blocks in the Magent UI and retain them.
If `ignore', hide reasoning from the Magent UI but still retain the
received reasoning text internally.
If nil, omit displayable reasoning items from the UI and transcript.
Provider-native continuation items are separate protocol data and remain
available for correct continuation and same-route replay, including encrypted
reasoning and any provider-supplied summaries."
  :type '(choice (const :tag "Display reasoning and keep it" t)
                 (const :tag "Hide reasoning but keep it internally" ignore)
                 (const :tag "Omit displayable reasoning items" nil))
  :group 'magent)

(defcustom magent-enable-capabilities t
  "Whether to resolve context-aware capabilities for each request.
When non-nil, Magent selects a small set of active capabilities
and injects the instruction skills linked to them."
  :type 'boolean
  :group 'magent)

(defcustom magent-capability-max-active 3
  "Maximum number of capabilities to auto-activate per request."
  :type 'integer
  :group 'magent)

(defcustom magent-project-instruction-file-names '("AGENTS.md")
  "Project instruction file names discovered for each request.
Files are loaded from the project root toward request-local resource paths.
Deeper files are appended later so their narrower scope is explicit."
  :type '(repeat string)
  :group 'magent)

(defcustom magent-project-instructions-max-bytes 65536
  "Maximum total bytes loaded from project instruction files per request.
Set to nil to disable project instruction discovery."
  :type '(choice (const :tag "Disabled" nil)
                 (natnum :tag "Maximum bytes"))
  :group 'magent)

(defcustom magent-disabled-capabilities nil
  "List of capability names that should never auto-activate.
These names are checked by the capability resolver before any
automatic activation happens."
  :type '(repeat string)
  :group 'magent)

(defcustom magent-disabled-capability-families nil
  "List of capability family names that should never auto-activate.
Families are maintainer-defined strings carried by capability
metadata, for example a package workflow family or a debugging
family.  A locally enabled capability can still override this for
that one capability."
  :type '(repeat string)
  :group 'magent)

(defcustom magent-doctor-probe-timeout 2
  "Default timeout in seconds for one Magent doctor probe.
Set to 0 to disable this per-probe limit."
  :type 'number
  :group 'magent)

(defcustom magent-doctor-process-timeout 10
  "Default timeout in seconds for a doctor probe subprocess.
Set to 0 to disable this subprocess limit."
  :type 'number
  :group 'magent)

(defcustom magent-doctor-total-timeout 30
  "Maximum seconds spent collecting local Magent doctor diagnostics.
Set to 0 to disable the total collection limit."
  :type 'number
  :group 'magent)

(defcustom magent-doctor-max-diagnostic-chars 24000
  "Maximum characters sent in one Magent doctor diagnostic bundle."
  :type 'integer
  :group 'magent)

(defcustom magent-doctor-max-probe-chars 8000
  "Maximum encoded characters retained from one Magent doctor probe."
  :type 'integer
  :group 'magent)

(defcustom magent-doctor-source-context-max-chars 6000
  "Maximum source characters included by the manual doctor source probe."
  :type 'integer
  :group 'magent)

(defcustom magent-doctor-log-max-lines 100
  "Maximum recent lines read from one allowlisted doctor log buffer."
  :type 'integer
  :group 'magent)

;;; Shared utilities

(defmacro magent--with-display-buffer (name &rest body)
  "Populate buffer NAME with BODY and display it in `special-mode'.
The buffer is created if needed.  The mode is set before content
insertion so that `kill-all-local-variables' does not wipe locals
set by BODY.  BODY runs with `inhibit-read-only' bound to t."
  (declare (indent 1))
  `(let ((buf (get-buffer-create ,name)))
     (with-current-buffer buf
       (unless (derived-mode-p 'special-mode)
         (special-mode))
       (let ((inhibit-read-only t))
         (erase-buffer)
         ,@body))
     (display-buffer buf)))

(defun magent-project-root (&optional directory no-fallback)
  "Return the project root for DIRECTORY.
Uses `magent-project-root-function' if set, then tries projectile
and project.el.  Unless NO-FALLBACK is non-nil, return DIRECTORY
\=(or `default-directory') if no project root can be determined."
  (let ((default-directory (or directory default-directory)))
    (or (when (bound-and-true-p magent-project-root-function)
          (funcall magent-project-root-function))
        (when (fboundp 'projectile-project-root)
          (projectile-project-root))
        (when (fboundp 'project-current)
          (when-let* ((proj (project-current nil)))
            (project-root proj)))
        (unless no-fallback
          default-directory))))

(provide 'magent-config)
;;; magent-config.el ends here
