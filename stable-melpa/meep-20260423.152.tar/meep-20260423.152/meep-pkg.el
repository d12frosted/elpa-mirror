;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260423.152"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "98a8b2bd6384237005e258a647f3d16a90bc0b97"
  :revdesc "98a8b2bd6384"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
