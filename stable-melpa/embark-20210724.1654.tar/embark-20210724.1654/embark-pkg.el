(define-package "embark" "20210724.1654" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "bf985564318bdc16d51754f1a9475dca4e239e7b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
