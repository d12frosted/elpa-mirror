;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20251119.2148"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "a7b59bc681e027bf99d1e3cd9475f53ea90b9b11"
  :revdesc "a7b59bc681e0"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
