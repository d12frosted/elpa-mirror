(define-package "cnfonts" "20211029.2242" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "2e8d64efb2c148a771636e957bef813b13d7aec8" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
