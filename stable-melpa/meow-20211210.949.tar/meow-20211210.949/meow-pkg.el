(define-package "meow" "20211210.949" "Yet Another modal editing"
  '((emacs "27.1")
    (dash "2.12.0")
    (s "1.12.0"))
  :commit "195c652ed92c99095e794c721803db6967e3fd2b" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
