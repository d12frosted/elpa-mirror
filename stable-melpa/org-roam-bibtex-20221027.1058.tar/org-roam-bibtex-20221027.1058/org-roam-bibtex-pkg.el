(define-package "org-roam-bibtex" "20221027.1058" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "2.2.0")
    (bibtex-completion "2.0.0"))
  :commit "1273b74b13f260bca441081b3a7ab1fd79706925" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
