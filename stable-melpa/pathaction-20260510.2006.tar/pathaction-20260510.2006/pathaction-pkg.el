;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260510.2006"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "b815e4866c41e1285c0a0b188b932a9822302966"
  :revdesc "b815e4866c41"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
