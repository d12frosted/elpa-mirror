(define-package "elm-mode" "20210221.2234" "Major mode for Elm"
  '((f "0.17")
    (s "1.7.0")
    (emacs "25.1")
    (dash "2.13.0")
    (reformatter "0.3"))
  :commit "8ae90ba7180f5e44f52ee82acf926407c90c7a40" :authors
  '(("Joseph Collard"))
  :maintainer
  '("Joseph Collard")
  :url "https://github.com/jcollard/elm-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
