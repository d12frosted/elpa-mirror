(define-package "worf" "20210826.1000" "A warrior does not press so many keys! (in org-mode)"
  '((swiper "0.11.0")
    (ace-link "0.1.0")
    (hydra "0.13.0")
    (zoutline "0.1.0"))
  :commit "aab516cd0cae65796cce89b29691e95d18bec3ef" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/abo-abo/worf")
;; Local Variables:
;; no-byte-compile: t
;; End:
