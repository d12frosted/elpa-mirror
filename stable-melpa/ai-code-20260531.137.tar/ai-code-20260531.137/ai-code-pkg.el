;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260531.137"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "7ec30aaa8c48c35d3bb562b92597716b6923ad05"
  :revdesc "7ec30aaa8c48"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
