(define-package "mastodon" "20220912.2042" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0"))
  :commit "cf504419334bf964e5211ab238783efb15325648" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
