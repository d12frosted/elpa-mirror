(define-package "koopa-mode" "20230904.1029" "A major mode for Microsoft PowerShell"
  '((company "0.9.13")
    (emacs "27.1"))
  :commit "a650f343ba5f30401b73e93deece97cbd5b15908" :authors
  '(("Tyler Hooks"))
  :maintainers
  '(("Tyler Hooks"))
  :maintainer
  '("Tyler Hooks")
  :keywords
  '("powershell" "convenience")
  :url "https://github.com/sch0lars/koopa-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
