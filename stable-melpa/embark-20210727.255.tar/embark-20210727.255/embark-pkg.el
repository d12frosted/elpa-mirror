(define-package "embark" "20210727.255" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "bd37cd1d8892a1699922102413a193972d7a43f8" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
