;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260131.2334"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "0aaac2270f4d85a585061d54bc3a065173bd2514"
  :revdesc "0aaac2270f4d"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
