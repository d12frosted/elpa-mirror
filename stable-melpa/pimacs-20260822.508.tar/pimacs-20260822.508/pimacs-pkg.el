;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260822.508"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "1aa6180ddf7dcb2f5deb971a8f3cea50730e813e"
  :revdesc "1aa6180ddf7d"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
