(define-package "consult" "20230914.1545" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "4b8f8a55e875f705925b954822127bfbc7045c82" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
