;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-browse-commit" "20260412.1414"
  "Browse pull/merge requests from magit-blame."
  '((emacs "25.1")
    (magit "3.0.0"))
  :url "https://github.com/bbw9n/magit-browse-commit"
  :commit "d7b73e3819cf4c6a178aa54f2331d22f41f010df"
  :revdesc "d7b73e3819cf"
  :keywords '("vc" "tools" "git")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
