(define-package "evil" "20220806.1425" "Extensible Vi layer for Emacs."
  '((emacs "24.1")
    (goto-chg "1.6")
    (cl-lib "0.5"))
  :commit "3045e425e9209808788c1a7b7e00e0814ec6c81b" :maintainer
  '("Tom Dalziel" . "tom.dalziel@gmail.com")
  :keywords
  '("emulation" "vim")
  :url "https://github.com/emacs-evil/evil")
;; Local Variables:
;; no-byte-compile: t
;; End:
