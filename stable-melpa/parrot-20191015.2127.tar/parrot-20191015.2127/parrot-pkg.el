(define-package "parrot" "20191015.2127" "Party Parrot rotates gracefully in mode-line."
  '((emacs "24.1"))
  :commit "13757524f1c708b866f4aaab5a9fb3599a1c4f56" :authors
  '(("Daniel Ting" . "deep.paren.12@gmail.com"))
  :maintainer
  '("Daniel Ting" . "deep.paren.12@gmail.com")
  :keywords
  '("party" "parrot" "rotate" "sirocco" "kakapo" "games")
  :url "https://github.com/dp12/parrot.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
