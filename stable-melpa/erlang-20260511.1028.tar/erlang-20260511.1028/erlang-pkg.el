;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20260511.1028"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "550d7b7898706c7822362c42e7b93120c1d1f29a"
  :revdesc "550d7b789870"
  :keywords '("erlang" "languages" "processes"))
