(define-package "whois" "20231106.1901" "Syntax highlighted domain name queries using system whois"
  '((emacs "24"))
  :commit "93413908ec7d39a70700b4b97d3185b06ae69204" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("network" "comm")
  :url "https://github.com/lassik/emacs-whois")
;; Local Variables:
;; no-byte-compile: t
;; End:
