;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260427.2205"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ea594fceee193d7618db26af5f741ddb26034612"
  :revdesc "ea594fceee19"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
