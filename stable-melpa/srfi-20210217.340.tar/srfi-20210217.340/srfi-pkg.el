(define-package "srfi" "20210217.340" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "8842e8e0cb78984ac5a7520278c33cca0ab0af90" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
