(define-package "oer-reveal" "20231122.820" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.22.0"))
  :commit "8585201444b3c7bfdea38b61a133ee4940162ec6" :authors
  '(("Jens Lechtenbörger"))
  :maintainers
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
