(define-package "binky" "20230905.346" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "cf08e27e31ad4488bc6e78fa5b7ea2a46898d7c6" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
