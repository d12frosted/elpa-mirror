;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261128.1122"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "49b8f4b65f1ba50a553ddaa3b1c228c9b6aaf952"
  :revdesc "49b8f4b65f1b"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
