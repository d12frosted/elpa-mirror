(define-package "consult" "20210806.214" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "9ea0de71da00430c3c6144919efd32fdfbd21cd7" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
