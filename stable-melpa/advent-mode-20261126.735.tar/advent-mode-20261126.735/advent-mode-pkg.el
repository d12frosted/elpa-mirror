;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20261126.735"
  "Advent of Code mode."
  '((emacs "30.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "c1d2ba783271b434629f4aa4ed75c2f6e3efa672"
  :revdesc "c1d2ba783271"
  :keywords '("tools")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
