;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20261003.1228"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "33a42ab44c509ee15c723f186781559b51319dca"
  :revdesc "33a42ab44c50"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
