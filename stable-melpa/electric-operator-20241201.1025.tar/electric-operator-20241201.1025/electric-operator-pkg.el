;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-operator" "20241201.1025"
  "Automatically add spaces around operators."
  '((dash  "2.10.0")
    (emacs "24.4"))
  :url "https://github.com/davidshepherd7/electric-operator"
  :commit "0a5edc6dca10511217ee3058ae1c29b0e2230cc1"
  :revdesc "0a5edc6dca10"
  :keywords '("electric")
  :authors '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainers '(("David Shepherd" . "davidshepherd7@gmail.com")))
