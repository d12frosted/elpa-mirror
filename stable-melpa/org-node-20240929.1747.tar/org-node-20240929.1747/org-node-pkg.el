;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20240929.1747"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f128fe29a77dc0c35cf707327b578e16cec6fd7a"
  :revdesc "f128fe29a77d"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
