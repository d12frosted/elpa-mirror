;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rails-i18n" "20220126.1643"
  "Seach and insert i18n on ruby code."
  '((emacs "27.2")
    (yaml  "0.1.0")
    (dash  "2.19.1"))
  :url "https://github.com/otavioschwanck/rails-i18n.el"
  :commit "8e87e4e48e31902b8259ded28a208c2e7efea6e9"
  :revdesc "8e87e4e48e31"
  :keywords '("tools" "languages")
  :authors '(("Otávio Schwanck dos Santos" . "otavioschwanck@gmail.com"))
  :maintainers '(("Otávio Schwanck dos Santos" . "otavioschwanck@gmail.com")))
