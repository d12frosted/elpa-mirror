;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sixcolors-theme" "20260922.1452"
  "Just another theme."
  '((emacs "27.1"))
  :url "https://github.com/mastro35/sixcolors-theme"
  :commit "f0208f375ca4167097a6204010e55189396c3aac"
  :revdesc "f0208f375ca4"
  :keywords '("faces" "colors" "apple" "sixcolors" "vintage" "dark")
  :authors '(("Davide Mastromatteo" . "mastro35@gmail.com"))
  :maintainers '(("Davide Mastromatteo" . "mastro35@gmail.com")))
