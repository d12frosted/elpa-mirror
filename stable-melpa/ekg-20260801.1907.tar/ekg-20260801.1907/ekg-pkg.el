;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260801.1907"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "a36218cf6e645d9ef451cb3935efeb507005f019"
  :revdesc "a36218cf6e64"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
