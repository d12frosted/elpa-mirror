(define-package "mpvi" "20230605.333" "Integrated video tool based on EMMS and MPV"
  '((emacs "28.1")
    (emms "11"))
  :commit "6c4a8a83f8e391a1c5f44d8dc4864aecc22d17c9" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience" "docs" "multimedia" "application")
  :url "https://github.com/lorniu/mpvi")
;; Local Variables:
;; no-byte-compile: t
;; End:
