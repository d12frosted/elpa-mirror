;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261023.718"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "c3fcfaef759eaf0ce158afa425dbbb29354702da"
  :revdesc "c3fcfaef759e"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
