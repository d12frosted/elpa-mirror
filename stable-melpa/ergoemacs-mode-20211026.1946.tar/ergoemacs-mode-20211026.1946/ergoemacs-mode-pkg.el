(define-package "ergoemacs-mode" "20211026.1946" "Emacs mode based on common modern interface and ergonomics."
  '((emacs "24.1")
    (cl-lib "0.5"))
  :commit "683020a92bbcb4a9135f277c6e90a338a49f224e" :authors
  '(("Xah Lee" . "xah@xahlee.org")
    ("David Capello" . "davidcapello@gmail.com")
    ("Matthew L. Fidler" . "matthew.fidler@gmail.com")
    ("Kim F. Storm" . "storm@cua.dk"))
  :maintainer
  '("Matthew L. Fidler" . "matthew.fidler@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ergoemacs/ergoemacs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
