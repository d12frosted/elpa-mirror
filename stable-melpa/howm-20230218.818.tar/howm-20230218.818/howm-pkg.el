(define-package "howm" "20230218.818" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "ffc1e7da1f02f750094a9f0fe8a0aa837743193b" :authors
  '(("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
