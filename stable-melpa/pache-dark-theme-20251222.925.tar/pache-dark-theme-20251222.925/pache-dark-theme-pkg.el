;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pache-dark-theme" "20251222.925"
  "High-contrast theme based on Gruvbox."
  '((emacs "24.1"))
  :url "https://github.com/0xhenrique/pache-dark-theme"
  :commit "73f2209c35f2d49fc4292564c9c4305fc16eec5b"
  :revdesc "73f2209c35f2"
  :authors '(("Henrique Marques" . "hm2030master@proton.me"))
  :maintainers '(("Henrique Marques" . "hm2030master@proton.me")))
