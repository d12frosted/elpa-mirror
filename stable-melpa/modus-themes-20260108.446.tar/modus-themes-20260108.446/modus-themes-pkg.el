;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260108.446"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "e438a2fcdce48034740e8da023205943bc156dd7"
  :revdesc "e438a2fcdce4"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
