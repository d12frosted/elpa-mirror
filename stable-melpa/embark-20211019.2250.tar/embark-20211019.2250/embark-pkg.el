(define-package "embark" "20211019.2250" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "4e91cce0b6f17ebe8b26f66dcb88664b4cd62af5" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
