(define-package "json-par" "20211106.535" "Minor mode for structural editing of JSON"
  '((emacs "24.4")
    (json-mode "1.7.0"))
  :commit "85a5288bea5c579b2bfdd7be16bdfc18a58b3a26" :authors
  '(("taku0 (http://github.com/taku0)"))
  :maintainer
  '("taku0 (http://github.com/taku0)")
  :keywords
  '("abbrev" "convenience" "files")
  :url "https://github.com/taku0/json-par")
;; Local Variables:
;; no-byte-compile: t
;; End:
