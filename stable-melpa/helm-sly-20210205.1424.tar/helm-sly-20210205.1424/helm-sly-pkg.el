;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-sly" "20210205.1424"
  "Helm sources and some utilities for SLY."
  '((emacs  "25.1")
    (helm   "3.2")
    (cl-lib "0.5")
    (sly    "0.0"))
  :url "https://github.com/emacs-helm/helm-sly"
  :commit "3691626c80620e992a338c3222283d9149f1ecb5"
  :revdesc "3691626c8062"
  :keywords '("convenience" "helm" "sly" "lisp")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
