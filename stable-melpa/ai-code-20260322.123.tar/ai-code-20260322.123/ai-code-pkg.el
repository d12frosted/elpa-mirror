;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260322.123"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5a0461aa38b1a3bdc8a6a863bd0525eed261f97d"
  :revdesc "5a0461aa38b1"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
