;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250426.435"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "93e89bdcf8b778e263d460ec98ad8a2c9b4625f7"
  :revdesc "93e89bdcf8b7"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
