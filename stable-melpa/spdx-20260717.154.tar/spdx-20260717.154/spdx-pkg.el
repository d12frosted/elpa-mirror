;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260717.154"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "e839ca0184713dd954aba57d59c618b7afdb678e"
  :revdesc "e839ca018471"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
