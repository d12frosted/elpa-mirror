(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "7bf41b6837ac2f5cef5ace80bab83b1aa5bc0274")
;; Local Variables:
;; no-byte-compile: t
;; End:
