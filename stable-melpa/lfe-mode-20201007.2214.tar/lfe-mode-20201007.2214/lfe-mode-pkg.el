(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "75a30e55501ffc70712bc8176fe47eaf9ca1dbe6")
;; Local Variables:
;; no-byte-compile: t
;; End:
