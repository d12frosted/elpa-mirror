(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "d383c04a6a67a70407d95ce87c890887e1901962")
;; Local Variables:
;; no-byte-compile: t
;; End:
