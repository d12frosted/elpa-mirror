(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "19c57030d6bf86baa598961fc4ee148eb2eef7a9")
;; Local Variables:
;; no-byte-compile: t
;; End:
