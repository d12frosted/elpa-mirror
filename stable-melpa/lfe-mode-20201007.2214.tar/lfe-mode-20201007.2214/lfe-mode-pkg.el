(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "89683794014cab79d2cb7362f901d03c6d3b8c00")
;; Local Variables:
;; no-byte-compile: t
;; End:
