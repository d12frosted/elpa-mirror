(define-package "lfe-mode" "20201007.2214" "Lisp Flavoured Erlang mode" 'nil :commit "b358979cbd863274e16a58ce444710b32f875ea9")
;; Local Variables:
;; no-byte-compile: t
;; End:
