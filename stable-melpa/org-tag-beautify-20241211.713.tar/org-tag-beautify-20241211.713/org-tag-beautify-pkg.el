;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "20241211.713"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "c3296be0c1b98972db92ca997b03a312b1c8ab90"
  :revdesc "c3296be0c1b9"
  :keywords '("hypermedia"))
