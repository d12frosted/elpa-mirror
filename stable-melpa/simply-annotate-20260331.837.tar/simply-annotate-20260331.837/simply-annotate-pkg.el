;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260331.837"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "2b8ac853ab237974bd113e1cb8c89404edf8eb1e"
  :revdesc "2b8ac853ab23"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
