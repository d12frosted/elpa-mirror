;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-accent-mode" "20260630.801"
  "Accent Selected Window."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/selected-window-accent-mode"
  :commit "57dfb3b4c65943f542eca322644cfa4d0731366c"
  :revdesc "57dfb3b4c659"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
