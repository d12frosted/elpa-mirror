;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260426.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "0cdfcd8d3962d2c4451e0fbb7a950cd4887c4adf"
  :revdesc "0cdfcd8d3962"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
