;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250322.1737"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "01f04e0437e45d0ea5c927542e42da0028e4904b"
  :revdesc "01f04e0437e4"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
