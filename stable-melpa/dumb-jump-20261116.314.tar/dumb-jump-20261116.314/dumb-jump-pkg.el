;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20261116.314"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "26.1"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "899181fedb73c08e88fc95aee8804265e714c756"
  :revdesc "899181fedb73"
  :keywords '("programming"))
