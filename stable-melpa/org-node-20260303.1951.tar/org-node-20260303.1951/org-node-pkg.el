;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260303.1951"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.32.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "a2fa007e5b5ce8844f4bd961f3e3ab617f6a1d1e"
  :revdesc "a2fa007e5b5c"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
