(define-package "verb" "20210802.2039" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "09756f7ca4869678d0492144eddb3d68065c142d" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
