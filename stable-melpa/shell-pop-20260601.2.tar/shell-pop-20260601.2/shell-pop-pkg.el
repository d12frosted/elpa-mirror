;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260601.2"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "f01ccd2c0c420637264c4391cfb2eb6697d22c91"
  :revdesc "f01ccd2c0c42"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
