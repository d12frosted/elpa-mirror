(define-package "julia-snail" "20211110.1407" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (vterm "0.0.1"))
  :commit "55458e9c8fbeebb33ffeb291d40c529f2b006c8d" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
