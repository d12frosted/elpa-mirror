;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20260701.1346"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "323eb562acf50ad117e614feadc0ee4b63eb817e"
  :revdesc "323eb562acf5"
  :keywords '("maint")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
