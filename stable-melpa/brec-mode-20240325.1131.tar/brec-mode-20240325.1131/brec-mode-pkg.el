(define-package "brec-mode" "20240325.1131" "A major mode for editing Breccian text"
  '((emacs "24.3"))
  :commit "5da576d3729ed1e570cfb74d322660e9ea039c0c" :authors
  '(("Michael Allan" . "mike@reluk.ca"))
  :maintainers
  '(("Michael Allan" . "mike@reluk.ca"))
  :maintainer
  '("Michael Allan" . "mike@reluk.ca")
  :keywords
  '("outlines" "wp")
  :url "http://reluk.ca/project/Breccia/Emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
