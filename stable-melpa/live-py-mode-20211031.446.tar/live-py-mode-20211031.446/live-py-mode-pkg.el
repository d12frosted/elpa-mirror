(define-package "live-py-mode" "20211031.446" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "067e12958c386d64f23d72bd087c06ff03e6ae2b" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
