(define-package "eldev" "20220718.1845" "Elisp development tool"
  '((emacs "24.4"))
  :commit "652d1ba86f18ab649e03905ec58603e97d72f779" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
