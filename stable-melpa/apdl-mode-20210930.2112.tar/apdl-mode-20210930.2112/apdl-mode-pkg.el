(define-package "apdl-mode" "20210930.2112" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "d2558d3d931c5e4802a584de4ada16dfd95a34f4" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
