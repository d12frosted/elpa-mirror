(define-package "geiser-guile" "20211130.205" "Guile's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.18"))
  :commit "4f47fe3321294c5e1e83634139bc73649de51224" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
