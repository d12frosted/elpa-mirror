;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codex-theme" "20240914.204"
  "Codex theme, a simple high contrast theme."
  ()
  :url "https://github.com/hsnovel/codex-theme"
  :commit "fe5ce22e801423e7a5dafb7b57674e2dffbeb86d"
  :revdesc "fe5ce22e8014"
  :authors '(("ağan Korkmaz" . "root@hsnovel.net"))
  :maintainers '(("ağan Korkmaz" . "root@hsnovel.net")))
