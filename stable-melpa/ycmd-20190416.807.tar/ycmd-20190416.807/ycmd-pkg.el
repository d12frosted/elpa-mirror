;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ycmd" "20190416.807"
  "Emacs bindings to the ycmd completion server."
  '((emacs            "24.4")
    (dash             "2.13.0")
    (s                "1.11.0")
    (deferred         "0.5.1")
    (cl-lib           "0.6.1")
    (let-alist        "1.0.5")
    (request          "0.3.0")
    (request-deferred "0.3.0")
    (pkg-info         "0.6"))
  :url "https://github.com/abingham/emacs-ycmd"
  :commit "6f4f7384b82203cccf208e3ec09252eb079439f9"
  :revdesc "6f4f7384b822"
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com")
             ("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")
                 ("Peter Vasil" . "mail@petervasil.net")))
