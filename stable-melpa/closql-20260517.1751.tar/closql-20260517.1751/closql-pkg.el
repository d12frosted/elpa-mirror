;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "closql" "20260517.1751"
  "Store EIEIO objects using EmacSQL."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "0.2")
    (emacsql  "4.3")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/closql"
  :commit "f1fff9861ea9ba344cebb1798c59cd5cc7fcef94"
  :revdesc "f1fff9861ea9"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.closql@jonas.bernoulli.dev")))
