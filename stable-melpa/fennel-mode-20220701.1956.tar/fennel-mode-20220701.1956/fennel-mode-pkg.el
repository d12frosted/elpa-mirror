(define-package "fennel-mode" "20220701.1956" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "5664357349462d0564c0bb55cb289a6722f0ecbc" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
