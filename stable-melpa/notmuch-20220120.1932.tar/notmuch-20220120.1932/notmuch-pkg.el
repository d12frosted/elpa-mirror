(define-package "notmuch" "20220120.1932" "run notmuch within emacs" 'nil :commit "cc180507b03d9826c92d48ee91dbd9bb5f15cd56" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
