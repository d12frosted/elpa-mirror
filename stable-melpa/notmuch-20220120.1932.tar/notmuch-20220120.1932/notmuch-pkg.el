(define-package "notmuch" "20220120.1932" "run notmuch within emacs" 'nil :commit "2786aa4d548d28579c761e9358d44c84dfb29068" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
