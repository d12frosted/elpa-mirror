(define-package "eldev" "20231001.1804" "Elisp development tool"
  '((emacs "24.4"))
  :commit "df2be1a28d1062414e5e8912760fbb486e5f1bae" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/emacs-eldev/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
