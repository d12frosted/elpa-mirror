;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marginalia" "20250603.1120"
  "Enrich existing commands with completion annotations."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/marginalia"
  :commit "ad490aa86d61742f558e927997b44e0650449a45"
  :revdesc "ad490aa86d61"
  :keywords '("docs" "help" "matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
