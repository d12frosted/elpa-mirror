;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260428.828"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "6bc95319a979a5e2c349c2eeb01388f53e8c6f9d"
  :revdesc "6bc95319a979"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
