(define-package "osm" "20230121.857" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.1.1"))
  :commit "f68f3060b66559996fdaa565c201a4f3c880b9d0" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
