;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260322.1756"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "f4c7a9e09ffebad3202c4080487c4f062122b46b"
  :revdesc "f4c7a9e09ffe"
  :keywords '("faces" "files" "q"))
