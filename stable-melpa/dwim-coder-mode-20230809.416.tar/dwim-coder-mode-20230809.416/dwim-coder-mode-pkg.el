(define-package "dwim-coder-mode" "20230809.416" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "ef24b18645ba506e6abe2d390db8f9bb4028f381" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
