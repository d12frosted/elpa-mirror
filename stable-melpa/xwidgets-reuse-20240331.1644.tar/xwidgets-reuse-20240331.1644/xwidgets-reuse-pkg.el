;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xwidgets-reuse" "20240331.1644"
  "Reuse xwidgets sessions to reduce resource consumption."
  '((emacs "26.1"))
  :url "https://github.com/lordpretzel/xwidgets-reuse"
  :commit "5653c8a3ac13615d171599b3ada87512bd1a6fb9"
  :revdesc "5653c8a3ac13"
  :keywords '("hypermedia")
  :authors '(("Boris Glavic" . "lordpretzel@gmail.com"))
  :maintainers '(("Boris Glavic" . "lordpretzel@gmail.com")))
