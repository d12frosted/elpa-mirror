(define-package "dired-rsync-transient" "20221214.1215" "Transient command for dired-rsync"
  '((dired-rsync "0.6")
    (transient "0.3.0")
    (emacs "24.4"))
  :commit "c0e2168b80df00116ab9071bb214cf05ed943d73" :authors
  '(("Alex Bennée" . "alex@bennee.com"))
  :maintainers
  '(("Alex Bennée" . "alex@bennee.com"))
  :maintainer
  '("Alex Bennée" . "alex@bennee.com")
  :url "https://github.com/stsquad/dired-rsync")
;; Local Variables:
;; no-byte-compile: t
;; End:
