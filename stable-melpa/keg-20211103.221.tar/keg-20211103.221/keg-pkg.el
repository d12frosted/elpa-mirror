(define-package "keg" "20211103.221" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "bd014ef4dcd799e54ed020e457c3fff9dad5eea1" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
