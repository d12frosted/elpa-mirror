(define-package "org-runbook" "20220512.144" "Org mode for runbooks" 'nil :commit "d2d97cb5badc29d9af37f24fce9d76bf9baf8af2" :authors
  '(("Tyler Dodge"))
  :maintainer
  '("Tyler Dodge")
  :keywords
  '("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
