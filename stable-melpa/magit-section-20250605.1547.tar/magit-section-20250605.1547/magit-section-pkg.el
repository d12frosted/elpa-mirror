;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "20250605.1547"
  "Sections for read-only buffers."
  '((emacs  "27.1")
    (compat "30.1")
    (llama  "0.6.3")
    (seq    "2.24"))
  :url "https://github.com/magit/magit"
  :commit "4067c7bfcb5360b1726ee1015ca077889ef96cf7"
  :revdesc "4067c7bfcb53"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
