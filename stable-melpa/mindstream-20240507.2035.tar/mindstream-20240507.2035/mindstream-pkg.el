(define-package "mindstream" "20240507.2035" "Start writing, stay focused, don't worry"
  '((emacs "25.1")
    (magit "3.3.0"))
  :commit "ac21b87c95b5e5287786e931d05f66968a34a820" :authors
  '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainers
  '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainer
  '("Siddhartha Kasivajhula" . "sid@countvajhula.com")
  :keywords
  '("convenience" "files" "languages" "outlines" "tools" "vc" "wp")
  :url "https://github.com/countvajhula/mindstream")
;; Local Variables:
;; no-byte-compile: t
;; End:
