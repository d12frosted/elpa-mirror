(define-package "x509-mode" "20220629.622" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "24.3"))
  :commit "56f041f5b0a5bb4c34dffeffc9aef5c64b2b98a8" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
