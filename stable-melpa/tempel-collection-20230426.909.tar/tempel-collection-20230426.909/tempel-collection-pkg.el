(define-package "tempel-collection" "20230426.909" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "5fa13a7aee2f8881ba0785dd755e0370727cd904" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
