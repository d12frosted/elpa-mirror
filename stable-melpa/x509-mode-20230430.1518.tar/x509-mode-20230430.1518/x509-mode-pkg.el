(define-package "x509-mode" "20230430.1518" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "3830cbfdadab4cd68e6f0b6a3a7a4931be8328ea" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
