(define-package "live-py-mode" "20221118.341" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "388cb12be5f1e225449cf34bf8c0b18b718d932c" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
