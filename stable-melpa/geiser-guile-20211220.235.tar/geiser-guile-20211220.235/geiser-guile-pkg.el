(define-package "geiser-guile" "20211220.235" "Guile's implementation of the geiser protocols"
  '((emacs "25.1")
    (geiser "0.20"))
  :commit "3d42dc2e723cd647322531a9737d8b7e5d4d16ff" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
