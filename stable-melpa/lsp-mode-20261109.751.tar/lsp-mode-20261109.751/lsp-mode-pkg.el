;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20261109.751"
  "LSP mode."
  '((emacs         "29.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "a8b0978967f1a0f96d8916282bd2351e3045cac0"
  :revdesc "a8b0978967f1"
  :keywords '("languages"))
