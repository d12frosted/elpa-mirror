(define-package "posframe" "20211109.935" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "610cc18f02698a0ced1a28b451062039f4d5d0f2" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
