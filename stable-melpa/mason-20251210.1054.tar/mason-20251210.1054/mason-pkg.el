;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20251210.1054"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/deirn/mason.el"
  :commit "50fc45c77d166d44ec283fa2d2769ea94a185996"
  :revdesc "50fc45c77d16"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
