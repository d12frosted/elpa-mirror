;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ujelly-theme" "20241111.245"
  "Ujelly theme for GNU Emacs 24 (deftheme)."
  ()
  :url "https://github.com/marktran/color-theme-ujelly"
  :commit "0a4d4ce7fd3cbd580b60bc4ce83e0db4d39f54e5"
  :revdesc "0a4d4ce7fd3c"
  :authors '(("Mark Tran" . "mark.tran@gmail.com"))
  :maintainers '(("Mark Tran" . "mark.tran@gmail.com")))
