(define-package "cape" "20230115.429" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.1.0"))
  :commit "4a24927b5f0ca74dcd50ed29b316e020ba061781" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
