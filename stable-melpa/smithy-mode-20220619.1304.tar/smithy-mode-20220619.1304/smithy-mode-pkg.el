;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smithy-mode" "20220619.1304"
  "Major mode for editing Smithy IDL files."
  '((emacs "26.1"))
  :url "https://github.com/mnemitz/smithy-mode"
  :commit "7dff0e7a497a055577226c7ae7ecdeaf7078b4c1"
  :revdesc "7dff0e7a497a"
  :keywords '("tools" "languages" "smithy" "idl" "amazon")
  :authors '(("Matt Nemitz" . "matt.nemitz@gmail.com"))
  :maintainers '(("Matt Nemitz" . "matt.nemitz@gmail.com")))
