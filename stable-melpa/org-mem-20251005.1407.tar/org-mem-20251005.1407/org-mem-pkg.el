;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20251005.1407"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.8")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "513ba2025d109362a2a203e834c922c148096942"
  :revdesc "513ba2025d10"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
