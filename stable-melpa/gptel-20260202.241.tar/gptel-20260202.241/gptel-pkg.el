;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260202.241"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "8b57c88c8ba9ed7d02cba43f570c5eb69d943369"
  :revdesc "8b57c88c8ba9"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
