;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260518.605"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "9dbbe72420bc014d8dfaea501dde5a7a18e5a9ac"
  :revdesc "9dbbe72420bc"
  :keywords '("data" "extensions"))
