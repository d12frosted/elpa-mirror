(define-package "modus-themes" "20211101.427" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "856922313b1f28cb1a9fc88fc5314ec69161b0a4" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
