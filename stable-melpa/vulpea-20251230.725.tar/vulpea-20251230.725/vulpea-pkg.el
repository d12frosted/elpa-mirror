;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20251230.725"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "38879c859272967674334c6e9208417ea66e5672"
  :revdesc "38879c859272"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
