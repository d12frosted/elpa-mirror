;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aws-snippets" "20191203.1553"
  "Yasnippets for AWS."
  '((yasnippet "0.8.0"))
  :url "https://github.com/baron42bba/aws-snippets"
  :commit "557d19a0bc486e0fddb597b2be5087769d9bd47e"
  :revdesc "557d19a0bc48"
  :keywords '("snippets"))
