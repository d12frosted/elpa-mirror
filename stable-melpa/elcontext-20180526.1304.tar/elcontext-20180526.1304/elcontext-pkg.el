(define-package "elcontext" "20180526.1304" "Create context specific actions"
  '((ht "2.3")
    (hydra "0.14.0")
    (emacs "24.3")
    (f "0.20.0")
    (osx-location "0.4")
    (uuidgen "0.3"))
  :commit "f434ffc655e6349a4dd52285ff68a9194bcfc949" :keywords
  ("calendar" "convenience")
  :authors
  (("Thomas Sojka"))
  :maintainer
  ("Thomas Sojka")
  :url "https://github.com/rollacaster/elcontext")
;; Local Variables:
;; no-byte-compile: t
;; End:
