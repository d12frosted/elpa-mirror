;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260213.1929"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "bf2a989c8d990396784ae7e2a38ef9943465a967"
  :revdesc "bf2a989c8d99"
  :keywords '("convenience"))
