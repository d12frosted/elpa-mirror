(define-package "consult" "20220110.1804" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "2d59f238bbed8e02155f095fe0555b43c14fd54f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
