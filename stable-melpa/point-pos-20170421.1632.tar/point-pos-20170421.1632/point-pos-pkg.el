;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "point-pos" "20170421.1632"
  "Save and restore point positions."
  ()
  :url "https://github.com/alezost/point-pos.el"
  :commit "4cd0f8c8d1296c5c64f708b6a5835e8520c51b68"
  :revdesc "4cd0f8c8d129"
  :keywords '("tools" "convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
