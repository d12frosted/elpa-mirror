;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dilbert" "20211118.1512"
  "View Dilbert comics."
  '((emacs  "26.1")
    (enlive "0.0.1")
    (dash   "2.19.1"))
  :url "https://github.com/DaniruKun/dilbert-el"
  :commit "d8c586f1bac58c334822b64bce671dde5e25a27f"
  :revdesc "d8c586f1bac5"
  :keywords '("multimedia" "news")
  :authors '(("Daniils Petrovs" . "thedanpetrov@gmail.com"))
  :maintainers '(("Daniils Petrovs" . "thedanpetrov@gmail.com")))
