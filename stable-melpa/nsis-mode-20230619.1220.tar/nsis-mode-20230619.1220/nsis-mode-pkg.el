;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nsis-mode" "20230619.1220"
  "NSIS-mode."
  ()
  :url "https://github.com/mlf176f2/nsis-mode"
  :commit "b5ae66dbab9b2d933a234bdcd28e017d44a1276f"
  :revdesc "b5ae66dbab9b"
  :keywords '("nsis"))
