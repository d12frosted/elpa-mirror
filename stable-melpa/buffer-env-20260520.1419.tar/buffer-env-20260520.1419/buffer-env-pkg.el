;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-env" "20260520.1419"
  "Buffer-local process environments."
  '((emacs  "27.1")
    (compat "29.1"))
  :url "https://github.com/astoff/buffer-env"
  :commit "e3ac6bd73304eb81f7b0393ef0cbc2361fc7f40b"
  :revdesc "e3ac6bd73304"
  :keywords '("processes" "tools")
  :authors '(("Augusto Stoffel" . "arstoffel@gmail.com"))
  :maintainers '(("Augusto Stoffel" . "arstoffel@gmail.com")))
