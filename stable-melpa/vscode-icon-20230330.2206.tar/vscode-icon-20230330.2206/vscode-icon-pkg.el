;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "vscode-icon" "20230330.2206"
  "Utility package to provide Vscode style icons."
  '((emacs "25.1"))
  :url "https://github.com/jojojames/vscode-icon-emacs"
  :commit "3976bc2e7e2fe0068ae59c11d226f67e0e87aaea"
  :revdesc "3976bc2e7e2f"
  :keywords '("files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
