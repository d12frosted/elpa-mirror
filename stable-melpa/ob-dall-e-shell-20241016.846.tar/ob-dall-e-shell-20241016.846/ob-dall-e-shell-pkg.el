;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-dall-e-shell" "20241016.846"
  "Org babel functions for DALL-E evaluation."
  '((emacs        "27.1")
    (dall-e-shell "0.37.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "d988b7f83942dd24a8ac0b7a8d854608acfaedfe"
  :revdesc "d988b7f83942")
