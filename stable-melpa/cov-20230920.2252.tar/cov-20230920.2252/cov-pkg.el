(define-package "cov" "20230920.2252" "Show coverage stats in the fringe."
  '((emacs "24.4")
    (f "0.18.2")
    (s "1.11.0")
    (elquery "0"))
  :commit "c094467dee9c79a75f8790e83fc7144e13b72fe7" :authors
  '(("Adam Niederer"))
  :maintainers
  '(("Adam Niederer"))
  :maintainer
  '("Adam Niederer")
  :keywords
  '("coverage" "gcov" "c" "lcov" "coveralls" "clover")
  :url "https://github.com/AdamNiederer/cov")
;; Local Variables:
;; no-byte-compile: t
;; End:
