(define-package "modus-themes" "20210930.1643" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "42cb16038cf1edea7d1076e206ee5846ff5821ef" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
