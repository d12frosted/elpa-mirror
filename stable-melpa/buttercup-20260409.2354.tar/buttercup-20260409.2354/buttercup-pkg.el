;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buttercup" "20260409.2354"
  "Behavior-Driven Emacs Lisp Testing."
  '((emacs "24.4"))
  :url "https://github.com/jorgenschaefer/emacs-buttercup"
  :commit "7baf9e5a60f201542309238d77aa6bb35bd77ec0"
  :revdesc "7baf9e5a60f2"
  :authors '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainers '(("Ola Nilsson" . "ola.nilsson@gmail.com")))
