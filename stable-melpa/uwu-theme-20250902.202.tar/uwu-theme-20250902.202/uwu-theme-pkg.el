;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uwu-theme" "20250902.202"
  "An awesome dark color scheme."
  '((emacs "24.1"))
  :url "https://github.com/kborling/uwu-theme"
  :commit "430e06214e8230357bea8252e8a56c5c1aa8f3eb"
  :revdesc "430e06214e82"
  :keywords '("custom themes" "dark" "faces"))
