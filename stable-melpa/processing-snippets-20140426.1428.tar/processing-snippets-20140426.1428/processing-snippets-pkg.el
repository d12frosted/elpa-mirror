;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "processing-snippets" "20140426.1428"
  "Snippets for processing-mode."
  '((yasnippet "0.8.0"))
  :url "https://github.com/ptrv/processing2-emacs"
  :commit "6175b8eef76369c4b1b8608b8df9a37f14b1be5c"
  :revdesc "6175b8eef763"
  :keywords '("snippets")
  :authors '(("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Peter Vasil" . "mail@petervasil.net")))
