(define-package "fedi" "20230820.1912" "Helper functions for fediverse clients"
  '((emacs "28.1"))
  :commit "0ff6bd3f57a799e2b3caadf0e0f1cf9ce3068dfb" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
