(define-package "stgit" "20231008.2236" "major mode for StGit interaction" 'nil :commit "f9b9280b570cb13696493ab4d39d64736edd2ca3" :authors
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainers
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainer
  '("David Kågedal" . "davidk@lysator.liu.se")
  :url "http://stacked-git.github.io")
;; Local Variables:
;; no-byte-compile: t
;; End:
