;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260403.521"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "48228bc4401a197a744516881b124f0930c38809"
  :revdesc "48228bc4401a"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
