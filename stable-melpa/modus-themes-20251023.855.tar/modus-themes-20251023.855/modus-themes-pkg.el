;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251023.855"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "74767ad3f8766da4fa020a8d15d648766a89e4a7"
  :revdesc "74767ad3f876"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
