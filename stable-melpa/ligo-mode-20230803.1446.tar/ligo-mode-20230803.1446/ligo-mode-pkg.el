(define-package "ligo-mode" "20230803.1446" "A major mode for editing LIGO source code"
  '((emacs "27.1"))
  :commit "bdd69fa7cd9adc8756ca9e688ede0335672e29cf" :authors
  '(("LigoLang SASU"))
  :maintainers
  '(("LigoLang SASU"))
  :maintainer
  '("LigoLang SASU")
  :keywords
  '("languages")
  :url "https://gitlab.com/ligolang/ligo/-/tree/dev/tools/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
