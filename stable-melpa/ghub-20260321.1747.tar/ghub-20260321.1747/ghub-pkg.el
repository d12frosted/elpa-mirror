;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20260321.1747"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "30.1")
    (cond-let "0.2")
    (llama    "1.0")
    (treepy   "0.1.2"))
  :url "https://github.com/magit/ghub"
  :commit "3866c821eea83060603d28528af1700ff6a9b318"
  :revdesc "3866c821eea8"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
