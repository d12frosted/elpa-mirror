;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20251020.1424"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "c9d68535d1293a215f16001305e673b127d5d38a"
  :revdesc "c9d68535d129"
  :keywords '("outlines"))
