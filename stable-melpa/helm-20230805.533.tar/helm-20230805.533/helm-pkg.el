(define-package "helm" "20230805.533" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.2")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "a3385dfa5d0e2d06bf83b12c95e0783b297f5272" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
