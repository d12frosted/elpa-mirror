(define-package "gnosis" "20240308.741" "Spaced Repetition System For Note Taking & Self Testing"
  '((emacs "29.1")
    (emacsql "20240124"))
  :commit "3b705cfb4a675e882d48fd98965ceb0803e74df9" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions")
  :url "https://thanosapollo.org/projects/gnosis")
;; Local Variables:
;; no-byte-compile: t
;; End:
