(define-package "ox-haunt" "20220615.7" "Haunt-flavored HTML backend for the Org export engine"
  '((emacs "26.1"))
  :commit "d32c4b1ab258dc34ca7e713152a274eab35d2608" :authors
  '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org"))
  :maintainers
  '(("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org"))
  :maintainer
  '("Jakob L. Kreuze" . "zerodaysfordays@sdf.lonestar.org")
  :keywords
  '("convenience" "hypermedia" "wp")
  :url "https://git.sr.ht/~jakob/ox-haunt")
;; Local Variables:
;; no-byte-compile: t
;; End:
