(define-package "asm-blox" "20220731.58" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "2dee1599bb609fb64aca75b996ae6c0204bd663f" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
