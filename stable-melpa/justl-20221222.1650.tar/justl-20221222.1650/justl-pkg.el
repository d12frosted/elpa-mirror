(define-package "justl" "20221222.1650" "Major mode for driving just files"
  '((transient "0.1.0")
    (emacs "25.3")
    (s "1.2.0")
    (f "0.20.0"))
  :commit "141daaa4b0dc07fe25423609dcd14441a9f2613e" :authors
  '(("Sibi Prabakaran"))
  :maintainers
  '(("Sibi Prabakaran"))
  :maintainer
  '("Sibi Prabakaran")
  :keywords
  '("just" "justfile" "tools" "processes")
  :url "https://github.com/psibi/justl.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
