;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260529.919"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "4a5e7bfda94c2d5d4b284956bd997880b18a68b8"
  :revdesc "4a5e7bfda94c"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
