(define-package "eglot-java" "20231224.1943" "Java extension for the eglot LSP client"
  '((emacs "26.1")
    (eglot "1.0")
    (jsonrpc "1.0.0"))
  :commit "e551c2e56d898dab3154cffa262c5fda528cfc87" :authors
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainers
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainer
  '("Yves Zoundi" . "yves_zoundi@hotmail.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/yveszoundi/eglot-java")
;; Local Variables:
;; no-byte-compile: t
;; End:
