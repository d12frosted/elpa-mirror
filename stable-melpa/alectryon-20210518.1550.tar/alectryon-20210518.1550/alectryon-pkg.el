(define-package "alectryon" "20210518.1550" "Toggle between Coq and reStructuredText"
  '((flycheck "31")
    (emacs "25.1"))
  :commit "d3e655afc39cf7f31f82379229bf033c82c2a0d8" :authors
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://github.com/cpitclaudel/alectryon")
;; Local Variables:
;; no-byte-compile: t
;; End:
