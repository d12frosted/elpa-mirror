;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20260722.741"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "b934b8e25c67dbc0af973de527013d243b9e047f"
  :revdesc "b934b8e25c67"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
