(define-package "helm" "20220906.1543" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.7")
    (popup "0.5.3"))
  :commit "267dec7ccf2bdd59bd3b866621653ded3253048b" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
