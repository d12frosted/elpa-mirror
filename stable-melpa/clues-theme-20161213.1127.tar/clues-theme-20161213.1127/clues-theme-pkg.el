;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clues-theme" "20161213.1127"
  "An Emacs 24 theme which may well be fully awesome..."
  '((emacs "24.0"))
  :url "https://github.com/emacsfodder/emacs-clues-theme"
  :commit "abd61f2b7f3e98de58ca26e6d1230e70c6406cc7"
  :revdesc "abd61f2b7f3e"
  :authors '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainers '(("Jason Milkins" . "jasonm23@gmail.com")))
