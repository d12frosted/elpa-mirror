(define-package "org-inline-pdf" "20230815.2356" "Inline PDF previewing for Org"
  '((emacs "25.1")
    (org "9.4"))
  :commit "3a22dca889e8fa815274adcc73bb31a31f5ed992" :authors
  '(("Shigeaki Nishina"))
  :maintainers
  '(("Shigeaki Nishina"))
  :maintainer
  '("Shigeaki Nishina")
  :keywords
  '("org" "outlines" "hypermedia")
  :url "https://github.com/shg/org-inline-pdf.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
