(define-package "dired-k" "20161116.916" "highlight dired buffer by file size, modified time, git status"
  '((emacs "24.3"))
  :commit "3f0b9315f87b0f930d51089e311d41282d5f8b15" :authors
  '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainer
  '("Syohei YOSHIDA" . "syohex@gmail.com")
  :url "https://github.com/syohex/emacs-dired-k")
;; Local Variables:
;; no-byte-compile: t
;; End:
