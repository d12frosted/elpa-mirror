(define-package "tok-theme" "20220215.1121" "My theme"
  '((emacs "24.3"))
  :commit "f78976e448853646e3b5e718783ddb8256bf341e" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
