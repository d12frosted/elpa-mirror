;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark-vc" "20250121.1558"
  "Embark actions for various version control integrations."
  '((emacs  "27.1")
    (embark "0.21.1")
    (forge  "0.3")
    (compat "29.1.3.0"))
  :url "https://github.com/elken/embark-vc"
  :commit "2bc2b3a3e610c217a61355a33b7e6c73b3b3ad44"
  :revdesc "2bc2b3a3e610"
  :keywords '("convenience" "matching" "terminals" "tools" "unix" "vc")
  :authors '(("Ellis Kenyő" . "https://github.com/elken"))
  :maintainers '(("Ellis Kenyő" . "me@elken.dev")))
