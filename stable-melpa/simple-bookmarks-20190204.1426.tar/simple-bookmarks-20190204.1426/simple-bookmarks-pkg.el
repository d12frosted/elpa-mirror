;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-bookmarks" "20190204.1426"
  "Bookmark / functioncall manager."
  '((cl-lib "0.5"))
  :url "https://github.com/jtkDvlp/simple-bookmarks"
  :commit "54e8d771bcdb0eb235b31c0aa9642171369500e5"
  :revdesc "54e8d771bcdb"
  :keywords '("bookmark" "functioncall")
  :authors '(("Julian T. Knabenschuh" . "jtkdevelopments@gmail.com"))
  :maintainers '(("Julian T. Knabenschuh" . "jtkdevelopments@gmail.com")))
