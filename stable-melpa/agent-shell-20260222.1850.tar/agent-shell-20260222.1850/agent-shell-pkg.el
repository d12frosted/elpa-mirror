;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260222.1850"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "63b9c3ff9f11c81bdc5b2d8a74318512f488b45d"
  :revdesc "63b9c3ff9f11")
