(define-package "danneskjold-theme" "20210915.929" "Beautiful high-contrast Emacs theme." 'nil :commit "748096cafb3d0ac5c1939aa220c7b23865bd881f" :authors
  '(("Dmitry Akatov" . "akatovda@yandex.com"))
  :maintainer
  '("Dmitry Akatov" . "akatovda@yandex.com")
  :url "https://github.com/rails-to-cosmos/")
;; Local Variables:
;; no-byte-compile: t
;; End:
