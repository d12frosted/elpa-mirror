;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260303.1250"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "36ed6ee7d97229c2b5344d3edc83ae003eae8117"
  :revdesc "36ed6ee7d972"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
