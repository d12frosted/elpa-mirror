(define-package "modus-themes" "20221230.1759" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "c7d03a3a3874502db78b0bdcee6852a95a7dda18" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
