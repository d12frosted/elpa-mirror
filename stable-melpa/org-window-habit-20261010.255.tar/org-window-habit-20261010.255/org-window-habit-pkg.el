;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20261010.255"
  "Time window based habits."
  '((emacs "29.1"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "6f3cb7b6fbeee67168a14e190fb403a18f100552"
  :revdesc "6f3cb7b6fbee"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
