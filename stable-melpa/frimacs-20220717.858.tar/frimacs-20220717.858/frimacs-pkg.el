(define-package "frimacs" "20220717.858" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "cfae8c8020f608a1361a4ead98dfbdaf240f4448" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
