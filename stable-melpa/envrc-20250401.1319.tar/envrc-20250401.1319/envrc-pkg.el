;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "20250401.1319"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "26.1")
    (inheritenv "0.1")
    (seq        "2.24"))
  :url "https://github.com/purcell/envrc"
  :commit "39892b2492e4fdb85466ee7ec5a7d97346d7d7c7"
  :revdesc "39892b2492e4"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
