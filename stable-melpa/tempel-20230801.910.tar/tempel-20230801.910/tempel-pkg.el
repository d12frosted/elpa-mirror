(define-package "tempel" "20230801.910" "Tempo templates/snippets with in-buffer field editing"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "eece42f153487238a6745e0ce2e57a606669bc17" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "languages" "tools" "wp")
  :url "https://github.com/minad/tempel")
;; Local Variables:
;; no-byte-compile: t
;; End:
