;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260828.1728"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "76cdef1722ba5c4943d547d6802e36c35a4979b2"
  :revdesc "76cdef1722ba"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
