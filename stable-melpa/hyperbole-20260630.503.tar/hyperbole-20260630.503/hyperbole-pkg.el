;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260630.503"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "68c9eba6123dc435dbe2c60b84b660e2e695e15c"
  :revdesc "68c9eba6123d"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
