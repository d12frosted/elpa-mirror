;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ejc-sql" "20261007.1647"
  "Emacs SQL client uses Clojure JDBC."
  '((emacs   "30.2")
    (clomacs "0.0.6")
    (dash    "2.16.0")
    (spinner "1.7.3"))
  :url "https://github.com/kostafey/ejc-sql"
  :commit "ac51ed0bd8ee9bbe0b433599ec8e5acd37e1ac67"
  :revdesc "ac51ed0bd8ee"
  :keywords '("sql" "jdbc")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
