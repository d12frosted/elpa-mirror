(define-package "circe" "20210104.1709" "Client for IRC in Emacs"
  '((cl-lib "0.5"))
  :commit "9c91a59ee7bce123181358e254232a7a92b56418" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :keywords
  '("irc" "chat")
  :url "https://github.com/jorgenschaefer/circe")
;; Local Variables:
;; no-byte-compile: t
;; End:
