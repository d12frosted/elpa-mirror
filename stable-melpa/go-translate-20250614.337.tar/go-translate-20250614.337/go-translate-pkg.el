;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250614.337"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.1"))
  :url "https://github.com/lorniu/go-translate"
  :commit "c6299872f45243a439433dcdd333854b6d1bd2b0"
  :revdesc "c6299872f452"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
