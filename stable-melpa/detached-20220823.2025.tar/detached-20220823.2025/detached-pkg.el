(define-package "detached" "20220823.2025" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "8a76055290aae3e9b555a055498e71591032e995" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
