;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250607.722"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "68cca7f73fb70f5f75da522389a8589de4e02b60"
  :revdesc "68cca7f73fb7"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
