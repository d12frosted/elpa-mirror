(define-package "geiser-guile" "20210405.1917" "Guile's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.12"))
  :commit "93ef7101fdfcc7eac6f465b4b9788c384a323c14" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
