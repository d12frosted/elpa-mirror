(define-package "slime-volleyball" "20190701.1624" "An SVG Slime Volleyball Game" 'nil :commit "f36a84f3c503c46ba0d011874d387a34b01c6bf6" :authors
  (("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
  :maintainer
  ("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")
  :keywords
  ("games"))
;; Local Variables:
;; no-byte-compile: t
;; End:
