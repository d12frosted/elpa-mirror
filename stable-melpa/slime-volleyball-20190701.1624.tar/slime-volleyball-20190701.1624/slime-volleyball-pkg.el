;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime-volleyball" "20190701.1624"
  "An SVG Slime Volleyball Game."
  ()
  :url "https://github.com/fitzsim/slime-volleyball"
  :commit "6c135ad18897c3566d4dadfe847061532600ba2e"
  :revdesc "6c135ad18897"
  :keywords '("games")
  :authors '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
  :maintainers '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")))
