(define-package "slime-volleyball" "20190701.1624" "An SVG Slime Volleyball Game" 'nil :commit "6c135ad18897c3566d4dadfe847061532600ba2e" :authors
  '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
  :maintainer
  '("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")
  :keywords
  '("games"))
;; Local Variables:
;; no-byte-compile: t
;; End:
