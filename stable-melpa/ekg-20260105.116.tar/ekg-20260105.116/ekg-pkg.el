;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260105.116"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "78e092df163c790a7d9a663cc350908d6cefaa84"
  :revdesc "78e092df163c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
