;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mason" "20251022.852"
  "Package managers for LSP, DAP, linters, and more."
  '((emacs "30.1")
    (s     "1.13.0"))
  :url "https://github.com/deirn/mason.el"
  :commit "77227959593e0cfe41a2432923f05c1c00c249de"
  :revdesc "77227959593e"
  :keywords '("tools" "lsp" "installer")
  :authors '(("Dimas Firmansyah" . "deirn@bai.lol"))
  :maintainers '(("Dimas Firmansyah" . "deirn@bai.lol")))
