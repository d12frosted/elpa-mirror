;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20251231.1606"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "ec894011a91d300b64127905fe12660c1cd3ee4a"
  :revdesc "ec894011a91d"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
