(define-package "weibo" "20111010.141" "No description available." 'nil :commit "a8af467e5660a35342029c2796de99cd551454b2")
;; Local Variables:
;; no-byte-compile: t
;; End:
