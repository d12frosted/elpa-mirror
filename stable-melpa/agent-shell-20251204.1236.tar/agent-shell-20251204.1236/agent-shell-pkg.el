;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251204.1236"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a1b94ab2f53085099871497981cecd79a3a9c3a3"
  :revdesc "a1b94ab2f530")
