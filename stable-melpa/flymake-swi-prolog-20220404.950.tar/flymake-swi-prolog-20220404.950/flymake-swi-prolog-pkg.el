;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-swi-prolog" "20220404.950"
  "A Flymake backend for SWI-Prolog."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~eshel/flymake-swi-prolog"
  :commit "ae0e4b706a40b71c007ed6cb0ec5425d49bea4c3"
  :revdesc "ae0e4b706a40"
  :keywords '("languages"))
