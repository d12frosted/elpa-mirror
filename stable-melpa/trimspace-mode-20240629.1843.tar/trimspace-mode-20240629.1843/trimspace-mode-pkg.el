;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trimspace-mode" "20240629.1843"
  "A minor mode to trim trailing whitespace and newlines."
  '((emacs "24.3"))
  :url "https://git.sr.ht/~bkhl/trimspace-mode"
  :commit "68fb627ba552644ddee0cf9048b2fefd722a59fb"
  :revdesc "68fb627ba552"
  :keywords '("files" "convenience")
  :authors '(("Björn Lindström" . "bkhl@elektrubadur.se"))
  :maintainers '(("Björn Lindström" . "bkhl@elektrubadur.se")))
