;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260522.2055"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "67fa1ebeb940c411fcc53a7dfbe33eac1ecb9cae"
  :revdesc "67fa1ebeb940"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
