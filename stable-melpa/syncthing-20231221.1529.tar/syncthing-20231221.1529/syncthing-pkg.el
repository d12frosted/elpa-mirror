(define-package "syncthing" "20231221.1529" "Client for Syncthing"
  '((emacs "27.1"))
  :commit "4050d39e769b74e09b60aeda0fbc1b7f4e5aa0a4" :authors
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainer
  '("Peter Badida" . "keyweeusr@gmail.com")
  :keywords
  '("convenience" "syncthing" "sync" "client" "view")
  :url "https://github.com/KeyWeeUsr/emacs-syncthing")
;; Local Variables:
;; no-byte-compile: t
;; End:
