;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slothbar" "20251124.353"
  "Emacs X window manager status bar."
  '((all-the-icons "5.0.0")
    (backlight     "1.4")
    (compat        "29.1")
    (dash          "2.1.0")
    (f             "0.20.0")
    (fontsloth     "0.19.1")
    (log4e         "0.3.3")
    (nerd-icons    "0.1.0")
    (s             "1.12.0")
    (volume        "1.0")
    (xelb          "0.18")
    (emacs         "28.1"))
  :url "https://codeberg.org/agnes-li/slothbar"
  :commit "52010da65a4688b2b2f16427f81dfeedf4443077"
  :revdesc "52010da65a46"
  :keywords '("frames" "hardware")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com")
             ("Agnes Li" . "agnes.li@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")
                 ("Agnes Li" . "agnes.li@mailfence.com")))
