;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260122.2139"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c60203934d577e88d03035038a1e247bb1ce0ded"
  :revdesc "c60203934d57")
