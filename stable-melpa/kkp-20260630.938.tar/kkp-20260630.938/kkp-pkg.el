;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "20260630.938"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "e239782faceea6c5aa617ca378042b428fb4eaad"
  :revdesc "e239782facee"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
