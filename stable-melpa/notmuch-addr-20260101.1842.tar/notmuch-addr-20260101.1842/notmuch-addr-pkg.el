;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-addr" "20260101.1842"
  "Improved address completion for Notmuch."
  '((emacs   "29.1")
    (compat  "30.1")
    (notmuch "0.39"))
  :url "https://github.com/tarsius/notmuch-addr"
  :commit "f4cb7f273b44faa4c0c5c85b2d740086ca709c56"
  :revdesc "f4cb7f273b44"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-addr@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-addr@jonas.bernoulli.dev")))
