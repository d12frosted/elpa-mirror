(define-package "python-mode" "20230613.1158" "Python major mode" 'nil :commit "92be5eca57c7a8a56d8a91b92908aee31ece6dd2" :authors
  '(("2015-2023 https://gitlab.com/groups/python-mode-devs")
    ("2003-2014 https://launchpad.net/python-mode")
    ("1995-2002 Barry A. Warsaw")
    ("1992-1994 Tim Peters"))
  :maintainer
  '(nil . "python-mode@python.org")
  :keywords
  '("python" "languages" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
