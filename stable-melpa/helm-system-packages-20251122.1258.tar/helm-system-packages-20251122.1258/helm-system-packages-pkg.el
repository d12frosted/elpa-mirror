;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "20251122.1258"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "50cc07fc2d99eed72ff08d5ac204b553755ba646"
  :revdesc "50cc07fc2d99"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
