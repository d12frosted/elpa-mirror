(define-package "boon" "20211217.737" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "654fb8051a5c00dd524710fbf917b00f6afc8844")
;; Local Variables:
;; no-byte-compile: t
;; End:
