(define-package "geiser-racket" "20210328.444" "Support for Racket in Geiser"
  '((emacs "26.1")
    (geiser "0.12"))
  :commit "42376b74ae0ad84d02c26560dfd9181493dcccd7" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "racket" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/racket")
;; Local Variables:
;; no-byte-compile: t
;; End:
