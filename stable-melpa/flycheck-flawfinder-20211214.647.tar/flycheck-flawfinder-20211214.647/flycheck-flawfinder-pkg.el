;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-flawfinder" "20211214.647"
  "Integrate flawfinder with flycheck."
  '((flycheck "0.24")
    (emacs    "24.4"))
  :url "https://github.com/alexmurray/flycheck-flawfinder"
  :commit "85701b849ea1ed8438ed4b7ae236e99d0f5528c7"
  :revdesc "85701b849ea1"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
