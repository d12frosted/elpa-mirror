(define-package "ue" "20210928.1227" "Minor mode for Unreal Engine projects"
  '((emacs "26.1")
    (projectile "2.5.0"))
  :commit "c34ffb97e2c082b4608d387f3e51e85a716a00dc" :authors
  '(("Oleksandr Manenko" . "seidfzehsd@use.startmail.com"))
  :maintainer
  '("Oleksandr Manenko" . "seidfzehsd@use.startmail.com")
  :keywords
  '("unreal engine" "languages" "tools")
  :url "https://gitlab.com/unrealemacs/ue.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
