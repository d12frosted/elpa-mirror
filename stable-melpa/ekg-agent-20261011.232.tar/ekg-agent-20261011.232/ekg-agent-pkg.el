;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20261011.232"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.8.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "39441026802cbf5c5ccd269b3c37cc953716e9c8"
  :revdesc "39441026802c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
