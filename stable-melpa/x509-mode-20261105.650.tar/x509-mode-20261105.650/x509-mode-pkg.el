;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261105.650"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "cbdec32d1570b64f18bcc838ba76701461819803"
  :revdesc "cbdec32d1570"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
