(define-package "epkg" "20220210.1319" "browse the Emacsmirror package database"
  '((closql "20210927")
    (emacs "25.1"))
  :commit "7f23116ba956a647b5137ebd48260934a3b7fc3b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
