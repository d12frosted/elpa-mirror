(define-package "window-purpose" "20210619.122" "Purpose-based window management for Emacs"
  '((emacs "24.4")
    (let-alist "1.0.3")
    (imenu-list "0.1"))
  :commit "e0ca3e5b462cb248a5fd9e6f2f61ee7b55d0ecab" :authors
  '(("Bar Magal"))
  :maintainer
  '("Bar Magal")
  :keywords
  '("frames")
  :url "https://github.com/bmag/emacs-purpose")
;; Local Variables:
;; no-byte-compile: t
;; End:
