;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260930.710"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "969619422b45107eddb12c6d5e951909a0330627"
  :revdesc "969619422b45")
