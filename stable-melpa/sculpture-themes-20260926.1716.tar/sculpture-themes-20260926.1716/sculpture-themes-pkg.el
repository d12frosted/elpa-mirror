;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sculpture-themes" "20260926.1716"
  "Themes with vivid colors."
  '((emacs "26.1"))
  :url "https://github.com/precompute/sculpture-theme"
  :commit "7f7fd917c21ff49477b904431e1e5a55a72283f7"
  :revdesc "7f7fd917c21f"
  :authors '(("Precompute" . "git@precompute.net"))
  :maintainers '(("Precompute" . "git@precompute.net")))
