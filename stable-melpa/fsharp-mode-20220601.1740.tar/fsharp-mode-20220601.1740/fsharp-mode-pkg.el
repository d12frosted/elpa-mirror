(define-package "fsharp-mode" "20220601.1740" "Support for the F# programming language"
  '((emacs "25"))
  :commit "4278c5fbe5aec33158ebb930bf5737b5d43fe43a" :authors
  '(("1993-1997 Xavier Leroy, Jacques Garrigue and Ian T Zimmerman")
    ("2010-2011 Laurent Le Brun" . "laurent@le-brun.eu")
    ("2012-2014 Robin Neatherway" . "robin.neatherway@gmail.com")
    ("2017-2022 Jürgen Hötzel"))
  :maintainer
  '("Jürgen Hötzel")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
