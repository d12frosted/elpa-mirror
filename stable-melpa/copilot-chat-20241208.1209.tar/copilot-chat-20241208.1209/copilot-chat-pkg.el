;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20241208.1209"
  "Copilot chat interface."
  '((request       "0.3.2")
    (markdown-mode "2.6")
    (emacs         "27.1")
    (chatgpt-shell "1.6.1")
    (magit         "4.0.0"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "48a8af88cf25361174b5785a1af064c6ec0825b3"
  :revdesc "48a8af88cf25"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
