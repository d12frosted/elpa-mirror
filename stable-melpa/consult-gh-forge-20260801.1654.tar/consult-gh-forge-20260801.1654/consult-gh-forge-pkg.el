;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-forge" "20260801.1654"
  "Magit/Forge Integration for consult-gh."
  '((emacs      "29.4")
    (consult    "2.0")
    (forge      "0.3.3")
    (consult-gh "3.1"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "c8707e86d36ea4ec38e177ca8fa0313a5374a0a9"
  :revdesc "c8707e86d36e"
  :keywords '("matching" "git" "repositories" "forges" "completion"))
