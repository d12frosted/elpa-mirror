(define-package "geiser-chez" "20221016.317" "Chez and Geiser talk to each other"
  '((emacs "26.1")
    (geiser "0.19"))
  :commit "e7b2c6635f9511c8294af862daf874bc519f56bf" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chez" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chez")
;; Local Variables:
;; no-byte-compile: t
;; End:
