;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260321.232"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "71db8b53de81790a7a8ae5c99935f087cae61f04"
  :revdesc "71db8b53de81"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
