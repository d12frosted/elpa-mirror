;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglotx" "20260930.931"
  "Native LSP multiplexer for Eglot."
  '((emacs   "29.1")
    (eglot   "1.24")
    (jsonrpc "1.0.29"))
  :url "https://github.com/cxa/eglotx"
  :commit "58033308a8c4611d9dd99cbebf8aa8d1fad40cb2"
  :revdesc "58033308a8c4"
  :keywords '("tools" "languages")
  :authors '(("CHEN Xian'an" . "xianan.chen@gmail.com"))
  :maintainers '(("CHEN Xian'an" . "xianan.chen@gmail.com")))
