;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ascii-table" "20231215.1527"
  "Interactive ASCII table."
  '((emacs "24.3"))
  :url "https://github.com/lassik/emacs-ascii-table"
  :commit "dc3c91feff6282303b66816bdcee9e031558ff77"
  :revdesc "dc3c91feff62"
  :keywords '("help" "tools")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
