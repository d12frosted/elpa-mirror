;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261009.1527"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "7dd25f3051d442a2856b98e40b07e256fd2b9f18"
  :revdesc "7dd25f3051d4"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
