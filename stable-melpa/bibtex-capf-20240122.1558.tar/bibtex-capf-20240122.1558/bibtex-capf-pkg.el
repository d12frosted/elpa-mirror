;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibtex-capf" "20240122.1558"
  "Completion at point for bibtex."
  '((emacs    "27.1")
    (parsebib "3.0")
    (org      "9.5"))
  :url "https://github.com/mclear-tools/bibtex-capf"
  :commit "31826efefcbbdebdb700a06b5070df0f06ce2291"
  :revdesc "31826efefcbb"
  :keywords '("bibtex" "convenience"))
