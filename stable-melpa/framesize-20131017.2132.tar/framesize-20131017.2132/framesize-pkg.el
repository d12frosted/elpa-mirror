;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "framesize" "20131017.2132"
  "Change the size of frames in Emacs."
  '((key-chord "0.5.20080915"))
  :url "https://github.com/nicferrier/emacs-framesize"
  :commit "f2dbf5d2513b2bc45f2085370a55c1754b6025da"
  :revdesc "f2dbf5d2513b"
  :keywords '("frames")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
