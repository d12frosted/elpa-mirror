;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260316.1602"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "5a73d24538ea6a938cb9f752e9464105d8f3f2e8"
  :revdesc "5a73d24538ea"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
