(define-package "helm" "20221020.1148" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.8.8")
    (popup "0.5.3"))
  :commit "29df83f4a2a2a08f579b964035b6ced4e21099f4" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
