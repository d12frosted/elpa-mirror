(define-package "consult" "20231006.744" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "65dcacd70523f2ae78bc70197555cce1f3b93ef0" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
