;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "20260914.2126"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "94de6816fe9f847f33e3f22ccaf52efbfb25a0b8"
  :revdesc "94de6816fe9f"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
