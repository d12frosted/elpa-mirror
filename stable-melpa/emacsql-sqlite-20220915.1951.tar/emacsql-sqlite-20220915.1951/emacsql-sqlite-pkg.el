(define-package "emacsql-sqlite" "20220915.1951" "EmacSQL back-end for SQLite"
  '((emacs "25.1")
    (emacsql "2.0.0"))
  :commit "739c24cab69c7b14eb43a0ef7f11a5111b401152" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
