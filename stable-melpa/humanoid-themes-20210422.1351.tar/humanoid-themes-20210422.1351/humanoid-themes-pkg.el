(define-package "humanoid-themes" "20210422.1351" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "1ce4f09af216f5bb643454da1a3f66beb4a26a55" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
