;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260504.1123"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "e0dfcc93e7777267ccc671f285a0225d24b348de"
  :revdesc "e0dfcc93e777"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
