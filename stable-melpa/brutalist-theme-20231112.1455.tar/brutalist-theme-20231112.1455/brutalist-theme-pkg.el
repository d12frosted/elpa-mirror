(define-package "brutalist-theme" "20231112.1455" "Brutalist theme" 'nil :commit "dbe094221fd727b8d3a4bffa84fc754df83c0450" :authors
  '(("Gergely Nagy"))
  :maintainers
  '(("Gergely Nagy"))
  :maintainer
  '("Gergely Nagy")
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
