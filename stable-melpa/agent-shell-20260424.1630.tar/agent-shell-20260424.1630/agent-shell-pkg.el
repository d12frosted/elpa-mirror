;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260424.1630"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "643aae11d7032ad5a8a5aec4232e8b80ea7f8cf6"
  :revdesc "643aae11d703")
