;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250301.1442"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "f58c8178c9af9e6be84a24be7b6af9a474922fbf"
  :revdesc "f58c8178c9af"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
