;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260502.607"
  "An Emacs Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "7fe7de7f34e6bc2b0c031bbe52dde63caf6f763d"
  :revdesc "7fe7de7f34e6"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
