(define-package "wavedrom-mode" "20230908.1615" "WaveDrom Integration"
  '((emacs "29.1"))
  :commit "203f30717a449892039c99bd29379bb5fe326e52" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("fpga" "asic" "tools")
  :url "https://github.com/gmlarumbe/wavedrom-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
