(define-package "consult" "20210809.2347" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "450d0c6592756f72c024dfd2290da65b22df4217" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
