(define-package "lacquer" "20211005.1517" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "3ef4c22982119674861ed61e3302ac3e0f05be2b" :authors
  '(("dingansich_kum0" . "zy.hua1122@outlook.com"))
  :maintainer
  '("dingansich_kum0" . "zy.hua1122@outlook.com")
  :keywords
  '("tools")
  :url "https://github.com/dingansichKum0/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
