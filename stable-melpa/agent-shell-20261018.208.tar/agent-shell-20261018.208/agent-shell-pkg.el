;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261018.208"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "3dfa9c43ca23d5cb3c1f6b385110b5fbf70549ab"
  :revdesc "3dfa9c43ca23")
