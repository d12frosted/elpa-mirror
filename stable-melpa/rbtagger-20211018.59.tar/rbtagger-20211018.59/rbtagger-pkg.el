(define-package "rbtagger" "20211018.59" "Ruby tagging tools"
  '((emacs "25.1"))
  :commit "ee1983d2579f0a82b6dcfe8cd3e2739afd78288b" :authors
  '(("Thiago Araújo" . "thiagoaraujos@gmail.com"))
  :maintainer
  '("Thiago Araújo" . "thiagoaraujos@gmail.com")
  :keywords
  '("languages" "tools")
  :url "https://www.github.com/thiagoa/rbtagger")
;; Local Variables:
;; no-byte-compile: t
;; End:
