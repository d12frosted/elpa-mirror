;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260114.1540"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "d54c72dce86dd7053a522beeb795b88951f9f18d"
  :revdesc "d54c72dce86d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
