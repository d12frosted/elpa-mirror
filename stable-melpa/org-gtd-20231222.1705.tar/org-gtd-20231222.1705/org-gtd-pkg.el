(define-package "org-gtd" "20231222.1705" "An implementation of GTD."
  '((emacs "27.2")
    (org-edna "1.1.2")
    (f "0.20.0")
    (org "9.6")
    (org-agenda-property "1.3.1")
    (transient "0.3.7"))
  :commit "87b4bf70b4e7957e4c028bf17b585e629b8b1020" :authors
  '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainer
  '("Aldric Giacomoni" . "trevoke@gmail.com")
  :url "https://github.com/Trevoke/org-gtd.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
