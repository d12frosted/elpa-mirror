;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slovak-holidays" "20211018.1754"
  "Adds a list of slovak holidays to Emacs calendar."
  ()
  :url "https://github.com/Fuco1/slovak-holidays"
  :commit "bedd26dd45ca497c0028a11e94a905560fcdb2f1"
  :revdesc "bedd26dd45ca"
  :keywords '("calendar")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
