;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaolin-themes" "20260515.2238"
  "A set of eye pleasing themes."
  '((emacs      "25.1")
    (autothemer "0.2.2")
    (cl-lib     "0.6"))
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes"
  :commit "53a6eab3f3b4ab638da0343b4845aab1074fc0e4"
  :revdesc "53a6eab3f3b4"
  :keywords '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :authors '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainers '(("Ogden Webb" . "ogdenwebb@gmail.com")))
