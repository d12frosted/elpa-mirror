(define-package "meow" "20210214.303" "Modal Editing On Wheel"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1")
    (s "1.12.0"))
  :commit "3297231711c5c04bc096855a2fcfed36fc32f820" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
