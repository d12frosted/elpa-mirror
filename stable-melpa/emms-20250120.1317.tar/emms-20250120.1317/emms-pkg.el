;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "20250120.1317"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://www.gnu.org/software/emms/"
  :commit "c0f035e98e5bb094b21816689e64185b3311001b"
  :revdesc "c0f035e98e5b"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
