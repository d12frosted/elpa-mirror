(define-package "jtags" "20160211.2029" "enhanced tags functionality for Java development" 'nil :commit "f7d29e1635ef7ee4ee2cdb8f1f6ab83e1015c84a" :authors
  '(("Alexander Baltatzis" . "alexander@baltatzis.com")
    ("Johan Dykstrom" . "jody4711-sf@yahoo.se"))
  :maintainer
  '("Johan Dykstrom" . "jody4711-sf@yahoo.se")
  :keywords
  '("languages" "tools")
  :url "http://jtags.sourceforge.net")
;; Local Variables:
;; no-byte-compile: t
;; End:
