;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20251021.1619"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "7f82d07581301f1280e10f10fa522a7e2fb61eff"
  :revdesc "7f82d0758130"
  :keywords '("data" "extensions"))
