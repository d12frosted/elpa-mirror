(define-package "chordpro-mode" "20230807.1606" "Major mode for ChordPro lead sheet file format"
  '((emacs "28.1")
    (compat "29.1.4.1"))
  :commit "2206eb246f47851a34da190169e2ce2486747c19" :authors
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainers
  '(("Howard Ding" . "hading2@gmail.com"))
  :maintainer
  '("Howard Ding" . "hading2@gmail.com")
  :keywords
  '("convenience")
  :url "https://git.sr.ht/~breatheoutbreathein/chordpro-mode.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
