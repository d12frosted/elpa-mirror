(define-package "autocrypt" "20220215.1204" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "00b87a82c4561b017052974eecd93c79b6790841" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
