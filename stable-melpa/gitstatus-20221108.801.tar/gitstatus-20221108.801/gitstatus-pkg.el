(define-package "gitstatus" "20221108.801" "Front-end for gitstatusd"
  '((emacs "25.1"))
  :commit "6c5024ad76fa9bbf2e3bea8d03e77e1767fd3aee" :authors
  '(("Igor Epstein" . "igorepst@gmail.com"))
  :maintainer
  '("Igor Epstein" . "igorepst@gmail.com")
  :keywords
  '("tools" "processes")
  :url "https://github.com/igorepst/gitstatus-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
