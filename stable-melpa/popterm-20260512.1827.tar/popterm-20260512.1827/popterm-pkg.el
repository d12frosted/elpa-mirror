;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260512.1827"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/CsBigDataHub/popterm.el"
  :commit "1fee2065d51d3b4f4ef1fa9cebd03ad0f8b1aeeb"
  :revdesc "1fee2065d51d"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
