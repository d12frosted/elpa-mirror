;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260810.1149"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "f954c2f0f347500e1b5b482d9492075447de5256"
  :revdesc "f954c2f0f347"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
