(define-package "org-node-fakeroam" "20240920.2108" "Stand-ins for org-roam-autosync-mode"
  '((emacs "28.1")
    (compat "30")
    (org-node "1.0.0")
    (org-roam "2.2.2")
    (emacsql "4.0.3")
    (persist "0.6.1"))
  :commit "2c84d6c4dc772408901d704db2b333292a597acb" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node-fakeroam")
;; Local Variables:
;; no-byte-compile: t
;; End:
