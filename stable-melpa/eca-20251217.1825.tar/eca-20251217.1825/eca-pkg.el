;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251217.1825"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "65d2d2c51ffad6930874e7e6af07b59545a6c351"
  :revdesc "65d2d2c51ffa"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
