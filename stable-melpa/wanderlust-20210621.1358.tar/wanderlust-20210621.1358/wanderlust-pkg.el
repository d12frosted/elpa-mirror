(define-package "wanderlust" "20210621.1358" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "23564584ab75ff2bf2ef60055254074b48c43868")
;; Local Variables:
;; no-byte-compile: t
;; End:
