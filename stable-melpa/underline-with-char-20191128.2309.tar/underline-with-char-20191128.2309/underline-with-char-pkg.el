;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "underline-with-char" "20191128.2309"
  "Underline with a char."
  '((emacs "24"))
  :url "https://gitlab.com/marcowahl/underline-with-char"
  :commit "36577e72aa4fbfa7f1abad01842359209f543751"
  :revdesc "36577e72aa4f"
  :keywords '("convenience")
  :maintainers '((nil . "marcowahlsoft@gmail.com")))
