;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20261014.732"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/corfu"
  :commit "92c1febc7fabacc07b6c4b5b100d9367d9c0404e"
  :revdesc "92c1febc7fab"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
