(define-package "borg" "20231122.2251" "Assimilate Emacs packages as Git submodules"
  '((emacs "27.1")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "b6507ebd915a83e34558feb917c7324a18b84ce4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
