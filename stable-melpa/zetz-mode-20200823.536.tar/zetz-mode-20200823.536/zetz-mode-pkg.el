;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zetz-mode" "20200823.536"
  "A major mode for the ZetZ programming language."
  '((emacs "25.1")
    (dash  "2.17.0")
    (hydra "0.15.0"))
  :url "https://github.com/damon-kwok/zetz-mode"
  :commit "04da33f4ffa9db5b3556f423276f4fd1db13ec67"
  :revdesc "04da33f4ffa9"
  :keywords '("languages" "programming")
  :authors '(("Damon Kwok" . "damon-kwok@outlook.com"))
  :maintainers '(("Damon Kwok" . "damon-kwok@outlook.com")))
