;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20250320.1437"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "91fac012406c31b1bd2520fdeadf14629ebc0210"
  :revdesc "91fac012406c"
  :keywords '("outlines"))
