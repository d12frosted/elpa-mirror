(define-package "sway" "20230812.1306" "Communication with the Sway window manager"
  '((emacs "27.1"))
  :commit "fc1c09fe30cf33e8755c3b6c9749783923f2cb9b" :authors
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainers
  '(("Thibault Polge" . "thibault@thb.lt"))
  :maintainer
  '("Thibault Polge" . "thibault@thb.lt")
  :keywords
  '("frames")
  :url "https://github.com/thblt/sway.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
