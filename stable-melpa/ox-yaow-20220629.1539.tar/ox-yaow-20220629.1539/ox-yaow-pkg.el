;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-yaow" "20220629.1539"
  "Generate html pages from org files."
  '((emacs "27")
    (f     "0.2.0")
    (s     "1.12.0")
    (dash  "2.17.0"))
  :url "https://github.com/LaurenceWarne/ox-yaow.el"
  :commit "71d7cee736542f6504c4733d040601d2d2086443"
  :revdesc "71d7cee73654"
  :keywords '("outlines" "hypermedia"))
