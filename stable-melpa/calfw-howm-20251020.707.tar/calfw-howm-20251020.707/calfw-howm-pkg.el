;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-howm" "20251020.707"
  "Calendar view for howm."
  '((emacs "28.1")
    (calfw "2.0")
    (howm  "1.5.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "9cce503eb0e998389485a74b956884d218a960e2"
  :revdesc "9cce503eb0e9"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
