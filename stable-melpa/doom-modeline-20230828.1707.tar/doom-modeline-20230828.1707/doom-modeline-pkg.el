(define-package "doom-modeline" "20230828.1707" "A minimal and modern mode-line"
  '((emacs "25.1")
    (compat "29.1.4.2")
    (nerd-icons "0.0.1")
    (shrink-path "0.3.1"))
  :commit "229f529134809b4dac6e4314c1762edc89a069ec" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
