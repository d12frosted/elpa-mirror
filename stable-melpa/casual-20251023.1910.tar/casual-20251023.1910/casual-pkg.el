;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20251023.1910"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/casual"
  :commit "0bd77c868bf50aff9550ef1d54d7dbcf90d9d146"
  :revdesc "0bd77c868bf5"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
