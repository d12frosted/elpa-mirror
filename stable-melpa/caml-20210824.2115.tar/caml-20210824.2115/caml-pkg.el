(define-package "caml" "20210824.2115" "Caml mode for GNU Emacs and XEmacs"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "a95aaca42e86473cc3aae9dc90f763251e38ab90" :authors
  '(("Jacques Garrigue" . "garrigue@kurims.kyoto-u.ac.jp")
    ("Ian T Zimmerman" . "itz@rahul.net")
    ("Damien Doligez" . "damien.doligez@inria.fr"))
  :maintainer
  '("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
  :keywords
  '("ocaml")
  :url "https://github.com/ocaml/caml-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
