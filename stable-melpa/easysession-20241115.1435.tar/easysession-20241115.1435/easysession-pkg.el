;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20241115.1435"
  "Easily persist and restore your editing sessions."
  '((emacs "25.1")
    (f     "0.18.2"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "57e43b914d8cdabbf6d9ab06adf0426cdde9e22f"
  :revdesc "57e43b914d8c"
  :keywords '("convenience"))
