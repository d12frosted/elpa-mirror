(define-package "merlin" "20220623.848" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "78a2ac7a37958edb005b0ddc457d65bd6387b19f" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
