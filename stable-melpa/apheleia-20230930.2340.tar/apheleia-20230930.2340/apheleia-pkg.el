(define-package "apheleia" "20230930.2340" "Reformat buffer stably"
  '((emacs "26"))
  :commit "bac7277ed0c344e3c15b2493911a31b73f99ba85" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
