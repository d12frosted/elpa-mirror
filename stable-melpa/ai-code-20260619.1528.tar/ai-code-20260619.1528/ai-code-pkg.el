;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260619.1528"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e85ac50068623229b96896f1d8c7718bf8bc90dd"
  :revdesc "e85ac5006862"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
