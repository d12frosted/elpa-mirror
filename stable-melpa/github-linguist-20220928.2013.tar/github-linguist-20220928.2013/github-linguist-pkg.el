(define-package "github-linguist" "20220928.2013" "Run GitHub Linguist on projects to collect information"
  '((emacs "27.1")
    (project "0.8")
    (async "1.9")
    (map "3"))
  :commit "73f9f52e1f626e866d8becc7a3671630449764c2" :authors
  '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers
  '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainer
  '("Akira Komamura" . "akira.komamura@gmail.com")
  :keywords
  '("processes")
  :url "https://github.com/akirak/github-linguist.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
