;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260816.1646"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b25a55e7d2a2cce8bf5c745a8f5078a08ad83020"
  :revdesc "b25a55e7d2a2"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
