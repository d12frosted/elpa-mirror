(define-package "modus-themes" "20210731.926" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "7490787c2b1639652be18a3aafd419e31df5f36b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
