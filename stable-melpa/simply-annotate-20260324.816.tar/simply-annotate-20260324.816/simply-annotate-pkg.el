;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260324.816"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "c7ddf6c73c09fc50cb6aec0b111f33e41c234f5a"
  :revdesc "c7ddf6c73c09"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
