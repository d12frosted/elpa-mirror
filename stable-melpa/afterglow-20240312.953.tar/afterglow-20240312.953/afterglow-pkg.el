;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "afterglow" "20240312.953"
  "Temporary Highlighting after Function Calls."
  '((emacs "26.1"))
  :url "https://github.com/ernstvanderlinden/emacs-afterglow"
  :commit "d90fcf4e5c8ac6f5bae2eb01dea32558b2b18fba"
  :revdesc "d90fcf4e5c8a"
  :keywords '("highlight" "line" "convenience" "evil")
  :authors '(("Ernest M. van der Linden" . "hello@ernestoz.com"))
  :maintainers '(("Ernest M. van der Linden" . "hello@ernestoz.com")))
