;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260816.420"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "2d8c28d3fbd64260cbfd5a1477aea3bff55ba54f"
  :revdesc "2d8c28d3fbd6"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
