;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260216.2011"
  "Tools for assembling a package archive."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/melpa/package-build"
  :commit "9da4218d5b260e0d5e9dad1c0b4fcea3bbb13cde"
  :revdesc "9da4218d5b26"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")))
