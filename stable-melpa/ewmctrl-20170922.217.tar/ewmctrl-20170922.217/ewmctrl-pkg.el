;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewmctrl" "20170922.217"
  "Use `wmctrl' to manage desktop windows via EWMH/NetWM."
  ()
  :url "https://github.com/flexibeast/ewmctrl"
  :commit "3d0217c4d6cdb5c308b6cb4293574f470d4faacf"
  :revdesc "3d0217c4d6cd"
  :keywords '("desktop" "windows" "ewmh" "netwm")
  :authors '(("Alexis" . "flexibeast@gmail.com")
             ("Adam Plaice" . "plaice.adam@gmail.com"))
  :maintainers '(("Alexis" . "flexibeast@gmail.com")))
