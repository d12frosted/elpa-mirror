;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260925.336"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "55d7148505da2433a30b1228092e17b0775ffa25"
  :revdesc "55d7148505da")
