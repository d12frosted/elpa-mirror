(define-package "ob-julia-vterm" "20230815.246" "Babel functions for Julia that work with julia-vterm"
  '((emacs "26.1")
    (julia-vterm "0.16")
    (queue "0.2"))
  :commit "6fe2919cd099d090a06ab3fa547f0b7371712109" :authors
  '(("Shigeaki Nishina"))
  :maintainers
  '(("Shigeaki Nishina"))
  :maintainer
  '("Shigeaki Nishina")
  :keywords
  '("julia" "org" "outlines" "literate programming" "reproducible research")
  :url "https://github.com/shg/ob-julia-vterm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
