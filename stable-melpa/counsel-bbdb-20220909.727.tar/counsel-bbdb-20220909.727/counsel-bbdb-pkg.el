;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-bbdb" "20220909.727"
  "Quick search&input email from BBDB based on Emacs API `completing-read'."
  '((emacs "24.3")
    (bbdb  "3.2.2.2"))
  :url "https://github.com/redguard/counsel-bbdb"
  :commit "ccae56b0551abb305cad087d85f1b6a97adb7c0f"
  :revdesc "ccae56b0551a"
  :keywords '("mail" "abbrev" "convenience" "matching")
  :authors '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
