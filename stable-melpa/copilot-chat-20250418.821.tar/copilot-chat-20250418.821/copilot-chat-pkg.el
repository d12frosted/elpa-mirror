;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20250418.821"
  "Copilot chat interface."
  '((emacs         "27.1")
    (aio           "1.0")
    (request       "0.3.2")
    (transient     "0.8.3")
    (polymode      "0.2.2")
    (org           "9.4.6")
    (markdown-mode "2.6")
    (shell-maker   "0.76.2"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "e5dd5a52528f11490764d74211996a04d0fe4a59"
  :revdesc "e5dd5a52528f"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
