(define-package "ghub" "20220325.1028" "Minuscule client libraries for Git forge APIs."
  '((emacs "25.1")
    (let-alist "1.0.6")
    (treepy "0.1.1"))
  :commit "fdf2e5bb9ba34216d6a76444c1889863db447b29" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
