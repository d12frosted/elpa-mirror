(define-package "super-save" "20231208.1733" "Auto-save buffers, based on your activity."
  '((emacs "25.1"))
  :commit "7f5e7f9d6e301e8f329e1ba735aef503077eeed3" :authors
  '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.com")
  :keywords
  '("convenience")
  :url "https://github.com/bbatsov/super-save")
;; Local Variables:
;; no-byte-compile: t
;; End:
