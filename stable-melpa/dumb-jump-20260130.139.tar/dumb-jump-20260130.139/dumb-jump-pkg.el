;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260130.139"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "24.4")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "8d44fa25db6849edb83379b33fd0a6298f90360e"
  :revdesc "8d44fa25db68"
  :keywords '("programming"))
