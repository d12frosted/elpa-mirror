(define-package "dashboard" "20240325.2111" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "d15bffc858085c80875843619356727302cf10af" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainers
  '(("Jesús Martínez" . "jesusmartinez93@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
