;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphviz-dot-mode" "20250628.1324"
  "Mode for the dot-language used by graphviz (att)."
  '((emacs "25.0"))
  :url "https://ppareit.github.io/graphviz-dot-mode/"
  :commit "8796abce1d3d5f94b6d31b014c6f1cd7da6d38d9"
  :revdesc "8796abce1d3d"
  :keywords '("mode" "dot" "dot-language" "dotlanguage" "graphviz" "graphs" "att")
  :maintainers '(("Pieter Pareit" . "pieter.pareit@gmail.com")))
