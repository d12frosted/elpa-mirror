;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "romkan" "20251019.1646"
  "Romaji/Kana conversion library."
  '((emacs "24.3"))
  :url "https://github.com/gicrisf/romkan.el"
  :commit "81cf9448450b866913b1f24d899f0a716fa49f0b"
  :revdesc "81cf9448450b"
  :keywords '("i18n" "languages")
  :authors '(("gicrisf" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("gicrisf" . "giovanni.crisalfi@protonmail.com")))
