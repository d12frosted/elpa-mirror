;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260313.1222"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "d284f957bc5c31a2cfb63058f29840c584c798d4"
  :revdesc "d284f957bc5c"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
