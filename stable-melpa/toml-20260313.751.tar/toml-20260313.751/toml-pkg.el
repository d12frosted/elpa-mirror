;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260313.751"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "7e29efc94468339f55152209b155e0952c823956"
  :revdesc "7e29efc94468"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
