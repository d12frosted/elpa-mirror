(define-package "helm" "20240411.932" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.7")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "8a328fb1321e2fe83c3c3e618047b6c7ca69d068" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
