(define-package "citre" "20210711.1945" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "55c043f5d439d55b8bc2acdca287ffa7e72e362d" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
