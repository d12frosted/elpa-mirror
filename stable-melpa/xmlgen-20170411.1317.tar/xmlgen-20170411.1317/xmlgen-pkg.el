;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xmlgen" "20170411.1317"
  "A DSL for generating XML."
  ()
  :url "https://github.com/philjackson/xmlgen"
  :commit "dba66681f0c5e621a9e70e8afb34903c9ffe93c4"
  :revdesc "dba66681f0c5"
  :authors '(("Philip Jackson" . "phil@shellarchive.co.uk"))
  :maintainers '(("Philip Jackson" . "phil@shellarchive.co.uk")))
