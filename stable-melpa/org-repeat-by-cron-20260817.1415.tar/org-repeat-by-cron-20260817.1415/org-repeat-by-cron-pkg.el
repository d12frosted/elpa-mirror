;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-repeat-by-cron" "20260817.1415"
  "An Org mode task repeater based on Cron expressions."
  '((emacs "24.4"))
  :url "https://github.com/TomoeMami/org-repeat-by-cron.el"
  :commit "5f4588f690c60f47f9488c4a88a2a5f49e6111c6"
  :revdesc "5f4588f690c6"
  :keywords '("calendar")
  :authors '(("TomoeMami" . "trembleafterme@outlook.com"))
  :maintainers '(("TomoeMami" . "trembleafterme@outlook.com")))
