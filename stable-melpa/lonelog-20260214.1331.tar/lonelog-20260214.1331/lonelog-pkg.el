;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lonelog" "20260214.1331"
  "Solo RPG notation support."
  '((emacs "27.1"))
  :url "https://github.com/enfors/lonelog"
  :commit "b1d63a77671149a677022910ded946a4950922b1"
  :revdesc "b1d63a776711"
  :keywords '("games" "convenience" "wp")
  :authors '(("Christer Enfors" . "christer.enfors@gmail.com"))
  :maintainers '(("Christer Enfors" . "christer.enfors@gmail.com")))
