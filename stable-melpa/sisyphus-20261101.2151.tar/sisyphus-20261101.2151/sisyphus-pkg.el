;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "20261101.2151"
  "Create releases of Emacs packages."
  '((emacs    "31.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.7"))
  :url "https://github.com/magit/sisyphus"
  :commit "b61386402fa283d2e427513958ac3b34d5a4424d"
  :revdesc "b61386402fa2"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
