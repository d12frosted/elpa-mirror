;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260616.821"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "983cb1fece13b245b99da252b396cc163f591b09"
  :revdesc "983cb1fece13"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
