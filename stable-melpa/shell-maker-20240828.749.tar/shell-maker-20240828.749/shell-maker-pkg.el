(define-package "shell-maker" "20240828.749" "Interaction mode for making comint shells"
  '((emacs "27.1"))
  :commit "54f31661df1c44e16638c8ff1e457573ea3ef7cd" :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
