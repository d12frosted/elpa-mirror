;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-typescript-preset" "20260402.158"
  "Eglot preset for TypeScript."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-typescript-preset"
  :commit "5cb96dfc2463d71ae57c5e7ecfe70c35caf4189d"
  :revdesc "5cb96dfc2463"
  :keywords '("typescript" "javascript" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
