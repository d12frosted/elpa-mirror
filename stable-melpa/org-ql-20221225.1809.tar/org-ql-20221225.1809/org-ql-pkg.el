(define-package "org-ql" "20221225.1809" "Org Query Language, search command, and agenda-like view"
  '((emacs "26.1")
    (dash "2.18.1")
    (f "0.17.2")
    (map "2.1")
    (org "9.0")
    (org-super-agenda "1.2")
    (ov "1.0.6")
    (peg "1.0.1")
    (s "1.12.0")
    (transient "0.1")
    (ts "0.2pre"))
  :commit "36ff9854ce4a8573386e7073fa2e8084dc06c0fe" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("hypermedia" "outlines" "org" "agenda")
  :url "https://github.com/alphapapa/org-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
