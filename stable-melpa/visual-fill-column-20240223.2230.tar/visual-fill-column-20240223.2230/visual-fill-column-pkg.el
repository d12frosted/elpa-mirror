(define-package "visual-fill-column" "20240223.2230" "fill-column for visual-line-mode"
  '((emacs "25.1"))
  :commit "c4f52d8435b021f0cd7aece88195a1f676e523bd" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :url "https://codeberg.org/joostkremers/visual-fill-column")
;; Local Variables:
;; no-byte-compile: t
;; End:
