;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260308.1902"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "ecb6276a94267f1373dd258ec6e9334ee40f4e75"
  :revdesc "ecb6276a9426"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
