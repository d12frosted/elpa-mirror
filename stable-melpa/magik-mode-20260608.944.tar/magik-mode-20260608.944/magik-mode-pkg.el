;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260608.944"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "4de861014274ef9c980112c204e116ee35ee224a"
  :revdesc "4de861014274"
  :keywords '("languages"))
