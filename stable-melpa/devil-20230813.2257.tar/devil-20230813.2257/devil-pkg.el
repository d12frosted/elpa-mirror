(define-package "devil" "20230813.2257" "Minor mode for translating key sequences"
  '((emacs "24.4"))
  :commit "edc71d41cb97cc8ec356a29364e14158a05ef70c" :authors
  '(("Susam Pal" . "susam@susam.net"))
  :maintainers
  '(("Susam Pal" . "susam@susam.net"))
  :maintainer
  '("Susam Pal" . "susam@susam.net")
  :keywords
  '("convenience" "abbrev")
  :url "https://github.com/susam/devil")
;; Local Variables:
;; no-byte-compile: t
;; End:
