(define-package "magit-section" "20220425.1002" "Sections for read-only buffers"
  '((emacs "25.1")
    (compat "28.1.0.4")
    (dash "20210826"))
  :commit "fa8552d1d94a24f843ae3985d04657bcef45425d" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
