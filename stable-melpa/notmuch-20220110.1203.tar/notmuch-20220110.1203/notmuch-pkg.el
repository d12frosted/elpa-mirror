(define-package "notmuch" "20220110.1203" "run notmuch within emacs" 'nil :commit "f9d8f9c6bae1a9ea60b41755008b71381464e208" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
