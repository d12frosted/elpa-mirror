(define-package "consult" "20220216.104" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "0150ab6d4eb2214b888f639f71268b8f1d421182" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
