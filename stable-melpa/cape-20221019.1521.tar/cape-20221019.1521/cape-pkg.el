(define-package "cape" "20221019.1521" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "b98c2ea11da135d9c8982ade5328900451bd24f4" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
