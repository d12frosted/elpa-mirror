;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251023.430"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "a8325500bcff6f4d96de743657f2971087e98ab0"
  :revdesc "a8325500bcff"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
