;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250623.924"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "7ba05b1442bac7df16c885dea72a34ea84fcf8aa"
  :revdesc "7ba05b1442ba"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
