;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251101.1021"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "501b6fe42c471b4b103e35c3f2d994fe6fed09b4"
  :revdesc "501b6fe42c47"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
