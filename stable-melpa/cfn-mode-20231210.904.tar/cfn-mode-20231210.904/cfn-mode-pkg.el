(define-package "cfn-mode" "20231210.904" "AWS cloudformation mode"
  '((emacs "26.0")
    (f "0.20.0")
    (s "1.12.0")
    (yaml-mode "0.0.13"))
  :commit "b166948f55eac3debe498a87918ed3dbe4868117" :authors
  '(("William Orr" . "will@worrbase.com"))
  :maintainers
  '(("William Orr" . "will@worrbase.com"))
  :maintainer
  '("William Orr" . "will@worrbase.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "https://gitlab.com/worr/cfn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
