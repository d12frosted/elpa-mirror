;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261128.757"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "cca46aec6619144538c984e6db7742f44892e2be"
  :revdesc "cca46aec6619"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
