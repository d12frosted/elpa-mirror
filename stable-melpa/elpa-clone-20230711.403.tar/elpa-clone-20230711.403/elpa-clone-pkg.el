(define-package "elpa-clone" "20230711.403" "Clone ELPA archive"
  '((emacs "24.4"))
  :commit "d1db4356191a52c524d6c44ca86091c5f4362906" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainers
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "elpa" "clone" "mirror")
  :url "https://github.com/dochang/elpa-clone")
;; Local Variables:
;; no-byte-compile: t
;; End:
