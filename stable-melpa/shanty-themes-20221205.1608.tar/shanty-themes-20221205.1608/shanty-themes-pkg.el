(define-package "shanty-themes" "20221205.1608" "The themes for digital workers"
  '((emacs "24.5.1"))
  :commit "682bb45afc47d8a4fe4a35e812da706105ffb6d2" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
