;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260406.703"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "cd4375a53525a399f64adfc99c791b35c890d152"
  :revdesc "cd4375a53525"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
