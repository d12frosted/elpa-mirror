;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20250323.2149"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "682ae483e16bb12b5451392aed367d41101b8c7f"
  :revdesc "682ae483e16b"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
