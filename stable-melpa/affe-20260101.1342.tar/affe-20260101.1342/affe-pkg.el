;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "affe" "20260101.1342"
  "Asynchronous Fuzzy Finder for Emacs."
  '((emacs   "29.1")
    (consult "2.8"))
  :url "https://github.com/minad/affe"
  :commit "683970cfd8dd7ba2ce118d2e6b7eb9dea77ba212"
  :revdesc "683970cfd8dd"
  :keywords '("matching" "files" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
