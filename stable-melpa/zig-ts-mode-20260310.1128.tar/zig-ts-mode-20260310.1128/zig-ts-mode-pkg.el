;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-ts-mode" "20260310.1128"
  "Tree Sitter support for Zig."
  '((emacs "29.1"))
  :url "https://codeberg.org/meow_king/zig-ts-mode"
  :commit "757e0350727dd4e6dbb5eb1d1d2a3cd836c1fbcb"
  :revdesc "757e0350727d"
  :keywords '("zig" "languages" "tree-sitter")
  :authors '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers '(("meowking" . "mr.meowking@tutamail.com")))
