(define-package "llama" "20230714.39" "Compact syntax for short lambda"
  '((seq "2.23"))
  :commit "5c454f1a83c698668942603e595cec36a5211768" :keywords
  '("extensions")
  :url "https://git.sr.ht/~tarsius/llama")
;; Local Variables:
;; no-byte-compile: t
;; End:
