;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260721.1440"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "2faa6509655cd3c535a6532697a0e8124c644abd"
  :revdesc "2faa6509655c"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
