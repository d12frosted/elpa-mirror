(define-package "consult" "20220419.1728" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "4223ef5edb3ed834fd9a80afb41a5fdcf561a2ab" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
