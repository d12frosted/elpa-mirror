(define-package "consult" "20210612.1836" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "62fcf8afb1a1c3115fef43c4b84683ea1a4a8a2f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
