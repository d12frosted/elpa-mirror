;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-mediawiki" "20260303.2050"
  "Mediawiki Back-End for Org Export Engine."
  '((cl-lib "0.5")
    (s      "1.9.0"))
  :url "https://github.com/tomalexander/orgmode-mediawiki"
  :commit "af145cea598105967c72b730c6eb01175c2b1fef"
  :revdesc "af145cea5981"
  :keywords '("org" "wp" "mediawiki")
  :authors '(("Tom Alexander" . "tomalexander@paphus.com"))
  :maintainers '(("Tom Alexander" . "tomalexander@paphus.com")))
