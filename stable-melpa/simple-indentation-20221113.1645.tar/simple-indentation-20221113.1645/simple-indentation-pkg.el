(define-package "simple-indentation" "20221113.1645" "Simplify writing indentation functions, alternative to SMIE"
  '((emacs "24.3")
    (dash "2.18.0")
    (s "1.12.0"))
  :commit "77685b3dd802dade7d60817fc0e24e60c101776b" :authors
  '(("Semen Khramtsov" . "hrams205@gmail.com"))
  :maintainer
  '("Semen Khramtsov" . "hrams205@gmail.com")
  :url "https://github.com/semenInRussia/simple-indentation.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
