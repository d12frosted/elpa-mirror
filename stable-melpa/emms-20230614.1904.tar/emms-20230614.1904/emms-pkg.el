(define-package "emms" "20230614.1904" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (seq "0"))
  :commit "0894fdc75d84cc0b6c1853945c53275d52e33108" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers
  '(("Yoni Rabkin" . "yrk@gnu.org"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
