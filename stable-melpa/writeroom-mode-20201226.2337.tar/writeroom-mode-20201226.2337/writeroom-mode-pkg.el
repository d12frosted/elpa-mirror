(define-package "writeroom-mode" "20201226.2337" "Minor mode for distraction-free writing"
  '((emacs "25.1")
    (visual-fill-column "2.1"))
  :commit "342d71f2ed2bb4edfe69ccf74b8d33d7fc2427a3" :authors
  (("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  ("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  ("text")
  :url "https://github.com/joostkremers/writeroom-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
