(define-package "geiser-chez" "20221023.526" "Chez and Geiser talk to each other"
  '((emacs "26.1")
    (geiser "0.19"))
  :commit "4f8b5d17ba2436ca08e6ba442ef8dd5a8fa5a714" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "chez" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chez")
;; Local Variables:
;; no-byte-compile: t
;; End:
