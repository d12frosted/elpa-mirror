;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260428.2141"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "cd385561ee1ec88e970eb4704e02391d8feba003"
  :revdesc "cd385561ee1e"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
