(define-package "async" "20210823.528" "Asynchronous processing in Emacs"
  '((emacs "24.4"))
  :commit "4061a10704d295675d5e8fffae0c8d4e612bdb56" :authors
  '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainer
  '("John Wiegley" . "jwiegley@gmail.com")
  :keywords
  '("async")
  :url "https://github.com/jwiegley/emacs-async")
;; Local Variables:
;; no-byte-compile: t
;; End:
