;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node-fakeroam" "20241005.857"
  "Stand-ins for org-roam-autosync-mode."
  '((emacs    "28.1")
    (compat   "30")
    (org-node "1.5.0")
    (org-roam "2.2.2")
    (emacsql  "4.0.3"))
  :url "https://github.com/meedstrom/org-node-fakeroam"
  :commit "5d28b3d06428ead6c8650f36ac237b36c137cc39"
  :revdesc "5d28b3d06428"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
