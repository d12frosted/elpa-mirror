(define-package "evil-textobj-tree-sitter" "20240821.1356" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1"))
  :commit "6e5722cf6a42fa7dd7af80e6820205e4a5598999" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
