;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "r-ts-mode" "20260913.1314"
  "R treesitter mode."
  '((emacs "30.1"))
  :url "https://codeberg.org/R-for-emacs/r-ts-mode"
  :commit "50ceffa2b79fa316752ae0f49408cac2080ceada"
  :revdesc "50ceffa2b79f"
  :authors '(("Manuel Teodoro" . "ttm@teoten.me"))
  :maintainers '(("Manuel Teodoro" . "ttm@teoten.me")))
