(define-package "yaml-pro" "20220722.334" "Parser-aided YAML editing features"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "4f2b032a75871b1ece2c465ca41fd54e615e4d25" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("tools")
  :url "https://github.com/zkry/yaml-pro")
;; Local Variables:
;; no-byte-compile: t
;; End:
