(define-package "consult" "20210215.1016" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "4b7830f620e93f74608abb537229f2034d95a40a" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
