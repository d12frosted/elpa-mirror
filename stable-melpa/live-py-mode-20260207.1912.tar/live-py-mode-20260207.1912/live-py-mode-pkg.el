;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-py-mode" "20260207.1912"
  "Live Coding in Python."
  '((emacs "24.3"))
  :url "http://donkirkby.github.io/live-py-plugin/"
  :commit "5b4211272730897e42b850e8fdf78c49a3bd12b3"
  :revdesc "5b4211272730"
  :keywords '("live" "coding"))
