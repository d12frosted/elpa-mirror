(define-package "cask" "20211103.1654" "Cask: Project management for package development"
  '((emacs "24.5")
    (s "1.8.0")
    (f "0.16.0")
    (epl "0.5")
    (shut-up "0.1.0")
    (cl-lib "0.3")
    (package-build "0")
    (ansi "0.4.1"))
  :commit "b6e3ba0802b5c4e336eeec5d60e3722c4ca0172d" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("speed" "convenience")
  :url "http://github.com/cask/cask")
;; Local Variables:
;; no-byte-compile: t
;; End:
