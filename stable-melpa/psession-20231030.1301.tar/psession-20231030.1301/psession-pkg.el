(define-package "psession" "20231030.1301" "Persistent save of elisp objects."
  '((emacs "24")
    (cl-lib "0.5")
    (async "1.9.3"))
  :commit "e1698e84e2e80ff48ebf7d27b6a17ed92514d8de" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://github.com/thierryvolpiatto/psession")
;; Local Variables:
;; no-byte-compile: t
;; End:
