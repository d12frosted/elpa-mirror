;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20250329.12"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "1b098201545a473d3f3e6eaab18a56556706a0d5"
  :revdesc "1b098201545a"
  :keywords '("languages" "lisp" "slime"))
