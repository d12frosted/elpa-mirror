;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-tasks" "20241026.420"
  "Efficient task management for your project."
  '((emacs   "26.1")
    (project "0.6.0"))
  :url "https://github.com/TxGVNN/project-tasks"
  :commit "ff1b159faae5e4f4756e5fc5f01b4a2a304ded13"
  :revdesc "ff1b159faae5"
  :keywords '("project" "workflow" "tools")
  :authors '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainers '(("Giap Tran" . "txgvnn@gmail.com")))
