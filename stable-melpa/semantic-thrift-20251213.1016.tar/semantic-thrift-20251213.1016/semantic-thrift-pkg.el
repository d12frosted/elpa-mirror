;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "semantic-thrift" "20251213.1016"
  "Thrift LALR parser."
  '((thrift "0.0.1")
    (emacs  "25.1"))
  :url "https://github.com/jerryxgh/semantic-thrift"
  :commit "94986339fd5ab0bfa23ab45befe7e88282dce8d3"
  :revdesc "94986339fd5a"
  :keywords '("extensions" "thrift" "semantic")
  :authors '((nil . "GuanghuiXugh_xu@qq.com"))
  :maintainers '((nil . "GuanghuiXugh_xu@qq.com")))
