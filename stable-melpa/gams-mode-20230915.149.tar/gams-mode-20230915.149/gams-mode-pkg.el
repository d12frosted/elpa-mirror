(define-package "gams-mode" "20230915.149" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "555611e3b86bf7d4d25e68a9a116717a5609b7ec" :authors
  '(("Shiro Takeda"))
  :maintainers
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
