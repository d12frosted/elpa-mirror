;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260228.16"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "45812e35e55e89f23678900afb603f4e67f86fa5"
  :revdesc "45812e35e55e"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
