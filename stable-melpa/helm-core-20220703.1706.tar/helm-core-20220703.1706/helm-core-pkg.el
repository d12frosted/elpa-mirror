(define-package "helm-core" "20220703.1706" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "0fc13ddb13b1c8e70eb6c0c7f7d46308a55f2344" :authors
  '(("Thierry Volpiatto "))
  :maintainer
  '("Thierry Volpiatto ")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
