(define-package "org-super-agenda" "20210924.245" "Supercharge your agenda"
  '((emacs "26.1")
    (s "1.10.0")
    (dash "2.13")
    (org "9.0")
    (ht "2.2")
    (ts "0.2"))
  :commit "ab30080c629e67ff4cb417ef86b1c7a19b7c87a5" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("hypermedia" "outlines" "org" "agenda")
  :url "http://github.com/alphapapa/org-super-agenda")
;; Local Variables:
;; no-byte-compile: t
;; End:
