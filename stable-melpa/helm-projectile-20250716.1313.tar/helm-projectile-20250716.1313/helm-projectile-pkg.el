;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-projectile" "20250716.1313"
  "Helm integration for Projectile."
  '((helm       "3.0")
    (projectile "2.9")
    (cl-lib     "0.3"))
  :url "https://github.com/bbatsov/helm-projectile"
  :commit "41068bbf38e56e66f1ec5832d355d6689ddbab07"
  :revdesc "41068bbf38e5"
  :keywords '("project" "convenience"))
