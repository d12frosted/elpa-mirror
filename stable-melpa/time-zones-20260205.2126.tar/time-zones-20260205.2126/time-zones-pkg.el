;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-zones" "20260205.2126"
  "Time zone lookups."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/time-zones"
  :commit "5513f14d857a67cfac56a86674dbf8d29f81fee5"
  :revdesc "5513f14d857a")
