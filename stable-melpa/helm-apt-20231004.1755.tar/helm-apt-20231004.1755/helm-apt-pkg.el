(define-package "helm-apt" "20231004.1755" "Helm interface for Debian/Ubuntu packages (apt-*)"
  '((helm "3.9.5")
    (emacs "25.1"))
  :commit "19075bbdf959ad8878c6c743b61b9e96d4316476" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://github.com/emacs-helm/helm-apt")
;; Local Variables:
;; no-byte-compile: t
;; End:
