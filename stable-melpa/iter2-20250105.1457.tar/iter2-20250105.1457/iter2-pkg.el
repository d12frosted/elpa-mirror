;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iter2" "20250105.1457"
  "Reimplementation of Elisp generators."
  '((emacs "25.1"))
  :url "https://github.com/doublep/iter2"
  :commit "5118f1174160acfac3b6f9061ea00e03a48fce42"
  :revdesc "5118f1174160"
  :keywords '("elisp" "extensions")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
