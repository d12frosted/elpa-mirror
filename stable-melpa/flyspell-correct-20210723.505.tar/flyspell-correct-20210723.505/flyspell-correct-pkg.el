(define-package "flyspell-correct" "20210723.505" "Correcting words with flyspell via custom interface"
  '((emacs "24"))
  :commit "f9b57ea42938e272d9b7ac90d62c5496694ece00" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/flyspell-correct")
;; Local Variables:
;; no-byte-compile: t
;; End:
