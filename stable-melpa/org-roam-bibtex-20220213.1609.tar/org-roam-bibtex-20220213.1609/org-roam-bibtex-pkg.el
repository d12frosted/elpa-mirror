(define-package "org-roam-bibtex" "20220213.1609" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "2.2.0")
    (bibtex-completion "2.0.0"))
  :commit "714b519f000697983eee291f7a28d595ef731d99" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
