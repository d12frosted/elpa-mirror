;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260205.1511"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "3b33795d2aa69b723e17cdc5100731c62609278b"
  :revdesc "3b33795d2aa6")
