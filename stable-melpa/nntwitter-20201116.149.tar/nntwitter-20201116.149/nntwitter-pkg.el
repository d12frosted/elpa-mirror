(define-package "nntwitter" "20201116.149" "Gnus Backend For Twitter"
  '((emacs "25.1")
    (dash "20190401")
    (anaphora "20180618")
    (request "20190819"))
  :commit "3659766769b7b50c50a82317ccd660524abce68f" :url "https://github.com/dickmao/nntwitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
