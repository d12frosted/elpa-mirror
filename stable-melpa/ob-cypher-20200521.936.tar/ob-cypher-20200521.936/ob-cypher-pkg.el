;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-cypher" "20200521.936"
  "Query neo4j using cypher in org-mode blocks."
  '((s               "1.9.0")
    (cypher-mode     "0.0.6")
    (dash            "2.10.0")
    (dash-functional "1.2.0"))
  :url "https://github.com/zweifisch/ob-cypher"
  :commit "da9f97339474a48d759fc128cee610c0bc9ae6c0"
  :revdesc "da9f97339474"
  :keywords '("org" "babel" "cypher" "neo4j")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
