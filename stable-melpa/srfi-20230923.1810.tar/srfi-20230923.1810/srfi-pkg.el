(define-package "srfi" "20230923.1810" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "520e7dd740e713d06966b54c9eac9e46c648b583" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
