;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20241108.151"
  "LSP mode."
  '((emacs         "27.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "4f987cb9841d1bd80d2c71c604103d78685b7acd"
  :revdesc "4f987cb9841d"
  :keywords '("languages"))
