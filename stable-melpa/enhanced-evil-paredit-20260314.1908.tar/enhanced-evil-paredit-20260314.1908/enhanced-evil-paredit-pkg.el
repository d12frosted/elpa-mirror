;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20260314.1908"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "11521019d4800f4de2a2ac460a48eba013ad89b6"
  :revdesc "11521019d480"
  :keywords '("convenience"))
