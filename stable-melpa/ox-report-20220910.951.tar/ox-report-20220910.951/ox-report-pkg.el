(define-package "ox-report" "20220910.951" "Export your org file to minutes report PDF file"
  '((emacs "24.4")
    (org-msg "3.9"))
  :commit "029fac8d4c83cc8841ade0dfebc8b7d7508efbb2" :authors
  '(("Matthias David" . "matthias@gnu.re"))
  :maintainers
  '(("Matthias David" . "matthias@gnu.re"))
  :maintainer
  '("Matthias David" . "matthias@gnu.re")
  :keywords
  '("org" "outlines" "report" "exporter" "meeting" "minutes")
  :url "https://github.com/DarkBuffalo/ox-report")
;; Local Variables:
;; no-byte-compile: t
;; End:
