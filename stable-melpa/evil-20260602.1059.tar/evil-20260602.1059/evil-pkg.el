;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil" "20260602.1059"
  "Extensible vi layer."
  '((emacs    "24.1")
    (cl-lib   "0.5")
    (goto-chg "1.6")
    (nadvice  "0.3"))
  :url "https://github.com/emacs-evil/evil"
  :commit "ba04ab8ce5a11e103d7343582b266b2f83cc752b"
  :revdesc "ba04ab8ce5a1"
  :keywords '("emulations")
  :maintainers '(("Tom Dalziel" . "tom.dalziel@gmail.com")))
