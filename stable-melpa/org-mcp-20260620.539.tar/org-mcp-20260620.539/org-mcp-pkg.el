;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260620.539"
  "MCP server for Org-mode."
  '((emacs          "27.1")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "b90355437b4c2b69b2362f04cff03f4877d7f022"
  :revdesc "b90355437b4c"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
