;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shift-number" "20260620.335"
  "Increase/decrease the number at point."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-shift-number"
  :commit "fed971a983fce0f60a2e9795df3eca7712152a29"
  :revdesc "fed971a983fc"
  :keywords '("convenience")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
