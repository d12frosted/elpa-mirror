;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20241107.1559"
  "Telegram client (unofficial)."
  '((emacs               "27.1")
    (visual-fill-column  "1.9")
    (rainbow-identifiers "0.2.2")
    (transient           "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "3126a5ca33f7be8befe4a2884570841ea95c5f76"
  :revdesc "3126a5ca33f7"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
