;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwin" "20251125.2357"
  "Navigate and arrange desktop windows."
  '((emacs "30.2"))
  :url "https://github.com/lsth/dwin"
  :commit "92f252008647b7b4e9e63d4607fcbcc5081db140"
  :revdesc "92f252008647"
  :keywords '("frames" "processes" "convenience")
  :authors '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de"))
  :maintainers '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de")))
