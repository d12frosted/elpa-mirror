(define-package "robe" "20240316.115" "Code navigation, documentation lookup and completion for Ruby"
  '((inf-ruby "2.5.1")
    (emacs "25.1"))
  :commit "1e8678027fb88ca2d699acad1dbd8f800c5153bb" :authors
  '(("Dmitry Gutov"))
  :maintainers
  '(("Dmitry Gutov"))
  :maintainer
  '("Dmitry Gutov")
  :keywords
  '("ruby" "convenience" "rails")
  :url "https://github.com/dgutov/robe")
;; Local Variables:
;; no-byte-compile: t
;; End:
