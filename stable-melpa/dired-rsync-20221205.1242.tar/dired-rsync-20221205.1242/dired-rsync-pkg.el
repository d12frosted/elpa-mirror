(define-package "dired-rsync" "20221205.1242" "Allow rsync from dired buffers"
  '((s "1.12.0")
    (dash "2.0.0")
    (emacs "24"))
  :commit "e2c5a0a8f19a17040b348a1a56b8facce58c9fcd" :authors
  '(("Alex Bennée" . "alex@bennee.com"))
  :maintainer
  '("Alex Bennée" . "alex@bennee.com")
  :url "https://github.com/stsquad/dired-rsync")
;; Local Variables:
;; no-byte-compile: t
;; End:
