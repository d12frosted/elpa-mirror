(define-package "modus-themes" "20220403.428" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "bdb4235eacdef25cd307b401c21f71ceabe0a98f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
