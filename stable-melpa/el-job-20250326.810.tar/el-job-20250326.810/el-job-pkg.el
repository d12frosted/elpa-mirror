;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250326.810"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "5fcadfaf967afd6bf4e2cc0c64576f72c4b9cf65"
  :revdesc "5fcadfaf967a"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
