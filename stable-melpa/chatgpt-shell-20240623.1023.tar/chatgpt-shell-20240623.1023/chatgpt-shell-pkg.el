(define-package "chatgpt-shell" "20240623.1023" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.50.1"))
  :commit "35437f283daa92946d549060b03ea4ac72d645cf" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
