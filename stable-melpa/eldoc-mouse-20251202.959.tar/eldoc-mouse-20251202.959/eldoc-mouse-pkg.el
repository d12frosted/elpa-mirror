;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20251202.959"
  "Display documentation for mouse hover."
  '((emacs    "27.1")
    (posframe "1.4.0")
    (eglot    "1.8"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "c42f3c920723a2b9248847d805c711d612b63e47"
  :revdesc "c42f3c920723"
  :keywords '("tools" "languages" "convenience" "mouse" "hover")
  :authors '(("Huang Feiyu" . "sibadake1@163.com"))
  :maintainers '(("Huang Feiyu" . "sibadake1@163.com")))
