;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "countdown-modeline" "20260615.1455"
  "Display a color-coded countdown in the modeline."
  '((emacs "27.1"))
  :url "https://github.com/jholland82/countdown-modeline"
  :commit "7485863972bd941a786bc595d566e02a490bb352"
  :revdesc "7485863972bd"
  :keywords '("convenience" "modeline")
  :authors '(("Jeffrey Holland" . "jeff.holland@gmail.com"))
  :maintainers '(("Jeffrey Holland" . "jeff.holland@gmail.com")))
