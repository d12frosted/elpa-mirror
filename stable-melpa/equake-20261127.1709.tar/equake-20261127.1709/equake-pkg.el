;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "equake" "20261127.1709"
  "Drop-down console for (e)shell & terminal emulation."
  '((emacs "27.1"))
  :url "https://github.com/emacsomancer/equake"
  :commit "c1dc003043464c04ed41d5bcab9a31c43c5f812d"
  :revdesc "c1dc00304346"
  :keywords '("convenience" "frames" "terminals" "tools" "window-system")
  :authors '(("Benjamin Slade" . "LfLg.gg.Lx.f.xx@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "LfLg.gg.Lx.f.xx@lambda-y.net")))
