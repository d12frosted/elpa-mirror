(define-package "pyramid" "20230114.1049" "Minor mode for working with pyramid projects"
  '((emacs "25.2")
    (pythonic "0.1.1")
    (tablist "0.70"))
  :commit "c8a8b36725d85664e74f59600fe5d18d06ea907d" :authors
  '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainer
  '("Daniel Kraus" . "daniel@kraus.my")
  :keywords
  '("python" "pyramid" "pylons" "convenience" "tools" "processes")
  :url "https://github.com/dakra/pyramid.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
