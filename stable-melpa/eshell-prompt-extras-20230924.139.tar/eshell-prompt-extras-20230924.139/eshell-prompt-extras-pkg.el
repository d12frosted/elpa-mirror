(define-package "eshell-prompt-extras" "20230924.139" "Display extra information for your eshell prompt."
  '((emacs "25"))
  :commit "10dc8691e555eae31414276f33ff3ba6a863d540" :authors
  '(("zwild" . "judezhao@outlook.com"))
  :maintainers
  '(("Xu Chunyang" . "xuchunyang56@gmail.com"))
  :maintainer
  '("Xu Chunyang" . "xuchunyang56@gmail.com")
  :keywords
  '("eshell" "prompt")
  :url "https://github.com/zwild/eshell-prompt-extras")
;; Local Variables:
;; no-byte-compile: t
;; End:
