(define-package "modus-themes" "20220831.108" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "c80eed8585846859ce35c2a62dfa32a0be20a633" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
