(define-package "tsort" "20231015.2136" "Topological sort for Emacs Lisp"
  '((emacs "28.1"))
  :commit "844a983841798a5e9de4a442674d691fea6d09ff" :authors
  '(("Ethan Hawk" . "ethan.hawk@valpo.edu"))
  :maintainers
  '(("Ethan Hawk" . "ethan.hawk@valpo.edu"))
  :maintainer
  '("Ethan Hawk" . "ethan.hawk@valpo.edu")
  :keywords
  '("algorithm" "tools")
  :url "https://github.com/ehawkvu/tsort.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
