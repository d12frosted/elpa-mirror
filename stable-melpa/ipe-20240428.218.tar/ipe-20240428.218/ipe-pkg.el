(define-package "ipe" "20240428.218" "Insert, Update and Delete PAIRs using overlays"
  '((emacs "24.4"))
  :commit "f1a7c5d464a937ec87c23a4a0bb41207eab07adf" :authors
  '((nil . "Brian Kavanagh <(concat \"Brians.Emacs\" \"@gmail.com\")>"))
  :maintainers
  '((nil . "Brian Kavanagh <(concat \"Brians.Emacs\" \"@gmail.com\")>"))
  :maintainer
  '(nil . "Brian Kavanagh <(concat \"Brians.Emacs\" \"@gmail.com\")>")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/BriansEmacs/insert-pair-edit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
