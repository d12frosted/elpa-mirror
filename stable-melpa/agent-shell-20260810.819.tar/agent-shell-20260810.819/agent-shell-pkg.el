;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260810.819"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.96.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4aa030e853a1fe640da5678c87e6a905440305ba"
  :revdesc "4aa030e853a1")
