;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261113.1857"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "8f035ae84440b4bdce7df3177c4945903eb68bb6"
  :revdesc "8f035ae84440"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
