;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260226.635"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "cacd5cecee672ad160be680d840df6e6d7fbf8a4"
  :revdesc "cacd5cecee67"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
