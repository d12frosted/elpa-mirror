(define-package "bbdb-vcard" "20210322.1100" "vCard import/export for BBDB"
  '((bbdb "3.0"))
  :commit "49ae6f412a005203438327768e03772a4c7e1fbc" :authors
  '(("Bert Burgemeister" . "trebbu@googlemail.com")
    ("Toke Høiland-Jørgensen")
    ("Kevin Brubeck Unhammer")
    ("Steve Purcell")
    ("Vincent Geddes" . "vincent.geddes@gmail.com"))
  :maintainer
  '("Bert Burgemeister" . "trebbu@googlemail.com")
  :keywords
  '("data" "calendar" "mail" "news")
  :url "https://github.com/tohojo/bbdb-vcard")
;; Local Variables:
;; no-byte-compile: t
;; End:
