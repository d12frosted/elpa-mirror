;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp" "20251027.1125"
  "Model Context Protocol."
  '((emacs   "30.1")
    (jsonrpc "1.0.25"))
  :url "https://github.com/lizqwerscott/mcp.el"
  :commit "ee6dc5e7c1eaec8817e331d9aef91de9c0f43ce7"
  :revdesc "ee6dc5e7c1ea"
  :keywords '("tools")
  :authors '(("lizqwer scott" . "lizqwerscott@gmail.com"))
  :maintainers '(("lizqwer scott" . "lizqwerscott@gmail.com")))
