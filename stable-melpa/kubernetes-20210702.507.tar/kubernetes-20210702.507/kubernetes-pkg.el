(define-package "kubernetes" "20210702.507" "Magit-like porcelain for Kubernetes."
  '((emacs "25.1")
    (dash "2.12.0")
    (magit "2.8.0")
    (magit-popup "2.13.0"))
  :commit "cc28f1d989d7d053c2c669170e86c0ebe3b4f5b5" :authors
  '(("Chris Barrett" . "chris+emacs@walrus.cool"))
  :maintainer
  '("Chris Barrett" . "chris+emacs@walrus.cool"))
;; Local Variables:
;; no-byte-compile: t
;; End:
