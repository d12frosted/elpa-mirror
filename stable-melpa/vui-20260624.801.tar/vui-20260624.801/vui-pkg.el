;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260624.801"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "bc7add258504673a5c3e1bcd9f8341aaa104d522"
  :revdesc "bc7add258504"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
