;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241220.1043"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.74.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "2345b9154c54c95c0b6a12ac2487936fb9cd8854"
  :revdesc "2345b9154c54")
