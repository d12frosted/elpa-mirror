;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260805.1158"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "6007a899026134507c6625d9f0d89a38bbe21e4b"
  :revdesc "6007a8990261"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
