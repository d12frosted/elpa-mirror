;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu-cite" "20260309.2341"
  "Yet another citation tool for GNU Emacs."
  '((flim "1.14.9"))
  :url "https://github.com/cvs-m17n-org/MU-CITE"
  :commit "01345683477c6802f437a63ae2df3d8df1665f6d"
  :revdesc "01345683477c"
  :keywords '("mail" "news" "citation")
  :authors '(("MORIOKA Tomohiko" . "tomo@m17n.org")
             ("Shuhei KOBAYASHI" . "shuhei@aqua.ocn.ne.jp"))
  :maintainers '(("Katsumi Yamaoka" . "yamaoka@jpl.org")))
