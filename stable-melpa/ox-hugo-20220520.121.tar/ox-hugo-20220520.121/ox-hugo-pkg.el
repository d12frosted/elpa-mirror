(define-package "ox-hugo" "20220520.121" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "26.3")
    (tomelr "0.4.3"))
  :commit "8914b75f51e3340d4a8d394f53ac2ece20e649c0" :authors
  '(("Kaushal Modi" . "kaushal.modi@gmail.com")
    ("Matt Price" . "moptop99@gmail.com"))
  :maintainer
  '("Kaushal Modi" . "kaushal.modi@gmail.com")
  :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
