;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260916.2007"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "4925190c930c36f683b19fdc72b0783b5d17a96b"
  :revdesc "4925190c930c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
