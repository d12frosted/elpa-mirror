(define-package "loopy" "20240225.1310" "A looping macro"
  '((emacs "27.1")
    (map "3.3.1")
    (seq "2.22")
    (compat "29.1.3"))
  :commit "14a8a8e9dc898e8c6ac5e92e14d2ae3b092e1817" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
