;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260320.1842"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral DeepSeek OpenRouter Support."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "a27b3e9f5c3bca38a6575477cfdd8f4259c15398"
  :revdesc "a27b3e9f5c3b"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
