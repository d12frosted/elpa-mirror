(define-package "detached" "20221101.1755" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "6415d90f8260b6c5f1da00e0028acf4be5b4053e" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
