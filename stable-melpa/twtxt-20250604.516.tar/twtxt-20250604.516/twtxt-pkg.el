;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "twtxt" "20250604.516"
  "A twtxt client for Emacs."
  '((emacs              "25.1")
    (request            "0.2.0")
    (visual-fill-column "2.4"))
  :url "https://codeberg.org/deadblackclover/twtxt-el"
  :commit "290d81bb944a20784f0c466fc4eebafb0b34dbe3"
  :revdesc "290d81bb944a"
  :authors '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com"))
  :maintainers '(("DEADBLACKCLOVER" . "deadblackclover@protonmail.com")))
