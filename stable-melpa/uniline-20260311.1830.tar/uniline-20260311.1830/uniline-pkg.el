;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260311.1830"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "d2e1ddf6806f33f58f7877dad6cab862c02263fa"
  :revdesc "d2e1ddf6806f"
  :keywords '("convenience" "text"))
