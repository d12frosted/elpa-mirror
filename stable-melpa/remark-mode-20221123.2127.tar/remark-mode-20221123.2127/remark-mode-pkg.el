(define-package "remark-mode" "20221123.2127" "Major mode for the remark slideshow tool"
  '((emacs "25.1")
    (markdown-mode "2.0"))
  :commit "5a2a702d2af8fd007ae02237d5824356d0c1acc6" :authors
  '(("@torgeir"))
  :maintainer
  '("@torgeir")
  :keywords
  '("remark" "slideshow" "markdown" "hot reload"))
;; Local Variables:
;; no-byte-compile: t
;; End:
