(define-package "lispy" "20220107.1902" "vi-like Paredit"
  '((emacs "24.3")
    (ace-window "0.9.0")
    (iedit "0.9.9")
    (swiper "0.13.4")
    (hydra "0.14.0")
    (zoutline "0.1.0"))
  :commit "a4844b9f46b97715524beb8d19c9f3192328394c" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/abo-abo/lispy")
;; Local Variables:
;; no-byte-compile: t
;; End:
