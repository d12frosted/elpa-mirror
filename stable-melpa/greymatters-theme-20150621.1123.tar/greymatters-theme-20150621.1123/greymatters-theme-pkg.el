;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greymatters-theme" "20150621.1123"
  "Emacs 24 theme with a light background."
  '((emacs "24"))
  :url "https://github.com/mswift42/greymatters-theme"
  :commit "a7220a8c6cf18ccae2b76946b6f01188a7c9d5d1"
  :revdesc "a7220a8c6cf1")
