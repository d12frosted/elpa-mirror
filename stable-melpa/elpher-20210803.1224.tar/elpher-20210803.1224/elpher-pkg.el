(define-package "elpher" "20210803.1224" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "6e2b49ea90c38098e731bd877002486b67faf7d7" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
