(define-package "wildcharm-theme" "20231011.110" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "4c0f5949e9fe581cf0ac72b1fc3668e6306103ba" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
