;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-browse-url-in-article" "20260806.2358"
  "Smarter browse-url for Gnus articles."
  '((emacs "27.1"))
  :url "https://github.com/jmibanez/gnus-browse-url-in-article"
  :commit "1fac4601d1222bca0e244f61fd0e6fba75cdbb0c"
  :revdesc "1fac4601d122"
  :keywords '("convenience" "mail" "gnus")
  :authors '(("JM Ibañez" . "jm@jmibanez.com"))
  :maintainers '(("JM Ibañez" . "jm@jmibanez.com")))
