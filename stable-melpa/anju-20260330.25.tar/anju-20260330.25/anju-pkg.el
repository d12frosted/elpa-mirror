;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260330.25"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (magit         "4.4.0")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "e9f3ca4c96b7149c5f8be711ebd5b95473368b9b"
  :revdesc "e9f3ca4c96b7"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
