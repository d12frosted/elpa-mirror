;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "opensub" "20250329.717"
  "Search and download from open-subtitles."
  '((emacs "25.1")
    (plz   "0"))
  :url "https://github.com/danielfleischer/opensub"
  :commit "d8b11e979897616a661edd22a759e5cb025af356"
  :revdesc "d8b11e979897"
  :keywords '("multimedia")
  :authors '(("Daniel Fleischer" . "danflscr@gmail.com"))
  :maintainers '(("Daniel Fleischer" . "danflscr@gmail.com")))
