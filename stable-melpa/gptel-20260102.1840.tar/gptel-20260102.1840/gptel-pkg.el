;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260102.1840"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "93d58e4cce68c8f603562904f77a3e329eaf5a24"
  :revdesc "93d58e4cce68"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
