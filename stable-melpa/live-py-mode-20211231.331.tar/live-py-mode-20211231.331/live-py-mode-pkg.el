(define-package "live-py-mode" "20211231.331" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "43af1831c71c3913cf8d1a574fddab4bd01c336e" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
