(define-package "live-py-mode" "20211231.331" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "4df0e46b166963a9fcf40e010f37516342a7f228" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
