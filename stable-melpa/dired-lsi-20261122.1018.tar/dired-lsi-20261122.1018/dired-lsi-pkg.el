;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-lsi" "20261122.1018"
  "Add memo to directory and show it in dired."
  '((emacs "26.1"))
  :url "https://github.com/conao3/dired-lsi.el"
  :commit "c0f67082d095ed480969336a5a7b87dd77b2ef58"
  :revdesc "c0f67082d095"
  :keywords '("convenience")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
