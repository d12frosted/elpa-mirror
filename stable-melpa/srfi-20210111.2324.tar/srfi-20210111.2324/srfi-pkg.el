(define-package "srfi" "20210111.2324" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "669532e3cf56232f22c3b318fcd4961a3789ecc0" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
