;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sphinx-frontend" "20161025.758"
  "Launch build process for rst documents via sphinx."
  ()
  :url "https://github.com/kostafey/sphinx-frontend"
  :commit "0cbb03361c245382d3e679dded30c4fc1713c252"
  :revdesc "0cbb03361c24"
  :keywords '("compile" "sphinx" "restructuredtext")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
