(define-package "live-py-mode" "20210409.328" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "242c30e64fef46e516ff309f222c8b1d7f7a8ac2" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
