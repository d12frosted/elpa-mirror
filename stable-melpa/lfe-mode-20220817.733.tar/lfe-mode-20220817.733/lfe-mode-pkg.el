(define-package "lfe-mode" "20220817.733" "Lisp Flavoured Erlang mode" 'nil :commit "6b2569f25572dee429f6c2f0eb2ef576999e5fb9")
;; Local Variables:
;; no-byte-compile: t
;; End:
