;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260704.917"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f77efee9172854abc08652637d23adc26faa25a2"
  :revdesc "f77efee91728"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
