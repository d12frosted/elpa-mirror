;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250416.1658"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "3b636aceee9e1dab5edc8c682d566221ccdcfb10"
  :revdesc "3b636aceee9e"
  :keywords '("languages"))
