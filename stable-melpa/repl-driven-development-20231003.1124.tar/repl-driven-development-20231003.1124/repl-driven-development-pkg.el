(define-package "repl-driven-development" "20231003.1124" "Send arbitrary code to a REPL in the background"
  '((s "1.12.0")
    (dash "2.16.0")
    (eros "0.1.0")
    (bind-key "2.4.1")
    (emacs "27.1")
    (f "0.20.0")
    (devdocs "0.5")
    (pulsar "1.0.1"))
  :commit "7af3d2fdb1e626739a6553b182204b2b08e0091a" :authors
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers
  '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainer
  '("Musa Al-hassy" . "alhassy@gmail.com")
  :keywords
  '("repl-driven-development" "rdd" "repl" "lisp" "java" "python" "ruby" "programming" "convenience")
  :url "http://alhassy.com/repl-driven-development")
;; Local Variables:
;; no-byte-compile: t
;; End:
