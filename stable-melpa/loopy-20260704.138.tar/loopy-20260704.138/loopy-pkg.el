;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260704.138"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://codeberg.org/okamsn/loopy"
  :commit "c845e017afd729f766b6d0aab10eec9351703753"
  :revdesc "c845e017afd7"
  :keywords '("extensions"))
