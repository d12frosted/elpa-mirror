(define-package "detached" "20220704.941" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "b778480d176f0fe16243f2eb4128a48ce0d0f6d5" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
