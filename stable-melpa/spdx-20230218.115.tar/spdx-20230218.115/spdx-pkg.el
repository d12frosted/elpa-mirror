(define-package "spdx" "20230218.115" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d423c06d5762629cb0b40fc1e8634976a1df5cf2" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
