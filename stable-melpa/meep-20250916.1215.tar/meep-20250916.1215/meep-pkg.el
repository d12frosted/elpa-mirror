;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250916.1215"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "f0409305434379044cf22b33cf477b29ce5763e0"
  :revdesc "f04093054343"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
