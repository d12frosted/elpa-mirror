;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vtab" "20260209.1524"
  "Vertical tab bar."
  '((emacs "27.1"))
  :url "https://github.com/mugen-void/vtab"
  :commit "ae2ef3915e19c6ebd36f7e87dc37219263744f23"
  :revdesc "ae2ef3915e19"
  :keywords '("convenience" "frames")
  :authors '(("mugen" . "mugen.void42@gmail.com"))
  :maintainers '(("mugen" . "mugen.void42@gmail.com")))
