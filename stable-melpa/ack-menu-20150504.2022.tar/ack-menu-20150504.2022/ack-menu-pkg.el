;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ack-menu" "20150504.2022"
  "A menu-based front-end for ack."
  '((mag-menu "0.1.0"))
  :url "https://github.com/chumpage/ack-menu"
  :commit "f77be93a4697926ecf3195a355eb69580f695f4d"
  :revdesc "f77be93a4697"
  :keywords '("tools" "matching" "convenience"))
