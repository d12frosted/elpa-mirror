;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260308.23"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "26.1"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "1cc7a57f1e6f6aa184931b59998a9570ea9599f2"
  :revdesc "1cc7a57f1e6f"
  :keywords '("programming"))
