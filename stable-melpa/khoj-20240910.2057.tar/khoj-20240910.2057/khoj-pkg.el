(define-package "khoj" "20240910.2057" "Your Second Brain"
  '((emacs "27.1")
    (transient "0.3.0")
    (dash "2.19.1"))
  :commit "596db603e03735e3fb6ecae0696a4fe9bbfce385" :authors
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
    ("Saba Imran" . "saba@khoj.dev"))
  :maintainers
  '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
    ("Saba Imran" . "saba@khoj.dev"))
  :maintainer
  '("Debanjum Singh Solanky" . "debanjum@khoj.dev")
  :keywords
  '("search" "chat" "ai" "org-mode" "outlines" "markdown" "pdf" "image")
  :url "https://github.com/khoj-ai/khoj/tree/master/src/interface/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
