(define-package "spaceline" "20230821.1443" "Modeline configuration library for powerline"
  '((emacs "24.4")
    (cl-lib "0.5")
    (powerline "2.3")
    (dash "2.11.0")
    (s "1.10.0"))
  :commit "3b1ae4d429f12bac65b0f3764f84eace2903a417" :authors
  '(("Eivind Fonn" . "evfonn@gmail.com"))
  :maintainers
  '(("Eivind Fonn" . "evfonn@gmail.com"))
  :maintainer
  '("Eivind Fonn" . "evfonn@gmail.com")
  :keywords
  '("mode-line" "powerline" "spacemacs")
  :url "https://github.com/TheBB/spaceline")
;; Local Variables:
;; no-byte-compile: t
;; End:
