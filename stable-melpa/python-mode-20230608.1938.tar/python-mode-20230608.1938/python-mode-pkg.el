(define-package "python-mode" "20230608.1938" "Python major mode" 'nil :commit "5a0f907cf0417347964c25436057c7f44b8de733" :authors
  '(("2015-2023 https://gitlab.com/groups/python-mode-devs")
    ("2003-2014 https://launchpad.net/python-mode")
    ("1995-2002 Barry A. Warsaw")
    ("1992-1994 Tim Peters"))
  :maintainer
  '(nil . "python-mode@python.org")
  :keywords
  '("python" "languages" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
