;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "20250322.1747"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "http://github.com/szermatt/visual-replace"
  :commit "638f9641042a58865a044ef1766ef0a2be1c04c0"
  :revdesc "638f9641042a"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
