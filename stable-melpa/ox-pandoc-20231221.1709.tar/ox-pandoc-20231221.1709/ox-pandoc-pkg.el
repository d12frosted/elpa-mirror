(define-package "ox-pandoc" "20231221.1709" "An Org-mode exporter using pandoc"
  '((org "8.2")
    (emacs "24.4")
    (dash "2.8")
    (ht "2.0"))
  :commit "f962392b9eb400e3d2c88a50aab8f77f6c39ec04" :authors
  '(("KAWABATA, Taichi" . "kawabata.taichi@gmail.com")
    ("FENTON, Alex" . "a-fent@github"))
  :maintainers
  '(("FENTON, Alex" . "a-fent@github"))
  :maintainer
  '("FENTON, Alex" . "a-fent@github")
  :keywords
  '("tools")
  :url "https://github.com/a-fent/ox-pandoc")
;; Local Variables:
;; no-byte-compile: t
;; End:
