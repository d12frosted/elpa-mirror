(define-package "hl-indent-scope" "20221211.709" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "b89f0a40d6e1b65c767d053d524544c7237f85d9" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
