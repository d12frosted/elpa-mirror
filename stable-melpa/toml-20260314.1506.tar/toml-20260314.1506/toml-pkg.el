;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260314.1506"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "d058f06efb94ab4b108aa666fa6917c9a48995d8"
  :revdesc "d058f06efb94"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
