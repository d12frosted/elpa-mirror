;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-latte" "20260315.900"
  "Auto-highlight unlinked Org-roam references."
  '((emacs       "27.1")
    (org-roam    "2.0")
    (inflections "1.1"))
  :url "https://github.com/yad-tahir/org-roam-latte"
  :commit "6cc41b3e20f8ec7762241774e7235f0e75fc2b7c"
  :revdesc "6cc41b3e20f8"
  :keywords '("hypermedia" "outlines" "org-roam" "convenience")
  :authors '(("Yad Tahir" . "yadatieee.org"))
  :maintainers '(("Yad Tahir" . "yadatieee.org")))
