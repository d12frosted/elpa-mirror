(define-package "unidecode" "20180312.1926" "Transliterate Unicode to ASCII" 'nil :commit "5502ada9287b4012eabb879f12f5b0a9df52c5b7" :authors
  (("sindikat <sindikat at mail36 dot net>"))
  :maintainer
  ("John Mastro" . "john.b.mastro@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
