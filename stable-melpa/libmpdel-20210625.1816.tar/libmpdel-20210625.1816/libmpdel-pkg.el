(define-package "libmpdel" "20210625.1816" "Communication with an MPD server"
  '((emacs "25.1"))
  :commit "b49ab2fe497d61d7d00ed1ad0c3b5a1d6a65e5c4" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("multimedia")
  :url "https://gitea.petton.fr/mpdel/libmpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
