;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251123.1806"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f36426ccb0418a3a7ec7da8b7ea5baa24cf4e472"
  :revdesc "f36426ccb041"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
