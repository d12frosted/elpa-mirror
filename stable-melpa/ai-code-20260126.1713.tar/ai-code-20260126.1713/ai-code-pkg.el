;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260126.1713"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "f657fe55dbdf030cfd71c66b5e2e8f154f6a0436"
  :revdesc "f657fe55dbdf"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
