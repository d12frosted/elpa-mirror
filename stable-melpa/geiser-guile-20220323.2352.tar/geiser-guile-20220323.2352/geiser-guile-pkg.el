(define-package "geiser-guile" "20220323.2352" "Guile's implementation of the geiser protocols"
  '((emacs "25.1")
    (geiser "0.23.2"))
  :commit "c641fcc50b6b86ca95743122b5206cdcd475f96e" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
