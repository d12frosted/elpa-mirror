;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ushin-shapes" "20241022.522"
  "USHIN shapes in org-mode."
  '((emacs        "27.1")
    (svg-tag-mode "0.3.3")
    (svg-lib      "0.3")
    (compat       "30.0.0.0"))
  :url "https://git.sr.ht/~ushin/ushin-shapes.el"
  :commit "fd2c4289c7d336528f1f855eb9378615417f4483"
  :revdesc "fd2c4289c7d3"
  :keywords '("convenience")
  :authors '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers '(("Joseph Turner" . "joseph@ushin.org")))
