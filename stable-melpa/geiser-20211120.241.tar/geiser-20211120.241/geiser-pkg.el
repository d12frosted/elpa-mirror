(define-package "geiser" "20211120.241" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "68e0991c96b1e5bc9a1d748a05a96127c6204987" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
