;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-vulpea" "20260809.1842"
  "Use Consult in tandem with Vulpea."
  '((emacs   "28.1")
    (vulpea  "2.0.0")
    (consult "2.2"))
  :url "https://github.com/fabcontigiani/consult-vulpea"
  :commit "3effef56dedf3df80667eec4c319f3fc55f5b5db"
  :revdesc "3effef56dedf"
  :keywords '("convenience" "notes" "vulpea")
  :authors '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com"))
  :maintainers '(("Fabrizio Contigiani" . "fabcontigiani@gmail.com")))
