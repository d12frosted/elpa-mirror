(define-package "code-review" "20211216.2242" "Perform code review from Github and Gitlab"
  '((emacs "25.1")
    (closql "1.2.0")
    (magit "3.0.0")
    (a "1.0.0")
    (ghub "3.5.1")
    (uuidgen "1.2")
    (deferred "0.5.1")
    (markdown-mode "2.4")
    (forge "0.3.0")
    (emojify "1.2"))
  :commit "b738a7fc6ed9f8b90cb4202aa1f9bdf28a9b1d93" :authors
  '(("Wanderson Ferreira <https://github.com/wandersoncferreira>"))
  :maintainer
  '("Wanderson Ferreira" . "wand@hey.com")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/wandersoncferreira/code-review")
;; Local Variables:
;; no-byte-compile: t
;; End:
