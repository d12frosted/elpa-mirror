;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251206.1752"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "4ed8dd608799bb412ccf71aad30e29483ebec620"
  :revdesc "4ed8dd608799"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
