(define-package "hyperdrive" "20230827.829" "P2P filesystem"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5"))
  :commit "5cf818f97cfbdfc9654be5313c15dbf44d8fc7b5" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
