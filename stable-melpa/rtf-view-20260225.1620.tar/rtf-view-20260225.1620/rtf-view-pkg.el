;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtf-view" "20260225.1620"
  "View Rich Text Format files."
  '((emacs "24.1"))
  :url "https://github.com/danielcmccarthy/rtf-view.git"
  :commit "0fc0d0baec1fb05d70aab6cf251f7d568677360c"
  :revdesc "0fc0d0baec1f"
  :keywords '("files" "data")
  :authors '(("Dan McCarthy" . "daniel.c.mccarthy@gmail.com"))
  :maintainers '(("Dan McCarthy" . "daniel.c.mccarthy@gmail.com")))
