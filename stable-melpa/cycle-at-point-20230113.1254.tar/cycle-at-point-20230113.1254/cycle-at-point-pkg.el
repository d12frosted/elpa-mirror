(define-package "cycle-at-point" "20230113.1254" "Cycle (rotate) the thing under the cursor"
  '((emacs "28.1")
    (recomplete "0.2"))
  :commit "e85ae108ed5cee64dd80305dcc2e8e7934cc6d56" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-cycle-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
