(define-package "stimmung-themes" "20220326.943" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "d4f331c689e55175f5e1ec922c2c8e809d400f9a" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
