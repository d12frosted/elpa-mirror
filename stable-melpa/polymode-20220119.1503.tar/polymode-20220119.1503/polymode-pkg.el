(define-package "polymode" "20220119.1503" "Extensible framework for multiple major modes"
  '((emacs "25"))
  :commit "d0913ed53d27ee90b8a31b7a78a29502a5314087" :authors
  '(("Vitalie Spinu"))
  :maintainer
  '("Vitalie Spinu")
  :keywords
  '("languages" "multi-modes" "processes")
  :url "https://github.com/polymode/polymode")
;; Local Variables:
;; no-byte-compile: t
;; End:
