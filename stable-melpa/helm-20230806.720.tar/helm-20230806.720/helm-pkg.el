(define-package "helm" "20230806.720" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.3")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "a9899a20df50aa8600d40c6553e12ce2d1f57aef" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
