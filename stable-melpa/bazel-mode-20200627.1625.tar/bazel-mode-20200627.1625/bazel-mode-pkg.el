(define-package "bazel-mode" "20200627.1625" "Emacs major mode for editing Bazel BUILD and WORKSPACE files"
  '((emacs "26.1"))
  :commit "689f5df2c728129f288ed6eed82cde5df8c2ad1f" :keywords
  '("build tools" "languages")
  :url "https://github.com/bazelbuild/emacs-bazel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
