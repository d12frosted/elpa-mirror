(define-package "org-treescope" "20200503.1609" "Time scoping sparse trees within org"
  '((emacs "24.3")
    (org "9.2.3")
    (org-ql "0.5pre")
    (dash "2.17.0"))
  :commit "a7c386ff134c71fd4f1f042e320751f077d57ddb" :authors
  '(("Mehmet Tekman"))
  :maintainer
  '("Mehmet Tekman")
  :keywords
  '("outlines")
  :url "https://github.com/mtekman/org-treescope.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
