;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xterm-color" "20251128.1134"
  "ANSI, XTERM 256 and Truecolor support."
  '((emacs "24.4"))
  :url "https://github.com/atomontage/xterm-color"
  :commit "7543ed80d0ad07f1044b4d55c9ee7893cd45362c"
  :revdesc "7543ed80d0ad"
  :keywords '("faces")
  :authors '(("xristos" . "xristos@sdf.org"))
  :maintainers '(("xristos" . "xristos@sdf.org")))
