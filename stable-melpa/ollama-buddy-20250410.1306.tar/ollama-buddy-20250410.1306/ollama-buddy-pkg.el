;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250410.1306"
  "Ollama LLM AI Assistant with ChatGPT and Claude Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "58a89f91b2bcb7e81accd5d3e716ddd0f410ec78"
  :revdesc "58a89f91b2bc"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
