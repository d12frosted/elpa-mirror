;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-python-preset" "20260329.335"
  "Eglot preset for Python."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-python-preset"
  :commit "3c820fd06193a67765683f1fab387b039fcdb634"
  :revdesc "3c820fd06193"
  :keywords '("python" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
