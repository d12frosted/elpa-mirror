(define-package "flycheck-apertium" "20181122.1935" "Apertium checkers in flycheck"
  '((flycheck "0.25"))
  :commit "e146ab1b929c50450ba0708e1bdd9fed85606964" :authors
  '(("Kevin Brubeck Unhammer" . "unhammer+apertium@mm.st"))
  :maintainer
  '("Kevin Brubeck Unhammer" . "unhammer+apertium@mm.st")
  :keywords
  '("convenience" "tools" "xml")
  :url "http://wiki.apertium.org/wiki/Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
