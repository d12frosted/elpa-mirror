;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251101.625"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "bd68e93088dde09d771b0d65a152b10b183bb802"
  :revdesc "bd68e93088dd"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
