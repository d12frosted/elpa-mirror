(define-package "mu4e-overview" "20240326.1036" "Show overview of maildir"
  '((emacs "26"))
  :commit "22d8bb2994e85b20884ffbfd83bca3e03f702a27" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("mail" "tools")
  :url "https://github.com/mkcms/mu4e-overview")
;; Local Variables:
;; no-byte-compile: t
;; End:
