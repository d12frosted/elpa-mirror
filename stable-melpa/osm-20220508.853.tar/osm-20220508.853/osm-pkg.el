(define-package "osm" "20220508.853" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "45dfc686e527d69b7965752594020a936ddfa9ef" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
