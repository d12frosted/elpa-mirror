;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260722.1634"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "004c680692dfcf6be957bee26ee33c94404b3f41"
  :revdesc "004c680692df"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
