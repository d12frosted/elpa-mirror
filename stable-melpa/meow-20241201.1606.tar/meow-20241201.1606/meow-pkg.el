;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241201.1606"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "6d94efba163ca12031b88c6e6034b1d732a49a55"
  :revdesc "6d94efba163c"
  :keywords '("convenience" "modal-editing"))
