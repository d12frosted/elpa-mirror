;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20260926.1128"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "519e20239d3f4ac21cd9849361622d9c4c8f0e37"
  :revdesc "519e20239d3f"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
