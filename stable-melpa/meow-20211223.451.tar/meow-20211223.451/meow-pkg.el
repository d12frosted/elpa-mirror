(define-package "meow" "20211223.451" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "1525f755166d71f930991cb4185cfdaaeb492189" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
