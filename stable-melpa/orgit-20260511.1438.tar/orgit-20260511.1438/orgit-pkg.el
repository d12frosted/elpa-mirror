;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260511.1438"
  "Support for Org links to Magit buffers."
  '((emacs    "28.1")
    (compat   "30.1")
    (cond-let "1.1")
    (magit    "4.5")
    (org      "9.7"))
  :url "https://github.com/magit/orgit"
  :commit "2de0c1839cb463c8c80f9c2de6786b473ba473f5"
  :revdesc "2de0c1839cb4"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
