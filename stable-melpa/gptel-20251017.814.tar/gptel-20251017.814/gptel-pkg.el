;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251017.814"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "d8f3f67c827f5f16e23c8f10fb61bfc8e145d9cf"
  :revdesc "d8f3f67c827f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
