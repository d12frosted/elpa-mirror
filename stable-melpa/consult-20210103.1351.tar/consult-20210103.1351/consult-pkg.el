(define-package "consult" "20210103.1351" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "4fe41a5aea26ca98ef6e1861d88fe6c3a7a77d3b" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
