;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repo-grep" "20260219.1754"
  "Project-wide grep search."
  '((emacs "25.1"))
  :url "https://github.com/BHFock/repo-grep"
  :commit "786259b805bd0617f1e718c1da79a5ef2da5a2ec"
  :revdesc "786259b805bd"
  :keywords '("tools" "search" "grep" "convenience" "project"))
