;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250514.644"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "fd9200b55979c9b262b269a2e4b5eb62ffc4253c"
  :revdesc "fd9200b55979"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
