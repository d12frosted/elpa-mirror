(define-package "notmuch" "20220126.1122" "run notmuch within emacs" 'nil :commit "e1e1b1176d617f6561b2dbc278110c963e116f1f" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
