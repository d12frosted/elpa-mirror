(define-package "notmuch" "20220126.1122" "run notmuch within emacs" 'nil :commit "28600c6ea1ed79f1b372c06fcdc839e7a6787dfc" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
