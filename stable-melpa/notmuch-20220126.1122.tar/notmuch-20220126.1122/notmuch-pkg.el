(define-package "notmuch" "20220126.1122" "run notmuch within emacs" 'nil :commit "0c357ce78516ca176156a12eb362fb1d854074b6" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
