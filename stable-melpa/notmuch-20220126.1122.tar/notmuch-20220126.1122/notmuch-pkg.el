(define-package "notmuch" "20220126.1122" "run notmuch within emacs" 'nil :commit "ade8202c1860d1b62bacedd2c54033800d0697b1" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
