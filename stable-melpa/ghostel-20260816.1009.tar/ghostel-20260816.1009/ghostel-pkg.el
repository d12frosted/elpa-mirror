;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260816.1009"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "cc707024b0a16d00ec520cd51f466245a2139ce1"
  :revdesc "cc707024b0a1"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
