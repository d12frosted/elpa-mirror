(define-package "citre" "20210811.1328" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "2a9119e6bce717bdc567e1cbc24b323d01804288" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
