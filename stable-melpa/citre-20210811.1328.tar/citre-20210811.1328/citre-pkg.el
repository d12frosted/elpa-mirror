(define-package "citre" "20210811.1328" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "3f31a0ad39c2a56519277c257c82826d35ae94cf" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
