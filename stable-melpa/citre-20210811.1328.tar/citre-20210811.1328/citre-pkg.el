(define-package "citre" "20210811.1328" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "1d3ed1f72828fbfda4229e6cd92f3b8e3f43cb8c" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
