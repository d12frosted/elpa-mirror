;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251001.452"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "247a9f7291c38e9d4070673f3a18688357e917de"
  :revdesc "247a9f7291c3"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
