;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260219.959"
  "On-the-fly syntax checking."
  '((emacs "27.1")
    (seq   "2.24"))
  :url "https://github.com/flycheck/flycheck"
  :commit "97e9638d8d2325096b930d24dc438301f505800c"
  :revdesc "97e9638d8d23"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
