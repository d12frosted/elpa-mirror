;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-expose-emphasis-markers" "20250320.705"
  "Automatically show hidden org emphasis markers."
  '((emacs "29.1"))
  :url "https://github.com/lorniu/org-expose-emphasis-markers"
  :commit "de6ec31399e8d634d5320c780b8ae481b07d01f2"
  :revdesc "de6ec31399e8"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
