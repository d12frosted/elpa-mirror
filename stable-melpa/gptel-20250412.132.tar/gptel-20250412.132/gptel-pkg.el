;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250412.132"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "243bd07ce833f571af344ca1e8ed16d6a1dde4bb"
  :revdesc "243bd07ce833"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
