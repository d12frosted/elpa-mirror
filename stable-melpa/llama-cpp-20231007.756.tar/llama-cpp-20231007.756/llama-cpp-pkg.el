(define-package "llama-cpp" "20231007.756" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "0573c85443488cbf90478d57a5e55751be535e27" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
