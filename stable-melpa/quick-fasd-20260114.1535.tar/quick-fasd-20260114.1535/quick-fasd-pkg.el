;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20260114.1535"
  "Integration for the command-line tool `fasd'."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "7f295404a9d5f93450c071e6226d8f52e574ab8b"
  :revdesc "7f295404a9d5"
  :keywords '("convenience"))
