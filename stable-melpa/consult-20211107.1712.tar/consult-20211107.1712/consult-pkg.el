(define-package "consult" "20211107.1712" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7708dc760ac2fc80219b226be27e11bbc9adf5b4" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
