;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260120.2332"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "eb9e38fc7cee4c45dc74dfd094ade9f6b81cfaaa"
  :revdesc "eb9e38fc7cee"
  :keywords '("outlines"))
