;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20260519.1023"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "65998eca7a909e5560e6ce05eec33ee6a18e0d0c"
  :revdesc "65998eca7a90"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
