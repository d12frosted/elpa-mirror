;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20251223.1207"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "6dbae195ddcd4f8408f9cc680024850909be4c39"
  :revdesc "6dbae195ddcd"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
