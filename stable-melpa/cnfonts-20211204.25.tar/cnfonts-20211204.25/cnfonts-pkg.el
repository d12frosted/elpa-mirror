(define-package "cnfonts" "20211204.25" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "dfa75df98625cbd9d563d833d4238c94cca5d22c" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
