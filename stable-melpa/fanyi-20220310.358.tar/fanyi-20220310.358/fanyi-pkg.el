(define-package "fanyi" "20220310.358" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "b01cb24209d223ae0e7281c279daab87800ee7f4" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
