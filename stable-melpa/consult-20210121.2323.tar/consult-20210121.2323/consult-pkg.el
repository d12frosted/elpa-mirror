(define-package "consult" "20210121.2323" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "aa47b1a6e95ee9b6429f21e41f25244b970a83ad" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
