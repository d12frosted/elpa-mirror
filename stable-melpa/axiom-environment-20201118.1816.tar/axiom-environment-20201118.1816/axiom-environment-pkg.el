(define-package "axiom-environment" "20201118.1816" "An environment for using Axiom/OpenAxiom/FriCAS"
  '((emacs "24.2"))
  :commit "9ef86ca16098050da4362f5aadaea64b0a093fc1" :keywords
  ("axiom" "openaxiom" "fricas")
  :authors
  (("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  ("Paul Onions" . "paul.onions@acm.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
