(define-package "racket-mode" "20220807.1605" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "ba6bba3efe1a63fdcfd131c4ddea76681a349660" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
