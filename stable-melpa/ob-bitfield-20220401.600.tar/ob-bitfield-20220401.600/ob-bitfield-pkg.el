;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-bitfield" "20220401.600"
  "Babel Functions for bitfield."
  '((emacs "24.4"))
  :url "https://github.com/gsingh93/ob-bitfield"
  :commit "abe3d8fe49dc53c4663def689ceb5c0433638652"
  :revdesc "abe3d8fe49dc")
