(define-package "slime" "20240629.1527" "Superior Lisp Interaction Mode for Emacs"
  '((emacs "24.3")
    (macrostep "0.9"))
  :commit "5f02c6ce1a1ab44d60110cef0e118407c921da28" :keywords
  '("languages" "lisp" "slime")
  :url "https://github.com/slime/slime")
;; Local Variables:
;; no-byte-compile: t
;; End:
