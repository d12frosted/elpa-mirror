(define-package "fanyi" "20210922.1909" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "b91ef80cd3418afc3839ef463566936eb4ef2341" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
