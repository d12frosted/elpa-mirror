;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "20260608.248"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "47d882912e2b90c816b50a8900f77c5e966f8d77"
  :revdesc "47d882912e2b")
