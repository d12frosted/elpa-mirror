;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "picpocket" "20250830.1131"
  "Image viewer."
  '((emacs "25.1"))
  :url "https://github.com/johanclaesson/picpocket"
  :commit "9fafd11824fd81cd884c20ff7243d6a58cea8ff2"
  :revdesc "9fafd11824fd"
  :keywords '("multimedia")
  :authors '(("Johan Claesson" . "johanwclaesson@gmail.com"))
  :maintainers '(("Johan Claesson" . "johanwclaesson@gmail.com")))
