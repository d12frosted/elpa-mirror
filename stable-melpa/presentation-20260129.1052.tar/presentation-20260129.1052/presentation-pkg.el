;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "presentation" "20260129.1052"
  "Display large character for presentation."
  '((emacs  "24.4")
    (compat "30"))
  :url "https://github.com/zonuexe/emacs-presentation-mode"
  :commit "9d12c83f56b24461682cfb921151985d27b77fe4"
  :revdesc "9d12c83f56b2"
  :keywords '("environment" "faces" "frames")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
