(define-package "ekg" "20240901.1906" "A system for recording and linking information"
  '((triples "0.4.0")
    (emacs "28.1")
    (llm "0.17.0"))
  :commit "12d2524b4b7fdbb2e60b564456c463e594919ca2" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
