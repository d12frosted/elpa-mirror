(define-package "dirvish" "20211230.255" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "8e58ce451ba28e3b7653bf11505863f4fbad8fa2" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
