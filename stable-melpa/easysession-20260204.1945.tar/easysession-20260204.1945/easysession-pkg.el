;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260204.1945"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "6a75579c7fdc8d953bb88be1229a75443c31e274"
  :revdesc "6a75579c7fdc"
  :keywords '("convenience"))
