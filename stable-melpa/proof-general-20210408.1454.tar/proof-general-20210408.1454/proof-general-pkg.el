(define-package "proof-general" "20210408.1454" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.5"))
  :commit "d0acb626eba17023c55b002921870d60e48527a5" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
