;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg-marginalia" "20261001.1611"
  "Show Epkg information in completion annotations."
  '((emacs      "28.1")
    (compat     "31.1")
    (cond-let   "1.1")
    (epkg       "4.2")
    (marginalia "2.13"))
  :url "https://github.com/emacscollective/epkg-marginalia"
  :commit "7992fc1fb6647703c7da269f0aa4f5dc3508d3f8"
  :revdesc "7992fc1fb664"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev")))
