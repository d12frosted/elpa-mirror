;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260814.1139"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.11"))
  :url "https://github.com/emacs-rime/rimel"
  :commit "7b2d967f4230ececbf7b34477c9db71ca5b0104d"
  :revdesc "7b2d967f4230"
  :keywords '("convenience" "chinese" "input-method" "rime"))
