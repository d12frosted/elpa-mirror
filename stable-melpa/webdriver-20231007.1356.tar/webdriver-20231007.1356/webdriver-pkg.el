(define-package "webdriver" "20231007.1356" "WebDriver local end implementation"
  '((emacs "27.1"))
  :commit "5d350eb8dbba32d20f193c135427e2cd8c0c24e5" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/mauroaranda/emacs-webdriver")
;; Local Variables:
;; no-byte-compile: t
;; End:
