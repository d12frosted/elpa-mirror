;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20260114.1500"
  "An Org-social client for Emacs."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "8330a5e9752c78af4311c9ef6a44010915c454f6"
  :revdesc "8330a5e9752c"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
