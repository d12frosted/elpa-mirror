;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260120.2200"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "49fc17d131dd3021094df7a4afe8c66be5d259f6"
  :revdesc "49fc17d131dd")
