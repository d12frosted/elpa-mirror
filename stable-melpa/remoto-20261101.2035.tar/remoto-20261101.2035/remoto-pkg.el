;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261101.2035"
  "Browse GitHub and Codeberg repos without cloning."
  '((emacs "29.1")
    (ghub  "5.3.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "8d831b4f2e893accb79c880600faed84e5c5f8d8"
  :revdesc "8d831b4f2e89"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
