(define-package "symbols-outline" "20230823.958" "Display symbols (functions, variables, etc) in outline view"
  '((emacs "27.1"))
  :commit "c51cb6527ce4fb869817f940284b256e4b8c35d2" :authors
  '(("Shihao Liu"))
  :maintainers
  '(("Shihao Liu"))
  :maintainer
  '("Shihao Liu")
  :keywords
  '("outlines")
  :url "https://github.com/liushihao456/symbols-outline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
