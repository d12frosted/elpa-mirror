;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260123.2110"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "fa2b14d4031cfe8da82778d1a7c01a06fa03032b"
  :revdesc "fa2b14d4031c"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
