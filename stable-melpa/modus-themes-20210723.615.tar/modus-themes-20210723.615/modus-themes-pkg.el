(define-package "modus-themes" "20210723.615" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "823b1904cff452b019ebf27a69828556f36fc8a6" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
