;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260423.438"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "2df40737c6cc9ccd8b69462a6f2f6a045c2d7684"
  :revdesc "2df40737c6cc"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
