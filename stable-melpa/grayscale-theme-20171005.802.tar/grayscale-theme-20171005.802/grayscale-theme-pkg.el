;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grayscale-theme" "20171005.802"
  "A simple grayscale theme."
  ()
  :url "https://github.com/belak/emacs-grayscale-theme"
  :commit "917d63c0effc8459502a41e0cad5822d2b200499"
  :revdesc "917d63c0effc"
  :keywords '("lisp")
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
