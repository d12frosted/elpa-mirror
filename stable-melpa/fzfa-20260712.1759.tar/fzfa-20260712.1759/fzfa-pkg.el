;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260712.1759"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.1"))
  :url "https://github.com/jojojames/fzfa"
  :commit "12d3c110f72e0d26bc298201d64b69e98f5765be"
  :revdesc "12d3c110f72e"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
