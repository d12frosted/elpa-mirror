(define-package "vc-auto-commit" "20170107.1333" "Auto-committing feature for your repository" 'nil :commit "446f664f4ec835532f4f18ba18b5fb731f6030aa" :authors
  (("Sylvain Rousseau <thisirs at gmail dot com>"))
  :maintainer
  ("Sylvain Rousseau <thisirs at gmail dot com>")
  :keywords
  ("vc" "convenience")
  :url "http://github.com/thisirs/vc-auto-commit.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
