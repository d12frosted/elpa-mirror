(define-package "citre" "20221022.1434" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "b4f0cb195528057afaa091ea77355633d68c2b3a" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
