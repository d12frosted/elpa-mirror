(define-package "good-scroll" "20210123.159" "Good pixel line scrolling"
  '((emacs "24.4"))
  :commit "5d0479e5a0fe1589fe549f2fc1966f80a4718a4f" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
