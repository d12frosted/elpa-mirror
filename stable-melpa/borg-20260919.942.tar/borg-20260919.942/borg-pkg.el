;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260919.942"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "153fd27001c8b0cfaa447debffa5e7144b82e7b7"
  :revdesc "153fd27001c8"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
