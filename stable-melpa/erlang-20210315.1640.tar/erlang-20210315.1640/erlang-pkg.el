(define-package "erlang" "20210315.1640" "Erlang major mode"
  '((emacs "24.1"))
  :commit "892593c53bd782bc02e2ae7622169f012330498d" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
