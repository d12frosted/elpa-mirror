;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20241208.620"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "0a5af92d60efc8bb5727b692f87a0ec042bbf5e8"
  :revdesc "0a5af92d60ef"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
