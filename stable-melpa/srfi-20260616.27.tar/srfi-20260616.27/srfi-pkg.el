;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260616.27"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "62032141c839eaf7671373a5d6959980726750c4"
  :revdesc "62032141c839"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
