;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabnine" "20241112.1549"
  "An unofficial TabNine package with TabNine Chat supported."
  '((emacs        "27.1")
    (dash         "2.16.0")
    (s            "1.12.0")
    (editorconfig "0.9.1")
    (language-id  "0.5.1")
    (transient    "0.4.0"))
  :url "https://github.com/shuxiao9058/tabnine"
  :commit "59108b8669165c6209e848b28fe1a76936e0fe93"
  :revdesc "59108b866916"
  :keywords '("convenience")
  :authors '(("Aaron Ji" . "shuxiao9058@gmail.com")
             ("Tommy Xiang" . "tommyx058@gmail.com")
             ("John Gong" . "gjtzone@hotmail.com"))
  :maintainers '(("Aaron Ji" . "shuxiao9058@gmail.com")
                 ("Tommy Xiang" . "tommyx058@gmail.com")
                 ("John Gong" . "gjtzone@hotmail.com")))
