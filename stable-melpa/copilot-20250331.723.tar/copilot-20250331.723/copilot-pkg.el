;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20250331.723"
  "An unofficial Copilot plugin."
  '((emacs        "27.2")
    (editorconfig "0.8.2")
    (jsonrpc      "1.0.14")
    (f            "0.20.0"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "ec2d61ecc679dea951590fbfe297cceee19ce341"
  :revdesc "ec2d61ecc679"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Rakotomandimby Mihamina" . "mihamina.rakotomandimby@rktmb.org")))
