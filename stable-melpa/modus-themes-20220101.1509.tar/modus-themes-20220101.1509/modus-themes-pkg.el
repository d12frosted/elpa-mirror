(define-package "modus-themes" "20220101.1509" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "58ceaa80c685a24bd712bf975d9f1c112eb39c13" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
