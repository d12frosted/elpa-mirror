;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251106.1917"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "71272bc6421ebc3aa1cf3b32097a9d46966f6933"
  :revdesc "71272bc6421e"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
