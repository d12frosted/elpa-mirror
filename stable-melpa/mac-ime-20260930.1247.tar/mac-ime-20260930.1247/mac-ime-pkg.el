;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mac-ime" "20260930.1247"
  "Seamless macOS IME integration without any IME patches."
  '((emacs "27.1"))
  :url "https://github.com/ma0001/mac-ime"
  :commit "d86c2afb44821f8320e761280554b91539077d2c"
  :revdesc "d86c2afb4482"
  :keywords '("i18n" "convenience"))
