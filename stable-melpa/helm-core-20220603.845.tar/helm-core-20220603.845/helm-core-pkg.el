(define-package "helm-core" "20220603.845" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "190d60c25debe7e2fe26578b8fb8204352db1ae9" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
