(define-package "helm-core" "20220603.845" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "8ec4ce04b54c5f681161ac9f566dc4e9a7429802" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
