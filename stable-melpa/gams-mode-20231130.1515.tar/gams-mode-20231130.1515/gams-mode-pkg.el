(define-package "gams-mode" "20231130.1515" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "150377ed33ab5b25e3ab7ed15dbdda3387b6df9a" :authors
  '(("Shiro Takeda"))
  :maintainers
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
