(define-package "weblorg" "20210130.2347" "Static Site Generator for org-mode"
  '((templatel "0.1.4")
    (emacs "26.1"))
  :commit "3c860c7b52ccee2f8d0b96e8a9e65e9695eb6e0a" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
