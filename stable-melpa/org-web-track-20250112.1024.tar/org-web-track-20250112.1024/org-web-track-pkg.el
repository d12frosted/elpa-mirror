;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-web-track" "20250112.1024"
  "Web data tracking framework in Org Mode."
  '((emacs   "29.1")
    (request "0.3.0")
    (enlive  "0.0.1")
    (gnuplot "0.8.1"))
  :url "https://github.com/p-snow/org-web-track"
  :commit "0c328de425f6e00d86700a47e946933776af3f82"
  :revdesc "0c328de425f6"
  :keywords '("org" "agenda" "web" "hypermedia")
  :authors '(("p-snow" . "public@p-snow.org"))
  :maintainers '(("p-snow" . "public@p-snow.org")))
