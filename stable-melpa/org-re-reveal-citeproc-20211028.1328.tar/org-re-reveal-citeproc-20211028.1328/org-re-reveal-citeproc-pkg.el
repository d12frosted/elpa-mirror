(define-package "org-re-reveal-citeproc" "20211028.1328" "Citations and bibliography for org-re-reveal"
  '((emacs "25.1")
    (org "9.5")
    (citeproc "0.9")
    (org-re-reveal "3.0.0"))
  :commit "faa9ea387917b20bd1499ad90199ff3d417c00c2" :authors
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "bibliography")
  :url "https://gitlab.com/oer/org-re-reveal-citeproc")
;; Local Variables:
;; no-byte-compile: t
;; End:
