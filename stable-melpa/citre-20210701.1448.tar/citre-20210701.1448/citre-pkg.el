(define-package "citre" "20210701.1448" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "01ed8539e8068f1e1ff658ab4b1931d9b7907809" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
