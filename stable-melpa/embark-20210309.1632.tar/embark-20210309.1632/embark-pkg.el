(define-package "embark" "20210309.1632" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d267c11b2d6f510d9e173400ec90e18a471fc7b3" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
