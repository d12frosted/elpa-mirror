(define-package "affe" "20211006.1629" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.10"))
  :commit "ccf486a902cd573d79b43ca61a4ba855fd056567" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
