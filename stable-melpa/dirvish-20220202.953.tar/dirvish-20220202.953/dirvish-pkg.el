(define-package "dirvish" "20220202.953" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "140262fb28529093eb3661f9c9a72bab98c7e4da" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
