;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-invox" "20260329.1955"
  "Invoice management for contractors using Org mode."
  '((emacs "27.1")
    (org   "9.0"))
  :url "https://github.com/a-manumohan/org-invox"
  :commit "458d3757ff0b52b44e163997ee131a62709eacd0"
  :revdesc "458d3757ff0b"
  :keywords '("outlines" "tools")
  :authors '(("Manu Mohan" . "me@manumohan.net"))
  :maintainers '(("Manu Mohan" . "me@manumohan.net")))
