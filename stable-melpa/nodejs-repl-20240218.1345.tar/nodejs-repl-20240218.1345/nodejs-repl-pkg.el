(define-package "nodejs-repl" "20240218.1345" "Run Node.js REPL" 'nil :commit "ec8f726a0939395a15d32d16d17a8ce77ab1e4f7" :authors
  '(("Takeshi Arabiki"))
  :maintainers
  '(("Takeshi Arabiki"))
  :maintainer
  '("Takeshi Arabiki"))
;; Local Variables:
;; no-byte-compile: t
;; End:
