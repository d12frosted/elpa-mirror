;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260321.2219"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "d1e3ba080afce39272c615b6398291b281e59045"
  :revdesc "d1e3ba080afc"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
