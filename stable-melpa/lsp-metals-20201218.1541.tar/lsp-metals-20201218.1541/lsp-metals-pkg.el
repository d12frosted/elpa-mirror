(define-package "lsp-metals" "20201218.1541" "Scala Client settings"
  '((emacs "26.1")
    (lsp-mode "7.0")
    (lsp-treemacs "0.2")
    (dap-mode "0.3")
    (dash "2.14.1")
    (dash-functional "2.14.1")
    (f "0.20.0")
    (ht "2.0")
    (treemacs "2.5"))
  :commit "1ef794cbaa112519403378fe344a21d766549055" :keywords
  ("languages" "extensions")
  :authors
  (("Ross A. Baker" . "ross@rossabaker.com")
   ("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  ("Ross A. Baker" . "ross@rossabaker.com")
  :url "https://github.com/emacs-lsp/lsp-metals")
;; Local Variables:
;; no-byte-compile: t
;; End:
