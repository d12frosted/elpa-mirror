;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260104.149"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "0675377baa2e7111014fb9db3ef10b2ef12e7ff8"
  :revdesc "0675377baa2e"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
