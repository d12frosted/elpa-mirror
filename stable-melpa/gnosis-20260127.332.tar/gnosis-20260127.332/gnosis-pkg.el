;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260127.332"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "2e31a974975af9ce1a68fb5cc1fa1662754c0f3e"
  :revdesc "2e31a974975a"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
