;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260207.1633"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "d6a2a5940d72e4e9c75d71ed40060662516eba40"
  :revdesc "d6a2a5940d72"
  :keywords '("convenience"))
