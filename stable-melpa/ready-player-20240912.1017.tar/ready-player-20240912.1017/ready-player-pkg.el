(define-package "ready-player" "20240912.1017" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "9105d36eee68c033815a07160e643a608b941387" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
