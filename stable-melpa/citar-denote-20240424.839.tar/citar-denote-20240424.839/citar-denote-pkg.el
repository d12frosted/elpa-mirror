(define-package "citar-denote" "20240424.839" "Minor mode integrating Citar and Denote"
  '((emacs "28.1")
    (citar "1.4")
    (denote "2.0")
    (dash "2.19.1"))
  :commit "35c3a2f108190f93f60aae480d244aab5920d83c" :authors
  '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers
  '(("Peter Prevos" . "peter@prevos.net"))
  :maintainer
  '("Peter Prevos" . "peter@prevos.net")
  :url "https://github.com/pprevos/citar-denote")
;; Local Variables:
;; no-byte-compile: t
;; End:
