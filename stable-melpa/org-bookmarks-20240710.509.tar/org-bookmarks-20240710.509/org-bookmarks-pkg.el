(define-package "org-bookmarks" "20240710.509" "Manage bookmarks in Org mode"
  '((emacs "29.1"))
  :commit "fc397f81f9d0b58a7d81ee7ee3a200cf5462a4cc" :keywords
  '("outline" "matching" "hypermedia" "org")
  :url "https://repo.or.cz/org-bookmarks.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
