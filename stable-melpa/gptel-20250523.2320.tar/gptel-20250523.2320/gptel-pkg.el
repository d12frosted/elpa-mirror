;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250523.2320"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "09c6a6b6adaf411256439aac4477db914e590f98"
  :revdesc "09c6a6b6adaf"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
