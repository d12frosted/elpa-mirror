(define-package "tempel-collection" "20230418.830" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "3a070e4fbe52772d276153e9e0042ba4dfc8c818" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
