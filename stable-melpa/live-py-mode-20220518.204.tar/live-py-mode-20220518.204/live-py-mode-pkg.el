(define-package "live-py-mode" "20220518.204" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "5ca8e4ad7124efeaa0cfc26e982e056a8cebba72" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
