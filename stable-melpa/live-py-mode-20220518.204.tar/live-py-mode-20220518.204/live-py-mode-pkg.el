(define-package "live-py-mode" "20220518.204" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "a97e83f5dc9101359beadc0bc409a9bda79e91eb" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
