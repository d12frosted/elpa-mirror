(define-package "live-py-mode" "20220518.204" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "c648b4d7f15d4f15b8e8cab5a01f4e068b774a06" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
