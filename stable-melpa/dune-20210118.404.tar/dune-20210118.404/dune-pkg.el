(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "0b95281acc0785b6ee532e8045bcaf28a703ccd3" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
