(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "30890ba923166dafddcf09021a9a82010cb59128" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
