(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "231ad58e4d8c72258e15c27301065ac32898f71f" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
