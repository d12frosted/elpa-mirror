(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "4f8367ff74f3572b54434e6da3998f6244527b87" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
