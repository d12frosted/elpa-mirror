(define-package "dune" "20210118.404" "Integration with the dune build system" 'nil :commit "f0a31ae77f5f161e52a37548e6754987fd9b44ae" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
