(define-package "ddskk" "20230318.2309" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "e0259efcb4ed31640ec335628dec0c0a3cb0f509" :authors
  '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp"))
  :maintainer
  '("SKK Development Team")
  :keywords
  '("japanese" "mule" "input method")
  :url "https://github.com/skk-dev/ddskk")
;; Local Variables:
;; no-byte-compile: t
;; End:
