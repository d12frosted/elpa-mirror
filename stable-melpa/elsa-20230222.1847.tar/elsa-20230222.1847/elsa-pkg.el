(define-package "elsa" "20230222.1847" "Emacs Lisp Static Analyser"
  '((emacs "25.1")
    (trinary "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3")
    (lsp-mode "0"))
  :commit "9b169851cfd47dfe1668991291cf1cbaba4a41ed" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
