;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spanish-holidays" "20251231.1119"
  "Spain holidays for calendar."
  ()
  :url "https://gitlab.com/gnuhack/spanish-holidays"
  :commit "783e75d933d2b1eb4eecd549afb4a8b6f97e67a9"
  :revdesc "783e75d933d2"
  :keywords '("calendar")
  :authors '(("Carlos Pajuelo" . "carlospajuelo_@hotmail.com"))
  :maintainers '(("Carlos Pajuelo" . "carlospajuelo_@hotmail.com")))
