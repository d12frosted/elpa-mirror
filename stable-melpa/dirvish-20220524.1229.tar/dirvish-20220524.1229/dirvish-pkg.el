(define-package "dirvish" "20220524.1229" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "806a60a9d5b507a46fd2c07fd0db988674b1e4f1" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
