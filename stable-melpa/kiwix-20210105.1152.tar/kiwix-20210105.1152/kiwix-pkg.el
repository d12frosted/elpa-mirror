(define-package "kiwix" "20210105.1152" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (request "0.3.0"))
  :commit "6c64f7b0776d346561bc887042a6cc5053b723f1" :authors
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
