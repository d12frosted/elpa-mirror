(define-package "gptel" "20231208.221" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "3e361323d5b2b6dd54a24667edeeb9480bab197f" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
