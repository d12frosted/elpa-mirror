(define-package "pipewire" "20220725.1858" "PipeWire user interface"
  '((emacs "28.1"))
  :commit "115a8a89a3a0c6a89ebe22df0ef0928a701cb1f0" :authors
  '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainer
  '("Milan Zamazal" . "pdm@zamazal.org")
  :keywords
  '("multimedia")
  :url "https://git.zamazal.org/pdm/pipewire-0")
;; Local Variables:
;; no-byte-compile: t
;; End:
