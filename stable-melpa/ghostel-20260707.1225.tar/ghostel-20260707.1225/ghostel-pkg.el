;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260707.1225"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "4acafb728ee235505c30ae29292b4f0db6fa3387"
  :revdesc "4acafb728ee2"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
