(define-package "modus-themes" "20211001.1643" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "392ebb115b07f8052d512ec847619387d109edd6" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
