;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20251011.1314"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "8de3e5abcdf99f76a339a386855d6c2ddd38b178"
  :revdesc "8de3e5abcdf9"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
