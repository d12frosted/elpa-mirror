;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insta-pocket" "20250921.2201"
  "Instapaper client."
  '((emacs   "29.1")
    (oauth   "1.11")
    (tablist "1.0"))
  :url "https://github.com/thanhvg/emacs-insta-pocket"
  :commit "33a735c3c5060b5e322aa4eb4e24665c01c3ba4b"
  :revdesc "33a735c3c506"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
