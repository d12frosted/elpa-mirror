(define-package "oer-reveal" "20211207.956" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "ef77f31fb99babe7918356897ecc18651a9d30bc" :authors
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
