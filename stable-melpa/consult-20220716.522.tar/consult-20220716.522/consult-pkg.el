(define-package "consult" "20220716.522" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "0fa264c2efc17e564af406d60dbe77ae2fb6f010" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
