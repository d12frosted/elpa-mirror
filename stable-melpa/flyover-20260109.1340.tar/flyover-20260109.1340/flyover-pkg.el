;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20260109.1340"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "e20abc64fe6a256f6fcda3c9599d7cbc526f7d28"
  :revdesc "e20abc64fe6a"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
