(define-package "compile-multi" "20230822.1933" "A multi target interface to compile"
  '((emacs "28.0"))
  :commit "28595f31c4c9b37c2e342cd7bb4b7f1553d18943" :authors
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("mohsin kaleem" . "mohkale@kisara.moe")
  :keywords
  '("tools" "compile" "build")
  :url "https://github.com/mohkale/compile-multi")
;; Local Variables:
;; no-byte-compile: t
;; End:
