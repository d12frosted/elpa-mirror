(define-package "chronometrist-key-values" "20210602.2249" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "a09317e0257d47be358a4d670d58d2affb30999e" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
