;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ts-node" "20260122.2349"
  "Org-Babel support for TypeScript via ts-node."
  '((emacs "25.1")
    (org   "8.0"))
  :url "https://github.com/tmythicator/ob-ts-node"
  :commit "a41a7cd5be425b2a41248bd17be38ff3dd68d4a1"
  :revdesc "a41a7cd5be42"
  :keywords '("languages" "tools"))
