(define-package "lispy" "20220906.1833" "vi-like Paredit"
  '((emacs "24.3")
    (ace-window "0.9.0")
    (iedit "0.9.9")
    (swiper "0.13.4")
    (hydra "0.14.0")
    (zoutline "0.2.0"))
  :commit "711281e7011807e1e2a0610d227c6ac1ada5dedb" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/abo-abo/lispy")
;; Local Variables:
;; no-byte-compile: t
;; End:
