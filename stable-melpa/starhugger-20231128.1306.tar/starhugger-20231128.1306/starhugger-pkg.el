(define-package "starhugger" "20231128.1306" "Hugging Face/AI-powered text & code completion client"
  '((emacs "28.2")
    (compat "29.1.4.0")
    (dash "2.18.0")
    (s "1.13.1")
    (spinner "1.7.4"))
  :commit "7583b914fbc3621be53bbfd7c29b98d0fc452cde" :keywords
  '("completion" "convenience" "languages")
  :url "https://gitlab.com/daanturo/starhugger.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
