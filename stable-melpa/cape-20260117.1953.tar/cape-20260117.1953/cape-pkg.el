;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20260117.1953"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "dfb3bca62238aab8f64ec319a77a125df86a0eee"
  :revdesc "dfb3bca62238"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
