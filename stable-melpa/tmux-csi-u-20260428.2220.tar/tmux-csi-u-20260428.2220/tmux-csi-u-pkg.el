;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tmux-csi-u" "20260428.2220"
  "Tmux CSI-u decoder."
  '((emacs "27.1"))
  :url "https://github.com/lajarre/tmux-csi-u.el"
  :commit "38e95db84ad02ad440e4fc0b18896e1c621e5f5d"
  :revdesc "38e95db84ad0"
  :keywords '("terminals" "tools")
  :authors '(("lajarre" . "1884912+lajarre@users.noreply.github.com"))
  :maintainers '(("lajarre" . "1884912+lajarre@users.noreply.github.com")))
