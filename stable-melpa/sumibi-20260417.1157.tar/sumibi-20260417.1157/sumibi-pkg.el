;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20260417.1157"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (markdown-mode  "2.0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "366cf1a2a9f408cc34c1412a4b06dfe01f46d97f"
  :revdesc "366cf1a2a9f4"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
