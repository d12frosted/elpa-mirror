(define-package "circe" "20210526.919" "Client for IRC in Emacs"
  '((emacs "24.4")
    (cl-lib "0.5"))
  :commit "4778675e0c3bde1c028085b7d96693fe033d2c72" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :keywords
  '("irc" "chat" "comm")
  :url "https://github.com/jorgenschaefer/circe")
;; Local Variables:
;; no-byte-compile: t
;; End:
