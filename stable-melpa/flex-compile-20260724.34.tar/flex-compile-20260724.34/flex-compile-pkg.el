;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-compile" "20260724.34"
  "Run, evaluate and compile across many languages."
  '((emacs         "26.1")
    (dash          "2.17.0")
    (buffer-manage "1.2.1"))
  :url "https://github.com/plandes/flex-compile"
  :commit "c9f6b00d6da0192a52f17a0b9c2a8753d7bbced8"
  :revdesc "c9f6b00d6da0"
  :keywords '("compilation" "integration" "processes"))
