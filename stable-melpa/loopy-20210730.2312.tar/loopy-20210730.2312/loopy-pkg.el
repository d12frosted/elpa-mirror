(define-package "loopy" "20210730.2312" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "3e6361d647cdbed22ff862bf6a7d53f1299eb726" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
