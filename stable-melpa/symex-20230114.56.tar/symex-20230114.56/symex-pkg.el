(define-package "symex" "20230114.56" "An evil way to edit Lisp symbolic expressions as trees"
  '((emacs "25.1")
    (tsc "0.15.2")
    (tree-sitter "0.15.2")
    (lispy "0.26.0")
    (paredit "24")
    (evil-cleverparens "20170718.413")
    (evil "1.2.14")
    (evil-surround "1.0.4")
    (hydra "0.15.0")
    (seq "2.22"))
  :commit "055ff24cb0aab6a0ea929dd681a734997d5e0f95" :authors
  '(("Siddhartha Kasivajhula" . "sid@countvajhula.com"))
  :maintainer
  '("Siddhartha Kasivajhula" . "sid@countvajhula.com")
  :keywords
  '("lisp" "convenience" "languages")
  :url "https://github.com/countvajhula/symex.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
