;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aqi" "20230530.1204"
  "Air quality data from the World Air Quality Index."
  '((emacs     "25.1")
    (request   "0.3")
    (let-alist "0.0"))
  :url "https://github.com/zzkt/aqi"
  :commit "cbff3c6ce691a3a1d2f5636384e29d43f0e1d236"
  :revdesc "cbff3c6ce691"
  :keywords '("air quality" "aqi" "pollution" "weather" "data")
  :authors '(("nik gaffney" . "nik@fo.am"))
  :maintainers '(("nik gaffney" . "nik@fo.am")))
