;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260221.116"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "f2b74e37c4293e7d29ce287225a723aed46aa07d"
  :revdesc "f2b74e37c429"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
