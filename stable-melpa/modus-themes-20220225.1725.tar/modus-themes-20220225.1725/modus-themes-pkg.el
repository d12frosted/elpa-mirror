(define-package "modus-themes" "20220225.1725" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "b0beb8affbb0e28b1c1916d536a2b14a302bb7f6" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
