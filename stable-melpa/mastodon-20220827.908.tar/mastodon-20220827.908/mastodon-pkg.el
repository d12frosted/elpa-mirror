(define-package "mastodon" "20220827.908" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0"))
  :commit "61f742f40df98bd79337bb755ff1c30db3da8f02" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
