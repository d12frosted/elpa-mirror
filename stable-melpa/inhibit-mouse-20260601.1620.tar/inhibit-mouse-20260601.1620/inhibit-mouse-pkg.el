;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "20260601.1620"
  "Deactivate mouse input (alternative to disable-mouse)."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "1e8cc1d95fd2bedc9b46acf6be29c119fdb7276d"
  :revdesc "1e8cc1d95fd2"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
