;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent-scope" "20251230.1126"
  "Highlight indentation by scope."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope"
  :commit "0515a8372c90dbac15dd806e2576e32cae801ae1"
  :revdesc "0515a8372c90"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
