;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nael" "20260114.1519"
  "Major mode for Lean."
  '((emacs "29.1"))
  :url "https://codeberg.org/mekeor/nael"
  :commit "1a462a61a3599c436c9284a23cae4ff8815a84da"
  :revdesc "1a462a61a359"
  :keywords '("languages")
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
