;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20251218.426"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs  "27.2")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "e179f00b065188b5c50af7e307fc262a6efea7ff"
  :revdesc "e179f00b0651"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
