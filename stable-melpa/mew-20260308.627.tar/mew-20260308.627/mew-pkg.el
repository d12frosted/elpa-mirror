;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260308.627"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "d1a4f1f63b9c1c3f9cf7bee726ee5be5015ad361"
  :revdesc "d1a4f1f63b9c")
