(define-package "gap-mode" "20220815.2355" "Major mode for editing files in the GAP programing language." 'nil :commit "afa70e8e396ce15f348612f09146650795fe58f8" :authors
  '(("Michael Smith" . "smith@pell.anu.edu.au")
    ("Gary Zablackis")
    ("Goetz Pfeiffer")
    ("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainer
  '("Ivan Andrus" . "darthandrus@gmail.com")
  :keywords
  '("gap")
  :url "https://gitlab.com/gvol/gap-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
