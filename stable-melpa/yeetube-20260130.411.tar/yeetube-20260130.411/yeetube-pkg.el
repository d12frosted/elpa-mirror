;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260130.411"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs  "27.2")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "2eddda6d93050b25a00c739b8ad72b58ce8602cc"
  :revdesc "2eddda6d9305"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
