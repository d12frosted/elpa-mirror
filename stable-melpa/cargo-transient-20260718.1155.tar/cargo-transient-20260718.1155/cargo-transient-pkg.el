;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cargo-transient" "20260718.1155"
  "A transient UI for Cargo, Rust's package manager."
  '((emacs "28.1"))
  :url "https://github.com/peterstuart/cargo-transient"
  :commit "a1fac6ce76d32317fd9f6bcdcc86fca46460c709"
  :revdesc "a1fac6ce76d3"
  :authors '(("Peter Stuart" . "peter@peterstuart.org"))
  :maintainers '(("Peter Stuart" . "peter@peterstuart.org")))
