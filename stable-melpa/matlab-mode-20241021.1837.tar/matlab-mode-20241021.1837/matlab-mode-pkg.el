;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241021.1837"
  "Major mode for MATLAB(R) dot-m files."
  ()
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "894b9b20b96e60766866f9baebc3c6865a23a504"
  :revdesc "894b9b20b96e"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")))
