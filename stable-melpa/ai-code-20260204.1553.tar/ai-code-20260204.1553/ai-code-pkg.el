;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260204.1553"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "a1a10c3cf80862fb96cba9a617cfc96e0bccc2d2"
  :revdesc "a1a10c3cf808"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
