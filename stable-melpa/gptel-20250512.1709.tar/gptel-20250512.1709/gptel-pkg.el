;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250512.1709"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "7e22a97127c9fa8649c714334f15c6d978fe0616"
  :revdesc "7e22a97127c9"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
