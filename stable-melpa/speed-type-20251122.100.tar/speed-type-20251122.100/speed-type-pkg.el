;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251122.100"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "1f39fced80ad8753ed9ec1c1e3e8e3f7b4d07e9c"
  :revdesc "1f39fced80ad"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
