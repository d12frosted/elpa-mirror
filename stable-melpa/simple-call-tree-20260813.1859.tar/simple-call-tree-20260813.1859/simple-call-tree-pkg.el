;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-call-tree" "20260813.1859"
  "Analyze source code based on font-lock text-properties."
  '((emacs    "24.3")
    (anaphora "1.0.0"))
  :url "http://www.emacswiki.org/emacs/download/simple-call-tree.el"
  :commit "a3c3c07461a06f41875fddad96daaf2e533ca147"
  :revdesc "a3c3c07461a0"
  :keywords '("programming")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
