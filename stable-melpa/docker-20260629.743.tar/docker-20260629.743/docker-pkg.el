;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "20260629.743"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "5c1fc2b6dcd2ec4238694603a746d041f8961793"
  :revdesc "5c1fc2b6dcd2"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
