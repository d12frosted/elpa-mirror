(define-package "ekg" "20230930.1823" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.1.1"))
  :commit "74d43f53cf9b11c40cf97de26d871a39c2ec596f" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
