(define-package "live-py-mode" "20230930.2134" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "c598eb91f6af553a7104ebe827fbbf16a84e3e10" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainers
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
