;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apiwrap" "20180602.2231"
  "Api-wrapping macros."
  '((emacs "25"))
  :url "https://github.com/vermiculus/apiwrap.el"
  :commit "e4c9c57d6620a788ec8a715ff1bb50542edea3a6"
  :revdesc "e4c9c57d6620"
  :keywords '("tools" "maint" "convenience")
  :authors '(("Sean Allred" . "code@seanallred.com"))
  :maintainers '(("Sean Allred" . "code@seanallred.com")))
