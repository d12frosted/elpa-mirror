;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250909.2219"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "d923f3ce82a31a1db8d482a3e9e6038a83aa6813"
  :revdesc "d923f3ce82a3"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
