(define-package "docsim" "20230621.2010" "Search and compare notes with a local search engine"
  '((emacs "24.4")
    (org "8.0"))
  :commit "819f1a92abfb177254b3b08b9d723baabbc6dc3c" :authors
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainers
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainer
  '("Harry R. Schwartz" . "hello@harryrschwartz.com")
  :url "https://github.com/hrs/docsim.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
