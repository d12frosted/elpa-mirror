;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250507.1515"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "8ad2ec9ece03b07ec2c95824f6991d170698bd7a"
  :revdesc "8ad2ec9ece03"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
