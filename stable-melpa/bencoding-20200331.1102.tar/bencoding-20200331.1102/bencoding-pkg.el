;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bencoding" "20200331.1102"
  "Bencoding decoding and encoding."
  '((emacs "25.1"))
  :url "https://github.com/xuchunyang/bencoding.el"
  :commit "409836f2cf4883826600de42519ee9cffeb48a11"
  :revdesc "409836f2cf48"
  :keywords '("tools"))
