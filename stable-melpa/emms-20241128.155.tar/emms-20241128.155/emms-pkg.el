;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "20241128.155"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://git.savannah.gnu.org/git/emms.git"
  :commit "a84ebc7984725a64177a70656a7860b1bf3f4d93"
  :revdesc "a84ebc798472"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
