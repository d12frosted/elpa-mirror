(define-package "hl-prog-extra" "20220130.630" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "ea22ef36137118ee084efb701b150c8d7ce1a98c" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
