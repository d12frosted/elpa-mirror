;;; hl-prog-extra-preset-python-mode.el --- Python preset -*- lexical-binding: t -*-
;; URL: https://gitlab.com/ideasman42/emacs-hl-prog-extra
;; Version: 0.1
;; Package-Requires: ((emacs "26.2"))

;;; Commentary:
;; Preset for Python.

;;; Code:

;;;###autoload
(defun hl-prog-extra-preset-python-mode (&rest args)
  "Presets for `python-mode' with optional ARGS keyword arguments.
:no-string-escape
  Don't use escape strings."
  (let
    ( ;; Keywords.
      (no-string-escape nil)

      (result (list)))

    ;; Parse keywords.
    (while args
      (let ((arg-current (pop args)))
        (cond
          ((symbolp arg-current)
            (unless args
              (error "Keyword argument %S has no value!" arg-current))
            (let ((v (pop args)))
              (pcase arg-current
                (:no-string-escape
                  (cond
                    ((null v)) ;; Be noisy.
                    ((eq v t))
                    (t
                      (error ":quiet expected a boolean")))
                  (setq no-string-escape v))
                (_ (error "Unknown argument %S" arg-current)))))
          (t
            (error
              "Arguments must be property pairs, found %S = %S"
              (type-of arg-current)
              arg-current)))))

    (unless no-string-escape
      (push
        (list
          (concat
            ;; Back-slash.
            "\\\\"
            ;; Group.
            "\\("
            ;; "\n" and similar single escape characters.
            "[abnrtfv\"\\\\]\\|"
            ;; "\x" number.
            "x[0-9]+\\|"
            ;; "\u" unicode.
            "u[0-9a-fA-F]+\\|"
            ;; "\x000".
            "[0-9]+\\|"
            ;; "\N{NAMED UNICODE}".
            "N{[A-Z\\s\\-]+}"
            ;; End group.
            "\\)")
          0 'string 'escape-glyph)
        result))

    result))

(provide 'hl-prog-extra-preset-python-mode)
;;; hl-prog-extra-preset-python-mode.el ends here
