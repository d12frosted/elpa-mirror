;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck" "20260211.1236"
  "On-the-fly syntax checking."
  '((emacs "27.1")
    (seq   "2.24"))
  :url "https://www.flycheck.org"
  :commit "5b8fd8f652f0c9ed7c88eda9e919e4e87cd74541"
  :revdesc "5b8fd8f652f0"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
                 ("fmdkdd" . "fmdkdd@gmail.com")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
