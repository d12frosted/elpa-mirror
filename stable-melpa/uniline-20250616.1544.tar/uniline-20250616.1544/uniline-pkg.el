;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250616.1544"
  "Add ╭─╴UNICODE╶─╮ based ╭─╴diagrams╶─╮ to ╭▶╴text files╶●╮."
  '((emacs "29.1"))
  :url "https://github.com/tbanel/uniline"
  :commit "3d934029aa917fb8e888496ae3742aa47c9e8ed0"
  :revdesc "3d934029aa91"
  :keywords '("convenience" "text"))
