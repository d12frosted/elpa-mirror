;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verdict" "20260503.612"
  "Generic test runner with treemacs results UI."
  '((emacs    "29.1")
    (treemacs "3.0")
    (dash     "2.0"))
  :url "https://github.com/tjarvstrand/verdict.el"
  :commit "2118ca8cfd915c9b3df7c3a70a9fc70257df6aaf"
  :revdesc "2118ca8cfd91"
  :keywords '("tools" "processes")
  :authors '(("Thomas Järvstrand" . "https://github.com/tjarvstrand"))
  :maintainers '(("Thomas Järvstrand" . "https://github.com/tjarvstrand")))
