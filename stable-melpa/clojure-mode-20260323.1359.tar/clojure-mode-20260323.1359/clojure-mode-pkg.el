;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260323.1359"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "dd25ae76c52e22da577239d8238d506197062d72"
  :revdesc "dd25ae76c52e"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
