;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "20260610.749"
  "Minimal and elegant modeline."
  '((emacs "29.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "5e2666b5536434288cd180cefe5fbe95f6196895"
  :revdesc "5e2666b55364"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
