(define-package "phpunit" "20180812.1324" "Launch PHP unit tests using phpunit"
  '((s "1.12.0")
    (f "0.19.0")
    (pkg-info "0.6")
    (cl-lib "0.5")
    (emacs "24.3"))
  :commit "4212307bbcfd8accd2abfa7e4ab55a6751a0b11b" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
    ("Eric Hansen" . "hansen.c.eric@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("tools" "php" "tests" "phpunit")
  :url "https://github.com/nlamirault/phpunit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
