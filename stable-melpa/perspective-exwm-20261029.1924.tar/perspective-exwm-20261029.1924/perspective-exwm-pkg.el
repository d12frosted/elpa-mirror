;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective-exwm" "20261029.1924"
  "Better integration for perspective.el and EXWM."
  '((emacs       "27.1")
    (burly       "0.2-pre")
    (exwm        "0.26")
    (perspective "2.17"))
  :url "https://github.com/SqrtMinusOne/perspective-exwm.el"
  :commit "8fb40cebe4fb6d58d3aaec9c7a00eff61759899a"
  :revdesc "8fb40cebe4fb"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
