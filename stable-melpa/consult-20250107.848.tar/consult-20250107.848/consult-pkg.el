;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250107.848"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "c88ae989e4b6d4dbc46e9c2562947be41c2957d8"
  :revdesc "c88ae989e4b6"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
