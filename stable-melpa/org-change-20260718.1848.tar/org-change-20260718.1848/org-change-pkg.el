;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "20260718.1848"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "08be1de3226010908d18ae31f0a2378cef0dfc05"
  :revdesc "08be1de32260"
  :keywords '("wp" "convenience"))
