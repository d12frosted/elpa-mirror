(define-package "spdx" "20231110.101" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "db107d1e9a716ffe531a0f73e7044bb8046d34c4" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
