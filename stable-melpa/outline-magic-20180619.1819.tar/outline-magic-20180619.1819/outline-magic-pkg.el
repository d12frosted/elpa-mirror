;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-magic" "20180619.1819"
  "Outline mode extensions for Emacs."
  ()
  :url "https://github.com/tj64/outline-magic"
  :commit "2a5f07417b696cf7541d435c43bafcc64817636b"
  :revdesc "2a5f07417b69"
  :keywords '("outlines")
  :authors '(("Carsten Dominik" . "dominik@science.uva.nl"))
  :maintainers '(("Thorsten Jolitz" . "tjolitzATgmailDOTcom")))
