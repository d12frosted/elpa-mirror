;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linkin-org" "20251014.1231"
  "A workflow with fast, reliable links."
  '((emacs "30.1")
    (s     "1.30.0")
    (dash  "2.20.0"))
  :url "https://github.com/Judafa/linkin-org"
  :commit "ba7a556321d960da232a7ebb1593e058ef6f1d77"
  :revdesc "ba7a556321d9"
  :authors '(("Julien Dallot" . "judafa@protonmail.com"))
  :maintainers '(("Julien Dallot" . "judafa@protonmail.com")))
