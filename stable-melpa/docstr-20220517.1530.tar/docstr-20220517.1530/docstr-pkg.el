(define-package "docstr" "20220517.1530" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "fe8ccd75e93c6e21398751a6d33c7ee445e4c039" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
