;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moom" "20250817.1347"
  "Commands to control frame position and size."
  '((emacs "25.1"))
  :url "https://github.com/takaxp/Moom"
  :commit "2683e801d3c7be537ddf8b6af5154c0b86fafeb6"
  :revdesc "2683e801d3c7"
  :keywords '("frames" "faces" "convenience")
  :authors '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg"))
  :maintainers '(("Takaaki ISHIKAWA" . "takaxpatieeedotorg")))
