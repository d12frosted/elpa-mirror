(define-package "loopy" "20210710.228" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "f3f81affc88e6cb9efbc5440b26e081cffddd311" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
