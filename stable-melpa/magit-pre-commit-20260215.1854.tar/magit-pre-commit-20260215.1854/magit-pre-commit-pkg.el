;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-pre-commit" "20260215.1854"
  "Magit integration for pre-commit."
  '((emacs "29.1")
    (magit "3.0.0")
    (yaml  "0.5.0"))
  :url "https://github.com/DamianB-BitFlipper/magit-pre-commit.el"
  :commit "406d14e364b11a3a7f5240b2bcb904a3c9c10cc9"
  :revdesc "406d14e364b1"
  :keywords '("git" "tools" "vc"))
