;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easy-kill" "20260112.1130"
  "Kill & mark things easily."
  '((emacs  "25")
    (cl-lib "0.5"))
  :url "https://github.com/leoliu/easy-kill"
  :commit "3401ab7427e34f8913374311bf75d342462fc9b0"
  :revdesc "3401ab7427e3"
  :keywords '("killing" "convenience")
  :authors '(("Leo Liu" . "sdl.web@gmail.com"))
  :maintainers '(("Leo Liu" . "sdl.web@gmail.com")))
