(define-package "dirvish" "20220107.1158" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "1dacbd008e7fcef8245789f333c1fd76798ff49f" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
