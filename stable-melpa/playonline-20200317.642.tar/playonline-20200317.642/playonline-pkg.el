(define-package "playonline" "20200317.642" "Play code with online playgrounds"
  '((emacs "24.4")
    (dash "2.1")
    (request "0.2"))
  :commit "7f20037688d92e6af67384d99abf7f9671326cd1" :authors
  '(("Gong Qijian" . "gongqijian@gmail.com"))
  :maintainer
  '("Gong Qijian" . "gongqijian@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/twlz0ne/playonline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
