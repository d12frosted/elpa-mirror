;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260507.1831"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "9a78738922f89c9eab9693219130a175ccbc1fc0"
  :revdesc "9a78738922f8"
  :keywords '("languages" "lisp" "slime"))
