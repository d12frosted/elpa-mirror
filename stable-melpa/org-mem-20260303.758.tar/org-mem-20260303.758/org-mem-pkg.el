;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260303.758"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "3a90968f693dfa80d6c8b2b3f3482de63a390f7d"
  :revdesc "3a90968f693d"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
