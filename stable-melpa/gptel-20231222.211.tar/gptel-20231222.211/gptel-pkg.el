(define-package "gptel" "20231222.211" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "ce75072f9dde5e89f41c26d374bb0b0891c691c7" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
