;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20260522.1348"
  "Nucleo-backed completion style."
  '((emacs "27.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "b3b85807e95d9d144300c1a4d0facfcf20b8dc06"
  :revdesc "b3b85807e95d"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
