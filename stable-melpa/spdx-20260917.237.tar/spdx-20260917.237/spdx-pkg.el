;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260917.237"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "95eeba8ce68732c2c6de9f7f2804c017f1c729d2"
  :revdesc "95eeba8ce687"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
