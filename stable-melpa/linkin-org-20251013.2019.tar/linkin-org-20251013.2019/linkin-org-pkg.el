;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linkin-org" "20251013.2019"
  "A workflow with fast, reliable links."
  '((emacs "30.1")
    (s     "1.30.0")
    (dash  "2.20.0"))
  :url "https://github.com/Judafa/linkin-org"
  :commit "0f6a0124b11df7329dd9a22c22e8e2931cd3abaa"
  :revdesc "0f6a0124b11d"
  :authors '(("Julien Dallot" . "judafa@protonmail.com"))
  :maintainers '(("Julien Dallot" . "judafa@protonmail.com")))
