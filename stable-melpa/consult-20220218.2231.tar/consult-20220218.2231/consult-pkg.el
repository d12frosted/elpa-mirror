(define-package "consult" "20220218.2231" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "1d5571f57977067fa9e4ac3794b0cb0fbca5dc6a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
