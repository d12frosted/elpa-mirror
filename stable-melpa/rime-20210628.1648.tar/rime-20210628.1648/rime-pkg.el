(define-package "rime" "20210628.1648" "Rime input method"
  '((emacs "26.3")
    (dash "2.17.0")
    (cl-lib "0.6.1")
    (popup "0.5.3")
    (posframe "0.1.0"))
  :commit "b93e761209211f8a6de1bb4b8f1d36651564a8d9" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "input-method")
  :url "https://www.github.com/DogLooksGood/emacs-rime")
;; Local Variables:
;; no-byte-compile: t
;; End:
