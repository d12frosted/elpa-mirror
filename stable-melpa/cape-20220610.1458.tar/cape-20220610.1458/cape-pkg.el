(define-package "cape" "20220610.1458" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "86a1df6cbacd0e05b801208f83be5ca6c1cc8cec" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
