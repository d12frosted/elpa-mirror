(define-package "cape" "20220610.1458" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "a2b5ed033ccf44d42c3062142d17c63ee5acf3f7" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
