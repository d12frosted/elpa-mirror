;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-vterm" "20261026.1441"
  "A mode for Julia REPL using vterm."
  '((emacs "26.1")
    (vterm "0.0.1"))
  :url "https://github.com/shg/julia-vterm.el"
  :commit "88cf140a69a4f7dd92ae0f50636783b03d228a1b"
  :revdesc "88cf140a69a4"
  :keywords '("languages" "julia"))
