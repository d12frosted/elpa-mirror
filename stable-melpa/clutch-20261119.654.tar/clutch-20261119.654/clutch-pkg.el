;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261119.654"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "708f40723d9e0538e7ecb2e3fa3ccb47a1437125"
  :revdesc "708f40723d9e"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
