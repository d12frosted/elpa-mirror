;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ext" "20251118.1329"
  "SystemVerilog Extensions."
  '((emacs           "29.1")
    (verilog-mode    "2024.3.1.121933719")
    (verilog-ts-mode "0.5.0")
    (lsp-mode        "8.0.0")
    (ag              "0.48")
    (ripgrep         "0.4.0")
    (hydra           "0.15.0")
    (apheleia        "3.1")
    (yasnippet       "0.14.0")
    (flycheck        "32")
    (async           "1.9.7"))
  :url "https://github.com/gmlarumbe/verilog-ext"
  :commit "bbf99e16866cdc35bddf04a2e68e7d8664343506"
  :revdesc "bbf99e16866c"
  :keywords '("verilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
