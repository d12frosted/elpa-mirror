(define-package "workgroups2" "20220306.1328" "save&load multiple named workspaces (or \"workgroups\")"
  '((emacs "25.1"))
  :commit "b4fb2287cd646c2d165f8ebe80c5fcbbce861856" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
