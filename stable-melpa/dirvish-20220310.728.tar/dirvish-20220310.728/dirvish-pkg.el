(define-package "dirvish" "20220310.728" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "359044345e7eace1bd467d29a68f2e41a8442541" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
