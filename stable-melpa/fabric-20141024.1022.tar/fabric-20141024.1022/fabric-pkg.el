(define-package "fabric" "20141024.1022" "Launch Fabric using Emacs" 'nil :commit "004934318f63d8cf955022f87b2c33eb97ada280" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@chmouel.com")
  :keywords
  '("python" "fabric")
  :url "https://github.com/nlamirault/fabric.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
