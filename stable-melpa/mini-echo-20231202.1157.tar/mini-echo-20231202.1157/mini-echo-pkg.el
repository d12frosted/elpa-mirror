(define-package "mini-echo" "20231202.1157" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "3e0d2a4b45bad543ad91264e9b136bb4ba760fac" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
