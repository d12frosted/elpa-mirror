(define-package "soccer" "20230327.1433" "Fixtures, results, table etc for soccer"
  '((emacs "26.1")
    (dash "2.19.1"))
  :commit "d126be0d4650bb7e1887d796a4fba4cee97a7c05" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("games" "soccer" "football")
  :url "https://github.com/md-arif-shaikh/soccer")
;; Local Variables:
;; no-byte-compile: t
;; End:
