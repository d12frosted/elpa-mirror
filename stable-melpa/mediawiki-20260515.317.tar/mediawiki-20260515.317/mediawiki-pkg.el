;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20260515.317"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "7ba10e435599b6d91f50c8aa0768dd0597dcacda"
  :revdesc "7ba10e435599"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
