;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mime" "20251127.340"
  "Org html export for text/html MIME emails."
  '((emacs "27.1"))
  :url "http://github.com/org-mime/org-mime"
  :commit "56583e6e9504bb3638d0aff4c80db424282818f5"
  :revdesc "56583e6e9504"
  :keywords '("mime" "mail" "email" "html")
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
