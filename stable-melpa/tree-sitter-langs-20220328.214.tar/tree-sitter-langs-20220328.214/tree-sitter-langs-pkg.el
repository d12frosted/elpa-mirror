(define-package "tree-sitter-langs" "20220328.214" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.15.0"))
  :commit "f8e4790c5f5a35d189f889ab3f82580e37bf64b4" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/tree-sitter-langs")
;; Local Variables:
;; no-byte-compile: t
;; End:
