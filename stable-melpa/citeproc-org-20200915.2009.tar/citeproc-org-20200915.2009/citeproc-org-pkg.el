(define-package "citeproc-org" "20200915.2009" "Render org-mode references in CSL styles"
  '((emacs "25.1")
    (dash "2.12.0")
    (org "9")
    (f "0.18.0")
    (citeproc "0.1")
    (org-ref "1.1.1"))
  :commit "20cd7e817420a3f6e7b82faea901a3c67c6d4d9f" :authors
  '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainer
  '("András Simonyi" . "andras.simonyi@gmail.com")
  :keywords
  '("org-ref" "org-mode" "cite" "bib")
  :url "https://github.com/andras-simonyi/citeproc-org")
;; Local Variables:
;; no-byte-compile: t
;; End:
