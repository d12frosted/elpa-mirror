;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "citeproc-org" "20200915.2009"
  "Render org-mode references in CSL styles."
  '((emacs    "25.1")
    (dash     "2.12.0")
    (org      "9")
    (f        "0.18.0")
    (citeproc "0.1")
    (org-ref  "1.1.1"))
  :url "https://github.com/andras-simonyi/citeproc-org"
  :commit "22a759c4f0ec80075014dcc594baa4d1b470d995"
  :revdesc "22a759c4f0ec"
  :keywords '("org-ref" "org-mode" "cite" "bib")
  :authors '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainers '(("András Simonyi" . "andras.simonyi@gmail.com")))
