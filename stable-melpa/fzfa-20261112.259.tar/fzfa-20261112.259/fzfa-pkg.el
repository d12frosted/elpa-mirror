;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20261112.259"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "3.4"))
  :url "https://github.com/jojojames/fzfa"
  :commit "96329f700b72228b0bc5c3d41b2200833499e575"
  :revdesc "96329f700b72"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
