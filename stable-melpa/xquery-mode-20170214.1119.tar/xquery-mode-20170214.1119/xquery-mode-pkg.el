;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xquery-mode" "20170214.1119"
  "A simple mode for editing xquery programs."
  '((cl-lib "0.5"))
  :url "https://github.com/xquery-mode/xquery-mode"
  :commit "19e6f9553ce05380843582b879712de00679e4ab"
  :revdesc "19e6f9553ce0")
