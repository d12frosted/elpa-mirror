;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "igist" "20260507.1739"
  "List, create, update and delete GitHub gists."
  '((emacs     "29.1")
    (ghub      "4.2.2")
    (transient "0.8.5"))
  :url "https://github.com/KarimAziev/igist"
  :commit "976be239b4bd10128c45789052f54ad58aa1b357"
  :revdesc "976be239b4bd"
  :keywords '("tools")
  :authors '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers '(("Karim Aziiev" . "karim.aziiev@gmail.com")))
