(define-package "deno-ts-mode" "20230823.1554" "Major mode for Deno"
  '((emacs "29.1"))
  :commit "5b5b41ae05c7ed90825a7a93ed1d1fb90962225b" :authors
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainers
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainer
  '("Graham Marlow" . "info@mgmarlow.com")
  :keywords
  '("languages")
  :url "https://git.sr.ht/~mgmarlow/deno-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
