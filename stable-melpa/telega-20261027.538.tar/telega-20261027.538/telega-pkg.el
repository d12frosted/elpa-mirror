;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20261027.538"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "a97206b891cafe4f4c052e8d14c48869f4ada5b3"
  :revdesc "a97206b891ca"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
