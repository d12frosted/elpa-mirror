;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinboard-popular" "20180511.1726"
  "Displays links from the pinboard.in popular page."
  '((loop "1.4"))
  :url "https://github.com/asimpson/pinboard-popular"
  :commit "c0bc76cd35f8ecf34723c64a702b82eec2751318"
  :revdesc "c0bc76cd35f8"
  :keywords '("pinboard"))
