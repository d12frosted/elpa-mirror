(define-package "evil-pinyin" "20200927.849" "Evil search Chinese characters by pinyin"
  '((emacs "25")
    (names "0.5")
    (evil "1"))
  :commit "3e9e501ded86f88e01a4edec5d526ab0fab879d7" :keywords
  ("extensions")
  :url "https://github.com/laishulu/evil-pinyin")
;; Local Variables:
;; no-byte-compile: t
;; End:
