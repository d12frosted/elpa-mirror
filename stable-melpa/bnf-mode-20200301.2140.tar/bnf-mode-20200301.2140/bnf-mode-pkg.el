(define-package "bnf-mode" "20200301.2140" "Major mode for editing BNF grammars."
  '((cl-lib "0.5")
    (emacs "24.3"))
  :commit "4a7aff6a3a691826ea4add9f519c854b9611d780" :authors
  '(("Serghei Iakovlev" . "egrep@protonmail.ch"))
  :maintainer
  '("Serghei Iakovlev" . "egrep@protonmail.ch")
  :keywords
  '("languages")
  :url "https://github.com/sergeyklay/bnf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
