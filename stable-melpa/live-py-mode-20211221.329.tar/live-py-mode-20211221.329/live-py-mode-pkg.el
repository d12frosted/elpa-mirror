(define-package "live-py-mode" "20211221.329" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "ad1adb0b90c4241b759d660511541278a5463c9c" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
