;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-signature-eldoc-talkative" "20240626.815"
  "Make Eglot make ElDoc echo docs."
  '((emacs   "29.1")
    (eglot   "1.16")
    (eldoc   "1.14.0")
    (jsonrpc "1.0.23"))
  :url "https://codeberg.org/mekeor/eglot-signature-eldoc-talkative"
  :commit "34cc207265f26f13142f5c62276e0ba18e1d55e4"
  :revdesc "34cc207265f2"
  :keywords '("convenience" "documentation" "eglot" "eldoc" "languages" "lsp")
  :authors '(("João Távora" . "joaotavora@gmail.com")
             ("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
