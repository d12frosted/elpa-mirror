(define-package "python-x" "20220602.2108" "python.el extras for interactive evaluation"
  '((python "0.24")
    (folding "0")
    (cl-lib "0.5"))
  :commit "fef5162af9dfc1225339098ae00e053a2e16b799" :authors
  '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainer
  '("Yuri D'Elia" . "wavexx@thregr.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
