(define-package "dirvish" "20220307.507" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "28d3ed5962bc6cf7b8bef32e72f4de561212d3fa" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
