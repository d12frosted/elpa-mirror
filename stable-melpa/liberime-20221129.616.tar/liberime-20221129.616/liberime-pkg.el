(define-package "liberime" "20221129.616" "Rime elisp binding"
  '((emacs "25.1"))
  :commit "bbd032c6aa438c240deaf5cefab51c8591029098" :authors
  '(("A.I."))
  :maintainer
  '("A.I.")
  :keywords
  '("convenience" "chinese" "input-method" "rime")
  :url "https://github.com/merrickluo/liberime")
;; Local Variables:
;; no-byte-compile: t
;; End:
