(define-package "helm-company" "20231107.2328" "Helm interface for company-mode"
  '((helm "1.5.9")
    (company "0.10.0"))
  :commit "fbcea041c2ee7c95b9e18cc1ef31f32b4dc4bd3e" :authors
  '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers
  '(("Daniel Ralston" . "Sodel-the-Vociferous@users.noreply.github.com"))
  :maintainer
  '("Daniel Ralston" . "Sodel-the-Vociferous@users.noreply.github.com")
  :url "https://github.com/Sodel-the-Vociferous/helm-company")
;; Local Variables:
;; no-byte-compile: t
;; End:
