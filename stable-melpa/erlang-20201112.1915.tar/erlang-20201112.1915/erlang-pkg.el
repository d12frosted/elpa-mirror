(define-package "erlang" "20201112.1915" "Erlang major mode"
  '((emacs "24.1"))
  :commit "b2e43bfe8f6bcbd3c49986d9ce8f2872eb17bbd4")
;; Local Variables:
;; no-byte-compile: t
;; End:
