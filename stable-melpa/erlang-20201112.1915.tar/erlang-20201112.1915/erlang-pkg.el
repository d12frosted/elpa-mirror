(define-package "erlang" "20201112.1915" "Erlang major mode"
  '((emacs "24.1"))
  :commit "f6fd911229fbbaf9c8da100b713cdaffc564e0ec")
;; Local Variables:
;; no-byte-compile: t
;; End:
