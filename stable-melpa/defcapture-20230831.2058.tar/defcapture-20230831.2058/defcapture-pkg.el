(define-package "defcapture" "20230831.2058" "A convenience macro for the Doct DSL"
  '((emacs "25.1")
    (doct "3.0"))
  :commit "03438a59c69f31f090dfe1a06045d07e667319cd" :authors
  '(("Abraham Aguilar" . "a.aguilar@ciencias.unam.mx"))
  :maintainers
  '(("Abraham Aguilar" . "a.aguilar@ciencias.unam.mx"))
  :maintainer
  '("Abraham Aguilar" . "a.aguilar@ciencias.unam.mx")
  :keywords
  '("convenience" "org")
  :url "https://github.com/aggu4/defcapture")
;; Local Variables:
;; no-byte-compile: t
;; End:
