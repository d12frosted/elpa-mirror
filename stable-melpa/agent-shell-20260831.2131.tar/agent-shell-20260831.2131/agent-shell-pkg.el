;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260831.2131"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.2")
    (acp         "0.14.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "fa5cf61ec52e679e054c2901f0af12187aa8fc4c"
  :revdesc "fa5cf61ec52e")
