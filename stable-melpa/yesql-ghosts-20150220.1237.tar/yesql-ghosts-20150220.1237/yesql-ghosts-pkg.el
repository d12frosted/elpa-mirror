;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yesql-ghosts" "20150220.1237"
  "Display ghostly yesql defqueries inline."
  '((s     "1.9.0")
    (dash  "2.10.0")
    (cider "0.8.0"))
  :url "https://github.com/magnars/yesql-ghosts"
  :commit "416198cdc4f316b0912af5e413410937b9b8432b"
  :revdesc "416198cdc4f3"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
