;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261019.1551"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "9bbb94b88830e8de592700cbd661c2c479afdbfd"
  :revdesc "9bbb94b88830"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
