(define-package "modus-themes" "20220309.1647" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "1458edbbbb28c666a1061f1f67fa5fc33fcb41fb" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
