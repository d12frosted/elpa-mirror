;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20261126.1131"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "b23eac58cb45beb69601e0bd46799e5374580185"
  :revdesc "b23eac58cb45"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
