(define-package "geiser-gambit" "20220207.2239" "Gambit's implementation of the geiser protocols"
  '((emacs "26.1")
    (geiser "0.18"))
  :commit "42249ec44d02ca3c45a6b76072f108ae32af2a8f" :authors
  '(("Daniel Leslie"))
  :maintainer
  '("Daniel Leslie, Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "gambit" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/gambit")
;; Local Variables:
;; no-byte-compile: t
;; End:
