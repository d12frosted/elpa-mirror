;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260405.549"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "18c16ed3114d779fdd3c0e4ec817005f9c5e53f2"
  :revdesc "18c16ed3114d"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
