;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20260503.415"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "7da84b7744a7a58f59ca3babc7acd1dab3a229d6"
  :revdesc "7da84b7744a7"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
