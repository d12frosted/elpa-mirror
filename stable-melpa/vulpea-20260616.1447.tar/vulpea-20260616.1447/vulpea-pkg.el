;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260616.1447"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "531a5b9ac60b8c4427ef5babcebe7d3de228c835"
  :revdesc "531a5b9ac60b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
