(define-package "dtache" "20220320.1338" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "b762fe472f1a47d0f1808620d4468aee645654ee" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
