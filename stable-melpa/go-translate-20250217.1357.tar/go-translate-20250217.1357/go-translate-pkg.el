;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250217.1357"
  "Translation framework, configurable and scalable."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/go-translate"
  :commit "01db11bf9a243710c15d4b74ea981ba8a4e0e98a"
  :revdesc "01db11bf9a24"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
