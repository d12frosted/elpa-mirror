(define-package "consult-recoll" "20221014.2002" "Recoll queries using consult"
  '((emacs "26.1")
    (consult "0.19"))
  :commit "8d506e2d01f46fc6b0a0825efb90b062ad6fe3d4" :authors
  '(("Jose A Ortega Ruiz" . "jao@gnu.org"))
  :maintainers
  '(("Jose A Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("docs" "convenience")
  :url "https://codeberg.org/jao/consult-recoll")
;; Local Variables:
;; no-byte-compile: t
;; End:
