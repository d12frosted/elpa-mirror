(define-package "go-translate" "20240507.834" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "d4add7da550f48049939416ba1615f03ec3a04d9" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
