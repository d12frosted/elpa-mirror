;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "earthfile-mode" "20230809.2250"
  "Major mode for editing Earthly file."
  '((emacs "26"))
  :url "https://github.com/earthly/earthly-mode"
  :commit "3029e5ab06171ca5947041e95053561e10e5ba41"
  :revdesc "3029e5ab0617"
  :authors '(("Thanabodee Charoenpiriyakij" . "wingyminus@gmail.com"))
  :maintainers '(("Thanabodee Charoenpiriyakij" . "wingyminus@gmail.com")))
