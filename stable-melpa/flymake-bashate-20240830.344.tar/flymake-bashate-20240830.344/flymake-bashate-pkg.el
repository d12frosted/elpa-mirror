(define-package "flymake-bashate" "20240830.344" "A Flymake backend for bashate (a Bash style checker)"
  '((flymake-quickdef "1.0.0")
    (emacs "26.1"))
  :commit "2339c28cd2aa6e63c5aeb5e904dd5b0060dc264e" :keywords
  '("tools")
  :url "https://github.com/jamescherti/flymake-bashate.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
