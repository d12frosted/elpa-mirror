(define-package "consult" "20211009.1756" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "166e3b03c3de4f88bbfdeef7f52efac27642e2d3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
