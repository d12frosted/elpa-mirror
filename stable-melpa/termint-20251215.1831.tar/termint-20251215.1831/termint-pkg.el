;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "20251215.1831"
  "Run REPLs in a terminal backend."
  '((emacs "29.1"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "3170eae7a73039e351c50a548de7e45e6b3ff222"
  :revdesc "3170eae7a730"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
