;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "x509-mode" "20261013.657"
  "View certificates, CRLs and keys using OpenSSL."
  '((emacs  "25.1")
    (compat "29.1"))
  :url "https://github.com/jobbflykt/x509-mode"
  :commit "376ee4f294bc4b9013bb781804471b2c6fda5a18"
  :revdesc "376ee4f294bc"
  :authors '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainers '(("Fredrik Axelsson" . "f.axelsson@gmail.com")))
