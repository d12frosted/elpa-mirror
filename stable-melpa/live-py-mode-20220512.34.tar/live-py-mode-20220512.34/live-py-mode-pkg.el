(define-package "live-py-mode" "20220512.34" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "9dee1cd6e885f2e5d3763b7527c50dc6c85ca5f3" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
