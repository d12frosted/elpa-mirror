;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stem-reading-mode" "20220522.1053"
  "Highlight word stems for speed-reading."
  '((emacs "25.1"))
  :url "https://gitlab.com/wavexx/stem-reading-mode.el"
  :commit "6efc9962e3a19a452c7ab9636cf1e2566a51bd38"
  :revdesc "6efc9962e3a1"
  :keywords '("convenience" "wp")
  :authors '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers '(("Yuri D'Elia" . "wavexx@thregr.org")))
