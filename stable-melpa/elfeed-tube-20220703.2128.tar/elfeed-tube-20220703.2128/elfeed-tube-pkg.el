(define-package "elfeed-tube" "20220703.2128" "YouTube integration for Elfeed"
  '((emacs "27.1")
    (elfeed "3.4.1")
    (aio "1.0"))
  :commit "16fbfef51273e863cdfdd9b7725ac7347ade3fa5" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("news" "hypermedia" "convenience")
  :url "https://github.com/karthink/elfeed-tube")
;; Local Variables:
;; no-byte-compile: t
;; End:
