(define-package "consult" "20210412.1151" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "737751dc334482b7f9dbe077f6e046f28d8d47b5" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
