(define-package "w3m" "20211009.252" "an Emacs interface to w3m" 'nil :commit "c088fe627f12597726dfc2062454e2e7bd99798a" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
