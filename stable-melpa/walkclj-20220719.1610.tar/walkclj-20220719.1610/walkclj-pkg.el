;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "walkclj" "20220719.1610"
  "Manipulate Clojure parse trees."
  '((emacs    "25")
    (parseclj "0.1.0")
    (treepy   "0.1.0")
    (a        "1.0.0"))
  :url "https://github.com/plexus/walkclj"
  :commit "875ee7a350f5141f425c4b5350a630e1ee1795e8"
  :revdesc "875ee7a350f5"
  :keywords '("languages"))
