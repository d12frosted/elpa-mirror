;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250408.807"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "654244eb78e07a3de566fc6fe5e78d589d8b5148"
  :revdesc "654244eb78e0"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
