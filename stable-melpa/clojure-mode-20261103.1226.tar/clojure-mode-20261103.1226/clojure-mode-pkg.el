;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20261103.1226"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "d864d6f26c8acc576fc7fc343299c240909f27ac"
  :revdesc "d864d6f26c8a"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :authors '(("Jeffrey Chu" . "jochu0@gmail.com")
             ("Lennart Staflin" . "lenst@lysator.liu.se")
             ("Phil Hagelberg" . "technomancy@gmail.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev")
             ("Artur Malabarba" . "bruce.connor.am@gmail.com")
             ("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
