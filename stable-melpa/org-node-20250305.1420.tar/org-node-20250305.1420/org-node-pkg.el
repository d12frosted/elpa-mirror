;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250305.1420"
  "Fast org-roam replacement."
  '((emacs         "28.1")
    (compat        "30")
    (llama         "0.5.0")
    (el-job        "1.0.5")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "adde970658e4274afd658fb6842a57ebbbba8482"
  :revdesc "adde970658e4"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
