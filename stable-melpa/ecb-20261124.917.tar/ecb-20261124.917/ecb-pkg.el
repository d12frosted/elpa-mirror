;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ecb" "20261124.917"
  "A code browser for Emacs."
  ()
  :url "https://github.com/ecb-org/ecb"
  :commit "1157c59893e37e119857679d18d9965a2feeb9ff"
  :revdesc "1157c59893e3"
  :keywords '("browser" "code" "programming" "tools")
  :authors '(("Jesper Nordenberg" . "mayhem@home.se")
             ("Klaus Berndl" . "klaus.berndl@sdm.de")
             ("Kevin A. Burton" . "burton@openprivacy.org"))
  :maintainers '(("Klaus Berndl" . "klaus.berndl@sdm.de")))
