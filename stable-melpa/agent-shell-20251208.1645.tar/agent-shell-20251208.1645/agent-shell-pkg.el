;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251208.1645"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c1578d831638328236e39845963be2ae03bf8bcf"
  :revdesc "c1578d831638")
