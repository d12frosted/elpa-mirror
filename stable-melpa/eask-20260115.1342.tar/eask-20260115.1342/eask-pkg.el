;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20260115.1342"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "d5e665fcc63af17bf2177ecc371dda1f999788aa"
  :revdesc "d5e665fcc63a"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
