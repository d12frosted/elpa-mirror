;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dslide" "20241227.158"
  "Domain Specific sLIDEs. Programmable Presentation."
  '((emacs "29.2"))
  :url "https://github.com/positron-solutions/dslide"
  :commit "7dedccc7ecc85180235e775ca55c44e17b8371f5"
  :revdesc "7dedccc7ecc8"
  :keywords '("convenience" "org-mode" "presentation" "narrowing")
  :authors '(("Positron" . "contact@positron.solutions"))
  :maintainers '(("Positron" . "contact@positron.solutions")))
