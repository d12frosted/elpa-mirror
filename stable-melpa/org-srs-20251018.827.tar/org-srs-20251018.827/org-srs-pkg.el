;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251018.827"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "2777e521ea5833bfa6da6c6f1fdebf9b7dd2cedb"
  :revdesc "2777e521ea58"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
