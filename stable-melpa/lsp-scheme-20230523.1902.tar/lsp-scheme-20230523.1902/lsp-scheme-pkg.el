(define-package "lsp-scheme" "20230523.1902" "Scheme support for lsp-mode"
  '((emacs "26.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "1c334a9bcfbebc347da65c441fdedbeef4000bcd" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainers
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
