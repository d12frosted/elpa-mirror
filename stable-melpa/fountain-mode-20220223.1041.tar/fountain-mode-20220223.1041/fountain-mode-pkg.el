(define-package "fountain-mode" "20220223.1041" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "63f29cbd66b9a3d2ff11ff99b36d4d095638d084" :authors
  '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainer
  '("Paul W. Rankin" . "pwr@bydasein.com")
  :keywords
  '("wp" "text")
  :url "https://github.com/rnkn/fountain-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
