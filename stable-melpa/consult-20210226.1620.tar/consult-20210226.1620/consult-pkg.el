(define-package "consult" "20210226.1620" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b65202247309d508c4062196284679661a7790fc" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
