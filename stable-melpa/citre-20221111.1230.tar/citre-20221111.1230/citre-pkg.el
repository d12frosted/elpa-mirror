(define-package "citre" "20221111.1230" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "244501472ddf31c91cc374231849a05c86dfb1fb" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
