;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cursor-test" "20131207.1732"
  "Testing library for cursor position in emacs."
  '((emacs "24"))
  :url "https://github.com/ainame/cursor-test.el"
  :commit "e09956e048b88fd2ee8dd90b5678baed8b04d31b"
  :revdesc "e09956e048b8")
