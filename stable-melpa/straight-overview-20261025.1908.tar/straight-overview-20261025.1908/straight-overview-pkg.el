;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "straight-overview" "20261025.1908"
  "Selective upgrade UI for straight.el packages."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/straight-overview"
  :commit "57c6309ecc409d3abf259947a5da583257fbc460"
  :revdesc "57c6309ecc40"
  :keywords '("convenience" "tools" "vc")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
