;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-secretario-org" "20250401.1638"
  "Create inboxes out of org-mode files for el-secretario."
  '((emacs         "27.1")
    (org-ql        "0.6-pre")
    (dash          "2.18.1")
    (el-secretario "0.0.1"))
  :url "https://git.sr.ht/~zetagon/el-secretario"
  :commit "8dee770b0693796286187abb7450fe5ad4109e5a"
  :revdesc "8dee770b0693"
  :keywords '("convenience")
  :authors '(("Leo Okawa Ericson" . "http://github/Zetagon"))
  :maintainers '(("Leo" . "github@relevant-information.com")))
