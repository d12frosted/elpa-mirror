(define-package "chronometrist-key-values" "20211118.630" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "b0bbfb9ac562d57c640dd15106e6af9bdc39e943" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
