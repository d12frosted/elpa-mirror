;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260611.0"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "d163b40a68272458e144c097517f5fdae989e348"
  :revdesc "d163b40a6827"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
