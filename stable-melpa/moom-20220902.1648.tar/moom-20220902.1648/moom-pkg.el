(define-package "moom" "20220902.1648" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "e7d60ea56e13ff987d58e9c930e40f5f6c1dbed4" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
