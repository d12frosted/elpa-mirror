;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-fricas" "20220612.854"
  "A FriCAS backend for Org-Babel."
  '((emacs   "26.1")
    (frimacs "1.0"))
  :url "https://github.com/pdo/frimacs"
  :commit "742268f6f05f418993dc366bbca9ccc931125748"
  :revdesc "742268f6f05f"
  :keywords '("fricas" "computer algebra" "extensions" "tools")
  :authors '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainers '(("Paul Onions" . "paul.onions@acm.org")))
