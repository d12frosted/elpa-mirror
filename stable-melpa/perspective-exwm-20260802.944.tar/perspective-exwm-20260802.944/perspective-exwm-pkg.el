;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective-exwm" "20260802.944"
  "Better integration for perspective.el and EXWM."
  '((emacs       "27.1")
    (burly       "0.2-pre")
    (exwm        "0.26")
    (perspective "2.17"))
  :url "https://github.com/SqrtMinusOne/perspective-exwm.el"
  :commit "c0357efbde56ab3aac456f122138e639cb2b8aac"
  :revdesc "c0357efbde56"
  :authors '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers '(("Korytov Pavel" . "thexcloud@gmail.com")))
