(define-package "detached" "20221004.1521" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "75f5c4d09a24b377b412869b1ab14899b1d405d9" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
