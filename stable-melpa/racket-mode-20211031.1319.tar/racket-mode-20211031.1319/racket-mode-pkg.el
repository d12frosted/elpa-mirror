(define-package "racket-mode" "20211031.1319" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "6f0fd8dfacb251d352e674641424ea2046e7aa4f" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
