(define-package "modus-themes" "20221022.316" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "a6fdd14ebb1f83a4d6316520a8d10a212357c09d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
