(define-package "wucuo" "20220526.1139" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "ec719c0ffd1264f81f6b3071542d09828bf27125" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
