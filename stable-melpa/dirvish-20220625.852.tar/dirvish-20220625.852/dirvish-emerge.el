;;; dirvish-emerge.el --- Pin important files at top -*- lexical-binding: t -*-

;; Copyright (C) 2021-2022 Alex Lu
;; Author : Alex Lu <https://github.com/alexluigit>
;; Version: 1.3.21
;; Keywords: files, convenience
;; Homepage: https://github.com/alexluigit/dirvish
;; SPDX-License-Identifier: GPL-3.0-or-later

;;; Commentary:

;; Allows important files pinned at top in Dirvish buffers.

;;; Code:

(declare-function dirvish-emerge--menu "dirvish-emerge")
(require 'dirvish)

(defcustom dirvish-emerge-groups '()
  "Doc.

((\"Recent\" (pred  . dirvish-emerge-recent-files))
 (\"README\" (regex . \"README\"))
 (\"PDF\"    (exts    \"pdf\"))
 (\"LaTeX\"  (exts    \"tex\" \"bib\"))
 (\"Org\"    (exts    \"org\"))).
"
  :group 'dirvish :type 'alist)
(put 'dirvish-emerge-groups 'safe-local-variable #'listp)

(defcustom dirvish-emerge-on-open nil
  "Doc."
  :group 'dirvish :type 'boolean
  :set (lambda (k v)
         (set k v)
         (funcall (if v #'add-hook #'remove-hook)
                  'dirvish-setup-hook #'dirvish-emerge)
         (funcall (if v #'add-hook #'remove-hook)
                  'dirvish-find-entry-hook #'dirvish-emerge--readin-groups)))

(defclass dirvish-emerge-group (transient-infix)
  ((hide     :initarg :hide)
   (selected :initarg :selected)
   (recipe   :initarg :recipe))
  "[Experimental] Class for Dirvish pinned groups.")

(cl-defmethod transient-format-key ((obj dirvish-emerge-group))
  "Format key for 'dirvish-emerge-group' instance OBJ."
  (let ((key (oref obj key))
        (sel (oref obj selected)))
    (propertize key 'face (if sel 'transient-value 'transient-key))))

(cl-defmethod transient-format-description ((obj dirvish-emerge-group))
  "Format description for 'dirvish-emerge-group' instance OBJ."
  (let ((desc (oref obj description))
        (sel (oref obj selected)))
    (propertize desc 'face (and sel 'transient-value))))

(cl-defmethod transient-format-value ((obj dirvish-emerge-group))
  "Format value for 'dirvish-emerge-group' instance OBJ."
  (let ((val (dirvish-emerge-format-recipe (oref obj recipe)))
        (hide (oref obj hide)))
    (propertize val 'face (if hide 'font-lock-comment-face 'transient-argument))))

(cl-defmethod transient-infix-read ((obj dirvish-emerge-group))
  "Read value from 'dirvish-emerge-group' instance OBJ."
  (oset obj value (list (oref obj description) (oref obj recipe)
                        (oref obj hide) (oref obj selected))))

(cl-defmethod transient-infix-set ((obj dirvish-emerge-group) _value)
  "Set value for 'dirvish-emerge-group' instance OBJ."
  (if-let ((sel (oref obj selected)))
      (dirvish-emerge-read-recipe (oref obj recipe) obj)
    (oset obj selected t)))

(cl-defgeneric dirvish-emerge-format-recipe (recipe)
  "Doc.")

(cl-defmethod dirvish-emerge-format-recipe ((recipe (head regex)))
  "Doc."
  (format "regex: %s" (cdr recipe)))

(cl-defmethod dirvish-emerge-format-recipe ((recipe (head exts)))
  "Doc."
  (format "extensions: %s" (mapconcat #'concat (cdr recipe) ",")))

(cl-defmethod dirvish-emerge-format-recipe ((recipe (head pred)))
  "Doc."
  (format "form: %s" (cdr recipe)))

(defvar dirvish-emerge-predefined-predicates
  '(dirvish-emerge-recent-files))

(defun dirvish-emerge-recent-files (_local-name _full-name attrs)
  "Doc."
  (let ((mtime (file-attribute-modification-time attrs)))
    (and (listp mtime)
         (< (float-time (time-subtract (current-time) mtime)) 7200))))

(cl-defgeneric dirvish-emerge-read-recipe (recipe obj)
  "Doc.")

(cl-defmethod dirvish-emerge-read-recipe ((recipe (head regex)) obj)
  "Doc."
  (let* ((deft (cdr recipe))
         (regex (read-regexp
                 (format "Change regex to (defaults to %s): " deft) deft)))
    (oset obj recipe `(regex . ,regex))))

(cl-defmethod dirvish-emerge-read-recipe ((recipe (head exts)) obj)
  "Doc."
  (let* ((table (cdr recipe))
         (initial (mapconcat #'concat table ","))
         (exts (completing-read-multiple "Input extensions: " table nil nil initial)))
    (oset obj recipe `(exts ,@exts))))

(cl-defmethod dirvish-emerge-read-recipe ((recipe (head pred)) obj)
  "Doc."
  (let* ((table dirvish-emerge-predefined-predicates)
         (pred (completing-read "Predicate: " table nil nil (cdr recipe))))
    (oset obj recipe `(pred . ,(read pred)))))

(cl-defgeneric dirvish-emerge-make-pred (recipe)
  "Doc.")

(cl-defmethod dirvish-emerge-make-pred ((recipe (head regex)))
  "Doc."
  `(lambda (local-name full-name attrs) (string-match ,(cdr recipe) local-name)))

(cl-defmethod dirvish-emerge-make-pred ((recipe (head exts)))
  "Doc."
  (let ((exts (format "\\.\\(%s\\)$" (mapconcat #'concat (cdr recipe) "\\|"))))
    `(lambda (local-name full-name attrs) (string-match ,exts local-name))))

(cl-defmethod dirvish-emerge-make-pred ((recipe (head pred)))
  "Doc."
  (cdr recipe))

(defun dirvish-emerge--get-infixes ()
  "Doc."
  (cl-loop for o in transient-current-suffixes
           when (eq (type-of o) 'dirvish-emerge-group)
           collect o))

(defun dirvish-emerge--apply ()
  "Doc."
  (let* ((infixes (dirvish-emerge--get-infixes))
         (preds (cl-loop for idx from 1 to (length infixes)
                         for obj in infixes
                         collect (cons idx (dirvish-emerge-make-pred (oref obj recipe)))))
         (groups (cl-loop for o in infixes
                          collect (list (oref o description) (oref o recipe)
                                        (oref o hide) (oref o selected)))))
    (setq-local dirvish-emerge-groups groups)
    (dirvish-prop :emerge-preds preds)
    (dirvish-emerge)))

(defun dirvish-emerge--toggle-hiding ()
  "Doc."
  (cl-loop for obj in transient-current-suffixes
           when (and (eq (type-of obj) 'dirvish-emerge-group)
                     (oref obj selected))
           do (oset obj hide (not (oref obj hide)))))

(defun dirvish-emerge--unselect ()
  "Doc."
  (cl-loop for obj in transient-current-suffixes
           when (eq (type-of obj) 'dirvish-emerge-group)
           do (oset obj selected nil)))

(defun dirvish-emerge--readin-groups (dv _entry buffer)
  "Doc."
  (with-current-buffer buffer
    (when (and (not dirvish-emerge-groups)
               (memq buffer (mapcar #'cdr (dv-roots dv)))
               (not (dirvish-prop :fd-dir)))
      (hack-dir-local-variables)
      (when-let ((pair (assq 'dirvish-emerge-groups
                             file-local-variables-alist)))
        (let ((vals (cdr pair)))
          (hack-one-local-variable 'dirvish-emerge-groups vals)
          (dirvish-prop :emerge-preds
            (cl-loop for idx from 1 to (length vals)
                     for (_desc recipe) in vals collect
                     (cons idx (dirvish-emerge-make-pred recipe)))))))))

(defun dirvish-emerge--insert-group (group)
  "Doc."
  (cl-loop with (idx . files) = group
           with hide = (nth 2 (nth (1- idx) dirvish-emerge-groups))
           with start = (point)
           for file in (reverse files) do (insert file "\n")
           finally do (when hide
                        (let ((o (make-overlay start (point))))
                          (overlay-put o 'dirvish-emerge-hide t)
                          (overlay-put o 'invisible t)))))

(defun dirvish-emerge--do-emerge (preds beg end)
  "Doc."
  (let ((beg (or beg (dirvish-prop :content-beginning)))
        (end (or end (point-max)))
        (idx-m (1+ (length preds)))
        buffer-read-only curr-dir groups)
    (setq groups (cl-loop for i from 1 to idx-m collect (cons i '())))
    (remove-overlays beg end 'dirvish-emerge-hide t)
    (save-excursion
      (goto-char beg)
      (setq curr-dir (dired-current-directory))
      (while (< (point) end)
        (when-let ((f-beg (dired-move-to-filename))
                   (f-end (dired-move-to-end-of-filename)))
          (let* ((l-beg (line-beginning-position))
                 (l-end (line-end-position))
                 (local (buffer-substring f-beg f-end))
                 (full (file-local-name
                        (expand-file-name local curr-dir)))
                 (attrs (dirvish-attribute-cache full :builtin))
                 (match (cl-loop for (index . fn) in preds
                                 for match = (funcall fn local full attrs)
                                 thereis (and match index))))
            (push (buffer-substring l-beg l-end)
                  (alist-get (or match idx-m) groups))))
        (forward-line 1))
      (delete-region beg end)
      (goto-char beg)
      (mapc #'dirvish-emerge--insert-group groups))))

(defun dirvish-emerge--create-infixes ()
  "Doc."
  (cl-loop for idx from 0
           for (desc recipe hide selected) in dirvish-emerge-groups
           for i-name = (intern (format "dirvish-%s-infix"
                                        (replace-regexp-in-string " " "-" desc)))
           collect (progn
                     (eval `(transient-define-infix ,i-name ()
                              :class 'dirvish-emerge-group
                              :recipe ',recipe
                              :selected ,selected
                              :hide ,hide
                              :description ,desc))
                     (list (number-to-string idx) i-name))))

;;;###autoload
(defun dirvish-emerge-menu ()
  "Doc."
  (interactive)
  (dirvish-emerge--readin-groups
   (dirvish-curr) nil (current-buffer))
  (eval
   `(transient-define-prefix dirvish-emerge--menu ()
      "Configure current Dirvish session."
      [:description
       (lambda () (propertize "Emerging groups:" 'face '(:inherit dired-mark :underline t) 'display '((height 1.2))))
       ["Emerging groups:"
        ,@(dirvish-emerge--create-infixes)]]
      ["Actions:"
       ("RET" "Apply" (lambda () (interactive) (dirvish-emerge--apply)))
       ("c" "  Clear selection"
        (lambda () (interactive) (dirvish-emerge--unselect)) :transient t)
       ("h" "  Hide/show selected group"
        (lambda () (interactive) (dirvish-emerge--toggle-hiding)) :transient t)
       ("r" "  Remove selected groups"
        (lambda () (interactive) (dirvish-emerge--toggle-hiding)) :transient t)
       ("a" "  Add group"
        (lambda () (interactive) (dirvish-emerge--toggle-hiding)) :transient t)
       ("s" "  Save groups to .dir-locals.el"
        (lambda () (interactive) (dirvish-emerge--toggle-hiding)) :transient t)]
      (interactive)
      (if (or (derived-mode-p 'dirvish-mode)
              (bound-and-true-p dirvish-override-dired-mode))
          (transient-setup 'dirvish-emerge--menu)
        (user-error "`dirvish-setup-menu' is for Dirvish only"))))
  (dirvish-emerge--menu))

;;;###autoload
(defun dirvish-emerge (&optional beg end)
  "Doc."
  (interactive)
  (dirvish-emerge--readin-groups
   (dirvish-curr) nil (current-buffer))
  (when-let ((preds (dirvish-prop :emerge-preds)))
    (dirvish-emerge--do-emerge preds beg end)))

(provide 'dirvish-emerge)
;;; dirvish-emerge.el ends here
