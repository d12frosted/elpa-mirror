;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-dabbrev" "20260717.1243"
  "Like dabbrev-expand with preview and popup menu."
  '((emacs "25.1")
    (popup "0.5.3"))
  :url "https://github.com/jrosdahl/fancy-dabbrev"
  :commit "9a9296f0dcfe272cdff1fc2e0a6a62b8cdaf11ab"
  :revdesc "9a9296f0dcfe"
  :authors '(("Joel Rosdahl" . "joel@rosdahl.net"))
  :maintainers '(("Joel Rosdahl" . "joel@rosdahl.net")))
