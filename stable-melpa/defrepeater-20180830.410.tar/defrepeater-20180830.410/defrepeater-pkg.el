;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "defrepeater" "20180830.410"
  "Easily make commands repeatable."
  '((emacs "25.2")
    (s     "1.12.0"))
  :url "https://github.com/alphapapa/defrepeater.el"
  :commit "62b00ede57d2e115b9ef9f21268c021ae1186873"
  :revdesc "62b00ede57d2"
  :keywords '("convenience")
  :authors '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers '(("Adam Porter" . "adam@alphapapa.net")))
