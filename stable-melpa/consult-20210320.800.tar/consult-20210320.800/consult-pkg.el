(define-package "consult" "20210320.800" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "6ced33ac555dc8852a3fc14811bb745fad19f3c7" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
