(define-package "realgud" "20190715.2328" "A modular front-end for interacting with external debuggers"
  '((load-relative "1.3.1")
    (loc-changes "1.2")
    (test-simple "1.3.0")
    (emacs "25"))
  :commit "53938f04d5252677484e5c48513e1c138aafc756" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :keywords
  '("debugger" "gdb" "python" "perl" "go" "bash" "zsh" "bashdb" "zshdb" "remake" "trepan" "perldb" "pdb")
  :url "http://github.com/realgud/realgud/")
;; Local Variables:
;; no-byte-compile: t
;; End:
