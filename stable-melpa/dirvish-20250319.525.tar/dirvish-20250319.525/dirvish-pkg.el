;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250319.525"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "77299abeeb5f518671d71447d1d061edeaf9537b"
  :revdesc "77299abeeb5f"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
