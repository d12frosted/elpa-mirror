;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-rootfile" "20251111.424"
  "Extension of project.el to detect project with root file."
  '((emacs "27.1"))
  :url "https://github.com/buzztaiki/project-rootfile.el"
  :commit "17ff39be3115c2d075845f86f37b0e24f6b5a2ec"
  :revdesc "17ff39be3115"
  :authors '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainers '(("Taiki Sugawara" . "buzz.taiki@gmail.com")))
