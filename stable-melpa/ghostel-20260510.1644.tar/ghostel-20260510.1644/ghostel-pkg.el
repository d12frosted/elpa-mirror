;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260510.1644"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "aee6a5af08a881d87605dc7c95d2d939298b1353"
  :revdesc "aee6a5af08a8"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
