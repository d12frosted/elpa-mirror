(define-package "helm-core" "20211004.1655" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "228ec3623f3defdbff416f60558b6d451cf37bbf")
;; Local Variables:
;; no-byte-compile: t
;; End:
