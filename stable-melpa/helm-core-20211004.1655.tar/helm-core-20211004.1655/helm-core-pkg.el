(define-package "helm-core" "20211004.1655" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "55186342ab12435eb5a8104abea52241df123c5f")
;; Local Variables:
;; no-byte-compile: t
;; End:
