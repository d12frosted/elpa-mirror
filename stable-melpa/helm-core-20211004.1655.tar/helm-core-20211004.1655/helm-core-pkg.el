(define-package "helm-core" "20211004.1655" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "435f07f5afeeec8467cbe89d09952742ddf8e82b")
;; Local Variables:
;; no-byte-compile: t
;; End:
