;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghub" "20260504.1922"
  "Client libraries for Git forge APIs."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.0")
    (llama    "1.0")
    (treepy   "0.1.3"))
  :url "https://github.com/magit/ghub"
  :commit "07f2f0e4be7f2b40fef272da9dcbbfa188a70604"
  :revdesc "07f2f0e4be7f"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
