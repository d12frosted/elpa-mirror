;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-dialyzer" "20160326.1430"
  "Support dialyzer in flycheck."
  '((flycheck "0.18"))
  :url "https://github.com/lbolla/emacs-flycheck-dialyzer"
  :commit "a5df0db95ac69f397b5f85d325a6d88cf8974f64"
  :revdesc "a5df0db95ac6"
  :authors '(("Lorenzo Bolla" . "lbolla@gmail.com"))
  :maintainers '(("Lorenzo Bolla" . "lbolla@gmail.com")))
