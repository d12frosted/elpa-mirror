;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "defcapture" "20230909.353"
  "A convenience macro for the Doct DSL."
  '((emacs "25.1")
    (doct  "3.0"))
  :url "https://github.com/aggu4/defcapture"
  :commit "777a10a3343da0553813d004a67e39e2df1bcbb2"
  :revdesc "777a10a3343d"
  :keywords '("convenience" "org")
  :authors '(("Abraham Aguilar" . "a.aguilar@ciencias.unam.mx"))
  :maintainers '(("Abraham Aguilar" . "a.aguilar@ciencias.unam.mx")))
