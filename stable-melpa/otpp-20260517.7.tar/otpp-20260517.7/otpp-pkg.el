;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260517.7"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "b3b3b3edc36af31b0b4439bce84aa67a5ace02e0"
  :revdesc "b3b3b3edc36a"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
