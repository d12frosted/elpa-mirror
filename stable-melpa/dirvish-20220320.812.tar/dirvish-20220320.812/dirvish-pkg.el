(define-package "dirvish" "20220320.812" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "23ccd19506f86eeb0b314c03a151c6caafc30ce4" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
