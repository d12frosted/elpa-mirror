;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260609.525"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "f88374d100e9a1005d62a9822a4038ff6f2d91e7"
  :revdesc "f88374d100e9"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
