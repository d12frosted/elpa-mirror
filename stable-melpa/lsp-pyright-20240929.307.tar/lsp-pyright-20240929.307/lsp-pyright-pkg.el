;; -*- mode: lisp-data; no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-pyright" "20240929.307"
  "Python LSP client using Pyright."
  '((emacs    "26.1")
    (lsp-mode "7.0")
    (dash     "2.18.0")
    (ht       "2.0"))
  :url "https://github.com/emacs-lsp/lsp-pyright"
  :commit "4e2a5eac006020efecb3c252d525054af44cd00d"
  :revdesc "4e2a5eac0060"
  :keywords '("languages" "tools" "lsp"))
