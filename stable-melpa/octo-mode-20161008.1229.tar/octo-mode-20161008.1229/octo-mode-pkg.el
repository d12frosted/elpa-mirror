;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "octo-mode" "20161008.1229"
  "Major mode for Octo assembly language."
  '((emacs "24"))
  :url "https://github.com/cryon/octo-mode"
  :commit "4b2ed4a61674f73a6ccd390b5ae123474bd0c977"
  :revdesc "4b2ed4a61674"
  :keywords '("languages")
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
