(define-package "standoff-mode" "20171115.1731" "Create stand-off markup, also called external markup." 'nil :commit "9db77f0acdc0fb7c3ddd8c5714eae4e88e215463" :authors
  '(("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de"))
  :maintainer
  '("Christian Lück" . "christian.lueck@ruhr-uni-bochum.de")
  :keywords
  '("text" "annotations" "ner" "humanities")
  :url "https://github.com/lueck/standoff-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
