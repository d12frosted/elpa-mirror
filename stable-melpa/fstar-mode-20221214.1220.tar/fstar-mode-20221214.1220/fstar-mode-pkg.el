(define-package "fstar-mode" "20221214.1220" "Support for F* programming"
  '((emacs "24.3")
    (dash "2.11")
    (company "0.8.12")
    (quick-peek "1.0")
    (yasnippet "0.11.0")
    (flycheck "30.0")
    (company-quickhelp "2.2.0"))
  :commit "ab0697b9474f36942a12a4b2a75251c247c18e9e" :authors
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers
  '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/FStarLang/fstar-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
