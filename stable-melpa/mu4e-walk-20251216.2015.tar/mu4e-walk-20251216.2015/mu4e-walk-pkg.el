;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-walk" "20251216.2015"
  "Send email addresses for a walk."
  '((emacs "29.1"))
  :url "https://codeberg.org/timmli/mu4e-walk"
  :commit "3d0b613cfdd52f0ddf56f305d8f96e9a52b3e4f9"
  :revdesc "3d0b613cfdd5"
  :keywords '("convenience" "mail")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
