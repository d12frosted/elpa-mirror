(define-package "apropospriate-theme" "20210315.1735" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "120291804ce02c38fc57c80b3dda9323173d08cf")
;; Local Variables:
;; no-byte-compile: t
;; End:
