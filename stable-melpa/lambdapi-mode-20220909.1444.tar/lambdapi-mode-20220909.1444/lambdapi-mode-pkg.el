(define-package "lambdapi-mode" "20220909.1444" "A major mode for editing Lambdapi source code"
  '((emacs "26.1")
    (eglot "1.5")
    (math-symbol-lists "1.2.1")
    (highlight "20190710.1527"))
  :commit "8752043f903acc7f4c54bc9ea18b9cec83beee70" :maintainer
  '("Deducteam" . "dedukti-dev@inria.fr")
  :keywords
  '("languages")
  :url "https://github.com/Deducteam/lambdapi")
;; Local Variables:
;; no-byte-compile: t
;; End:
