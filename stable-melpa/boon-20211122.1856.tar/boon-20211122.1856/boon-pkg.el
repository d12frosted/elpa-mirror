(define-package "boon" "20211122.1856" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "ec898237d12112e8cdb94d5a8fa129e8610b8725")
;; Local Variables:
;; no-byte-compile: t
;; End:
