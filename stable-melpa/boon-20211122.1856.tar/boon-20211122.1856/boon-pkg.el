(define-package "boon" "20211122.1856" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "483a6e6610ba17d13ae0fc0cd0b2247d6368cfdf")
;; Local Variables:
;; no-byte-compile: t
;; End:
