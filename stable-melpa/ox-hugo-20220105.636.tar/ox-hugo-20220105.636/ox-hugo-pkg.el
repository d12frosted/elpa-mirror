(define-package "ox-hugo" "20220105.636" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "de5dfdfdcdc3ec50cb27d1f6cf7314a5c9aa1385" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
