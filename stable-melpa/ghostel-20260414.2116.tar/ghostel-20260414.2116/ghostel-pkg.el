;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260414.2116"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "bfb6e7c25085501592c2daa90719bc90dbb6773b"
  :revdesc "bfb6e7c25085"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
