(define-package "helm-core" "20220514.725" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "87bf219648ade7ca2462cd415b4df55f77a4f975" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
