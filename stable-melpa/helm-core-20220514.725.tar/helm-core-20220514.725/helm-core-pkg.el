(define-package "helm-core" "20220514.725" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "e038260fcca73e4f234e9b6abdf90f5ef094a490" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
