(define-package "helm-core" "20220514.725" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "4d1f38684c7bd770244704ff80f21f49e3891734" :authors
  '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
