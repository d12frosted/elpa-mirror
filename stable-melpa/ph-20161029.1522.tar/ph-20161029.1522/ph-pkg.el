(define-package "ph" "20161029.1522" "A global minor mode for managing multiple projects."
  '((emacs "24.3"))
  :commit "ed80dad9211583ed0db633448b3624c99b7fac23")
;; Local Variables:
;; no-byte-compile: t
;; End:
