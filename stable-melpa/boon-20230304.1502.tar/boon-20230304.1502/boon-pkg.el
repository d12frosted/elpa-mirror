(define-package "boon" "20230304.1502" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "1e85d6a11a756519dd4632b1bb2029a1e9c61f5a")
;; Local Variables:
;; no-byte-compile: t
;; End:
