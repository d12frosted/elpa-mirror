;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultra-scroll" "20260822.2031"
  "Fast and smooth scrolling."
  '((emacs "29.1"))
  :url "https://github.com/jdtsmith/ultra-scroll"
  :commit "af8dd38480f251a2a99b10b765ce8fd5eeab22ca"
  :revdesc "af8dd38480f2"
  :keywords '("convenience"))
