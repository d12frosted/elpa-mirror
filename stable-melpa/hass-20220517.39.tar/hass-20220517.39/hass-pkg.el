(define-package "hass" "20220517.39" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3"))
  :commit "da313bfc5d6c14c445d2de393bf63d0ace612ae0" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
