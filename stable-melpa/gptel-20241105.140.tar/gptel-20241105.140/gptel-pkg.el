;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241105.140"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "af6c4927c453610b0cecd098402f6667797aaf41"
  :revdesc "af6c4927c453"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
