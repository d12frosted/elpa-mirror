;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "decl" "20221027.1823"
  "Library for organizing code declaratively."
  '((dash   "2.5.0")
    (emacs  "24.3")
    (cl-lib "0.3"))
  :url "https://github.com/preetpalS/decl.el"
  :commit "1b11ee91c4b2a2d30b236debf65538fbe4bf10a9"
  :revdesc "1b11ee91c4b2")
