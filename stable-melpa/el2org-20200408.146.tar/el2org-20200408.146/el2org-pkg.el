;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el2org" "20200408.146"
  "Convert elisp file to org file."
  '((emacs "25.1"))
  :url "https://github.com/tumashu/el2org"
  :commit "7db77fdd73f378d4e60e34c11bbdf00677adc32c"
  :revdesc "7db77fdd73f3"
  :keywords '("convenience")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
