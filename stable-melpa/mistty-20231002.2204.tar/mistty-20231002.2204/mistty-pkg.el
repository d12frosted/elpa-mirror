(define-package "mistty" "20231002.2204" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "a7c7471abbc7fb011e055ef11fe748b531ed4f52" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
