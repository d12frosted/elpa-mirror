(define-package "ellama" "20231019.905" "Ollama client for calling local LLMs"
  '((emacs "28.1")
    (spinner "1.7.4"))
  :commit "f9e0de5af6a48659dc39914e61964231fe75ca69" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
