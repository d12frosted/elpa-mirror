;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magent" "20260831.915"
  "AI coding agent."
  '((emacs       "29.1")
    (gptel       "0.9.8")
    (yaml        "1.0.0")
    (compat      "30.1.0.0")
    (acp         "0.13.1")
    (agent-shell "0.66.1"))
  :url "https://github.com/jamie-cui/magent"
  :commit "59c2082d99a92a6e2d582a70c46d94ee6207bddd"
  :revdesc "59c2082d99a9"
  :keywords '("tools" "ai" "copilot")
  :authors '(("Jamie Cui" . "jamie.cui@outlook.com"))
  :maintainers '(("Jamie Cui" . "jamie.cui@outlook.com")))
