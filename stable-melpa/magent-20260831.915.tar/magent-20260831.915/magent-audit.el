;;; magent-audit.el --- Audit recording for Magent  -*- lexical-binding: t; -*-

;; Copyright (C) 2026 Jamie Cui
;; SPDX-License-Identifier: GPL-3.0-or-later
;; Assisted-by: Codex:GPT-5.6, Magent:deepseek-v4-pro

;; Author: Jamie Cui <jamie.cui@outlook.com>
;; Keywords: tools, ai

;;; Commentary:

;; Compact audit recording for permission decisions and sensitive agent
;; actions.  Records may stay only in a live browser buffer or be appended as
;; JSONL to a configured file.  This is intentionally separate from
;; *magent-log*.

;;; Code:

(require 'cl-lib)
(require 'json)
(require 'pp)
(require 'subr-x)
(require 'magent-config)
(require 'magent-approval)
(require 'magent-lifecycle-events)
(require 'magent-protocol)
(require 'magent-redaction)
(require 'magent-session)

(defconst magent-audit--sensitive-tools
  '("bash" "emacs_eval" "write_file" "edit_file"
    "spawn_agent"
    "send_agent_message" "wait_agent" "list_agents" "close_agent")
  "Tool names that are always included in audit recording.")

(defvar magent-audit--enabled nil
  "Non-nil when Magent audit hooks are installed.")

(defvar magent-audit--pending-writes nil
  "Queued audit payloads waiting to be flushed to disk.
Each entry is a cons cell of the form (FILE . JSONL-LINE).")

(defvar magent-audit--flush-timer nil
  "Idle timer used to flush queued audit records to disk.")

(defvar magent-audit-entry-map
  (let ((map (make-sparse-keymap)))
    (define-key map [mouse-1] #'magent-audit-toggle-entry)
    map)
  "Keymap used on audit entry summaries.")

(defvar-local magent-audit--all-records nil
  "All audit records loaded into the current audit buffer.")

(defvar-local magent-audit--live-records nil
  "Audit records retained only in the current live audit buffer.")

(defvar-local magent-audit--visible-records nil
  "Audit records currently rendered in the buffer.")

(defvar-local magent-audit--filters nil
  "Current audit browser filters as a plist.")

(defvar-local magent-audit--expanded-ids nil
  "Record ids expanded in the current audit buffer.")

(defvar-local magent-audit--load-errors 0
  "Number of audit lines skipped during the last refresh.")

(defvar-local magent-audit--truncated-count 0
  "Number of matching records omitted from the current render.")

(defvar magent-audit-mode-map
  (let ((map (make-sparse-keymap)))
    (set-keymap-parent map special-mode-map)
    (define-key map (kbd "g") #'magent-audit-refresh)
    (define-key map (kbd "c") #'magent-audit-clear-filters)
    (define-key map (kbd "e") #'magent-audit-filter-by-event)
    (define-key map (kbd "t") #'magent-audit-filter-by-tool)
    (define-key map (kbd "d") #'magent-audit-filter-by-decision)
    (define-key map (kbd "s") #'magent-audit-filter-by-status)
    (define-key map (kbd "a") #'magent-audit-filter-by-agent)
    (define-key map (kbd "RET") #'magent-audit-toggle-entry)
    (define-key map (kbd "TAB") #'magent-audit-toggle-entry)
    map)
  "Keymap for `magent-audit-mode'.")

(define-derived-mode magent-audit-mode special-mode "MagentAudit"
  "Major mode for browsing Magent audit records."
  (setq-local truncate-lines t)
  (setq-local revert-buffer-function #'magent-audit-refresh)
  (setq-local header-line-format '(:eval (magent-audit--header-line))))

(defun magent-audit-enable ()
  "Enable audit recording hooks."
  ;; Registration is idempotent.  Reassert it even when the enabled flag is
  ;; already set so live reloads and dynamically rebound hook lists
  ;; cannot leave auditing nominally enabled but disconnected.
  (magent-lifecycle-events-add-sink #'magent-audit--event-sink)
  (add-hook 'magent-approval-state-change-functions
            #'magent-audit--approval-state-changed)
  (setq magent-audit--enabled t)
  magent-audit--enabled)

(defun magent-audit-disable ()
  "Disable audit recording hooks."
  (when magent-audit--enabled
    (magent-lifecycle-events-remove-sink #'magent-audit--event-sink)
    (remove-hook 'magent-approval-state-change-functions
                 #'magent-audit--approval-state-changed)
    (magent-audit--flush-pending)
    (setq magent-audit--enabled nil))
  magent-audit--enabled)

(defun magent-audit-record (event &rest props)
  "Record audit EVENT with PROPS in the configured destination."
  (when magent-audit
    (condition-case err
        (let ((record (magent-audit--build-record event props)))
          (when record
            (pcase magent-audit
              ('buffer
               (magent-audit--record-live-buffer record))
              ((pred stringp)
               (magent-audit--enqueue-record
                (magent-audit--file-path)
                (concat (json-encode record) "\n"))))))
      (error
       (magent-log "WARN audit record failed: %s"
                   (error-message-string err))))))

(defun magent-audit-record-permission-decision (tool-name perm-key decision source
                                                         &rest props)
  "Record a structured permission decision for TOOL-NAME.
PERM-KEY is the tool permission symbol.  DECISION is the final
decision symbol and SOURCE identifies how that decision was made.
PROPS accepts the same plist keys as `magent-audit-record'."
  (apply #'magent-audit-record
         'permission-decision
         :tool-name tool-name
         :perm-key perm-key
         :decision decision
         :decision-source source
         props))

(defun magent-audit--file-path ()
  "Return the configured audit JSONL file path.
Signal an error unless `magent-audit' names a file."
  (unless (stringp magent-audit)
    (error "Magent audit destination is not a file: %S" magent-audit))
  (expand-file-name magent-audit user-emacs-directory))

(defun magent-audit--record-live-buffer (record)
  "Retain RECORD in the live audit buffer and redraw it."
  (with-current-buffer (magent-audit-get-buffer)
    (let ((preserve-entry-id (magent-audit--entry-id-at-point)))
      (push record magent-audit--live-records)
      (magent-audit--refresh-current-buffer preserve-entry-id))))

(defun magent-audit--enqueue-record (file line)
  "Queue audit LINE for FILE and schedule an idle flush."
  (push (cons file line) magent-audit--pending-writes)
  (magent-audit--schedule-flush))

(defun magent-audit--schedule-flush ()
  "Schedule an idle flush for queued audit records."
  (unless (timerp magent-audit--flush-timer)
    (setq magent-audit--flush-timer
          (run-with-idle-timer
           (max 0.0 (or magent-audit-flush-delay 0.0))
           nil
           #'magent-audit--flush-pending))))

(defun magent-audit--flush-pending ()
  "Write queued audit records to disk in batched appends."
  (when (timerp magent-audit--flush-timer)
    (cancel-timer magent-audit--flush-timer))
  (setq magent-audit--flush-timer nil)
  (when magent-audit--pending-writes
    (let ((writes (prog1 (nreverse magent-audit--pending-writes)
                    (setq magent-audit--pending-writes nil)))
          grouped)
      (dolist (entry writes)
        (let* ((file (car entry))
               (line (cdr entry))
               (existing (assoc file grouped)))
          (if existing
              (setcdr existing (concat (cdr existing) line))
            (push (cons file line) grouped))))
      ;; A stale or unwritable destination must not discard records queued for
      ;; unrelated scopes/directories in the same flush.
      (dolist (entry (nreverse grouped))
        (condition-case err
            (magent-audit--append-batch (car entry) (cdr entry))
          (error
           (magent-log "WARN audit write failed for %s: %s"
                       (magent-audit--path-preview (car entry))
                       (error-message-string err))))))))

(defun magent-audit--append-batch (file payload)
  "Append audit PAYLOAD to FILE using private directory and file modes."
  (let* ((directory (file-name-directory file))
         (old-default-modes (default-file-modes)))
    (unwind-protect
        (progn
          (set-default-file-modes #o700)
          (make-directory directory t))
      (set-default-file-modes old-default-modes))
    (set-file-modes directory #o700)
    (unwind-protect
        (progn
          (set-default-file-modes #o600)
          (when (file-exists-p file)
            (set-file-modes file #o600))
          (with-temp-buffer
            (insert payload)
            (write-region (point-min) (point-max) file t 0)))
      (set-default-file-modes old-default-modes))
    (set-file-modes file #o600)))

(defun magent-audit-get-buffer ()
  "Return the Magent audit browser buffer."
  (let ((buffer (get-buffer-create magent-audit-buffer-name)))
    (with-current-buffer buffer
      (unless (derived-mode-p 'magent-audit-mode)
        (magent-audit-mode)))
    buffer))

;;;###autoload
(defun magent-open-audit ()
  "Open the Magent audit browser."
  (interactive)
  (magent-audit--flush-pending)
  (let ((buffer (magent-audit-get-buffer)))
    (with-current-buffer buffer
      (unless magent-audit--filters
        (setq magent-audit--filters nil))
      (magent-audit-refresh))
    (display-buffer buffer)
    buffer))

(defun magent-audit-refresh (&optional _ignore-auto _noconfirm preserve-entry-id)
  "Reload and redraw the Magent audit browser.
PRESERVE-ENTRY-ID is the record id to keep point on after
refresh.  The first two arguments follow `revert-buffer'."
  (interactive)
  (magent-audit--flush-pending)
  (let ((buffer (magent-audit-get-buffer)))
    (with-current-buffer buffer
      (setq preserve-entry-id (or preserve-entry-id
                                  (magent-audit--entry-id-at-point)))
      (magent-audit--refresh-current-buffer preserve-entry-id))
    buffer))

(defun magent-audit--refresh-current-buffer (&optional preserve-entry-id)
  "Reload and redraw the current audit buffer.
PRESERVE-ENTRY-ID is the record id to keep point on after refresh."
  (pcase-let* ((`(,records . ,errors) (magent-audit--load-records))
               (filtered (magent-audit--apply-filters
                          records magent-audit--filters))
               (limit (and (integerp magent-audit-max-records)
                           (> magent-audit-max-records 0)
                           magent-audit-max-records))
               (visible (if (and limit (> (length filtered) limit))
                            (cl-subseq filtered 0 limit)
                          filtered)))
    (setq magent-audit--all-records records
          magent-audit--visible-records visible
          magent-audit--load-errors errors
          magent-audit--truncated-count (max 0 (- (length filtered)
                                                  (length visible))))
    (magent-audit--render preserve-entry-id)))

(defun magent-audit-clear-filters ()
  "Clear all active audit browser filters."
  (interactive)
  (unless (derived-mode-p 'magent-audit-mode)
    (user-error "Current buffer is not a Magent audit buffer"))
  (setq magent-audit--filters nil
        magent-audit--expanded-ids nil)
  (magent-audit-refresh)
  (message "Magent audit filters cleared"))

(defun magent-audit-filter-by-event ()
  "Set the current audit event filter."
  (interactive)
  (magent-audit--prompt-and-set-filter :event "Event"))

(defun magent-audit-filter-by-tool ()
  "Set the current audit tool filter."
  (interactive)
  (magent-audit--prompt-and-set-filter :tool-name "Tool"))

(defun magent-audit-filter-by-decision ()
  "Set the current audit decision filter."
  (interactive)
  (magent-audit--prompt-and-set-filter :decision "Decision"))

(defun magent-audit-filter-by-status ()
  "Set the current audit status filter."
  (interactive)
  (magent-audit--prompt-and-set-filter :status "Status"))

(defun magent-audit-filter-by-agent ()
  "Set the current audit agent filter."
  (interactive)
  (magent-audit--prompt-and-set-filter :agent "Agent"))

(defun magent-audit-toggle-entry ()
  "Toggle details for the audit entry at point."
  (interactive)
  (unless (derived-mode-p 'magent-audit-mode)
    (user-error "Current buffer is not a Magent audit buffer"))
  (let ((entry-id (magent-audit--entry-id-at-point)))
    (unless entry-id
      (user-error "No Magent audit entry at point"))
    (if (member entry-id magent-audit--expanded-ids)
        (setq magent-audit--expanded-ids
              (delete entry-id (copy-sequence magent-audit--expanded-ids)))
      (push entry-id magent-audit--expanded-ids))
    (magent-audit-refresh nil nil entry-id)))

(defun magent-audit--build-record (event props)
  "Build one audit record for EVENT from PROPS."
  (let* ((audit-context
          (magent-audit--valid-context-snapshot
           (plist-get props :audit-context)))
         ;; Async audit records must never borrow mutable ambient attribution.
         ;; Explicit lifecycle contexts may contribute only their stable ids;
         ;; session, scope, project, and agent always come from AUDIT-CONTEXT.
         (candidate-context (or (plist-get props :context)
                                (plist-get props :event-context)))
         (context (and (magent-lifecycle-events-context-p candidate-context)
                       candidate-context))
         (scope (plist-get audit-context :scope))
         (project-root (plist-get audit-context :project-root))
         (tool-name (plist-get props :tool-name))
         (args (plist-get props :args)))
    `((timestamp . ,(format-time-string "%Y-%m-%dT%H:%M:%S%z"))
      (event . ,(magent-audit--safe-identifier event))
      (attribution_source . ,(if audit-context "request-snapshot" "missing"))
      (agent . ,(magent-audit--safe-identifier
                 (plist-get audit-context :agent)))
      (turn_id . ,(magent-audit--safe-identifier
                   (or (plist-get props :turn-id)
                       (plist-get audit-context :turn-id)
                       (and context
                            (magent-lifecycle-events-context-turn-id context)))))
      (subagent_id . ,(magent-audit--safe-identifier
                       (or (plist-get props :subagent-id)
                           (plist-get audit-context :subagent-id)
                           (and context
                                (magent-lifecycle-events-context-subagent-id
                                 context)))))
      (session_id . ,(magent-audit--safe-identifier
                      (plist-get audit-context :session-id)))
      (scope . ,(magent-audit--scope-name scope))
      (project_root . ,(magent-audit--path-preview project-root project-root))
      (project_id . ,(magent-audit--safe-identifier
                      (plist-get audit-context :project-id)))
      (tool_name . ,(magent-audit--safe-identifier tool-name))
      (perm_key . ,(magent-audit--safe-identifier (plist-get props :perm-key)))
      (decision . ,(magent-audit--safe-identifier (plist-get props :decision)))
      (decision_source . ,(magent-audit--safe-identifier
                           (plist-get props :decision-source)))
      (status . ,(magent-audit--safe-identifier (plist-get props :status)))
      (summary . nil)
      (summary_length . ,(magent-audit--string-length
                          (plist-get props :summary)))
      (args_preview . ,(magent-audit--sanitize-args
                        tool-name args project-root))
      (result_preview . nil)
      (result_length . ,(magent-audit--string-length
                         (plist-get props :result)))
      (call_id . ,(magent-audit--safe-identifier (plist-get props :call-id)))
      (request_id . ,(magent-audit--safe-identifier
                      (plist-get props :request-id)))
      (title . nil)
      (title_length . ,(magent-audit--string-length
                        (plist-get props :title)))
      (detail . nil)
      (detail_length . ,(magent-audit--string-length
                         (plist-get props :detail))))))

(defun magent-audit--valid-context-snapshot (value)
  "Return VALUE when it is a valid scalar audit context, otherwise nil."
  (when (and (proper-list-p value)
             (zerop (% (length value) 2))
             (eq (plist-get value :attribution-source) 'request-snapshot)
             (cl-every
              (lambda (key)
                (let ((item (plist-get value key)))
                  (or (null item) (stringp item))))
              '(:session-id :project-root :project-id :agent
                :turn-id :subagent-id))
             (let ((scope (plist-get value :scope)))
               (or (null scope) (eq scope 'global) (stringp scope))))
    value))

(defun magent-audit--scope-name (scope)
  "Return a stable scope name string for SCOPE."
  (cond
   ((eq scope 'global) "global")
   ((stringp scope) "project")
   (t nil)))

(defun magent-audit--safe-identifier (value)
  "Return VALUE only when it is a bounded identifier, otherwise a marker."
  (when value
    (let ((text (cond ((symbolp value) (symbol-name value))
                      ((stringp value) value))))
      (cond
       ((null text) "<invalid-identifier>")
       ((and (<= (length text) 128)
             (string-match-p "\\`[[:alnum:]_.:@+-]+\\'" text))
        text)
       (t (format "<identifier:%s>"
                  (substring (secure-hash 'sha256 text) 0 12)))))))

(defun magent-audit--external-path-marker (path)
  "Return a stable non-disclosing marker for external absolute PATH."
  (format "<external-path:%s>"
          (substring (secure-hash 'sha256 path) 0 12)))

(defun magent-audit--path-preview (value &optional request-project-root)
  "Return a redacted and normalized audit preview for path VALUE.
REQUEST-PROJECT-ROOT is explicit; this helper never consults ambient scope."
  (when value
    (condition-case nil
        (if (not (stringp value))
            "<redacted:unsafe-path>"
          (let* ((project-root
                  (and request-project-root
                       (condition-case nil
                           (file-truename
                            (expand-file-name request-project-root))
                         (error (expand-file-name request-project-root)))))
                 (canonical-value
                  (if (file-name-absolute-p value)
                      (condition-case nil
                          (file-truename (expand-file-name value))
                        (error (expand-file-name value)))
                    value))
                 (normalized
                  (magent-redaction-normalize-paths
                   canonical-value project-root))
                 (redacted (magent-redaction-string normalized t)))
            (cond
             ((string-prefix-p "/" redacted)
              (magent-audit--external-path-marker redacted))
             ((string-empty-p redacted) nil)
             (t (truncate-string-to-width
                 redacted magent-audit-preview-length nil nil "...")))))
      (error "<redacted:unsafe-path>"))))

(defun magent-audit--generic-args-preview (args)
  "Return fail-closed metadata for generic ARGS without persisting values."
  (if (and (proper-list-p args) (zerop (% (length args) 2)))
      (list (cons 'field_count (/ (length args) 2)))
    '((redacted . "<redacted:unsafe-args>"))))

(defun magent-audit--sanitize-args (tool-name args &optional project-root)
  "Return a redacted JSON-safe preview for TOOL-NAME ARGS.
PROJECT-ROOT is the captured request root used to normalize path prefixes."
  (when args
    (pcase tool-name
      ("write_file"
       (magent-audit--compact-alist
        (cons 'path (magent-audit--path-preview
                     (plist-get args :path) project-root))
        (cons 'content_length (magent-audit--string-length (plist-get args :content)))))
      ("edit_file"
       (magent-audit--compact-alist
        (cons 'path (magent-audit--path-preview
                     (plist-get args :path) project-root))
        (cons 'old_text_length (magent-audit--string-length (plist-get args :old_text)))
        (cons 'new_text_length (magent-audit--string-length (plist-get args :new_text)))))
      ("bash"
       (magent-audit--compact-alist
        (cons 'command_length
              (magent-audit--string-length (plist-get args :command)))
        (cons 'timeout (magent-audit--safe-number
                        (plist-get args :timeout)))))
      ("emacs_eval"
       (magent-audit--compact-alist
        (cons 'sexp_length
              (magent-audit--string-length (plist-get args :sexp)))
        (cons 'timeout (magent-audit--safe-number
                        (plist-get args :timeout)))))
      ("spawn_agent"
       (magent-audit--compact-alist
        (cons 'agent (magent-audit--safe-identifier
                      (plist-get args :agent)))
        (cons 'task_name_length
              (magent-audit--string-length (plist-get args :task_name)))
        (cons 'prompt_length
              (magent-audit--string-length (plist-get args :prompt)))))
      ((or "send_agent_message" "wait_agent" "close_agent")
       (magent-audit--compact-alist
        (cons 'job_id (magent-audit--safe-identifier
                       (plist-get args :job_id)))
        (cons 'message_length (magent-audit--string-length
                               (plist-get args :message)))
        (cons 'close_reason_length
              (magent-audit--string-length
               (plist-get args :close_reason)))))
      ("list_agents"
       (magent-audit--compact-alist
        (cons 'include_closed
              (magent-audit--safe-true-boolean
               (plist-get args :include_closed)))))
      ("read_file"
       (magent-audit--compact-alist
        (cons 'path (magent-audit--path-preview
                     (plist-get args :path) project-root))
        (cons 'source (magent-audit--safe-identifier
                       (plist-get args :source)))))
      ("grep"
       (magent-audit--compact-alist
        (cons 'pattern_length
              (magent-audit--string-length (plist-get args :pattern)))
        (cons 'path (magent-audit--path-preview
                     (plist-get args :path) project-root))
        (cons 'case_sensitive
              (magent-audit--safe-true-boolean
               (plist-get args :case_sensitive)))))
      ("glob"
       (magent-audit--compact-alist
        (cons 'pattern_length
              (magent-audit--string-length (plist-get args :pattern)))
        (cons 'path (magent-audit--path-preview
                     (plist-get args :path) project-root))))
      (_
       (magent-audit--generic-args-preview args)))))

(defun magent-audit--compact-alist (&rest pairs)
  "Return PAIRS without null values."
  (delq nil
        (mapcar (lambda (pair)
                  (when (cdr pair) pair))
                pairs)))

(defun magent-audit--string-length (value)
  "Return the string length of VALUE, or nil."
  (when (stringp value)
    (length value)))

(defun magent-audit--safe-number (value)
  "Return finite numeric VALUE, otherwise nil.
This prevents malformed provider arguments from turning a metadata field into
an arbitrary persisted string or object."
  (cond
   ((integerp value) value)
   ((and (floatp value)
         (not (isnan value))
         (not (string-match-p "\\(?:INF\\|NaN\\)" (format "%s" value))))
    value)))

(defun magent-audit--safe-true-boolean (value)
  "Return t only when VALUE is the canonical true value.
False and malformed values are omitted by `magent-audit--compact-alist'."
  (and (eq value t) t))

(defun magent-audit--tool-status (result)
  "Return a compact status string for RESULT."
  (pcase (magent-tool-result-status-value result)
    ('completed "ok")
    ('timeout "timeout")
    ((or 'failed 'cancelled) "error")
    (_ nil)))

(defun magent-audit--approval-request-data (entry)
  "Extract the request plist from approval ENTRY."
  (or (plist-get entry :request) entry))

(defun magent-audit--approval-decision-info (event entry)
  "Return a `(DECISION . SOURCE)' pair for approval EVENT and ENTRY."
  (let ((decision (and entry (plist-get entry :decision))))
    (pcase event
      ('requested '(ask . approval-requested))
      ('resolved
       (pcase decision
         ('allow-once '(allow . user-allow-once))
         ('deny-once '(deny . user-deny-once))
         ('allow-session '(allow . user-allow-session))
         ('deny-session '(deny . user-deny-session))
         (_ (cons decision 'approval-resolved))))
      ('dropped '(dropped . approval-dropped))
      ('cleared '(cleared . approval-cleared))
      (_ (cons event event)))))

(defun magent-audit--approval-state-changed (event request-id entry)
  "Persist approval lifecycle EVENT for REQUEST-ID and ENTRY."
  (when (or request-id entry)
    (let* ((request (magent-audit--approval-request-data entry))
           (context (plist-get request :context))
           (decision-info (magent-audit--approval-decision-info event entry)))
      (magent-audit-record
       (intern (format "approval-%s" event))
       :context context
       :audit-context (plist-get request :audit-context)
       :request-id request-id
       :tool-name (plist-get request :tool-name)
       :perm-key (plist-get request :perm-key)
       :decision (car decision-info)
       :decision-source (cdr decision-info)
       :status (pcase event
                 ('requested 'pending)
                 ('resolved 'completed)
                 (_ event))
       :summary (plist-get request :summary)
       :args (plist-get request :args)
       :detail (and (eq event 'resolved)
                    (magent-audit--safe-identifier
                     (plist-get entry :decision)))))))

(defun magent-audit--event-sink (event)
  "Persist supported EVENT plists to the audit log."
  (pcase (plist-get event :type)
    ((or 'tool-call-start 'tool-call-end)
     (when (member (plist-get event :tool-name) magent-audit--sensitive-tools)
       (magent-audit-record
        (plist-get event :type)
        :context (plist-get event :context)
        :audit-context (plist-get event :audit-context)
        :turn-id (plist-get event :turn-id)
        :subagent-id (plist-get event :subagent-id)
        :tool-name (plist-get event :tool-name)
        :call-id (plist-get event :call-id)
        :status (and (eq (plist-get event :type) 'tool-call-end)
                     (pcase (plist-get event :status)
                       ('completed "ok")
                       ('timeout "timeout")
                       ((or 'failed 'cancelled) "error")
                       (_ (magent-audit--tool-status
                           (plist-get event :result)))))
        :summary (or (plist-get event :summary)
                     (plist-get event :description))
        :args (plist-get event :args)
        :result (plist-get event :result)
        :title (plist-get event :title))))
    ('subagent-start
     (magent-audit-record
      'subagent-start
      :context (plist-get event :context)
      :audit-context (plist-get event :audit-context)
      :turn-id (plist-get event :turn-id)
      :subagent-id (plist-get event :subagent-id)
      :status 'started
      :title (plist-get event :title)
      :summary (plist-get event :title)))
    ('subagent-stop
      (magent-audit-record
      'subagent-stop
      :context (plist-get event :context)
      :audit-context (plist-get event :audit-context)
      :turn-id (plist-get event :turn-id)
      :subagent-id (plist-get event :subagent-id)
      :status 'stopped))))

(defun magent-audit--load-records ()
  "Return `(RECORDS . LOAD-ERRORS)' for the current audit window."
  (let ((cutoff (magent-audit--cutoff-time))
        records
        (load-errors 0))
    (pcase magent-audit
      ('buffer
       (setq records (copy-sequence magent-audit--live-records)))
      ((pred stringp)
       (dolist (file (magent-audit--list-files))
         (pcase-let ((`(,file-records . ,file-errors)
                      (magent-audit--read-file file)))
           (setq load-errors (+ load-errors file-errors)
                 records (nconc file-records records))))))
    (setq records
          (cl-remove-if-not
           (lambda (record)
             (magent-audit--record-in-window-p record cutoff))
           records))
    (cons (sort records #'magent-audit--record-newer-p) load-errors)))

(defun magent-audit--list-files ()
  "Return available audit JSONL files."
  (when (stringp magent-audit)
    (let ((file (magent-audit--file-path)))
      (and (file-regular-p file) (list file)))))

(defun magent-audit--cutoff-time ()
  "Return the oldest time included by default, or nil for all data."
  (when (and (integerp magent-audit-default-days)
             (> magent-audit-default-days 0))
    (time-subtract (current-time)
                   (days-to-time magent-audit-default-days))))

(defun magent-audit--read-file (file)
  "Return `(RECORDS . LOAD-ERRORS)' loaded from audit FILE."
  (let (records
        (load-errors 0))
    (with-temp-buffer
      (insert-file-contents file)
      (dolist (line (split-string (buffer-string) "\n" t))
        (condition-case err
            (let ((json-object-type 'alist)
                  (json-array-type 'list)
                  (json-key-type 'symbol))
              (push (json-read-from-string line) records))
          (error
           (setq load-errors (1+ load-errors))
           (magent-log "WARN audit ui skipped malformed record in %s: %s"
                       file
                       (error-message-string err))))))
    (cons (nreverse records) load-errors)))

(defun magent-audit--record-newer-p (left right)
  "Return non-nil when LEFT should sort before RIGHT."
  (let ((left-time (magent-audit--record-time left))
        (right-time (magent-audit--record-time right)))
    (time-less-p right-time left-time)))

(defun magent-audit--record-time (record)
  "Return the parsed timestamp of RECORD."
  (or (alist-get '_parsed_time record)
      (let ((parsed (condition-case nil
                        (date-to-time (or (alist-get 'timestamp record) ""))
                      (error (seconds-to-time 0)))))
        (setf (alist-get '_parsed_time record) parsed)
        parsed)))

(defun magent-audit--record-in-window-p (record cutoff)
  "Return non-nil when RECORD is newer than CUTOFF or CUTOFF is nil."
  (or (null cutoff)
      (not (time-less-p (magent-audit--record-time record) cutoff))))

(defun magent-audit--apply-filters (records filters)
  "Return RECORDS that satisfy FILTERS."
  (if (null filters)
      records
    (cl-remove-if-not
     (lambda (record)
       (magent-audit--record-matches-p record filters))
     records)))

(defun magent-audit--record-matches-p (record filters)
  "Return non-nil when RECORD matches FILTERS."
  (let ((matches t))
    (while (and filters matches)
      (let ((key (pop filters))
            (value (pop filters)))
        (when value
          (setq matches
                (equal (magent-audit--filter-value record key) value)))))
    matches))

(defun magent-audit--filter-value (record key)
  "Return the comparable filter value from RECORD for KEY."
  (alist-get (magent-audit--filter-field key) record))

(defun magent-audit--filter-field (key)
  "Return the record field symbol corresponding to filter KEY."
  (pcase key
    (:tool-name 'tool_name)
    (_ (intern (substring (symbol-name key) 1)))))

(defun magent-audit--prompt-and-set-filter (key prompt)
  "Prompt for PROMPT and set KEY in the active audit buffer."
  (unless (derived-mode-p 'magent-audit-mode)
    (user-error "Current buffer is not a Magent audit buffer"))
  (let* ((current (plist-get magent-audit--filters key))
         (choices (magent-audit--filter-choices key))
         (value (completing-read
                 (if current
                     (format "%s (RET to clear, current %s): " prompt current)
                   (format "%s (RET to clear): " prompt))
                 choices nil nil nil nil current)))
    (magent-audit--set-filter-value key (unless (string-empty-p value) value))))

(defun magent-audit--set-filter-value (key value)
  "Set audit filter KEY to VALUE in the current buffer."
  (setq magent-audit--filters (plist-put magent-audit--filters key value)
        magent-audit--expanded-ids nil)
  (magent-audit-refresh)
  (message (if value
               "Magent audit %s filter: %s"
             "Magent audit %s filter cleared")
           (substring (symbol-name key) 1)
           (or value "")))

(defun magent-audit--filter-choices (key)
  "Return sorted distinct choices for filter KEY."
  (let ((field (magent-audit--filter-field key))
        values)
    (dolist (record magent-audit--all-records)
      (when-let* ((value (alist-get field record)))
        (push value values)))
    (sort (delete-dups values) #'string-lessp)))

(defun magent-audit--render (&optional preserve-entry-id)
  "Render the current audit buffer.
When PRESERVE-ENTRY-ID is non-nil, restore point to that entry."
  (let ((inhibit-read-only t)
        (buffer (current-buffer)))
    (erase-buffer)
    (cond
     ((null magent-audit)
      (insert "Audit recording is disabled.\n"))
     ((null magent-audit--all-records)
      (insert "No audit records found.\n"))
     ((null magent-audit--visible-records)
      (insert "No audit records matched the current filters.\n"))
     (t
      (when (> magent-audit--load-errors 0)
        (insert (format "%d malformed audit line(s) were skipped.\n\n"
                        magent-audit--load-errors)))
      (dolist (record magent-audit--visible-records)
        (magent-audit--insert-record record))))
    (goto-char (point-min))
    (when preserve-entry-id
      (magent-audit--goto-entry preserve-entry-id))
    (set-buffer-modified-p nil)
    buffer))

(defun magent-audit--insert-record (record)
  "Insert one audit RECORD into the current buffer."
  (let* ((entry-id (magent-audit--record-id record))
         (expanded (member entry-id magent-audit--expanded-ids))
         (start (point)))
    (insert (magent-audit--summary-line record expanded))
    (put-text-property start (point) 'magent-audit-entry-id entry-id)
    (put-text-property start (point) 'mouse-face 'highlight)
    (put-text-property start (point) 'keymap magent-audit-entry-map)
    (when expanded
      (let ((detail-start (point)))
        (insert (magent-audit--detail-block record))
        (put-text-property detail-start (point) 'magent-audit-entry-id entry-id)))
    (insert "\n")))

(defun magent-audit--summary-line (record expanded)
  "Return the one-line summary for audit RECORD.
When EXPANDED is non-nil, include the expanded marker."
  (let* ((timestamp (magent-audit--display-time (alist-get 'timestamp record)))
         (decision (alist-get 'decision record))
         (status (alist-get 'status record))
         (event (alist-get 'event record))
         (tool (alist-get 'tool_name record))
         (summary (or (alist-get 'summary record)
                      (alist-get 'title record)
                      (alist-get 'detail record)
                      (alist-get 'result_preview record)
                      ""))
         (marker (if expanded "[-]" "[+]"))
         (primary (or decision status event "record")))
    (concat
     (propertize marker 'face 'font-lock-comment-face)
     " "
     (propertize timestamp 'face 'font-lock-comment-face)
     " "
     (magent-audit--propertize-badge primary)
     (if event
         (concat " " (propertize event 'face 'font-lock-function-name-face))
       "")
     (if tool
         (concat " " (propertize tool 'face 'font-lock-variable-name-face))
       "")
     (if (string-empty-p summary)
         ""
       (concat " " summary))
     "\n")))

(defun magent-audit--detail-block (record)
  "Return the multi-line detail block for RECORD."
  (let ((lines nil))
    (dolist (field '(timestamp event agent scope project_root turn_id subagent_id
                               session_id request_id call_id tool_name perm_key
                               decision decision_source status title summary detail
                               args_preview result_preview))
      (when-let* ((value (alist-get field record)))
        (push (magent-audit--detail-line field value) lines)))
    (concat
     (mapconcat #'identity (nreverse lines) "\n")
     "\n")))

(defun magent-audit--detail-line (field value)
  "Return a formatted detail line for FIELD VALUE."
  (format "    %s: %s"
          (replace-regexp-in-string "_" "-" (symbol-name field))
          (magent-audit--format-value value)))

(defun magent-audit--format-value (value)
  "Return a printable value string for VALUE."
  (cond
   ((null value) "")
   ((stringp value) value)
   ((or (listp value) (vectorp value))
    (string-trim-right
     (replace-regexp-in-string
      "\n"
      "\n      "
      (pp-to-string value))))
   (t (format "%s" value))))

(defun magent-audit--display-time (timestamp)
  "Return a compact display string for TIMESTAMP."
  (if (and timestamp (>= (length timestamp) 19))
      (replace-regexp-in-string "T" " " (substring timestamp 0 19))
    (or timestamp "<no time>")))

(defun magent-audit--propertize-badge (text)
  "Return TEXT propertized as an audit badge."
  (let* ((upper (upcase text))
         (face (cond
                ((member text '("allow" "ok" "completed" "started"))
                 'success)
                ((member text '("deny" "error" "timeout" "dropped"))
                 'error)
                ((member text '("pending" "ask"))
                 'warning)
                (t 'font-lock-keyword-face))))
    (propertize (format "[%s]" upper) 'face face)))

(defun magent-audit--record-id (record)
  "Return a stable identifier for RECORD."
  (secure-hash 'sha1 (format "%S"
                             (list (alist-get 'timestamp record)
                                   (alist-get 'event record)
                                   (alist-get 'request_id record)
                                   (alist-get 'call_id record)
                                   (alist-get 'tool_name record)
                                   (alist-get 'summary record)
                                   (alist-get 'detail record)))))

(defun magent-audit--entry-id-at-point ()
  "Return the audit entry id at point, or nil."
  (or (get-text-property (point) 'magent-audit-entry-id)
      (and (not (bobp))
           (get-text-property (1- (point)) 'magent-audit-entry-id))))

(defun magent-audit--goto-entry (entry-id)
  "Move point to ENTRY-ID if present."
  (goto-char (point-min))
  (let ((found nil))
    (while (and (not found) (not (eobp)))
      (if (equal (get-text-property (point) 'magent-audit-entry-id) entry-id)
          (setq found t)
        (goto-char (or (next-single-property-change
                        (point) 'magent-audit-entry-id nil (point-max))
                       (point-max)))))
    found))

(defun magent-audit--header-line ()
  "Return the dynamic header line for the current audit buffer."
  (let* ((filters (magent-audit--active-filter-labels))
         (window (if (and (integerp magent-audit-default-days)
                          (> magent-audit-default-days 0))
                     (format "days=%d" magent-audit-default-days)
                   "days=all"))
         (counts (format "records %d/%d"
                         (length magent-audit--visible-records)
                         (length magent-audit--all-records)))
         (truncated (when (> magent-audit--truncated-count 0)
                      (format " truncated=%d" magent-audit--truncated-count)))
         (errors (when (> magent-audit--load-errors 0)
                   (format " parse-errors=%d" magent-audit--load-errors))))
    (string-join
     (delq nil
           (list "Audit"
                 counts
                 truncated
                 errors
                 window
                 (and filters (concat "filters " filters))
                 "keys g refresh c clear e event t tool d decision s status a agent RET details"))
     " | ")))

(defun magent-audit--active-filter-labels ()
  "Return a compact string describing active audit filters."
  (let ((filters magent-audit--filters)
        labels)
    (while filters
      (let ((key (pop filters))
            (value (pop filters)))
        (when value
          (push (format "%s=%s"
                        (substring (symbol-name key) 1)
                        value)
                labels))))
    (when labels
      (string-join (nreverse labels) " "))))

(provide 'magent-audit)
;;; magent-audit.el ends here
