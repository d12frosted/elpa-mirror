(define-package "keg" "20220305.1633" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "e915aba012ad1910ff5ad355de4414f9e1277d39" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
