;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20250217.2030"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.22.0")
    (spinner   "1.7.4")
    (transient "0.7")
    (compat    "29.1")
    (posframe  "1.4.0"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "8b6db08f89349ea56e17a04c01afcb3641f781be"
  :revdesc "8b6db08f8934"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
