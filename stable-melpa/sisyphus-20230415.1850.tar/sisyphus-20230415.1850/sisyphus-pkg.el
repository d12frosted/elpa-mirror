(define-package "sisyphus" "20230415.1850" "Create releases of Emacs packages"
  '((emacs "27.1")
    (compat "29.1.3.4")
    (elx "1.6.0")
    (llama "0.3.0")
    (magit "3.4.0"))
  :commit "c75298b35c40a2267e5b37689e4df7c8c970908b" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/sisyphus")
;; Local Variables:
;; no-byte-compile: t
;; End:
