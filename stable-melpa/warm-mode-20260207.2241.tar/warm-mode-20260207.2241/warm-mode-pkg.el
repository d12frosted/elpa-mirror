;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "warm-mode" "20260207.2241"
  "Warm colors for nighttime coding."
  '((emacs "27.1"))
  :url "https://github.com/smallwat3r/emacs-warm-mode"
  :commit "f609d2ad4c0af311162444a84f427c566802c0db"
  :revdesc "f609d2ad4c0a"
  :keywords '("faces" "convenience")
  :authors '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com"))
  :maintainers '(("Matthieu Petiteau" . "mpetiteau.pro@gmail.com")))
