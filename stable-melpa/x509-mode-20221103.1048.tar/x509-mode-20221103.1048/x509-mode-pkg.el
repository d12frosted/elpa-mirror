(define-package "x509-mode" "20221103.1048" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "a51b8aa4a96ed43463501b78835c670d28399ed3" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
