;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projection" "20250531.1124"
  "Project type support for `project'."
  '((emacs   "29.1")
    (project "0.9.8")
    (compat  "29.1.4.1")
    (f       "0.20")
    (s       "1.13"))
  :url "https://github.com/mohkale/projection"
  :commit "c92a64088947d2d7381a1a53b53473a89bc57e87"
  :revdesc "c92a64088947"
  :keywords '("project" "convenience")
  :authors '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@kisara.moe")))
