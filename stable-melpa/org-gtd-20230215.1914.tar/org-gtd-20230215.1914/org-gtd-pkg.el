(define-package "org-gtd" "20230215.1914" "An implementation of GTD."
  '((emacs "27.1")
    (org-edna "1.1.2")
    (f "0.20.0")
    (org "9.6")
    (org-agenda-property "1.3.1")
    (transient "0.3.7"))
  :commit "09601daa6eb872a67b22157a5c2b62917dea75b9" :authors
  '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainer
  '("Aldric Giacomoni" . "trevoke@gmail.com")
  :url "https://github.com/Trevoke/org-gtd.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
