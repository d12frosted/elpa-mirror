;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250419.225"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "a59461a41465c7db62af19d1d275e7602e7a7ba6"
  :revdesc "a59461a41465"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
