(define-package "folding" "20230919.1053" "A folding-editor-like minor mode." 'nil :commit "46ebc3ae256c3a76d83fa2ade4c372c0751c1922" :maintainers
  '(("Jari Aalto <jari aalto A T cante dt net>"))
  :maintainer
  '("Jari Aalto <jari aalto A T cante dt net>")
  :keywords
  '("tools"))
;; Local Variables:
;; no-byte-compile: t
;; End:
