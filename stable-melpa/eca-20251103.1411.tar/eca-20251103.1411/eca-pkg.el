;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251103.1411"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "eb8b1767082ee899a8d6a944ad7bf75dceb45a75"
  :revdesc "eb8b1767082e"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
