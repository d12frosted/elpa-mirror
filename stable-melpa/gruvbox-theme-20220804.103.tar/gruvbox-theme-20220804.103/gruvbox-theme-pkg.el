(define-package "gruvbox-theme" "20220804.103" "A retro-groove colour theme for Emacs"
  '((autothemer "0.2"))
  :commit "6c54b1f453dca09e5800da5fbce7153c26dc6b82" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "http://github.com/greduan/emacs-theme-gruvbox")
;; Local Variables:
;; no-byte-compile: t
;; End:
