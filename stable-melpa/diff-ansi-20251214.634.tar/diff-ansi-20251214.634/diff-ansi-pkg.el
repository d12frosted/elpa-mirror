;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-ansi" "20251214.634"
  "Display diff's using alternative diffing tools."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-diff-ansi"
  :commit "fc37833b19478a8c56bc883fde76b6eefb72ac98"
  :revdesc "fc37833b1947"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
