;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260522.1501"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "55965656d51ee23f70ec87fe3998a6e5021bfb2e"
  :revdesc "55965656d51e"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
