;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20261106.647"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "2c85a07409957627a6660c88407a21f3e4272db9"
  :revdesc "2c85a0740995"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
