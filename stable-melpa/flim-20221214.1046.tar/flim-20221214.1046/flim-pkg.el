(define-package "flim" "20221214.1046" "A library to provide basic features about message representation or encoding."
  '((emacs "24.5")
    (apel "10.8")
    (oauth2 "0.11"))
  :commit "3a931b566494e7dc210a5109b60c8cbd5b655108")
;; Local Variables:
;; no-byte-compile: t
;; End:
