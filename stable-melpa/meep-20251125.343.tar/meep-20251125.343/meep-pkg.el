;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251125.343"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "28355dbb7c95e72c262e7243d8807e8430be0976"
  :revdesc "28355dbb7c95"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
