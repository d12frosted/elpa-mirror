(define-package "go-translate" "20221110.1618" "Translation framework supports multiple engines such as Google/Bing/DeepL"
  '((emacs "27.1"))
  :commit "92cdb7c878eec96531b900f01075f67b885e50e3" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
