(define-package "tsc" "20201229.1403" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "a7036676de3ba35b93346f5325ed568240c1ef58" :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
   ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  ("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
