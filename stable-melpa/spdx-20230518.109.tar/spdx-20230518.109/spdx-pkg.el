(define-package "spdx" "20230518.109" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "c31e3eab09754bd843d1c9c55152121d1f4e9383" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
