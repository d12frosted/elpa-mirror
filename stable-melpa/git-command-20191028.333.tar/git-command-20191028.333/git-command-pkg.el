;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-command" "20191028.333"
  "A Git Command-Line interface."
  '((term-run    "0.1.4")
    (with-editor "2.3.1"))
  :url "https://github.com/10sr/git-command-el"
  :commit "a773d40da39dfb1c6ecf2b0758aa370ddea8f06d"
  :revdesc "a773d40da39d"
  :keywords '("utility" "git")
  :authors '(("10sr" . "8slashes+el[at]gmail[dot]com"))
  :maintainers '(("10sr" . "8slashes+el[at]gmail[dot]com")))
