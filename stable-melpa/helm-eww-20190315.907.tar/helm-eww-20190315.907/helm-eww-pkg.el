;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-eww" "20190315.907"
  "Helm UI wrapper for EWW."
  '((emacs "24.4")
    (helm  "2.8.6")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-eww"
  :commit "76ba59fda8dd6f32a1bc7c6df0b43c6f76169911"
  :revdesc "76ba59fda8dd"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
