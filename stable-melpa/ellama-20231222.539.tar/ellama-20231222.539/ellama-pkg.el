(define-package "ellama" "20231222.539" "Tool for interacting with LLMs"
  '((emacs "28.1")
    (llm "0.6.0")
    (spinner "1.7.4"))
  :commit "931aff60da5cbf84cb11e3cb138d10784f7a6ecb" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
