(define-package "json-par" "20220122.352" "Minor mode for structural editing of JSON"
  '((emacs "24.4")
    (json-mode "1.7.0"))
  :commit "962e5a2221136aa07f512834925c381cfeed2d92" :authors
  '(("taku0 (http://github.com/taku0)"))
  :maintainer
  '("taku0 (http://github.com/taku0)")
  :keywords
  '("abbrev" "convenience" "files")
  :url "https://github.com/taku0/json-par")
;; Local Variables:
;; no-byte-compile: t
;; End:
