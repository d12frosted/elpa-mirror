(define-package "stgit" "20230819.2343" "major mode for StGit interaction" 'nil :commit "505ddcd2f01b563187da5f901da1fc9825e797b3" :authors
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainers
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainer
  '("David Kågedal" . "davidk@lysator.liu.se")
  :url "http://stacked-git.github.io")
;; Local Variables:
;; no-byte-compile: t
;; End:
