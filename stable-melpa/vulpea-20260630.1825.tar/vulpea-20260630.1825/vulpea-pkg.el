;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260630.1825"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "65572ce76d6ed3ed1a8d853b165688626930a373"
  :revdesc "65572ce76d6e"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
