(define-package "yasnippet" "20240101.2117" "Yet another snippet extension for Emacs"
  '((cl-lib "0.5")
    (emacs "24.4"))
  :commit "b86b44cce66f2a6a9994888dd0b7b8a89c898c83" :maintainers
  '(("Noam Postavsky" . "npostavs@gmail.com"))
  :maintainer
  '("Noam Postavsky" . "npostavs@gmail.com")
  :keywords
  '("convenience" "emulation")
  :url "http://github.com/joaotavora/yasnippet")
;; Local Variables:
;; no-byte-compile: t
;; End:
