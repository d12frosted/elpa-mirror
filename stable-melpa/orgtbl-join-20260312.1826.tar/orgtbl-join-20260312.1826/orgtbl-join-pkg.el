;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260312.1826"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "837155efe2c107e92d4c62701fffb7c0416fa4f4"
  :revdesc "837155efe2c1"
  :keywords '("data" "extensions"))
