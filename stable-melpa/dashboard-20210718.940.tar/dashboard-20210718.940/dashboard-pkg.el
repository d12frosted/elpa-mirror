(define-package "dashboard" "20210718.940" "A startup screen extracted from Spacemacs"
  '((emacs "25.3"))
  :commit "88c9ac06f2f943605414ab35176f3730a252b3a4" :authors
  '(("Rakan Al-Hneiti"))
  :maintainer
  '("Rakan Al-Hneiti")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
