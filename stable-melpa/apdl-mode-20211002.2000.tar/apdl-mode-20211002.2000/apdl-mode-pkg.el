(define-package "apdl-mode" "20211002.2000" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "3a4c6b3650a106f5e4d5118145999ef4ad09df0d" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
