(define-package "embark" "20210221.1716" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "68b220c362023f8e1cb754e53db292cdeaab7fa5" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
