;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20261124.2229"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "1e647428f63032aafc46d949b7c407d58555b988"
  :revdesc "1e647428f630"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
