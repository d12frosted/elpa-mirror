(define-package "mybigword" "20221208.1243" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "26.1")
    (avy "0.5.0"))
  :commit "a7d6f5f91d87e89b8fb6c788077abcdbb552d26b" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
