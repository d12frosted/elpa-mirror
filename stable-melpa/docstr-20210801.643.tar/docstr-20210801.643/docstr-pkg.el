(define-package "docstr" "20210801.643" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "18266d097a760e0378414659969980bd67d36381" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
