;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250325.1543"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "afbc23a0e239091e36b0917c00bf3fef30b84887"
  :revdesc "afbc23a0e239"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
