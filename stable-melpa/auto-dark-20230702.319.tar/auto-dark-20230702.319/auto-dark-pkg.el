(define-package "auto-dark" "20230702.319" "Automatically sets the dark-mode theme based on macOS/Linux/Windows status"
  '((emacs "24.4"))
  :commit "af19a779c6df1e371d26e4092e6a2113ad1f44cd" :authors
  '(("Rahul M. Juliato")
    ("Tim Harper <timcharper at gmail dot com>")
    ("Vincent Zhang" . "seagle0128@gmail.com")
    ("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers
  '(("Rahul M. Juliato"))
  :maintainer
  '("Rahul M. Juliato")
  :keywords
  '("macos" "windows" "linux" "themes" "tools" "faces")
  :url "https://github.com/LionyxML/auto-dark-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
