(define-package "eproject" "20180312.1642" "assign files to projects, programatically"
  '((helm "1.6.4"))
  :commit "068218d2cf2138cb2e8fc29b57e773a0097a7e8b" :keywords
  ("programming" "projects")
  :authors
  (("Jonathan Rockway" . "jon@jrock.us"))
  :maintainer
  ("Jonathan Rockway" . "jon@jrock.us"))
;; Local Variables:
;; no-byte-compile: t
;; End:
