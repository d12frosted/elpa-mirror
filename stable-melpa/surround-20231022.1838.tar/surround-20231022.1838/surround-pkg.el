(define-package "surround" "20231022.1838" "Easily add/delete/change parens, quotes, and more"
  '((emacs "24.3"))
  :commit "b75abfaf3e157d232c10e09cd6316a0ad92d2468" :authors
  '(("Michael Kleehammer" . "michael@kleehammer.com"))
  :maintainers
  '(("Michael Kleehammer" . "michael@kleehammer.com"))
  :maintainer
  '("Michael Kleehammer" . "michael@kleehammer.com")
  :url "https://github.com/mkleehammer/surround")
;; Local Variables:
;; no-byte-compile: t
;; End:
