;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calc-at-point" "20210219.1252"
  "Perform calculations at point or over selection."
  '((emacs "26")
    (dash  "2.18.0"))
  :url "https://github.com/walseb/calc-at-point"
  :commit "0c1a9e94b519b0edb0abcbacdf6101eea2f2a524"
  :revdesc "0c1a9e94b519"
  :keywords '("convenience")
  :authors '(("Sebastian Wålinder" . "s.walinder@gmail.com"))
  :maintainers '(("Sebastian Wålinder" . "s.walinder@gmail.com")))
