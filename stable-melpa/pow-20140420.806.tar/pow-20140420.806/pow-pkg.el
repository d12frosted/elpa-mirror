(define-package "pow" "20140420.806" "pow (http://pow.cx/) manager for emacs"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "782532d5d3582fe8fd67014507b20077f3f2d292" :authors
  '(("yukihiro hara" . "yukihr@gmail.com"))
  :maintainer
  '("yukihiro hara" . "yukihr@gmail.com")
  :keywords
  '("develop" "web" "pow")
  :url "http://github.com/yukihr/emacs-pow")
;; Local Variables:
;; no-byte-compile: t
;; End:
