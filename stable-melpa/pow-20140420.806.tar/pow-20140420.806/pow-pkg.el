(define-package "pow" "20140420.806" "pow (http://pow.cx/) manager for emacs"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "ea83986b8ca8e27cb996290d6463b111ec0966ce" :keywords
  ("develop" "web" "pow")
  :authors
  (("yukihiro hara" . "yukihr@gmail.com"))
  :maintainer
  ("yukihiro hara" . "yukihr@gmail.com")
  :url "http://github.com/yukihr/emacs-pow")
;; Local Variables:
;; no-byte-compile: t
;; End:
