(define-package "pet" "20230705.2132" "Executable and virtualenv tracker for python-mode"
  '((emacs "26.1")
    (f "0.6.0"))
  :commit "4f5ca245531053f10ea234bc5e95fc7efcabe251" :authors
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers
  '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainer
  '("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/wyuenho/emacs-pet/")
;; Local Variables:
;; no-byte-compile: t
;; End:
