;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20261030.1739"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "0f55f166c3dfbd30146a6381465f71966e29a288"
  :revdesc "0f55f166c3df"
  :keywords '("convenience" "files" "tools"))
