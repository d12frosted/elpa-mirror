(define-package "ebib" "20221107.2019" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "26.1"))
  :commit "6c09bc39b4a7ae70de5c1ce912d693e8b6f5f8d1" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
