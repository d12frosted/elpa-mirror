;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250520.1248"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "a8f72b70540f933b1204ad5ae64b038b78aae7b8"
  :revdesc "a8f72b70540f"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
