(define-package "friendly-remote-shell" "20200828.1218" "Human-friendly remote interactive shells"
  '((emacs "24.1")
    (cl-lib "0.6.1")
    (with-shell-interpreter "0.2.3")
    (friendly-tramp-path "0.1.0")
    (friendly-shell "0.2.0"))
  :commit "1b1ba2033e59e5968380640280bd853701fbbb21" :keywords
  '("processes" "terminals")
  :url "https://github.com/p3r7/friendly-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
