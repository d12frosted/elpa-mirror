;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "etd" "20230711.547"
  "Examples to Tests and Docs."
  '((emacs "24.4"))
  :url "https://github.com/emacsfodder/kurecolor"
  :commit "65f713935c9d2598f6fa4674bf2bdac2169005a9"
  :revdesc "65f713935c9d"
  :keywords '("lisp" "tools" "extensions")
  :authors '(("Jason M23" . "jasonm23@gmail.com"))
  :maintainers '(("Jason M23" . "jasonm23@gmail.com")))
