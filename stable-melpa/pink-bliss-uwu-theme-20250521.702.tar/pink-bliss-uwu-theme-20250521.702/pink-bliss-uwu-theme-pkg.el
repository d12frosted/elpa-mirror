;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pink-bliss-uwu-theme" "20250521.702"
  "Pink color theme."
  '((emacs "24.1"))
  :url "https://github.com/themkat/pink-bliss-uwu"
  :commit "a70bda02873203cc6a464f0f45cc73c12df7b425"
  :revdesc "a70bda028732")
