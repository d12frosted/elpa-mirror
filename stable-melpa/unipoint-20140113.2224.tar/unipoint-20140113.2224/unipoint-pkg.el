;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unipoint" "20140113.2224"
  "A simple way to insert unicode characters by TeX name."
  ()
  :url "https://github.com/apgwoz/unipoint"
  :commit "5da04aebac35a5c9e1d8704f2231808d42f4b36a"
  :revdesc "5da04aebac35"
  :authors '(("Andrew Gwozdziewycz" . "git@apgwoz.com"))
  :maintainers '(("Andrew Gwozdziewycz" . "git@apgwoz.com")))
