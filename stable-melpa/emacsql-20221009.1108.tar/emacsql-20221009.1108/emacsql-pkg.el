(define-package "emacsql" "20221009.1108" "High-level SQL database front-end"
  '((emacs "25.1"))
  :commit "20cdad6fe6d7ada00cd74b096fe5208e37e6ce5c" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
