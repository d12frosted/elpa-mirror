;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "webkit-color-picker" "20180325.736"
  "Insert and adjust colors using Webkit Widgets."
  '((emacs    "26.0")
    (posframe "0.1.0"))
  :url "https://github.com/osener/emacs-webkit-color-picker"
  :commit "765cac80144cad4bc0bf59025ea0199f0486f737"
  :revdesc "765cac80144c"
  :keywords '("tools")
  :authors '(("Ozan Sener" . "hi@ozan.email"))
  :maintainers '(("Ozan Sener" . "hi@ozan.email")))
