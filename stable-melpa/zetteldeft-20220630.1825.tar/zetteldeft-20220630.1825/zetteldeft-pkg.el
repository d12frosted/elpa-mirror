(define-package "zetteldeft" "20220630.1825" "Turn deft into a zettelkasten system"
  '((emacs "25.1")
    (deft "0.8")
    (ace-window "0.7.0"))
  :commit "40fe8845ea48c7a6a81ea2771962cd810f789406" :authors
  '(("EFLS <Elias Storms>"))
  :maintainer
  '("EFLS <Elias Storms>")
  :keywords
  '("deft" "zettelkasten" "zetteldeft" "wp" "files")
  :url "https://efls.github.io/zetteldeft/")
;; Local Variables:
;; no-byte-compile: t
;; End:
