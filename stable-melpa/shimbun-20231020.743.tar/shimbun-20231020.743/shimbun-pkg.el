(define-package "shimbun" "20231020.743" "interfacing with web newspapers" 'nil :commit "622038d8e24c542f29bccde2db84a6a6d6af19a2" :authors
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
    ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
    ("Yuuichi Teranishi " . "teranisi@gohome.org")
    ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainers
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org"))
  :maintainer
  '("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  '("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
