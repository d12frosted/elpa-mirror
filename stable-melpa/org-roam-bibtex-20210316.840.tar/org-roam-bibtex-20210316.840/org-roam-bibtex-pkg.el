(define-package "org-roam-bibtex" "20210316.840" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "1.2.2")
    (bibtex-completion "2.0.0"))
  :commit "042db4d92a8e70a0d868c0305ac18b3f712de1d7" :authors
  '(("Leo Vivier" . "leo.vivier+dev@gmail.com")
    ("Mykhailo Shevchuk" . "mail@mshevchuk.com"))
  :maintainer
  '("Leo Vivier" . "leo.vivier+dev@gmail.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
