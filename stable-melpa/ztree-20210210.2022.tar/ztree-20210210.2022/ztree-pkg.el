(define-package "ztree" "20210210.2022" "Text mode directory tree"
  '((cl-lib "0"))
  :commit "6eee81d2691009ce60b2edf7c298b227caf1b0d6" :authors
  '(("Alexey Veretennikov" . "alexey.veretennikov@gmail.com"))
  :maintainer
  '("Alexey Veretennikov" . "alexey.veretennikov@gmail.com")
  :keywords
  '("files" "tools")
  :url "https://github.com/fourier/ztree")
;; Local Variables:
;; no-byte-compile: t
;; End:
