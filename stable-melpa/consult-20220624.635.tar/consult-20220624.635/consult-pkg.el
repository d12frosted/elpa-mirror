(define-package "consult" "20220624.635" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "5b7cdb19024857037663e27a4855921e4f368426" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
