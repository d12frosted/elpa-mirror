;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-sonarlint" "20260507.1751"
  "Emacs SonarLint lsp client."
  '((emacs    "29.1")
    (dash     "2.12.0")
    (lsp-mode "6.3")
    (ht       "2.3"))
  :url "https://github.com/emacs-lsp/lsp-sonarlint"
  :commit "91794c7663fc24afd8d93a74e775793de8f2f811"
  :revdesc "91794c7663fc"
  :keywords '("languages" "tools" "php" "javascript" "typescript" "go" "xml" "html" "java" "python")
  :authors '(("Fermin MF" . "fmfs@posteo.net"))
  :maintainers '(("Fermin MF" . "fmfs@posteo.net")))
