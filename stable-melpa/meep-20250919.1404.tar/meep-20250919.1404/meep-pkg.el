;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250919.1404"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "98ead6a2d2407a06a9dfd9448091235e6b05f0c3"
  :revdesc "98ead6a2d240"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
