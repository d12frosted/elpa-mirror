(define-package "humanoid-themes" "20210721.2022" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "d140638360a3eb1bf8f17877bd888f898df63ec0" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
