(define-package "humanoid-themes" "20210721.2022" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "727a7395fcb75b889059d37ede008935623fe919" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
