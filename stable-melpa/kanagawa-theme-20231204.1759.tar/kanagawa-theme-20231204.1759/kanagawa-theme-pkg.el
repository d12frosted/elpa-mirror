(define-package "kanagawa-theme" "20231204.1759" "An elegant theme inspired by The Great Wave off Kanagawa by Katsushika Hokusa"
  '((emacs "24.3"))
  :commit "f0bc41223584973e24bdf7cd97c2ea61384df0af" :authors
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainers
  '(("Meritamen" . "meritamen@sdf.org"))
  :maintainer
  '("Meritamen" . "meritamen@sdf.org")
  :keywords
  '("themes" "faces")
  :url "https://github.com/Meritamen/kanagawa-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
