(define-package "autoscratch" "20230605.617" "Automatically switch scratch buffer mode"
  '((emacs "24.1"))
  :commit "350a27e5d271dbbb81bcd7509f559eb809853d60" :authors
  '(("T.v.Dein" . "tlinden@cpan.org"))
  :maintainers
  '(("T.v.Dein" . "tlinden@cpan.org"))
  :maintainer
  '("T.v.Dein" . "tlinden@cpan.org")
  :keywords
  '("convenience" "buffer" "scrach")
  :url "https://github.com/tlinden/autoscratch")
;; Local Variables:
;; no-byte-compile: t
;; End:
