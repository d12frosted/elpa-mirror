(define-package "spdx" "20230612.123" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "e7e87438656761e3a9ec585e7e59f5046686c472" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
