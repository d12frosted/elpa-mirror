;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20250715.1550"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "eff827c2616a10f70fbee8c31623b01169d8d81f"
  :revdesc "eff827c2616a"
  :keywords '("convenience"))
