;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacemacs-theme" "20250603.1705"
  "Color theme with a dark and light versions."
  ()
  :url "https://github.com/nashamri/spacemacs-theme"
  :commit "6811b68da63905391fe4dee60ebed9e787688e5e"
  :revdesc "6811b68da639"
  :keywords '("color" "theme"))
