;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260406.1740"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "579d9d3802ad449724db7649b90cf3593be92a75"
  :revdesc "579d9d3802ad"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
