;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20250930.1310"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "f66b80c6ee570471c8eca89ec84f6391b64a7b51"
  :revdesc "f66b80c6ee57"
  :keywords '("calendar" "holidays"))
