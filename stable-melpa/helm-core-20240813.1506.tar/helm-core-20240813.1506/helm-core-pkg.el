(define-package "helm-core" "20240813.1506" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.8"))
  :commit "1714c2818dc0c51c99f7c7eee972e917c75e5083" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
