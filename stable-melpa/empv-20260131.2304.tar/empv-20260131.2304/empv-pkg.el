;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260131.2304"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "40c9c0e64d892aff1331ea3c059dd1efda686c15"
  :revdesc "40c9c0e64d89"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
