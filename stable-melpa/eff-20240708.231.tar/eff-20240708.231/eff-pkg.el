;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eff" "20240708.231"
  "Show symbols in Executable File Formats."
  '((emacs "28"))
  :url "https://github.com/oxidase/eff"
  :commit "b8298439360b29333d3dcd8a352e00cde2b6ccd7"
  :revdesc "b8298439360b"
  :keywords '("elf" "readelf" "convenience"))
