(define-package "proof-general" "20220329.655" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "a894bcc5f915f1c76a2a83c12c12ea3497542426" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
