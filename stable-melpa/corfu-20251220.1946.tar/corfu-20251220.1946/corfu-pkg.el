;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251220.1946"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "d7a1cd6be27ef9aadd308cb20ee4e4602233a299"
  :revdesc "d7a1cd6be27e"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
