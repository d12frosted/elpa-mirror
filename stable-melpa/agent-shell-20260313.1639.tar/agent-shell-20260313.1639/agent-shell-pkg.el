;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260313.1639"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b3e556c9eaf8663a37673bd6845b2707b8b97201"
  :revdesc "b3e556c9eaf8")
