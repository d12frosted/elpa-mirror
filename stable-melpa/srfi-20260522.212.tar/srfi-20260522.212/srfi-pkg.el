;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260522.212"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "8b94d0f8fad2614eb6f17b0bcd8902224041c82a"
  :revdesc "8b94d0f8fad2"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
