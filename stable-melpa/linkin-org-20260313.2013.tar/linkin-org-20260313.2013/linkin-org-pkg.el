;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linkin-org" "20260313.2013"
  "A workflow with fast, reliable links."
  '((emacs "30.1"))
  :url "https://github.com/Judafa/linkin-org"
  :commit "daab39c4e3dc5d77c55630e26f8b0339ae218dd1"
  :revdesc "daab39c4e3dc"
  :authors '(("Julien Dallot" . "judafa@protonmail.com"))
  :maintainers '(("Julien Dallot" . "judafa@protonmail.com")))
