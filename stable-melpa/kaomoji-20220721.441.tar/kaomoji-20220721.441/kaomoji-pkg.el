;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kaomoji" "20220721.441"
  "Input kaomoji superb easily."
  '((emacs     "24.3")
    (helm-core "3.6.0"))
  :url "https://github.com/kuanyui/kaomoji.el"
  :commit "fba0018a13eba70c2bffc6153dcfee99937fa3d6"
  :revdesc "fba0018a13eb"
  :keywords '("tools" "fun")
  :authors '(("Ono Hiroko" . "azazabc123@gmail.com"))
  :maintainers '(("Ono Hiroko" . "azazabc123@gmail.com")))
