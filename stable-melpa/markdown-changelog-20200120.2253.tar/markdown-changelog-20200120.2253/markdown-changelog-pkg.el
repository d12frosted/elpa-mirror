(define-package "markdown-changelog" "20200120.2253" "Maintain changelog entries"
  '((emacs "26")
    (dash "2.13.0"))
  :commit "1a2c3a4c3e4196f2b5dbb145b01b4bc435a93a96" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("markdown" "changelog" "files")
  :url "https://github.com/plandes/markdown-changelog")
;; Local Variables:
;; no-byte-compile: t
;; End:
