(define-package "loopy" "20210811.244" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "c37b669a12337fa04c3dad96bd52e9ae961f14e8" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
