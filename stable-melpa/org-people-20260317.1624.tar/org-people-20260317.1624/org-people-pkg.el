;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260317.1624"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "e16aff3f3a8de78cb8659229722e7aaf6c8c7433"
  :revdesc "e16aff3f3a8d"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
