;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20261128.1851"
  "Advent of Code mode."
  '((emacs "30.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "fd0711258007b9c2a1b95bc6fcb87e8010d796f9"
  :revdesc "fd0711258007"
  :keywords '("tools")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
