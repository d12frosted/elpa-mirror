(define-package "gams-mode" "20230914.441" "Major mode for General Algebraic Modeling System (GAMS)"
  '((emacs "24.3"))
  :commit "41ee0598ddebac17dc93335abe157f22b22ffa6d" :authors
  '(("Shiro Takeda"))
  :maintainers
  '(("Shiro Takeda"))
  :maintainer
  '("Shiro Takeda")
  :keywords
  '("languages" "tools" "gams")
  :url "http://shirotakeda.org/en/gams/gams-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
