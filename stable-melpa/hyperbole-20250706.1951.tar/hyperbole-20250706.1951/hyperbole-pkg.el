;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250706.1951"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "7fd90d5e192223ec0cbfe40b12d57875b8731afb"
  :revdesc "7fd90d5e1922"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
