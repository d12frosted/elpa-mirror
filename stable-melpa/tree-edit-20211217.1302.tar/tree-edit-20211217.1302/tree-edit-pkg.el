(define-package "tree-edit" "20211217.1302" "A library for structural refactoring and editing"
  '((emacs "27.1")
    (tree-sitter "0.15.0")
    (tsc "0.15.0")
    (tree-sitter-langs "0.10.0")
    (dash "2.19")
    (reazon "0.4.0")
    (s "0.0.0"))
  :commit "ceae46cc78958fe96bac521a8e2969148f8aacca" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
