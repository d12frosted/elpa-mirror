;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20251114.319"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/casual"
  :commit "ce236e17eb099255f8bf3c8782b920f7346c15d1"
  :revdesc "ce236e17eb09"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
