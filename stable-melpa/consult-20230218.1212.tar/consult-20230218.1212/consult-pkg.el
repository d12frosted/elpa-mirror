(define-package "consult" "20230218.1212" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "ffaaf6da909dc9ff766e5a5f16eb265635aa6149" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
