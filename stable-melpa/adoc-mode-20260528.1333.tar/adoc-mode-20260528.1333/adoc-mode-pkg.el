;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260528.1333"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "96dedb7a3151e233cd4c388f5cb30c068c6f7629"
  :revdesc "96dedb7a3151"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
