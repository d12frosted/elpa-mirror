;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241202.105"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "809b059dd412c19ecd3a3578f422900e3402069c"
  :revdesc "809b059dd412"
  :keywords '("convenience" "modal-editing"))
