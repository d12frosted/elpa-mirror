(define-package "webdriver" "20231012.1205" "WebDriver local end implementation"
  '((emacs "27.1"))
  :commit "98317be11ae87e7eac11df5d58f8c2b5366fa19b" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/mauroaranda/emacs-webdriver")
;; Local Variables:
;; no-byte-compile: t
;; End:
