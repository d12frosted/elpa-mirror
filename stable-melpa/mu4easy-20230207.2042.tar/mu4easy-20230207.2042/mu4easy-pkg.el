(define-package "mu4easy" "20230207.2042" "Packages + configs for using mu4e with multiple accounts"
  '((emacs "25.1")
    (mu4e-column-faces "1.2.1")
    (mu4e-alert "1.0")
    (helm-mu "1.0.0")
    (org-msg "4.0"))
  :commit "34565ddb9fc74675b28ce19694485cf2e91eba20" :authors
  '(("Daniel Fleischer" . "danflscr@gmail.com"))
  :maintainers
  '(("Daniel Fleischer" . "danflscr@gmail.com"))
  :maintainer
  '("Daniel Fleischer" . "danflscr@gmail.com")
  :keywords
  '("mail")
  :url "https://github.com/danielfleischer/mu4easy")
;; Local Variables:
;; no-byte-compile: t
;; End:
