(define-package "chronometrist-spark" "20220321.349" "Show sparklines in Chronometrist buffers"
  '((emacs "25.1")
    (chronometrist "0.7.0")
    (spark "0.1"))
  :commit "19624f0edc663f5cb29464e3fc82ea398d6f860a" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
