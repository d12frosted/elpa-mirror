(define-package "chronometrist-spark" "20220321.349" "Show sparklines in Chronometrist buffers"
  '((emacs "25.1")
    (chronometrist "0.7.0")
    (spark "0.1"))
  :commit "05514a014f2f4bf261a3d4ac0992a9cdfa2f515e" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
