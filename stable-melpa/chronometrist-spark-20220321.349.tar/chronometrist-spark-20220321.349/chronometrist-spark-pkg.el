(define-package "chronometrist-spark" "20220321.349" "Show sparklines in Chronometrist buffers"
  '((emacs "25.1")
    (chronometrist "0.7.0")
    (spark "0.1"))
  :commit "c5d5ba419e7024f4152e141232e948267337d6ca" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
