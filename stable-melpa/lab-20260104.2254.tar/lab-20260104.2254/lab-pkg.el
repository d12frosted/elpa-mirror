;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "20260104.2254"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "a7c696defe68c171b679a877737921c963629048"
  :revdesc "a7c696defe68"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
