(define-package "embark-consult" "20230613.654" "Consult integration for Embark"
  '((emacs "27.1")
    (embark "0.20")
    (consult "0.17"))
  :commit "c5ac899d87992c4206a9a01e6355369d088b9f75" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
