(define-package "magithub" "20190512.2316" "Magit interfaces for GitHub"
  '((emacs "25")
    (magit "2.12")
    (s "1.12.0")
    (ghub+ "0.3")
    (git-commit "2.12")
    (markdown-mode "2.3"))
  :commit "b75bb92eb5defeb358aac09bc50f6067e3c1d250" :authors
  '(("Sean Allred" . "code@seanallred.com"))
  :maintainer
  '("Sean Allred" . "code@seanallred.com")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/vermiculus/magithub")
;; Local Variables:
;; no-byte-compile: t
;; End:
