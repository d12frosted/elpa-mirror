(define-package "darktooth-theme" "20220923.347" "From the darkness... it watches"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "c64c1dd0e2364197ca9ac6410392eade27a55909" :url "http://github.com/emacsfodder/emacs-theme-darktooth")
;; Local Variables:
;; no-byte-compile: t
;; End:
