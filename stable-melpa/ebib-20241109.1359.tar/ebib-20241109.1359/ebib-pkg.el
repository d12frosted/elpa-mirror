;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebib" "20241109.1359"
  "A BibTeX database manager."
  '((parsebib "6.0")
    (emacs    "27.1")
    (compat   "29.1.4.3"))
  :url "https://github.com/joostkremers/ebib"
  :commit "25eee3752d82a4375c448acd7f242b6ebaacc5a1"
  :revdesc "25eee3752d82"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
