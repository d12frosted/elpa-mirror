;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260802.848"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "1c4f76a6645df5636070ce0d481648dd31d7409c"
  :revdesc "1c4f76a6645d"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
