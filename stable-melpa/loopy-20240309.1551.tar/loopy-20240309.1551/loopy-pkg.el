(define-package "loopy" "20240309.1551" "A looping macro"
  '((emacs "27.1")
    (map "3.3.1")
    (seq "2.22")
    (compat "29.1.3"))
  :commit "395885b322975ef9ae4a4c7fcb14640a41c52562" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
