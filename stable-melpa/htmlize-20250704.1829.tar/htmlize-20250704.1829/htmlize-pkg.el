;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "htmlize" "20250704.1829"
  "Convert buffer text and decorations to HTML."
  '((emacs "26.1"))
  :url "https://github.com/emacsorphanage/htmlize"
  :commit "3bd98f29e83e971239ede8b7bda211ee125237d0"
  :revdesc "3bd98f29e83e"
  :keywords '("hypermedia" "extensions")
  :authors '(("Hrvoje Niksic" . "hniksic@gmail.com"))
  :maintainers '(("Hrvoje Niksic" . "hniksic@gmail.com")))
