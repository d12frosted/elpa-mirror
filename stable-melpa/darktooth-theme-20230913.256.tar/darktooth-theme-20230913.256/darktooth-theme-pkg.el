(define-package "darktooth-theme" "20230913.256" "From the darkness... it watches"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "ac7c3a2322648b6338c93f01a0038007bedc7680" :url "http://github.com/emacsfodder/emacs-theme-darktooth")
;; Local Variables:
;; no-byte-compile: t
;; End:
