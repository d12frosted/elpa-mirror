;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260802.1034"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazelbuild/emacs-bazel-mode"
  :commit "c8d1e64ab10b10b7c58ae0995402a50dd2960f40"
  :revdesc "c8d1e64ab10b"
  :keywords '("build tools" "languages"))
