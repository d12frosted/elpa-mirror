(define-package "embark" "20230218.2115" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "f2d59df788c74d185b4076a200a3334e724772e2" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
