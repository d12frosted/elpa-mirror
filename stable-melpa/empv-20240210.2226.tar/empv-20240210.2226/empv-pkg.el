(define-package "empv" "20240210.2226" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0")
    (compat "29.1.4.4"))
  :commit "4d02eaae506f6988856e894c9b405dadd2d3f427" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
