(define-package "clojure-ts-mode" "20230828.1657" "Major mode for Clojure code"
  '((emacs "29"))
  :commit "d630cd63af8022d5a1fee0e7aa05450b6e0fd75e" :maintainers
  '(("Danny Freeman" . "danny@dfreeman.email"))
  :maintainer
  '("Danny Freeman" . "danny@dfreeman.email")
  :keywords
  '("languages" "clojure" "clojurescript" "lisp")
  :url "http://github.com/clojure-emacs/clojure-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
