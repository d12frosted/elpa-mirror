(define-package "consult" "20230126.1037" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "073713645867a8b7de7703e91411875e073c9292" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
