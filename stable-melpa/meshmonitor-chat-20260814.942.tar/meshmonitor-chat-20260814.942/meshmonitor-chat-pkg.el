;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meshmonitor-chat" "20260814.942"
  "Chat client for MeshMonitor (Meshtastic)."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/meshmonitor-chat.el"
  :commit "398a33e0cece33a1ca978d98497bef9bd9013f8d"
  :revdesc "398a33e0cece"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
