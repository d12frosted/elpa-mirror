(define-package "tmsu" "20230308.1935" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "edad2cb7ff14d6dda6f98c2c21a134572fcfec8c" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
