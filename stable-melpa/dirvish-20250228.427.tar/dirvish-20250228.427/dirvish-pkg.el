;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250228.427"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "2781c59ecbbe6aeb75f68129e1ae6d374305f3b1"
  :revdesc "2781c59ecbbe"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
