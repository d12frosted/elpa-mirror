;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250423.1010"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "7d05492e1b70df006c84b9ef64f4d77c43ddec88"
  :revdesc "7d05492e1b70"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
