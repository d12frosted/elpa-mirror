;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260202.929"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "d3cf4d16dd9d7e6832bd538d2bab41f1210a6c16"
  :revdesc "d3cf4d16dd9d"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
