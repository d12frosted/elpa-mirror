(define-package "websearch" "20220815.2237" "Query search engines"
  '((emacs "24.4"))
  :commit "4904103478aa0aefbbb225182c9a9a58306ea406" :authors
  '(("Maciej Barć" . "xgqt@riseup.net"))
  :maintainer
  '("Maciej Barć" . "xgqt@riseup.net")
  :keywords
  '("convenience" "hypermedia")
  :url "https://gitlab.com/xgqt/emacs-websearch/")
;; Local Variables:
;; no-byte-compile: t
;; End:
