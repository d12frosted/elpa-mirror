(define-package "typit" "20200217.2059" "Typing game similar to tests on 10 fast fingers"
  '((emacs "24.4")
    (f "0.18")
    (mmt "0.1.1"))
  :commit "3e64bfcdbd6a5d3d5a0d168f7cde782a1e6b1016" :authors
  '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainer
  '("Mark Karpov" . "markkarpov92@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/mrkkrp/typit")
;; Local Variables:
;; no-byte-compile: t
;; End:
