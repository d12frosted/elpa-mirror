(define-package "swift-helpful" "20210402.1934" "Show documentation for Swift programs."
  '((emacs "25.1")
    (dash "2.12.0")
    (lsp-mode "6.0")
    (swift-mode "8.0.0"))
  :commit "bcaa24d916fa09f8dd053a22ff377e7dfb984632" :authors
  '(("Daniel Martín" . "mardani29@yahoo.es"))
  :maintainer
  '("Daniel Martín" . "mardani29@yahoo.es")
  :keywords
  '("help" "swift")
  :url "https://github.com/danielmartin/swift-helpful")
;; Local Variables:
;; no-byte-compile: t
;; End:
