(define-package "consult" "20201230.2159" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "dc3fa6678bc1bc80cf1c7e4eacb478fdee902ea3" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
