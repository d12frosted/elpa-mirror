(define-package "grugru" "20211008.1720" "Rotate text at point"
  '((emacs "24.4"))
  :commit "856d66a65a75fd9906c47a930a8ee584bdef4077" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "toolsa")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
