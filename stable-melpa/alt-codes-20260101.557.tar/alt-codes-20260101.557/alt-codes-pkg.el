;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alt-codes" "20260101.557"
  "Insert alt codes using meta key."
  '((emacs "26.1"))
  :url "https://github.com/jcs-elpa/alt-codes"
  :commit "1a4df7f34b1072ef199aba602c6c3901d3da5bb1"
  :revdesc "1a4df7f34b10"
  :keywords '("convenience" "alt" "codes" "insertion" "meta")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
