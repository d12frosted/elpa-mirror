(define-package "projection" "20230603.1248" "Project type support for `project'"
  '((emacs "29")
    (project "0.9.8")
    (compat "29.1.4.1"))
  :commit "b53085ec53b01ccdd4305a34865cbfcf52770407" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
