;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20260422.253"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "1720200b1271a9e70ebfc86c0f942ff02aefcdd1"
  :revdesc "1720200b1271"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
