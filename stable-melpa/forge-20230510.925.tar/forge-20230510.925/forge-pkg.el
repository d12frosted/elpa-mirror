(define-package "forge" "20230510.925" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "29.1.3.4")
    (closql "20230407")
    (dash "2.19.1")
    (emacsql "20230409")
    (ghub "20220621")
    (let-alist "1.0.6")
    (magit "20230319")
    (markdown-mode "2.4")
    (transient "0.3.6")
    (yaml "0.3.5"))
  :commit "d2bdd2ca14d7a97dce751c122174896c35a34aa1" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
