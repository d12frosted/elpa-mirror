(define-package "citre" "20210802.1843" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "4e0ff7c28145bea0a071399bdbeca79e85feb59c" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
