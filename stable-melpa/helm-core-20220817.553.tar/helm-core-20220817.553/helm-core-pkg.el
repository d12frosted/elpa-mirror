(define-package "helm-core" "20220817.553" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "746e2c01c806c9e52ff75c3568dad90ca281b784" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
