(define-package "magit-section" "20201120.2150" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20200524"))
  :commit "068f8389743b96d31069bb891b6cc26810bf50d9" :keywords
  ("tools")
  :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
