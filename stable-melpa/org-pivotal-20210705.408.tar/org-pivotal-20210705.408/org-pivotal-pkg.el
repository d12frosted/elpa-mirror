(define-package "org-pivotal" "20210705.408" "Sync Pivotal Tracker to org buffer"
  '((a "0.1.1")
    (dash "2.18.0")
    (emacs "26.1")
    (request "0.3.0"))
  :commit "f3cb4c96b8ef27a7c5ad681d502e8836cef662ab" :authors
  '(("Huy Duong" . "qhuyduong@hotmail.com"))
  :maintainer
  '("Huy Duong" . "qhuyduong@hotmail.com")
  :url "https://github.com/org-pivotal/org-pivotal")
;; Local Variables:
;; no-byte-compile: t
;; End:
