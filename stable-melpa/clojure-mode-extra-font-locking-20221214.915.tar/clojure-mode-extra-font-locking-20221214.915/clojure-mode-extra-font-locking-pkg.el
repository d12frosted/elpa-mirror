(define-package "clojure-mode-extra-font-locking" "20221214.915" "Extra font-locking for Clojure mode"
  '((clojure-mode "3.0"))
  :commit "3453cd229b412227aaffd1dc2870fa8fa213c5b1" :authors
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.dev")
  :keywords
  '("languages" "lisp")
  :url "http://github.com/clojure-emacs/clojure-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
