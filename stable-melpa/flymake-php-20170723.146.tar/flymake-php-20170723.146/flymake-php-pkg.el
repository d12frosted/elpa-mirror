;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-php" "20170723.146"
  "A flymake handler for php-mode files."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-php"
  :commit "c045d01e002ba5e09b05f40e25bf5068d02126bc"
  :revdesc "c045d01e002b"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
