(define-package "rmsbolt" "20220323.1859" "A compiler output viewer"
  '((emacs "25.1"))
  :commit "fffadc0b865a58fd8eee00f03ed55b9ae5b78e08" :authors
  '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainer
  '("Jay Kamat" . "jaygkamat@gmail.com")
  :keywords
  '("compilation" "tools")
  :url "http://gitlab.com/jgkamat/rmsbolt")
;; Local Variables:
;; no-byte-compile: t
;; End:
