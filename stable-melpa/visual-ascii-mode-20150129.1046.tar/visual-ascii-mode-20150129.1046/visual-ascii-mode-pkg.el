;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-ascii-mode" "20150129.1046"
  "Visualize ascii code (small integer) on buffer."
  ()
  :url "https://github.com/Dewdrops/visual-ascii-mode"
  :commit "99285a099a17472ddd9f1b4f74e9d092dd8c5947"
  :revdesc "99285a099a17"
  :keywords '("presentation")
  :authors '(("Dewdrops" . "v_v_4474@126.com"))
  :maintainers '(("Dewdrops" . "v_v_4474@126.com")))
