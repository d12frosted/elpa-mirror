;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250519.1615"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "8f430bf0d37192236f1fab5d3e7bf5ec60dff929"
  :revdesc "8f430bf0d371"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
