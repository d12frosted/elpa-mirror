(define-package "modus-themes" "20210717.410" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "d061b3d56a4299ebe07df7596633988b53f5eaf5" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
