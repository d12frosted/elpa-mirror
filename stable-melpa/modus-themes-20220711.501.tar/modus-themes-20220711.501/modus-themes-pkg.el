(define-package "modus-themes" "20220711.501" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "fc936326f9486cfda0c9113dc4a3054e9971447d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
