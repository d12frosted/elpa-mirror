(define-package "flexoki-themes" "20231113.1309" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "cbcc840db4b21567f30e9e16ec435b941095a0c4" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
