;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fj" "20261006.1914"
  "Client for Forgejo instances."
  '((emacs     "29.1")
    (compat    "31")
    (fedi      "0.5")
    (tp        "0.8")
    (transient "0.10.0")
    (magit     "4.3.8"))
  :url "https://codeberg.org/martianh/fj.el"
  :commit "e3e2b461102b050aead991a065d513c6109c25da"
  :revdesc "e3e2b461102b"
  :keywords '("git" "convenience")
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
