(define-package "loopy" "20220510.323" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22"))
  :commit "a2dbc79bd33a1d194c4804c1157caf27e67b5066" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
