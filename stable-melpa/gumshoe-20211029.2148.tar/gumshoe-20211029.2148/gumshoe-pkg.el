(define-package "gumshoe" "20211029.2148" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "397379a3e032f31e98a57f5eb2187a0607c6bd7a" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
