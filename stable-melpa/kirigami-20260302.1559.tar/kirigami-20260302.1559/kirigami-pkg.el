;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260302.1559"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "5e987e13d406116a97af90f5bd6a01c0fc6deb65"
  :revdesc "5e987e13d406"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
