(define-package "spdx" "20230324.110" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "bb787bfd385076a0a914dd656c6f776c36714e27" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
