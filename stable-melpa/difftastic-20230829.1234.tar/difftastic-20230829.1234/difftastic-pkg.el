(define-package "difftastic" "20230829.1234" "Emacs wrapper for difftastic"
  '((emacs "28.1")
    (magit "20220326"))
  :commit "b2bc4136af8a1cf015c0136d16e40948b563e139" :authors
  '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers
  '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainer
  '("Przemyslaw Kryger" . "pkryger@gmail.com")
  :keywords
  '("tools" "diff")
  :url "https://github.com/pkryger/difftastic.el.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
