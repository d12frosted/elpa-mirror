;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260630.1155"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0c54d5bc20eead6ec1b13d0bd2cf61eea54f2452"
  :revdesc "0c54d5bc20ee")
