;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260410.1557"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "0217c0dde5a060dfd48318a70814687062e4ce3a"
  :revdesc "0217c0dde5a0"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
