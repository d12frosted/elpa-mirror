;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260621.1451"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "1d5b5ac1b0d1f93c90e23b0c18c9691887260a73"
  :revdesc "1d5b5ac1b0d1"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
