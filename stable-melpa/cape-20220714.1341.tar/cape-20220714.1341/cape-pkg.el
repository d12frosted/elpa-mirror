(define-package "cape" "20220714.1341" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "52b25f5b864029252e6b7d4736adf678ad84903a" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
