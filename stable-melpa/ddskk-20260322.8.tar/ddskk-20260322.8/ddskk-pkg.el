;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk" "20260322.8"
  "Daredevil SKK (Simple Kana to Kanji conversion program)."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :url "https://github.com/skk-dev/ddskk"
  :commit "240fb05f4edf07f221d074f00eb5f593dad86150"
  :revdesc "240fb05f4edf"
  :keywords '("japanese" "mule" "input method")
  :authors '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp")))
