;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-guide" "20260513.1504"
  "Show vertical lines to guide indentation."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "8ee7b5056cf20acabc3cf1297b9347802f9ea01d"
  :revdesc "8ee7b5056cf2")
