;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20260824.735"
  "An Org-social client for Emacs."
  '((emacs            "30.1")
    (org              "9.0")
    (request          "0.3.0")
    (seq              "2.20")
    (emojify          "1.2")
    (async-http-queue "0.1"))
  :url "https://git.andros.dev/org-social/org-social.el"
  :commit "94915a57b619ff9e43088915b8844ce46e8143f9"
  :revdesc "94915a57b619"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
