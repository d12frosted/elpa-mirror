;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20260219.1710"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "340dac3ee07d3fd3c778ace4aedb667ec231c22a"
  :revdesc "340dac3ee07d"
  :keywords '("docs" "startdict" "sdcv"))
