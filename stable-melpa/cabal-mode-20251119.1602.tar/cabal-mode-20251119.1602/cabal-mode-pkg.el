;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cabal-mode" "20251119.1602"
  "Support for Cabal packages."
  '((emacs "24.4"))
  :url "https://github.com/webdevred/cabal-mode"
  :commit "14183916674121ce49bff129c5c1f4f49092ee2c"
  :revdesc "141839166741"
  :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainers '(("Stefan Monnier" . "monnier@iro.umontreal.ca")))
