(define-package "boon" "20210323.1341" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "17a7a9219a5a9b7156f58f7f30227fc2b79b6020")
;; Local Variables:
;; no-byte-compile: t
;; End:
