;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260426.1706"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "6b38c3d3bbdddba242386644fe49f04b8fdc13cd"
  :revdesc "6b38c3d3bbdd"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
