;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260428.1401"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "3b831468b506e8b49716540bce3b3a583188d72c"
  :revdesc "3b831468b506"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
