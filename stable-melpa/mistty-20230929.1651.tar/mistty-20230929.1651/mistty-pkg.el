(define-package "mistty" "20230929.1651" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "33cb1e98e7ad771a555a96f1349cbdd949b08df3" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
