(define-package "company" "20240302.513" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "abd9099b309ab52275b6ddd12c6df15b032b5c3a" :authors
  '(("Nikolaj Schumacher"))
  :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
