(define-package "dart-mode" "20230929.2140" "Major mode for editing Dart files"
  '((emacs "27.1"))
  :commit "722e7a2d6b885542a14bf27b9d0b0b5898aba78a" :authors
  '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers
  '(("Brady Trainor"))
  :maintainer
  '("Brady Trainor")
  :keywords
  '("languages")
  :url "https://github.com/emacsorphanage/dart-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
