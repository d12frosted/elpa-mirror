(define-package "tabnine" "20231012.342" "An unofficial TabNine package with TabNine Chat supported"
  '((emacs "28.1")
    (dash "2.16.0")
    (s "1.12.0")
    (editorconfig "0.9.1")
    (vterm "0.0.2")
    (language-id "0.5.1")
    (transient "0.4.0"))
  :commit "a321807ed64a1a4917e2ffd97de1ec2c861a2c24" :authors
  '(("Aaron Ji" . "shuxiao9058@gmail.com")
    ("Tommy Xiang" . "tommyx058@gmail.com")
    ("John Gong" . "gjtzone@hotmail.com"))
  :maintainers
  '(("Aaron Ji" . "shuxiao9058@gmail.com"))
  :maintainer
  '("Aaron Ji" . "shuxiao9058@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/shuxiao9058/tabnine/")
;; Local Variables:
;; no-byte-compile: t
;; End:
