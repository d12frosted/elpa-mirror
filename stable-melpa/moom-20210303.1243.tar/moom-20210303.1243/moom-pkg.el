(define-package "moom" "20210303.1243" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "ed084a7a21cc7558ceb647fbd59869023ff76f6c" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
