(define-package "org-ref" "20211025.1744" "citations, cross-references and bibliographies in org-mode"
  '((dash "0")
    (s "0")
    (f "0")
    (htmlize "0")
    (hydra "0")
    (parsebib "0")
    (bibtex-completion "0")
    (citeproc "0"))
  :commit "e5db441b5fee12c144a0946de56ff2fd9adf3f32" :authors
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainer
  '("John Kitchin" . "jkitchin@andrew.cmu.edu")
  :keywords
  '("org-mode" "cite" "ref" "label")
  :url "https://github.com/jkitchin/org-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
