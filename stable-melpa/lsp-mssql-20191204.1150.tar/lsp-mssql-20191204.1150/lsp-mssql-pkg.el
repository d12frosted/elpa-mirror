(define-package "lsp-mssql" "20191204.1150" "MSSQL LSP bindings"
  '((emacs "25.1")
    (lsp-mode "6.2")
    (dash "2.14.1")
    (f "0.20.0")
    (ht "2.0")
    (lsp-treemacs "0.1"))
  :commit "e16e91d6a2a6cdb406ee9b98cfb47f7a32e41d61" :authors
  '(("Ivan Yonchovski" . "yyoncho@gmail.com"))
  :maintainer
  '("Ivan Yonchovski" . "yyoncho@gmail.com")
  :keywords
  '("data" "languages")
  :url "https://github.com/emacs-lsp/lsp-mssql")
;; Local Variables:
;; no-byte-compile: t
;; End:
