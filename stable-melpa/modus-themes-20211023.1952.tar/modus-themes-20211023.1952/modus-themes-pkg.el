(define-package "modus-themes" "20211023.1952" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "45b92cf80505db759b38316ea32a877517c78b21" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
