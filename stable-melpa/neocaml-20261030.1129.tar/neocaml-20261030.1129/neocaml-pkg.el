;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261030.1129"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "c33a11f7994d6acb21676793ba3d45a98cb10bcb"
  :revdesc "c33a11f7994d"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
