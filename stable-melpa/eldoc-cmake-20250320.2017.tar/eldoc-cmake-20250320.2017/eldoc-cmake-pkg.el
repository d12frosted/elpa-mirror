;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-cmake" "20250320.2017"
  "Eldoc support for CMake."
  '((emacs "25.1"))
  :url "https://github.com/ikirill/eldoc-cmake"
  :commit "8ffe7ef0fc01f487834d6bb2468f2d55d68277f1"
  :revdesc "8ffe7ef0fc01")
