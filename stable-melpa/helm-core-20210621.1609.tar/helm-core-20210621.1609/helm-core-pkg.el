(define-package "helm-core" "20210621.1609" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "f41e1361404fa9a7b053fdedcdb02d187eb9bae5")
;; Local Variables:
;; no-byte-compile: t
;; End:
