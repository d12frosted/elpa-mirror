(define-package "brutalist-theme" "20220507.909" "Brutalist theme" 'nil :commit "f7611ba27ccf1f48f9547d23a20a260ee8886677" :authors
  '(("Gergely Nagy"))
  :maintainer
  '("Gergely Nagy")
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
