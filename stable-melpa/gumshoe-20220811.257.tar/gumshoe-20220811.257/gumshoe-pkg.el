(define-package "gumshoe" "20220811.257" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "68cc9c1654862dfb8aee4c1dd732e752bf202532" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
