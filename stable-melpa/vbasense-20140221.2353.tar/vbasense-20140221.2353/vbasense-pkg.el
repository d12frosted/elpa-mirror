;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vbasense" "20140221.2353"
  "Provide a environment like Visual Basic Editor."
  '((auto-complete "1.4.0")
    (log4e         "0.2.0")
    (yaxception    "0.1"))
  :url "https://github.com/aki2o/emacs-vbasense"
  :commit "8c61a492d7c15218ae1a96e2aebfe6f78bfff6db"
  :revdesc "8c61a492d7c1"
  :keywords '("vba" "completion")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
