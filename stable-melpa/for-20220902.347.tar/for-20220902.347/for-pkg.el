(define-package "for" "20220902.347" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "ff2e56c379ef732c9b19bd0a4c57e651ee6b8303" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
