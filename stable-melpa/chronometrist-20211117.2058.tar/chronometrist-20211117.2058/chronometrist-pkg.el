(define-package "chronometrist" "20211117.2058" "A time tracker with a nice interface"
  '((emacs "25.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "133554d1b89b988235475b1c815cd7d808128393" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
