;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261110.1513"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "9e0f8286b2799db8e540ad006ed0998d6ba6731a"
  :revdesc "9e0f8286b279"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
