;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251030.845"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "57be107b20625c13ed010cb0f70a603a61d47629"
  :revdesc "57be107b2062"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
