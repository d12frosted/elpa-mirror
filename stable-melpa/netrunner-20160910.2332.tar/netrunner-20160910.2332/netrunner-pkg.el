;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "netrunner" "20160910.2332"
  "Create Android: Netrunner decklists using Company, Helm and org-mode."
  '((popup   "0.5.3")
    (company "0.9.0")
    (helm    "1.9.5"))
  :url "https://github.com/Kungsgeten/netrunner"
  :commit "c64672992175c8c1073c0f56c2e471839db71a0f"
  :revdesc "c64672992175"
  :keywords '("games"))
