;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20251021.1258"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "43aa842994b63cac05fb315167aa5d4c38d1901b"
  :revdesc "43aa842994b6"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
