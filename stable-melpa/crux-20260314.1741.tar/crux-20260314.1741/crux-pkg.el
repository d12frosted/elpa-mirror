;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crux" "20260314.1741"
  "A Collection of Ridiculously Useful eXtensions."
  '((emacs "26.1"))
  :url "https://github.com/bbatsov/crux"
  :commit "eddca2675974828f92134cab82a12c54a1eb7b51"
  :revdesc "eddca2675974"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
