(define-package "imbot" "20210423.731" "Automatic system input method switcher"
  '((emacs "25.1"))
  :commit "01bf1e1101ac9cd34bfda7016ce0f82f97a3de35" :keywords
  '("convenience")
  :url "https://github.com/QiangF/imbot")
;; Local Variables:
;; no-byte-compile: t
;; End:
