;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260222.2329"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "89fe2eba671a08bc5fa56bbb4a5bdc1ffb91d46d"
  :revdesc "89fe2eba671a")
