(define-package "transient" "20240928.1345" "Transient commands"
  '((emacs "26.1")
    (compat "30.0.0.0")
    (seq "2.24"))
  :commit "f67500bfd21a28596c034eed446dc5cbfbe7e987" :authors
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers
  '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainer
  '("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
