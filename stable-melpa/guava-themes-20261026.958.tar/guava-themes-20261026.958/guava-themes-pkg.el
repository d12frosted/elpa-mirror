;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261026.958"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "4e6768c8740881b7a5f298fb7bc666aa56f970e7"
  :revdesc "4e6768c87408"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
