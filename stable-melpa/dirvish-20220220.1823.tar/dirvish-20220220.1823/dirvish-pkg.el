(define-package "dirvish" "20220220.1823" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "0d21876b8a5db2e2d5999ddbe0514c6e0c0bd79d" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
