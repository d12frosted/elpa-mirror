(define-package "consult" "20221202.1047" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "68ed535cc5d9943d29d9e45d1cbbb102ce7e2e74" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
