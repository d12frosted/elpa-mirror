;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu-session" "20251126.508"
  "Persistent undo, available between sessions."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu-session"
  :commit "ef544227502c613c39fb9a140b94135df80a49b5"
  :revdesc "ef544227502c"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
