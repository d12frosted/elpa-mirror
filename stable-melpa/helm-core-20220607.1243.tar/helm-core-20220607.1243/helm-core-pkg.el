(define-package "helm-core" "20220607.1243" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "ece8a6042da8dad0239055570e45b44d641293ac" :authors
  '(("Thierry Volpiatto "))
  :maintainer
  '("Thierry Volpiatto ")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
