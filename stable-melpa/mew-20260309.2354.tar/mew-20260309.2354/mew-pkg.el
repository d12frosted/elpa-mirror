;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260309.2354"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "caf4703cbf5adba19ec929d955d02838b6d4c7de"
  :revdesc "caf4703cbf5a")
