(define-package "jabber" "20230617.234" "A Jabber client for Emacs."
  '((fsm "0.2")
    (srv "0.2"))
  :commit "644a3ef7d9ddbfe496443d7e358186fe90fcdc93")
;; Local Variables:
;; no-byte-compile: t
;; End:
