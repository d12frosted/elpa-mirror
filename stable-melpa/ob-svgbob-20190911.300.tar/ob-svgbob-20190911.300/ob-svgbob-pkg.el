;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-svgbob" "20190911.300"
  "Babel Functions for svgbob."
  '((emacs "24"))
  :url "https://github.com/mgxm/ob-svgbob"
  :commit "5747f96fb4fdb8711546b3313df9412177eb3c1a"
  :revdesc "5747f96fb4fd"
  :keywords '("tools" "files")
  :authors '(("Marcio Giaxa" . "i@mgxm.me"))
  :maintainers '(("Marcio Giaxa" . "i@mgxm.me")))
