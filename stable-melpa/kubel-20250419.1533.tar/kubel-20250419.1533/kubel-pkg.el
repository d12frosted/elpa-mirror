;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "20250419.1533"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "ac1d9143e49f9c91f3eb130920f8a9a335d8e12a"
  :revdesc "ac1d9143e49f"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
