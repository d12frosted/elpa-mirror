;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260531.1253"
  "MCP server for Org-mode."
  '((emacs          "27.1")
    (mcp-server-lib "0.3.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "76fb211f97888ab66c9be09f04421a70c06b5f8a"
  :revdesc "76fb211f9788"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
