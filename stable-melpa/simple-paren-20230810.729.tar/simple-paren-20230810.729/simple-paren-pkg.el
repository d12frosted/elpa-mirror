;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-paren" "20230810.729"
  "Non-electrical insert paired delimiter, wrap."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/andreas-roehler/simple-paren"
  :commit "206d8f3f82123f61e7133a14f66c83a9632bd99e"
  :revdesc "206d8f3f8212"
  :keywords '("convenience"))
