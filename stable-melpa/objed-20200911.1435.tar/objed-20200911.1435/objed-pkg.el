(define-package "objed" "20200911.1435" "Navigate and edit text objects."
  '((emacs "25")
    (cl-lib "0.5"))
  :commit "e93dda73bd932563d35e76f1c2f1b50895b640cf" :authors
  '(("Clemens Radermacher" . "clemera@posteo.net"))
  :maintainer
  '("Clemens Radermacher" . "clemera@posteo.net")
  :keywords
  '("convenience")
  :url "https://github.com/clemera/objed")
;; Local Variables:
;; no-byte-compile: t
;; End:
