(define-package "objed" "20200911.1435" "Navigate and edit text objects."
  '((emacs "25")
    (cl-lib "0.5"))
  :commit "70f9fb5e0aa1627b0afc7c6b3d0aea9bac70a210" :authors
  '(("Clemens Radermacher" . "clemera@posteo.net"))
  :maintainer
  '("Clemens Radermacher" . "clemera@posteo.net")
  :keywords
  '("convenience")
  :url "https://github.com/clemera/objed")
;; Local Variables:
;; no-byte-compile: t
;; End:
