(define-package "ebib" "20210503.1412" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "3142de8d64789c611e553667cac3bb84428d004c" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
