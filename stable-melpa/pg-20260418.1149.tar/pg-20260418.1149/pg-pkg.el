;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20260418.1149"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "e82be0a8a69042c102119b9c7d59619f3a2277a3"
  :revdesc "e82be0a8a690"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
