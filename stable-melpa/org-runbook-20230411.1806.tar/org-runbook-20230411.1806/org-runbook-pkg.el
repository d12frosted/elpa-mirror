(define-package "org-runbook" "20230411.1806" "Org mode for runbooks"
  '((emacs "27.1")
    (seq "2.3")
    (f "0.20.0")
    (s "1.12.0")
    (dash "2.17.0")
    (mustache "0.24")
    (ht "0.9")
    (ivy "0.8.0"))
  :commit "f9dcc1c9262752a2ecb561578fa01d58f8ad32aa" :authors
  '(("Tyler Dodge"))
  :maintainer
  '("Tyler Dodge")
  :keywords
  '("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
