(define-package "dionysos" "20160810.1056" "Dionysos, a music player for Emacs"
  '((libmpdee "2.1.0")
    (alert "1.2")
    (s "1.11.0")
    (dash "2.12.1")
    (pkg-info "0.5.0")
    (cl-lib "0.5"))
  :commit "98bc789d20e41020d6e62d63d3c78f8032fa4bf2" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("music")
  :url "https://github.com/nlamirault/dionysos")
;; Local Variables:
;; no-byte-compile: t
;; End:
