;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-cpp-complete" "20260107.150"
  "GPTel-powered C++ completion."
  '((emacs "30.1")
    (eglot "1.19")
    (gptel "0.9.8"))
  :url "https://github.com/beacoder/gptel-cpp-complete"
  :commit "b743d3045125a65cdcf19bcc88da68e52d0d7332"
  :revdesc "b743d3045125"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
