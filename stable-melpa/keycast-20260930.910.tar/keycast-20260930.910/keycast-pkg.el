;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycast" "20260930.910"
  "Show current command and its binding."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/keycast"
  :commit "39dfd8359cfb03377c8c1a772491169c7f66cd9f"
  :revdesc "39dfd8359cfb"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev")))
