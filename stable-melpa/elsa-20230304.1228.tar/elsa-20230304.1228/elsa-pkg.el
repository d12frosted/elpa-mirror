(define-package "elsa" "20230304.1228" "Emacs Lisp Static Analyser"
  '((emacs "25.1")
    (trinary "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3")
    (lsp-mode "0"))
  :commit "2126a72f6d5d632741d9f5209997fb4f11133fd7" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp")
  :url "https://github.com/emacs-elsa/Elsa")
;; Local Variables:
;; no-byte-compile: t
;; End:
