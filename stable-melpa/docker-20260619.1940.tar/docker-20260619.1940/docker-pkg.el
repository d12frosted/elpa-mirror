;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "docker" "20260619.1940"
  "Interface to Docker."
  '((aio       "1.0")
    (dash      "2.19.1")
    (emacs     "28.1")
    (s         "1.13.0")
    (tablist   "1.1")
    (transient "0.4.3"))
  :url "https://github.com/Silex/docker.el"
  :commit "6b16f3ecce24cd24c0a9305a4b04491880c8ea53"
  :revdesc "6b16f3ecce24"
  :keywords '("filename" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
