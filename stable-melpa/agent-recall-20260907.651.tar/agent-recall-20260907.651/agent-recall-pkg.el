;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20260907.651"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "67651796756668479ff954b3ea6f7fb7312762f3"
  :revdesc "676517967566"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
