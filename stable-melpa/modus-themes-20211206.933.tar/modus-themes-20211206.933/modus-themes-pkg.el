(define-package "modus-themes" "20211206.933" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "ce36b16d319e405825eabbf9bc69e54165cd972d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
