;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20260609.500"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "46b821d3bf8d5a4a53b2f6915ce59fd623720be9"
  :revdesc "46b821d3bf8d"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
