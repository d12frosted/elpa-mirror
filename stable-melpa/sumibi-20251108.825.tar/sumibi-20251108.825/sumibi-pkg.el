;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20251108.825"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (mozc           "0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "eaedf9de6f62b7dc248ac890cfefe5f38c6301ca"
  :revdesc "eaedf9de6f62"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
