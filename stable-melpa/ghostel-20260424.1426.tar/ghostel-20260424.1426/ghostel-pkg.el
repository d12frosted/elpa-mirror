;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260424.1426"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "257386ddb18dc8cecaed351ad00b8943a392717b"
  :revdesc "257386ddb18d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
