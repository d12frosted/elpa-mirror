(define-package "spdx" "20220729.153" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "e2ed5d9b1039c90c18bc090837dd6a20a219bd1b" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
