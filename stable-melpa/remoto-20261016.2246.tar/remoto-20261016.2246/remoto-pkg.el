;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "remoto" "20261016.2246"
  "Browse GitHub repos without cloning."
  '((emacs "29.1")
    (ghub  "4.0.0"))
  :url "https://github.com/agzam/remoto.el"
  :commit "914046738749c0ffd5a2ca18986809b616cac45b"
  :revdesc "914046738749"
  :keywords '("tools" "vc")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
