(define-package "modus-themes" "20230123.459" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "4dca14bb16b5fe269ff7ef9722e2b1fe7da25f06" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
