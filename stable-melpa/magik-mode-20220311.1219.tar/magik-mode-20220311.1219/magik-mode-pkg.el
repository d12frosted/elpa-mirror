(define-package "magik-mode" "20220311.1219" "mode for editing Magik + some utils." 'nil :commit "86f1ca9f0f45e61a1ac7b96c809a85defc4ca665" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
