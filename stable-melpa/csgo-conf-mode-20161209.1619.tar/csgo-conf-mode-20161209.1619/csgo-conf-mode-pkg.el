;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "csgo-conf-mode" "20161209.1619"
  "CS:GO Configuration files syntax highlighting."
  ()
  :url "https://github.com/wynro/emacs-csgo-conf-mode"
  :commit "df45ca833eb68c394dd03acce5733a33c3b06bf8"
  :revdesc "df45ca833eb6"
  :keywords '("languages")
  :authors '(("Guillermo Robles" . "guillerobles1995@gmail.com"))
  :maintainers '(("Guillermo Robles" . "guillerobles1995@gmail.com")))
