;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250226.153"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "de915a538e1b0c63226e22c8570c80012c899613"
  :revdesc "de915a538e1b"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
