;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "immaterial-theme" "20261025.749"
  "A family of themes loosely based on material colors."
  '((emacs        "29")
    (modus-themes "5.3.0"))
  :url "https://github.com/petergardfjall/emacs-immaterial-theme"
  :commit "1ca35bbaa3e5236203c3d3ffaae8e6aa4ee2ae45"
  :revdesc "1ca35bbaa3e5"
  :keywords '("themes"))
