;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "egison-mode" "20260720.1006"
  "Egison editing mode."
  ()
  :url "https://github.com/egisatoshi/egison/blob/master/emacs/egison-mode.el"
  :commit "cbd50c069e9b0791268a2a6bf136ea17f7f995fb"
  :revdesc "cbd50c069e9b"
  :authors '(("Satoshi Egi" . "egisatoshi@gmail.com"))
  :maintainers '(("Satoshi Egi" . "egisatoshi@gmail.com")))
