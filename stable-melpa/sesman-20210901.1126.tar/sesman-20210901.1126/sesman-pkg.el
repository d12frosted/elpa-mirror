(define-package "sesman" "20210901.1126" "Generic Session Manager"
  '((emacs "25"))
  :commit "563ebeaafbb39a719eb53e6e7de5eb90d08e0233" :authors
  '(("Vitalie Spinu"))
  :maintainer
  '("Vitalie Spinu")
  :keywords
  '("process")
  :url "https://github.com/vspinu/sesman")
;; Local Variables:
;; no-byte-compile: t
;; End:
