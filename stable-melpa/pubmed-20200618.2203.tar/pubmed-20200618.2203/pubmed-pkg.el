(define-package "pubmed" "20200618.2203" "Interface to PubMed"
  '((emacs "25.1")
    (deferred "0.5.1")
    (esxml "0.3.4")
    (s "1.12.0")
    (unidecode "0.2"))
  :commit "88aeb71ed4354af0b58354636ee6a9485887213d" :authors
  '(("Folkert van der Beek" . "folkertvanderbeek@gmail.com"))
  :maintainer
  '("Folkert van der Beek" . "folkertvanderbeek@gmail.com")
  :keywords
  '("pubmed" "hypermedia")
  :url "https://gitlab.com/fvdbeek/emacs-pubmed")
;; Local Variables:
;; no-byte-compile: t
;; End:
