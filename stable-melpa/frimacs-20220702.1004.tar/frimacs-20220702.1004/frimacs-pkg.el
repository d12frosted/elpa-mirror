(define-package "frimacs" "20220702.1004" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "978665a47314f385850097442a3838ad7f3b688d" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
