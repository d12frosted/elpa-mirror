(define-package "expenses" "20211224.1620" "Record and view expenses"
  '((emacs "26.1")
    (dash "2.19.1")
    (ht "2.3"))
  :commit "e02a80eedbc825dafd0a0a6cf566f4978dc5ed89" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("expense tracking" "convenience")
  :url "https://github.com/md-arif-shaikh/expenses")
;; Local Variables:
;; no-byte-compile: t
;; End:
