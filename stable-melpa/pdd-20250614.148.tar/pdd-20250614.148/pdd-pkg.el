;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250614.148"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "7519b5101206ad47b8ab10992d5e8307845ee1b7"
  :revdesc "7519b5101206"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
