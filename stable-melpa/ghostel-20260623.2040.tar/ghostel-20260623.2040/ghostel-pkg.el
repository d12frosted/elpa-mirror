;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260623.2040"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "3431d79f44a7fc8a6b6638587a5604cacd03f897"
  :revdesc "3431d79f44a7"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
