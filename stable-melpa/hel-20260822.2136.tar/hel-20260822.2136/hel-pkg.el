;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hel" "20260822.2136"
  "Helix Emulation Layer."
  '((emacs        "29.1")
    (dash         "2.19.1")
    (avy          "0.5.0")
    (pcre2el      "1.12")
    (ultra-scroll "0.6"))
  :url "https://github.com/helheim-emacs/hel"
  :commit "7706d7a5adbbef9d604d30f7e86a9322a7936447"
  :revdesc "7706d7a5adbb"
  :authors '(("Yuriy Artemyev" . "anuvyklack@gmail.com"))
  :maintainers '(("Yuriy Artemyev" . "anuvyklack@gmail.com")))
