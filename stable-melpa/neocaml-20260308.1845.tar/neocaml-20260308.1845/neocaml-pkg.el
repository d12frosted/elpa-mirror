;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260308.1845"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "37ccaaa523801a5f511ba0a654a9d2a4ef1aec8d"
  :revdesc "37ccaaa52380"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
