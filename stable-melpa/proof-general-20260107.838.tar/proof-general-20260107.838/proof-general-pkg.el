;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20260107.838"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "c3895abfb58481e84797771b00019a3d52ce8954"
  :revdesc "c3895abfb584"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
