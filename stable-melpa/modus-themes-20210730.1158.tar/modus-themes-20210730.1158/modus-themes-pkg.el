(define-package "modus-themes" "20210730.1158" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "cbd4e5a6e88bd523bbc044c2bb9de24d5bfb494f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
