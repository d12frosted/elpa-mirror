(define-package "consult" "20240224.1017" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "4f6b9564c309c029ae4bb92644aeec3980833f15" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
