(define-package "clippy" "20230118.1924" "Show tooltip with function documentation at point"
  '((pos-tip "1.0"))
  :commit "85aec3129ff17f71ea4541cfadbb7b56b31a7474" :authors
  '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers
  '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matus Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("docs")
  :url "https://github.com/Fuco1/clippy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
