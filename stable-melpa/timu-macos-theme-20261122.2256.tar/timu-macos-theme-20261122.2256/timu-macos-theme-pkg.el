;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timu-macos-theme" "20261122.2256"
  "Color theme inspired by the macOS UI."
  '((emacs "27.1"))
  :url "https://gitlab.com/aimebertrand/timu-macos-theme"
  :commit "69600280997cf980a5a0e4a436d821f2b1754ad2"
  :revdesc "69600280997c"
  :keywords '("faces" "themes")
  :authors '(("Aimé Bertrand" . "aime.bertrand@macowners.club"))
  :maintainers '(("Aimé Bertrand" . "aime.bertrand@macowners.club")))
