(define-package "ein" "20210211.1542" "Emacs IPython Notebook"
  '((emacs "25")
    (websocket "20190620")
    (anaphora "20180618")
    (request "20200117")
    (deferred "0.5")
    (polymode "20190714")
    (dash "2.13.0")
    (with-editor "20200522"))
  :commit "069e54cc1270ff4957699e5e9481b56b7b4bef8b" :keywords
  '("jupyter" "literate programming" "reproducible research")
  :url "https://github.com/dickmao/emacs-ipython-notebook")
;; Local Variables:
;; no-byte-compile: t
;; End:
