(define-package "embark" "20210806.1318" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "e4bdbd55af2e948d0bceb5d08b9d9518d91fc563" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
