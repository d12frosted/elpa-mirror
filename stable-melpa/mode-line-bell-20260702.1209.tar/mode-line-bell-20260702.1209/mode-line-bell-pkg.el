;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-line-bell" "20260702.1209"
  "Flash the mode line instead of ringing the bell."
  ()
  :url "https://github.com/purcell/mode-line-bell"
  :commit "b888963bf390b6e1d132b72b8a14041bd7afae4b"
  :revdesc "b888963bf390"
  :keywords '("convenience")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
