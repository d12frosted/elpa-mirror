(define-package "company-php" "20230522.1329" "A company back-end for PHP."
  '((cl-lib "0.5")
    (ac-php-core "2.0")
    (company "0.9"))
  :commit "4c678709e1e1f1673a83b9eb01875e457c6ca658" :authors
  '(("jim" . "xcwenn@qq.com"))
  :maintainers
  '(("jim"))
  :maintainer
  '("jim")
  :keywords
  '("completion" "convenience" "intellisense")
  :url "https://github.com/xcwen/ac-php")
;; Local Variables:
;; no-byte-compile: t
;; End:
