(define-package "syslog-mode" "20210901.53" "Major-mode for viewing log files & strace output"
  '((hide-lines "20130623")
    (ov "20150311")
    (hsluv "20181127"))
  :commit "78ddfaf5b011e4c26e7edeaf1168e600aee23783" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
