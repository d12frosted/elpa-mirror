;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260410.549"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral DeepSeek OpenRouter Support."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "4ee00d2f11715547778497eff38cceabb830d1a6"
  :revdesc "4ee00d2f1171"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
