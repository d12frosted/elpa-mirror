(define-package "ebib" "20220118.739" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "c854cd0ba979085178b797adb72ad42eed2f87f7" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
