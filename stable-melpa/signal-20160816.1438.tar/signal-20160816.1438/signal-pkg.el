;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "signal" "20160816.1438"
  "Advanced hook."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/mola-T/signal"
  :commit "aa58327e2297df921d72a0370468b48663efd438"
  :revdesc "aa58327e2297"
  :keywords '("internal" "lisp" "processes" "tools")
  :authors '(("Mola-T" . "Mola@molamola.xyz"))
  :maintainers '(("Mola-T" . "Mola@molamola.xyz")))
