(define-package "bbdb" "20220327.2341" "The Insidious Big Brother Database for GNU Emacs" 'nil :commit "029128c0a7c320e93c3a7526a40135d02a3f3ee4" :maintainer
  '("Roland Winkler" . "winkler@gnu.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
