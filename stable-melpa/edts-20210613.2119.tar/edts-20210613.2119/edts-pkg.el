(define-package "edts" "20210613.2119" "Erlang Development Tool Suite"
  '((auto-complete "20170125.245")
    (auto-highlight-symbol "20130313.943")
    (dash "20190814.2006")
    (erlang "20190404.928")
    (f "20190109.906")
    (popup "20160709.1429")
    (s "20180406.808"))
  :commit "2b54b51334572da53e0a59f5c9e4aa00c81eb04e")
;; Local Variables:
;; no-byte-compile: t
;; End:
