(define-package "consult" "20221219.1929" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "9481fe9a249b4b35ca861b4f89d68fecafd46b25" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
