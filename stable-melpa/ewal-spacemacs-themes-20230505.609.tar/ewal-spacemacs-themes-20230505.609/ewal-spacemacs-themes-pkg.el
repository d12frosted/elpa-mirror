;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ewal-spacemacs-themes" "20230505.609"
  "Ride the rainbow spaceship."
  '((emacs           "25")
    (ewal            "0.1")
    (spacemacs-theme "0.1"))
  :url "https://gitlab.com/jjzmajic/ewal"
  :commit "0d245edcfcd9cc5766d37b270214fb9da9b4336d"
  :revdesc "0d245edcfcd9"
  :keywords '("faces"))
