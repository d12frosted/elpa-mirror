;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mpdel" "20250704.823"
  "Play and control your MPD music."
  '((emacs    "25.1")
    (libmpdel "1.2.0")
    (navigel  "0.7.0"))
  :url "https://github.com/mpdel/mpdel"
  :commit "8665d032b0456e3e5df7f077db785b3bbb3183d4"
  :revdesc "8665d032b045"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
