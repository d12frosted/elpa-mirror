;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260218.1509"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.10.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "0d7c8c374b4e15f8e7a9c25acc7c5f06fbd40943"
  :revdesc "0d7c8c374b4e")
