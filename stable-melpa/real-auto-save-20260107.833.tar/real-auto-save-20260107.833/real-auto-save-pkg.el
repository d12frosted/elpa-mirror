;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "real-auto-save" "20260107.833"
  "Automatically save your buffers/files at regular intervals."
  '((emacs "24.4"))
  :url "https://github.com/ChillarAnand/real-auto-save"
  :commit "84c1eca9bd65ecd65ef0c0f71b44c5480cee1e68"
  :revdesc "84c1eca9bd65"
  :authors '(("Chaoji Li" . "lichaojiATgmailDOTcom")
             ("Anand Reddy Pandikunta" . "anand21nandaATgmailDOTcom"))
  :maintainers '(("Chaoji Li" . "lichaojiATgmailDOTcom")
                 ("Anand Reddy Pandikunta" . "anand21nandaATgmailDOTcom")))
