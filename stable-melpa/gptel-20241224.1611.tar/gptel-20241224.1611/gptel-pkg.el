;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241224.1611"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "c165342f436b4090bfddc4aab3d54a2843d206e7"
  :revdesc "c165342f436b"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
