;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260505.1904"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "f5be2dc7578542b5c71658733edee52f7b6e4fbb"
  :revdesc "f5be2dc75785"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
