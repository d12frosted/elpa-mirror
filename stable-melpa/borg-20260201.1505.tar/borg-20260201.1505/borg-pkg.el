;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260201.1505"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.1")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "99933c616380fdcdf3732644d7d69b7c5d54d4bf"
  :revdesc "99933c616380"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
