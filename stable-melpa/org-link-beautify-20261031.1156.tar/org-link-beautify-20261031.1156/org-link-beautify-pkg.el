;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20261031.1156"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "2fa82d0c24db19a8d1dcff5e4b967c131bb7a028"
  :revdesc "2fa82d0c24db"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
