(define-package "consult" "20201212.1904" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "408a2c8e91d766810e0f9f37d81b43791dfbb517" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
