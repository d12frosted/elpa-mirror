;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260410.1158"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "df74b73a600e203eefd9bfcc5e31f8c5888032e8"
  :revdesc "df74b73a600e"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
