;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "20260222.1818"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "e42ebaf74a3d8174935a9122b174ed1d874241dd"
  :revdesc "e42ebaf74a3d"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
