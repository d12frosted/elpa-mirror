;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260624.444"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "23302acc331738652f6295eae9c8feb856cb021e"
  :revdesc "23302acc3317"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
