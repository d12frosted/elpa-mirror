;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260801.1501"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "f3da49c5a10479bb490c0ddb320a1f87680c765d"
  :revdesc "f3da49c5a104"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
