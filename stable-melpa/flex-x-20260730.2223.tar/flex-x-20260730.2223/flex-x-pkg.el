;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "20260730.2223"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "7a4e8b7bf7f5c0bdd51bc96f2e4a8cc7290155b6"
  :revdesc "7a4e8b7bf7f5"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
