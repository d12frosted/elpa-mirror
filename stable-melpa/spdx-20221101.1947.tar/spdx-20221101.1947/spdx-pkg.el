(define-package "spdx" "20221101.1947" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d88fa0d7c8ce438f43b5b7edd033d581a7faa13d" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
