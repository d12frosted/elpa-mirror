(define-package "hyperbole" "20240908.732" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.2"))
  :commit "25ad337b6be9ebe59ec0925a4ab0095ad7743dc2" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainer
  '("Robert Weiner" . "rsw@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
