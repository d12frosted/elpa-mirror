;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mw-thesaurus" "20261113.510"
  "Merriam-Webster Thesaurus and Dictionary."
  '((emacs "27.1"))
  :url "https://github.com/agzam/mw-thesaurus.el"
  :commit "870dad42f4022d6e854e7b48e21b7cb458bc0d4f"
  :revdesc "870dad42f402"
  :keywords '("wp" "matching")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
