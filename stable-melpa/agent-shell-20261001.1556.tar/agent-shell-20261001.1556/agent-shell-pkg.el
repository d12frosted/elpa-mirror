;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261001.1556"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d3c6708197b70e2d23c1b2b7ef2c37f499d0c087"
  :revdesc "d3c6708197b7")
