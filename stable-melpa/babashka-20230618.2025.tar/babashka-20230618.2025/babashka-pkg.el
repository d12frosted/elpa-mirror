(define-package "babashka" "20230618.2025" "Babashka Tasks Interface"
  '((emacs "27.1")
    (parseedn "1.1.0"))
  :commit "2b71b3d5a9939836f1224817f0acc1ac7512ff24" :authors
  '(("Mykhaylo Bilyanskyy" . "mb@m1k.pw"))
  :maintainers
  '(("Mykhaylo Bilyanskyy" . "mb@m1k.pw"))
  :maintainer
  '("Mykhaylo Bilyanskyy" . "mb@m1k.pw")
  :url "https://github.com/licht1stein/babashka.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
