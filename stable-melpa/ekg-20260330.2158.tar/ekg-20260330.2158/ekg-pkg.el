;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260330.2158"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "62c71d7491817f87337d9d8e4868469c4a599be0"
  :revdesc "62c71d749181"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
