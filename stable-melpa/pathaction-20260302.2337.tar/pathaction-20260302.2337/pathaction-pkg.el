;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260302.2337"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "fe88bf99e371984b9777434c1f854840f316299d"
  :revdesc "fe88bf99e371"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
