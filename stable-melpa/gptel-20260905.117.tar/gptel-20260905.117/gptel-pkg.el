;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260905.117"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "9417813e279f81d1ee1909f848b7c42f69d68d20"
  :revdesc "9417813e279f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
