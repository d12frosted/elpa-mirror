;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cache" "20111019.2300"
  "Implementation of a hash table whose key-value pairs expire."
  ()
  :url "https://github.com/nflath/cache"
  :commit "7499586b6c8224df9f5c5bc4dec96b008258d580"
  :revdesc "7499586b6c82")
