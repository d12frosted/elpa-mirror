(define-package "evil-tree-edit" "20220129.446" "Evil structural editing for any language!"
  '((emacs "27.1")
    (tree-edit "0.1.0")
    (tree-sitter "0.15.0")
    (evil "1.0.0")
    (avy "0.5.0")
    (s "0.0.0"))
  :commit "a94e4a645988a2c0e2369e27a2635f6555d321d8" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
