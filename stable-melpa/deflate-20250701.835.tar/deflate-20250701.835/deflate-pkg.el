;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "deflate" "20250701.835"
  "The DEFLATE compression algorithm in pure Emacs LISP."
  '((dash  "2.0.0")
    (emacs "25.1"))
  :url "https://github.com/skuro/deflate"
  :commit "4fb44291cb8ac9587939ed511008c8b8eaa586f3"
  :revdesc "4fb44291cb8a"
  :keywords '("files" "tools")
  :authors '(("Carlo Sciolla" . "carlo.sciolla@gmail.com"))
  :maintainers '(("Carlo Sciolla" . "carlo.sciolla@gmail.com")))
