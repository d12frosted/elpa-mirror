;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-daily-reflection" "20251120.7"
  "Concurrent display of org(-roam) dailies."
  '((emacs  "26.1")
    (org    "9.4")
    (compat "30.0.0.0"))
  :url "https://github.com/emacsomancer/org-daily-reflection"
  :commit "a6a051b931e196a112946be118d3db8b177a0298"
  :revdesc "a6a051b931e1"
  :keywords '("convenience" "frames" "terminals" "tools" "window-system")
  :authors '(("Benjamin Slade" . "slade@lambda-y.net"))
  :maintainers '(("Benjamin Slade" . "slade@lambda-y.net")))
