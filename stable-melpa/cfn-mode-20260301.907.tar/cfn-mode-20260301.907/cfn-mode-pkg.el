;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260301.907"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "2a933343672a883a2eaf404553ad463cf12d8104"
  :revdesc "2a933343672a"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
