;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250309.1501"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "836f6054352f4cd5f9c4e2c928011beafe89e5cc"
  :revdesc "836f6054352f"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
