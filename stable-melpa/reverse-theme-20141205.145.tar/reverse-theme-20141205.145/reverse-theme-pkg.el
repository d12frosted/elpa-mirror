;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reverse-theme" "20141205.145"
  "Reverse theme for Emacs."
  ()
  :url "https://github.com/syohex/emacs-reverse-theme"
  :commit "3105c950bcb51c662c79b59ca102ef662c2b0be0"
  :revdesc "3105c950bcb5"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
