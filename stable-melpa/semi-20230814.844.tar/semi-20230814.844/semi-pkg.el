(define-package "semi" "20230814.844" "A library to provide MIME features."
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9"))
  :commit "d15603b8eb791f2057b48071c262996ad7767505")
;; Local Variables:
;; no-byte-compile: t
;; End:
