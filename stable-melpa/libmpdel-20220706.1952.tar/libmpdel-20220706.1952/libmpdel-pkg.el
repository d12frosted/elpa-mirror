(define-package "libmpdel" "20220706.1952" "Communication with an MPD server"
  '((emacs "25.1"))
  :commit "c27c08949a742a888eb9921a8528882b2aec6137" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("multimedia")
  :url "https://github.com/mpdel/libmpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
