;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260311.749"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "92e0b5db1515f757301171a7e8fffdb52e64f705"
  :revdesc "92e0b5db1515"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
