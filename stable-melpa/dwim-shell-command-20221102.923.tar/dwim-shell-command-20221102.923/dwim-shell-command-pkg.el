(define-package "dwim-shell-command" "20221102.923" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "bc2e9bb89c4dc244ff6795c89c8539897191a1bd" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
