;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260608.1831"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "436081e734ec40b44acca33da3479c0789220231"
  :revdesc "436081e734ec"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
