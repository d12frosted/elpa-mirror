;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-typst" "20250611.2031"
  "Typst Back-End for Org Export Engine."
  '((emacs "30.1")
    (org   "9.7"))
  :url "https://github.com/jmpunkt/ox-typst"
  :commit "71bc9eb5f257d66ab64b04575df98e36cf615277"
  :revdesc "71bc9eb5f257"
  :keywords '("text" "wp" "org" "typst"))
