(define-package "boxquote" "20231215.2228" "Quote text with a semi-box"
  '((cl-lib "0.5"))
  :commit "a07e9d321569b72296c267ac4460277b42b71b3e" :authors
  '(("Dave Pearson" . "davep@davep.org"))
  :maintainers
  '(("Dave Pearson" . "davep@davep.org"))
  :maintainer
  '("Dave Pearson" . "davep@davep.org")
  :keywords
  '("quoting")
  :url "https://github.com/davep/boxquote.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
