;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gerrit" "20260510.2014"
  "Gerrit client."
  '((emacs "29.1")
    (magit "2.13.1")
    (s     "1.12.0")
    (dash  "0.2.15"))
  :url "https://github.com/twmr/gerrit.el"
  :commit "dcdd672b73284def8e8b3ee6e4f1d9092b87c5f7"
  :revdesc "dcdd672b7328"
  :keywords '("extensions")
  :authors '(("Thomas Wimmer" . "thomaswimmer@posteo.com"))
  :maintainers '(("Thomas Wimmer" . "thomaswimmer@posteo.com")))
