(define-package "verilog-ts-mode" "20230912.1837" "Verilog Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "e1a5fe296db2e19571b7edeabc1b58712b2ed558" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
