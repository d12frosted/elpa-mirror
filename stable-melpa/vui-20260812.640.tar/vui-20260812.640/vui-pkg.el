;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260812.640"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "d026eac87d1b25992891e1e276ad08653cca38f0"
  :revdesc "d026eac87d1b"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
