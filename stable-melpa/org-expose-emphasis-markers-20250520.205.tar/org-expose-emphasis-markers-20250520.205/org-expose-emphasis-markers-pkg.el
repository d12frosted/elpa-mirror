;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-expose-emphasis-markers" "20250520.205"
  "Automatically show hidden org emphasis markers."
  '((emacs "29.1"))
  :url "https://github.com/lorniu/org-expose-emphasis-markers"
  :commit "7c15b876ff8db998c8f5d4475f8c1342ccae5ac3"
  :revdesc "7c15b876ff8d"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
