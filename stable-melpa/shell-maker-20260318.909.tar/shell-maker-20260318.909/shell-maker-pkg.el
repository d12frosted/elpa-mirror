;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260318.909"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "e109a106708824baeaefbb7ae833c87aaa27f6a3"
  :revdesc "e109a1067088")
