(define-package "consult" "20210531.243" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "879a14cc2ec4d2b0dbf0843cba5d3287feb31f7f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
