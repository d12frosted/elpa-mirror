(define-package "stimmung-themes" "20220315.1458" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "ab9debd7ebbf1d8d1575c81743a8dab508338e5e" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
