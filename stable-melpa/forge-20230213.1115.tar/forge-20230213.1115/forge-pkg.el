(define-package "forge" "20230213.1115" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "29.1.3.4")
    (closql "1.2.0")
    (dash "2.19.1")
    (emacsql-sqlite "3.0.0")
    (ghub "20220621")
    (let-alist "1.0.6")
    (magit "20220621")
    (markdown-mode "2.4")
    (transient "0.3.6")
    (yaml "0.3.5"))
  :commit "0db3e938b60cf809e321cff2b958e2b7db477f69" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
