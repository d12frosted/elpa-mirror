;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vcomp" "20261001.1632"
  "Compare version strings."
  '((emacs "26.1"))
  :url "https://github.com/tarsius/vcomp"
  :commit "f7d38443a300386058c91ed3bd9574f02950b4de"
  :revdesc "f7d38443a300"
  :keywords '("versions")
  :authors '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
