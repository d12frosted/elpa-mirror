;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20260903.1658"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "a4ee6158ecafc89a934dd00f3b86dd1154e99d3e"
  :revdesc "a4ee6158ecaf"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
