;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260510.1632"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "ab6f712453befaf03a4e7083e781d3356b4ff961"
  :revdesc "ab6f712453be"
  :keywords '("languages"))
