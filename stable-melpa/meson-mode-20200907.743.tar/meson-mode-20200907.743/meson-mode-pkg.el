(define-package "meson-mode" "20200907.743" "Major mode for the Meson build system files"
  '((emacs "26.1"))
  :commit "d995dafa388ec03c0113cd1ac46403c20ad18ab0" :keywords
  ("languages" "tools")
  :authors
  (("Michal Sojka" . "sojkam1@fel.cvut.cz"))
  :maintainer
  ("Michal Sojka" . "sojkam1@fel.cvut.cz")
  :url "https://github.com/wentasah/meson-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
