(define-package "package-build" "20220115.2346" "Tools for assembling a package archive"
  '((cl-lib "0.5")
    (emacs "25.1"))
  :commit "415552b9548fb4fd929a62ec09563e94dfbec5c9" :authors
  '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainer
  '("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
  :keywords
  '("tools")
  :url "https://github.com/melpa/package-build")
;; Local Variables:
;; no-byte-compile: t
;; End:
