;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260604.1238"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "2f09c570b7f1483bd31514c4e0fea2ad6b4fbc72"
  :revdesc "2f09c570b7f1"
  :keywords '("asciidoc" "text")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
