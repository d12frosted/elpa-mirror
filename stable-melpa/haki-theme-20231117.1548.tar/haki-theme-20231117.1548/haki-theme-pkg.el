(define-package "haki-theme" "20231117.1548" "An elegant, high-contrast dark theme in modern sense"
  '((emacs "27.1"))
  :commit "d734c8457bec0d5c2844383490fb8ecf8904e9ea" :authors
  '(("Dilip"))
  :maintainers
  '(("Dilip"))
  :maintainer
  '("Dilip")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://github.com/idlip/haki")
;; Local Variables:
;; no-byte-compile: t
;; End:
