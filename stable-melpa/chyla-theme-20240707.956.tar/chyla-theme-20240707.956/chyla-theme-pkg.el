(define-package "chyla-theme" "20240707.956" "Chyla.org - green color theme"
  '((emacs "24.1"))
  :commit "e7b5237c15bc9fc76e15861418c68616efbb103b" :authors
  '(("Adam Chyła https://chyla.org/" . "adam@chyla.org"))
  :maintainers
  '(("Adam Chyła https://chyla.org/" . "adam@chyla.org"))
  :maintainer
  '("Adam Chyła https://chyla.org/" . "adam@chyla.org")
  :url "https://github.com/chyla/ChylaThemeForEmacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
