;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calctape" "20251016.857"
  "Adding-machine, tape calculator, column sum-mer."
  '((emacs "29.1"))
  :url "https://github.com/Boruch-Baum/emacs-calctape"
  :commit "4fe05aa8d0071c7e057cec9985dd5bab65c3380c"
  :revdesc "4fe05aa8d007"
  :keywords '("convenience" "data")
  :authors '(("Boruch Baum" . "boruch_baum@gmx.com"))
  :maintainers '(("Boruch Baum" . "boruch_baum@gmx.com")))
