;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-coffee" "20170725.1424"
  "Org-babel functions for coffee-script evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-coffee"
  :commit "7f0b330273e8af7777de87a75fe52a89798e4548"
  :revdesc "7f0b330273e8"
  :keywords '("org" "babel" "coffee-script")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
