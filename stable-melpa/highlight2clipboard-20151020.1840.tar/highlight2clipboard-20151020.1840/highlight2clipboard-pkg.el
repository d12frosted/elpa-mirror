(define-package "highlight2clipboard" "20151020.1840" "Copy text to clipboard with highlighting."
  '((htmlize "1.47"))
  :commit "6ce58a060d9c5843ccb8c79ec2bba7858c68ac15" :keywords
  ("tools")
  :authors
  (("Anders Lindgren"))
  :maintainer
  ("Anders Lindgren"))
;; Local Variables:
;; no-byte-compile: t
;; End:
