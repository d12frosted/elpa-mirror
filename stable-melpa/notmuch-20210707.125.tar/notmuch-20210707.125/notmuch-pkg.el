(define-package "notmuch" "20210707.125" "run notmuch within emacs" 'nil :commit "04f378e673852ade100c54318124ff8c22f857b6" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
