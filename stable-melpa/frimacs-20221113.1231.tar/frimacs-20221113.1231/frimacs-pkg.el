(define-package "frimacs" "20221113.1231" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "ae3870ebced2fb92f7fac1aa0051f7e46b30d55b" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
