(define-package "embark" "20230507.1612" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "f88314044d5492efeacb9466122889c6e60c8af4" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
