;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260325.1631"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "74a59ec34adf15c2064162e2c2d7c05328fa5131"
  :revdesc "74a59ec34adf")
