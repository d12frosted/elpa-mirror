(define-package "meow" "20230410.1803" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "4fe321a7a0b603474f8c348a8862a27b360f80a5" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
