;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20261125.429"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "733a5aec9c9446ad8ae61765404e79bb85a60fe9"
  :revdesc "733a5aec9c94"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
