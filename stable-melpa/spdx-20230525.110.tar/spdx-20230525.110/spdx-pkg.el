(define-package "spdx" "20230525.110" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "9815f8e78e7dd50d75e1b2f6dc3a16c797b904c7" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
