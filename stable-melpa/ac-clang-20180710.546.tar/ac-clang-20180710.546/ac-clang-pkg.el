;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-clang" "20180710.546"
  "Auto Completion source by libclang for GNU Emacs."
  '((emacs         "24")
    (cl-lib        "0.5")
    (auto-complete "1.4.0")
    (pos-tip       "0.4.6")
    (yasnippet     "0.8.0"))
  :url "https://github.com/yaruopooner/ac-clang"
  :commit "3294b968eb1a8317049190940193f9da47c085ef"
  :revdesc "3294b968eb1a"
  :keywords '("completion" "convenience" "intellisense"))
