;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261015.2313"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "9b8111f38201d13d1eb926e26c0d1b3288bc4d0a"
  :revdesc "9b8111f38201"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
