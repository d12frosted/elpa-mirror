;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250523.2211"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "3a00d4f2c530ee57291878d065f493555422ca53"
  :revdesc "3a00d4f2c530"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
