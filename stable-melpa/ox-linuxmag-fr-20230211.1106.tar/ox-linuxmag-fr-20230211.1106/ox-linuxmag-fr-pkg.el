(define-package "ox-linuxmag-fr" "20230211.1106" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "335db57fc992b8dff57881b05b667df3d19447c8" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
