(define-package "ctune" "20210205.1428" "Tune out CC Mode Noise Macros"
  '((emacs "26.1"))
  :commit "3f7abc6e74d4e5954b476ba9a1dc652f96b10c05" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("c" "convenience")
  :url "https://github.com/maurooaranda/ctune")
;; Local Variables:
;; no-byte-compile: t
;; End:
