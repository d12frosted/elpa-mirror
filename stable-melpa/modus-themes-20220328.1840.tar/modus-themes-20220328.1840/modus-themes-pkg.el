(define-package "modus-themes" "20220328.1840" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "d7c7574269d335fb45d520047c4f2cdb91f82b1a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
