;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250310.320"
  "AI pair programming with Aider."
  '((emacs "28.1"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "1971d487172762ae4c0506cec4d553ff92114fe3"
  :revdesc "1971d4871727"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
