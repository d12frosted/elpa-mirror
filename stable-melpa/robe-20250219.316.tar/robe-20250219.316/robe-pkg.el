;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "robe" "20250219.316"
  "Code navigation, documentation lookup and completion for Ruby."
  '((inf-ruby "2.5.1")
    (emacs    "25.1"))
  :url "https://github.com/dgutov/robe"
  :commit "8234c6243f499f906d1d0ae018543547214b2b47"
  :revdesc "8234c6243f49"
  :keywords '("ruby" "convenience" "rails"))
