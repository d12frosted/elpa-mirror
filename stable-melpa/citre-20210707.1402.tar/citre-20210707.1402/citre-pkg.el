(define-package "citre" "20210707.1402" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "672c05b9e72e3b6a4a7e15291e2a6c7aa7d8344d" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
