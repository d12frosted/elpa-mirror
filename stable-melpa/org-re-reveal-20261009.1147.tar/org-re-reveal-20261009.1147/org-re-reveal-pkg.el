;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-re-reveal" "20261009.1147"
  "Org export to reveal.js presentations."
  '((emacs   "24.4")
    (org     "8.3")
    (htmlize "1.34"))
  :url "https://gitlab.com/oer/org-re-reveal"
  :commit "2f161edbb3c4be006039770be8614e38d28a0800"
  :revdesc "2f161edbb3c4"
  :keywords '("tools" "outlines" "hypermedia" "slideshow" "presentation" "oer"))
