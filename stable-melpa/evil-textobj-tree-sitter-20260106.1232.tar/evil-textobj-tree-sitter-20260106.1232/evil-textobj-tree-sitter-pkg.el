;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-textobj-tree-sitter" "20260106.1232"
  "Provides evil textobjects using tree-sitter."
  '((emacs "25.1"))
  :url "https://github.com/meain/evil-textobj-tree-sitter"
  :commit "38e6cc59c29a1d86030364bccd89b78b44054396"
  :revdesc "38e6cc59c29a"
  :keywords '("evil" "tree-sitter" "text-object" "convenience"))
