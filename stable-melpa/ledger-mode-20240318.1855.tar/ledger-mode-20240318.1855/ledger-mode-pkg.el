(define-package "ledger-mode" "20240318.1855" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "cd36c4c00e07b6cf40c0a39d2dbcb650f0903f49")
;; Local Variables:
;; no-byte-compile: t
;; End:
