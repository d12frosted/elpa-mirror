;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260508.2029"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "c6bb5eb8df4ed817aeb23649a1cc56982b6b81c5"
  :revdesc "c6bb5eb8df4e"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
