;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260528.1434"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "4d9d660ac0d9485699f68b6ce2decb6c439eb15e"
  :revdesc "4d9d660ac0d9"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
