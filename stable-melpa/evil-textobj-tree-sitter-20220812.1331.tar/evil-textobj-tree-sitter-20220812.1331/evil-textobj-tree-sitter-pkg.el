(define-package "evil-textobj-tree-sitter" "20220812.1331" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1")
    (evil "1.0.0")
    (tree-sitter "0.15.0"))
  :commit "0df263f83ce7d756bbb8cead8ffc9c3b13399b4a" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
