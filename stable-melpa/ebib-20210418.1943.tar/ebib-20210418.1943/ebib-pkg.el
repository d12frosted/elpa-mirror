(define-package "ebib" "20210418.1943" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "2447ca89c83428cb1ecbc47b1408b304baea9155" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
