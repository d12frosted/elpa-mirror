(define-package "pandoc-mode" "20210305.1435" "Minor mode for interacting with Pandoc"
  '((hydra "0.10.0")
    (dash "2.10.0"))
  :commit "10df0452da4eaf79b45804e9b5029c545be1968a" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "pandoc")
  :url "http://joostkremers.github.io/pandoc-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
