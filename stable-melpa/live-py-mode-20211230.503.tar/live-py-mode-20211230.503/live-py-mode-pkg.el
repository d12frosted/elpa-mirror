(define-package "live-py-mode" "20211230.503" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "7bdcd669647c9604b856617162446d59c0f9e4e1" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
