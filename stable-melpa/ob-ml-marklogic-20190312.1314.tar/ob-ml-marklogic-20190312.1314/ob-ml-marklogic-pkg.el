;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-ml-marklogic" "20190312.1314"
  "Org-babel functions for MarkLogic evaluation."
  ()
  :url "https://github.com/ndw/ob-ml-marklogic"
  :commit "d5660ad14f29e17cd26ae92eeb585b24030e9570"
  :revdesc "d5660ad14f29"
  :keywords '("marklogic" "xquery" "javascript" "sparql")
  :authors '(("Norman Walsh" . "ndw@nwalsh.com"))
  :maintainers '(("Norman Walsh" . "ndw@nwalsh.com")))
