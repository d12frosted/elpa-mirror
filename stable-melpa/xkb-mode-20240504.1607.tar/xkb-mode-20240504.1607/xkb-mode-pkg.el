(define-package "xkb-mode" "20240504.1607" "Major mode for editing X Keyboard Extension (XKB) files"
  '((emacs "25.1"))
  :commit "c5752b8d6e06194e1f0dcbd9f1552d3cfaa47bbf" :authors
  '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers
  '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainer
  '("James Dyer" . "captainflasmr@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/captainflasmr/xkb-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
