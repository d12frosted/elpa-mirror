(define-package "stgit" "20230725.1528" "major mode for StGit interaction" 'nil :commit "cee9dfd7d12b86178bcbf1d48679f298f94113b3" :authors
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainers
  '(("David Kågedal" . "davidk@lysator.liu.se"))
  :maintainer
  '("David Kågedal" . "davidk@lysator.liu.se")
  :url "http://stacked-git.github.io")
;; Local Variables:
;; no-byte-compile: t
;; End:
