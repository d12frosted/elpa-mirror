(define-package "parse-it" "20220214.1531" "Basic Parser in Emacs Lisp"
  '((emacs "25.1")
    (s "1.12.0"))
  :commit "5c163ffc63d52631c1494c260b50d63c04c37a97" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/parse-it")
;; Local Variables:
;; no-byte-compile: t
;; End:
