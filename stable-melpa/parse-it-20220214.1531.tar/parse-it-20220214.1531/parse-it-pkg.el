(define-package "parse-it" "20220214.1531" "Basic Parser in Emacs Lisp"
  '((emacs "25.1")
    (s "1.12.0"))
  :commit "29ded5f05d9d35b9077dc3ccb7f68c66e4e4851c" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/parse-it")
;; Local Variables:
;; no-byte-compile: t
;; End:
