;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260601.17"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "490e47decdc686d99e034b7bfcab27780ff0c843"
  :revdesc "490e47decdc6"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
