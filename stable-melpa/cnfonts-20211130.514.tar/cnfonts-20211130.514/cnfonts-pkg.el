(define-package "cnfonts" "20211130.514" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "36eac01474c7b49ea4d006b6663271242be7bf7b" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
