(define-package "boon" "20230808.1231" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "ba12cf8b40b9858cba85c6121c2390285b75a2a7")
;; Local Variables:
;; no-byte-compile: t
;; End:
