(define-package "pyim" "20210706.107" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "24.4")
    (async "1.6")
    (xr "1.13"))
  :commit "70ab1df61060cf2049aac3375e1e959a6f573b38" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
