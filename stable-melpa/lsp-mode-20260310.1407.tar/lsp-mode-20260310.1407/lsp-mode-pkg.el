;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260310.1407"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "fafdc3531ac08f63f76cacac997ee00d0624c8f3"
  :revdesc "fafdc3531ac0"
  :keywords '("languages"))
