;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-starter-swiper" "20220326.1106"
  "Swiper for org-starter."
  '((emacs       "25.1")
    (swiper      "0.11")
    (org-starter "0.2.4"))
  :url "https://github.com/akirak/org-starter"
  :commit "cd9c5c0402de941299d1c8901f26a8f24d755022"
  :revdesc "cd9c5c0402de"
  :authors '(("Akira Komamura" . "akira.komamura@gmail.com"))
  :maintainers '(("Akira Komamura" . "akira.komamura@gmail.com")))
