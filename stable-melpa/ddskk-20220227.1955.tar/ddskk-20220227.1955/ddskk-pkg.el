(define-package "ddskk" "20220227.1955" "Simple Kana to Kanji conversion program."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :commit "ac0777ace98b6e8a8a10aa2302d51efeaa6f7893")
;; Local Variables:
;; no-byte-compile: t
;; End:
