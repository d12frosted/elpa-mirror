;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-tag-beautify" "20260103.934"
  "Beautify Org mode tags."
  '((emacs      "26.1")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-tag-beautify.git"
  :commit "de02883b9ad339539482d30450074ca572709d90"
  :revdesc "de02883b9ad3"
  :keywords '("hypermedia"))
