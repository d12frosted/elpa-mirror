(define-package "modus-themes" "20210409.825" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "929fe49f606c7b10582310947025e330c0caf641" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
