(define-package "wanderlust" "20210209.1125" "Yet Another Message Interface on Emacsen"
  '((emacs "24.5")
    (apel "10.8")
    (flim "1.14.9")
    (semi "1.14.7"))
  :commit "3a3530b1c4e2a2aa02d683d166cf123e9cc16a0a")
;; Local Variables:
;; no-byte-compile: t
;; End:
