(define-package "merlin" "20210615.1208" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "444f6e000f6b7dc58dac44d6ac096fc0e09894cc" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
