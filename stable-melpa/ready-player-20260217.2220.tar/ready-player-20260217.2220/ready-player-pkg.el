;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ready-player" "20260217.2220"
  "Open media files in ready-player major mode."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/ready-player"
  :commit "81b9878872f994b4acbd45bd9a0ef0c5f8c3ce68"
  :revdesc "81b9878872f9")
