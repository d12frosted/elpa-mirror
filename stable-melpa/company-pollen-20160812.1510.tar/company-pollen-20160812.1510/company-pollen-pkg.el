;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-pollen" "20160812.1510"
  "Company-mode completion backend for pollen."
  '((company     "0.9.0")
    (pollen-mode "1.0"))
  :url "https://github.com/lijunsong/pollen-mode"
  :commit "9779f7f13b1e0cfb58af01af5d8ee9e783bb8a43"
  :revdesc "9779f7f13b1e"
  :keywords '("languages" "pollen" "pollenpub" "company")
  :authors '(("Junsong Li" . "ljs.darkfishATGMAIL")))
