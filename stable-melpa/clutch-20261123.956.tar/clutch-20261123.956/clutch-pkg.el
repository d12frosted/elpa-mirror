;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261123.956"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "902e5b3b6c06994ece1a3eb8f8716f2d333f5b28"
  :revdesc "902e5b3b6c06"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
