(define-package "proof-general" "20211109.1442" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "25.1"))
  :commit "2145c23f44a0951a14240d3b85a1a3d08aade9bb" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
