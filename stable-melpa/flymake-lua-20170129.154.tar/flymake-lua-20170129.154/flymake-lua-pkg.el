;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-lua" "20170129.154"
  "Flymake for Lua."
  ()
  :url "https://github.com/sroccaserra/flymake-lua"
  :commit "dcc32b62a285215898ae774ba63dbda0656f6f53"
  :revdesc "dcc32b62a285"
  :keywords '("lua")
  :authors '(("Sébastien Roccaserra (format \"s\" \"roccaserra\" \"yahoo\" \"com\"" . "\"<%s%s@%s.%s>\" "))
  :maintainers '(("Sébastien Roccaserra (format \"s\" \"roccaserra\" \"yahoo\" \"com\"" . "\"<%s%s@%s.%s>\" ")))
