;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260607.1313"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "7bc0e6df5f39fa4c517e27531a2c22926c39361a"
  :revdesc "7bc0e6df5f39"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
