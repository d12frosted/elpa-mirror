;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-du-duc" "20251223.1935"
  "Speed up dired-du with duc."
  '((emacs    "29.1")
    (dired-du "0.5.2"))
  :url "https://github.com/meedstrom/dired-du-duc"
  :commit "a90e13b6e4b7e39c9b7c57b9111bf33261431dc8"
  :revdesc "a90e13b6e4b7"
  :keywords '("files")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
