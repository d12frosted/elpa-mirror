(define-package "paperless" "20230204.1815" "A major mode for sorting and filing PDF documents."
  '((emacs "29.1")
    (f "0.11.0")
    (s "1.10.0")
    (cl-lib "0.6.1"))
  :commit "e524e31350d74f13319968d24b7326a4a412e105" :authors
  '(("Anthony Green" . "green@moxielogic.com"))
  :maintainer
  '("Anthony Green" . "green@moxielogic.com")
  :keywords
  '("pdf" "convenience")
  :url "http://github.com/atgreen/paperless")
;; Local Variables:
;; no-byte-compile: t
;; End:
