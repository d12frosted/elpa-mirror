(define-package "racket-mode" "20211216.2033" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "ba63c5b9b05ce54e370e5c6bb631060246ce7ea4" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
