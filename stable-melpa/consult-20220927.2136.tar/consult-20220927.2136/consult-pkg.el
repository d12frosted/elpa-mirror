(define-package "consult" "20220927.2136" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "fae2c56bdc6832af65b85a3f2111be32eb2e68b2" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
