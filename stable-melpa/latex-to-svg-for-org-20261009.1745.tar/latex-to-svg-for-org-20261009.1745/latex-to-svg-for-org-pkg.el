;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-org" "20261009.1745"
  "Preview Org LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.20.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "3e579cd06ec45a643284bf2b6674682a0b722453"
  :revdesc "3e579cd06ec4"
  :keywords '("tex" "org" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
