;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20261112.1041"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.9")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "2c15394e5fee4f928587e28c4f2f926a7f8793f8"
  :revdesc "2c15394e5fee"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
