(define-package "projection" "20231016.1934" "Project type support for `project'"
  '((emacs "29.1")
    (project "0.9.8")
    (compat "29.1.4.1")
    (f "0.20")
    (s "1.13"))
  :commit "e3bd95ee6f729b578f5ee9e15a3dd77e6836c7b6" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
