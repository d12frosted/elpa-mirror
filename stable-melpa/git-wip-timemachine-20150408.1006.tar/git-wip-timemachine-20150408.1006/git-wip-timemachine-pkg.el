;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-wip-timemachine" "20150408.1006"
  "Walk through git-wip revisions of a file."
  '((s "1.9.0"))
  :url "https://github.com/itsjeyd/git-wip-timemachine"
  :commit "1ce257e6c25117b01f1b899aca21e07eae084d40"
  :revdesc "1ce257e6c251"
  :keywords '("git")
  :authors '(("Tim Krones" . "t.krones@gmx.net"))
  :maintainers '(("Tim Krones" . "t.krones@gmx.net")))
