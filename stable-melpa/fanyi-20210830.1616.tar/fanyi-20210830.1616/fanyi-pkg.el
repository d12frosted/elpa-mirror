(define-package "fanyi" "20210830.1616" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "5837b9fa3b87a3b243514a57c0c0173bba2e56ba" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
