;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250219.410"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.1")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "2ebf4ce731eec4830c5e57563eed4d448043796f"
  :revdesc "2ebf4ce731ee"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
