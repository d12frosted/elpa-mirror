;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250926.1322"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "395945542ee0c43fd0c5161d34c4c08180019ef9"
  :revdesc "395945542ee0"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
