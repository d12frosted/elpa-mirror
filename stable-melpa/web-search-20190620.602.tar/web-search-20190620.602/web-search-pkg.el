;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web-search" "20190620.602"
  "Open a web search."
  '((emacs "24.3"))
  :url "https://github.com/xuchunyang/web-search.el"
  :commit "a22cbdc663a1895d5a5b69de91e1e3b9eb64b92f"
  :revdesc "a22cbdc663a1"
  :keywords '("web" "search")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
