(define-package "noaa" "20230718.526" "Get NOAA weather data"
  '((emacs "27.1")
    (kv "0.0.19")
    (request "0.2.0")
    (s "1.12.0"))
  :commit "0e40721ff97d1311e2b5d392344a961421fa75f0" :authors
  '(("David Thompson"))
  :maintainers
  '(("David Thompson"))
  :maintainer
  '("David Thompson")
  :keywords
  '("calendar")
  :url "https://github.com/thomp/noaa")
;; Local Variables:
;; no-byte-compile: t
;; End:
