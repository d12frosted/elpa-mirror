(define-package "tree-sitter-langs" "20210831.1555" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.15.0"))
  :commit "846b2459105d1bc213033dbc82e79b2953bc5767" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/tree-sitter-langs")
;; Local Variables:
;; no-byte-compile: t
;; End:
