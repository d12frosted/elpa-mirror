(define-package "chronometrist-key-values" "20210603.539" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "85a14fe6529d3e96945683fb2bef16e1826a6811" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
