;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gams-mode" "20251120.1438"
  "Major mode for General Algebraic Modeling System (GAMS)."
  '((emacs "25.1"))
  :url "https://github.com/ShiroTakeda/gams-mode"
  :commit "daf8595b4d72fd012ef9b1240cff3878568adb60"
  :revdesc "daf8595b4d72"
  :keywords '("languages" "tools" "gams"))
