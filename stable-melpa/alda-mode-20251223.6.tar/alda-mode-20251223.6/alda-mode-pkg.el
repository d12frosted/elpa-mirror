;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alda-mode" "20251223.6"
  "An Alda major mode."
  '((emacs "24.0"))
  :url "https://gitlab.com/jgkamat/alda-mode"
  :commit "bde0e9c5df2810deb48df57f46bb3a1a51d7a8f6"
  :revdesc "bde0e9c5df28"
  :keywords '("alda" "highlight")
  :authors '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainers '(("Jay Kamat" . "jaygkamat@gmail.com")))
