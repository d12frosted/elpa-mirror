(define-package "modus-themes" "20221019.256" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "092a9048b3e2005d1d91d8b1223e734304901e52" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
