(define-package "modus-themes" "20221228.1533" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "61db7d4bca8bd231dde8446ae663385b29be9f70" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
