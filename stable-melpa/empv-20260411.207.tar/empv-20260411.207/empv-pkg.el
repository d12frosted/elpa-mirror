;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20260411.207"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "61cc54f8a506b708285a3f7a3fb299616d0fab02"
  :revdesc "61cc54f8a506"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
