(define-package "smithers" "20210531.2232" "A startup message featuring Mr C.M. Burns"
  '((emacs "26.1")
    (dash "2.17.0")
    (org "9.4.5"))
  :commit "db9ed12a8d2c131b6d37b4e7aff01b8e3cec81a6" :authors
  '(("Mehmet Tekman"))
  :maintainer
  '("Mehmet Tekman")
  :keywords
  '("games")
  :url "https://gitlab.com/mtekman/smithers.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
