(define-package "ebib" "20220608.1923" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "26.1"))
  :commit "db2b467c2ede510479ba3d026fbe0227f89294b4" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
