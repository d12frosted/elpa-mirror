(define-package "drupal-mode" "20220117.1142" "Advanced minor mode for Drupal development"
  '((php-mode "1.5.0"))
  :commit "5b90a053f73849db77e4c89a030acd81b53712d1" :authors
  '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainer
  '("Arne Jørgensen" . "arne@arnested.dk")
  :keywords
  '("programming" "php" "drupal")
  :url "https://github.com/arnested/drupal-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
