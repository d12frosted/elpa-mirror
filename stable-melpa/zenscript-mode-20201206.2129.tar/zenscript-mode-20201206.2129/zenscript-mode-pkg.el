(define-package "zenscript-mode" "20201206.2129" "Major mode for ZenScript"
  '((emacs "25.1"))
  :commit "5ec8663f3d2e6391f18a9f3a78864bcf6962898a" :url "https://github.com/eutropius225/zenscript-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
