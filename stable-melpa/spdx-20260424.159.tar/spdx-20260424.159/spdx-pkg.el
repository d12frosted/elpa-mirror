;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260424.159"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "2cc92e11cc1b6007d8ffdd18c541e9ac126664ed"
  :revdesc "2cc92e11cc1b"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
