;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251208.1157"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e6cbfa8d9cfb00d9d6bff3ae81befb83cf0466ff"
  :revdesc "e6cbfa8d9cfb")
