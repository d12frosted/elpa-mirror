;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260201.1213"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "204c69c04fa9a00cecb79d406d47848e8cbb89b4"
  :revdesc "204c69c04fa9")
