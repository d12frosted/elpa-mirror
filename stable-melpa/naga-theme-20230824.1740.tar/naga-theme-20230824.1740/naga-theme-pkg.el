(define-package "naga-theme" "20230824.1740" "Dark color theme with green foreground color"
  '((emacs "24.1"))
  :commit "00f3bac7bc11fde37fa60e66442e8c13a6159a81" :authors
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainers
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainer
  '("Johannes Maier" . "johannes.maier@mailbox.org")
  :keywords
  '("faces" "themes")
  :url "https://github.com/kenranunderscore/emacs-naga-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
