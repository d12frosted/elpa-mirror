(define-package "consult" "20210204.1855" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "1d9df3d32c7ef637f893a49828fb36019640e1a3" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
