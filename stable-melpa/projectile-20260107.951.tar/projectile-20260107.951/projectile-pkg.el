;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260107.951"
  "Manage and navigate projects in Emacs easily."
  '((emacs "26.1"))
  :url "https://github.com/bbatsov/projectile"
  :commit "80fa2366c4b8922f14946f3d82ff77e19f22e434"
  :revdesc "80fa2366c4b8"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
