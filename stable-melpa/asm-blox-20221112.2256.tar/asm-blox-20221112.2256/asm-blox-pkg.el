(define-package "asm-blox" "20221112.2256" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "0234a9fe3e4bea7717e857f516209fcc00cf85c0" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
