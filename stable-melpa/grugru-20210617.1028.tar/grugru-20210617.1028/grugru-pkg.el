(define-package "grugru" "20210617.1028" "Rotate text at point"
  '((emacs "24.4"))
  :commit "7efb041b826f15b10aa9cfb67b971fdc41064980" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
