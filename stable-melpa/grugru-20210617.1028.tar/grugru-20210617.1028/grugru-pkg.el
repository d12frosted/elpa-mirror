(define-package "grugru" "20210617.1028" "Rotate text at point"
  '((emacs "24.4"))
  :commit "3c505729004c28b8ddae76a107ba36b9a040ced9" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
