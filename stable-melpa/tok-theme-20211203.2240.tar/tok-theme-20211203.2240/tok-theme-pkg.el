(define-package "tok-theme" "20211203.2240" "My theme"
  '((emacs "24.1"))
  :commit "631e8b0b5e72983104084256d30b01ba4bc41e94" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
