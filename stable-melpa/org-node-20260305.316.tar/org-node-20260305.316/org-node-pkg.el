;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260305.316"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.34.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "25dcad1d4e2d20ccdcda2191fa060d29cfee1859"
  :revdesc "25dcad1d4e2d"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
