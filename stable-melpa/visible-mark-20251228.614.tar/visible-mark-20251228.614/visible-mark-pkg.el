;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visible-mark" "20251228.614"
  "Highlight marks in buffers."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-visible-mark"
  :commit "1954c15a790701cdac5734318bd3b1ab4c87d3f9"
  :revdesc "1954c15a7907"
  :keywords '("convenience" "faces")
  :authors '(("Ian Kelling" . "ian@iankelling.org"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
