;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260223.1906"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "b4cf300c1335dfe8210da05af0a8f3bf18b8f5d3"
  :revdesc "b4cf300c1335"
  :keywords '("convenience" "comm" "hypermedia"))
