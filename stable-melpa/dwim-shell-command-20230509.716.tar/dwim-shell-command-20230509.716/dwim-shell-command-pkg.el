(define-package "dwim-shell-command" "20230509.716" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "1a896221cc34319582b0921b919638ea2528b0e6" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
