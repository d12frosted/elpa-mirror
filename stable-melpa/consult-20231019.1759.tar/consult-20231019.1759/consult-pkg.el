(define-package "consult" "20231019.1759" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "3cadc1031495661dc2c884fc307e8d59852f3b54" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
