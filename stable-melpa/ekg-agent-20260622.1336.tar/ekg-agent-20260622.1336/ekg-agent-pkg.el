;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260622.1336"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "a2c73924cda658ee70f6076ffad4f9ee2a91c788"
  :revdesc "a2c73924cda6"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
