;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20250423.1027"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "http://github.com/clojure-emacs/clojure-ts-mode"
  :commit "61041c82be52faf7f931b62b7b300742b04f76a3"
  :revdesc "61041c82be52"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
