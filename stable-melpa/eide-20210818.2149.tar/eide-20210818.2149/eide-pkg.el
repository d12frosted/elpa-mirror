(define-package "eide" "20210818.2149" "IDE interface" 'nil :commit "a547b8f46ed905f456ac37f4693279532cc1d886" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://eide.hjuvi.fr.eu.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
