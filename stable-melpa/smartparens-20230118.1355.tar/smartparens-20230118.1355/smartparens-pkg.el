(define-package "smartparens" "20230118.1355" "Automatic insertion, wrapping and paredit-like navigation with user defined pairs."
  '((dash "2.13.0")
    (cl-lib "0.3"))
  :commit "1cb21a99462ddd8e6501ba8e832b7f77b80fb6a7" :authors
  '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matus Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("abbrev" "convenience" "editing")
  :url "https://github.com/Fuco1/smartparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
