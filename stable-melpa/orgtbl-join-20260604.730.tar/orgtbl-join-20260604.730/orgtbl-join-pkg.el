;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260604.730"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "ab5adbe40af0d0fe7407e779da10980e5d502bef"
  :revdesc "ab5adbe40af0"
  :keywords '("data" "extensions"))
