(define-package "datetime" "20230913.2015" "Parsing, formatting and matching timestamps"
  '((emacs "24.4")
    (extmap "1.1.1"))
  :commit "2f8037f0ba47f6da29afae074b1c5ce507839f6c" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
