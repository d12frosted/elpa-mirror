;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260926.1400"
  "Support for Org links to Magit buffers."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.7")
    (org      "9.8"))
  :url "https://github.com/magit/orgit"
  :commit "ebba35e2fd3fe831eff9a14e088f3cb0b593e215"
  :revdesc "ebba35e2fd3f"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
