(define-package "magit-section" "20220506.1936" "Sections for read-only buffers."
  '((emacs "25.1")
    (compat "28.1.1.0")
    (dash "20210826"))
  :commit "71f7d1df1d715a866269f33ed5c3836ed0839571" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
