(define-package "consult" "20240923.734" "Consulting completing-read"
  '((emacs "28.1")
    (compat "30"))
  :commit "6ba044e6db1c391adee834af9dac48e163dd5a40" :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
