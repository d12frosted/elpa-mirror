;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "single-window" "20260914.322"
  "Always open buffers in the current window."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/single-window.el"
  :commit "a0bd2a516370a630ad007ccd467e9b4b395c57b1"
  :revdesc "a0bd2a516370"
  :keywords '("convenience" "windows")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
