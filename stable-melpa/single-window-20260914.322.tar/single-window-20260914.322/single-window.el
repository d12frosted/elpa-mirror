;;; single-window.el --- Always open buffers in the current window -*- lexical-binding: t; -*-

;; Copyright (C) 2026 James Cherti

;; Author: James Cherti <https://www.jamescherti.com/contact/>
;; Package-Version: 20260914.322
;; Package-Revision: a0bd2a516370
;; URL: https://github.com/jamescherti/single-window.el
;; Keywords: convenience, windows
;; Package-Requires: ((emacs "24.4"))
;; SPDX-License-Identifier: GPL-3.0-or-later

;; This file is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 2, or (at your option)
;; any later version.

;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; The single-window package forces Emacs to open buffers in the current active
;; window.
;;
;; It keeps your carefully arranged layouts intact, reduces visual clutter, and
;; provides a much more predictable workflow.
;;
;; To ensure it does not break standard Emacs functionality, the package is
;; built to handle the following edge cases and integrations out of the box:
;;
;; - Transient and Magit: Excludes Transient buffers by default, which ensures
;;   that Magit popup menus render correctly and manage their own window
;;   placement.
;; - Ediff control panel: Excludes the Ediff control interface so it can
;;   maintain its specific layout requirements without breaking.
;; - Temporary and utility buffers: Ignores the minibuffer, asynchronous Emacs
;;   warnings, Org capture popups, and built-in *Completions* buffers so they do
;;   not hijack your active workspace.
;; - Dedicated windows: Safely handles dedicated windows in the background
;;   (e.g., grep-mode or embark-export), temporarily un-dedicating them to load
;;   the buffer without throwing errors or breaking the layout.
;; - Org-mode integrations: Configures Org-mode to open source blocks, the
;;   agenda, and indirect buffers directly in the active window
;; - Manual overrides: Allows you to temporarily bypass the single-window
;;   enforcement by passing a prefix argument (e.g., C-u) before running a
;;   command.
;;
;; The package also provides the following customization options:
;;
;; - Custom window rules: Provides a setting
;;   (`single-window-respect-display-buffer-alist') that lets you prioritize
;;   your own custom display rules for specific buffers, while falling back to
;;   the single-window behavior for everything else.
;; - Customizable exclusions: Allows you to define additional exclusions via the
;;   `single-window-exclude-regexps' variable, which accepts a list of regular
;;   expressions to match ignored buffer names.
;; - Popper integration: Provides `single-window-exclude-popper' (disabled by
;;   default) to allow popper to bypass the single-window package enforcement
;;   for its popups.

;;; Code:

;;; Variables

(defgroup single-window nil
  "Always open buffer in the current window."
  :group 'windows
  :prefix "single-window-"
  :link '(url-link
          :tag "Github"
          "https://github.com/jamescherti/single-window.el"))

(defcustom single-window-exclude-regexps
  '("^\\*Warnings\\*$"             ; Async Emacs warnings
    "^\\*Org Select\\*$"           ; `org-capture'
    "^ \\*Agenda "                ; `org-agenda'
    "^\\*Calendar\\*$"             ; Org-mode date picker
    "^\\*Completions\\*$"          ; Built-in completion
    "^\\*pathaction"              ; The pathaction package
    "^\\*compilation\\*$"          ; Built-in compilation
    "^\\*Ediff Control Panel\\*$"  ; Ediff control interface
    "^ \\*Minibuf-"               ; Minibuffer internal buffers
    "^ \\*transient\\*$")          ; Transient and Magit
  "List of regular expressions matching buffers to exclude.
When a buffer name matches any of these regexps, `single-window-mode'
will not force it to open in the current window. This is especially
useful for temporary utility buffers that hide their mode-line."
  :type '(repeat regexp)
  :group 'single-window)

(defcustom single-window-respect-display-buffer-alist nil
  "When non-nil, respect existing rules in `display-buffer-alist'.
If no rule matches, fallback to opening the buffer in the current window."
  :type 'boolean
  :group 'single-window)

(defcustom single-window-exclude-popper nil
  "When non-nil, allow `popper' to manage its popup buffers.
If `popper-mode' is active, buffers designated as popups by popper will bypass
`single-window-mode' enforcement and open according to popper's window rules."
  :type 'boolean
  :group 'single-window)

;;; Internal variables

(defvar org-agenda-window-setup)
(defvar org-indirect-buffer-display)
(defvar org-src-window-setup)
(defvar switch-to-buffer-in-dedicated-window)
(defvar switch-to-buffer-obey-display-actions)
(defvar single-window--save-vars nil)

;;; Functions

(defun single-window--force-single-window-advice (orig-fun
                                                  buffer-or-name
                                                  &rest args)
  "Advice to force functions to open in the current window.
ORIG-FUN is the original function being advised.
BUFFER-OR-NAME is the buffer or buffer name to display.
ARGS are the remaining arguments passed to ORIG-FUN."
  (let* ((buf (get-buffer buffer-or-name))
         (buf-name (if buf
                       (buffer-name buf)
                     (if (stringp buffer-or-name)
                         buffer-or-name
                       "")))
         (action (car args))
         (funcs (if (listp action) (car action) nil))
         (no-window (or (eq action 'display-buffer-no-window)
                        (eq funcs 'display-buffer-no-window)
                        (and (listp funcs)
                             (memq 'display-buffer-no-window funcs))))
         (excluded-by-regexp
          (when single-window-exclude-regexps
            (catch 'match
              (dolist (re single-window-exclude-regexps)
                (when (and buf-name (string-match-p re buf-name))
                  (throw 'match t)))
              nil)))
         (excluded-by-popper
          (and single-window-exclude-popper
               buf
               (bound-and-true-p popper-mode)
               (fboundp 'popper-display-control-p)
               ;; Does Popper consider THIS SPECIFIC buffer a popup?
               (popper-display-control-p buf))))
    (if (or current-prefix-arg
            excluded-by-regexp
            excluded-by-popper
            no-window)
        (apply orig-fun buffer-or-name args)
      (let* ((single-window-fallback-rule
              ;; We pass a list of two display action functions to act as a
              ;; primary and a fallback.
              ;;
              ;; 1. `display-buffer-same-window': The primary goal. Force the
              ;;    buffer into the active window.
              ;; 2. `display-buffer-use-some-window': The safety fallback. If
              ;;    Emacs cannot use the current window (e.g., the user invoked
              ;;    a command while inside the minibuffer, which cannot display
              ;;    normal buffers), Emacs's behavior is to split the frame.
              ;;    This fallback catches that edge case and forces Emacs to
              ;;    hijack another existing window instead of creating a new
              ;;    split.
              '(".*"
                (display-buffer-same-window
                 display-buffer-use-some-window)
                (inhibit-same-window . nil)))
             (display-buffer-alist
              (if single-window-respect-display-buffer-alist
                  (append display-buffer-alist
                          (list single-window-fallback-rule))
                (append (list single-window-fallback-rule)
                        display-buffer-alist)))
             (window (selected-window)))
        (let ((dedicated (window-dedicated-p window)))
          (if (and dedicated (not (window-minibuffer-p window)))
              (progn
                (set-window-dedicated-p window nil)
                (unwind-protect
                    (apply orig-fun buffer-or-name args)
                  (set-window-dedicated-p window dedicated)))
            (apply orig-fun buffer-or-name args)))))))

;;; Mode

;;;###autoload
(define-minor-mode single-window-mode
  "Toggle `single-window-mode'."
  :global t
  :lighter " single-window"
  :group 'single-window
  (if single-window-mode
      ;; Enable
      (progn
        ;; Save variables only if they have not been saved yet
        (unless single-window--save-vars
          (dolist (var '(org-src-window-setup
                         org-agenda-window-setup
                         org-indirect-buffer-display
                         switch-to-buffer-obey-display-actions
                         switch-to-buffer-in-dedicated-window
                         ;; pop-up-windows
                         ;; pop-up-frames
                         ))
            (when (boundp var)
              (push (cons var (symbol-value var)) single-window--save-vars))))

        ;; Allow buffer switching in dedicated windows
        (when (boundp 'switch-to-buffer-in-dedicated-window)
          (setq switch-to-buffer-in-dedicated-window t))

        ;; Route buffer switching through display actions
        (when (boundp 'switch-to-buffer-obey-display-actions)
          (setq switch-to-buffer-obey-display-actions t))

        ;; Discourage creating new windows and frames globally
        ;; (setq pop-up-windows t)
        ;; (setq pop-up-frames nil)

        ;; Configure org
        (setq org-src-window-setup 'current-window)
        (setq org-agenda-window-setup 'current-window)
        (setq org-indirect-buffer-display 'current-window)

        ;; Advise display-buffer to catch all rogue commands
        (advice-add 'display-buffer
                    :around
                    #'single-window--force-single-window-advice))
    ;; Disable
    (dolist (var single-window--save-vars)
      (set (car var) (cdr var)))
    (setq single-window--save-vars nil)

    (advice-remove 'display-buffer
                   #'single-window--force-single-window-advice)))

;;; Provide

(provide 'single-window)

;;; single-window.el ends here
