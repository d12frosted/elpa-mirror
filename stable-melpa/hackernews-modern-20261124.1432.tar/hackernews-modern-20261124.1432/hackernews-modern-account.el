;;; hackernews-modern-account.el --- Hacker News login for hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Session handling for hackernews-modern: login with auth-source or a
;; pasted browser cookie, logout, requests to the Hacker News website
;; and the account widgets shown in the headers.

;;; Code:

(require 'auth-source)
(require 'url)
(require 'url-cookie)
(require 'hackernews-modern-core)

(declare-function hackernews-modern-submit "hackernews-modern-submit" ())
(declare-function hackernews-modern-user "hackernews-modern-user" (name))

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern--karma nil
  "Cons of the logged in user name and its karma, once fetched.")

(defun hackernews-modern--current-user ()
  "Return the name of the logged in Hacker News user, or nil.
The session lives in the \"user\" cookie set by the website, whose
value starts with the user name."
  (url-do-setup)
  (let ((cookie (seq-find (lambda (cookie)
                            (equal (url-cookie-name cookie) "user"))
                          (url-cookie-retrieve hackernews-modern-site-host "/" t))))
    (when cookie
      (car (split-string (url-cookie-value cookie) "&")))))

(defun hackernews-modern--site-request (path callback &optional data)
  "Request PATH from the Hacker News website asynchronously.
When DATA is non-nil, it is a list of (KEY VALUE) pairs sent as a
form with a POST request.  Redirects are followed and session
cookies are sent and stored.  Calls CALLBACK with the decoded body
of the final page, or nil on network errors, and a non-nil second
argument when the server answered with a redirect."
  (let ((url-request-method (if data "POST" "GET"))
        (url-request-extra-headers
         (when data
           '(("Content-Type" . "application/x-www-form-urlencoded"))))
        (url-request-data (when data (url-build-query-string data))))
    (url-retrieve
     (hackernews-modern--site-url path)
     (lambda (status)
       (let ((body (and (not (plist-get status :error))
                        (progn
                          (goto-char (point-min))
                          (re-search-forward "\r?\n\r?\n" nil t))
                        (decode-coding-string
                         (buffer-substring-no-properties (point) (point-max))
                         'utf-8))))
         (kill-buffer (current-buffer))
         (funcall callback body (plist-get status :redirect))))
     nil t)))

(defun hackernews-modern--sent-p (redirect)
  "Return non-nil if REDIRECT shows that a form was accepted.
Hacker News redirects after accepting a form, but also to a dead
link when its anti-forgery token has expired."
  (and redirect (not (string-match-p "deadlink" redirect))))

(defun hackernews-modern--login-page-p (body)
  "Return non-nil if BODY asks to log in."
  (let ((case-fold-search t))
    (string-match-p "<form[^>]*action=['\"]?/?login\\|you have to be logged in" body)))

(defun hackernews-modern--goto-item-path (link id)
  "Return LINK of item ID changed to redirect to the page of ID.
The page then shows the state of the item, which tells whether the
change was applied: Hacker News redirects even when it ignores a
vote."
  (let ((target (concat "goto=" (url-hexify-string (format "item?id=%s" id)))))
    (if (string-match "goto=[^&]*" link)
        (replace-match target t t link)
      (concat link "&" target))))

(defun hackernews-modern--page-message (body)
  "Return the text of the Hacker News page BODY as a short message."
  (let ((text (string-trim
               (replace-regexp-in-string
                " \\([.,;:!?]\\)" "\\1"
                (replace-regexp-in-string
                 "[ \t\n]+" " "
                 (hackernews-modern--decode-entities
                  (replace-regexp-in-string "<[^>]*>" " " (or body ""))))))))
    (if (string-empty-p text)
        "No response from Hacker News"
      (truncate-string-to-width text 200 nil nil "..."))))

(defun hackernews-modern--user-karma (user)
  "Return the karma of USER, or nil while it is being fetched.
The karma is fetched once from the API and then the account line
of every hackernews-modern buffer is refreshed."
  (if (equal (car hackernews-modern--karma) user)
      (cdr hackernews-modern--karma)
    (setq hackernews-modern--karma (list user))
    (hackernews-modern--fetch-json
     (hackernews-modern--user-url user)
     (lambda (data error)
       (when error
         (message "Error reading the karma of %s: %s" user error))
       (when (and data (equal (car hackernews-modern--karma) user))
         (setq hackernews-modern--karma (cons user (cdr (assq 'karma data))))
         (hackernews-modern--refresh-account-lines))))
    nil))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--insert-account ()
  "Insert the right aligned login or account widgets.
They go on the next line when they do not fit after the text before
them.  The inserted text is marked so that
`hackernews-modern--refresh-account-lines' can redraw it."
  (let* ((start (point))
         (user  (hackernews-modern--current-user))
         (karma (and user (hackernews-modern--user-karma user)))
         (label (if user
                    (concat user (if karma (format " (%s)" karma) ""))
                  ""))
         (width (+ (string-width label) (if user 26 9))))
    ;; Go to the next line when the text before leaves no room
    (when (> (+ (current-column) width 1) hackernews-modern-display-width)
      (insert "\n"))
    (insert (make-string (max 1 (- hackernews-modern-display-width
                                   (current-column) width))
                         ?\s))
    (if user
        (progn
          (widget-create 'push-button
                         :notify (lambda (&rest _) (hackernews-modern-submit))
                         :help-echo "Submit a story to Hacker News"
                         " Submit ")
          (insert " ")
          (widget-create 'push-button
                         :notify (lambda (&rest _) (hackernews-modern-user user))
                         :help-echo "View your profile, lists and settings"
                         (format " %s " label))
          (insert " ")
          (widget-create 'push-button
                         :notify (lambda (&rest _) (hackernews-modern-logout))
                         :help-echo "Log out from Hacker News"
                         " Logout "))
      (widget-create 'push-button
                     :notify (lambda (&rest _) (hackernews-modern-login))
                     :help-echo "Log in to Hacker News to comment"
                     " Login "))
    (put-text-property start (point) 'hackernews-modern-account t)))

(defun hackernews-modern--refresh-account-lines ()
  "Redraw the account widgets of every hackernews-modern buffer."
  (dolist (buffer (buffer-list))
    (when (buffer-live-p buffer)
      (with-current-buffer buffer
	(let ((start (and (or (derived-mode-p 'hackernews-modern-mode)
                              (derived-mode-p 'hackernews-modern-comments-mode)
                              (derived-mode-p 'hackernews-modern-user-mode))
                          (text-property-any (point-min) (point-max)
                                             'hackernews-modern-account t)))
              (inhibit-read-only t))
          (when start
            (save-excursion
              (let ((end (next-single-property-change
                          start 'hackernews-modern-account nil (point-max)))
                    (widgets '()))
		(dolist (overlay (overlays-in start end))
                  (let ((widget (overlay-get overlay 'button)))
                    (when widget
                      (cl-pushnew widget widgets))))
		(mapc #'widget-delete widgets)
		(delete-region start (next-single-property-change
                                      start 'hackernews-modern-account nil (point-max)))
		(goto-char start)
		(hackernews-modern--insert-account)
		(widget-setup)))))))))

(defun hackernews-modern--refresh-session-buffers ()
  "Redraw every hackernews-modern buffer after a session change."
  (dolist (buffer (buffer-list))
    (with-current-buffer buffer
      (when hackernews-modern--redraw-function
        (hackernews-modern--redraw hackernews-modern--redraw-function)))))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--login-credentials ()
  "Return the Hacker News user name and password as a cons.
They are read from `auth-source' when available and prompted for
otherwise."
  (let* ((auth   (car (auth-source-search :host hackernews-modern-site-host
                                          :max 1 :require '(:user :secret))))
         (secret (plist-get auth :secret)))
    (cons (or (plist-get auth :user) (read-string "HN username: "))
          (cond ((functionp secret) (funcall secret))
                (secret)
                (t (read-passwd "HN password: "))))))

(defun hackernews-modern--login-done (&optional callback)
  "Persist the session, refresh the account lines and call CALLBACK."
  (url-cookie-write-file)
  (hackernews-modern--refresh-session-buffers)
  (message "Logged in to Hacker News as %s" (hackernews-modern--current-user))
  (when callback
    (funcall callback)))

(defun hackernews-modern-login (&optional callback)
  "Log in to Hacker News and call CALLBACK on success.
Credentials are taken from `auth-source' (host
\"news.ycombinator.com\") or prompted for.  When Hacker News asks
for a CAPTCHA, offer to paste the session cookie of a browser
instead; see `hackernews-modern-login-with-cookie'."
  (interactive)
  (let ((credentials (hackernews-modern--login-credentials)))
    (message "Logging in to Hacker News...")
    (hackernews-modern--site-request
     "login"
     (lambda (body _redirect)
       (cond
        ((hackernews-modern--current-user)
         (hackernews-modern--login-done callback))
        ((and body (string-match-p "recaptcha\\|Validation required" body))
         (when (y-or-n-p "Hacker News requires a CAPTCHA.  Paste the session cookie of your browser? ")
           (hackernews-modern-login-with-cookie
            (read-string "Value of the \"user\" cookie: "))
           (when (hackernews-modern--current-user)
             (when callback
               (funcall callback)))))
        ((and body (string-match-p "Bad login" body))
         (message "Hacker News login failed: wrong user name or password"))
        (t
         (message "Hacker News login failed: %s"
                  (hackernews-modern--page-message body)))))
     `(("acct" ,(car credentials))
       ("pw"   ,(cdr credentials))
       ("goto" "news")))))

(defun hackernews-modern-login-with-cookie (value)
  "Log in to Hacker News using the session cookie VALUE.
Copy the value of the \"user\" cookie of news.ycombinator.com from
a browser where you are logged in.  Useful when the login form
asks for a CAPTCHA."
  (interactive "sValue of the \"user\" cookie: ")
  (url-do-setup)
  (url-cookie-store "user" (string-trim value)
                    (format-time-string "%a, %d %b %Y %T GMT"
                                        (time-add nil (* 365 24 3600)) t)
                    hackernews-modern-site-host "/" t)
  (setq url-cookies-changed-since-last-save t)
  (hackernews-modern--login-done))

(defun hackernews-modern-logout ()
  "Log out from Hacker News by forgetting the session cookie."
  (interactive)
  (url-do-setup)
  (url-cookie-delete-cookies (regexp-quote hackernews-modern-site-host))
  (setq hackernews-modern--karma nil)
  (hackernews-modern--refresh-session-buffers)
  (message "Logged out from Hacker News"))

(defun hackernews-modern--with-login (callback)
  "Call CALLBACK now if logged in, or after logging in."
  (if (hackernews-modern--current-user)
      (funcall callback)
    (hackernews-modern-login callback)))

(provide 'hackernews-modern-account)

;;; hackernews-modern-account.el ends here
