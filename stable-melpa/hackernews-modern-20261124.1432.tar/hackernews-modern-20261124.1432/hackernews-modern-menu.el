;;; hackernews-modern-menu.el --- Item actions menu for hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; The menu opened by the "more" button of stories and comments.  It
;; is a transient menu shown at the bottom of the frame, whose entries
;; can be clicked or chosen with their keys, and lists only the
;; actions available on the item, labeled with its state.

;;; Code:

(require 'transient)
(require 'hackernews-modern-core)
(require 'hackernews-modern-account)
(require 'hackernews-modern-vote)
(require 'hackernews-modern-actions)
(require 'hackernews-modern-edit)
(require 'hackernews-modern-reply)
(require 'hackernews-modern-user)

(declare-function hackernews-modern--get "hackernews-modern" (prop))
(declare-function hackernews-modern--open-comments "hackernews-modern" (id))

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern--menu nil
  "Plist describing the item of the open menu.
It holds the ID of the item (:id), the item itself (:item), the
buffer the menu was opened from (:buffer) and whether that buffer
shows the comments of a story (:comments).")

(defun hackernews-modern--menu-get (prop)
  "Return PROP of the item of the open menu."
  (plist-get hackernews-modern--menu prop))

(defun hackernews-modern--menu-story-p ()
  "Return non-nil if the item of the open menu is a story."
  (if (hackernews-modern--menu-get :comments)
      (eql (hackernews-modern--menu-get :id)
           (buffer-local-value 'hackernews-modern--comments-id
                               (hackernews-modern--menu-get :buffer)))
    (not (equal (cdr (assq 'type (hackernews-modern--menu-get :item))) "comment"))))

(defun hackernews-modern--menu-by ()
  "Return the author of the item of the open menu."
  (cdr (assq 'by (hackernews-modern--menu-get :item))))

(defun hackernews-modern--menu-own-p ()
  "Return non-nil if the item of the open menu was written by you."
  (let ((user (hackernews-modern--current-user)))
    (and user (equal user (hackernews-modern--menu-by)))))

(defun hackernews-modern--menu-find-item (id)
  "Return the item with ID shown in the current buffer, or nil."
  (if (derived-mode-p 'hackernews-modern-comments-mode)
      (gethash id hackernews-modern--comments-items)
    (seq-find (lambda (item) (eql (cdr (assq 'id item)) id))
              (hackernews-modern--get :shown))))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--menu-title ()
  "Return the title of the open menu."
  (let* ((item  (hackernews-modern--menu-get :item))
         (time  (cdr (assq 'time item)))
         (title (cdr (assq 'title item))))
    (concat
     (if (and (hackernews-modern--menu-story-p) title)
         (format "Story: %s" (xml-substitute-special title))
       (format "Comment by %s" (or (hackernews-modern--menu-by) "unknown")))
     (if time (format " · %s" (hackernews-modern--time-ago time)) ""))))

(defun hackernews-modern--menu-action-label (action applied unapplied)
  "Return APPLIED or UNAPPLIED as ACTION is applied on the menu item."
  (if (cdr (hackernews-modern--action-link (hackernews-modern--menu-get :id) action))
      applied
    unapplied))

(defun hackernews-modern--menu-vote-label ()
  "Return the label of the vote entry of the open menu."
  (if (hackernews-modern--voted-p (hackernews-modern--menu-get :id))
      "Remove your vote"
    "Upvote"))

(defun hackernews-modern--menu-can-vote-p ()
  "Return non-nil if you can vote the item of the open menu."
  (hackernews-modern--can-vote-p (hackernews-modern--menu-by)))

(defun hackernews-modern--menu-can-downvote-p ()
  "Return non-nil if the menu should offer to downvote its item.
The website only offers it with enough karma, and an upvoted item
has to be unvoted first."
  (let ((id (hackernews-modern--menu-get :id)))
    (and (hackernews-modern--menu-can-vote-p)
         (not (eq (hackernews-modern--voted-p id) 'up))
         (or (eq (hackernews-modern--voted-p id) 'down)
             (plist-get (hackernews-modern--vote-entry id) :down)))))

(defun hackernews-modern--menu-has-action-p (action)
  "Return non-nil if ACTION is offered on the item of the open menu."
  (hackernews-modern--action-link (hackernews-modern--menu-get :id) action))

(defun hackernews-modern--menu-has-edit-p (key)
  "Return non-nil if your item of the open menu has an edit link KEY.
KEY is :edit or :delete."
  (and (hackernews-modern--menu-get :comments)
       (hackernews-modern--menu-own-p)
       (plist-get (hackernews-modern--edit-entry (hackernews-modern--menu-get :id)) key)))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--menu-call (function &rest args)
  "Call FUNCTION with the ID of the menu item and ARGS.
It is called in the buffer the menu was opened from."
  (let ((buffer (hackernews-modern--menu-get :buffer)))
    (unless (buffer-live-p buffer)
      (user-error "The buffer of this item is gone"))
    (with-current-buffer buffer
      (apply function (hackernews-modern--menu-get :id) args))))

(defun hackernews-modern-menu-vote ()
  "Upvote the item of the menu, or remove your vote."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--menu-call #'hackernews-modern--toggle-vote))

(defun hackernews-modern-menu-downvote ()
  "Downvote the item of the menu, or remove your downvote."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--menu-call #'hackernews-modern--toggle-downvote))

(defun hackernews-modern-menu-reply ()
  "Reply to the item of the menu."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--menu-call #'hackernews-modern--reply))

(defun hackernews-modern-menu-comments ()
  "Open the comments of the story of the menu."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--menu-call #'hackernews-modern--open-comments))

(defun hackernews-modern-menu-favorite ()
  "Add the item of the menu to your favorites, or remove it."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--menu-call #'hackernews-modern--item-action 'fave 'toggle))

(defun hackernews-modern-menu-hide ()
  "Hide the story of the menu, or show it again."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--menu-call #'hackernews-modern--item-action 'hide
                                (if (hackernews-modern--menu-get :comments) 'toggle t)))

(defun hackernews-modern-menu-flag ()
  "Flag the item of the menu, or remove your flag."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--menu-call #'hackernews-modern--item-action 'flag 'toggle))

(defun hackernews-modern-menu-edit ()
  "Edit your item of the menu."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--menu-call #'hackernews-modern--edit))

(defun hackernews-modern-menu-delete ()
  "Delete your item of the menu."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--menu-call #'hackernews-modern--delete))

(defun hackernews-modern-menu-open-article ()
  "Open the article of the story of the menu."
  (declare (completion ignore))
  (interactive)
  (let ((id (hackernews-modern--menu-get :id)))
    (hackernews-modern--browse-url
     (or (cdr (assq 'url (hackernews-modern--menu-get :item)))
         (hackernews-modern--comments-url id)))))

(defun hackernews-modern-menu-browse ()
  "Open the page of the item of the menu in the browser."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern--browse-url
   (hackernews-modern--comments-url (hackernews-modern--menu-get :id))))

(defun hackernews-modern-menu-copy-link ()
  "Copy the link to the page of the item of the menu."
  (declare (completion ignore))
  (interactive)
  (let ((url (hackernews-modern--comments-url (hackernews-modern--menu-get :id))))
    (kill-new url)
    (message "Copied %s" url)))

(defun hackernews-modern-menu-profile ()
  "View the profile of the author of the item of the menu."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern-user (hackernews-modern--menu-by)))

(defun hackernews-modern-menu-login ()
  "Log in to Hacker News."
  (declare (completion ignore))
  (interactive)
  (hackernews-modern-login))

(transient-define-prefix hackernews-modern--item-menu ()
  "Actions on a Hacker News story or comment."
  :transient-non-suffix #'transient--do-leave
  [:description
   hackernews-modern--menu-title
   ["Vote"
    :if hackernews-modern--menu-can-vote-p
    ("v" hackernews-modern-menu-vote
     :description hackernews-modern--menu-vote-label
     :if hackernews-modern--menu-can-vote-p)
    ("V" hackernews-modern-menu-downvote
     :description (lambda ()
		    (if (eq (hackernews-modern--voted-p (hackernews-modern--menu-get :id)) 'down)
			"Remove your downvote"
		      "Downvote"))
     :if hackernews-modern--menu-can-downvote-p)]
   ["Respond"
    ("c" hackernews-modern-menu-comments
     :description (lambda () (if (hackernews-modern--menu-story-p) "Read comments" "Open in thread"))
     :if-not (lambda () (hackernews-modern--menu-get :comments)))
    ("r" hackernews-modern-menu-reply
     :description (lambda () (if (hackernews-modern--menu-story-p) "Add a comment" "Reply"))
     :if (lambda () (hackernews-modern--menu-get :comments)))]
   ["Keep"
    :if hackernews-modern--current-user
    ("F" hackernews-modern-menu-favorite
     :description (lambda ()
		    (hackernews-modern--menu-action-label
		     'fave "Remove from favorites" "Add to favorites"))
     :if (lambda () (hackernews-modern--menu-has-action-p 'fave)))
    ("x" hackernews-modern-menu-hide
     :description (lambda ()
		    (hackernews-modern--menu-action-label 'hide "Show again" "Hide story"))
     :if (lambda () (and (hackernews-modern--menu-story-p)
			 (hackernews-modern--menu-has-action-p 'hide))))
    ("!" hackernews-modern-menu-flag
     :description (lambda ()
		    (hackernews-modern--menu-action-label 'flag "Remove your flag" "Flag…"))
     :if (lambda () (hackernews-modern--menu-has-action-p 'flag)))]
   ["Yours"
    :if (lambda () (or (hackernews-modern--menu-has-edit-p :edit)
		       (hackernews-modern--menu-has-edit-p :delete)))
    ("e" "Edit" hackernews-modern-menu-edit
     :if (lambda () (hackernews-modern--menu-has-edit-p :edit)))
    ("d" "Delete…" hackernews-modern-menu-delete
     :if (lambda () (hackernews-modern--menu-has-edit-p :delete)))]
   ["Open"
    ("a" "Open article" hackernews-modern-menu-open-article
     :if (lambda () (and (hackernews-modern--menu-story-p)
			 (cdr (assq 'url (hackernews-modern--menu-get :item))))))
    ("P" hackernews-modern-menu-profile
     :description (lambda () (format "Profile of %s" (hackernews-modern--menu-by)))
     :if hackernews-modern--menu-by)
    ("o" "Open in browser" hackernews-modern-menu-browse)
    ("w" "Copy link" hackernews-modern-menu-copy-link)]
   ["Account"
    :if-not hackernews-modern--current-user
    ("L" "Log in to vote and more" hackernews-modern-menu-login)]]
  [("q" "✕ Close" transient-quit-one)])

(defun hackernews-modern--menu-show (id buffer)
  "Open the menu of item ID shown in BUFFER."
  (with-current-buffer buffer
    (setq hackernews-modern--menu
          (list :id id
                :item (hackernews-modern--menu-find-item id)
                :buffer buffer
                :comments (derived-mode-p 'hackernews-modern-comments-mode)))
    (transient-setup 'hackernews-modern--item-menu)))

(defun hackernews-modern--open-menu (id)
  "Open the menu of item ID of the current buffer.
When logged in, the state of the item is read from its page first,
unless it is already known."
  (let ((buffer (current-buffer)))
    (if (or (not (hackernews-modern--current-user))
            (hackernews-modern--action-entry id))
        (hackernews-modern--menu-show id buffer)
      (message "Reading item...")
      (hackernews-modern--fetch-item-state
       id
       (lambda ()
         (message nil)
         (when (and (buffer-live-p buffer)
                    (eq (window-buffer (selected-window)) buffer))
           (run-at-time 0 nil #'hackernews-modern--menu-show id buffer)))))))

(defun hackernews-modern--insert-menu-button (id)
  "Insert the button that opens the menu of item ID."
  (widget-create 'push-button
                 :notify (lambda (&rest _) (hackernews-modern--open-menu id))
                 :help-echo "More actions"
                 :format "%[%v%]"
                 "⋯ more"))

(provide 'hackernews-modern-menu)

;;; hackernews-modern-menu.el ends here
