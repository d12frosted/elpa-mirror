;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews-modern" "20261124.1432"
  "Hacker News client with modern widget UI."
  '((emacs              "28.1")
    (transient          "0.5.0")
    (visual-fill-column "2.2")
    (async-http-queue   "0.1.0"))
  :url "https://git.andros.dev/andros/hackernews-modern-el"
  :commit "2db11280e06aff08347b12ac48b08d6d1c0178ef"
  :revdesc "2db11280e06a"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
