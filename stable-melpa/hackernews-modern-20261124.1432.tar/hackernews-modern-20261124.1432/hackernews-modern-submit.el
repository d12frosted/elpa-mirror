;;; hackernews-modern-submit.el --- Submit stories to Hacker News from hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Buffer to write a story, link or question, and the requests that
;; submit it to Hacker News.

;;; Code:

(require 'hackernews-modern-core)
(require 'hackernews-modern-account)
(require 'thingatpt)

(declare-function hackernews-modern-comments "hackernews-modern-comments" (id))
(defvar eww-data)

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defconst hackernews-modern--submit-buffer "*HN submit*"
  "Name of the buffer where stories are written.")

(defconst hackernews-modern--submit-title-max 80
  "Maximum length of a story title accepted by Hacker News.")

(defconst hackernews-modern--submit-labels
  '((title . "Title: ")
    (url   . "URL:   "))
  "Labels of the fields of the submit buffer.")

(defvar-local hackernews-modern--submit-body-start nil
  "Marker at the start of the text written in the submit buffer.")

(defun hackernews-modern--submit-field-bounds (field)
  "Return the start and end of the value of FIELD as a cons.
FIELD is a key of `hackernews-modern--submit-labels'."
  (save-excursion
    (goto-char (point-min))
    (when (re-search-forward
           (concat "^" (regexp-quote (alist-get field hackernews-modern--submit-labels))
                   "\\(.*\\)$")
           hackernews-modern--submit-body-start t)
      (cons (match-beginning 1) (match-end 1)))))

(defun hackernews-modern--submit-field (field)
  "Return the trimmed value of FIELD in the submit buffer."
  (let ((bounds (hackernews-modern--submit-field-bounds field)))
    (if bounds
        (string-trim (buffer-substring-no-properties (car bounds) (cdr bounds)))
      "")))

(defun hackernews-modern--submit-text ()
  "Return the text written below the fields of the submit buffer."
  (string-trim (buffer-substring-no-properties
                hackernews-modern--submit-body-start (point-max))))

(defun hackernews-modern--url-p (string)
  "Return non-nil if STRING is an http or https URL."
  (string-match-p "\\`https?://[^ \t\n]+\\'" string))

(defun hackernews-modern--submit-initial-url ()
  "Return the URL to start a submission with and where it comes from.
The result is a cons of the URL and the symbol `point' or `kill-ring',
or nil.  The URL at point, the link at point or the page shown by
EWW are preferred to the last killed text."
  (let ((here (or (thing-at-point 'url t)
                  (get-text-property (point) 'shr-url)
                  (and (derived-mode-p 'eww-mode)
                       (plist-get eww-data :url))))
        (kill (ignore-errors (current-kill 0 t))))
    (cond
     ((and (stringp here) (hackernews-modern--url-p here))
      (cons (substring-no-properties here) 'point))
     ((and (stringp kill) (hackernews-modern--url-p (string-trim kill)))
      (cons (substring-no-properties (string-trim kill)) 'kill-ring)))))

(defun hackernews-modern--html-title (html)
  "Return the contents of the title element of HTML, or nil."
  (let ((case-fold-search t))
    (when (string-match "<title[^>]*>\\([^<]*\\)</title>" html)
      (let ((title (string-trim
                    (replace-regexp-in-string
                     "[ \t\r\n]+" " "
                     (hackernews-modern--decode-entities (match-string 1 html))))))
        (unless (string-empty-p title)
          title)))))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--submit-status ()
  "Return the header line of the submit buffer.
It shows the length of the title and the kind of the submission."
  (let* ((length (length (hackernews-modern--submit-field 'title)))
         (count  (format "Title %d/%d" length hackernews-modern--submit-title-max)))
    (concat " "
            (if (> length hackernews-modern--submit-title-max)
                (propertize (concat count " · Title too long") 'face 'error)
              count)
            " · "
            (if (string-empty-p (hackernews-modern--submit-field 'url))
                "Ask HN (no URL)"
              "Link"))))

(defun hackernews-modern--insert-read-only (text &optional first)
  "Insert TEXT in the shadow face, protected from edits.
When FIRST, text can not be inserted before it either."
  (insert (propertize text
                      'read-only t
                      'face 'shadow
                      'front-sticky (and first '(read-only))
                      'rear-nonsticky t)))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defvar hackernews-modern-submit-mode-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "C-c C-c") #'hackernews-modern-submit-send)
    (define-key map (kbd "C-c C-k") #'hackernews-modern-submit-cancel)
    (define-key map (kbd "C-c C-t") #'hackernews-modern-submit-fetch-title)
    map)
  "Keymap used in hackernews-modern submit buffer.")

(define-derived-mode hackernews-modern-submit-mode text-mode "HN Submit"
  "Mode for writing a Hacker News story.

Write the title and the URL in their fields and, optionally, a
text below the separator line.  Leave the URL empty to ask a
question.  The header line shows the length of the title, which
is limited to 80 characters.

\\<hackernews-modern-submit-mode-map>
\\[hackernews-modern-submit-send]	Submit the story.
\\[hackernews-modern-submit-cancel]	Cancel.
\\[hackernews-modern-submit-fetch-title]	Use the title of the page at the URL.

\\{hackernews-modern-submit-mode-map}"
  :interactive nil
  (setq header-line-format '(:eval (hackernews-modern--submit-status)))
  (visual-line-mode 1))

;;;###autoload
(defun hackernews-modern--insert-story-form (intro title url &optional text)
  "Insert the fields of a story after the read-only INTRO lines.
TITLE, URL and TEXT are the initial values.  When URL is nil there
is no URL field, and when TEXT is nil no text can be written.
Return the position at the end of the title."
  (let ((inhibit-read-only t)
        (separator (concat (make-string 72 ?─) "\n"))
        title-end)
    (hackernews-modern--insert-read-only
     (concat intro separator (alist-get 'title hackernews-modern--submit-labels))
     t)
    (insert title)
    (setq title-end (point))
    (when url
      (hackernews-modern--insert-read-only
       (concat "\n" (alist-get 'url hackernews-modern--submit-labels)))
      (insert url))
    (hackernews-modern--insert-read-only (concat "\n" separator))
    (setq hackernews-modern--submit-body-start (point-marker))
    (if text
        (insert text)
      (hackernews-modern--insert-read-only "There is no text to edit in link stories.\n"))
    (set-buffer-modified-p nil)
    title-end))

(defun hackernews-modern--check-story (title url text &optional url-field)
  "Signal a `user-error' if TITLE, URL and TEXT can not be submitted.
When URL-FIELD is non-nil, the story has a URL field but may have
no text."
  (cond
   ((string-empty-p title)
    (user-error "The title is empty"))
   ((> (length title) hackernews-modern--submit-title-max)
    (user-error "The title has %d characters, the limit is %d"
                (length title) hackernews-modern--submit-title-max))
   ((and (not (string-empty-p url)) (not (hackernews-modern--url-p url)))
    (user-error "The URL must start with http:// or https://"))
   ((and (not url-field) (string-empty-p url) (string-empty-p text))
    (user-error "Write a URL, or a text to ask a question"))))

;;;###autoload
(defun hackernews-modern-submit ()
  "Open a buffer to submit a story to Hacker News.
The URL starts with the URL or link at point, the page shown by
EWW or, failing those, the last killed text when it is a URL.  An
unsent story is kept and shown again."
  (interactive)
  (let ((initial (hackernews-modern--submit-initial-url))
        (buffer  (get-buffer-create hackernews-modern--submit-buffer))
        (user    (hackernews-modern--current-user))
        title-end)
    (with-current-buffer buffer
      (unless (derived-mode-p #'hackernews-modern-submit-mode)
        (hackernews-modern-submit-mode)
        (setq title-end
              (hackernews-modern--insert-story-form
               (concat (if user
                           (format "Submitting to Hacker News as %s\n" user)
                         "Submitting to Hacker News (you will be asked to log in)\n")
                       (substitute-command-keys
                        (concat "\\<hackernews-modern-submit-mode-map>"
                                "\\[hackernews-modern-submit-send] submit · "
                                "\\[hackernews-modern-submit-cancel] cancel · "
                                "\\[hackernews-modern-submit-fetch-title] "
                                "fetch title from URL\n"))
                       "Leave the URL empty to ask a question. "
                       "With a URL, the text is optional.\n"
                       (when (eq (cdr initial) 'kill-ring)
                         "The URL comes from the kill ring, check it before submitting.\n"))
               "" (or (car initial) "") ""))))
    (pop-to-buffer buffer '((display-buffer-below-selected)
                            (window-height . 0.4)))
    (when title-end
      (goto-char title-end))))

(defun hackernews-modern-submit-cancel ()
  "Discard the story being written."
  (declare (modes hackernews-modern-submit-mode))
  (interactive)
  (when (or (and (string-empty-p (hackernews-modern--submit-field 'title))
                 (string-empty-p (hackernews-modern--submit-text)))
            (y-or-n-p "Discard this story? "))
    (quit-window t)))

(defun hackernews-modern--submit-set-title (buffer title)
  "Replace the title field of submit BUFFER with TITLE."
  (when (buffer-live-p buffer)
    (with-current-buffer buffer
      (let ((bounds (hackernews-modern--submit-field-bounds 'title)))
        (when bounds
          (save-excursion
            (goto-char (car bounds))
            (delete-region (car bounds) (cdr bounds))
            (insert title)))))))

(defun hackernews-modern-submit-fetch-title ()
  "Replace the title with the title of the page at the URL.
Hacker News asks to use the original title, so check that it does
not include extra text such as the name of the site."
  (declare (modes hackernews-modern-submit-mode))
  (interactive)
  (let ((url    (hackernews-modern--submit-field 'url))
        (buffer (current-buffer)))
    (unless (hackernews-modern--url-p url)
      (user-error "Write a URL first"))
    (message "Fetching title...")
    (url-retrieve
     url
     (lambda (status)
       (let ((title (and (not (plist-get status :error))
                         (progn
                           (goto-char (point-min))
                           (re-search-forward "\r?\n\r?\n" nil t))
                         (hackernews-modern--html-title
                          (decode-coding-string
                           (buffer-substring-no-properties (point) (point-max))
                           'utf-8)))))
         (kill-buffer (current-buffer))
         (if (not title)
             (message "No title found at %s" url)
           (hackernews-modern--submit-set-title buffer title)
           (message "Title fetched, check it follows the original title"))))
     nil t t)))

(defun hackernews-modern-submit-send ()
  "Submit the story of the current buffer to Hacker News."
  (declare (modes hackernews-modern-submit-mode))
  (interactive)
  (let ((title  (hackernews-modern--submit-field 'title))
        (url    (hackernews-modern--submit-field 'url))
        (text   (hackernews-modern--submit-text))
        (buffer (current-buffer)))
    (hackernews-modern--check-story title url text)
    (hackernews-modern--with-login
     (lambda ()
       (hackernews-modern--post-story buffer title url text)))))

(defun hackernews-modern--post-story (buffer title url text &optional retried)
  "Submit the story with TITLE, URL and TEXT written in BUFFER.
The submit form is fetched first to obtain its anti-forgery token.
When the session or the form has expired, try again once unless
RETRIED."
  (message "Submitting story...")
  (hackernews-modern--site-request
   "submit"
   (lambda (body _redirect)
     (let ((fnid (and body
                      (string-match "name=\"fnid\" value=\"\\([^\"]+\\)\"" body)
                      (match-string 1 body))))
       (cond
        (fnid
         (hackernews-modern--site-request
          "r"
          (lambda (result redirect)
            (hackernews-modern--story-posted buffer title url text retried
                                             result redirect))
          `(("fnid"  ,fnid)
            ("fnop"  "submit-page")
            ("title" ,title)
            ("url"   ,url)
            ("text"  ,text))))
        ((and (not retried) body (string-match-p "logged in" body))
         (hackernews-modern-login
          (lambda () (hackernews-modern--post-story buffer title url text t))))
        (t
         (message "Story not submitted: %s"
                  (hackernews-modern--page-message body))))))))

(defun hackernews-modern--story-posted (buffer title url text retried body redirect)
  "Handle the answer to the story with TITLE, URL and TEXT of BUFFER.
BODY and REDIRECT are the page and the redirect target returned by
Hacker News: the newest stories on success, the existing story when
the URL was already submitted, or a dead link when the form
expired, in which case it is sent again unless RETRIED."
  (cond
   ((and redirect (string-match-p "/newest\\'" redirect))
    (hackernews-modern--story-submitted buffer))
   ((and redirect (string-match "item\\?id=\\([0-9]+\\)" redirect))
    (let ((id (string-to-number (match-string 1 redirect))))
      (when (y-or-n-p "This URL was already submitted.  Open its comments? ")
        (hackernews-modern--quit-buffer buffer)
        (hackernews-modern-comments id))))
   ((and redirect (not retried) (string-match-p "deadlink" redirect))
    (hackernews-modern--post-story buffer title url text t))
   (t
    (message "Story not submitted: %s" (hackernews-modern--page-message body)))))

(defun hackernews-modern--story-submitted (buffer)
  "Close submit BUFFER and open the comments of the new story.
Its ID is read from the list of stories of the user."
  (hackernews-modern--quit-buffer buffer)
  (let ((user (hackernews-modern--current-user)))
    (hackernews-modern--site-request
     (format "submitted?id=%s" user)
     (lambda (body _redirect)
       (if (and body
                (string-match "class=\"athing submission\" id=\"\\([0-9]+\\)\"" body))
           (progn
             (hackernews-modern-comments (string-to-number (match-string 1 body)))
             (message "Story submitted"))
         (message "Story submitted, see it in the new stories"))))))

(provide 'hackernews-modern-submit)

;;; hackernews-modern-submit.el ends here
