;;; hackernews-modern-actions.el --- Favorite, hide and flag items in hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Adding items to the favorites, hiding stories and flagging items
;; for hackernews-modern.  Each action is undone the same way, and
;; its links are read from the website, which only offers them to
;; users allowed to use them.

;;; Code:

(require 'hackernews-modern-core)
(require 'hackernews-modern-account)
(require 'hackernews-modern-edit)
(require 'subr-x)

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defconst hackernews-modern--item-actions
  '((fave :label "favorite" :undo "un-favorite"
          :verb "favorite" :progress "Saving favorite..."
          :done "Added to favorites" :undone "Removed from favorites")
    (hide :label "hide" :undo "un-hide"
          :verb "hide" :progress "Hiding story..."
          :done "Story hidden" :undone "Story no longer hidden")
    (flag :label "flag" :undo "unflag"
          :verb "flag" :progress "Flagging..."
          :done "Flagged" :undone "Flag removed"))
  "Actions on items, keyed by the path of their links.
Each value is a plist with the label of the button that applies the
action (:label) and of the one that undoes it (:undo), the verb used
in messages (:verb) and the messages shown while it is sent
\(:progress) and once applied (:done) or undone (:undone).")

(defvar hackernews-modern--actions (make-hash-table)
  "Hash table mapping item IDs to the links of their actions.
Each value is a plist with the user it was read for (:user) and, for
every action of `hackernews-modern--item-actions' offered by the
website, a cons of the path of its link and whether the action is
applied, keyed by the action as a keyword (:fave, :hide or :flag).")

(defun hackernews-modern--action-key (action)
  "Return the keyword under which the link of ACTION is stored."
  (intern (format ":%s" action)))

(defun hackernews-modern--action-entry (id)
  "Return the action plist of item ID for the logged in user, or nil."
  (let ((entry (gethash id hackernews-modern--actions)))
    (and (equal (plist-get entry :user) (hackernews-modern--current-user))
         entry)))

(defun hackernews-modern--action-link (id action)
  "Return the cons of the link of ACTION on item ID and its state.
The state is non-nil when the action is applied.  Return nil when
the link is unknown."
  (plist-get (hackernews-modern--action-entry id)
             (hackernews-modern--action-key action)))

(defun hackernews-modern--read-actions (body)
  "Store the links of the actions on the items of page BODY.
The link of an applied action undoes it and carries \"un=t\".  Only
links carrying the anti-forgery token of a session are kept."
  (let ((user (hackernews-modern--current-user))
        (pos  0))
    (while (string-match
            "<a[ \t][^>]*href=['\"]\\(\\(fave\\|hide\\|flag\\)\\?id=\\([0-9]+\\)[^'\"]*\\)['\"][^>]*>\\([^<]*\\)<"
            body pos)
      (setq pos (match-end 0))
      (let* ((action (intern (match-string 2 body)))
             (id     (string-to-number (match-string 3 body)))
             (label  (string-trim (match-string 4 body)))
             (path   (hackernews-modern--decode-entities (match-string 1 body)))
             (entry  (hackernews-modern--action-entry id)))
        (when (string-match-p "[?&]auth=" path)
          (puthash id
                   (plist-put (plist-put entry :user user)
                              (hackernews-modern--action-key action)
                              (cons path (and (or (string-match-p "[?&]un=t" path)
                                                  (string-prefix-p "un" label))
                                              t)))
                   hackernews-modern--actions))))))

(defun hackernews-modern--fetch-actions (id callback)
  "Read the actions of item ID from its page.
Calls CALLBACK with the body of the page, or nil on errors."
  (hackernews-modern--site-request
   (format "item?id=%s" id)
   (lambda (body _redirect)
     (when body
       (hackernews-modern--read-actions body))
     (funcall callback body))))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--insert-action-marks (id)
  "Insert the marks of item ID being a favorite or flagged."
  (when (cdr (hackernews-modern--action-link id 'fave))
    (insert (propertize " ★" 'face 'hackernews-modern-mark
                        'help-echo "In your favorites")))
  (when (cdr (hackernews-modern--action-link id 'flag))
    (insert (propertize " ⚑" 'face 'hackernews-modern-mark
                        'help-echo "Flagged by you"))))

;;;; Controller ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--action-done (id action on)
  "Update the buffers once ACTION on item ID is applied, or undone.
ON is non-nil when it was applied.  A hidden story is removed from
the story lists."
  (let ((spec (cdr (assq action hackernews-modern--item-actions))))
    (when (and on (eq action 'hide))
      (hackernews-modern--update-stories
       (lambda (shown)
         (seq-remove (lambda (item) (eql (cdr (assq 'id item)) id)) shown))))
    (hackernews-modern--refresh-session-buffers)
    (message "%s" (plist-get spec (if on :done :undone)))))

(defun hackernews-modern--item-action (id action want &optional retried)
  "Apply ACTION on item ID, or undo it, as WANT says.
ACTION is a key of `hackernews-modern--item-actions'.  WANT is t to
apply it, nil to undo it and `toggle' to change its state.  The link
comes from the actions already read, or else from the page of the
item.  When the session has expired, log in again once unless
RETRIED."
  (let ((verb (plist-get (cdr (assq action hackernews-modern--item-actions)) :verb)))
    (if (hackernews-modern--action-link id action)
        (hackernews-modern--apply-action id action want retried)
      (hackernews-modern--fetch-actions
       id
       (lambda (body)
         (cond
          ((null body)
           (message "Not sent: no response from Hacker News"))
          ((hackernews-modern--action-link id action)
           (hackernews-modern--apply-action id action want retried))
          ((and (not retried)
                (not (string-match-p "id=['\"]logout['\"]" body)))
           (hackernews-modern-login
            (lambda () (hackernews-modern--item-action id action want t))))
          (t
           (message "Hacker News does not allow you to %s this item" verb))))))))

(defun hackernews-modern--apply-action (id action want retried)
  "Open the link of ACTION on item ID when its state differs from WANT.
See `hackernews-modern--item-action' for WANT and RETRIED.  Flagging
asks for confirmation first."
  (let* ((spec   (cdr (assq action hackernews-modern--item-actions)))
         (link   (hackernews-modern--action-link id action))
         (active (cdr link))
         (on     (if (eq want 'toggle) (not active) (and want t))))
    (cond
     ((eq active on)
      (hackernews-modern--action-done id action on))
     ((and on (eq action 'flag)
           (not (y-or-n-p "Flag this item as breaking the guidelines? "))))
     (t
      (message "%s" (if on (plist-get spec :progress) "Undoing..."))
      (hackernews-modern--site-request
       (hackernews-modern--goto-item-path (car link) id)
       (lambda (body _redirect)
         (cond
          ((null body)
           (message "Not sent: no response from Hacker News"))
          ((hackernews-modern--login-page-p body)
           (remhash id hackernews-modern--actions)
           (if retried
               (message "Not sent: you are not logged in")
             (hackernews-modern-login
              (lambda () (hackernews-modern--item-action id action want t)))))
          (t
           (hackernews-modern--fetch-actions
            id
            (lambda (_body)
              (if (eq (cdr (hackernews-modern--action-link id action)) on)
                  (hackernews-modern--action-done id action on)
                (message "Hacker News did not %s the item"
                         (if on (plist-get spec :verb) "change")))))))))))))

(provide 'hackernews-modern-actions)

;;; hackernews-modern-actions.el ends here
