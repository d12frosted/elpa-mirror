;;; hackernews-modern-vote.el --- Votes for hackernews-modern -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-3.0-or-later

;; Author: Andros Fenollosa <hi@andros.dev>
;; URL: https://git.andros.dev/andros/hackernews-modern-el

;; This file is NOT part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Upvoting, downvoting and unvoting stories and comments for
;; hackernews-modern.  The vote buttons are only shown when logged in.

;;; Code:

(require 'hackernews-modern-core)
(require 'hackernews-modern-account)
(require 'hackernews-modern-edit)
(require 'hackernews-modern-actions)
(require 'subr-x)

;;;; Model ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defconst hackernews-modern--vote-max-pages 10
  "Maximum number of pages of a thread read to learn its votes.")

(defvar hackernews-modern--votes (make-hash-table)
  "Hash table mapping item IDs to what is known about their votes.
Each value is a plist with the user it was read for (:user), how the
item is voted (:voted, `up', `down' or nil) and the paths of its
vote links (:up, :down and :un).  The API does not tell which items
the user has voted, so this is read from the pages of the website.")

(defun hackernews-modern--vote-entry (id)
  "Return the vote plist of item ID for the logged in user, or nil."
  (let ((entry (gethash id hackernews-modern--votes)))
    (and (equal (plist-get entry :user) (hackernews-modern--current-user))
         entry)))

(defun hackernews-modern--voted-p (id)
  "Return how item ID is known to be voted: `up', `down' or nil."
  (plist-get (hackernews-modern--vote-entry id) :voted))

(defun hackernews-modern--vote-state (how)
  "Return the vote state an item gets with vote HOW.
HOW is \"up\", \"down\" or \"un\"."
  (pcase how
    ("up"   'up)
    ("down" 'down)
    (_      nil)))

(defun hackernews-modern--read-votes (body)
  "Store the vote state and links of every item in page BODY.
An item is voted when the page shows its unvote link or hides its
upvote arrow, and downvoted when that link reads \"undown\".  Only
links carrying the anti-forgery token of a session are kept.
Return the list of item IDs found."
  (let ((user  (hackernews-modern--current-user))
        (found (make-hash-table))
        (pos   0))
    (while (string-match "<a[ \t]\\(?:[^>]*[ \t]\\)?id=['\"]\\(up\\|down\\|un\\)_\\([0-9]+\\)['\"][^>]*>" body pos)
      (setq pos (match-end 0))
      (let* ((tag   (match-string 0 body))
             (how   (match-string 1 body))
             (id    (string-to-number (match-string 2 body)))
             (entry (gethash id found))
             (href  (hackernews-modern--tag-attribute tag "href"))
             (class (or (hackernews-modern--tag-attribute tag "class") "")))
        (when (and href (string-match-p "[?&]auth=" href))
          (setq entry (plist-put entry (intern (concat ":" how)) href)))
        (cond
         ((equal how "un")
          (setq entry (plist-put entry :voted
                                 (if (string-match-p
                                      "\\`[ \t\n]*undown"
                                      (substring body pos (min (length body) (+ pos 20))))
                                     'down
                                   'up))))
         ((and (member "nosee" (split-string class))
               (not (plist-get entry :voted)))
          (setq entry (plist-put entry :voted 'up))))
        (puthash id entry found)))
    (maphash (lambda (id entry)
               (puthash id (plist-put entry :user user) hackernews-modern--votes))
             found)
    (hash-table-keys found)))

(defun hackernews-modern--read-item-page (body)
  "Store the votes, edit links and actions of the items in page BODY."
  (hackernews-modern--read-votes body)
  (hackernews-modern--read-edit-links body)
  (hackernews-modern--read-actions body))

(defun hackernews-modern--fetch-item-state (id callback)
  "Read the votes, edit links and actions of item ID from its page.
Only the first page is read.  Calls CALLBACK when done."
  (hackernews-modern--site-request
   (format "item?id=%s" id)
   (lambda (body _redirect)
     (when body
       (hackernews-modern--read-item-page body))
     (funcall callback))))

(defun hackernews-modern--fetch-votes (id callback &optional page)
  "Read the votes of item ID and its comments from the website.
Pages of long threads are followed up to
`hackernews-modern--vote-max-pages'.  PAGE is the page to read and
defaults to the first one.  Calls CALLBACK when done."
  (let ((page (or page 1)))
    (hackernews-modern--site-request
     (if (= page 1) (format "item?id=%s" id) (format "item?id=%s&p=%s" id page))
     (lambda (body _redirect)
       (when body
         (hackernews-modern--read-item-page body))
       (if (and body
                (< page hackernews-modern--vote-max-pages)
                (string-match-p "class=['\"]morelink['\"]" body))
           (hackernews-modern--fetch-votes id callback (1+ page))
         (funcall callback))))))

(defun hackernews-modern--vote-done (text)
  "Redraw the buffers and show TEXT."
  (hackernews-modern--refresh-session-buffers)
  (message "%s" text))

(defun hackernews-modern--vote-message (how)
  "Return the message shown once vote HOW is applied."
  (pcase how
    ("up"   "Upvoted")
    ("down" "Downvoted")
    (_      "Vote removed")))

(defun hackernews-modern--send-vote (id how link retried)
  "Open vote LINK of item ID, where HOW is \"up\", \"down\" or \"un\".
When the session has expired, log in again once unless RETRIED."
  (let ((state (hackernews-modern--vote-state how)))
    (hackernews-modern--site-request
     (hackernews-modern--goto-item-path link id)
     (lambda (body _redirect)
       (cond
        ((null body)
         (message "Vote not sent: no response from Hacker News"))
        ((hackernews-modern--login-page-p body)
         (remhash id hackernews-modern--votes)
         (if retried
             (message "Vote not sent: you are not logged in")
           (hackernews-modern-login
            (lambda () (hackernews-modern--vote id how t)))))
        ((let ((case-fold-search t))
           (string-match-p "make that vote\\|too old to be modified" body))
         (message "Vote not sent: %s" (hackernews-modern--page-message body)))
        (t
         (hackernews-modern--read-votes body)
         (if (eq (hackernews-modern--voted-p id) state)
             (hackernews-modern--vote-done (hackernews-modern--vote-message how))
           (hackernews-modern--vote-done "Hacker News did not apply the vote"))))))))

(defun hackernews-modern--vote (id how &optional retried)
  "Vote item ID, where HOW is \"up\", \"down\" or \"un\" to unvote.
The vote link comes from the votes already read, or else from the
page of the item.  When the session has expired, log in again once
unless RETRIED."
  (let ((state (hackernews-modern--vote-state how))
        (link  (plist-get (hackernews-modern--vote-entry id) (intern (concat ":" how)))))
    (message (pcase how
               ("up"   "Upvoting...")
               ("down" "Downvoting...")
               (_      "Removing vote...")))
    (if link
        (hackernews-modern--send-vote id how link retried)
      (hackernews-modern--site-request
       (format "item?id=%s" id)
       (lambda (body _redirect)
         (when body
           (hackernews-modern--read-votes body))
         (let ((link (plist-get (hackernews-modern--vote-entry id)
                                (intern (concat ":" how)))))
           (cond
            ((null body)
             (message "Vote not sent: no response from Hacker News"))
            ((and (hackernews-modern--vote-entry id)
                  (eq (hackernews-modern--voted-p id) state))
             (hackernews-modern--vote-done (pcase how
                                             ("up"   "Already upvoted")
                                             ("down" "Already downvoted")
                                             (_      "Not voted"))))
            ((and state (hackernews-modern--voted-p id))
             (message "Remove your vote first"))
            (link
             (hackernews-modern--send-vote id how link retried))
            ((and (not retried)
                  (not (string-match-p "id=['\"]logout['\"]" body)))
             (hackernews-modern-login
              (lambda () (hackernews-modern--vote id how t))))
            ((equal how "down")
             (message "Hacker News does not allow you to downvote this item"))
            (t
             (message "Hacker News does not allow voting on this item")))))))))

;;;; View ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun hackernews-modern--can-vote-p (by)
  "Return non-nil if the logged in user can vote an item written BY."
  (let ((user (hackernews-modern--current-user)))
    (and user (not (equal by user)))))

(defun hackernews-modern--toggle-vote (id)
  "Upvote item ID, or remove the vote if it is already voted."
  (hackernews-modern--vote id (if (hackernews-modern--voted-p id) "un" "up")))

(defun hackernews-modern--toggle-downvote (id)
  "Downvote item ID, or remove the vote if it is already downvoted.
An upvoted item has to be unvoted first."
  (pcase (hackernews-modern--voted-p id)
    ('down (hackernews-modern--vote id "un"))
    ('up   (message "Remove your upvote first"))
    (_     (hackernews-modern--vote id "down"))))

(defun hackernews-modern--insert-vote-button (id)
  "Insert the button that upvotes item ID, or unvotes it if voted.
A voted item shows the direction of its vote highlighted."
  (let ((voted (hackernews-modern--voted-p id)))
    (widget-create 'push-button
                   :notify (lambda (&rest _) (hackernews-modern--toggle-vote id))
                   :help-echo (pcase voted
                                ('up   "You upvoted this, click to remove your vote")
                                ('down "You downvoted this, click to remove your vote")
                                (_     "Upvote"))
                   :button-face (if voted 'hackernews-modern-voted 'widget-button)
                   :format "%[%v%]"
                   (if (eq voted 'down) "▼" "▲"))))

(provide 'hackernews-modern-vote)

;;; hackernews-modern-vote.el ends here
