(define-package "for" "20220921.1022" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "7a9b33880dcd666a9e7047db661ea42c3c8bbce4" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
