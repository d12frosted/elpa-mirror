;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260611.1137"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "5b15c9198e32ae370814847dde80b6b4bac3e0f8"
  :revdesc "5b15c9198e32"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
