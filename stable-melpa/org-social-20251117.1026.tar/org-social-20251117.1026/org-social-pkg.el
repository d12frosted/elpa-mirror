;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251117.1026"
  "An Org-social client."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "4fd0c19977e1e6053a9bbdc69c93c8821170a0a3"
  :revdesc "4fd0c19977e1"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
