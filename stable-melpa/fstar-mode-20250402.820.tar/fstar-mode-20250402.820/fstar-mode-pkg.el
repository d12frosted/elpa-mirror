;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fstar-mode" "20250402.820"
  "Support for F* programming."
  '((emacs             "24.3")
    (dash              "2.11")
    (company           "0.8.12")
    (quick-peek        "1.0")
    (yasnippet         "0.11.0")
    (flycheck          "30.0")
    (company-quickhelp "2.2.0"))
  :url "https://github.com/FStarLang/fstar-mode.el"
  :commit "3bbfe93abd077103e9e4417d076d4f4d21e9acab"
  :revdesc "3bbfe93abd07"
  :keywords '("convenience" "languages")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
