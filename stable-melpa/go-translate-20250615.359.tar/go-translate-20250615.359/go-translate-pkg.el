;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250615.359"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "b8f9c174b1ac2ef9038c7404cb457e92b6a05f64"
  :revdesc "b8f9c174b1ac"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
