(define-package "keg" "20211105.316" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "f0a719892aed5b1b4b644f1339d1ace99c656100" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
