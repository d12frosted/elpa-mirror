;;; difflayer.el --- Overlay diffs on selected regions -*- lexical-binding: t; -*-

;; Copyright (C) 2026 precompute

;; Author: precompute <git@precompute.net>
;; URL: https://github.com/precompute/legit
;; Created: May 26, 2025
;; Modified: October 23, 2026
;; Package-Version: 20261023.1601
;; Package-Revision: b27ec3bafa41
;; Package-Requires: ((emacs "29.1"))

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Difflayer takes two regions and overlays their diff on them.

;;; Code:
;;;; Variables
(defcustom difflayer-highlight-selections t
  "When non-nil, highlight selected regions."
  :type 'boolean :group 'difflayer)

(defcustom difflayer-diff-style 'git-word
  "Diff style to use.
diff     : GNU Diff
git      : git diff (line)
git-word : git diff (word)
git-char : git diff (char)"
  :type 'symbol :group 'difflayer
  :options (list 'diff 'git 'git-char 'git-word))

(defcustom difflayer-deactivate-mark t
  "When non-nil, mark is deactivated after a region is selected."
  :type 'boolean :group 'difflayer)

(defcustom difflayer-preserve-first-selection nil
  "When non-nil, selections are FILO."
  :type 'boolean :group 'difflayer)

(defcustom difflayer-do-not-check-for-binaries nil
  "When non-nil, difflayer will not check for git / diff binaries."
  :type 'boolean :group 'difflayer)

;;;; Internal
(defvar difflayer--current-diff nil
  "Stores the current diff output.")

(defvar difflayer--metadata nil
  "Stores the overlays, region bounds and buffers of the two selected regions.
Keys: :bounds :overlay :buffer")

(defvar difflayer--commands
  (list 'diff (list "diff" "-s" "-U0")
        'git (list "git" "--no-pager" "diff" "--no-index" "-U0")
        'git-word (list "git" "--no-pager" "diff" "--no-index" "-U0" "--word-diff=porcelain" "--word-diff-regex=[^[:space:]]+|[[:space:]]+")
        'git-char (list "git" "--no-pager" "diff" "--no-index" "-U0" "--word-diff=porcelain" "--word-diff-regex=."))
  "Commands associated with `difflayer-diff-style’.")

(defvar difflayer--exit-code nil
  "Exit code for the previous process call by Difflayer.")

(defvar difflayer--done nil
  "States whether difflayer has diffed two regions.")

(defvar difflayer--cached-binary-status 'unchecked
  "Cache the result of `difflayer--check-for-binaries'.")

;;;; Faces
(defface difflayer-highlight-face
  '((t :inherit highlight))
  "Face for highlighting selected regions."
  :group 'difflayer)

(defface difflayer-diff-added
  '((t :inherit diff-added))
  "Face for highlighting new parts of text."
  :group 'difflayer)

(defface difflayer-diff-removed
  '((t :inherit diff-removed))
  "Face for highlighting deleted parts of text."
  :group 'difflayer)

(defface difflayer-rule-face-1
  '((t :underline t :extend t))
  "Face for horizontal rule before selection regions."
  :group 'difflayer)

(defface difflayer-rule-face
  '((t :overline t :extend t))
  "Face for horizontal rule after selection regions."
  :group 'difflayer)

;;;; Functions
;;;;; Check for binaries
(defun difflayer--check-for-binaries ()
  "Check whether the diff and git binaries exist on this system."
  (if (eq difflayer--cached-binary-status 'unchecked)
      (if (and (executable-find "git") (executable-find "diff"))
          (setq difflayer--cached-binary-status 'found)
        (setq difflayer--cached-binary-status 'notfound)
        (error "Difflayer couldn't find the 'git' and/or 'diff' binaries"))
    (when (eq difflayer--cached-binary-status 'notfound)
      (error "Difflayer couldn't find the 'git' and/or 'diff' binaries"))))
;; Maybe `error' is too heavy?

;;;;; Register
(defun difflayer--register-region (&optional metadata)
  "Register the currently active region.
Use METADATA (:bounds :buffer) if specified."
  (when (> (length difflayer--metadata) 1)
    (difflayer--remove-selection-overlay (if difflayer-preserve-first-selection
                                             (car difflayer--metadata)
                                           (cadr difflayer--metadata)))
    (setq difflayer--metadata (if difflayer-preserve-first-selection
                                  (cdr difflayer--metadata)
                                (list (car difflayer--metadata)))))
  (let ((metadata (if metadata
                      metadata
                    (list :bounds (car (region-bounds)) :buffer (current-buffer)))))
    (push (if difflayer-highlight-selections
              (difflayer--add-selection-overlay metadata)
            metadata)
          difflayer--metadata))
  (when difflayer-deactivate-mark (deactivate-mark)))

;;;;; Clear
(defun difflayer--clear-vars (&optional everything)
  "Clear all registered regions and stored diffs.
When EVERYTHING is non-nil, clear all vars and overlays."
  (setq difflayer--metadata nil)
  (setq difflayer--exit-code nil)
  (when everything
    (setq difflayer--current-diff nil)
    (setq difflayer--done nil)
    (difflayer--remove-all-selection-overlays)))

;;;;; Message
(defun difflayer--message (add del)
  "Displays a message with number of lines changed (ADD and DEL)."
  (message "Diff: %s insertion%s, %s deletion%s"
           add (if (> add 1) "s" "") del (if (> del 1) "s" "")))

;;;;; Overlay
;;;;;; Selection
;;;;;;; Add
(defun difflayer--add-selection-overlay (metadata)
  "Add overlay with face `difflayer-highlight-face’ to region in METADATA."
  (with-current-buffer (plist-get metadata :buffer)
    (let ((overlay (make-overlay (car (plist-get metadata :bounds))
                                 (cdr (plist-get metadata :bounds)))))
      (overlay-put overlay 'difflayer-highlight t)
      (overlay-put overlay 'face 'difflayer-highlight-face)
      (overlay-put overlay 'before-string (propertize " " 'display '(space :align-to right) 'face 'difflayer-rule-face-1))
      (overlay-put overlay 'after-string (propertize " " 'display '(space :align-to right) 'face 'difflayer-rule-face))
      (plist-put metadata :overlay overlay))))

(defun difflayer--add-all-selection-overlays ()
  "Add all selection overlays."
  (unless (= 0 (length difflayer--metadata))
    (mapc #'difflayer--add-selection-overlay difflayer--metadata)))

;;;;;;; Remove
(defun difflayer--remove-selection-overlay (metadata)
  "Remove overlay in METADATA."
  (let ((buf (plist-get metadata :buffer)))
    (if (buffer-live-p buf)
        (with-current-buffer buf
          (delete-overlay (plist-get metadata :overlay)))
      (difflayer--clear-vars t)))) ;; If a registered buffer no longer exists, clear everything.

(defun difflayer--remove-all-selection-overlays ()
  "Remove all selection overlays."
  (if (= 0 (length difflayer--metadata))
      (mapc (lambda (b)
              (when (buffer-live-p b)
                (with-current-buffer b
                  (mapc (lambda (o)
                          (when (overlay-get o 'difflayer-highlight)
                            (delete-overlay o)))
                        (car (overlay-lists))))))
            (buffer-list))
    (mapc #'difflayer--remove-selection-overlay difflayer--metadata)))

;;;;;; Diff
;;;;;;; Add Negative Overlay
(defun difflayer--add-negative-overlay (beg end)
  "Add an overlay that shows removal of content between BEG and END."
  (let ((overlay (make-overlay beg end)))
    (overlay-put overlay 'difflayer-highlight t)
    (overlay-put overlay 'face 'difflayer-diff-removed)))

;;;;;;; Add Positive Overlay
(defun difflayer--add-positive-overlay (beg end)
  "Add an overlay that shows addition of content between BEG and END."
  (let ((overlay (make-overlay beg end)))
    (overlay-put overlay 'difflayer-highlight t)
    (overlay-put overlay 'face 'difflayer-diff-added)))

;;;;; Get Diff
(defun difflayer--get-diff ()
  "Call the command associated with `difflayer-diff-style’."
  (let ((tempf0 (make-temp-file "difflayer0"))
        (tempf1 (make-temp-file "difflayer1"))
        (result))
    (setq difflayer--metadata (reverse difflayer--metadata))
    (unwind-protect
        (let* ((r0 (plist-get (car difflayer--metadata) :bounds))
               (r1 (plist-get (cadr difflayer--metadata) :bounds))
               (exec (car (plist-get difflayer--commands difflayer-diff-style)))
               (args (append (cdr (plist-get difflayer--commands difflayer-diff-style))
                             (list "--" tempf0 tempf1)))
               (inhibit-message t))
          (with-current-buffer (plist-get (car difflayer--metadata) :buffer)
            (write-region (car r0) (cdr r0) tempf0))
          (with-current-buffer (plist-get (cadr difflayer--metadata) :buffer)
            (write-region (car r1) (cdr r1) tempf1))
          (setq result
                (apply #'process-lines-handling-status exec #'difflayer--status-handler args)))
      (mapc #'delete-file (list tempf0 tempf1))
      result)))

;;;;;; Status Handler
(defun difflayer--status-handler (status)
  "Handles STATUS for `process-lines-handling-status’ in `difflayer--diff’."
  (setq difflayer--exit-code status)
  t)

;;;;; Overlay Diff
(defun difflayer--overlay-diff (d)
  "Overlay the diff D over regions in `difflayer--metadata’."
  (setq difflayer--current-diff d) ;; debug
  (pcase difflayer-diff-style
    ('git (mapc #'difflayer--overlay-diff--git d))
    ('diff (mapc #'difflayer--overlay-diff--diff d))
    ('git-word (difflayer--overlay-diff--git-word (nthcdr 4 d)))
    ('git-char (difflayer--overlay-diff--git-char (nthcdr 4 d)))
    (_ nil))
  (setq difflayer--done t))

;;;;;; Helper Functions
(defun difflayer--parse-hunk-info (hi)
  "Parse hunk info HI and return a list of four integers.
Hunk info looks like the following:
@@ -N[,N] +N[,N] @@
We assume the user has supplied the correct line."
  (mapcan (lambda (z)
            (let ((y (split-string z ",")))
              (list (string-to-number (car y))
                    (if (= 1 (length y)) 0 (string-to-number (cadr y))))))
          (let ((z (split-string hi)))
            (list (substring (nth 1 z) 1)
                  (substring (nth 2 z) 1)))))

(defun difflayer--pos-bol (line &optional end? buf)
  "Return the position at the beginning of LINE.
When END? is non-nil, return position at the end of LINE.
When BUF is non-nil, use buffer BUF."
  (with-current-buffer (or buf (current-buffer))
    (save-excursion (goto-char (point-min))
                    (if end? (pos-eol line) (pos-bol line)))))

(defun difflayer--pos-eol (line)
  "Call `difflayer--pos-bol' with LINE, and END? set to t."
  (difflayer--pos-bol line t))

(defun difflayer--region-pos-beg (&optional n)
  "Get the beginning position for the first entry in `difflayer--metadata'.
When N is non-nil, use the second entry instead."
  (car (plist-get (nth (if n 1 0) difflayer--metadata) :bounds)))

(defun difflayer--region-line-number-beg (buf &optional n)
  "In buffer BUF, get line number for the beginning of the first region from
`difflayer--metadata'.  When N is non-nil, use the second region instead."
  (with-current-buffer buf
    (line-number-at-pos (difflayer--region-pos-beg n))))

;;;;;; diff-type: git
(defun difflayer--overlay-diff--git (line)
  "Make overlays for a LINE from a git-style diff D.
This function doesn’t consider anything but hunk info."
  (when (= ?@ (aref line 0))
    (let* ((hunkinfo (difflayer--parse-hunk-info line))
           (b1 (plist-get (car difflayer--metadata) :buffer))
           (b2 (plist-get (cadr difflayer--metadata) :buffer))
           (b1beg (+ -1 (nth 0 hunkinfo)
                     (difflayer--region-line-number-beg b1)))
           (b1end (let ((z (nth 1 hunkinfo)))
                    (if (= 0 z) b1beg (+ z b1beg -1))))
           (b2beg (+ -1 (nth 2 hunkinfo)
                     (difflayer--region-line-number-beg b2 t)))
           (b2end (let ((z (nth 3 hunkinfo)))
                    (if (= 0 z) b2beg (+ z b2beg -1)))))
      (with-current-buffer b1
        (difflayer--add-negative-overlay (difflayer--pos-bol b1beg) (difflayer--pos-eol b1end)))
      (with-current-buffer b2
        (difflayer--add-positive-overlay (difflayer--pos-bol b2beg) (difflayer--pos-eol b2end)))
      (difflayer--message (1+ (- b1end b1beg)) (1+ (- b2end b2beg))))))

;;;;;; diff-type: diff
(defun difflayer--overlay-diff--diff (line)
  "Make overlays for a LINE from a diff-style diff D."
  (difflayer--overlay-diff--git line))

;;;;;; diff-type: git-char
(defun difflayer--overlay-diff--git-char (d)
  "Make overlays for git-char diff D."
  (let* ((b1 (plist-get (car difflayer--metadata) :buffer)) ;; buffers 1 and 2
         (b2 (plist-get (cadr difflayer--metadata) :buffer))
         (s1 (difflayer--region-pos-beg))
         (s2 (difflayer--region-pos-beg t))
         (l1 (difflayer--region-line-number-beg b1))
         (l2 (difflayer--region-line-number-beg b2 t))
         p1 p2 ;; positions for regions 1 and 2
         (newlinep (lambda (buf pos) (with-current-buffer buf (eq (char-after pos) ?\n)))))
    (dolist (line d)
      (pcase (aref line 0)
        (?@ (let ((hunkinfo (difflayer--parse-hunk-info line)))
              (setq p1 (max s1 (difflayer--pos-bol (+ -1 (nth 0 hunkinfo) l1) nil b1))
                    p2 (max s2 (difflayer--pos-bol (+ -1 (nth 2 hunkinfo) l2) nil b2)))))
        (?- (when p1
              (let ((z (1- (length line))))
                (with-current-buffer b1 (difflayer--add-negative-overlay p1 (+ p1 z)))
                (setq p1 (+ p1 z)))))
        (?+ (when p2
              (let ((z (1- (length line))))
                (with-current-buffer b2 (difflayer--add-positive-overlay p2 (+ p2 z)))
                (setq p2 (+ p2 z)))))
        (?  (let ((z (1- (length line))))
              (when p1 (setq p1 (+ p1 z)))
              (when p2 (setq p2 (+ p2 z)))))
        (?~ (when (funcall newlinep b1 p1) (setq p1 (1+ p1)))
            (when (funcall newlinep b2 p2) (setq p2 (1+ p2))))
        (_)))))

;;;;;; diff-type: git-word
(defun difflayer--overlay-diff--git-word (d)
  "Make overlays for git-word diff D."
  (difflayer--overlay-diff--git-char d))

;;;;; Difflayer
(defun difflayer (arg)
  "Select two regions and overlay their diffs on them.
Select a region and call this function.  Repeat for the second region.
Call when region is inactive to diff the two previously selected regions.
Without a prefix ARG, use the diff style set in `difflayer-diff-style'.
With \\[universal-argument], allow dynamically choosing diff style.
With \\[universal-argument] \\[universal-argument], clear all state set by difflayer."
  (interactive "P")
  (let ((difflayer-diff-style difflayer-diff-style))
    (cond ((or difflayer--done (= 16 (prefix-numeric-value arg)))
           (difflayer--clear-vars t))
          ((= 4 (prefix-numeric-value arg))
           (setq difflayer-diff-style
                 (intern (completing-read
                          "Diff Style:"
                          (list 'diff 'git 'git-char 'git-word) ;; custom-variable-type is too new?
                          nil t)))))
    (if (region-active-p)
        (difflayer--register-region)
      (if (/= 2 (length difflayer--metadata))
          (message "Difflayer needs 2 regions to work.  You have registered %s."
                   (length difflayer--metadata))
        (unless difflayer-do-not-check-for-binaries (difflayer--check-for-binaries))
        (difflayer--remove-all-selection-overlays)
        (let ((d (difflayer--get-diff)))
          (pcase difflayer--exit-code
            (0 (message "Diff (%s): Regions are identical." difflayer-diff-style))
            (1 (difflayer--overlay-diff d))
            (_ (message "Difflayer: %s exit: %s" difflayer-diff-style difflayer--exit-code))))))))

(defun difflayer-reset ()
  "Reset Difflayer overlays and state.
Alternative: \\[universal-argument] \\[universal-argument] `difflayer'."
  (interactive)
  (difflayer--clear-vars t))

;;; provide
(provide 'difflayer)

;;; TODO (maybe)
;;;; Add a difflayer-reset function if the "arg" isn’t good enough
;;; difflayer.el ends here
