;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20251003.1441"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "450472bd2969bce33ce03a5115d1bd2f5d36e95f"
  :revdesc "450472bd2969"
  :keywords '("calendar" "holidays"))
