(define-package "racket-mode" "20231125.2105" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "0160fca2543ab6d3c9506797533b2cf26cf88c33" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
