;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260607.2228"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "83ade23a58edd1442778fa31c788c16d539ccb86"
  :revdesc "83ade23a58ed"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
