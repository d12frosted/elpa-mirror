;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251026.515"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "ea426e5c90bd24882c8af09c6832da1e12d40f74"
  :revdesc "ea426e5c90bd"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
