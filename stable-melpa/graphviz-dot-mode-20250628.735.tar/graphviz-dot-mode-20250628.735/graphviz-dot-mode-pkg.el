;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphviz-dot-mode" "20250628.735"
  "Mode for the dot-language used by graphviz (att)."
  '((emacs "25.0"))
  :url "https://ppareit.github.io/graphviz-dot-mode/"
  :commit "50fac2efe6c39a4be289b3eb944ba077d72f2d8c"
  :revdesc "50fac2efe6c3"
  :keywords '("mode" "dot" "dot-language" "dotlanguage" "graphviz" "graphs" "att")
  :maintainers '(("Pieter Pareit" . "pieter.pareit@gmail.com")))
