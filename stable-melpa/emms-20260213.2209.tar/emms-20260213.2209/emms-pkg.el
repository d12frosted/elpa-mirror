;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "20260213.2209"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://www.gnu.org/software/emms/"
  :commit "002a8db0913c1780149eb4a9306e6f582efe8974"
  :revdesc "002a8db0913c"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
