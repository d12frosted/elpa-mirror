(define-package "consult" "20210706.1114" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7f837ce628588ab93a496435b4b4bed5cbd166b5" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
