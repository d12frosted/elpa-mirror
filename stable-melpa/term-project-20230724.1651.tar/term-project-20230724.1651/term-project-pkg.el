(define-package "term-project" "20230724.1651" "Terminal management for project.el"
  '((emacs "28.1")
    (term-manager "0.1.0"))
  :commit "f6e55491aedac15b9bf1ef92aaebf35ba9c9dd94" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com")
    ("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("project" "tools" "terminals" "vc")
  :url "https://www.github.com/IvanMalison/term-manager")
;; Local Variables:
;; no-byte-compile: t
;; End:
