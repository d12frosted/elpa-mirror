;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "never-comment" "20140104.2207"
  "Never blocks are comment."
  ()
  :url "http://stackoverflow.com/a/4554658/89376"
  :commit "1996d003cad6bccf1475f7845d79efacbc7cd673"
  :revdesc "1996d003cad6")
