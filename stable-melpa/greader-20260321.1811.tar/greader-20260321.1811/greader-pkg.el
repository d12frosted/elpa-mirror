;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greader" "20260321.1811"
  "Gnamù reader, send buffer contents to a speech engine."
  '((emacs  "26.1")
    (seq    "2.24")
    (compat "29.1.4.5"))
  :url "https://gitlab.com/michelangelo-rodriguez/greader"
  :commit "3128a8df0a4abb4a35537dc0e8e063ade9ce0524"
  :revdesc "3128a8df0a4a"
  :keywords '("tools" "accessibility")
  :authors '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com"))
  :maintainers '(("Michelangelo Rodriguez" . "michelangelo.rodriguez@gmail.com")))
