;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260519.1548"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "3f3f91ea5292af36d6f31824dfde901636047bd6"
  :revdesc "3f3f91ea5292")
