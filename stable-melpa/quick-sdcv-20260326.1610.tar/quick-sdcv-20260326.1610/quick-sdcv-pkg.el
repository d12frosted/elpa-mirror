;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20260326.1610"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "e28c59514500d61d825657fc735fbafce3599d32"
  :revdesc "e28c59514500"
  :keywords '("docs" "startdict" "sdcv"))
