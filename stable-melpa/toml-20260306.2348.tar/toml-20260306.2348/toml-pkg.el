;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260306.2348"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "907e9ef9599f5bd5fbde01afe133417f730e6af5"
  :revdesc "907e9ef9599f"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
