;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260325.1521"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "5b46176ee4728c9e542c8de408e75676cc0384d5"
  :revdesc "5b46176ee472"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
