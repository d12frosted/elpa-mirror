;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exiftool" "20260328.2210"
  "Elisp wrapper around ExifTool."
  '((emacs "27.1"))
  :url "https://git.systemreboot.net/exiftool.el"
  :commit "23e9b7b407440037b23b1f7ad5f2010e41898621"
  :revdesc "23e9b7b40744"
  :keywords '("data")
  :authors '(("Arun I" . "arunisaac@systemreboot.net"))
  :maintainers '(("Arun I" . "arunisaac@systemreboot.net")))
