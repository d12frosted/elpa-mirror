;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260407.556"
  "Major mode for Godot's GDScript language."
  '((emacs "28.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "4913fdcd5aebab2c13d44a4478af1846aa9583bd"
  :revdesc "4913fdcd5aeb"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
