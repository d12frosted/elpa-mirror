(define-package "gptel" "20231108.2129" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "0109d0d1c067aee8fc3228f1f34d766043258cc3" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
