(define-package "x509-mode" "20220905.1652" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "def4acd761ee959b25599a8149488f1ab5789381" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
