;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260608.9"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e9dbe523f841385e9bc6b665bc4c36b06e082e30"
  :revdesc "e9dbe523f841")
