;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260213.1258"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "ec6ecb191fe4cc0e4d3ecf62ef6bc870a6e708a7"
  :revdesc "ec6ecb191fe4"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
