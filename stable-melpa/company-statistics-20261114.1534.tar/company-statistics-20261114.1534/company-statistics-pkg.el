;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-statistics" "20261114.1534"
  "Sort candidates using completion history."
  '((emacs   "24.3")
    (company "0.8.5"))
  :url "https://github.com/company-mode/company-statistics"
  :commit "2ae5457dc5f4ab80c2ca8f1752e5e81ab6203815"
  :revdesc "2ae5457dc5f4"
  :keywords '("abbrev" "convenience" "matching")
  :authors '(("Ingo Lohmar" . "i.lohmar@gmail.com"))
  :maintainers '(("Ingo Lohmar" . "i.lohmar@gmail.com")))
