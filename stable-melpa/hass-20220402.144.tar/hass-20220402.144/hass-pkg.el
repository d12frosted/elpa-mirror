(define-package "hass" "20220402.144" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3"))
  :commit "44bb81d9d1b5263d6fbcd52c708bc81dcca935bb" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
