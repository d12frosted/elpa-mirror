;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260322.541"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "5479da6dadf5dc4c2b8833dc269bd06110dc63c4"
  :revdesc "5479da6dadf5"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
