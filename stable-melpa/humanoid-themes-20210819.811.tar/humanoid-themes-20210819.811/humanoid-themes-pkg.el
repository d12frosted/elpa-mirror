(define-package "humanoid-themes" "20210819.811" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "3a157bab0493fe0654de0324ec59eef9b3d15202" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
