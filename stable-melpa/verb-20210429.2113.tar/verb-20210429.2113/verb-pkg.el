(define-package "verb" "20210429.2113" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "a6e46f436495fb54ba57832450995425ad8dbc26" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
