(define-package "sumibi" "20231019.1246" "Japanese input method powered by ChatGPT API"
  '((emacs "28.1")
    (popup "0.5.9")
    (unicode-escape "1.1")
    (deferred "0.5.1"))
  :commit "d6bbc65b71f0c59a471fffe13797d1ab6cac80f8" :authors
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers
  '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainer
  '("Kiyoka Nishiyama" . "kiyoka@sumibi.org")
  :keywords
  '("lisp" "ime" "japanese")
  :url "https://github.com/kiyoka/Sumibi")
;; Local Variables:
;; no-byte-compile: t
;; End:
