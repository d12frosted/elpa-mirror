;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "intel-hex-mode" "20180423.31"
  "Mode for Intel Hex files."
  ()
  :url "https://github.com/mschuldt/intel-hex-mode"
  :commit "e83c94e1c31a8435a88b3ae395f2bc842ef83217"
  :revdesc "e83c94e1c31a"
  :keywords '("tools" "hex")
  :authors '(("Rubens Ramos" . "rubensrATusers.sourceforge.net"))
  :maintainers '(("Michael Schuldt" . "mbschuldt@gmail.com")))
