(define-package "flycheck-apertium" "20181211.1038" "Apertium checkers in flycheck"
  '((flycheck "0.25"))
  :commit "22b60a17836477ac1edd15dc85b14f88ca871ba9" :keywords
  ("convenience" "tools" "xml")
  :authors
  (("Kevin Brubeck Unhammer" . "unhammer+apertium@mm.st"))
  :maintainer
  ("Kevin Brubeck Unhammer" . "unhammer+apertium@mm.st")
  :url "http://wiki.apertium.org/wiki/Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
