;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-apertium" "20181211.1038"
  "Apertium checkers in flycheck."
  '((flycheck "0.25"))
  :url "http://wiki.apertium.org/wiki/Emacs"
  :commit "22b60a17836477ac1edd15dc85b14f88ca871ba9"
  :revdesc "22b60a178364"
  :keywords '("convenience" "tools" "xml")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer+apertium@mm.st"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer+apertium@mm.st")))
