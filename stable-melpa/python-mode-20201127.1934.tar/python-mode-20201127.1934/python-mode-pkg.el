(define-package "python-mode" "20201127.1934" "Python major mode" 'nil :commit "d8b57753fe70603c9ad6ffc53e1c15912024f980")
;; Local Variables:
;; no-byte-compile: t
;; End:
