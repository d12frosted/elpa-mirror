;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20260909.1534"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.9.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "b65d2544d89ce9ab8f953cb4e545a453ea9eac92"
  :revdesc "b65d2544d89c"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
