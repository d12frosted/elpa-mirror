;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "color-theme-buffer-local" "20170126.601"
  "Install color-themes by buffer."
  '((color-theme "0"))
  :url "https://github.com/vic/color-theme-buffer-local"
  :commit "faf7415c99e132094f1f09c6b6974ec118a18d87"
  :revdesc "faf7415c99e1"
  :keywords '("faces")
  :authors '(("Victor Borja" . "vic.borja@gmail.com"))
  :maintainers '(("Victor Borja" . "vic.borja@gmail.com")))
