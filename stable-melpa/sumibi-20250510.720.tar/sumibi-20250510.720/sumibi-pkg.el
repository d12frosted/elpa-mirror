;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250510.720"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "28.1")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "f781b6d37049fca3548bb62a5e0d259b2beca2a2"
  :revdesc "f781b6d37049"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
