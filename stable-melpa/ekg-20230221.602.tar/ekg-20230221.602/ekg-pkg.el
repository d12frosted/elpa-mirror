(define-package "ekg" "20230221.602" "A system for recording and linking information"
  '((triples "0.2.3")
    (emacs "28.1"))
  :commit "cb3dfbf8c6faa0aa95f603b855eb37260acdc89d" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
