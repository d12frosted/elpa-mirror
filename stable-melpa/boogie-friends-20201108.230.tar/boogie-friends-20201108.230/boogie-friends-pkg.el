(define-package "boogie-friends" "20201108.230" "A collection of programming modes for Boogie, Dafny, and Z3 (SMTLIB v2)."
  '((cl-lib "0.5")
    (dash "2.10.0")
    (flycheck "0.23")
    (yasnippet "0.9.0.1")
    (company "0.8.12"))
  :commit "462acddf8012c896a510f539fa3d16eb3c4dc71b" :authors
  '(("Clément Pit--Claudel" . "clement.pitclaudel@live.com"))
  :maintainer
  '("Clément Pit--Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/boogie-org/boogie-friends/")
;; Local Variables:
;; no-byte-compile: t
;; End:
