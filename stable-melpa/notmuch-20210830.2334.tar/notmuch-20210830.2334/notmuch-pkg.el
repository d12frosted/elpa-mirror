(define-package "notmuch" "20210830.2334" "run notmuch within emacs" 'nil :commit "49aa44bb012e8c2412b5447119b78b61842740b8" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
