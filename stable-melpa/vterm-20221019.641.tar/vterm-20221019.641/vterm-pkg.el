(define-package "vterm" "20221019.641" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "19c84e97a2d682a62d30b284935dca80e4299bed" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
