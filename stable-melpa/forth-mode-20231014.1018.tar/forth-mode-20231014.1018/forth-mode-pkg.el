(define-package "forth-mode" "20231014.1018" "Programming language mode for Forth"
  '((cl-lib "0.2"))
  :commit "3ef319bf2da443cf9f999f42bf854160b32448a0" :authors
  '(("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainers
  '(("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainer
  '("Lars Brinkhoff" . "lars@nocrew.org")
  :keywords
  '("languages" "forth")
  :url "http://github.com/larsbrinkhoff/forth-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
