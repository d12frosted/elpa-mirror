;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260412.1535"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "ea60ab537b6842b2f96d01f08561b86bb5efa319"
  :revdesc "ea60ab537b68"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
