(define-package "modus-themes" "20210613.620" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "a53f23fcc30df1eabf0b17de705e0fe8f0ef7825" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
