;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-phpstan" "20250331.1827"
  "Flycheck integration for PHPStan."
  '((emacs    "24.3")
    (flycheck "26")
    (phpstan  "0.7.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "c9bb8b2a7364165e1f68e9b57f4822435d66521f"
  :revdesc "c9bb8b2a7364"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
