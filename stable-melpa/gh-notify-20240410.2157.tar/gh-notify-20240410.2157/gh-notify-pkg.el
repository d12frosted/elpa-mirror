(define-package "gh-notify" "20240410.2157" "A veneer for Magit/Forge GitHub notifications"
  '((emacs "29.1")
    (magit "3.3.0")
    (forge "0.3.2"))
  :commit "6d1a267309da8e329200f4dd11ffe54110fd7070" :authors
  '(("Bas Alberts" . "bas@anti.computer")
    ("xristos" . "xristos@sdf.org"))
  :maintainers
  '(("Bas Alberts" . "bas@anti.computer"))
  :maintainer
  '("Bas Alberts" . "bas@anti.computer")
  :keywords
  '("comm")
  :url "https://github.com/anticomputer/gh-notify")
;; Local Variables:
;; no-byte-compile: t
;; End:
