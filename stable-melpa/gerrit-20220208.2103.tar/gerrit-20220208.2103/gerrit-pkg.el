(define-package "gerrit" "20220208.2103" "Gerrit client"
  '((emacs "25.1")
    (magit "2.13.1")
    (s "1.12.0")
    (dash "0.2.15"))
  :commit "bd0349236baacfdcdf82cb33c9ba45f451b9b255" :authors
  '(("Thomas Hisch" . "t.hisch@gmail.com"))
  :maintainer
  '("Thomas Hisch" . "t.hisch@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/thisch/gerrit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
