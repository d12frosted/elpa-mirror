;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260427.616"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "da56a41379405963e8725ce47cad2d747fedef9c"
  :revdesc "da56a4137940"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
