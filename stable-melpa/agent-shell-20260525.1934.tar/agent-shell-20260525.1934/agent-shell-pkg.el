;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260525.1934"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "89bd6e136a08e1527dd630e4573639c838fd7e22"
  :revdesc "89bd6e136a08")
