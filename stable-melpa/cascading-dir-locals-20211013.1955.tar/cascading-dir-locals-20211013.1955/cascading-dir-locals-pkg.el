;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cascading-dir-locals" "20211013.1955"
  "Apply all (!) .dir-locals.el from root to current directory."
  '((emacs "26.1"))
  :url "https://github.com/fritzgrabo/cascading-dir-locals"
  :commit "345d4b70e837d45ee84014684127e7399932d5e6"
  :revdesc "345d4b70e837"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
