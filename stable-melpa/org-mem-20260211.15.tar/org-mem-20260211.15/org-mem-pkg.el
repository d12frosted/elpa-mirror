;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260211.15"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "00dc88914cabb740d0d09d180e5b6dbe3a609b0b"
  :revdesc "00dc88914cab"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
