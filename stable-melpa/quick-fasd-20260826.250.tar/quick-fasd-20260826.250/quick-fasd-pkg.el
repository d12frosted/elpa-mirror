;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20260826.250"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "f849c8ae8c2e6166a279dd65e159c59f2b8257ce"
  :revdesc "f849c8ae8c2e"
  :keywords '("convenience" "files" "tools"))
