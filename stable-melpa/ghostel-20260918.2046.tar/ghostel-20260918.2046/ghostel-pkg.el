;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260918.2046"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "6be56484c5375ea08a4888c949d118327ff3d1c4"
  :revdesc "6be56484c537"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
