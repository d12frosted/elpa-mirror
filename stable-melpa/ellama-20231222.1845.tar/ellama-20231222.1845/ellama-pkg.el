(define-package "ellama" "20231222.1845" "Tool for interacting with LLMs"
  '((emacs "28.1")
    (llm "0.6.0")
    (spinner "1.7.4"))
  :commit "b2082aca991311be2657479767d757762871f685" :authors
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers
  '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainer
  '("Sergey Kostyaev" . "sskostyaev@gmail.com")
  :keywords
  '("help" "local" "tools")
  :url "http://github.com/s-kostyaev/ellama")
;; Local Variables:
;; no-byte-compile: t
;; End:
