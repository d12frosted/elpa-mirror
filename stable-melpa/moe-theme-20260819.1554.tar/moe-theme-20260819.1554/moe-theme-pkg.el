;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moe-theme" "20260819.1554"
  "A colorful eye-candy theme. Moe, moe, kyun!."
  ()
  :url "https://github.com/kuanyui/moe-theme.el"
  :commit "6a5c85c89855ff1fba6aa57d68346b9b7bb7cec0"
  :revdesc "6a5c85c89855"
  :keywords '("themes")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
