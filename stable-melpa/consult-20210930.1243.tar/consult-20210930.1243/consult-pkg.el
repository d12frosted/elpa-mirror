(define-package "consult" "20210930.1243" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "48474f1e69755e514ffd6def20147bce28f71f9f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
