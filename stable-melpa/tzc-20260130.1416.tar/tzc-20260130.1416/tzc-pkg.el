;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260130.1416"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "910f651214581ea16aa593f60498c02de577c5bc"
  :revdesc "910f65121458"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
