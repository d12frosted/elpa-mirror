(define-package "embark" "20220521.1736" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "bd603d8f3b1bcff34aee2dc4b7b36dc7912b9b26" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
