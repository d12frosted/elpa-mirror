;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260215.2310"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.10.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "034baa3f6df4bc0cb8f2056339f50b658005647e"
  :revdesc "034baa3f6df4")
