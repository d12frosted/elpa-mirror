(define-package "mistty" "20231006.1752" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "efe490554fff6f97309dba2749c7e780643024b3" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
