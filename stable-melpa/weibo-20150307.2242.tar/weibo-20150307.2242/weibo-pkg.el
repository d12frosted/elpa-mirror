(define-package "weibo" "20150307.2242" "Weibo client for Emacs"
  '((cl-lib "0.5"))
  :commit "a8abb50b7602fe15fe2bc6400ac29780e956b390" :keywords
  ("weibo")
  :authors
  (("Austin" . "austiny.cn@gmail.com"))
  :maintainer
  ("Austin" . "austiny.cn@gmail.com")
  :url "https://github.com/austin-----/weibo.emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
