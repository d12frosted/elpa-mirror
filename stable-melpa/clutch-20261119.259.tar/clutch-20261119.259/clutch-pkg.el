;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261119.259"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "bfd6b64ea0cf39e09c931024632cfa567fdee5b5"
  :revdesc "bfd6b64ea0cf"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
