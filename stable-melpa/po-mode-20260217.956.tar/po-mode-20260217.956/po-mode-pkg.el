;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "po-mode" "20260217.956"
  "Major mode for GNU gettext PO files."
  '((emacs "23"))
  :commit "27538dd0938d5a941833d503afc9dba13dcf16fe"
  :revdesc "27538dd0938d"
  :keywords '("i18n" "gettext"))
