;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "raku-mode" "20261125.1509"
  "Major mode for editing Raku code."
  '((emacs "24.4"))
  :url "https://github.com/hinrik/perl6-mode"
  :commit "4e6d5625bfc3ab2e09d3019ecaf3bfa59e4cc4e8"
  :revdesc "4e6d5625bfc3"
  :keywords '("languages")
  :authors '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com"))
  :maintainers '(("Hinrik rn Sigurðsson" . "hinrik.sig@gmail.com")))
