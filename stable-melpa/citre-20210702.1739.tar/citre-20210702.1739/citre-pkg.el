(define-package "citre" "20210702.1739" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "19461d1f8726cce29424e1cd111ad1af0aa16c22" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
