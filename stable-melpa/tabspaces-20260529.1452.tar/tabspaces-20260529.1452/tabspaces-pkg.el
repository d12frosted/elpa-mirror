;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260529.1452"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://github.com/mclear-tools/tabspaces"
  :commit "d3a74c0d39a0029d956dc37ddbf540802fb76973"
  :revdesc "d3a74c0d39a0"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
