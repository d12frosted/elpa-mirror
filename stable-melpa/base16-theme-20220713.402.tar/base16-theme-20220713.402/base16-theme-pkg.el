(define-package "base16-theme" "20220713.402" "Collection of themes built on combinations of 16 base colors" 'nil :commit "6f37e4a849a84a41c4404a15d1bac57cbf912324" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/base16-project/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
