(define-package "base16-theme" "20220713.402" "Collection of themes built on combinations of 16 base colors" 'nil :commit "e8a5430b367faf43e0c56a7da47aad0751ca0b8b" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/base16-project/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
