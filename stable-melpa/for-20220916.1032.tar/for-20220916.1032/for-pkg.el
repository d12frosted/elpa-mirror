(define-package "for" "20220916.1032" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "5ea476409ae87b473de29673ed372a5c08636f67" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
