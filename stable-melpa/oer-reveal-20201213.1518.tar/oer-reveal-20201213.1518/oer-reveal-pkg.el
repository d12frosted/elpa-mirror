(define-package "oer-reveal" "20201213.1518" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "e321b99788d99505370403ceaf3c6880a5e1f7ae" :keywords
  ("hypermedia" "tools" "slideshow" "presentation" "oer")
  :authors
  (("Jens Lechtenbörger"))
  :maintainer
  ("Jens Lechtenbörger")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
