(define-package "dwim-shell-command" "20230411.721" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "d04809778a3a28e594588efdee34f72e7bd8ef1f" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
