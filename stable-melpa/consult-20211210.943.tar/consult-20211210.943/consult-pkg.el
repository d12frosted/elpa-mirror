(define-package "consult" "20211210.943" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "36ac62c7de467dd8f677421a6366bd17f7c8446d" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
