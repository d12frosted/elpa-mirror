(define-package "consult" "20220718.1254" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "054143c3941f745fa0d950acc2cb0b68338e8b1c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
