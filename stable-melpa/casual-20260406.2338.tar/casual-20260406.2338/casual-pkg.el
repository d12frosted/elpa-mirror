;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260406.2338"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "81e032d24c46159cc98ec5248e48ee3659025ad0"
  :revdesc "81e032d24c46"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
