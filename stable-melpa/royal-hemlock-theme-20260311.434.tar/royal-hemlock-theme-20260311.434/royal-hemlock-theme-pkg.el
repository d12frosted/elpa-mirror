;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "20260311.434"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "1e856571b97f2265654338581e58ee36a6fa81f5"
  :revdesc "1e856571b97f"
  :keywords '("color" "theme" "faces"))
