;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-timeline" "20260916.23"
  "Visual timeline for Org-Roam nodes."
  '((emacs        "27.1")
    (org-roam     "2.0")
    (json-mode    "1.0")
    (simple-httpd "1.5.1"))
  :url "https://github.com/GerardoCendejas/org-roam-timeline"
  :commit "75f210cb76d115f8faf77fcae25584588723b47c"
  :revdesc "75f210cb76d1"
  :keywords '("org" "hypermedia" "visualization" "timeline")
  :authors '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu"))
  :maintainers '(("Gerardo Cendejas Mendoza" . "gc597@cornell.edu")))
