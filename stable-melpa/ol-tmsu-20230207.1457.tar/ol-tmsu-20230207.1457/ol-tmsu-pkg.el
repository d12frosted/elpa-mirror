;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ol-tmsu" "20230207.1457"
  "Org-mode links to TMSU queries."
  '((emacs "28.1")
    (tmsu  "0.9"))
  :url "https://github.com/vifon/tmsu.el"
  :commit "9672d193a51f2848696445528de757aa21b2b686"
  :revdesc "9672d193a51f"
  :keywords '("files" "outlines" "hypermedia"))
