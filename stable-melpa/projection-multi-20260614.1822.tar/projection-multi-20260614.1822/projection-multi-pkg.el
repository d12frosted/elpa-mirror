;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projection-multi" "20260614.1822"
  "Projection integration for `compile-multi'."
  '((emacs         "29.1")
    (projection    "0.1")
    (compile-multi "0.5"))
  :url "https://github.com/mohkale/projection"
  :commit "66dfa454cbd0ca356d0c5761f6ade248b612b204"
  :revdesc "66dfa454cbd0"
  :keywords '("project" "convenience")
  :authors '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers '(("Mohsin Kaleem" . "mohkale@kisara.moe")))
