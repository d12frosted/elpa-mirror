(define-package "macports" "20220503.606" "A porcelain for MacPorts"
  '((emacs "25.1")
    (transient "0.1.0"))
  :commit "32f78a4dde9abe2f177244a5d004fe79b6a60dd4" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("convenience")
  :url "https://github.com/amake/macports.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
