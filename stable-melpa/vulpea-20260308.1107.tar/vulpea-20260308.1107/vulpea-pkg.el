;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260308.1107"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "4433949421f302edefb575896265f11a261275bf"
  :revdesc "4433949421f3"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
