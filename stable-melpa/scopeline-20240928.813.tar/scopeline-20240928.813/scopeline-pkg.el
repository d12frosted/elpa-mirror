(define-package "scopeline" "20240928.813" "Show scope info of blocks in buffer at end of scope"
  '((emacs "29.1"))
  :commit "f9166b1df3aa3eebdac3b544da159b09eebcb3cc" :keywords
  '("scope" "context" "tree-sitter" "convenience")
  :url "https://github.com/meain/scopeline.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
