(define-package "nim-mode" "20230928.2104" "A major mode for the Nim programming language"
  '((emacs "24.4")
    (epc "0.1.1")
    (let-alist "1.0.1")
    (commenter "0.5.1")
    (flycheck-nimsuggest "0.8.1"))
  :commit "674ecd1ebfe23cb13791edbf5c79e3bec25dbdc5" :authors
  '(("Simon Hafner"))
  :maintainers
  '(("Simon Hafner" . "hafnersimon@gmail.com"))
  :maintainer
  '("Simon Hafner" . "hafnersimon@gmail.com")
  :keywords
  '("nim" "languages")
  :url "https://github.com/nim-lang/nim-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
