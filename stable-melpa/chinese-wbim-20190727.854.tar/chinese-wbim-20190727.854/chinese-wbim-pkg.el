;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chinese-wbim" "20190727.854"
  "Enable Wubi(五笔) Input Method in Emacs."
  ()
  :url "https://github.com/andyque/chinese-wbim"
  :commit "5d496364b0b6bbaaf0f9b37e5a6d260d4994f260"
  :revdesc "5d496364b0b6"
  :keywords '("wubi" "input" "method.")
  :authors '(("Guanghui Qu" . "guanghui8827@gmail.com"))
  :maintainers '(("Guanghui Qu" . "guanghui8827@gmail.com")))
