(define-package "r-autoyas" "20120918.653" "Provides automatically created yasnippets for R function argument lists." 'nil :commit "563254f01ce530ca4c9be1f23395e3fd7d520ff9" :authors
  '(("Sven Hartenstein & Matthew Fidler"))
  :maintainer
  '("Matthew Fidler")
  :keywords
  '("r" "yasnippet")
  :url "https://github.com/mlf176f2/r-autoyas.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
