;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grip-mode" "20261007.1036"
  "Instant GitHub-flavored Markdown/Org preview using grip."
  '((emacs "24.4"))
  :url "https://github.com/seagle0128/grip-mode"
  :commit "fa5dc512eac835545063813e28bcf9f8da57e0db"
  :revdesc "fa5dc512eac8"
  :keywords '("convenience" "markdown" "preview")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
