;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260222.358"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "f7874b0ffb85d949c2f5d564159e3cf04153368a"
  :revdesc "f7874b0ffb85"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
