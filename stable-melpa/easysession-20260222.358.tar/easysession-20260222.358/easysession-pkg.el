;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260222.358"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "6198a7b212284600d24a72ff09b911b4f67217da"
  :revdesc "6198a7b21228"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
