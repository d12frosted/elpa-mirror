;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20261019.951"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.5.0")
    (vui    "1.3.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "0cb3a3ecd6b1641da3ed28f578c9173ee39bb724"
  :revdesc "0cb3a3ecd6b1"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
