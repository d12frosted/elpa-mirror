;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260223.1711"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (transient  "0.7.0")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "3074525e5fc54a801e4102742fe362e7ac1b10f7"
  :revdesc "3074525e5fc5"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
