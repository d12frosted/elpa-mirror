;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phi-autopair" "20210306.424"
  "Another simple-minded autopair implementation."
  '((paredit "20"))
  :url "http://zk-phi.gitub.io/"
  :commit "6a67c37d31a3ff9261fc9f812547a0c86721fc90"
  :revdesc "6a67c37d31a3")
