(define-package "chronos" "20150602.1529" "multiple simultaneous countdown / countup timers" 'nil :commit "b360d9dae57aa553cf2a14ffa0756a51ad71de09" :keywords
  ("calendar")
  :authors
  (("David Knight" . "dxknight@opmbx.org"))
  :maintainer
  ("David Knight" . "dxknight@opmbx.org")
  :url "http://github.com/dxknight/chronos")
;; Local Variables:
;; no-byte-compile: t
;; End:
