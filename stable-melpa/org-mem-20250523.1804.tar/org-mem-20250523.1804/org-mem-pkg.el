;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250523.1804"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "4ee47a7a4468729ff587c3382122937e07f436c8"
  :revdesc "4ee47a7a4468"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
