;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "file-info" "20250929.939"
  "Show pretty information about current file."
  '((emacs            "28.1")
    (hydra            "0.15.0")
    (browse-at-remote "0.15.0"))
  :url "https://github.com/artawower/file-info.el"
  :commit "60208db2d6dda49208e50502e7fe3837cb9dda4f"
  :revdesc "60208db2d6dd"
  :authors '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers '(("Artur Yaroshenko" . "artawower@protonmail.com")))
