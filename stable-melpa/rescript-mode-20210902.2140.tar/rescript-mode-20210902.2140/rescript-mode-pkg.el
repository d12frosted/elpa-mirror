(define-package "rescript-mode" "20210902.2140" "A major mode for editing ReScript"
  '((emacs "26.1"))
  :commit "4bd88e4e835af2f9f7c0b65cf4488570126d4fef" :authors
  '(("Karl Landstrom" . "karl.landstrom@brgeight.se")
    ("Daniel Colascione" . "dancol@dancol.org")
    ("John Lee" . "jjl@pobox.com"))
  :maintainer
  '("John Lee" . "jjl@pobox.com")
  :keywords
  '("languages" "rescript")
  :url "https://github.com/jjlee/rescript-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
