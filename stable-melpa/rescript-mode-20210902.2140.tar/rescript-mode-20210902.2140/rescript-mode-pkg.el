(define-package "rescript-mode" "20210902.2140" "A major mode for editing ReScript"
  '((emacs "26.1"))
  :commit "350d717f5c2564817179c4b6b1c615b10fd062e8" :authors
  '(("Karl Landstrom" . "karl.landstrom@brgeight.se")
    ("Daniel Colascione" . "dancol@dancol.org")
    ("John Lee" . "jjl@pobox.com"))
  :maintainer
  '("John Lee" . "jjl@pobox.com")
  :keywords
  '("languages" "rescript")
  :url "https://github.com/jjlee/rescript-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
