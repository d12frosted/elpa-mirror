;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-orgcard" "20220721.756"
  "Browse the orgcard by helm."
  '((helm-core "3.6.0"))
  :url "https://github.com/emacs-jp/helm-orgcard"
  :commit "d58d35627bb1714bb2cb095f696706b6881233ed"
  :revdesc "d58d35627bb1"
  :keywords '("convenience" "helm" "org")
  :authors '(("Yuhei Maeda" . "yuhei.maeda_at_gmail.com")))
