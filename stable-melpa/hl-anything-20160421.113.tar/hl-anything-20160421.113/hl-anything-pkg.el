(define-package "hl-anything" "20160421.113" "Highlight symbols, selections, enclosing parens and more."
  '((emacs "24.3"))
  :commit "de631c87d3a6602cdbf84c1623558334fda354fa" :authors
  '(("boyw165"))
  :maintainer
  '("boyw165"))
;; Local Variables:
;; no-byte-compile: t
;; End:
