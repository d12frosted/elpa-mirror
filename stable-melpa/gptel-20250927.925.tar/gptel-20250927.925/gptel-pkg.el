;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250927.925"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "7c443eeb4e5929bdb0b6420f13f4a504363c602b"
  :revdesc "7c443eeb4e59"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
