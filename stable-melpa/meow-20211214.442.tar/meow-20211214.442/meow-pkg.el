(define-package "meow" "20211214.442" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "c319f6bb484a02b0b004fa22a2c6ae92968bb594" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
