;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251127.2113"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "956ce7f34bd3d88f446254461cb9c52cf7df071f"
  :revdesc "956ce7f34bd3"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
