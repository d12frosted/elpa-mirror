(define-package "modus-themes" "20230120.926" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "9e1b5dfce352ea0654c91428ed2ecc7c2cc6645d" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
