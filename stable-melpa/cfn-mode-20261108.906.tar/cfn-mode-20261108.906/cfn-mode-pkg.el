;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20261108.906"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "7d9e2c34ccfb4495d6b3a36138d02031529a5823"
  :revdesc "7d9e2c34ccfb"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
