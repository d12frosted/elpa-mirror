(define-package "eldev" "20210410.1721" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "635744890ba2d55d9569a66cb72b13870418a513" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
