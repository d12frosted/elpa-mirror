(define-package "tmsu" "20230304.59" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "3baca29f5d8a60abac52cdd1ce2966c5cdebfbd8" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
