;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "20260105.21"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "f7c4f64ff8abc252d37a15e9653d80add6305a7e"
  :revdesc "f7c4f64ff8ab"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
