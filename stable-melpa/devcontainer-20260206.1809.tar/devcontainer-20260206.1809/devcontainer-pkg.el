;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20260206.1809"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "8e77740f17d21f70f56e8031b8dc9ddabdc3f4f6"
  :revdesc "8e77740f17d2"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
