(define-package "verb" "20220214.943" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "67dd7aa58530d237f60e0090bfdcd96da94fe3e8" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
