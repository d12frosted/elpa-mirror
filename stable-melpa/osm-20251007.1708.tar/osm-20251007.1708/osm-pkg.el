;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251007.1708"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "c2928b6362580ad2c1cec7c3951c4df467165edb"
  :revdesc "c2928b636258"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
