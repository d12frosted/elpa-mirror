(define-package "modus-themes" "20220401.933" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "f9b2c8b677d343dc2d8da7a1154033f5c304c73a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
