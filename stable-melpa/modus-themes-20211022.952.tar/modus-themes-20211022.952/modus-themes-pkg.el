(define-package "modus-themes" "20211022.952" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "7618d4c34bc02b93f75e09ea5ad1e6afdf393cb2" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
