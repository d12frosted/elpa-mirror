(define-package "parinfer-rust-mode" "20240318.159" "An interface for the parinfer-rust library"
  '((emacs "26.1"))
  :commit "0eb7febd4e652261d224652ff5313946f0c67be4" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
