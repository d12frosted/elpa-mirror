;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260411.126"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "3d97417424e3e6b69da340e4b10d4c5f61ebacf5"
  :revdesc "3d97417424e3"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
