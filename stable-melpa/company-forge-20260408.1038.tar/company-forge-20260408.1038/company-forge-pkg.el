;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-forge" "20260408.1038"
  "Company backend for mentions and topics from forge."
  '((emacs   "29.1")
    (company "1.0.0")
    (forge   "0.5.0")
    (ghub    "4.3.0"))
  :url "https://github.com/pkryger/company-forge.el"
  :commit "e8329706023daac8fa047623cf87979f5d4b9f12"
  :revdesc "e8329706023d"
  :keywords '("convenience" "completion" "company" "forge")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
