(define-package "cycle-at-point" "20220220.431" "Cycle (rotate) the thing under the cursor"
  '((emacs "27.1")
    (recomplete "0.2"))
  :commit "ea22b90f35f4cef73387047b3ef3fad83787d4e2" :authors
  '(("Campbell Barton"))
  :maintainer
  '("Campbell Barton")
  :keywords
  '("convenience")
  :url "https://gitlab.com/ideasman42/emacs-cycle-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
