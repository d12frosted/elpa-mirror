;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20251218.2148"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "710433ddf3073b97659eb9e71b85dcb37f2f6a10"
  :revdesc "710433ddf307"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
