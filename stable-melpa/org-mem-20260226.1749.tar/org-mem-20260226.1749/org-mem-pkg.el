;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260226.1749"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.1.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "a483da56b7d4a6a7b6f48a99e3295c8d27bdc677"
  :revdesc "a483da56b7d4"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
