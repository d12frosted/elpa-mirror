;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rasi-mode" "20250603.758"
  "Major mode for editing RASI configuration files."
  '((emacs "24.3"))
  :url "https://github.com/taquangtrung/emacs-rasi-mode"
  :commit "f6c8551cdc98cb893997f482b9d8d6b366fa39d8"
  :revdesc "f6c8551cdc98"
  :keywords '("languages"))
