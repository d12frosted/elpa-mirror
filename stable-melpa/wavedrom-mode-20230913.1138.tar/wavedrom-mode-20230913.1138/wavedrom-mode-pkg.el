(define-package "wavedrom-mode" "20230913.1138" "WaveDrom Integration"
  '((emacs "29.1"))
  :commit "da94e2943fb4507ad192c046d590fd292d626f8d" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("fpga" "asic" "tools")
  :url "https://github.com/gmlarumbe/wavedrom-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
