(define-package "dirvish" "20220601.722" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "460bf045cf69027eada323d8a96de6739bcc4bbf" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
