(define-package "python-mode" "20230620.908" "Python major mode" 'nil :commit "269f8004f538d5c1e51b86b91f23f53536fa215b" :authors
  '(("2015-2023 https://gitlab.com/groups/python-mode-devs")
    ("2003-2014 https://launchpad.net/python-mode")
    ("1995-2002 Barry A. Warsaw")
    ("1992-1994 Tim Peters"))
  :maintainer
  '(nil . "python-mode@python.org")
  :keywords
  '("python" "languages" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
