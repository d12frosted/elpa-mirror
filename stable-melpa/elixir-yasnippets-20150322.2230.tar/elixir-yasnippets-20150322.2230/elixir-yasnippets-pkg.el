(define-package "elixir-yasnippets" "20150322.2230" "Yasnippets for Elixir"
  '((yasnippet "0.8.0"))
  :commit "6b55c88ce483932f226b6bca0212b589d1d393ea" :authors
  '(("Yinghai Zhao" . "zyinghai@gmail.com"))
  :maintainer
  '("Yinghai Zhao" . "zyinghai@gmail.com")
  :keywords
  '("snippets"))
;; Local Variables:
;; no-byte-compile: t
;; End:
