;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260507.1734"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "a6ada629720af8e405561ef92c18a74e44c484ab"
  :revdesc "a6ada629720a"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
