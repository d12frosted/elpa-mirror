;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260203.2223"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8e07a1c2e0d9f1f31a4e0a4b9bedc8d8e9570923"
  :revdesc "8e07a1c2e0d9")
