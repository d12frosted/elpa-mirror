(define-package "dune" "20230213.1556" "Integration with the dune build system" 'nil :commit "b9c27038fbf0d69e173e5f045b688d00eb47796b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
