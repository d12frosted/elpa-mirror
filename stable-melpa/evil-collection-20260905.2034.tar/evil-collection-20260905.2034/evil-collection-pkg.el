;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260905.2034"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "783c96b9901417cb8b6df63ab606387fa72dc922"
  :revdesc "783c96b99014"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
