(define-package "dtk" "20230601.1417" "access SWORD content via diatheke"
  '((emacs "24.4")
    (cl-lib "0.6.1")
    (dash "2.12.0")
    (seq "1.9")
    (s "1.9"))
  :commit "c3214bcab4076ac7855a19b52a2925e279477e8d" :authors
  '(("David Thompson"))
  :maintainers
  '(("David Thompson"))
  :maintainer
  '("David Thompson")
  :keywords
  '("hypermedia")
  :url "https://github.com/dtk01/dtk.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
