(define-package "kiwix" "20220110.1542" "Searching offline Wikipedia through Kiwix."
  '((emacs "25.1")
    (request "0.3.0"))
  :commit "e20c67854bd56816b2d9b927f551799b80c1e198" :authors
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
