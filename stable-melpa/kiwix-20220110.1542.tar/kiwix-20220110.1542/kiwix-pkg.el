(define-package "kiwix" "20220110.1542" "Searching offline Wikipedia through Kiwix."
  '((emacs "25.1")
    (request "0.3.0"))
  :commit "1645c5b659a74c7fe3cae364b967edd45f64d61c" :authors
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
