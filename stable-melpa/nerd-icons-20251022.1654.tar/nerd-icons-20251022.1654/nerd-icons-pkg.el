;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20251022.1654"
  "Emacs Nerd Font Icons Library."
  '((emacs "24.3"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "4c033505f103c1f302a51fccab0c44fcffce38d6"
  :revdesc "4c033505f103"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
