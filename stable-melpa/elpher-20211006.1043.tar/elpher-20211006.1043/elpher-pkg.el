(define-package "elpher" "20211006.1043" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "7ac8997eb71a5f5b914bdd4a99317588ba076727" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
