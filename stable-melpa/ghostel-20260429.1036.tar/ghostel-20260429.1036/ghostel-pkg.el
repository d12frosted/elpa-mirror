;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260429.1036"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "a8bf9ae27424b163989bdc750e62bdae7261677c"
  :revdesc "a8bf9ae27424"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
