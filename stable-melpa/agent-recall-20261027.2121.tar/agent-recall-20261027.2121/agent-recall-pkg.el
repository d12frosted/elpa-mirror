;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20261027.2121"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "4dd831650d326d16ee036a0d251dc9546e9a0dda"
  :revdesc "4dd831650d32"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
