;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260426.2132"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "405bbc48d8a8bfdfb01093b40f83b86e8356e2b2"
  :revdesc "405bbc48d8a8"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
