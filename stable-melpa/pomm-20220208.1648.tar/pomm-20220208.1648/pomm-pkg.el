(define-package "pomm" "20220208.1648" "Yet another Pomodoro timer implementation"
  '((emacs "27.1")
    (alert "1.2")
    (seq "2.22")
    (transient "0.3.0"))
  :commit "6dc3b5f913908bca8db85e4b2161a1de76c60a58" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/pomm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
