(define-package "wildcharm-theme" "20231010.2239" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "6f5ce687e68fafdecaf557c48abf793c7f2b3c4b" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
