(define-package "racket-mode" "20220517.2322" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "c6f18e6883c4f48eee2d0d4f5bd7604a2de31753" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
