(define-package "flycheck-grammalecte" "20221212.1508" "Integrate Grammalecte with Flycheck"
  '((emacs "26.1")
    (flycheck "26"))
  :commit "a6d31030197c7ee92de97314ac3ab37c75aab363" :authors
  '(("Guilhem Doulcier" . "guilhem.doulcier@espci.fr")
    ("Étienne Deparis" . "etienne@depar.is"))
  :maintainer
  '("Étienne Deparis" . "etienne@depar.is")
  :keywords
  '("i18n" "text")
  :url "https://git.umaneti.net/flycheck-grammalecte/")
;; Local Variables:
;; no-byte-compile: t
;; End:
