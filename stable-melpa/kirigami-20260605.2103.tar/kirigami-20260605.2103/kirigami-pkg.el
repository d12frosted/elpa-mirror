;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260605.2103"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "e129fd9528487253d7bcc1aa13d583f62a47ccd6"
  :revdesc "e129fd952848"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
