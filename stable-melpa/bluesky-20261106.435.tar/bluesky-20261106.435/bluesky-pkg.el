;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bluesky" "20261106.435"
  "A Bluesky client."
  '((emacs "30.1")
    (plz   "0.9.0")
    (futur "1.7")
    (vui   "1.0.0"))
  :url "https://github.com/ahyatt/emacs-bluesky"
  :commit "455875a4dac957eb10b831f1d965ea63c19cafe1"
  :revdesc "455875a4dac9"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
