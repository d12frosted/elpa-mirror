;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20241102.1204"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "27.1")
    (epkg  "4.0.1")
    (magit "4.1.0"))
  :url "https://github.com/emacscollective/borg"
  :commit "cd4bb2b4b670f671611c72227869197c918b8ea7"
  :revdesc "cd4bb2b4b670"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
