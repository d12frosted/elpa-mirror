;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251224.940"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "bf7e02e4492c4bc5cd31bd80e0cd26767c86d370"
  :revdesc "bf7e02e4492c"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
