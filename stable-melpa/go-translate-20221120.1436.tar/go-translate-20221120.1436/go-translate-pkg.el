(define-package "go-translate" "20221120.1436" "Translation framework supports multiple engines such as Google/Bing/DeepL"
  '((emacs "27.1"))
  :commit "923d117ab399a0598a496d3fab84188c6f460dae" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
