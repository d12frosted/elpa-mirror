(define-package "fanyi" "20211030.1408" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "2e37cc1d19f0f6f710932610639e4fd206884770" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
