(define-package "aproject" "20220410.541" "Basic project framework for Emacs" 'nil :commit "13e176ee69851403bec6471c5cceed17b7912b6f" :authors
  '(("Vietor Liu" . "vietor.liu@gmail.com"))
  :maintainer
  '("Vietor Liu" . "vietor.liu@gmail.com")
  :keywords
  '("environment" "project")
  :url "https://github.com/vietor/aproject")
;; Local Variables:
;; no-byte-compile: t
;; End:
