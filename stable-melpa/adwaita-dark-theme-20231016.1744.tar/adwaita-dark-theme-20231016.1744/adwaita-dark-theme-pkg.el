(define-package "adwaita-dark-theme" "20231016.1744" "A dark color scheme inspired by Adwaita"
  '((emacs "27.1"))
  :commit "de32d1da1d04a43c413370eb94b0a338ce1cab27" :authors
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainers
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainer
  '("Jessie Hildebrandt <jessieh.net>")
  :keywords
  '("mode-line" "faces")
  :url "https://gitlab.com/jessieh/adwaita-dark-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
