;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260619.1128"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "5acb509de9fb690fdc661b9efb8a06f6554297a2"
  :revdesc "5acb509de9fb"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
