;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260216.1419"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "175ce3e0acc6c950c49b71bfd2da30d0ff47d32e"
  :revdesc "175ce3e0acc6"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
