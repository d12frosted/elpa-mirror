(define-package "consult" "20210929.1244" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "d230fdaae58d613c9ab2fd26af08669f51cb2e62" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
