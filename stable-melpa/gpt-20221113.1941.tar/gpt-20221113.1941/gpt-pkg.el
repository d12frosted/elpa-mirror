(define-package "gpt" "20221113.1941" "Run instruction-following language models"
  '((emacs "24.1"))
  :commit "1db27e69745b414b19407fdd7f01c55e66583e28" :authors
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainer
  '("Andreas Stuhlmueller" . "andreas@ought.org")
  :keywords
  '("gpt3" "language" "copilot" "convenience" "tools")
  :url "https://github.com/stuhlmueller/gpt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
