(define-package "live-py-mode" "20230408.1602" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "0b5531b33ed7d89c363e5a130002c6b48ba32bc5" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
