;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20240930.1338"
  "LSP mode."
  '((emacs         "27.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "b635d67284263d6e33f7170c522ac99ed6e629a0"
  :revdesc "b635d6728426"
  :keywords '("languages"))
