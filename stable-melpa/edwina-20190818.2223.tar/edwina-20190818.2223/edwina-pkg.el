(define-package "edwina" "20190818.2223" "Dynamic window manager"
  '((emacs "25"))
  :commit "cc0a039a400e8ef07b0d96d2169f1407e0af107a" :authors
  '(("Alex Griffin" . "a@ajgrf.com"))
  :maintainer
  '("Alex Griffin" . "a@ajgrf.com")
  :keywords
  '("convenience")
  :url "https://github.com/ajgrf/edwina")
;; Local Variables:
;; no-byte-compile: t
;; End:
