;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20251022.2118"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "fe91f0d4eed1cc4a6a4df4e69fd69cf98fc1ce65"
  :revdesc "fe91f0d4eed1"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
