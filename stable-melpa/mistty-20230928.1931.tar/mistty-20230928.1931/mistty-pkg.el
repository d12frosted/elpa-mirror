(define-package "mistty" "20230928.1931" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "b56eb35986b0d5cde97949d9344ed02190220b30" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
