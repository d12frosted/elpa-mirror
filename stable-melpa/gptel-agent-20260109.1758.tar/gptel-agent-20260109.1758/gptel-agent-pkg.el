;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260109.1758"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "a7a800af7d38e4d941d00cbeaa9aa3b2eb05ab70"
  :revdesc "a7a800af7d38"
  :keywords '("comm"))
