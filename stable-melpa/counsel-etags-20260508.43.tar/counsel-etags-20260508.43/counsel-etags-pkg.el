;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-etags" "20260508.43"
  "Fast and complete Ctags solution using ivy."
  '((emacs   "28.1")
    (counsel "0.15.1"))
  :url "https://github.com/redguardtoo/counsel-etags"
  :commit "c31228e1ffa5186c00aac871565be63c7fdae2b9"
  :revdesc "c31228e1ffa5"
  :keywords '("tools" "convenience"))
