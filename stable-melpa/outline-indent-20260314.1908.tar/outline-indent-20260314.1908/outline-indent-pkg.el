;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260314.1908"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "812bc835cb45785e1d0f3bc88157bc4af11f55a8"
  :revdesc "812bc835cb45"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
