;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250704.707"
  "Minor mode to format JS code on file save."
  '((emacs "28.1"))
  :url "https://github.com/prettier/prettier-emacs"
  :commit "79e045c6ae02bdd30e93d524f1980b965b865201"
  :revdesc "79e045c6ae02"
  :keywords '("convenience" "wp" "edit" "js"))
