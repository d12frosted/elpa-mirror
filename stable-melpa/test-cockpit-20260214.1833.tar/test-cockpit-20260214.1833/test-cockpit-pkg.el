;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "test-cockpit" "20260214.1833"
  "A command center to run tests of a software project."
  '((emacs      "28.1")
    (projectile "2.7")
    (toml       "0.2.0"))
  :url "https://github.com/johannes-mueller/test-cockpit.el"
  :commit "1a35f2cdc75310bbf8628dfb636466361126306c"
  :revdesc "1a35f2cdc753"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
