;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260211.1753"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b7fb018bc15b54c77202952014b9ea646a5bca59"
  :revdesc "b7fb018bc15b"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
