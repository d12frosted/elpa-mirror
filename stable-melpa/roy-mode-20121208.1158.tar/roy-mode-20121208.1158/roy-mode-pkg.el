;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "roy-mode" "20121208.1158"
  "Roy major mode."
  ()
  :url "https://github.com/folone/roy-mode"
  :commit "e1a4fb5ec0f46e82f569865ca47042ba5934e425"
  :revdesc "e1a4fb5ec0f4"
  :keywords '("extensions"))
