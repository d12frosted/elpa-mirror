(define-package "pacfiles-mode" "20200915.1815" "pacnew and pacsave merging tool"
  '((emacs "26")
    (cl-lib "0.5"))
  :commit "8d06f64abc98c3f3338560c8d6eb47719e034069" :authors
  '(("Carlos G. Cordero <http://github/UndeadKernel>"))
  :maintainers
  '(("Carlos G. Cordero" . "pacfiles@binarycharly.com"))
  :maintainer
  '("Carlos G. Cordero" . "pacfiles@binarycharly.com")
  :keywords
  '("files" "pacman" "arch" "pacnew" "pacsave" "update" "linux")
  :url "https://github.com/UndeadKernel/pacfiles-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
