;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260728.2214"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "28e0df606187d388fbd1e8869afb8b21fcefb9d7"
  :revdesc "28e0df606187"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
