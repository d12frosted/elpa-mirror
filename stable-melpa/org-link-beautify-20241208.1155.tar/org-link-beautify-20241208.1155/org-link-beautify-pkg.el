;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20241208.1155"
  "Beautify Org Links."
  '((emacs      "29.1")
    (org        "9.7.14")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "54faf01b8e70d870fea1257069920792a19ba0e5"
  :revdesc "54faf01b8e70"
  :keywords '("hypermedia"))
