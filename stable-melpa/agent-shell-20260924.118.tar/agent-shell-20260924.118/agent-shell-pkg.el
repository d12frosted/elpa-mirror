;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260924.118"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "f0854f6492c58979396833b979d50a81672e7bfc"
  :revdesc "f0854f6492c5")
