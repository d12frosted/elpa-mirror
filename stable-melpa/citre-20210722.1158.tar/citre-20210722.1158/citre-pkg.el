(define-package "citre" "20210722.1158" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "45e7f801744f471b43fdd96cfe734a4a3796bab6" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
