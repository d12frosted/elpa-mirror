;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260601.1038"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "2bd245a9aa31bc0e3b2197ce254582bde4e9b676"
  :revdesc "2bd245a9aa31")
