(define-package "autocrypt" "20210411.1759" "Autocrypt implementation"
  '((emacs "25.1")
    (cl-generic "0.3"))
  :commit "39c06eb4020c38de8f282340449691210cc23bb8" :authors
  '(("Philip K." . "philip@warpmail.net"))
  :maintainer
  '("Philip K." . "philip@warpmail.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~zge/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
