(define-package "verilog-ts-mode" "20230823.1142" "Verilog Tree-sitter major mode"
  '((emacs "28.2")
    (compat "29.1.4.0"))
  :commit "cded4120491282710943f66f8d7b7b1b7affdf78" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
