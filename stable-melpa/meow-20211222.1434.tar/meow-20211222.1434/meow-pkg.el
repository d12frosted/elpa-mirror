(define-package "meow" "20211222.1434" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "aa274c3a25200664f8cdad4f166a1d2433c59447" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
