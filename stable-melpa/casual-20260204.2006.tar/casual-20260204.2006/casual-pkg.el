;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260204.2006"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "838bba16c3029cdec777bb8e6224e349df8fbbe5"
  :revdesc "838bba16c302"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
