(define-package "eldev" "20230121.1404" "Elisp development tool"
  '((emacs "24.4"))
  :commit "a1ea1a3df7602ffab30c15348365d2e6a75063b7" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
