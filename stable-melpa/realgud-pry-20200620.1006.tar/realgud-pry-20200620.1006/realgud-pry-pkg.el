(define-package "realgud-pry" "20200620.1006" "Realgud front-end to the Ruby pry debugger"
  '((realgud "1.4.5")
    (load-relative "1.2")
    (cl-lib "0.5")
    (emacs "24"))
  :commit "500bef62369ef1ad876afd99db383c23196e1355" :authors
  '(("Rocky Bernstein"))
  :maintainer
  '("Rocky Bernstein")
  :url "http://github.com/rocky/realgud-pry")
;; Local Variables:
;; no-byte-compile: t
;; End:
