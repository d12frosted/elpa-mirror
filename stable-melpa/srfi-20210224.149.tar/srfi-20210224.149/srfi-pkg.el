(define-package "srfi" "20210224.149" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "9fcacc8ced3db37f9c1907d13f42ebeae943f676" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
