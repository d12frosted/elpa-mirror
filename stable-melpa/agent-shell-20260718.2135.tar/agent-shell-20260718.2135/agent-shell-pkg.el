;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260718.2135"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "25899550d3e65aad425efc43664e5888c8edaa6b"
  :revdesc "25899550d3e6")
