(define-package "vhdl-ts-mode" "20230912.1852" "VHDL Tree-sitter major mode"
  '((emacs "29.1"))
  :commit "703c08252632d0b6dad96d7bd0d1f605c67cce94" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
