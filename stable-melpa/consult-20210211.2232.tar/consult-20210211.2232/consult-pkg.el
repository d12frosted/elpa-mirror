(define-package "consult" "20210211.2232" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "1ccec4f600e703d88d4ec5fa107857139d425305" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
