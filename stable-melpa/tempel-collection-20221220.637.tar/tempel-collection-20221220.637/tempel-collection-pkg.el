(define-package "tempel-collection" "20221220.637" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "cd9529b2a2fdfd49010117d2a1fc49adf9725051" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
