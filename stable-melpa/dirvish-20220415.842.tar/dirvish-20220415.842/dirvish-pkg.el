(define-package "dirvish" "20220415.842" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "47d7f373b4782ab9e25c1ff1f3f450a2fd611388" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
