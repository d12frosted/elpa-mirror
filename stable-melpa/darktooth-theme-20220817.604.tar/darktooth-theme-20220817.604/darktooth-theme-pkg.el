(define-package "darktooth-theme" "20220817.604" "From the darkness... it watches"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "c344fc80647338e137cd78a4c30bfad41ab56736" :url "http://github.com/emacsfodder/emacs-theme-darktooth")
;; Local Variables:
;; no-byte-compile: t
;; End:
