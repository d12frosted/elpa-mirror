;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261104.1833"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "b5d6fc0e792a396afb0c6ee5280978773677371d"
  :revdesc "b5d6fc0e792a"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
