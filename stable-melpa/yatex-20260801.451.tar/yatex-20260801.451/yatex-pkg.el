;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yatex" "20260801.451"
  "Yet Another tex-mode for emacs //野鳥//."
  ()
  :commit "6a0fea36298fdfdd32e8346eaa252cc358ec807a"
  :revdesc "6a0fea36298f")
