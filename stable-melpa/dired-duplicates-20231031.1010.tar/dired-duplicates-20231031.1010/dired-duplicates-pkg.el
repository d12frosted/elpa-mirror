(define-package "dired-duplicates" "20231031.1010" "Find duplicate files locally and remotely"
  '((emacs "27.1"))
  :commit "c6193334fd677ebe6b962aca16d18c117fc1b62a" :authors
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainers
  '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainer
  '("Harald Judt" . "h.judt@gmx.at")
  :keywords
  '("files")
  :url "https://codeberg.org/hjudt/dired-duplicates")
;; Local Variables:
;; no-byte-compile: t
;; End:
