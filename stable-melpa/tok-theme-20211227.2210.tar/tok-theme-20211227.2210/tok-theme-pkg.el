(define-package "tok-theme" "20211227.2210" "My theme"
  '((emacs "24.3"))
  :commit "a776c68debd43e71d295ae4796b08c77e4e235a8" :authors
  '(("Topi Kettunen" . "mail@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "mail@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
