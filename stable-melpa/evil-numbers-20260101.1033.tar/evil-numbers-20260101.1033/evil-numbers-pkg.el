;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-numbers" "20260101.1033"
  "Increment/decrement numbers like in VIM."
  '((emacs "24.1")
    (evil  "1.2.0"))
  :url "http://github.com/juliapath/evil-numbers"
  :commit "7bc4c7dd4cbc9bc1e1fa2f79337bf31fa66e65d6"
  :revdesc "7bc4c7dd4cbc"
  :keywords '("convenience" "tools")
  :authors '(("Michael Markert" . "markert.michael@googlemail.com"))
  :maintainers '(("Julia Path" . "julia@jpath.de")))
