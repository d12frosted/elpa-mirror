(define-package "latex-labeler" "20231014.2110" "Simplify equation labeling in LaTeX"
  '((emacs "28.1"))
  :commit "d45dedbc74887c59f15c5a3dcd7546d2c29c30a4" :authors
  '(("X9hRRDys"))
  :maintainers
  '(("X9hRRDys"))
  :maintainer
  '("X9hRRDys")
  :keywords
  '("tools")
  :url "https://github.com/X9hRRDys/latex-labeler")
;; Local Variables:
;; no-byte-compile: t
;; End:
