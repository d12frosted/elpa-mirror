;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-matterircd" "20260625.2137"
  "Integrate matterircd with ERC."
  '((emacs "27.1"))
  :url "https://github.com/alexmurray/erc-matterircd"
  :commit "831a3db4e4064fe02249feeee8813929ad9c48ff"
  :revdesc "831a3db4e406"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
