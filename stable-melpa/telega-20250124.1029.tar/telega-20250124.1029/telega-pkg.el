;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250124.1029"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "8c1d51de57dfd105cace23a504fca390f6b7ad66"
  :revdesc "8c1d51de57df"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
