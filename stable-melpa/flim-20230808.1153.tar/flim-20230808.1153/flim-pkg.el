(define-package "flim" "20230808.1153" "A library to provide basic features about message representation or encoding."
  '((emacs "24.5")
    (apel "10.8")
    (oauth2 "0.11"))
  :commit "80b8121f05a5a0d7fcfe3e54085467a646dd2028")
;; Local Variables:
;; no-byte-compile: t
;; End:
