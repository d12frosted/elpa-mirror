;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260710.206"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "fc2d8b3edc697fab664979abb2a9336d8a8e21a0"
  :revdesc "fc2d8b3edc69"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
