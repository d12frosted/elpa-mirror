;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tesouro" "20221003.1303"
  "Brazilian Portuguese synonym search in dicio.com.br."
  '((request "0.3.2")
    (emacs   "24.4"))
  :url "https://github.com/rberaldo/tesouro.el"
  :commit "3dbfc49209237215163be1ea338dea099ddc0795"
  :revdesc "3dbfc4920923")
