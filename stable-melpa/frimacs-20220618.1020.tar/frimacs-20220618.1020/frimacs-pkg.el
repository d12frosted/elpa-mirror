(define-package "frimacs" "20220618.1020" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "5d8e7ad44de328d31cd642f2a0c92b4049114af4" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
