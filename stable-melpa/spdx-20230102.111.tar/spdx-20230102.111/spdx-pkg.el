(define-package "spdx" "20230102.111" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "fd637b38d118f57fb1037cfc6b5449beb462a81d" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
