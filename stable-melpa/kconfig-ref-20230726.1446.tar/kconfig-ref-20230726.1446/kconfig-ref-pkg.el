(define-package "kconfig-ref" "20230726.1446" "A simple package for looking up kconfig symbol quickly"
  '((emacs "24.4")
    (projectile "2.7.0"))
  :commit "7953808d1cf79a7794c4fe9826acf98063efc636" :authors
  '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers
  '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainer
  '("Jason Kim" . "sukbeom.kim@gmail.com")
  :keywords
  '("tools" "kconfig" "linux" "kernel")
  :url "https://github.com/seokbeomkim/kconfig-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
