;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-bulletproof" "20230615.640"
  "Automatic plain list bullet cycling."
  '((emacs "27.1"))
  :url "https://github.com/pondersson/org-bulletproof"
  :commit "8ae80a53f8034914f502a8655f420c55078e02e1"
  :revdesc "8ae80a53f803"
  :keywords '("outlines" "convenience")
  :authors '(("Pontus Andersson" . "pondersson@gmail.com"))
  :maintainers '(("Pontus Andersson" . "pondersson@gmail.com")))
