(define-package "kotlin-ts-mode" "20231018.1342" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "6c2568693cd80b1cf57c7950d9458bca5af371ce" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
