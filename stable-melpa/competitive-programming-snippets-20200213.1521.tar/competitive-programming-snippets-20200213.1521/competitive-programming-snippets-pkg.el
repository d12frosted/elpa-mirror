(define-package "competitive-programming-snippets" "20200213.1521" "Competitive Programming snippets for Yasnippet"
  '((emacs "26")
    (yasnippet "0.8.0"))
  :commit "b0245fcbabf035d89b80150add5d6a47859ab555" :authors
  '(("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainer
  '("Seong Yong-ju" . "sei40kr@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/sei40kr/competitive-programming-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
