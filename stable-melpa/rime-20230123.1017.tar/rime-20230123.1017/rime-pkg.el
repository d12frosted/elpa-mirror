(define-package "rime" "20230123.1017" "Rime input method"
  '((emacs "26.3")
    (dash "2.17.0")
    (cl-lib "0.6.1")
    (popup "0.5.3")
    (posframe "0.1.0"))
  :commit "0a50c918d2de56aa401a68ba37394446c6fc9ed6" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "input-method")
  :url "https://www.github.com/DogLooksGood/emacs-rime")
;; Local Variables:
;; no-byte-compile: t
;; End:
