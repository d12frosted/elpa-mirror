;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260810.130"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "d4aedaefc86eab8fd303dfdf1033f94758103887"
  :revdesc "d4aedaefc86e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
