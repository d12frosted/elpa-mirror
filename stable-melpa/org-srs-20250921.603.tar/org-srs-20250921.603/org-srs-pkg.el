;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20250921.603"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "d5b3acbae5bc1a94d5cc62fb60c0b5a4abc8b7da"
  :revdesc "d5b3acbae5bc"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
