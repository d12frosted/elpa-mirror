;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "seml-mode" "20261122.923"
  "Major-mode for SEML, S-Expression Markup Language, file."
  '((emacs          "27.1")
    (impatient-mode "1.1")
    (htmlize        "1.59")
    (web-mode       "17.3.20"))
  :url "https://github.com/conao3/seml-mode.el"
  :commit "eade9c60a87198863aa954f58da0d3090d2eabdc"
  :revdesc "eade9c60a871"
  :keywords '("lisp" "html")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
