;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250611.1758"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "3675b55815b365ba13ee70a2bd7f6097d9756915"
  :revdesc "3675b55815b3"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
