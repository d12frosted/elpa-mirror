;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hnreader" "20250702.446"
  "A hackernews reader."
  '((emacs   "25.1")
    (promise "1.1")
    (request "0.3.0")
    (org     "9.2"))
  :url "https://github.com/thanhvg/emacs-hnreader/"
  :commit "d3e3578b6af9b048a6cc8942c9ee283a44a45aee"
  :revdesc "d3e3578b6af9"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
