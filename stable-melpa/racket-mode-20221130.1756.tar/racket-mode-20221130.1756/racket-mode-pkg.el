(define-package "racket-mode" "20221130.1756" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "23059488748101dcfddec723da216826d62df075" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
