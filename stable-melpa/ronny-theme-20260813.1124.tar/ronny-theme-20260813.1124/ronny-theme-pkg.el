;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ronny-theme" "20260813.1124"
  "A dark colorscheme inspired by Monokai."
  '((emacs "27"))
  :url "https://github.com/judaew/ronny.el"
  :commit "3446ad504128dbf4a37d23109eafc9056e95602d"
  :revdesc "3446ad504128"
  :authors '(("Vadym-Valdis Yudaiev" . "judaew@outlook.com"))
  :maintainers '(("Vadym-Valdis Yudaiev" . "judaew@outlook.com")))
