;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "babel" "20210612.640"
  "Interface to web translation services such as Babelfish."
  ()
  :url "https://github.com/juergenhoetzel/babel"
  :commit "946e69c61188bc41793402ac48466d8967ddb43d"
  :revdesc "946e69c61188"
  :keywords '("translation" "web")
  :authors '(("Juergen Hoetzel" . "juergen@hoetzel.info")
             ("Eric Marsden" . "emarsden@laas.fr"))
  :maintainers '(("Juergen Hoetzel" . "juergen@hoetzel.info")
                 ("Eric Marsden" . "emarsden@laas.fr")))
