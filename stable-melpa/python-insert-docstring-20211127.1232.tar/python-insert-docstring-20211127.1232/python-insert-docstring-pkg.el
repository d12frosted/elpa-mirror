;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-insert-docstring" "20211127.1232"
  "Python Google docstring inserter."
  '((emacs "25.1"))
  :url "https://github.com/macurovc/insert-docstring"
  :commit "cd6419b74c99c06d5c48c1b289572acce1fd193b"
  :revdesc "cd6419b74c99"
  :authors '(("Marco Vocialta" . "macurovc@tutanota.com"))
  :maintainers '(("Marco Vocialta" . "macurovc@tutanota.com")))
