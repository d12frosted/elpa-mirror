(define-package "magik-mode" "20220204.1229" "mode for editing Magik + some utils." 'nil :commit "0168a410ea2e25c1e98c9be6381ba0872d1e1ae1" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
