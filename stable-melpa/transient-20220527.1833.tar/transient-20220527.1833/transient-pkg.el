(define-package "transient" "20220527.1833" "Transient commands"
  '((emacs "25.1")
    (compat "28.1.1.0"))
  :commit "a28a6c4ad4c7b9430fcbb29017a328190939c456" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("extensions")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
