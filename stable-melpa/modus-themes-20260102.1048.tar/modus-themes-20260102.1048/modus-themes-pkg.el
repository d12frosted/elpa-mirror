;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260102.1048"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "3247c5d0f7f745f51aaf814fa6abcb621b3e7b02"
  :revdesc "3247c5d0f7f7"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
