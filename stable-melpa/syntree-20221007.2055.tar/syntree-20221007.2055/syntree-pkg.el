(define-package "syntree" "20221007.2055" "Draw plain text constituency trees"
  '((emacs "27.1"))
  :commit "a9df2930dcc67f813c7892fb40aac020ed7627b9" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/syntree")
;; Local Variables:
;; no-byte-compile: t
;; End:
