(define-package "mode-line-debug" "20230511.2106" "Show status of debug-on-error in mode-line"
  '((emacs "25.1")
    (compat "29.1.4.1"))
  :commit "8e58bd51f1a8292c5df92e75a8c4a470e11a03e4" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("convenience" "lisp")
  :url "https://github.com/tarsius/mode-line-debug")
;; Local Variables:
;; no-byte-compile: t
;; End:
