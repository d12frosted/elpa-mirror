(define-package "modus-themes" "20220405.630" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "7f4cd627c224776d9682b508a9b058473fa51573" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
