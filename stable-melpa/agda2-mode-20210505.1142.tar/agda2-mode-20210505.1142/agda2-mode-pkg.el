(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "a4560307cb9e2ed30221294fabb870ff6f99f90a")
;; Local Variables:
;; no-byte-compile: t
;; End:
