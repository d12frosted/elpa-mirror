(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "465e46a20b59160ea38bd50a30beaab849d176c5")
;; Local Variables:
;; no-byte-compile: t
;; End:
