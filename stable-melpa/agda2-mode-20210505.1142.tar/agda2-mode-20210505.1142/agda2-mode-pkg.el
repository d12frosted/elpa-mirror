(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "cee43ea309a6d7f7900bd1a10667cb8068b32ddf")
;; Local Variables:
;; no-byte-compile: t
;; End:
