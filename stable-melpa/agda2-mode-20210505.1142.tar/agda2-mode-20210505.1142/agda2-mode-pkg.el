(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "989a13a3dc360f8355a1ea2ded9423b809b84ef6")
;; Local Variables:
;; no-byte-compile: t
;; End:
