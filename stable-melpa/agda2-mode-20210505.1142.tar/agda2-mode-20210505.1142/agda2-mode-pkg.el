(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "7b385b480c4bfc32d9468e4750648e35e1960be8")
;; Local Variables:
;; no-byte-compile: t
;; End:
