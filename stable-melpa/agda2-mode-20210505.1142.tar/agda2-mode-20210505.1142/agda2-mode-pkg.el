(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "bd74ccf7f64ce54fff6c2cc0e93e1351d9bdd8ce")
;; Local Variables:
;; no-byte-compile: t
;; End:
