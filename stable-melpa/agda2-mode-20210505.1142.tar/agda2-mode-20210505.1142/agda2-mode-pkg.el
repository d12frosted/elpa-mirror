(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "044843c5281a7bdb9479317793a75c8c0fcfadd9")
;; Local Variables:
;; no-byte-compile: t
;; End:
