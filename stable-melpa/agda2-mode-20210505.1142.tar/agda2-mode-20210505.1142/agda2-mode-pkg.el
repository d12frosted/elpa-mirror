(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "fcef64024edf81e79d5b34cf5ea156a5363e68be")
;; Local Variables:
;; no-byte-compile: t
;; End:
