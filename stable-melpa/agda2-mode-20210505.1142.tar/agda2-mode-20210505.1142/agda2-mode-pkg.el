(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "87ea144139326ba922f9c19ad96f52a57944f1fe")
;; Local Variables:
;; no-byte-compile: t
;; End:
