(define-package "agda2-mode" "20210505.1142" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "ecdeda1c1e3bb8d178efa4b365aa02399375495c")
;; Local Variables:
;; no-byte-compile: t
;; End:
