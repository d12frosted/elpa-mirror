;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260605.2030"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "fd22a525ff201200990eab39390dda87f5307b57"
  :revdesc "fd22a525ff20"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
