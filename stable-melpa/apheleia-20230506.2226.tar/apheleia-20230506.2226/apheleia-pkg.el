(define-package "apheleia" "20230506.2226" "Reformat buffer stably"
  '((emacs "26"))
  :commit "01f2f0da561e29b75c6b12933943a40850cf704c" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/raxod502/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
