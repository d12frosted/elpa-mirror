;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260517.1927"
  "Lets your agent talk to Emacs."
  '((emacs       "30.1")
    (http-server "0.1.0")
    (elisp-refs  "1.6"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "42216ee2403879104def73e018f67097bc36ac88"
  :revdesc "42216ee24038"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
