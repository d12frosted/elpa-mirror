(define-package "esup" "20200129.1533" "the Emacs StartUp Profiler (ESUP)"
  '((cl-lib "0.5")
    (emacs "25"))
  :commit "49e05d4f96adfbf71e608a78d23bbf148a8a7fc0" :authors
  '(("Joe Schafer" . "joe@jschaf.com"))
  :maintainer
  '("Serghei Iakovlev" . "egrep@protonmail.ch")
  :keywords
  '("convenience" "processes")
  :url "http://github.com/jschaf/esup")
;; Local Variables:
;; no-byte-compile: t
;; End:
