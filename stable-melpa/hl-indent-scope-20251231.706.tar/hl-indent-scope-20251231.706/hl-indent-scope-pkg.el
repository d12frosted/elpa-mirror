;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent-scope" "20251231.706"
  "Highlight indentation by scope."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope"
  :commit "38c8775dc575ecf6a35fa88946be3dfb5b489018"
  :revdesc "38c8775dc575"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
