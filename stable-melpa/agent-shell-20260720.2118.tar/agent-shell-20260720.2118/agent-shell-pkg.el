;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260720.2118"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6da58df2a3dc83260f22657c9663bb97dae9a025"
  :revdesc "6da58df2a3dc")
