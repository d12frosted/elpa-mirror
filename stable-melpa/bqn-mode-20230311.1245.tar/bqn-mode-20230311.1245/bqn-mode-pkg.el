(define-package "bqn-mode" "20230311.1245" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "8dd46215c4534a057758bd4ef15173d2820cefa7" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
