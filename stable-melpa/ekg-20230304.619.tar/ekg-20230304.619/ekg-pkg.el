(define-package "ekg" "20230304.619" "A system for recording and linking information"
  '((triples "0.2.5")
    (emacs "28.1"))
  :commit "f19f25279cab76d025f710ce3d373b92f9fad0ca" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
