(define-package "tsc" "20201116.1148" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "d6e98defcaf1d928bb9a1849f45e85d669925c26" :keywords
  ("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
   ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
