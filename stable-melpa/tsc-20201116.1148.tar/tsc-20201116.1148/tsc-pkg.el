(define-package "tsc" "20201116.1148" "Core Tree-sitter APIs"
  '((emacs "25.1"))
  :commit "887ad56d5c755d0007905d874e48eeedb2e8a383" :keywords
  ("languages" "tools" "parsers" "dynamic-modules" "tree-sitter")
  :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
   ("Jorge Javier Araya Navarro" . "jorgejavieran@yahoo.com.mx"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
