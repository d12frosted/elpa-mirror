;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260106.738"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "c9989805dbe7f7482905ad03562d955d847e97c8"
  :revdesc "c9989805dbe7"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
