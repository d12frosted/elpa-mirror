(define-package "ein" "20211104.2351" "Emacs IPython Notebook"
  '((emacs "25")
    (websocket "1.12")
    (anaphora "1.0.4")
    (request "0.3.3")
    (deferred "0.5")
    (polymode "0.2.2")
    (dash "2.13.0")
    (with-editor "0pre"))
  :commit "f6add0bf9dce3c30c2d2944798dfcd89a33b9d3f" :keywords
  '("jupyter" "literate programming" "reproducible research")
  :url "https://github.com/dickmao/emacs-ipython-notebook")
;; Local Variables:
;; no-byte-compile: t
;; End:
