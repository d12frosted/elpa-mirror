;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-denote" "20261011.232"
  "A denote integration for ekg."
  '((emacs  "28.1")
    (ekg    "0.7.0")
    (denote "4.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "39441026802cbf5c5ccd269b3c37cc953716e9c8"
  :revdesc "39441026802c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Jay Rajput" . "jayrajput@gmail.com"))
  :maintainers '(("Jay Rajput" . "jayrajput@gmail.com")))
