(define-package "verb" "20231110.1915" "Organize and send HTTP requests"
  '((emacs "26.3"))
  :commit "84b342fc94071b8f6002f7cef9cf236f2feea84b" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
