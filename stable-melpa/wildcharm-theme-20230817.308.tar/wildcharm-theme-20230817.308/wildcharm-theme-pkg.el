(define-package "wildcharm-theme" "20230817.308" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "803de0c7799350c1e10c471d305f09921217e8e9" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
