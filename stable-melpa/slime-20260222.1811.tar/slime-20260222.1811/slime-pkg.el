;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260222.1811"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "cd3e5eee57e444c62e4295163114e7743177b5d9"
  :revdesc "cd3e5eee57e4"
  :keywords '("languages" "lisp" "slime"))
