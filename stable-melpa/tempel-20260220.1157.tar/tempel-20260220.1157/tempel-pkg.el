;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260220.1157"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "7120539bf047d3748636a7299fd7bca62ab2c74a"
  :revdesc "7120539bf047"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
