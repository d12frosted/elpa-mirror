(define-package "tempel-collection" "20230103.2244" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "7ef22ea7aaf699632a1d02d47a9a505ae8bc52c3" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
