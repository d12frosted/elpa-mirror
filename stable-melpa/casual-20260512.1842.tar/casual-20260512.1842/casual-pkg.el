;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260512.1842"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "72fc24345934888528e823195d90cf0a60b948c9"
  :revdesc "72fc24345934"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
