;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260929.57"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "5953a052ac361c095de111681aa4bb4a1a1f2ce2"
  :revdesc "5953a052ac36"
  :keywords '("build tools" "languages"))
