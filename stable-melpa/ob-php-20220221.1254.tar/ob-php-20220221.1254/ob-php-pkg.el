;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-php" "20220221.1254"
  "Execute PHP within org-mode source blocks."
  '((org "8"))
  :url "https://repo.or.cz/ob-php.git"
  :commit "6ebf7799e9ded1d5114094f46785960a50000614"
  :revdesc "6ebf7799e9de"
  :keywords '("org" "babel" "php")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
