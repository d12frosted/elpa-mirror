;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-vterm" "20260813.1434"
  "A mode for Julia REPL using vterm."
  '((emacs "25.1")
    (vterm "0.0.1"))
  :url "https://github.com/shg/julia-vterm.el"
  :commit "3f50c6c4a983a33e1afc0c4cfc5f151358d880cd"
  :revdesc "3f50c6c4a983"
  :keywords '("languages" "julia"))
