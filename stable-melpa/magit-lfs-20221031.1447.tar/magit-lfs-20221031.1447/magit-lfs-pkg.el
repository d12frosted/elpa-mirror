;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-lfs" "20221031.1447"
  "Magit plugin for Git LFS."
  '((emacs "24.4")
    (magit "2.10.3")
    (dash  "2.13.0"))
  :url "https://github.com/ailrun/magit-lfs"
  :commit "cd9f46e1840270be27e2c2d9dcf036ff0781f66d"
  :revdesc "cd9f46e18402"
  :keywords '("magit" "git" "lfs" "tools" "vc")
  :authors '(("Junyoung/Clare Jang" . "jjc9310@gmail.com"))
  :maintainers '(("Junyoung/Clare Jang" . "jjc9310@gmail.com")))
