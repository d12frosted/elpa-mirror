(define-package "mandm-theme" "20220426.1131" "An M&M color theme." 'nil :commit "4991bbc4b17308f5dc53742dc528cbfdc467ee01" :authors
  '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainers
  '(("Christian Hopps" . "chopps@gmail.com"))
  :maintainer
  '("Christian Hopps" . "chopps@gmail.com")
  :url "https://github.com/choppsv1/emacs-mandm-theme.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
