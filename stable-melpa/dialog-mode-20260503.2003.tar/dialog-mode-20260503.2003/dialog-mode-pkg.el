;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260503.2003"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "3b93cb6424c325c52778e1a28e487fcff8fa0c83"
  :revdesc "3b93cb6424c3"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
