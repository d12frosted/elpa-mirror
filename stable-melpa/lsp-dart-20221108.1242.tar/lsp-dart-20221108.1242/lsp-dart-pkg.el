(define-package "lsp-dart" "20221108.1242" "Dart support lsp-mode"
  '((emacs "26.3")
    (lsp-treemacs "0.3")
    (lsp-mode "7.0.1")
    (dap-mode "0.6")
    (f "0.20.0")
    (dash "2.14.1")
    (dart-mode "1.0.5")
    (jsonrpc "1.0.15")
    (ht "2.2"))
  :commit "cc6c51b1e7887736c08260dbbcd28215c019a67a" :keywords
  '("languages" "extensions")
  :url "https://emacs-lsp.github.io/lsp-dart")
;; Local Variables:
;; no-byte-compile: t
;; End:
