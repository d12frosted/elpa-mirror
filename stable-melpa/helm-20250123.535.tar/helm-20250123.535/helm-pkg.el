;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250123.535"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "40eb2d9194f094714253b5e928dcaf31675bfbc5"
  :revdesc "40eb2d9194f0"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
