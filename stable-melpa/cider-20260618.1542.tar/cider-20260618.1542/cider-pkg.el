;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cider" "20260618.1542"
  "Clojure Interactive Development Environment that Rocks."
  '((emacs        "28")
    (clojure-mode "5.19")
    (compat       "30")
    (parseedn     "1.2.1")
    (queue        "0.2")
    (spinner      "1.7")
    (seq          "2.22")
    (sesman       "0.3.2")
    (transient    "0.4.1"))
  :url "https://www.github.com/clojure-emacs/cider"
  :commit "da0e416fc9ed71a0b09f4220f5987584a53ee314"
  :revdesc "da0e416fc9ed"
  :keywords '("languages" "clojure" "cider")
  :authors '(("Tim King" . "kingtim@gmail.com")
             ("Phil Hagelberg" . "technomancy@gmail.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev")
             ("Artur Malabarba" . "bruce.connor.am@gmail.com")
             ("Hugo Duncan" . "hugo@hugoduncan.org")
             ("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
