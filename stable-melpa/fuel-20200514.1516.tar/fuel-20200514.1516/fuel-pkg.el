(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "179e856273c5d12dc42fae50b8019503561ea31f")
;; Local Variables:
;; no-byte-compile: t
;; End:
