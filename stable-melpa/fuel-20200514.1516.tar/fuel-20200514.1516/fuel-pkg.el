(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "122de83c6fdf082f774377b2985f986dfed0356f")
;; Local Variables:
;; no-byte-compile: t
;; End:
