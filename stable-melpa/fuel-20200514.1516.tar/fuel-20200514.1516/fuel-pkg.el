(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1639b00a9e53839b317c94a6a70940c1dd488a7e")
;; Local Variables:
;; no-byte-compile: t
;; End:
