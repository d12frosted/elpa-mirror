(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f0fa95a2590c64b00b09b2a038955a46aebde5ed")
;; Local Variables:
;; no-byte-compile: t
;; End:
