(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "8f5f6939044b68a97d231b6902ab5ac86744db2a")
;; Local Variables:
;; no-byte-compile: t
;; End:
