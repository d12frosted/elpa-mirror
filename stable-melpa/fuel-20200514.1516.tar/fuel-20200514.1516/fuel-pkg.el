(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "71ac38692ace9b90c27f214943e8e77542459b12")
;; Local Variables:
;; no-byte-compile: t
;; End:
