(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "33b1f84a0886fd6d21464d81d34bf8192cb68072")
;; Local Variables:
;; no-byte-compile: t
;; End:
