(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ae77a6eff8d19ff116615795371f485ca839bea0")
;; Local Variables:
;; no-byte-compile: t
;; End:
