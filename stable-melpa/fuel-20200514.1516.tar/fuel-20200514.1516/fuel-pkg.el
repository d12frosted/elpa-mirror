(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4bcbaeac03deef338dc8bbf6b0c99854110f22df")
;; Local Variables:
;; no-byte-compile: t
;; End:
