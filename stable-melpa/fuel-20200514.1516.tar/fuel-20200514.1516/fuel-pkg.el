(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1488f29aa774326e5d6bf4f9c2823124606399b3")
;; Local Variables:
;; no-byte-compile: t
;; End:
