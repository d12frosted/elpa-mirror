(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "54dd0fd71a5727e60c43099cd1a9041c47b3edb0")
;; Local Variables:
;; no-byte-compile: t
;; End:
