(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ba0895aeb2554f03a3f757b4f958b8a2920d95cc")
;; Local Variables:
;; no-byte-compile: t
;; End:
