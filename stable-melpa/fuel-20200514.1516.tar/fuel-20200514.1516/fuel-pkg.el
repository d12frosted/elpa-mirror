(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4d2138709605059dec86d79f645a07c4c6fdb0c3")
;; Local Variables:
;; no-byte-compile: t
;; End:
