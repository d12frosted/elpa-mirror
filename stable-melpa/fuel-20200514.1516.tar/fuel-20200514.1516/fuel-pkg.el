(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f2230273044dee6c72811f1b22943ae514f46999")
;; Local Variables:
;; no-byte-compile: t
;; End:
