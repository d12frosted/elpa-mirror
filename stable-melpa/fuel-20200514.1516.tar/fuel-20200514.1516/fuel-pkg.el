(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ecd518eddcc2bb9cc8a84ba544ef7c596d303ab1")
;; Local Variables:
;; no-byte-compile: t
;; End:
