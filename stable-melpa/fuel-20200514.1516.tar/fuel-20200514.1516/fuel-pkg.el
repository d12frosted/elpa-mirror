(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "e80dd07ba38c35d1f1b7698e44094c26cf9bb9de")
;; Local Variables:
;; no-byte-compile: t
;; End:
