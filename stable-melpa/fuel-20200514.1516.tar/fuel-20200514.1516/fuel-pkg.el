(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "aeff3f35c8896e0e7f9c0005f9e65417ea488516")
;; Local Variables:
;; no-byte-compile: t
;; End:
