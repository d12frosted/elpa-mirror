(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "e7f5b1aecdb42e605bfcb227511d3cfba324228c")
;; Local Variables:
;; no-byte-compile: t
;; End:
