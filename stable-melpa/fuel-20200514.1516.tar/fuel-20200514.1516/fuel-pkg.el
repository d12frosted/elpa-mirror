(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "bd6055dfa6790c28382601527111cb90ec1e68b7")
;; Local Variables:
;; no-byte-compile: t
;; End:
