(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "28dcaf5008d9504caff392d112f7335756f384e1")
;; Local Variables:
;; no-byte-compile: t
;; End:
