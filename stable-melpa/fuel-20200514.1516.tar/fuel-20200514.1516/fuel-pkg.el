(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d78ae037780ee687b654ac0e8fc8f1b954493164")
;; Local Variables:
;; no-byte-compile: t
;; End:
