(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1928e6094ea644b24e511e5c21036729b017f98d")
;; Local Variables:
;; no-byte-compile: t
;; End:
