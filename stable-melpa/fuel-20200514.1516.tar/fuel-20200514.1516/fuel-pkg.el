(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3654ddbd8b3d54258edcc0f4e30ec482cfa8a255")
;; Local Variables:
;; no-byte-compile: t
;; End:
