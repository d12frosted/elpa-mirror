(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b27b5a27040d5f3e86fc855e2af044aad60b63a1")
;; Local Variables:
;; no-byte-compile: t
;; End:
