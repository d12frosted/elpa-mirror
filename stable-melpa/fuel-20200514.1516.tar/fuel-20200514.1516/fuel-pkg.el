(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "0fccda1feba0db87cdcb2b62753a97f2a1fa9d66")
;; Local Variables:
;; no-byte-compile: t
;; End:
