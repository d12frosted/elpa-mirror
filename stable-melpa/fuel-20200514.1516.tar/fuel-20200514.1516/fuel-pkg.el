(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ffa195f55426bfa92e1fde59ff3d385fd224a5c7")
;; Local Variables:
;; no-byte-compile: t
;; End:
