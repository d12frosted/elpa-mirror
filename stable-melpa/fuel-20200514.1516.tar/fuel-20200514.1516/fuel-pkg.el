(define-package "fuel" "20200514.1516" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ced28b7dae49a845420c16e9c1eef4905376b2d7")
;; Local Variables:
;; no-byte-compile: t
;; End:
