;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uncrustify-mode" "20130707.1359"
  "Minor mode to automatically uncrustify."
  ()
  :url "https://github.com/koko1000ban/emacs-uncrustify-mode"
  :commit "2c00d5cf2d1868a5955347438746f4dd82b3b9fc"
  :revdesc "2c00d5cf2d18"
  :keywords '("uncrustify")
  :authors '(("Tabito Ohtani" . "koko1000ban@gmail.com"))
  :maintainers '(("Tabito Ohtani" . "koko1000ban@gmail.com")))
