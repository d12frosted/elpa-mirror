(define-package "keycast" "20231105.1206" "Show current command and its binding"
  '((emacs "25.3")
    (compat "29.1.4.1"))
  :commit "6a6f9106270f65b0bae3afb2ccdc52a3b5fbe340" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("multimedia")
  :url "https://github.com/tarsius/keycast")
;; Local Variables:
;; no-byte-compile: t
;; End:
