;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sql-impala" "20250616.110"
  "Comint support for Cloudera Impala."
  ()
  :url "https://github.com/jterk/sql-impala"
  :commit "8968be95e493da3a3cc445e44a852186fa37df6b"
  :revdesc "8968be95e493"
  :keywords '("sql" "impala")
  :authors '(("Jason Terk" . "jason@goterkyourself.com"))
  :maintainers '(("Jason Terk" . "jason@goterkyourself.com")))
