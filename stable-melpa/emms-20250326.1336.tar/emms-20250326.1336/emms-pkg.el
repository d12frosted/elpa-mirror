;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "20250326.1336"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://www.gnu.org/software/emms/"
  :commit "b2ccd522cc362fb7070acb1fc9cd6a88dfc3c0f8"
  :revdesc "b2ccd522cc36"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
