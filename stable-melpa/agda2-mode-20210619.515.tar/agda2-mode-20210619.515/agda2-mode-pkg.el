(define-package "agda2-mode" "20210619.515" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "246a229faea2ef2fa53caf491ff8a2d72dd7510c")
;; Local Variables:
;; no-byte-compile: t
;; End:
