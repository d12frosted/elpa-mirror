;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-kanban" "20250312.2001"
  "Kanban dynamic block for org-mode."
  '((s    "0")
    (dash "2.17.0"))
  :url "http://github.com/gizmomogwai/org-kanban"
  :commit "c11283e6534d53fd66a9244f7aed592d39f2489a"
  :revdesc "c11283e6534d"
  :keywords '("org-mode" "org" "kanban" "tools")
  :authors '(("Christian Köstlin" . "christian.koestlin@gmail.com"))
  :maintainers '(("Christian Köstlin" . "christian.koestlin@gmail.com")))
