(define-package "nu-mode" "20190404.2032" "Modern Emacs Prompts Based Keybinding"
  '((undo-tree "0.6.5")
    (ace-window "0")
    (lv "0")
    (avy "0")
    (which-key "0")
    (transpose-frame "0"))
  :commit "d5fb4d26d1b0bb383ea2827cc5af5dfb2a269d2b")
;; Local Variables:
;; no-byte-compile: t
;; End:
