;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw-org" "20251023.2205"
  "Calendar view for org-agenda."
  '((emacs "28.1")
    (calfw "2.0"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "de895bc8071b26209c6f9b9a665004d9bc6456f8"
  :revdesc "de895bc8071b"
  :keywords '("calendar" "org")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
