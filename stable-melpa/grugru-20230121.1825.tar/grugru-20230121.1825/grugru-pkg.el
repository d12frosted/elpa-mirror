(define-package "grugru" "20230121.1825" "Rotate text at point"
  '((emacs "24.4"))
  :commit "088f26330be161cfad4835e155595ec60dcb335a" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
