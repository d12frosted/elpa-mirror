(define-package "pg" "20240305.1657" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "28.1"))
  :commit "bc996817035a0b96435c845553353392a59c0688" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
