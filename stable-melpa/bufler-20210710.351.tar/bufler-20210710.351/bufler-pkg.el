(define-package "bufler" "20210710.351" "Group buffers into workspaces with programmable rules"
  '((emacs "26.3")
    (dash "2.18")
    (f "0.17")
    (pretty-hydra "0.2.2")
    (magit-section "0.1"))
  :commit "a282aab23016b0b5563d2d96f66393edf93c8ee7" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/bufler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
