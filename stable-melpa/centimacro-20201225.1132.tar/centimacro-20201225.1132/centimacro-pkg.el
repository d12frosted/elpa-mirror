;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "centimacro" "20201225.1132"
  "Assign multiple macros as global key bindings."
  ()
  :url "https://github.com/abo-abo/centimacro"
  :commit "0149877584b333c4f1953f0767f0cae23881b0df"
  :revdesc "0149877584b3"
  :keywords '("macros")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
