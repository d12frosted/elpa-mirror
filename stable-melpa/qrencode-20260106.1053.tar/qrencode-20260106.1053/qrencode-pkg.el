;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "20260106.1053"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "caaa2646820014a1503bb03b70462ce6c68216e2"
  :revdesc "caaa26468200"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
