(define-package "mistty" "20231120.1653" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "e75ba0b05d0afac245f455e14ad52c840bb6b0c4" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
