(define-package "eglot-jl" "20230117.1243" "Julia support for eglot"
  '((emacs "25.1")
    (eglot "1.4")
    (project "0.8.1")
    (cl-generic "1.0"))
  :commit "2e04597223553a369dd5b6520b6365b41e6ea508" :authors
  '(("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz"))
  :maintainer
  '("Adam Beckmeyer" . "adam_git@thebeckmeyers.xyz")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/non-Jedi/eglot-jl")
;; Local Variables:
;; no-byte-compile: t
;; End:
