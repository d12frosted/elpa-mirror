(define-package "eide" "20230507.2000" "IDE interface" 'nil :commit "bdc7a13434cb23c68f08f4ac7449569a61e03fd5" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://software.hjuvi.fr.eu.org/eide/")
;; Local Variables:
;; no-byte-compile: t
;; End:
