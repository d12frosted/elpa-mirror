;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250406.2133"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "62e9eb4b249db853953aa1e8a4d3f27d1ac37beb"
  :revdesc "62e9eb4b249d"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
