;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ocaml-eglot" "20250115.1638"
  "An OCaml companion for Eglot."
  '((emacs "29.1"))
  :url "https://github.com/tarides/ocaml-eglot"
  :commit "51eb8cbc79da259d5d38d709c46fa4b9d16e3088"
  :revdesc "51eb8cbc79da"
  :keywords '("ocaml" "languages")
  :authors '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com"))
  :maintainers '(("Xavier Van de Woestyne" . "xaviervdw@gmail.com")))
