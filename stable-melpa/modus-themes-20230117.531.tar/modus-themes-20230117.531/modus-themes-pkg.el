(define-package "modus-themes" "20230117.531" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "7d643b30f450f9043288f952895e1282b7fcc734" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
