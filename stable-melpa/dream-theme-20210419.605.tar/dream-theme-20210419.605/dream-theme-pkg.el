;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dream-theme" "20210419.605"
  "Maximalist Nordic/Zenburn-inspired color theme."
  '((emacs "26.1"))
  :url "https://github.com/djcb/dream-theme"
  :commit "0c27f05544b90e41338f79ea923044b358a323c6"
  :revdesc "0c27f05544b9"
  :keywords '("faces" "theme")
  :authors '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl"))
  :maintainers '(("Dirk-Jan C. Binnema" . "djcb@djcbsoftware.nl")))
