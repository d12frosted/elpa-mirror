;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20260303.2008"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "e7b229450ac5383c4cde2639836cb0dc99220127"
  :revdesc "e7b229450ac5"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
