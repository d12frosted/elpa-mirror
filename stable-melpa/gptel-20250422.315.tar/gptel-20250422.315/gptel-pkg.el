;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250422.315"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "0c5a95d527b22380112356cda1719fc43de893bd"
  :revdesc "0c5a95d527b2"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
