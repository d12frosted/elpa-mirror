(define-package "magik-mode" "20220920.1237" "mode for editing Magik + some utils." 'nil :commit "2f86d2f456029c3ed9d8e5cd0ed2f3dd8cb3b862" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
