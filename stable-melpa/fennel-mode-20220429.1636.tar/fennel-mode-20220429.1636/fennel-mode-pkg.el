(define-package "fennel-mode" "20220429.1636" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "90498bd9c8dac2749baaddb605d35370aa79ba15" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
