;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20250331.339"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "fd1cad3435eb59165376cf6344372091b0d82cfd"
  :revdesc "fd1cad3435eb"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
