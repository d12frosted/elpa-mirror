;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250105.1737"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "31562f00579ea4b6b7cabd9825cd6c24aebad1cd"
  :revdesc "31562f00579e"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
