(define-package "modus-themes" "20210116.1942" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "8f3f1f9ea9e719f294d8f1308e8c333e469abc5b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
