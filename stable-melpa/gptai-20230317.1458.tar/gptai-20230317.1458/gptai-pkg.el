(define-package "gptai" "20230317.1458" "Integrate with the OpenAI API"
  '((emacs "24.1"))
  :commit "608e305dd264ff489642df45ead3d4ca4003cbea" :authors
  '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainer
  '("Anton Hibl" . "antonhibl11@gmail.com")
  :keywords
  '("comm" "convenience")
  :url "https://github.com/antonhibl/gptai")
;; Local Variables:
;; no-byte-compile: t
;; End:
