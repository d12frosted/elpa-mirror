;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compiler-explorer" "20251229.1015"
  "Compiler explorer client (godbolt.org)."
  '((emacs "28.1")
    (plz   "0.9")
    (eldoc "1.15.0")
    (map   "3.3.1")
    (seq   "2.23"))
  :url "https://github.com/mkcms/compiler-explorer.el"
  :commit "95daa680767bb44dea98a5ad6c2da2ebd5c6bfa3"
  :revdesc "95daa680767b"
  :keywords '("c" "tools")
  :authors '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers '(("Michał Krzywkowski" . "k.michal@zoho.com")))
