(define-package "modaled" "20230625.1448" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "fc520f46780736147ab015d825c7332a9dd1a855" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
