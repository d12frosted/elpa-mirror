(define-package "modus-themes" "20220409.1314" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "7cdf9302a3ea6ba739be08dbf66e8bd6cfad2833" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
