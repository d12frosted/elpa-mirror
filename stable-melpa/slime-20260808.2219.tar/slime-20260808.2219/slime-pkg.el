;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260808.2219"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "32740772e0b669679df835d38044493b9b090487"
  :revdesc "32740772e0b6"
  :keywords '("languages" "lisp" "slime"))
