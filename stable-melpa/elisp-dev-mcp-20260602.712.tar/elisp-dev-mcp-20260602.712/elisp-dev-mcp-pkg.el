;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-dev-mcp" "20260602.712"
  "MCP server for agentic Elisp development."
  '((emacs          "27.1")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/elisp-dev-mcp"
  :commit "b387face5faf3ec6d632da12eb17c5ac0bbd7178"
  :revdesc "b387face5faf"
  :keywords '("tools" "development"))
