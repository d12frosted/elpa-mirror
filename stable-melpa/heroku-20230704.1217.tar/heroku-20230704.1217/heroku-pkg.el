(define-package "heroku" "20230704.1217" "Like Magit but for Heroku CLI"
  '((emacs "27.2")
    (transient "0.3.7")
    (dash "2.19.1")
    (s "1.13.0")
    (ts "0.2.2"))
  :commit "22b2b8442de444011fb2306f6a50bbe898cd1fc3" :authors
  '(("Mykhaylo Bilyanskyy"))
  :maintainers
  '(("Mykhaylo Bilyanskyy"))
  :maintainer
  '("Mykhaylo Bilyanskyy")
  :keywords
  '("heroku" "devops" "convenience")
  :url "https://github.com./licht1stein/heroku.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
