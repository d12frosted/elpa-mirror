(define-package "treebundel" "20231125.1934" "Bundle related git-worktrees together"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "8a52d0174d1f03a18b73904bccf3f28c35de74c2" :authors
  '(("Ben Whitley"))
  :maintainers
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/treebundel")
;; Local Variables:
;; no-byte-compile: t
;; End:
