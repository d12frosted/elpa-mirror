(define-package "hass" "20230116.2220" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3")
    (websocket "1.13"))
  :commit "033d11b07e0f8bb68b348a12d5ae13fabea56c73" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
