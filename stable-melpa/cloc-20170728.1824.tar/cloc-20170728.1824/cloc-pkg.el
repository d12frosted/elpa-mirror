;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cloc" "20170728.1824"
  "Count lines of code over emacs buffers."
  '((cl-lib "0.5"))
  :url "https://github.com/cosmicexplorer/cloc-emacs"
  :commit "f30f0472e465cc8d433d2473e9d3b8dfe2c94491"
  :revdesc "f30f0472e465"
  :keywords '("cloc" "count" "source" "code" "lines")
  :authors '(("Danny McClanahan" . "danieldmcclanahan@gmail.com"))
  :maintainers '(("Danny McClanahan" . "danieldmcclanahan@gmail.com")))
