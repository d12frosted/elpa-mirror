(define-package "modus-themes" "20230107.1653" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "40138996b259f5d2f1f1cc5dd3595a202de9c19a" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
