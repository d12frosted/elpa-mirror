;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-auto-export-pandoc" "20241026.832"
  "Add org auto export with pandoc."
  '((ox-pandoc "2.0")
    (emacs     "24.1"))
  :url "https://github.com/Y0ngg4n/org-auto-export-pandoc.git"
  :commit "4c63da7ed3c6bae6fd512d2b886ed3c57c850219"
  :revdesc "4c63da7ed3c6"
  :keywords '("convenience")
  :authors '(("Yonggan" . "yonggan@obco.pro"))
  :maintainers '(("Yonggan" . "yonggan@obco.pro")))
