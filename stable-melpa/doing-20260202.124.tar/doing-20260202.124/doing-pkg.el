;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doing" "20260202.124"
  "Frictionless activity log and time tracking."
  '((emacs "27.1")
    (org   "9.0"))
  :url "https://github.com/xiaoxinghu/doing.el"
  :commit "9b0997dadc9e937bed6080956f4a55795f59c0b3"
  :revdesc "9b0997dadc9e"
  :keywords '("convenience" "org" "time-tracking")
  :authors '(("Xiaoxing Hu" . "hi@xiaoxing.dev"))
  :maintainers '(("Xiaoxing Hu" . "hi@xiaoxing.dev")))
