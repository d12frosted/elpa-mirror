(define-package "marcopolo" "20160421.1004" "Emacs client to the Docker HUB/Registry API"
  '((s "1.9.0")
    (dash "2.9.0")
    (pkg-info "0.5.0")
    (request "0.1.0"))
  :commit "9193aabdf12223087b5ed58f1507d5d8a24a4381" :authors
  '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainer
  '("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")
  :keywords
  '("docker")
  :url "https://github.com/nlamirault/marcopolo")
;; Local Variables:
;; no-byte-compile: t
;; End:
