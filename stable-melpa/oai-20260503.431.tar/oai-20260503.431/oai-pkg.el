;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260503.431"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "c042d702f07735b674cc867cd8c7829e92972263"
  :revdesc "c042d702f077"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
