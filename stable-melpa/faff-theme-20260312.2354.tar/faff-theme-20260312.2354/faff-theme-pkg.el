;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20260312.2354"
  "Light Emacs color theme on cornsilk3 background."
  ()
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "2b33d31857c73fd1d48a4814a83d885dd4c00569"
  :revdesc "2b33d31857c7"
  :keywords '("color" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
