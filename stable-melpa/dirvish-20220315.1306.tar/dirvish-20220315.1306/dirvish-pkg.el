(define-package "dirvish" "20220315.1306" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "f2a52d4412e5c30c0d146f3721d467e4dbad65a9" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
