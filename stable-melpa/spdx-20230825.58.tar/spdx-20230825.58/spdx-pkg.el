(define-package "spdx" "20230825.58" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "fc71cb8c0b6b5b159f9cf27f61a9ff0692be89fe" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
