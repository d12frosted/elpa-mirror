;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250621.1424"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.17.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "306338112b97f1a7dae5a8e415c561b84f8e013e"
  :revdesc "306338112b97"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
