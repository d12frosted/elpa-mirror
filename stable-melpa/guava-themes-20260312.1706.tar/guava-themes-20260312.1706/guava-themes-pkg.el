;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260312.1706"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "a1617fd3ad78c87d01b4c5f26a75e272f9ca60ed"
  :revdesc "a1617fd3ad78"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
