(define-package "evil-matchit" "20220524.1237" "Vim matchit ported to Evil"
  '((emacs "25.1"))
  :commit "ce93c5bcdbb049506c199dfc4324bf60f6fb4f2d" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
