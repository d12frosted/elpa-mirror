(define-package "evil-matchit" "20220524.1237" "Vim matchit ported to Evil"
  '((emacs "25.1"))
  :commit "094de831bdc76ff8bd7f61013bb93110fe894939" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
