;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "md-ts-mode" "20260929.1359"
  "Major mode for Markdown using tree-sitter."
  '((emacs "29.1"))
  :url "https://github.com/dnouri/md-ts-mode"
  :commit "b0a39248e614113711e4f197b6c39eb48604de0b"
  :revdesc "b0a39248e614"
  :keywords '("markdown" "languages" "tree-sitter")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
