;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "20260828.1749"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "7c9cbbfd1d43a4e575aa666f3eb7554e37ed049b"
  :revdesc "7c9cbbfd1d43"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
