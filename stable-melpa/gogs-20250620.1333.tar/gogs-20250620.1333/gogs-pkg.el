;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gogs" "20250620.1333"
  "Client library for the Gogs API."
  '((ghub "4"))
  :url "https://github.com/emacsattic/gogs"
  :commit "87f47b3b3d7a336c2a41fcf65b30fc48e497d53e"
  :revdesc "87f47b3b3d7a"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.ghub@jonas.bernoulli.dev")))
