;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "httpcode" "20121002.345"
  "Explains the meaning of an HTTP status code."
  ()
  :url "https://github.com/rspivak/httpcode.el"
  :commit "a45e735082b09477cd704a99294d336cdbeb12ba"
  :revdesc "a45e735082b0"
  :authors '(("Ruslan Spivak" . "ruslan.spivak@gmail.com"))
  :maintainers '(("Ruslan Spivak" . "ruslan.spivak@gmail.com")))
