;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conda-project" "20250408.507"
  "Work with conda-project environments."
  '((emacs     "28.1")
    (s         "1.13.0")
    (yaml      "0.1.1")
    (pythonic  "0.2.0")
    (transient "0.8.6"))
  :url "http://github.com/gilbertwong96/conda-project.el"
  :commit "5c47b586d7a83d33c34431560e2e976d11aad01e"
  :revdesc "5c47b586d7a8"
  :keywords '("python" "conda-project" "tools")
  :authors '(("Gilbert" . "gilbertwong96@icloud.com"))
  :maintainers '(("Gilbert" . "gilbertwong96@icloud.com")))
