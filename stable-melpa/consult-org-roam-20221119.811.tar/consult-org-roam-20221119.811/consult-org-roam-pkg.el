(define-package "consult-org-roam" "20221119.811" "Consult integration for org-roam"
  '((emacs "27.1")
    (org-roam "2.2.0")
    (consult "0.16"))
  :commit "4f5e77d36fb8256818df9042ee699954566d81d5" :authors
  '(("jgru <https://github.com/jgru>"))
  :maintainer
  '("jgru <https://github.com/jgru>")
  :url "https://github.com/jgru/consult-org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
