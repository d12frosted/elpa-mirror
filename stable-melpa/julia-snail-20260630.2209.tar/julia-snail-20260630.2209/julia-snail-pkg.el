;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-snail" "20260630.2209"
  "Julia Snail."
  '((emacs      "26.2")
    (dash       "2.16.0")
    (julia-mode "0.3")
    (s          "1.12.0")
    (spinner    "1.7.3")
    (popup      "0.5.9"))
  :url "https://github.com/gcv/julia-snail"
  :commit "dbdd95734ecdf39c514ede16bc4fa37cfc16268c"
  :revdesc "dbdd95734ecd")
