(define-package "electric-operator" "20220313.911" "Automatically add spaces around operators"
  '((dash "2.10.0")
    (emacs "24.4"))
  :commit "8bcc6b02722adb21d3698df46db2426718aebf70" :authors
  '(("David Shepherd" . "davidshepherd7@gmail.com"))
  :maintainer
  '("David Shepherd" . "davidshepherd7@gmail.com")
  :keywords
  '("electric")
  :url "https://github.com/davidshepherd7/electric-operator")
;; Local Variables:
;; no-byte-compile: t
;; End:
