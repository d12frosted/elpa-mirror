;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode-extra-font-locking" "20260218.1919"
  "Extra font-locking for Clojure mode."
  '((clojure-mode "3.0"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "f1cd680918d6e3c28247b54fb199e186ef9cfd9d"
  :revdesc "f1cd680918d6"
  :keywords '("languages" "lisp")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
