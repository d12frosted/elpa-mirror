;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20250707.616"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "cdbe67fdcccc13d410541aa527a73d4fcd754991"
  :revdesc "cdbe67fdcccc")
