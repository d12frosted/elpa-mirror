;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-phpstan" "20250331.1336"
  "Flymake backend for PHP using PHPStan."
  '((emacs   "26.1")
    (phpstan "0.7.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "7fb12964750f65d3c4b7e75cd7ffa7c72923e70c"
  :revdesc "7fb12964750f"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
