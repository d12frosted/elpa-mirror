(define-package "jabber" "20220712.1643" "A Jabber client for Emacs."
  '((fsm "0.2")
    (srv "0.2"))
  :commit "28353b2a0daaf6fef5b170745b52257816a52774" :authors
  '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainer
  '("wgreenhouse" . "wgreenhouse@tilde.club")
  :keywords
  '("comm")
  :url "https://codeberg.org/emacs-jabber/emacs-jabber")
;; Local Variables:
;; no-byte-compile: t
;; End:
