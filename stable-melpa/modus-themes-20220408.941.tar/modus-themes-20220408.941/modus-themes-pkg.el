(define-package "modus-themes" "20220408.941" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "a3a12c0afb843dc599a96d4fea410048979a41d7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
