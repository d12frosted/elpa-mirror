;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260530.503"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "d0d937067519054a401e952ae321a1241c229331"
  :revdesc "d0d937067519"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
