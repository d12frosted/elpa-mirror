(define-package "comb" "20180831.721" "Interactive grep tool for manual static analysis"
  '((emacs "25.1"))
  :commit "8a68d313bf429763eb8aa78ece00230a668f2a1f" :authors
  '(("Andrea Cardaci" . "cyrus.and@gmail.com"))
  :maintainer
  '("Andrea Cardaci" . "cyrus.and@gmail.com")
  :keywords
  '("matching")
  :url "https://github.com/cyrus-and/comb")
;; Local Variables:
;; no-byte-compile: t
;; End:
