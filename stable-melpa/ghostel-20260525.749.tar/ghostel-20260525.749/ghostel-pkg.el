;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260525.749"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "d92a367084935aac7fd5fff1a17914d87ddaad03"
  :revdesc "d92a36708493"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
