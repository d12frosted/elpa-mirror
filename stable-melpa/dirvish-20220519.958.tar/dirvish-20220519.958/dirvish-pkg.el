(define-package "dirvish" "20220519.958" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "1b077d80ed916d3a0514bdeb21d40313adf9405e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
