;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260728.1005"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "46376588cdc842318232a2d9e279f081cf66daec"
  :revdesc "46376588cdc8"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
