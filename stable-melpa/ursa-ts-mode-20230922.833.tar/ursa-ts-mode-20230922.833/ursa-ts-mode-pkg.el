(define-package "ursa-ts-mode" "20230922.833" "Major mode for Ursa, using tree-sitter"
  '((emacs "29.1"))
  :commit "e585fbeb4d885e0513db219db305d9ae0e21fb5b" :authors
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("ursalang" "languages" "tree-sitter")
  :url "https://github.com/ursalang/ursa-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
