(define-package "ada-ts-mode" "20240505.2037" "Major mode for Ada using Tree-sitter"
  '((emacs "29.1"))
  :commit "6b1a4667ccc7a9010b355ae619c9fe865e598d78" :authors
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainers
  '(("Troy Brown" . "brownts@troybrown.dev"))
  :maintainer
  '("Troy Brown" . "brownts@troybrown.dev")
  :keywords
  '("ada" "languages" "tree-sitter")
  :url "https://github.com/brownts/ada-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
