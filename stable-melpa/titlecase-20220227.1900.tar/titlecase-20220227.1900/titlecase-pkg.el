(define-package "titlecase" "20220227.1900" "Title-case phrases"
  '((emacs "25.1"))
  :commit "157b2943f4aa5745d64c77c1ac4b76ce6e60c47b" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://github.com/duckwork/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
