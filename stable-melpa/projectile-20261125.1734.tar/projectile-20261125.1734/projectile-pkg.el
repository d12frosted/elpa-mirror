;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20261125.1734"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "e26235eaae9cdd3885f198e8c50ede93eef76adc"
  :revdesc "e26235eaae9c"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
