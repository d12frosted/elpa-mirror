;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260118.1120"
  "Highlight by brightness of text and background."
  '((emacs "29.4"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "fb993d5a535809f46c9aad4c2d19829348531ed6"
  :revdesc "fb993d5a5358"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
