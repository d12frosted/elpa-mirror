(define-package "humanoid-themes" "20210525.2259" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "9b4587417f2583c503f84f3b1e994d7934e57bdd" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
