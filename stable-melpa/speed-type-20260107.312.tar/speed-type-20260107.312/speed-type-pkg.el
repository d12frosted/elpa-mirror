;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260107.312"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "aee618583e94b4ff6eaacd674e676d28a2c79ec3"
  :revdesc "aee618583e94"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
