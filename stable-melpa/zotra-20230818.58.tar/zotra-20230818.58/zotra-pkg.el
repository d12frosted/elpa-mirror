(define-package "zotra" "20230818.58" "Library to use Zotero translators"
  '((emacs "27.1"))
  :commit "4044c134f629d4da3fab5052bfa848b5f62db4c0" :authors
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainers
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainer
  '("Mohammad Pedramfar <https://github.com/mpedramfar>")
  :url "https://github.com/mpedramfar/zotra")
;; Local Variables:
;; no-byte-compile: t
;; End:
