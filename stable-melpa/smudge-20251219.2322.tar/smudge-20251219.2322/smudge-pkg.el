;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smudge" "20251219.2322"
  "Control the Spotify app."
  '((emacs        "27.1")
    (simple-httpd "1.5.1")
    (request      "0.3")
    (oauth2       "0.17"))
  :url "https://github.com/danielfm/smudge"
  :commit "b244c2ef7faa148779cf968800b5dd7645bcb797"
  :revdesc "b244c2ef7faa"
  :keywords '("multimedia" "music" "spotify" "smudge"))
