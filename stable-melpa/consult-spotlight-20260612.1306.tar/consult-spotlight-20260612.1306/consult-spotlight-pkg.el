;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-spotlight" "20260612.1306"
  "Consult interface to macOS mdfind (Spotlight)."
  '((emacs   "27.1")
    (consult "1.5"))
  :url "https://github.com/guibor/consult-spotlight"
  :commit "1cfbd52ab988de8476d28ec0c18f74d66c6918a4"
  :revdesc "1cfbd52ab988"
  :keywords '("matching" "files" "convenience")
  :authors '(("MDF" . "sguibor@gmail.com"))
  :maintainers '(("MDF" . "sguibor@gmail.com")))
