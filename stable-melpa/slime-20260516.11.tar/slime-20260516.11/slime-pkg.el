;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260516.11"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "2f1c18d6bddf397267e6873ea2c1997633ff4de9"
  :revdesc "2f1c18d6bddf"
  :keywords '("languages" "lisp" "slime"))
