;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-python-preset" "20260312.1711"
  "Eglot preset for Python."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-python-preset"
  :commit "7737777368d8aa6707c1e6b5e86b9806292eb1a4"
  :revdesc "7737777368d8"
  :keywords '("python" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
