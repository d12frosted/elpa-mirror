;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diffed" "20240618.2037"
  "Diffed is for recursive diff like Dired is for ls."
  '((emacs "27.1"))
  :url "https://github.com/ber-ro/diffed"
  :commit "93251169a4fc8c07fdd5f3d32c89b4d3401d37a1"
  :revdesc "93251169a4fc"
  :keywords '("tools")
  :authors '(("Bernhard Rotter" . "bernhard@b-rotter.de"))
  :maintainers '(("Bernhard Rotter" . "bernhard@b-rotter.de")))
