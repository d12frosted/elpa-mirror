(define-package "modus-themes" "20221228.2223" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "601a0498739c2b575cb72aac61fc36a233b043ab" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
