;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250109.243"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "ea041a499b26f677689d8df8588a65bd4938ebe0"
  :revdesc "ea041a499b26"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
