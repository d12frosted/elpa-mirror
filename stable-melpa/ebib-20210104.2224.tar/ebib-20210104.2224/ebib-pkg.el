(define-package "ebib" "20210104.2224" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "ff62296e8a66b035a2248b94ff53b81ac74042c9" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
