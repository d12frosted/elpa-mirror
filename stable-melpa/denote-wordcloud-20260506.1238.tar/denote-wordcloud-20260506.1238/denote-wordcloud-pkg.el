;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-wordcloud" "20260506.1238"
  "Generate a word cloud."
  '((emacs  "28.1")
    (denote "4.1.3"))
  :url "https://codeberg.org/treflip/denote-wordcloud"
  :commit "01a74f13bd1fa4f1645851cc64f2701ff2654e64"
  :revdesc "01a74f13bd1f"
  :keywords '("files")
  :authors '(("Alexander Kuzmin" . "treflcrew@gmail.org"))
  :maintainers '(("Alexander Kuzmin" . "treflcrew@gmail.org")))
