;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpactor" "20251226.855"
  "Interface to Phpactor."
  '((emacs       "27.1")
    (php-runtime "0.2")
    (composer    "0.2.0")
    (async       "1.9.3"))
  :url "https://github.com/emacs-php/phpactor.el"
  :commit "a4371b525afd5cd74c24461c50a489a1f459bd38"
  :revdesc "a4371b525afd"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me")
             ("Mikael Kermorgant" . "mikael@kgtech.fi"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")
                 ("Mikael Kermorgant" . "mikael@kgtech.fi")))
