(define-package "nordic-night-theme" "20230613.524" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "92092171486b0405dd0217b8ebaa17da9665da0e" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
