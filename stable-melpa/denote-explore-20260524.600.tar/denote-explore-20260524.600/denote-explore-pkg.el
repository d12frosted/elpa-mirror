;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "20260524.600"
  "Explore and visualise Denote files."
  '((emacs         "29.1")
    (denote        "4.0")
    (dash          "2.19.1")
    (denote-regexp "20250415.2202"))
  :url "https://github.com/pprevos/denote-explore/"
  :commit "e0265d41298a978e8a857d9aa5ec9ccc50136976"
  :revdesc "e0265d41298a"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
