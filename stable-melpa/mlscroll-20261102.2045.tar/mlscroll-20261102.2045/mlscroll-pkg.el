;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mlscroll" "20261102.2045"
  "A scroll bar for the modeline."
  '((emacs "27.1"))
  :url "https://github.com/jdtsmith/mlscroll"
  :commit "05244d3a5981bb273c0b488252e3f697a9dcb0e3"
  :revdesc "05244d3a5981"
  :keywords '("convenience"))
