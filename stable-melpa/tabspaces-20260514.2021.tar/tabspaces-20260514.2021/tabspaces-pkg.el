;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tabspaces" "20260514.2021"
  "Leverage tab-bar and project for buffer-isolated workspaces."
  '((emacs   "27.1")
    (project "0.8.1"))
  :url "https://github.com/mclear-tools/tabspaces"
  :commit "bb60b8285093a39d5f0c7f9983eb111c14c8f9ea"
  :revdesc "bb60b8285093"
  :keywords '("convenience" "frames")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
