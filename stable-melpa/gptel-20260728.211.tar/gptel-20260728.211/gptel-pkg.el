;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260728.211"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "513a6b74310d7bcc2a6138ccc1860b4577e73800"
  :revdesc "513a6b74310d"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
