;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vale-mode" "20190725.125"
  "Major mode for writing Vale vaf files."
  '((emacs "25"))
  :url "https://github.com/jaybosamiya/vale-mode.el"
  :commit "48bbc4b4ee5bf0b1b73e52705c0fbc112b255cd0"
  :revdesc "48bbc4b4ee5b"
  :keywords '("convenience" "languages")
  :authors '(("Jay Bosamiya" . "jaybosamiya@gmail.com"))
  :maintainers '(("Jay Bosamiya" . "jaybosamiya@gmail.com")))
