(define-package "mini-echo" "20231118.329" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "5c43d10138cb7911138a42d054dae0fc11bc7146" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
