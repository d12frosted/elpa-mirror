;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent-harness" "20260824.211"
  "Agent execution harness for gptel-agent."
  '((emacs       "29.1")
    (compat      "30.1.0.0")
    (gptel       "0.9.9")
    (gptel-agent "0.0.1"))
  :url "https://github.com/beacoder/gptel-agent-harness"
  :commit "3fae7abad86d977ec7db88eea1940baf95e71267"
  :revdesc "3fae7abad86d"
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
