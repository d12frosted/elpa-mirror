(define-package "modus-themes" "20230107.1439" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "542ee4ab5c040a3b97e71411e7579f585d3dc7e8" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
