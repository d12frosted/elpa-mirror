;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260915.751"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "37148afd595ab41625c73e6b6460028d9bc30db4"
  :revdesc "37148afd595a"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
