(define-package "llama" "20230603.1123" "Compact syntax for short lambda"
  '((seq "2.23"))
  :commit "34cadf22e3113a8fd51d2664a2f1538f8b40f679" :keywords
  '("extensions")
  :url "https://git.sr.ht/~tarsius/llama")
;; Local Variables:
;; no-byte-compile: t
;; End:
