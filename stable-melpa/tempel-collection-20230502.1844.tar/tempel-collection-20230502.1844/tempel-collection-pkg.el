(define-package "tempel-collection" "20230502.1844" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "08e453ead37771b46da5f9687f9ae0c00cae3159" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
