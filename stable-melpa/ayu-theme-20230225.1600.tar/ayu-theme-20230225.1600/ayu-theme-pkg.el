(define-package "ayu-theme" "20230225.1600" "Ayu theme"
  '((emacs "24.1"))
  :commit "16fc8d8085ca7763915fecd782ad11a596ca5773" :authors
  '(("Tran Anh Vu"))
  :maintainer
  '("Tran Anh Vu")
  :keywords
  '("lisp" "theme" "emacs")
  :url "https://github.com/vutran1710/Ayu-Theme-Emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
