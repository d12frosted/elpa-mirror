;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260215.208"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "71785e95378aecee8f44fb2e8468e44a277913a9"
  :revdesc "71785e95378a"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
