;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260326.1138"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "ad025758b72b478aced96736703e20fdf6d6d0aa"
  :revdesc "ad025758b72b"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
