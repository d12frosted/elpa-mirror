;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260308.930"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "581eacedb3c5112abae76bbcd494ca5ab8fa7607"
  :revdesc "581eacedb3c5"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
