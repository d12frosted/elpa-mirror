;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260515.815"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a57b87a6864bb7de9e3f68ec66079f8eb7b3bc65"
  :revdesc "a57b87a6864b")
