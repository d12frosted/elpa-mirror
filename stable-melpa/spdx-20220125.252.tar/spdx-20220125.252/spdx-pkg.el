(define-package "spdx" "20220125.252" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d7e0eb6dd1d05b5f521cff739ee4cdccf2fb9784" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
