;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed" "20260526.2305"
  "An Atom/RSS feed reader."
  '((emacs  "28.1")
    (compat "31"))
  :url "https://github.com/emacs-elfeed/elfeed"
  :commit "8a7b5c8c18aaee1b361d13cc9227acfe9d6b0259"
  :revdesc "8a7b5c8c18aa"
  :keywords '("network" "comm" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
