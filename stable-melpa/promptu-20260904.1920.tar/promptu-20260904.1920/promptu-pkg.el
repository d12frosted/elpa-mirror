;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "20260904.1920"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "3d1c6c70e84bfdb1633029f04354473f9d947929"
  :revdesc "3d1c6c70e84b"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
