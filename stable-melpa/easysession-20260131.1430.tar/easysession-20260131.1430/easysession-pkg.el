;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260131.1430"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "fce6d8b18327f71d72447943fba8e67d55403f3c"
  :revdesc "fce6d8b18327"
  :keywords '("convenience"))
