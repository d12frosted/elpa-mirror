(define-package "notmuch" "20210909.200" "run notmuch within emacs" 'nil :commit "7556bb7da27621895327b84d22abba2519c24ba7" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
