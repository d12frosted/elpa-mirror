(define-package "notmuch" "20210909.200" "run notmuch within emacs" 'nil :commit "dc8262bd336f1c406e5705ec8cb5029f1bacd524" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
