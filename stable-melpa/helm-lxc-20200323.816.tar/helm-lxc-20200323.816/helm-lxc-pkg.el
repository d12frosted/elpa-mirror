;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-lxc" "20200323.816"
  "Helm interface to manage LXC containers."
  '((emacs     "25")
    (cl-lib    "0.5")
    (helm      "2.9.4")
    (lxc-tramp "0.2.0"))
  :url "https://github.com/montag451/helm-lxc"
  :commit "37fe2d7ed97967edf59a3b68b1434910516ae24f"
  :revdesc "37fe2d7ed979"
  :keywords '("helm" "lxc" "convenience"))
