;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260601.542"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "7d51990ae589a4f24d32b7db153df463941f715e"
  :revdesc "7d51990ae589"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
