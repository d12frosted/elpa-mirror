(define-package "helm-core" "20240407.1400" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "440b7da9be9ad5c5b00458696f9a8b0a2a1b4cbe" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
