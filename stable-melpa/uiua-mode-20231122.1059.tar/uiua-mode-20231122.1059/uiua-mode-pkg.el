(define-package "uiua-mode" "20231122.1059" "Uiua integration"
  '((emacs "27.1")
    (reformatter "0.8"))
  :commit "e22f106ea4ebb0c1ea6449700baaa0b119cc4da7" :keywords
  '("languages" "uiua")
  :url "https://github.com/crmsnbleyd/uiua-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
