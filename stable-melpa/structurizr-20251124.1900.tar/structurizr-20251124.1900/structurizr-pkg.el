;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "structurizr" "20251124.1900"
  "Major mode for Structurizr DSL."
  '((emacs "29.1"))
  :url "https://github.com/papadakis-k/structurizr.el"
  :commit "8ecf03c0cd911d72cae049bb01cf9142d6be02d8"
  :revdesc "8ecf03c0cd91"
  :keywords '("languages"))
