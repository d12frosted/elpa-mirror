;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20260805.1021"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "ba455656de8cc2c3a5180bce8531e6c78541e757"
  :revdesc "ba455656de8c"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
