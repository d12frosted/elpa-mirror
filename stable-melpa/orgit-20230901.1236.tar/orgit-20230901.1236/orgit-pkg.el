(define-package "orgit" "20230901.1236" "Support for Org links to Magit buffers"
  '((emacs "25.1")
    (compat "29.1.4.1")
    (magit "3.3.0")
    (org "9.6.5"))
  :commit "1f2785f78be31d65aa036aa4b1c9a41c5fa48a4e" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("hypermedia" "vc")
  :url "https://github.com/magit/orgit")
;; Local Variables:
;; no-byte-compile: t
;; End:
