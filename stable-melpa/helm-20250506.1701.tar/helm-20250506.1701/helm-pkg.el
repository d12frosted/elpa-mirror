;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250506.1701"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.2")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "fde69a9a38072eb00d2ad57168ed9c8d7ac084d6"
  :revdesc "fde69a9a3807"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
