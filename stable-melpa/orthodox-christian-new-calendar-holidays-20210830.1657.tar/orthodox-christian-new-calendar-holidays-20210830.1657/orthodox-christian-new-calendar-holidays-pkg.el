;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orthodox-christian-new-calendar-holidays" "20210830.1657"
  "Feasts (NS)."
  ()
  :url "https://github.com/cmchittom/orthodox-christian-new-calendar-holidays"
  :commit "6869024ecd45eefd0ec648979c6a59d7c79770e0"
  :revdesc "6869024ecd45"
  :keywords '("calendar")
  :authors '(("Carson Chittom" . "carson@wistly.net"))
  :maintainers '(("Carson Chittom" . "carson@wistly.net")))
