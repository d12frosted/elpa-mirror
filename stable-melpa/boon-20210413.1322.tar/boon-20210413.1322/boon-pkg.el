(define-package "boon" "20210413.1322" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "a4f2d2caaf2d7a0adf36c19ea20a79dcfa129cad")
;; Local Variables:
;; no-byte-compile: t
;; End:
