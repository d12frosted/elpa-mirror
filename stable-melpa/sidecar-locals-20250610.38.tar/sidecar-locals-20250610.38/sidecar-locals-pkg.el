;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sidecar-locals" "20250610.38"
  "A flexible alternative to built-in dir-locals."
  '((emacs "27.1"))
  :url "https://codeberg.org/ideasman42/emacs-sidecar-locals"
  :commit "5f2b5fb8a16f0f9bb8803b219dc772eba7ac1981"
  :revdesc "5f2b5fb8a16f"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
