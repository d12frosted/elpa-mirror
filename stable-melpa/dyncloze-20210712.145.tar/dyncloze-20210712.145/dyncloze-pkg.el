(define-package "dyncloze" "20210712.145" "Language alternatives self-testing"
  '((emacs "25.1")
    (dash "2.18"))
  :commit "aafc5adc25c7f714b619109bccf92e475d6c84ef" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :url "https://github.com/ahyatt/emacs-dyncloze")
;; Local Variables:
;; no-byte-compile: t
;; End:
