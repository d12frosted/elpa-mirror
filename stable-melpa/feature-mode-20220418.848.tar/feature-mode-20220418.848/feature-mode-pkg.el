(define-package "feature-mode" "20220418.848" "Major mode for editing Gherkin (i.e. Cucumber) user stories" 'nil :commit "177d065db5984cbfaa66c375d13d5f1ccbb5f4a7" :authors
  '(("Michael Klishin"))
  :maintainer
  '("Michael Klishin")
  :url "https://github.com/michaelklishin/cucumber.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
