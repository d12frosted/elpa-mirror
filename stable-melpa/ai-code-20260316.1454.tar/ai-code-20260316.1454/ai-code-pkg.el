;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260316.1454"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "8a795aca219b3ae3fad99b38e4938eccc90664af"
  :revdesc "8a795aca219b"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
