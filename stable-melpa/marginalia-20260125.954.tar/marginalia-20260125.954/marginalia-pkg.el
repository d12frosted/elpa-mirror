;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marginalia" "20260125.954"
  "Enrich existing commands with completion annotations."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/marginalia"
  :commit "43cf0455f93fb3c7901e2d2609302326584f40a7"
  :revdesc "43cf0455f93f"
  :keywords '("docs" "help" "matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
