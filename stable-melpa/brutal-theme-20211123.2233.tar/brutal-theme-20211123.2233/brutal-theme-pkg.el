(define-package "brutal-theme" "20211123.2233" "Brutalist theme"
  '((emacs "24.1"))
  :commit "ab6af0ee7146289b3dcd12d2b70f400b94d7e0e7" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
