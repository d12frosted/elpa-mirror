(define-package "snakemake-mode" "20201109.315" "Major mode for editing Snakemake files"
  '((emacs "24.5")
    (cl-lib "0.5")
    (magit-popup "2.4.0"))
  :commit "0e4ef118ca3af4a6851fe670cf8fe7472ba18393" :authors
  '(("Kyle Meyer" . "kyle@kyleam.com"))
  :maintainer
  '("Kyle Meyer" . "kyle@kyleam.com")
  :keywords
  '("tools")
  :url "https://git.kyleam.com/snakemake-mode/about")
;; Local Variables:
;; no-byte-compile: t
;; End:
