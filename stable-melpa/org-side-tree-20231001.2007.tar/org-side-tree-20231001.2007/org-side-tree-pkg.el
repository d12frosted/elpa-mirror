(define-package "org-side-tree" "20231001.2007" "Navigate Org outlines in side window tree"
  '((emacs "28.1"))
  :commit "61207c68705b4f8d90b55cf49972f382d8603322" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/org-side-tree")
;; Local Variables:
;; no-byte-compile: t
;; End:
