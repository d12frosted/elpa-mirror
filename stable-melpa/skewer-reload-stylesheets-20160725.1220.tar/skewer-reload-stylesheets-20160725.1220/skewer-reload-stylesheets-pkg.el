(define-package "skewer-reload-stylesheets" "20160725.1220" "live-edit CSS, SCSS, Less, and friends."
  '((skewer-mode "1.5.3"))
  :commit "3207abca9551660407a6b009cb40fb32bbb550da" :authors
  '(("Nate Eagleson" . "nate@nateeag.com"))
  :maintainer
  '("Nate Eagleson" . "nate@nateeag.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
