(define-package "org-project-capture" "20230817.816" "Repository todo capture and management for org-mode"
  '((dash "2.10.0")
    (emacs "28")
    (s "1.9.0")
    (org-category-capture "1.0.0"))
  :commit "ad8daa991698df265a21b161e62a41e04979d98f" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "todo" "tools" "outlines" "project" "capture")
  :url "https://github.com/colonelpanic8/org-project-capture")
;; Local Variables:
;; no-byte-compile: t
;; End:
