(define-package "modus-themes" "20210222.1732" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "87564e35cfc4b96b63309ff49f436b5d1061930f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
