(define-package "lfe-mode" "20220102.1653" "Lisp Flavoured Erlang mode" 'nil :commit "6e1e42768d40528e7a13f7cebf0a56cffbeda3c6")
;; Local Variables:
;; no-byte-compile: t
;; End:
