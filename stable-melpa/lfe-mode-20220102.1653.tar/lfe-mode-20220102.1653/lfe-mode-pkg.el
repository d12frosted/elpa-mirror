(define-package "lfe-mode" "20220102.1653" "Lisp Flavoured Erlang mode" 'nil :commit "c196a9ba1f052f4fee68610a25ba43699ec432cb")
;; Local Variables:
;; no-byte-compile: t
;; End:
