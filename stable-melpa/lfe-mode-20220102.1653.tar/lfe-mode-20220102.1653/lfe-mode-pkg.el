(define-package "lfe-mode" "20220102.1653" "Lisp Flavoured Erlang mode" 'nil :commit "22b33ecbba56312e4218365064e8e91f676bdef9")
;; Local Variables:
;; no-byte-compile: t
;; End:
