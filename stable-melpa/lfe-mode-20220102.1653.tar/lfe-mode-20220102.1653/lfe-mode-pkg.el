(define-package "lfe-mode" "20220102.1653" "Lisp Flavoured Erlang mode" 'nil :commit "fc5ae30f6738dfd0664864698bfebb5423241ff8")
;; Local Variables:
;; no-byte-compile: t
;; End:
