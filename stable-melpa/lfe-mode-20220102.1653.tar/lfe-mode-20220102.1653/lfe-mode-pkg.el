(define-package "lfe-mode" "20220102.1653" "Lisp Flavoured Erlang mode" 'nil :commit "1db53e014de290ce70e6e3ee3443c94301d6df92")
;; Local Variables:
;; no-byte-compile: t
;; End:
