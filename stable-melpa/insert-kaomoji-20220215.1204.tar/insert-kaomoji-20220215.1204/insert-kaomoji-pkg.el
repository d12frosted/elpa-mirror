(define-package "insert-kaomoji" "20220215.1204" "Easily insert kaomojis"
  '((emacs "24.4"))
  :commit "974bb7dc02059253e032c501b2c3c0ece448d472" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")
  :keywords
  '("wp")
  :url "https://git.sr.ht/~pkal/insert-kaomoji")
;; Local Variables:
;; no-byte-compile: t
;; End:
