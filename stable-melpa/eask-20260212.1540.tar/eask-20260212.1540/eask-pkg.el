;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20260212.1540"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "2ee0d9a8e45de4a42be719fc21c6e9a4d8bbc653"
  :revdesc "2ee0d9a8e45d"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
