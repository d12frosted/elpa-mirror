(define-package "java-imports" "20220712.1653" "Code for dealing with Java imports"
  '((emacs "24.4")
    (s "1.10.0")
    (pcache "0.3.2"))
  :commit "bbb173c319a32b46680b5c0bffd72b607ed7b71a" :authors
  '(("Lee Hinman" . "lee@writequit.org"))
  :maintainers
  '(("Lee Hinman" . "lee@writequit.org"))
  :maintainer
  '("Lee Hinman" . "lee@writequit.org")
  :keywords
  '("java" "kotlin")
  :url "http://www.github.com/dakrone/emacs-java-imports")
;; Local Variables:
;; no-byte-compile: t
;; End:
