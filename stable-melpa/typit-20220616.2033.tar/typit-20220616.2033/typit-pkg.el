(define-package "typit" "20220616.2033" "Typing game similar to tests on 10 fast fingers"
  '((emacs "24.4")
    (f "0.18")
    (mmt "0.1.1"))
  :commit "eb67151f0693103bd7ef09a4a121c0f18b53c395" :authors
  '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainer
  '("Mark Karpov" . "markkarpov92@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/mrkkrp/typit")
;; Local Variables:
;; no-byte-compile: t
;; End:
