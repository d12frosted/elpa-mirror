(define-package "vc-msg" "20220526.1349" "Show commit information of current line"
  '((emacs "24.4")
    (popup "0.5.0"))
  :commit "230fef6ffd2c149c88caab2d1563c37c949b65e3" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("git" "vc" "svn" "hg" "messenger")
  :url "http://github.com/redguardtoo/vc-msg")
;; Local Variables:
;; no-byte-compile: t
;; End:
