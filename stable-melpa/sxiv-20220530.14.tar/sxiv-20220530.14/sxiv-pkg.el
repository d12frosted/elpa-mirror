;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sxiv" "20220530.14"
  "Run the Simple X Image Viewer, with Dired integration."
  '((dash  "2.16.0")
    (emacs "25.1"))
  :url "https://tildegit.org/contrapunctus/sxiv"
  :commit "47f5b2fbb94c569dc5e71cbe4de9c6eabbbc69e8"
  :revdesc "47f5b2fbb94c"
  :keywords '("multimedia")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr")))
