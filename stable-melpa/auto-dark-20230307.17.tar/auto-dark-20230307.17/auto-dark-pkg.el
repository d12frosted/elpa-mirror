(define-package "auto-dark" "20230307.17" "Automatically sets the dark-mode theme based on macOS/Linux/Windows status"
  '((emacs "24.4"))
  :commit "dcb5b4e6da8553c43b8ad7aff51de477980e23d8" :authors
  '(("Rahul M. Juliato")
    ("Tim Harper <timcharper at gmail dot com>")
    ("Vincent Zhang" . "seagle0128@gmail.com")
    ("Jonathan Arnett" . "jonathan.arnett@protonmail.com"))
  :maintainers
  '(("Rahul M. Juliato"))
  :maintainer
  '("Rahul M. Juliato")
  :keywords
  '("macos" "windows" "linux" "themes" "tools" "faces")
  :url "https://github.com/LionyxML/auto-dark-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
