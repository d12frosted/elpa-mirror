;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mlscroll" "20260703.1544"
  "A scroll bar for the modeline."
  '((emacs "27.1"))
  :url "https://github.com/jdtsmith/mlscroll"
  :commit "ff698fbbfc3b7c5775944bdff2da0acfb697d162"
  :revdesc "ff698fbbfc3b"
  :keywords '("convenience"))
