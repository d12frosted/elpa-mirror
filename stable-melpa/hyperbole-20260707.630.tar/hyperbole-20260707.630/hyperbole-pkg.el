;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260707.630"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "24985daca0b1c903ffc275f6d8af49f8acd13498"
  :revdesc "24985daca0b1"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
