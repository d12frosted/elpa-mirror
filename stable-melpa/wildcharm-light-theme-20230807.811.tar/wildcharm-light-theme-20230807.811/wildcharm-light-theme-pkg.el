(define-package "wildcharm-light-theme" "20230807.811" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "e811b9e38837e6659b9caa84e90d9bc08d6f6b62" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
