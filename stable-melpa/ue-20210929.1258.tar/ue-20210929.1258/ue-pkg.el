(define-package "ue" "20210929.1258" "Minor mode for Unreal Engine projects"
  '((emacs "26.1")
    (projectile "2.5.0"))
  :commit "f0726b5aa3268a00794ca3380c0f0e15d0b72674" :authors
  '(("Oleksandr Manenko" . "seidfzehsd@use.startmail.com"))
  :maintainer
  '("Oleksandr Manenko" . "seidfzehsd@use.startmail.com")
  :keywords
  '("unreal engine" "languages" "tools")
  :url "https://gitlab.com/unrealemacs/ue.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
