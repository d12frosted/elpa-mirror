;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20260221.2307"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "49de56f0de328ad9022e2784f52acd73170f7e75"
  :revdesc "49de56f0de32")
