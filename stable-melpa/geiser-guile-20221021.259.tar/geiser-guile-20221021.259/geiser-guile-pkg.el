(define-package "geiser-guile" "20221021.259" "Guile and Geiser talk to each other"
  '((emacs "25.1")
    (geiser "0.26.1"))
  :commit "d8fae2d194b1dde1a60f1f09e854a3a21047615f" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
