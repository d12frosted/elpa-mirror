;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260511.1712"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "fbb6fd854c79fc176747a10e3382fe5d40ae234e"
  :revdesc "fbb6fd854c79")
