;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20250404.1330"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://www.github.com/DogLooksGood/meow"
  :commit "78e4b876d06825cf55c5f039ea93f0d62ff6ec9c"
  :revdesc "78e4b876d068"
  :keywords '("convenience" "modal-editing"))
