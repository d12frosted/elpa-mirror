;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20260108.1320"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "a08e8774e757202dc1aa453892c88e961b8240d9"
  :revdesc "a08e8774e757"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
