;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20251222.2304"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "878539338e842e5769ba251c093dabe594c8230e"
  :revdesc "878539338e84"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
