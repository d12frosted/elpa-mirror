;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "biblio-gbooks" "20241025.1400"
  "Google Books backend for biblio.el."
  '((emacs       "24.4")
    (biblio-core "0.2")
    (let-alist   "1.0.6")
    (seq         "2.24")
    (compat      "29.1.4.2"))
  :url "https://github.com/jrasband/biblio-gbooks"
  :commit "c7bdaba4dde8fca8b8e923f3c004d050a32c06c2"
  :revdesc "c7bdaba4dde8"
  :keywords '("bib" "tex"))
