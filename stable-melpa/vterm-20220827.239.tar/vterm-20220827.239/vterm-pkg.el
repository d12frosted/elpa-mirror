(define-package "vterm" "20220827.239" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "0091bb026637cd6fa6035052d7449df204e53044" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
