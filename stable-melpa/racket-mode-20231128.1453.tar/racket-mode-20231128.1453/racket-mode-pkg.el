(define-package "racket-mode" "20231128.1453" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "cee96e20cd34e979dc9e3b7a92b5025a2ceb6358" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
