;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260729.304"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "553a3ec1ea8de142bc4ffd894c23d205a163cdb1"
  :revdesc "553a3ec1ea8d"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
