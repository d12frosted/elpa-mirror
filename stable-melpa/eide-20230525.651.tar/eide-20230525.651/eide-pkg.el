(define-package "eide" "20230525.651" "IDE interface" 'nil :commit "8cabc6d77b41bf0c9982ab56530c088d980bc353" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://software.hjuvi.fr.eu.org/eide/")
;; Local Variables:
;; no-byte-compile: t
;; End:
