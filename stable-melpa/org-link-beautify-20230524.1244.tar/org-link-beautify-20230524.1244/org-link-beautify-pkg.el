(define-package "org-link-beautify" "20230524.1244" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1"))
  :commit "003e0967d85f9589bc828cf044c149fd59b45d2e" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
