;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grails-mode" "20220407.1954"
  "Minor-mode that adds some Grails project management to a grails project."
  ()
  :url "http://blog.wolfman.com"
  :commit "29210e5a969c02169b68e04f2e28e3bf2fc13363"
  :revdesc "29210e5a969c"
  :keywords '("languages")
  :authors '(("Jim Morris" . "morris@wolfman.com"))
  :maintainers '(("Russel Winder" . "russel@winder.org.uk")))
