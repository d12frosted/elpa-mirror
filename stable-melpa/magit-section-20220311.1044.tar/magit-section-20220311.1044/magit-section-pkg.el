(define-package "magit-section" "20220311.1044" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "9d8d5e560394c001b866c00200ccea65b7d94a04" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
