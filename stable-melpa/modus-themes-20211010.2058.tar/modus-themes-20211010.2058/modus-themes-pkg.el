(define-package "modus-themes" "20211010.2058" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "fd606b75990a5f7facc74adf9246112577a70456" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
