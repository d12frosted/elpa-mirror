(define-package "brutalist-theme" "20230902.1" "Brutalist theme" 'nil :commit "19e4315ff0af129eab655febb948c4d5a6ad64a4" :authors
  '(("Gergely Nagy"))
  :maintainers
  '(("Gergely Nagy"))
  :maintainer
  '("Gergely Nagy")
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
