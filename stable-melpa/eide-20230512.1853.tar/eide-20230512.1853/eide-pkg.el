(define-package "eide" "20230512.1853" "IDE interface" 'nil :commit "3f54e6c070df11bd1f1a9d4af6534ba7b760249d" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://software.hjuvi.fr.eu.org/eide/")
;; Local Variables:
;; no-byte-compile: t
;; End:
