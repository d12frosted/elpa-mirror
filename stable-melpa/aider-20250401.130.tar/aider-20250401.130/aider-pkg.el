;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250401.130"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "07f93b284e06647471bc4908bf9f2e80587109fe"
  :revdesc "07f93b284e06"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
