(define-package "org-roam-bibtex" "20201220.1653" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "1.2.2")
    (bibtex-completion "2.0.0"))
  :commit "9ba15069c3f7ecd1080873cd3a7d587eb7c72d08" :keywords
  ("bib" "hypermedia" "outlines" "wp")
  :authors
  (("Leo Vivier" . "leo.vivier+dev@gmail.com")
   ("Mykhailo Shevchuk" . "mail@mshevchuk.com")
   ("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  ("Leo Vivier" . "leo.vivier+dev@gmail.com")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
