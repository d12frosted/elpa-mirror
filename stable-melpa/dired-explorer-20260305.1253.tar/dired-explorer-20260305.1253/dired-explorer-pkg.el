;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-explorer" "20260305.1253"
  "Minor-mode provides Explorer like select file at dired."
  '((cl-lib "0.5"))
  :url "https://github.com/jidaikobo-shibata/dired-explorer"
  :commit "aafe6364c64c74b4c569fa39d67e06ea53db66a4"
  :revdesc "aafe6364c64c"
  :keywords '("dired" "explorer"))
