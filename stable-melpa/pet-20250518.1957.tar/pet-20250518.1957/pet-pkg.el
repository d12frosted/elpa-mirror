;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pet" "20250518.1957"
  "Executable and virtualenv tracker for python-mode."
  '((emacs "26.1")
    (f     "0.6.0")
    (map   "3.3.1")
    (seq   "2.24"))
  :url "https://github.com/wyuenho/emacs-pet/"
  :commit "6750097e3eb8aa0cc0432117f56a3cf82d6895ad"
  :revdesc "6750097e3eb8"
  :keywords '("tools")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
