(define-package "brutal-theme" "20210127.1848" "Brutalist theme"
  '((emacs "24.1"))
  :commit "540689ce52509c3c959e85ace356ce3608162cba" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
