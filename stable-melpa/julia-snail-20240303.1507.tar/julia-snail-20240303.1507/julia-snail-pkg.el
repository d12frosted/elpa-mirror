(define-package "julia-snail" "20240303.1507" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (popup "0.5.9"))
  :commit "d316b6c874a6cacb37de91a81fcb7214ab173e62" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
