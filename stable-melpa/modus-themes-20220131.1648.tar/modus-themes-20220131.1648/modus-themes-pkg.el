(define-package "modus-themes" "20220131.1648" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "df0d0848eb37bf0f54585748a08b4229fd2b03eb" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
