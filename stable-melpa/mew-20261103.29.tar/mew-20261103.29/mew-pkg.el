;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261103.29"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "5a5cf466b8f5ca9f39f86ccddfe11a26011b850e"
  :revdesc "5a5cf466b8f5")
