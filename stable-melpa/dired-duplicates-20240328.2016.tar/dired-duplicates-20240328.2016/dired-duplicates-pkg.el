;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-duplicates" "20240328.2016"
  "Find duplicate files locally and remotely."
  '((emacs "27.1"))
  :url "https://codeberg.org/hjudt/dired-duplicates"
  :commit "5c5f24bea92159987f65f01ef32b261e905997bd"
  :revdesc "5c5f24bea921"
  :keywords '("files")
  :authors '(("Harald Judt" . "h.judt@gmx.at"))
  :maintainers '(("Harald Judt" . "h.judt@gmx.at")))
