(define-package "fuel" "20230103.1201" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a68a784a8070e252aa9ff547d997ee56fee5549a")
;; Local Variables:
;; no-byte-compile: t
;; End:
