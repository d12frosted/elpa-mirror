;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmd-to-echo" "20161203.2133"
  "Show the output of long-running commands in the echo area."
  '((emacs              "24.4")
    (s                  "1.11.0")
    (shell-split-string "20151224.208"))
  :url "https://github.com/mallt/cmd-to-echo"
  :commit "e0e874fc0e1ad6d291e39ed76023445297ad438a"
  :revdesc "e0e874fc0e1a"
  :authors '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com"))
  :maintainers '(("Tijs Mallaerts" . "tijs.mallaerts@gmail.com")))
