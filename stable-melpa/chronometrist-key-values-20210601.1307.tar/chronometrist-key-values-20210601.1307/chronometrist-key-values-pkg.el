(define-package "chronometrist-key-values" "20210601.1307" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "3c8be625ceefb5749921bc35de198ced22d1ae45" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
