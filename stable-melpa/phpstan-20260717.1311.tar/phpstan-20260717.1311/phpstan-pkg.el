;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpstan" "20260717.1311"
  "Interface to PHPStan (PHP static analyzer)."
  '((emacs       "25.1")
    (compat      "30")
    (php-mode    "1.22.3")
    (php-runtime "0.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "fec900ecbfb601c8eb9e01534ac1f4b29a759565"
  :revdesc "fec900ecbfb6"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
