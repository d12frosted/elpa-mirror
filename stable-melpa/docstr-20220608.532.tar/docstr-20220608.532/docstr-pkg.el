(define-package "docstr" "20220608.532" "A document string minor mode"
  '((emacs "27.1")
    (s "1.9.0"))
  :commit "0a48429c2d0c2aa1de34ea24d2d3f9c8176519de" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/emacs-vs/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
