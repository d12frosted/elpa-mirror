(define-package "modaled" "20230820.2113" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "afae3cb778fb3f2f65eb6f4f06e4cfcefb427a0c" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
