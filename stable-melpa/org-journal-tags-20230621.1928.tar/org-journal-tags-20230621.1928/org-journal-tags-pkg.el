(define-package "org-journal-tags" "20230621.1928" "Tagging and querying system for org-journal"
  '((emacs "27.1")
    (org-journal "2.1.2")
    (magit-section "3.3.0")
    (transient "0.3.7"))
  :commit "5f1f6fde83e92c9aff28205bab77233778f4346f" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainers
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/org-journal-tags")
;; Local Variables:
;; no-byte-compile: t
;; End:
