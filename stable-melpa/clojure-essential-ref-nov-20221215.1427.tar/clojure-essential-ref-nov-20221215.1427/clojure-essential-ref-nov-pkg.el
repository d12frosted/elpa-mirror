;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-essential-ref-nov" "20221215.1427"
  "Cider-doc to \"Clojure, The Essential Reference\" (EPUB)."
  '((emacs                 "24")
    (dash                  "2.16.0")
    (nov                   "0.3.1")
    (clojure-essential-ref "0.1.0"))
  :url "https://github.com/p3r7/clojure-essential-ref"
  :commit "6741bf65cf9b9bc896ab1cc3c384573e8ffe5f96"
  :revdesc "6741bf65cf9b")
