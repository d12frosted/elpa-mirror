(define-package "racket-mode" "20220619.1429" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "9d2303ce38f206bb745111103f2f964dec65f9cf" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
