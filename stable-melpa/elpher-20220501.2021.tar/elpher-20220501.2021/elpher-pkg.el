(define-package "elpher" "20220501.2021" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "61d565ce18392a8a92347cb3376f7cd8d1092fe5" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
