;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241117.2053"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "7ccfb435ff649346e0ec62d6fdad4568113f1731"
  :revdesc "7ccfb435ff64"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
