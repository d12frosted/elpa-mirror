;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kele" "20251110.1353"
  "Spritzy Kubernetes cluster management."
  '((emacs   "29.1")
    (async   "1.9.7")
    (dash    "2.19.1")
    (f       "0.20.0")
    (ht      "2.3")
    (memoize "0")
    (plz     "0.8.0")
    (s       "1.13.0")
    (yaml    "0.5.1"))
  :url "https://github.com/jinnovation/kele.el"
  :commit "b1178fddeb6590bbe8b058adcc5c82625e201174"
  :revdesc "b1178fddeb65"
  :keywords '("kubernetes" "tools")
  :authors '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers '(("Jonathan Jin" . "me@jonathanj.in")))
