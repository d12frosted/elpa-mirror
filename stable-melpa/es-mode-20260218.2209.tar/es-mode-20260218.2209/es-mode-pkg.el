;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "es-mode" "20260218.2209"
  "A major mode for editing and executing Elasticsearch queries."
  '((dash    "2.11.0")
    (cl-lib  "0.5")
    (spark   "1.0")
    (s       "1.11.0")
    (request "0.3.0"))
  :url "http://www.github.com/dakrone/es-mode"
  :commit "91e09835e3d7cfb0748edef94fa4bd53a32e63ae"
  :revdesc "91e09835e3d7"
  :keywords '("elasticsearch")
  :authors '(("Lee Hinman" . "lee@writequit.org"))
  :maintainers '(("Lee Hinman" . "lee@writequit.org")))
