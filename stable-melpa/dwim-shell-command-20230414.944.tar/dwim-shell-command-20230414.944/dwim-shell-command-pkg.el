(define-package "dwim-shell-command" "20230414.944" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "21c25fb2cf8c43b4496a47ac1b45c20b2f63c9f4" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
