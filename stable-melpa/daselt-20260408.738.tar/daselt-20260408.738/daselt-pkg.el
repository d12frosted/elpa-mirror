;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260408.738"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "c16b966e91a20472dda2f7d671c7b786eb5c1708"
  :revdesc "c16b966e91a2"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
