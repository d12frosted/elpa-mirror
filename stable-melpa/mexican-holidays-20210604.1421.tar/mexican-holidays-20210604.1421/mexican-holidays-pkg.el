;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mexican-holidays" "20210604.1421"
  "Mexico holidays for Emacs calendar."
  ()
  :url "https://github.com/sggutier/mexican-holidays"
  :commit "8e28907ea69f2c0ed9aad9f3b99664ca147379d0"
  :revdesc "8e28907ea69f"
  :keywords '("calendar")
  :authors '(("Saúl Gutiérrez" . "me@sggc.me"))
  :maintainers '(("Saúl Gutiérrez" . "me@sggc.me")))
