;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vim-tab-bar" "20260201.120"
  "Vim-like tab bar."
  '((emacs "28.1"))
  :url "https://github.com/jamescherti/vim-tab-bar.el"
  :commit "6fcfd37c8d6f0cce0c3ed9987988609299faf74b"
  :revdesc "6fcfd37c8d6f"
  :keywords '("frames"))
