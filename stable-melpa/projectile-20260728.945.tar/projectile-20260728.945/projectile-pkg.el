;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260728.945"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "727b62a0ffee5fe59dcac4ac701be4332f4e46ae"
  :revdesc "727b62a0ffee"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
