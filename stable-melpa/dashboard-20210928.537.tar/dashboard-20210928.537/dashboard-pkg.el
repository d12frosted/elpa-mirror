(define-package "dashboard" "20210928.537" "A startup screen extracted from Spacemacs"
  '((emacs "25.3"))
  :commit "8cfe3c66831f538d40d4024f3cf8d2058e71a648" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
