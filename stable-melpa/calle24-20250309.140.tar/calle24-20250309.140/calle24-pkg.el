;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calle24" "20250309.140"
  "Emacs Toolbar Support for SF Symbols."
  '((emacs "29.1"))
  :url "https://github.com/kickingvegas/calle24"
  :commit "c5152bc1f9ee305b371f6ea9553320c80df91688"
  :revdesc "c5152bc1f9ee"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
