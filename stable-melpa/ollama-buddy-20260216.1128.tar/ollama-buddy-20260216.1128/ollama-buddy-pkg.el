;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260216.1128"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "e6d8e101c01f1ed2fc1b3bf367e6ed4ce1875338"
  :revdesc "e6d8e101c01f"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
