(define-package "grugru" "20211119.815" "Rotate text at point"
  '((emacs "24.4"))
  :commit "ac92a8d54efe000557564a9b01a426f34cc01dfa" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
