(define-package "multitran" "20230919.706" "Interface to multitran"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "c1f604fa3ba02790654603897565ec15a3d8f428" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("dictionary" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
