;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260714.1645"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "102ac73a89f13b49b49542e84abfbd1baf3c2573"
  :revdesc "102ac73a89f1")
