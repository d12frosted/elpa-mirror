(define-package "dirvish" "20220319.854" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "94c122773057c5024df19ba12f01f7980a473e54" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
