(define-package "embark" "20220916.1357" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "a50b86c87f7f1b15c959ba8f2fff5a0eb79ecd1d" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
