;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250312.31"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "254dc73d85f0d8973e0220d1c4b4a81fa4cde874"
  :revdesc "254dc73d85f0"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
