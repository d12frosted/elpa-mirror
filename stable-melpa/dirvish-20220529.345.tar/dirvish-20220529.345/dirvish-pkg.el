(define-package "dirvish" "20220529.345" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "594f035fb40663cc9363366f413e3bb078a7c888" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
