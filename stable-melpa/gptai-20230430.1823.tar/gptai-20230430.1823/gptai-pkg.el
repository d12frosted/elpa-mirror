(define-package "gptai" "20230430.1823" "Integrate with the OpenAI API"
  '((emacs "24.1"))
  :commit "a2e84a9936fb7dee82024082bc38e6f7564506e4" :authors
  '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainers
  '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainer
  '("Anton Hibl" . "antonhibl11@gmail.com")
  :keywords
  '("comm" "convenience")
  :url "https://github.com/antonhibl/gptai")
;; Local Variables:
;; no-byte-compile: t
;; End:
