(define-package "w3m" "20210817.327" "an Emacs interface to w3m" 'nil :commit "179adee10bc835ecc6fa245d20dc5ec577104ef3" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
