(define-package "w3m" "20210817.327" "an Emacs interface to w3m" 'nil :commit "a30c750fc2b356c7d3adaa5d75dc436a2d3d1368" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
