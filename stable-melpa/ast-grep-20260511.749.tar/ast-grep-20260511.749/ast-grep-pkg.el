;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ast-grep" "20260511.749"
  "Search code using ast-grep with completing-read interface."
  '((emacs "28.1"))
  :url "https://github.com/sunskyxh/ast-grep.el"
  :commit "6de548db344dea994d4a777f069bbadcf5c7a79b"
  :revdesc "6de548db344d"
  :keywords '("tools" "matching")
  :authors '(("SunskyxXH" . "sunskyxh@gmail.com"))
  :maintainers '(("SunskyxXH" . "sunskyxh@gmail.com")))
