(define-package "org-re-reveal" "20211118.1032" "Org export to reveal.js presentations"
  '((emacs "24.4")
    (org "8.3")
    (htmlize "1.34"))
  :commit "61030efb11d313a158c74c6011be273246051490" :keywords
  '("tools" "outlines" "hypermedia" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/org-re-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
