(define-package "nnreddit" "20210912.236" "Gnus Backend For Reddit"
  '((emacs "25.1")
    (request "0.3.3")
    (anaphora "1.0.4")
    (dash "2.18.1")
    (json-rpc "0.0.1")
    (virtualenvwrapper "20151123")
    (s "1.6.1"))
  :commit "cb22a8480e9688f16f3764953cebebe64df31ccf" :keywords
  '("news")
  :url "https://github.com/dickmao/nnreddit")
;; Local Variables:
;; no-byte-compile: t
;; End:
