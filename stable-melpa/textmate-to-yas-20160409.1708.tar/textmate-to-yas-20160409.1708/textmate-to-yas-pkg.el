;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "textmate-to-yas" "20160409.1708"
  "Import Textmate macros into yasnippet syntax."
  ()
  :url "https://github.com/mlf176f2/textmate-to-yas.el/"
  :commit "be3a768b7ac4c2e24b9d4aa6e9ac1d916cdc5a73"
  :revdesc "be3a768b7ac4"
  :keywords '("yasnippet" "textmate"))
