;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250502.1842"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "5b21ef9022d787514141475104f78e788faabc59"
  :revdesc "5b21ef9022d7"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
