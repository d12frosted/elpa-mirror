(define-package "mpdel" "20190428.918" "Play and control your MPD music"
  '((emacs "25.1")
    (libmpdel "1.0.0"))
  :commit "a2da2f2fe2357641909514da788f7c6cbe5801f4" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("multimedia")
  :url "https://gitlab.petton.fr/mpdel/mpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
