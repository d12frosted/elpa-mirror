;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260406.150"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "62193075aa38cd64fc812b6208e6fffb2a207e5f"
  :revdesc "62193075aa38"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
