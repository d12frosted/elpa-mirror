(define-package "geiser" "20220825.1804" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (transient "0.3")
    (project "0.8.1"))
  :commit "40f03bbad917a16ffda0e4b5d5795a2875bc0428" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
