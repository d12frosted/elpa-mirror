(define-package "loco" "20240617.1524" "A library and minor mode for entering key sequences"
  '((emacs "29.1"))
  :commit "d3b955b5a92ce7131cfd41d3737fd5c2e622084d" :authors
  '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainers
  '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainer
  '("Chris McLaren" . "csmclaren@me.com")
  :keywords
  '("abbrev" "convenience")
  :url "https://github.com/csmclaren/loco")
;; Local Variables:
;; no-byte-compile: t
;; End:
