;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241201.1125"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "5c18500b873802a3b167caef98c0ced62515b2ef"
  :revdesc "5c18500b8738"
  :keywords '("convenience" "modal-editing"))
