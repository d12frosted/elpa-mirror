;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260204.1544"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "acd4f380b1f943eaa0a6465e41f521d8ed6e8c2c"
  :revdesc "acd4f380b1f9")
