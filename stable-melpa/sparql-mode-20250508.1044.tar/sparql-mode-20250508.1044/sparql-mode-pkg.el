;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sparql-mode" "20250508.1044"
  "Edit and interactively evaluate SPARQL queries."
  '((cl-lib "0.5")
    (emacs  "24.3"))
  :url "https://github.com/ljos/sparql-mode"
  :commit "be606dc08d808e7d996e531d2878ce5a27ad37f4"
  :revdesc "be606dc08d80"
  :authors '(("Craig Andera" . "canderaatwangderadotcom"))
  :maintainers '(("Bjarte Johansen" . "BjartedotJohansenatgmaildotcom")))
