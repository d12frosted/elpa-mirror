(define-package "proof-general" "20201219.1543" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.3"))
  :commit "221b68de1a06c0833fb91e26f27721e8f928d45c" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
