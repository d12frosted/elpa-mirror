;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "20260516.1903"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "eb9625e1db3821a277a11364616cae1516d8e0ba"
  :revdesc "eb9625e1db38"
  :keywords '("tools")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
