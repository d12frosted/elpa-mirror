(define-package "elfeed-score" "20210805.1535" "Gnus-style scoring for Elfeed"
  '((emacs "26.1")
    (elfeed "3.3.0"))
  :commit "53d4154c7d993ea5424535b3f0c4e9e75388e36e" :authors
  '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainer
  '("Michael Herstine" . "sp1ff@pobox.com")
  :keywords
  '("news")
  :url "https://github.com/sp1ff/elfeed-score")
;; Local Variables:
;; no-byte-compile: t
;; End:
