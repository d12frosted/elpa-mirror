;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260402.1738"
  "A minimal Jabber client."
  '((emacs "29.1")
    (fsm   "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-jabber"
  :commit "aade6a9e3584b4eccd7a4893e1b5881c3ac1356c"
  :revdesc "aade6a9e3584"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
