;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260309.2343"
  "Emacs frontend for pi coding agent."
  '((emacs      "29.1")
    (transient  "0.9.0")
    (md-ts-mode "0.3.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "6d3eeb658d91b03643d8fde348c60ede47e70ecb"
  :revdesc "6d3eeb658d91"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
