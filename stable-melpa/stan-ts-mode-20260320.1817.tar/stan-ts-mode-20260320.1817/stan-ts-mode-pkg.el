;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stan-ts-mode" "20260320.1817"
  "Major mode for editing Stan files."
  '((emacs "30.1"))
  :url "https://github.com/WardBrian/stan-ts-mode"
  :commit "14e85d2dd8930935899db4c3156db21c7980c613"
  :revdesc "14e85d2dd893"
  :keywords '("stan" "languages" "tree-sitter")
  :authors '(("Brian Ward" . "bward@flatironinstitute.org"))
  :maintainers '(("Brian Ward" . "bward@flatironinstitute.org")))
