;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-gwt" "20261119.1208"
  "GWT-style BDD testing for ERT."
  '((emacs "28.1"))
  :url "https://github.com/OverbearingPearl/ert-gwt"
  :commit "3687d0fe043c5feb413689ddacf235d5f304f6dd"
  :revdesc "3687d0fe043c"
  :keywords '("lisp" "tools")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
