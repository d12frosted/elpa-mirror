(define-package "grugru" "20211115.1721" "Rotate text at point"
  '((emacs "24.4"))
  :commit "b7eac6e07dfac87835bf4094cecd74d559674244" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
