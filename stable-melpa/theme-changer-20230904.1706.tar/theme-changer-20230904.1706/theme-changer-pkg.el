;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "theme-changer" "20230904.1706"
  "Sunrise/Sunset Theme Changer for Emacs."
  '((cl-lib "0"))
  :url "https://github.com/hadronzoo/theme-changer"
  :commit "7febd7632451bb99a5d92f24623432c4de035ff1"
  :revdesc "7febd7632451"
  :keywords '("color-theme" "deftheme" "solar" "sunrise" "sunset")
  :authors '(("Joshua B. Griffith" . "josh.griffith@gmail.com"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
