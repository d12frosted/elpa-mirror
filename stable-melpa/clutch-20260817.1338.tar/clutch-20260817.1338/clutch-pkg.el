;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260817.1338"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "c2c098bfc86a05c8deb1970445435a3493f52270"
  :revdesc "c2c098bfc86a"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
