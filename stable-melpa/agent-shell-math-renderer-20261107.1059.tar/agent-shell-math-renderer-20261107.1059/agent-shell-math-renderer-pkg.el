;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20261107.1059"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.89.4")
    (latex-to-svg-backend "0.19.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "cf7aa1a0be27c9dbf92471d9ac98cef631bda44a"
  :revdesc "cf7aa1a0be27"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
