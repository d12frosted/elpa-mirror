;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260228.651"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "fe41733a7b00d872175ae0ad6c1290e01782157f"
  :revdesc "fe41733a7b00"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
