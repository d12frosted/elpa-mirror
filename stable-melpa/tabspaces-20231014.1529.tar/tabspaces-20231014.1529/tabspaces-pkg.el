(define-package "tabspaces" "20231014.1529" "Leverage tab-bar and project for buffer-isolated workspaces"
  '((emacs "27.1")
    (project "0.8.1"))
  :commit "a11882e3aa5caf2c86af48d66e067fc32884c432" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainers
  '(("Colin McLear"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/mclear-tools/tabspaces")
;; Local Variables:
;; no-byte-compile: t
;; End:
