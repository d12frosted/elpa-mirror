(define-package "shanty-themes" "20220509.1656" "The themes for digital workers"
  '((emacs "27.2"))
  :commit "14a0e9de08aa6412931b121ae97b700e10ccaa80" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
