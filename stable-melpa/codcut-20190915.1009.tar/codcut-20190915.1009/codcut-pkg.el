;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codcut" "20190915.1009"
  "Share pieces of code to Codcut."
  ()
  :url "https://github.com/codcut/codcut-emacs"
  :commit "bf07c3db3900e36b0b87423f3b715d6378f86393"
  :revdesc "bf07c3db3900"
  :keywords '("comm" "tools" "codcut" "share")
  :authors '(("Diego Pasquali" . "hello@dgopsq.space"))
  :maintainers '(("Diego Pasquali" . "hello@dgopsq.space")))
