(define-package "boon" "20220918.1946" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "ee3d12fa3a811f13806b005bb3b1395e5f41dba9")
;; Local Variables:
;; no-byte-compile: t
;; End:
