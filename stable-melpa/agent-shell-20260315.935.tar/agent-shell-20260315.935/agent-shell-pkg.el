;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260315.935"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "264dc76e674bf38e5e42370a1a706e3785f90678"
  :revdesc "264dc76e674b")
