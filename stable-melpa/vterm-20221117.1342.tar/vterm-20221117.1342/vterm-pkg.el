(define-package "vterm" "20221117.1342" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "fd2a0255b1d8c0f112b3e2a5e01ff2e510d05def" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
