;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251029.2058"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "767fb6c45b8d49d30b62cf7b5903f3e6a5748025"
  :revdesc "767fb6c45b8d"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
