(define-package "ox-linuxmag-fr" "20230206.2037" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "de0768f44a7401c05535e6b7bc68aef98e547ce3" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
