(define-package "tree-sitter-langs" "20210805.303" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.15.0"))
  :commit "8a531ff9fabe88a2054739822240a34930001384" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/tree-sitter-langs")
;; Local Variables:
;; no-byte-compile: t
;; End:
