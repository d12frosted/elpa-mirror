(define-package "babashka" "20230704.1224" "Babashka Tasks Interface"
  '((emacs "27.1")
    (parseedn "1.1.0"))
  :commit "0714564d2092d37751085ac729712f05c2bb1b91" :authors
  '(("Mykhaylo Bilyanskyy" . "mb@m1k.pw"))
  :maintainers
  '(("Mykhaylo Bilyanskyy" . "mb@m1k.pw"))
  :maintainer
  '("Mykhaylo Bilyanskyy" . "mb@m1k.pw")
  :url "https://github.com/licht1stein/babashka.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
