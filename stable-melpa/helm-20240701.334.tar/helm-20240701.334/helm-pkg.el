(define-package "helm" "20240701.334" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.9")
    (wfnames "1.2"))
  :commit "a3595001098bef01314dad941b21e795f04aa280" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
