(define-package "edts" "20220312.2132" "Erlang Development Tool Suite"
  '((auto-complete "20201213.1255")
    (auto-highlight-symbol "20211106.638")
    (dash "20210609.1330")
    (emacs "24.3")
    (erlang "20210315.1640")
    (f "20191110.1357")
    (popup "20210317.138")
    (s "20210603.736"))
  :commit "d815148f22ed194116dcde63a0150919e380ecd6")
;; Local Variables:
;; no-byte-compile: t
;; End:
