;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261020.1355"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "68d1ad454ba17865d7195ffc73ef6d767c92b355"
  :revdesc "68d1ad454ba1"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
