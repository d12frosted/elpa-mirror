;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inform-mode" "20250415.1252"
  "Major mode for Inform 6 interactive fiction code."
  '((emacs "29.1"))
  :url "https://rrthomas.github.io/inform-mode"
  :commit "f24b44dfd623d47a3a83b43bd969dad33435cd09"
  :revdesc "f24b44dfd623"
  :keywords '("languages")
  :authors '(("Rupert Lane" . "rupert@rupert-lane.org")
             ("Gareth Rees" . "Gareth.Rees@cl.cam.ac.uk"))
  :maintainers '(("Reuben Thomas" . "rrt@sc3d.org")))
