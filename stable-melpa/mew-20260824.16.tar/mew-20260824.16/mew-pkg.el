;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260824.16"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "97fac965e9880e02d1e8778190cddf4059d6be04"
  :revdesc "97fac965e988")
