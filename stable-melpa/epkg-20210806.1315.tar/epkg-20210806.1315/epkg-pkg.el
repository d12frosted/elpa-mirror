(define-package "epkg" "20210806.1315" "browse the Emacsmirror package database"
  '((closql "1.0.6")
    (emacs "25.1"))
  :commit "23045743150f9a50ccc164a710c4d495820de803" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
