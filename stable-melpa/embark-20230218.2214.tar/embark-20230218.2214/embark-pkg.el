(define-package "embark" "20230218.2214" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "5497a19eef92e4b82e2dcbcd26eb671227240c45" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
