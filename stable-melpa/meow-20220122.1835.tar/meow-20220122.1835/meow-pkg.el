(define-package "meow" "20220122.1835" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "de39ddf6f9fd6503ae68ede681117ac3a323c1a7" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
