;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digistar-mode" "20250710.1554"
  "Major mode for Digistar scripts."
  '((emacs "25.1"))
  :url "https://github.com/retroj/digistar-mode/"
  :commit "09063c4f05129be3c4b595a318edabf6ad05393a"
  :revdesc "09063c4f0512"
  :keywords '("languages")
  :authors '(("John Foerch" . "jjfoerch@gmail.com"))
  :maintainers '(("John Foerch" . "jjfoerch@gmail.com")))
