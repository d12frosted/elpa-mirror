(define-package "consult" "20210201.1902" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "319f9155b9505e65ccc32a2183592a4d1ca6bea1" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
