(define-package "rmsbolt" "20210624.417" "A compiler output viewer"
  '((emacs "25.1"))
  :commit "3a8964d537e6c84671f8ff41741cf2064ec151eb" :authors
  '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainer
  '("Jay Kamat" . "jaygkamat@gmail.com")
  :keywords
  '("compilation" "tools")
  :url "http://gitlab.com/jgkamat/rmsbolt")
;; Local Variables:
;; no-byte-compile: t
;; End:
