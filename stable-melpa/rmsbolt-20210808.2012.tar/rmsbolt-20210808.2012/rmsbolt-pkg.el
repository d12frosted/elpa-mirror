(define-package "rmsbolt" "20210808.2012" "A compiler output viewer"
  '((emacs "25.1"))
  :commit "972e6f41a2e0c76a1cdbab462965bbcb378bdb79" :authors
  '(("Jay Kamat" . "jaygkamat@gmail.com"))
  :maintainer
  '("Jay Kamat" . "jaygkamat@gmail.com")
  :keywords
  '("compilation" "tools")
  :url "http://gitlab.com/jgkamat/rmsbolt")
;; Local Variables:
;; no-byte-compile: t
;; End:
