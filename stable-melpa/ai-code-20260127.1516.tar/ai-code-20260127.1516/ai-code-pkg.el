;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260127.1516"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3c1f815081b028ccadbf035c8ab0bde759f3936a"
  :revdesc "3c1f815081b0"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
