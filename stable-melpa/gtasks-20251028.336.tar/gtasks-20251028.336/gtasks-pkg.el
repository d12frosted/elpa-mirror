;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gtasks" "20251028.336"
  "Google Tasks API (sync)."
  '((emacs "27.1"))
  :url "https://github.com/thndrbrrr/gtasks"
  :commit "574205a511b5788e3711f86a438573a62a08c472"
  :revdesc "574205a511b5"
  :keywords '("convenience" "tools" "google" "tasks" "api")
  :authors '((nil . "thndrbrrr@gmail.com"))
  :maintainers '((nil . "thndrbrrr@gmail.com")))
