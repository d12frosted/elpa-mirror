;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241108.1609"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "1b94ff9445f62debd6649047bc3dc86807b393bd"
  :revdesc "1b94ff9445f6"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
