(define-package "dirvish" "20220612.1300" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "b8e92be2c08066168198f7e3a77a6af767f892dc" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
