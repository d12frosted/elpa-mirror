;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "crux" "20261001.519"
  "A Collection of Ridiculously Useful eXtensions."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/crux"
  :commit "29b05ef8eda684aa8cb2156ef68aaef2f50985e4"
  :revdesc "29b05ef8eda6"
  :keywords '("convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
