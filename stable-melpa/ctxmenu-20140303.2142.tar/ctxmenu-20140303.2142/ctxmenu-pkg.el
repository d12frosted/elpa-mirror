;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ctxmenu" "20140303.2142"
  "Provide a context menu like right-click."
  '((popup      "20140205.103")
    (log4e      "0.2.0")
    (yaxception "0.1"))
  :url "https://github.com/aki2o/emacs-ctxmenu"
  :commit "5c2376859562b98c07c985d2b483658e4c0e888e"
  :revdesc "5c2376859562"
  :keywords '("popup")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
