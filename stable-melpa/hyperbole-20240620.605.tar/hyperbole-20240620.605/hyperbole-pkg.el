(define-package "hyperbole" "20240620.605" "GNU Hyperbole: The Everyday Hypertextual Information Manager"
  '((emacs "27.1"))
  :commit "c4cfe68db84a8b682a589791a336ce3c42899e34" :authors
  '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers
  '(("Mats Lidell" . "matsl@gnu.org"))
  :maintainer
  '("Mats Lidell" . "matsl@gnu.org")
  :keywords
  '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :url "http://www.gnu.org/software/hyperbole")
;; Local Variables:
;; no-byte-compile: t
;; End:
