(define-package "org-change" "20231023.152" "Annotate changes in org-mode files"
  '((emacs "26.1")
    (org "9.3"))
  :commit "43d1d83713532c631ee72e35fd66bce295e93cc3" :keywords
  '("wp" "convenience")
  :url "https://github.com/drghirlanda/org-change")
;; Local Variables:
;; no-byte-compile: t
;; End:
