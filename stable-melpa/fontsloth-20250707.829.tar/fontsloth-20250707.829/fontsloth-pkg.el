;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fontsloth" "20250707.829"
  "Elisp otf/ttf font loader/renderer."
  '((async  "1.9.7")
    (f      "0.20.0")
    (logito "0.1")
    (pcache "0.5")
    (stream "2.2.5")
    (emacs  "28.1"))
  :url "https://github.com/jollm/fontsloth"
  :commit "0835098743e060b2f2191f53d181257d6444dce4"
  :revdesc "0835098743e0"
  :keywords '("data" "font" "rasterization" "ttf" "otf")
  :authors '(("Jo Gay" . "jo.gay@mailfence.com"))
  :maintainers '(("Jo Gay" . "jo.gay@mailfence.com")))
