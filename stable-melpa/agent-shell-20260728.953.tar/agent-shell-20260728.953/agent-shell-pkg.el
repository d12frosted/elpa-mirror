;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260728.953"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.94.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a59891a9d8f1d26afb8358239346e081708cf2cb"
  :revdesc "a59891a9d8f1")
