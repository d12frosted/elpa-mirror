;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260804.149"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "e32d8c6d93c763f52b69b4e459fd83c3aeda4d77"
  :revdesc "e32d8c6d93c7"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
