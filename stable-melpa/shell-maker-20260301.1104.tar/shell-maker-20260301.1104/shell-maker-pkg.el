;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260301.1104"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "d4b182e9fec919fa774972c1dc25e7700f36f966"
  :revdesc "d4b182e9fec9")
