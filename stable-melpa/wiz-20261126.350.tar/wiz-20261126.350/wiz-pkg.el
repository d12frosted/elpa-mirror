;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiz" "20261126.350"
  "Macros to simplify startup initialization."
  '((emacs                "29.1")
    (exec-path-from-shell "2.1"))
  :url "https://github.com/zonuexe/emacs-wiz"
  :commit "157e873e97947dabb35f3bf0ee092547a05b9161"
  :revdesc "157e873e9794"
  :keywords '("convenience" "lisp")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
