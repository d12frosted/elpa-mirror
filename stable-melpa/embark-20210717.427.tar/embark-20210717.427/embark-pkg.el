(define-package "embark" "20210717.427" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "72b12097835fd234677b9226129fc6600d88891b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
