;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260815.1459"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "30acda5aa115eaf395a40795cf3b5ed88bd2c2c3"
  :revdesc "30acda5aa115"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
