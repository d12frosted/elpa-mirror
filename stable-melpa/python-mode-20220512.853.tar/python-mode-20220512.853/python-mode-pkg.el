(define-package "python-mode" "20220512.853" "Python major mode" 'nil :commit "e1f288d2958aa9325f1dd344e635cb3e95ae498f" :authors
  '(("2015-2021 https://gitlab.com/groups/python-mode-devs")
    ("2003-2014 https://launchpad.net/python-mode")
    ("1995-2002 Barry A. Warsaw")
    ("1992-1994 Tim Peters"))
  :maintainer
  '(nil . "python-mode@python.org")
  :keywords
  '("languages" "processes" "python" "oop")
  :url "https://gitlab.com/groups/python-mode-devs")
;; Local Variables:
;; no-byte-compile: t
;; End:
