;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251110.1433"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "f2daf7d8d5ec63a9eae25c44e060649711cb1454"
  :revdesc "f2daf7d8d5ec"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
