;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20251105.121"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "7673e72ed4dc4af9c3db9a5962c4673bd1ce90e3"
  :revdesc "7673e72ed4dc"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
