;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260914.1423"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "aaf2743ebcd046426b9b9877828ba7c25c6104f5"
  :revdesc "aaf2743ebcd0"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
