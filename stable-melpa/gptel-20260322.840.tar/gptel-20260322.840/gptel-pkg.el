;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260322.840"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "4bb9d41e249d7fb00220a05efa3991033597746a"
  :revdesc "4bb9d41e249d"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
