(define-package "go-translate" "20240714.256" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "7c451ec408d1cdf5645940b8e9f769fbd58f4c6d" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
