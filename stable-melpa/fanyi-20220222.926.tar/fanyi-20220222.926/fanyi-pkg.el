(define-package "fanyi" "20220222.926" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "8a09c7a24bd959603f1ede3a28ee323f19e40451" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
