(define-package "libbcel" "20221003.1827" "Library to connect to basecamp 3 API"
  '((emacs "26.1")
    (request "0.3.1"))
  :commit "3d506a3fb5b377bf460e7b8096f7211949567f75" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://gitlab.petton.fr/bcel/libbcel")
;; Local Variables:
;; no-byte-compile: t
;; End:
