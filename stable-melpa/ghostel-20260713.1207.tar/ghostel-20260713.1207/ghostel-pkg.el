;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260713.1207"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "fccade496050fde96369950ee1d9976cf78fa63b"
  :revdesc "fccade496050"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
