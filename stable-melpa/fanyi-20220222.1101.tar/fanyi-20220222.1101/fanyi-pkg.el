(define-package "fanyi" "20220222.1101" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "bf214d3256143c4d18f3ec6060ee141d252424e2" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
