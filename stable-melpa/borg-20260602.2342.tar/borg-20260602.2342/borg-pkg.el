;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260602.2342"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.5"))
  :url "https://github.com/emacscollective/borg"
  :commit "04fc19ef58fc23965d582721cf22691e1bd91cfd"
  :revdesc "04fc19ef58fc"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
