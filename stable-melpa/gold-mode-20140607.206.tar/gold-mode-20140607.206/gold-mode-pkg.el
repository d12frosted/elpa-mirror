;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gold-mode" "20140607.206"
  "Major mode for editing .gold files."
  '((sws-mode "0"))
  :url "https://github.com/yuutayamada/gold-mode-el"
  :commit "6d3aa59602b1b835495271c8c9741ac344c2eab1"
  :revdesc "6d3aa59602b1"
  :keywords '("golang" "template" "gold")
  :authors '(("Yuta Yamada" . "cokesboy\"at\"gmail.com"))
  :maintainers '(("Yuta Yamada" . "cokesboy\"at\"gmail.com")))
