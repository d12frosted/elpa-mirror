(define-package "cape" "20230818.1821" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "ebac3e2eabf24e2fec1309d44fce5913c7c1a331" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
