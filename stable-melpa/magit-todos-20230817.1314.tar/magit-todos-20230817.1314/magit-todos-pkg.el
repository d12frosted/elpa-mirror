(define-package "magit-todos" "20230817.1314" "Show source file TODOs in Magit"
  '((emacs "26.1")
    (async "1.9.2")
    (dash "2.13.0")
    (f "0.17.2")
    (hl-todo "1.9.0")
    (magit "2.13.0")
    (pcre2el "1.8")
    (s "1.12.0")
    (transient "0.2.0"))
  :commit "cadf29d1cc410c71a0020c7f83999d9f61721b90" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("magit" "vc")
  :url "http://github.com/alphapapa/magit-todos")
;; Local Variables:
;; no-byte-compile: t
;; End:
