(define-package "binky" "20230904.437" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "690067264b7f5c942db05f0381f75b2d2b971f56" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
