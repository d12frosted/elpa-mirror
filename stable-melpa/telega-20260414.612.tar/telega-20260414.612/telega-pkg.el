;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260414.612"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "35c26aa9b88999e631cf0b7842fbd42219b1d2dc"
  :revdesc "35c26aa9b889"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
