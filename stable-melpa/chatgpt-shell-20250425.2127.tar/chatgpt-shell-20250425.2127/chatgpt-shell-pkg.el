;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250425.2127"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.76.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "51e0523d6c7abeb5b99ac93b0af033d28acc36b2"
  :revdesc "51e0523d6c7a")
