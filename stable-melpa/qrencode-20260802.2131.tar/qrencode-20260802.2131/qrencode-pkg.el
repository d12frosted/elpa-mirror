;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "qrencode" "20260802.2131"
  "QRCode encoder."
  '((emacs "25.1"))
  :url "https://github.com/ruediger/qrencode-el"
  :commit "7f19d5c20039e3c3e3872c7ae031509a0369d3bd"
  :revdesc "7f19d5c20039"
  :keywords '("qrcode" "comm")
  :authors '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net"))
  :maintainers '(("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")))
