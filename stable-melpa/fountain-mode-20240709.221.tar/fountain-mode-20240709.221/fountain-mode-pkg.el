(define-package "fountain-mode" "20240709.221" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "b9b0b34b2e4b502e0204d590c183d1db1b77570e" :authors
  '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainers
  '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainer
  '("Paul W. Rankin" . "rnkn@rnkn.xyz")
  :keywords
  '("wp" "text")
  :url "https://www.fountain-mode.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
