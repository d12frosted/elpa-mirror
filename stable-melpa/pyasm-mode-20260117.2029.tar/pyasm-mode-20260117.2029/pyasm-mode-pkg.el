;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyasm-mode" "20260117.2029"
  "Mode for editing assembler code."
  '((emacs  "24.4")
    (compat "30.1.0.1"))
  :url "https://github.com/rocky/emacs-pyasm-mode"
  :commit "3d3dc5a820a488a1fb9618fda5d7307a5eae75ec"
  :revdesc "3d3dc5a820a4"
  :keywords '("languages")
  :authors '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainers '((nil . "rocky@gnu.org")))
