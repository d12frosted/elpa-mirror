(define-package "org-ml" "20201207.638" "Functional Org Mode API"
  '((emacs "26.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "b644fdcc85090fd83827fb480482681409a3033e" :keywords
  ("org-mode" "outlines")
  :authors
  (("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  ("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
