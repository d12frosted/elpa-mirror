(define-package "eping" "20201019.2125" "Ping websites to check internet connectivity"
  '((emacs "25.1")
    (dash "2.12.0")
    (s "1.12.0"))
  :commit "0d5d80dd0c76f0d46a3565d940a2b0ed955dfd0a" :authors
  '(("Sean Hutchings" . "seanhut@yandex.com"))
  :maintainer
  '("Sean Hutchings" . "seanhut@yandex.com")
  :keywords
  '("comm" "processes" "terminals" "unix")
  :url "https://github.com/sean-hut/eping")
;; Local Variables:
;; no-byte-compile: t
;; End:
