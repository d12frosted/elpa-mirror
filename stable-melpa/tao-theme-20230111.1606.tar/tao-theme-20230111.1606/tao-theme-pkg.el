(define-package "tao-theme" "20230111.1606" "This package provides two parametrized uncoloured color themes for Emacs: tao-yin and tao-yang." 'nil :commit "5525e49357d066c0dca4ccc12ca69804e46577f2" :authors
  '(("Peter Kosov" . "11111000000@email.com"))
  :maintainer
  '("Peter Kosov" . "11111000000@email.com")
  :url "http://github.com/11111000000/tao-theme-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
