(define-package "workgroups2" "20211225.1005" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "f9479da3b35ec79555bcd190dbb1b5535947c4e4" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
