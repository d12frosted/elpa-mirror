;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occult" "20260908.327"
  "Collapse and reveal buffer regions."
  '((emacs "29.1"))
  :url "https://github.com/agzam/occult.el"
  :commit "9d12eed668acf7decaae6dd19a3f2fecaa1d3c68"
  :revdesc "9d12eed668ac"
  :keywords '("convenience")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
