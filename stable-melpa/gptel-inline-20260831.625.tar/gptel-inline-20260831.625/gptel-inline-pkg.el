;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-inline" "20260831.625"
  "Persistent gptel session that follows you around."
  '((emacs  "30.1")
    (compat "30.1.0.0")
    (gptel  "0.9.9.5"))
  :url "https://github.com/karthink/gptel-inline"
  :commit "3e7cd46681e57a3c56f720c6dd6ed589dec76307"
  :revdesc "3e7cd46681e5"
  :keywords '("comm")
  :authors '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthikchikmagalur@gmail.com")))
