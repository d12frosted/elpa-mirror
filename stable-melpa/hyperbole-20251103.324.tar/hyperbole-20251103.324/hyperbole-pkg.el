;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251103.324"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "932f80c044e46bf88ce95ff1e51cecd823de0785"
  :revdesc "932f80c044e4"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
