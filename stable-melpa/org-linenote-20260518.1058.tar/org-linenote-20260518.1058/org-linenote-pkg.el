;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-linenote" "20260518.1058"
  "A package inspired by VSCode Linenote."
  '((emacs         "29.1")
    (vertico       "1.7")
    (eldoc         "1.11")
    (fringe-helper "1.0.1"))
  :url "https://github.com/seokbeomKim/org-linenote"
  :commit "35a7940c1c81a1faf8f4b58a633cdcdd89c99509"
  :revdesc "35a7940c1c81"
  :keywords '("tools" "note" "org")
  :authors '(("Jason Kim" . "sukbeom.kim@gmail.com"))
  :maintainers '(("Jason Kim" . "sukbeom.kim@gmail.com")))
