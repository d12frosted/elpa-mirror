;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260326.141"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "08979671f1a3a5c957404e13cbe0c1633b08bf03"
  :revdesc "08979671f1a3"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
