(define-package "affe" "20211002.1821" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.10"))
  :commit "b7d51c5e5426863b39809fa6ebce5f54696b50d6" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
