;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260317.1541"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e61208a7f80ba4474a1d00ff42e51edf61af7e95"
  :revdesc "e61208a7f80b")
