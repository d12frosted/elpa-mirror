(define-package "datetime" "20240331.1909" "Parsing, formatting and matching timestamps"
  '((emacs "25.1")
    (extmap "1.1.1"))
  :commit "3d27814a099898f1ff68016a2e46558d0ffa6143" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
