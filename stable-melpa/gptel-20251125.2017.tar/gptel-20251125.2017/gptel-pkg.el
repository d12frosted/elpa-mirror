;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251125.2017"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "e8dbe7baae0f25e2fe0bbe5521cc0c7ffe0cc08f"
  :revdesc "e8dbe7baae0f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
