;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sql-sqlline" "20231109.2111"
  "Adds SQLLine support to SQLi mode."
  '((emacs "24.4"))
  :url "https://gitlab.com/matteoredaelli/sql-sqlline"
  :commit "3d540a8cc9c6f816b241913042008f09323455af"
  :revdesc "3d540a8cc9c6"
  :keywords '("languages")
  :authors '(("Matteo Redaelli" . "matteo.redaelli@gmail.com"))
  :maintainers '(("Matteo Redaelli" . "matteo.redaelli@gmail.com")))
