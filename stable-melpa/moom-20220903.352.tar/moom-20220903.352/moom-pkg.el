(define-package "moom" "20220903.352" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "c4dfd12068f438919d7966f9e975fcac6a840a76" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
