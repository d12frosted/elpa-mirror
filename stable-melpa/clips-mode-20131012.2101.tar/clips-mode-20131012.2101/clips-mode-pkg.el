(define-package "clips-mode" "20131012.2101" "Major mode for editing CLIPS code and REPL" 'nil :commit "a3ab4a3e958d54a16544ec38fe6338f27df20817" :authors
  '(("David E. Young" . "david.young@fnc.fujitsu.com")
    ("Andrey Kotlarski" . "m00naticus@gmail.com")
    ("Grant Rettke" . "grettke@acm.org"))
  :maintainer
  '("Grant Rettke" . "grettke@acm.org")
  :keywords
  '("clips"))
;; Local Variables:
;; no-byte-compile: t
;; End:
