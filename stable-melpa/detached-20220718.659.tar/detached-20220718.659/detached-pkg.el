(define-package "detached" "20220718.659" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "56bf59e7d4b8997901e4b7db87e94e7ed17998fd" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
