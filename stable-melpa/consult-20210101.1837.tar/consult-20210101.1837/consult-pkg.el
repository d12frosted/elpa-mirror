(define-package "consult" "20210101.1837" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "2fd52e09e65676801632e5ae208c74144ba226f8" :authors
  (("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  ("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
