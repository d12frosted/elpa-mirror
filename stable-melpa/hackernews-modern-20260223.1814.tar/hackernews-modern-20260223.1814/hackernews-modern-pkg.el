;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hackernews-modern" "20260223.1814"
  "Hacker News client with modern widget UI."
  '((emacs              "28.1")
    (visual-fill-column "2.2"))
  :url "https://git.andros.dev/andros/hackernews-modern-el"
  :commit "e0972d950b028ee7b6030dcc44265357e5c4108d"
  :revdesc "e0972d950b02"
  :keywords '("comm" "hypermedia" "news")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
