;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "app-monochrome-themes" "20241110.930"
  "Low contrast monochrome themes."
  '((emacs "24.4"))
  :url "https://github.com/Greybeard-Entertainment/app-monochrome"
  :commit "751b38f288ae736073a77df72457ddd6ca4765d0"
  :revdesc "751b38f288ae"
  :authors '(("Aleksandr Petrosyan" . "appetrosan3@gmail.com"))
  :maintainers '(("Aleksandr Petrosyan" . "appetrosan3@gmail.com")))
