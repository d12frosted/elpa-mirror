;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stan-ts-mode" "20260309.1402"
  "Major mode for editing Stan files."
  '((emacs "30.1"))
  :url "https://github.com/WardBrian/stan-ts-mode"
  :commit "f1318ceeece817d608e2644d30712dee123c6d1a"
  :revdesc "f1318ceeece8"
  :keywords '("stan" "languages" "tree-sitter")
  :authors '(("Brian Ward" . "bward@flatironinstitute.org"))
  :maintainers '(("Brian Ward" . "bward@flatironinstitute.org")))
