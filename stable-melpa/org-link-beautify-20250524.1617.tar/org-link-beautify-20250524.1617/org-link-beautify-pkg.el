;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20250524.1617"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "8f88b821c5787a2961c6b7ab2f2d71d2e817a7d6"
  :revdesc "8f88b821c578"
  :keywords '("hypermedia"))
