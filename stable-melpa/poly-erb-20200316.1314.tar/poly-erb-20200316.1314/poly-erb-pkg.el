;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-erb" "20200316.1314"
  "Polymode for erb."
  '((emacs    "25")
    (polymode "0.2.2"))
  :url "https://github.com/polymode/poly-erb"
  :commit "56c744b8d87d8cbe0aba2696d4e8525afc4aa0e8"
  :revdesc "56c744b8d87d"
  :keywords '("emacs"))
