;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260320.1646"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "1d63d04dd95a12473c737f12cda85be1ea526098"
  :revdesc "1d63d04dd95a"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
