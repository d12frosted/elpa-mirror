(define-package "rime" "20201227.717" "Rime input method"
  '((emacs "26.3")
    (dash "2.12.0")
    (cl-lib "0.6.1")
    (popup "0.5.3")
    (posframe "0.1.0"))
  :commit "c797c443886aca6083737a3644e45af51f5b6760" :authors
  (("Shi Tianshu"))
  :maintainer
  ("Shi Tianshu")
  :keywords
  ("convenience" "input-method")
  :url "https://www.github.com/DogLooksGood/emacs-rime")
;; Local Variables:
;; no-byte-compile: t
;; End:
