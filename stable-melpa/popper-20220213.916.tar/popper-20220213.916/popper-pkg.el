(define-package "popper" "20220213.916" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "47bf592c89e6bb54150559386ca2a094ca3dff1e" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
