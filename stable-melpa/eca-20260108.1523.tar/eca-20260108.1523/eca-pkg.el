;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260108.1523"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "93e94e43fc7a1999a1f352b00acbc7eb3b0396e6"
  :revdesc "93e94e43fc7a"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
