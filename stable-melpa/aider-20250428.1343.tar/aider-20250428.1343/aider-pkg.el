;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250428.1343"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "5b3ed745ae32f97a6881cc88cbc1046023b6c209"
  :revdesc "5b3ed745ae32"
  :keywords '("agent" "ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
