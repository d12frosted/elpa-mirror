(define-package "magit-section" "20220325.1720" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "d134b87a6b4b84791e1fca655f5e4feb62580920" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
