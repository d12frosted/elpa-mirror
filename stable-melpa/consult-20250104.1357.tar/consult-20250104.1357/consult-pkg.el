;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250104.1357"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "c824677a40dde91121923462e3017fe21759de93"
  :revdesc "c824677a40dd"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
