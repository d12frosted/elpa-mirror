;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20251101.2020"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.22.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "0afac06521c3d1274262f351a281fcf85e92a7ea"
  :revdesc "0afac06521c3"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
