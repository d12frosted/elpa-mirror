;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yml" "20261110.1449"
  "Fast YAML parser (dynamic module)."
  '((emacs "26.1"))
  :url "https://github.com/isamert/yml.el"
  :commit "936dbbded7616adf9282d7b54272faec4f5a6332"
  :revdesc "936dbbded761"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
