(define-package "humanoid-themes" "20210514.1657" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "855bb895784767d770c88a0265837ab5439c70f1" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
