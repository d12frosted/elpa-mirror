(define-package "tok-theme" "20230730.1922" "Minimal light monochromatic theme for Emacs in the spirit of Zmacs and Smalltalk-80."
  '((emacs "27.0"))
  :commit "b926f4a5891be2428489601b0de7e475dd1b697d" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
