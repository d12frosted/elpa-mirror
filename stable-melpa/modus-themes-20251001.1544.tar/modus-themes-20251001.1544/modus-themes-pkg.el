;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251001.1544"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "6326130654f413fd15862fe71a8901a0b3592f44"
  :revdesc "6326130654f4"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
