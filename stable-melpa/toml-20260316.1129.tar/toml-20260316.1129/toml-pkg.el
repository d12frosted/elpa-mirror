;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260316.1129"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "141a5f24ac6e727955393f749217c46c9c497087"
  :revdesc "141a5f24ac6e"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
