;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abridge-diff" "20230307.2159"
  "Abridge long line-based diff hunks, including in magit."
  '((emacs "26.1"))
  :url "https://github.com/jdtsmith/abridge-diff"
  :commit "31e0ccaa9d0bd4ad257f5de25cc3c0b3395fafa1"
  :revdesc "31e0ccaa9d0b"
  :keywords '("magit" "diffs" "tools")
  :authors '(("J.D. Smith" . "jdtsmithATgmail"))
  :maintainers '(("J.D. Smith" . "jdtsmithATgmail")))
