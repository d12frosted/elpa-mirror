;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241016.1304"
  "ChatGPT shell + buffer insert commands."
  '((emacs       "27.1")
    (shell-maker "0.53.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "a13794d1b967bd4cc3cbe6be6d6a4eb9a3677e04"
  :revdesc "a13794d1b967")
