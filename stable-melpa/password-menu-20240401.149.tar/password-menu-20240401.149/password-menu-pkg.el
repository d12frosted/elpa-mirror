(define-package "password-menu" "20240401.149" "Password Menu for auth-source secrets"
  '((emacs "28.1"))
  :commit "77be1d6a9f742cb6e2982fc8bdb120f752fb76e5" :authors
  '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainers
  '(("Robert Nadler" . "robert.nadler@gmail.com"))
  :maintainer
  '("Robert Nadler" . "robert.nadler@gmail.com")
  :keywords
  '("news")
  :url "https://github.com/rnadler/password-menu")
;; Local Variables:
;; no-byte-compile: t
;; End:
