;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calibredb" "20260811.1404"
  "Yet another calibre client."
  '((emacs     "29.1")
    (org       "9.3")
    (transient "0.1.0")
    (s         "1.12.0")
    (dash      "2.17.0")
    (request   "0.3.3")
    (esxml     "0.3.7"))
  :url "https://github.com/chenyanming/calibredb.el"
  :commit "18d146481d0176935fde1baebec6d1a65151cff6"
  :revdesc "18d146481d01"
  :keywords '("tools")
  :authors '(("Damon Chan" . "elecming@gmail.com"))
  :maintainers '(("Damon Chan" . "elecming@gmail.com")))
