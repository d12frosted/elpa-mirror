;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pet" "20251216.116"
  "Executable and virtualenv tracker for python-mode."
  '((emacs "27.1")
    (f     "0.6.0")
    (map   "3.3.1")
    (seq   "2.24"))
  :url "https://github.com/wyuenho/emacs-pet/"
  :commit "2b40310a210ca672fd454cf0ad2a6c78dc6c412f"
  :revdesc "2b40310a210c"
  :keywords '("tools")
  :authors '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com"))
  :maintainers '(("Jimmy Yuen Ho Wong" . "wyuenho@gmail.com")))
