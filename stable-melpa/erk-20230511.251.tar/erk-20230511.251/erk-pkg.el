(define-package "erk" "20230511.251" "Elisp (GitHub) Repository Kit"
  '((emacs "28.1")
    (auto-compile "1.2.0")
    (dash "2.18.0"))
  :commit "f6cca4647538c4dc659f07669938f7e795dba4ee" :authors
  '(("<author>"))
  :maintainers
  '(("<author>"))
  :maintainer
  '("<author>")
  :keywords
  '("convenience")
  :url "http://github.com/positron-solutions/elisp-repo-kit")
;; Local Variables:
;; no-byte-compile: t
;; End:
