(define-package "slime" "20240928.1151" "Superior Lisp Interaction Mode for Emacs"
  '((emacs "24.3")
    (macrostep "0.9"))
  :commit "8b5bbccf178717a63c053f6c74c8f1288dce9b8b" :keywords
  '("languages" "lisp" "slime")
  :url "https://github.com/slime/slime")
;; Local Variables:
;; no-byte-compile: t
;; End:
