;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20241130.2157"
  "Fuzzy completion style using `flx'."
  '((emacs "28.2")
    (flx   "0.5"))
  :url "https://github.com/jojojames/fussy"
  :commit "9e4b84508e3a305647946d887d381729eabed2f3"
  :revdesc "9e4b84508e3a"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
