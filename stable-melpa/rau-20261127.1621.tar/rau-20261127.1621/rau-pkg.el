;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rau" "20261127.1621"
  "Wayland Window Manager based on River."
  '((emacs "31.1")
    (ewc   "0")
    (lgr   "0.1.0"))
  :url "https://github.com/thkoch2001/rau"
  :commit "bca533776f4264c5b0cf996c450d73fdf3b30df6"
  :revdesc "bca533776f42"
  :keywords '("frames")
  :authors '(("Thomas Koch" . "thomas@koch.ro"))
  :maintainers '(("Thomas Koch" . "thomas@koch.ro")))
