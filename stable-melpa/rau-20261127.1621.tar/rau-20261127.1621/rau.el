;;; rau.el --- Wayland Window Manager based on River -*- lexical-binding: t -*-

;; Copyright (C) 2026 Thomas Koch

;; Author: Thomas Koch <thomas@koch.ro>
;; Package-Version: 20261127.1621
;; Package-Revision: bca533776f42
;; Keywords: frames
;; URL: https://github.com/thkoch2001/rau
;; Package-Requires: ((emacs "31.1")
;;                    (ewc)
;;                    (lgr "0.1.0"))

;;; Commentary:
;; Rau is a Wayland Window Manager based on Emacs and River in pure Elisp.  The
;; heavy lifting is provided by River, written in Zig and thus fast while the
;; opinionated parts like Window placement, Keybindings and Focus management
;; are written in Elisp and are thus easy to customize.

;;; History:
;; This package is based on <https://codeberg.org/tazjin/reka>. The major
;; difference is that reka uses Rust code to bind to libwayland while rau uses
;; the ewc.el library of Michael Bauer to implement wayland communication.

;;; SPDX-License-Identifier: GPL-3.0-or-later

;;; Code:

(require 'cl-lib)
(require 'rau-lib)
(require 'server)

(declare-function rau--bind-parsed-keys "rau-be" (parsed-keys))
(declare-function rau--manage-enqueue "rau-be" (ewc-object request &optional args))
(declare-function rau--mark-manage-dirty "rau-be" ())
(declare-function rau--request-focus "rau-be" (target))
(declare-function rau--toggle-fullscreen-by-window-id "rau-be" (window-id))
(declare-function rau--update-fe-ui-state "rau-be" (state))

(defgroup rau nil
  "Rau - Emacs swimming in the river."
  :group 'environment
  :prefix "rau-")

(defcustom rau-ready-hook nil
  "Hook run when Rau is ready.
At the moment this means that all global Wayland objects have been registered.
This is the right place to setup keybindings."
  :type 'hook)

(defcustom rau-backend-init-file nil
  "Emacs Lisp init file for the backend Emacs instance.
Logging for the backend can be configured there."
  :type 'file
  :risky t)

(defcustom rau-menu-bar-height nil
  "Vertical offset in pixels for Wayland windows if `menu-bar-mode' is enabled.
There is no way from inside Emacs to find out this value, so it needs to
be set for each setup individually by trial-and-error.  This is
experimental!"
  :type 'integer)

(defcustom rau-tool-bar-height nil
  "Vertical offset in pixels for Wayland windows if `tool-bar-mode' is enabled.
There is no way from inside Emacs to find out this value, so it needs to
be set for each setup individually by trial-and-error.  This is
experimental!"
  :type 'integer)

(defvar rau--fe-state nil
  "Current global rau WM front-end state.")

(cl-defstruct (rau--fe-state (:constructor rau--fe-state-make))
  last-send-state
  ;; task queue: list of (FN ARGS...).
  ;; TODO: move to rau--fe-state
  task-queue
  task-timer)

;;; Data access helpers

(defun rau--window-id-for-emacs-window (emacs-window)
  "Return window-id for any EMACS-WINDOW rau-mode or not.
For a window with a `rau-mode' buffer return window-id pointing to an
external window.  For all other buffers return the window-id of the
Emacs frame."
  (if-let* ((buffer (window-buffer emacs-window))
            (window-id (buffer-local-value 'rau--window-id buffer)))
      window-id
    (let ((emacs-frame (window-frame emacs-window)))
      (frame-parameter emacs-frame 'rau--window-id))))

(defun rau--buffer-for-window-id (window-id)
  "Return Emacs buffer for Wayland WINDOW-ID."
  (cl-find window-id
           (buffer-list)
           :key (lambda (b) (buffer-local-value 'rau--window-id b))))

(defun rau--emacs-window-for-window-id (window-id)
  "Return Emacs window associated with WINDOW-ID."
  (when-let* ((buffer (rau--buffer-for-window-id window-id)))
    (get-buffer-window buffer 'visible)))

;;; Emacs integration, interaction

(defun rau--make-outputframe-parameters ()
  "Make standard frame parameters for a Rau output frame."
  (let ((params `((name . ,(make-temp-name "rau-frame-"))
                  (undecorated . t)
                  (window-system . pgtk)
                  ;; avoid showing the same rau buffer twice
                  (buffer-predicate . rau--buffer-predicate))))
    (unless rau-menu-bar-height
      (push '(menu-bar-lines . 0) params))
    (unless rau-tool-bar-height
      (push '(tool-bar-lines . 0) params))
    params))

;; Major mode for rau-managed buffers
(defvar-local rau--window-id nil
  "Wayland window id for this `rau-mode' buffer.")

(defun rau--show-only-once (win)
  "Hide rau buffer on any other window than WIN."
  (when-let* (((windowp win))
              (buffer (current-buffer))
              ;; only react to runs for newly added buffer
              ((eq (window-buffer win) buffer))
              (wins (get-buffer-window-list buffer 'nomb t)))
    (dolist (other-win (cdr wins))
      (rau--tasks-enqueue #'set-window-buffer other-win (other-buffer)))))

(define-derived-mode rau-mode special-mode "Rau"
  "Major mode for buffers representing windows managed by rau."
  :group 'rau
  (setq-local buffer-read-only t)
  (add-hook 'kill-buffer-query-functions #'rau--buffer-killed nil t)
  (add-hook 'window-buffer-change-functions #'rau--show-only-once nil t)
  (scroll-bar-mode 0)
  (setq-local left-fringe-width 0
              right-fringe-width 0))

;;; task queue
(defun rau--tasks-execute ()
  "Execute tasks enqueued by event listeners."
  (let ((tasks (nreverse (rau--fe-state-task-queue rau--fe-state))))
    (setf (rau--fe-state-task-queue rau--fe-state) nil)
    (while-let ((task (pop tasks)))
      (let ((fn (car task))
            (args (cdr task)))
        (condition-case-unless-debug err
            (apply fn args)
          (error (lgr-error rau--lgr "Error executing task %S with args %S: %S" fn args err)))))))

(defun rau--tasks-schedule-execution ()
  "Schedule task processing if not already scheduled."
  (unless (rau--fe-state-task-timer rau--fe-state)
    (setf (rau--fe-state-task-timer rau--fe-state)
          (run-at-time
           0 nil
           (lambda ()
             (setf (rau--fe-state-task-timer rau--fe-state) nil)
             (rau--tasks-execute))))))

(defun rau--tasks-enqueue (fn &rest args)
  "Queue FN with ARGS for execution by `rau--tasks-execute'.
Also schedule the task execution timer if not yet done so.  Only to be
used in event listeners."
  (push `(,fn . ,args) (rau--fe-state-task-queue rau--fe-state))
  (rau--tasks-schedule-execution))

(defun rau--good-new-frame-buffer-p (buffer)
  "Whether BUFFER is good to be shown as initial buffer in a new frame."
  (and (not (string-prefix-p " " (buffer-name buffer)))
       (not (with-current-buffer buffer (derived-mode-p 'rau-mode)))))

(defun rau--make-frame ()
  "Make frame for a new output that will not show a `rau-mode' buffer.
`make-frame' assigns the current buffer to the new frame.  So we need to
wrap it in a `with-current-buffer'."
  (let ((buffer (or (cl-find-if #'rau--good-new-frame-buffer-p (buffer-list))
                    (get-buffer-create "*scratch*"))))
    (with-current-buffer buffer
      (make-frame (rau--make-outputframe-parameters)))))

(defun rau--task-assign-emacs-frame (output-id)
  "Find initial frame or create one and set OUTPUT-ID in `frame-parameter'."
  (let ((emacs-frame
         (or
          ;; search the initial frame
          (cl-loop for f in (frame-list)
                   for name = (frame-parameter f 'name)
                   for is_rau_frame = (string-prefix-p "rau-frame-" name)
                   for is_assigned = (frame-parameter f 'rau--output-id)
                   if (and is_rau_frame (not is_assigned)) return f)
          (rau--make-frame))))
    (set-frame-parameter emacs-frame 'rau--output-id output-id))
  (rau--send-fe-ui-state))

(defun rau--task-consume-key-event (event needs-focus)
  "Forward EVENT to Emacs and setup to recover focus if NEEDS-FOCUS."
  (push (cons t event) unread-command-events)
  (when needs-focus
    (add-hook 'post-command-hook #'rau--recover-focus-after-binding-pressed)))

(defun rau--task-delete-frame (frame-id)
  "Delete frame by FRAME-ID."
  (lgr-info rau--lgr "task delete frame with frame-id %S" frame-id)
  (when-let* ((emacs-frame (frame-by-id frame-id)))
    (delete-frame emacs-frame)))

(defun rau--task-kill-buffer (window-id)
  "Remove kill inhibiting hook in buffer for WINDOW-ID and kill buffer."
  (when-let* ((buffer (rau--buffer-for-window-id window-id)))
    (with-current-buffer buffer
      (remove-hook 'kill-buffer-query-functions #'rau--buffer-killed t))
    (kill-buffer buffer)))

(defun rau--task-link-emacs-frame-to-window (title window-id)
  "Link Emacs frame with name TITLE to Wayland window with WINDOW-ID."
  (let ((emacs-frame
         (cl-find title (frame-list)
                  :test #'equal
                  :key (lambda (f) (frame-parameter f 'name)))))
    (unless emacs-frame
      (error "No Emacs frame found for wayland window: id=%d title=%s" window-id title))

    (set-frame-parameter emacs-frame 'rau--window-id window-id))
  (rau--send-fe-ui-state))

(defun rau--task-rename-buffer (window-id name)
  "Rename buffer for Wayland window with WINDOW-ID to NAME."
  (when-let* ((buffer (rau--buffer-for-window-id window-id)))
    (with-current-buffer buffer
      (rename-buffer name t))))

(defun rau--task-select-window (window-id)
  "Let Emacs select the underlying emacs-window for the external WINDOW-ID."
  (when-let* ((emacs-window (rau--emacs-window-for-window-id window-id)))
    (select-window emacs-window 'norecord)))

(defun rau--task-set-frame-position (frame-id position)
  "Set parameter rau--frame-position of frame FRAME-ID to (x . y) POSITION.
This can be used e.g. to have predictable numbering in ace-window.el."
  (when-let* ((frame (frame-by-id frame-id)))
    (set-frame-parameter frame 'rau--frame-position position)))

(defun rau--task-setup-new-external-window (window-id title)
  "Create and display Rau mode buffer with name TITLE for WINDOW-ID."
  (let* ((name (or title (make-temp-name "rau-external-")))
         (buffer (generate-new-buffer name)))
    (with-current-buffer buffer
      (rau-mode)
      (setq-local rau--window-id window-id)
      (unless (display-buffer buffer)
        (error "display-buffer failed for window %d buffer %S" window-id buffer)))))

;;; Keybindings

(defun rau--key-to-xkb (key-string)
  "Decompose KEY-STRING into (EVENT KEY MODIFIERS)."
  (let* ((event (aref (kbd key-string) 0))
         (basic (event-basic-type event))
         (mods (rau--modifiers-bitmap (event-modifiers event)))
         (key (if (characterp basic) basic (symbol-name basic))))
    (list event key mods)))

(defun rau--parse-keys (keys)
  "Parse KEYS into a list of rau--binding structs.  See `rau-bind-keys'."
  (let ((seen (make-hash-table :test #'equal))
        (result nil))
    (dolist (item keys)
      (let ((elements (if (stringp item) (list item) item))
            keys flags)
        (while-let ((elt (pop elements)))
          (cond
           ((stringp elt)
            (push elt keys))
           ((eq :layout elt)
            (unless elements
              (error ":layout requires a layout number"))
            (push (cons elt (pop elements)) flags))
           ((memq elt '(:needs-focus :allow-when-locked))
            (push (cons elt t) flags))
           ((keywordp elt)
            (error "Unknown flag %S" elt))
           (t
            (error "Unexpected element in key binding spec: %S" elt))))
        (dolist (key keys)
          (when (gethash key seen)
            (error "Duplicate key binding: %s" key))
          (puthash key t seen)
          (let ((xkb (rau--key-to-xkb key)))
            (push `(:event ,(cl-first xkb)
                   :key ,key
                   :keysym ,(rau--resolve-keysym (cl-second xkb))
                   :modifiers ,(cl-third xkb)
                   :needs-focus   ,(cdr (assq :needs-focus flags))
                   :allow-when-locked ,(cdr (assq :allow-when-locked flags))
                   :layout        ,(cdr (assq :layout flags)))
                  result)))))
    (nreverse result)))

(defvar rau--xkb-keysym-alist
  '(("iso-lefttab" . #xFE20)
    ("return" . #xFF0D)
    ("escape" . #xFF1B)
    ("backspace" . #xFF08)
    ("tab" . #xFF09)
    ("space" . #x020)
    ("delete" . #xFFFF)
    ("home" . #xFF50)
    ("left" . #xFF51)
    ("up" . #xFF52)
    ("right" . #xFF53)
    ("down" . #xFF54)
    ("prior" . #xFF55)
    ("pageup" . #xFF55)
    ("next" . #xFF56)
    ("pagedown" . #xFF56)
    ("end" . #xFF57)
    ("insert" . #xFF63)
    ("begin" . #xFF58)
    ("select" . #xFF60)
    ("print" . #xFF61)
    ("execute" . #xFF62)
    ("pause" . #xFF13)
    ("scroll" . #xFF14)
    ("sysrq" . #xFF15)
    ("f1" . #xFFBE)
    ("f2" . #xFFBF)
    ("f3" . #xFFC0)
    ("f4" . #xFFC1)
    ("f5" . #xFFC2)
    ("f6" . #xFFC3)
    ("f7" . #xFFC4)
    ("f8" . #xFFC5)
    ("f9" . #xFFC6)
    ("f10" . #xFFC7)
    ("f11" . #xFFC8)
    ("f12" . #xFFC9)
    ("xf86monbrightnessup"   . #x1008FF02)
    ("xf86monbrightnessdown" . #x1008FF03)
    ("audioraisevolume" . #x1008FF13)
    ("audiolowervolume" . #x1008FF11)
    ("audiomute"        . #x1008FF12)
    ("audioplay"        . #x1008FF14)
    ("audiostop"        . #x1008FF15)
    ("audiopause"       . #x1008FF31)
    ("audionext"        . #x1008FF17)
    ("audioprev"        . #x1008FF16)
    ("homepage"  . #x1008FF18)
    ("mail"      . #x1008FF19)
    ("search"    . #x1008FF1B)
    ("favorites" . #x1008FF30)
    ("launcha"   . #x1008FF52)
    ("explorer"  . #x1008FF5D)
    ("display"   . #x1008FF85)
    ("tools"     . #x1008FF89)
    ("wlan"      . #x1008FF95)
    ("audiomicmute" . #x1008FFB2))
  "Fallback table mapping key names to XKB keysyms.
See X11/XF86keysym.h.")

(defun rau--utf32-to-keysym (cp)
  "Convert Unicode codepoint CP to an XKB keysym."
  (cond
   ((not (integerp cp)) 0)
   ((and (>= cp #x20) (<= cp #x7e)) cp)
   ((and (>= cp #xa0) (<= cp #xff)) cp)
   ((> cp 0) (+ #x01000000 cp))
   (t 0)))

(defun rau--resolve-keysym (key)
  "Resolve KEY to an XKB keysym.
KEY may be an integer codepoint, a symbol, or a string key name."
  (cond
   ((integerp key)
    (rau--utf32-to-keysym key))

   ((symbolp key)
    (rau--resolve-keysym (symbol-name key)))

   ((stringp key)
    (or (and (length= key 1)
             (rau--utf32-to-keysym (aref key 0)))
        (alist-get (downcase key)
                   rau--xkb-keysym-alist
                   nil nil #'equal)
        (user-error "Could not resolve %s to an XKB keysym" key)))
   (t (error "Key should be an integer, symbol or string"))))

(defun rau-bind-keys (keys)
  "Bind KEYS to always be sent to Emacs.
KEYS is a list either of strings acceptable to `kbd' or of lists of
strings and one or more of the following keywords:

- :allow-when-locked - keys are also active when the session is locked,
   e.g. Volume or Brightness control
- :needs-focus - focus should be temporarily given to Emacs
- :layout LAYOUT-NR - 0 indexed layout override

Example:

\(\"s\-e\" \"\s\-f\"
  (\"s\-d\" \"C\-h\" :needs-focus)
  (:allow-when-locked \"M-x\" :needs-focus)
  (:allow-when-locked \"s-c\" \"s-z\" :layout 2))

This function should be run from the `rau-ready-hook'."
  ;; TODO: check whether Rau has already been started
  (let ((parsed-keys (rau--parse-keys keys)))
    (rau--be #'rau--bind-parsed-keys parsed-keys)))

(defun rau--save-delete-frame ()
  "Save replacement for C\-x 5 0 binding to avoid deleting rau frames."
  (interactive)
  (let ((frame (selected-frame)))
    (if (or (frame-parameter frame 'rau--window-id)
            (frame-parameter frame 'rau--output-id))
        (user-error "Must not delete rau frame")
      (delete-frame))))

(defun rau--global-unset-key-if (key command &optional new-command)
  "Unset KEY if it is currently bound to COMMAND or set it to NEW-COMMAND."
  (when (eq command (keymap-global-lookup key))
    (if new-command
        (keymap-global-set key new-command)
      (keymap-global-unset key))))

;;; Emacs handler functions for hooks

(defun rau--focus-change-allowed-p ()
  "Non-nil when no interactive command or edit is in progress."
  (and (not this-command)
       (length= unread-command-events 0)
       (length= (this-single-command-keys) 0)
       (zerop (minibuffer-depth))
       (zerop (recursion-depth))))

(defun rau--update-focus-request (&rest args)
  "Reconcile Wayland focus with the selected window, ignores ARGS."
  (lgr-debug rau--lgr "update-focus-request %S" args)
  (when-let* (((rau--focus-change-allowed-p))
              (emacs-window (selected-window))
              (target-id (rau--window-id-for-emacs-window emacs-window)))
    (rau--be #'rau--request-focus target-id)))

(defun rau--recover-focus-after-binding-pressed ()
  "Recover focus after it was given to Emacs to handle a keybinding."
  (lgr-debug rau--lgr "recover focus. not t-c=%S u-c-e=%d t-s-c-k=%d m-d=%d r-d=%d"
             (not this-command)
             (length unread-command-events)
             (length (this-single-command-keys))
             (minibuffer-depth)
             (recursion-depth))
  (when (and (length= unread-command-events 0)
             (zerop (minibuffer-depth))
             (zerop (recursion-depth)))
    (lgr-debug rau--lgr "recover focus. removing post-command-hook.")
    (remove-hook 'post-command-hook #'rau--recover-focus-after-binding-pressed)
    (when-let* ((window-id (buffer-local-value 'rau--window-id (current-buffer))))
      (rau--be #'rau--request-focus window-id))))

(defun rau--buffer-killed ()
  "Request closing of the associated Wayland window when a rau buffer is killed."
  (when rau--window-id
    (rau--be #'rau--manage-enqueue rau--window-id 'close)
    nil))

(defun rau--window-configuration-change-handler ()
  "Schedule a river manage cycle and thus a reconciliation cycle.
This is necessary for external windows to resize when the minibuffer
expands.  This needs to be added to the global hook since local hooks
don't get called for windows that disappear.  Also
`window-size-change-functions' does not get called when minibuffer
expands and thus minibuffer ends up below external window."
  (rau--be #'rau--mark-manage-dirty))

(defun rau--buffer-predicate (buffer)
  "Avoid showing a rau BUFFER."
  (or (not (with-current-buffer buffer (derived-mode-p 'rau-mode)))
      (not (get-buffer-window buffer t))))

(defun rau--initial-frame-buffer (frame)
  "Set initial buffer for FRAME in `after-make-frame-functions' hook."
  (lgr-trace rau--lgr "init frame buffer frame-id=%S"
             (frame-id frame))
  (dolist (window (window-list frame 'no-minibuffer))
    (when-let* ((current-buffer (window-buffer window))
                ((with-current-buffer current-buffer
                   (derived-mode-p 'rau-mode)))
                (new-buffer (other-buffer current-buffer t)))
      (lgr-trace rau--lgr "switching initial-frame buffer to %S" (buffer-name new-buffer))
      (set-window-buffer window new-buffer))))

(defun rau-toggle-fullscreen ()
  "Toggle fullscreen for the currently focused external window."
  (interactive)
  (if-let* ((window-id (buffer-local-value 'rau--window-id (current-buffer))))
      (rau--be #'rau--toggle-fullscreen-by-window-id window-id)
    (message "Fullscreen requested, but nothing is focused")))

;;; fe-state

(defun rau--fe-ui-state ()
  "Build ui-state data to be sent to the backend."
  (let* (frames wins)
    (dolist (f (frame-list))
      (let ((offset (+ (* rau-tool-bar-height (frame-parameter f 'tool-bar-lines))
                       (* rau-menu-bar-height (frame-parameter f 'menu-bar-lines))))
            (frame-id (frame-id f))
            (window-id (frame-parameter f 'rau--window-id))
            (output-id (frame-parameter f 'rau--output-id)))
        (when (or window-id output-id)
          (push `[,frame-id ,window-id ,output-id] frames))
        (dolist (w (window-list f 'no-minibuffer))
          (when-let* ((buffer (window-buffer w))
                      (window-id (buffer-local-value 'rau--window-id buffer)))
            (pcase-let* ((edges (window-inside-absolute-pixel-edges w))
                         (`(,left ,top ,right ,bottom) edges)
                         (position `(,left . ,(+ top offset)))
                         (dimensions-override (and (buffer-local-boundp 'rau--dimensions buffer)
                                                (buffer-local-value 'rau--dimensions buffer)))
                         (dimensions (or dimensions-override
                                         `(,(- right left) . ,(- bottom top)))))
              (push `[,window-id ,frame-id ,position ,dimensions] wins))))))
    `[,(sort frames) ,(sort wins)]))

(defun rau--send-fe-ui-state ()
  "Send UI-state data to the backend."
  (let ((new-state (rau--fe-ui-state))
        (last-state (rau--fe-state-last-send-state rau--fe-state)))
    (if (equal new-state last-state)
        (lgr-trace rau--lgr "new-state and last-state equal, not sending.")
      (rau--be #'rau--update-fe-ui-state new-state)
      (setf (rau--fe-state-last-send-state rau--fe-state) new-state))))

(defun rau--window-state-change-handler ()
  "Update UI-state and focus any time Emacs window configuration changes."
  (rau--send-fe-ui-state)
  (rau--update-focus-request)

  ;; Schedule a river manage cycle and thus a reconciliation cycle.
  ;; This is necessary for external windows to resize when the minibuffer
  ;; expands.  This needs to be added to the global hook since local hooks
  ;; don't get called for windows that disappear.  Also
  ;; window-size-change-functions does not get called when minibuffer expands
  ;; and thus minibuffer ends up below external window.
  (rau--be #'rau--mark-manage-dirty))

;;; Startup

;; NOTE: No need for rau-disable since this Emacs process is serving as a
;; Window Manager and disabling rau while keeping the Emacs process running
;; would result in an unresponsive user environment.
;;;###autoload
(defun rau-enable ()
  "Enable the rau window manager for river.
Call this function once when starting Emacs inside of river."
  (unless (eq window-system 'pgtk)
    (user-error "Rau requires a pgtk Emacs on Wayland"))

  (when rau--fe-state
    (user-error "Rau is already running"))
  (setq rau--fe-state (rau--fe-state-make))

  (unless confirm-kill-emacs
    (setq confirm-kill-emacs #'yes-or-no-p))
  (rau--global-unset-key-if "C-x C-c" 'save-buffers-kill-terminal)
  (rau--global-unset-key-if "C-z" 'suspend-frame)
  (rau--global-unset-key-if "C-x C-z" 'suspend-frame)
  (rau--global-unset-key-if "C-x 5 0" 'delete-frame #'rau--save-delete-frame)

  (message "Launching rau (pure Elisp) ...")
  (unless (= 1 (length (frame-list)))
    (user-error "There should be exactly one frame when starting Rau"))

  (modify-frame-parameters nil (rau--make-outputframe-parameters))

  (rau--rpc-start-backend)

  (add-hook 'window-state-change-hook #'rau--window-state-change-handler)
  (add-hook 'after-make-frame-functions #'rau--initial-frame-buffer))

;;; RPC State

(defun rau--make-be-server-name (&optional number)
  "Create unique `server-name' for the Rau backend server.
Iterates recursively with NUMBER + 1. Multiple Rau backend servers
happen mostly during development.  This function assumes that
`server-socket-dir' will be the same in the backend Emacs instance!"
  (let* ((number (or number 1))
         (server-name (format "rau-backend-%d" number))
         (server-file (expand-file-name server-name server-socket-dir)))
    (if (file-exists-p server-file)
        (rau--make-be-server-name (+ 1 number))
      server-name)))

(defun rau--wait-for-file (path interval times)
  "Wait for PATH to exist TIMES x INTERVAL before raising an error."
  (let ((count 0))
    (while (and (not (file-exists-p path))
                (< count times))
      (cl-incf count)
      (sleep-for interval))
    (lgr-debug rau--lgr "Waited %d x %.2f seconds for %s" count interval path)
    (unless (file-exists-p path)
      (error "File did not show up: %s" path))))

(defun rau--rpc-start-backend ()
  "Start the rau backend subprocess and connect via Unix socket."
  ;; TODO create socket in users run dir
  (let* ((sock-file
          (make-temp-name
           (expand-file-name "rau--backend-internal-"
                             server-socket-dir)))
         (be-server-name (rau--make-be-server-name))
         (coding-system-for-read 'utf-8-emacs-unix)
         (coding-system-for-write 'utf-8-emacs-unix)
         (init-file-args (when rau-backend-init-file
                           (unless (file-readable-p rau-backend-init-file)
                             (error "Not readable rau-backend-init-file: %S" rau-backend-init-file))
                           `("-l" ,rau-backend-init-file)))
         (command `(,(expand-file-name invocation-name invocation-directory)
                    "-Q"
                    ,(format "--fg-daemon=%s" be-server-name) ; race-condition
                    "-l" ,(locate-library "ewc")
                    "-l" ,(locate-library "rau-lib")
                    "-l" ,(locate-library "rau-be")
                    ,@init-file-args
                    "--eval=(rau-be-main)"
                    ,sock-file)))
    (make-process :name "rau-backend"
                  :command command
                  :buffer " *rau-backend-stdout*"
                  :noquery t
                  :stderr " *rau-backend-stderr*")
    (rau--wait-for-file sock-file 0.1 30)
    (rau--rpc-connect sock-file)
    ;; The Emacs subprocess probably gets killed and might not have time to
    ;; clean up the socket. Ignore error in case the subprocess did actually
    ;; delete the file.
    (add-hook 'kill-emacs-hook
              (lambda () (ignore-error file-error (delete-file sock-file))))))

(provide 'rau)
;;; rau.el ends here
