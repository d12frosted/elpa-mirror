(define-package "base16-theme" "20220709.727" "Collection of themes built on combinations of 16 base colors" 'nil :commit "310d0a966f9120997c80476c42043c1023f835e2" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/base16-project/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
