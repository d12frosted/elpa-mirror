;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251118.1038"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "3ddb82b37bb76692c00be8727563ed004ffb4e3f"
  :revdesc "3ddb82b37bb7"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
