;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20260828.809"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "100f98b6194dfc1eb868fbbff0a6f874a44c7131"
  :revdesc "100f98b6194d"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
