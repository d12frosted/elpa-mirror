;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-essential-ref" "20221215.1427"
  "Cider-doc to \"Clojure, The Essential Reference\"."
  '((emacs "24")
    (cider "0.24.0"))
  :url "https://github.com/p3r7/clojure-essential-ref"
  :commit "6741bf65cf9b9bc896ab1cc3c384573e8ffe5f96"
  :revdesc "6741bf65cf9b")
