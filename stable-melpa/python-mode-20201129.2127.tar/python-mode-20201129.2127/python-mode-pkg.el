(define-package "python-mode" "20201129.2127" "Python major mode" 'nil :commit "0c8835ccf9cba221ef1a95bc45659eeab9a79c24")
;; Local Variables:
;; no-byte-compile: t
;; End:
