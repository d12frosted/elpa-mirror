(define-package "dirvish" "20220813.1233" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "ec1650a82c24c2c45fda56f96092cd7e898f69e8" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
