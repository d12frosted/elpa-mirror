;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260820.310"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "617ac49c15e0caa7310ad7c13525a9b8639c4005"
  :revdesc "617ac49c15e0"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
