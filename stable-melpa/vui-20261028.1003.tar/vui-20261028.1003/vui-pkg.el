;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261028.1003"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "6a933489bc60c254ddb15c14b5c9b53426fc409a"
  :revdesc "6a933489bc60"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
