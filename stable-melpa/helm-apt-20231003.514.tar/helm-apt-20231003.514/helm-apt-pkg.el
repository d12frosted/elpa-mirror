(define-package "helm-apt" "20231003.514" "Helm interface for Debian/Ubuntu packages (apt-*)"
  '((helm "3.9.5")
    (emacs "25.1"))
  :commit "f020465c18908efe00807e1e0f828a3766fc6916" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://github.com/emacs-helm/helm-apt")
;; Local Variables:
;; no-byte-compile: t
;; End:
