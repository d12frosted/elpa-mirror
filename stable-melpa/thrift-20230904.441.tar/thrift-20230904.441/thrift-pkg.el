(define-package "thrift" "20230904.441" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "f953c648861dd6bc6a81bff7a9505dd5998afea8" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
