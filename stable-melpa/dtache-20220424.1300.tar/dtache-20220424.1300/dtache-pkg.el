(define-package "dtache" "20220424.1300" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "aee3289eb1e1c3c31ca2f9a4f5323aeb4feed262" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
