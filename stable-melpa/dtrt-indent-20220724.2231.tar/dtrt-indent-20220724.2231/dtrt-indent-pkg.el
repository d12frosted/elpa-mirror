(define-package "dtrt-indent" "20220724.2231" "Adapt to foreign indentation offsets" 'nil :commit "397ca8e244dc57ee9583815d30fc3fbbb0dfac3d" :authors
  '(("Julian Scheid" . "julians37@googlemail.com"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("convenience" "files" "languages" "c"))
;; Local Variables:
;; no-byte-compile: t
;; End:
