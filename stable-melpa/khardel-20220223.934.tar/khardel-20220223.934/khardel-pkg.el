(define-package "khardel" "20220223.934" "Integrate with khard"
  '((emacs "27.1")
    (yaml-mode "0.0.13"))
  :commit "1436ec5ef1b5b26104a4735ee64c0afe148700de" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://github.com/DamienCassou/khardel")
;; Local Variables:
;; no-byte-compile: t
;; End:
