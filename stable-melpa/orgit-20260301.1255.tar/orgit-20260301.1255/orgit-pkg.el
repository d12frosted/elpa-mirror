;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260301.1255"
  "Support for Org links to Magit buffers."
  '((emacs    "28.1")
    (compat   "30.1")
    (cond-let "0.2")
    (magit    "4.5")
    (org      "9.7"))
  :url "https://github.com/magit/orgit"
  :commit "4fb91faff3bf32dac5f6f932654c280cd1f190f7"
  :revdesc "4fb91faff3bf"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
