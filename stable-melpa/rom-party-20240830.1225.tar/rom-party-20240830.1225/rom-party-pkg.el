(define-package "rom-party" "20240830.1225" "Rendition of jklm.fun's \"Bomb Party\" game"
  '((emacs "28")
    (dash "2.17.0")
    (f "0.2.0")
    (s "1.12.0")
    (ht "2.3")
    (extmap "1.3")
    (compat "29.1.4.4")
    (async "1.9.7"))
  :commit "60da757070d23c5f33b89b787ee01a280539c4f1" :url "https://github.com/LaurenceWarne/rom-party.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
