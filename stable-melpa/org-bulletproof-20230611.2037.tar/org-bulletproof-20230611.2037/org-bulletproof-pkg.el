(define-package "org-bulletproof" "20230611.2037" "Automatic plain list bullet cycling"
  '((emacs "27.1"))
  :commit "c9d09ff91a8d637ad8c2975bc39288a0e26c98ec" :authors
  '(("Pontus Andersson" . "pondersson@gmail.com"))
  :maintainers
  '(("Pontus Andersson" . "pondersson@gmail.com"))
  :maintainer
  '("Pontus Andersson" . "pondersson@gmail.com")
  :keywords
  '("outlines" "convenience")
  :url "https://github.com/pondersson/org-bulletproof")
;; Local Variables:
;; no-byte-compile: t
;; End:
