;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260213.1730"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "c7767d6a9e6afe967edd60c8e48c77dba4b0a571"
  :revdesc "c7767d6a9e6a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
