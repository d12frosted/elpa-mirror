;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "download-region" "20210306.415"
  "Simple in-buffer download manager."
  '((cl-lib "0.3"))
  :url "http://zk-phi.github.io/"
  :commit "e0a721858a22896fa1d7f1d5689dd0878dbc58fa"
  :revdesc "e0a721858a22")
