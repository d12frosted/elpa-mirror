(define-package "geiser" "20211203.329" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "8c2fcf6b8a072f6fe896178747119766c6609dd0" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
