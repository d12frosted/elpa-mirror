;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20250420.642"
  "Enchanted Spell Checker."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "eef32c319a0625c287c3c9eaac0326204fa314b1"
  :revdesc "eef32c319a06"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
