;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260409.653"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "90aaaede809fa32167507032cddf1fbe769dcd7d"
  :revdesc "90aaaede809f"
  :keywords '("comm"))
