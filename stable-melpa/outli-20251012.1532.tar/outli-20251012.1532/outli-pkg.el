;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outli" "20251012.1532"
  "Org-like code outliner."
  '((emacs "27.1"))
  :url "https://github.com/jdtsmith/outli"
  :commit "739bd8434ed376d2dd0bf8cd3dc3083e74d53f5b"
  :revdesc "739bd8434ed3"
  :keywords '("convenience" "outlines" "org")
  :authors '(("J.D. Smith" . "jdtsmith@gmail.com"))
  :maintainers '(("J.D. Smith" . "jdtsmith@gmail.com")))
