;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auth-source-gopass" "20230109.1213"
  "Gopass integration for auth-source."
  '((emacs "24.4"))
  :url "https://github.com/"
  :commit "6f7f0cc0d682f66d11f7fac4fa5c1e79904232da"
  :revdesc "6f7f0cc0d682"
  :authors '(("Markus M. May" . "mmay@javafreedom.org"))
  :maintainers '(("Markus M. May" . "mmay@javafreedom.org")))
