;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "history" "20160821.1602"
  "History utility for source code navigation."
  '((emacs "24.3"))
  :url "https://github.com/boyw165/history"
  :commit "5317663fb45bbd5e96d258cb0807dcc266ce67ff"
  :revdesc "5317663fb45b")
