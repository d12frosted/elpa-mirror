;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iedit" "20251013.1148"
  "Edit multiple regions in the same way simultaneously."
  ()
  :url "https://github.com/victorhge/iedit"
  :commit "b4bffe2abbd021c6fd3f2e361ca89dd211080b1d"
  :revdesc "b4bffe2abbd0"
  :keywords '("occurrence" "region" "simultaneous" "refactoring")
  :authors '(("Victor Ren" . "victorhge@gmail.com"))
  :maintainers '(("Victor Ren" . "victorhge@gmail.com")))
