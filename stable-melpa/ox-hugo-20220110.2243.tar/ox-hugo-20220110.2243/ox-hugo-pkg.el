(define-package "ox-hugo" "20220110.2243" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "79257479725c96100ef2b810ce877715ea1f7afa" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
