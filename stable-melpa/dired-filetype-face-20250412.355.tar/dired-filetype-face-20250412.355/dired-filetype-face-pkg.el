;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-filetype-face" "20250412.355"
  "Set different faces for different filetypes in dired."
  ()
  :url "https://github.com/jixiuf/dired-filetype-face"
  :commit "e05fe6b6686ce684ea28d5460beda3bb89d106a2"
  :revdesc "e05fe6b6686c"
  :keywords '("dired" "filetype" "face")
  :authors '((nil . "jixiufatgmaildotcom"))
  :maintainers '((nil . "jixiufatgmaildotcom")))
