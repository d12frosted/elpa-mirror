;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260224.1606"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "feb32c92a2197251e65c8c2d5efb438a2e052ebd"
  :revdesc "feb32c92a219"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
