;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-emoji" "20260218.1141"
  "Select emojis with Helm."
  '((emacs "29.1")
    (helm  "3.9.6"))
  :url "https://codeberg.org/timmli/helm-emoji"
  :commit "4c125d3fc42fad0576ff653c0a45ee265498a2c6"
  :revdesc "4c125d3fc42f"
  :keywords '("matching")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
