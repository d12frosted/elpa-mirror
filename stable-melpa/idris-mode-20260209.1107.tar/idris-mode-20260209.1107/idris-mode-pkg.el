;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idris-mode" "20260209.1107"
  "Major mode for editing Idris code."
  '((emacs     "24")
    (prop-menu "0.1")
    (cl-lib    "0.5"))
  :url "https://github.com/idris-hackers/idris-mode"
  :commit "d32b2396a8ad17820e308cd267f1b464a5235abc"
  :revdesc "d32b2396a8ad"
  :keywords '("languages"))
