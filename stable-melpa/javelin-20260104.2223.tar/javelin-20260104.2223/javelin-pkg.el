;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "javelin" "20260104.2223"
  "Implementation of harpoon: bookmarks on steroids."
  '((emacs "28.1"))
  :url "https://github.com/DamianB-BitFlipper/javelin.el"
  :commit "1fe2c9d01fa5b71f54d5528bf81faa2d47834c21"
  :revdesc "1fe2c9d01fa5"
  :keywords '("tools" "languages"))
