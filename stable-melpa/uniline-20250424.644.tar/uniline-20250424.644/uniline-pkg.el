;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20250424.644"
  "Add UNICODE based diagrams to text files."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "c6fdeb07efabb546cbb6ae77d3888ba8c36f7a6c"
  :revdesc "c6fdeb07efab"
  :keywords '("convenience" "text"))
