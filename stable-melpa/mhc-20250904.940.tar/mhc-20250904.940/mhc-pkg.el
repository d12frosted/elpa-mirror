;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mhc" "20250904.940"
  "Message Harmonized Calendaring system."
  '((calfw "20150703"))
  :url "http://www.quickhack.net/mhc"
  :commit "2e5e6260363744f124bd0ca22ac7d5962e32fd87"
  :revdesc "2e5e62603637"
  :keywords '("calendar")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
