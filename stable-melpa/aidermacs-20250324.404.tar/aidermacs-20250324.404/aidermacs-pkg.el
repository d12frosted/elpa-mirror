;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250324.404"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "9c8806258e1935238c4e72a3f58af0aa58ad8150"
  :revdesc "9c8806258e19"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
