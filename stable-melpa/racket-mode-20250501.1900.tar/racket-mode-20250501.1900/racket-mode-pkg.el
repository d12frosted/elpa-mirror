;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "racket-mode" "20250501.1900"
  "Racket editing, REPL, and more."
  '((emacs "25.1"))
  :url "https://www.racket-mode.com/"
  :commit "2eec63cd62bacf6d6b09bcc09e601265c36d165f"
  :revdesc "2eec63cd62ba"
  :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")))
