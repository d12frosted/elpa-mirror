;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lambdapi-mode" "20260423.1057"
  "A major mode for editing Lambdapi source code."
  '((emacs             "27.1")
    (eglot             "1.6")
    (math-symbol-lists "1.2.1")
    (highlight         "20190710.1527"))
  :url "https://github.com/Deducteam/lambdapi"
  :commit "fbbe050639dfe7c1c1f2be2e6807dd31e3108e5e"
  :revdesc "fbbe050639df"
  :keywords '("languages")
  :maintainers '(("Deducteam" . "dedukti-dev@inria.fr")))
