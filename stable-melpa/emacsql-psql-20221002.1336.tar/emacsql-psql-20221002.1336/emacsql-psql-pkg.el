(define-package "emacsql-psql" "20221002.1336" "EmacSQL back-end for PostgreSQL via psql"
  '((emacs "25.1")
    (emacsql "2.0.0"))
  :commit "5c4aa1030be157229cdccd6b11cb30ca94cda954" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
