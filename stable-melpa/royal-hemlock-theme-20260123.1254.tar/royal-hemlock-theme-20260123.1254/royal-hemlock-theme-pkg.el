;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "20260123.1254"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "8a4d85a7029866540db5261b33b20223374f26ac"
  :revdesc "8a4d85a70298"
  :keywords '("color" "theme" "faces"))
