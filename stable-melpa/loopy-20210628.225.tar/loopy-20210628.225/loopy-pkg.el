(define-package "loopy" "20210628.225" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "f955073c4710ba5b963dea25d8a9f5b2e7183fcd" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
