;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260105.316"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "2173cd58e3a53ff69ef06932ad2dec9f1b714454"
  :revdesc "2173cd58e3a5"
  :keywords '("extensions"))
