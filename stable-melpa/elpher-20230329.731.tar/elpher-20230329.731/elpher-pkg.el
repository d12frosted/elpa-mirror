(define-package "elpher" "20230329.731" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "31641d57f7bb95c8a8903a8d2c7ac8104603b7c4" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
