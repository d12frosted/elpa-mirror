;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mime" "20251128.525"
  "Org html export for text/html MIME emails."
  '((emacs "27.1"))
  :url "http://github.com/org-mime/org-mime"
  :commit "0019f24479535fa7122d14418fc7c5fef11af090"
  :revdesc "0019f2447953"
  :keywords '("mime" "mail" "email" "html")
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
