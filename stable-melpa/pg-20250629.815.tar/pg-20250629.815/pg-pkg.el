;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20250629.815"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "365da3f723b6d7d207704026d4c31046df51e5c7"
  :revdesc "365da3f723b6"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
