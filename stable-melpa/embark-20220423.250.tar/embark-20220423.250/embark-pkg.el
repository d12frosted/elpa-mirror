(define-package "embark" "20220423.250" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "9bf01e1c1d554150a7e0ec07f0dc6892295a51dd" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
