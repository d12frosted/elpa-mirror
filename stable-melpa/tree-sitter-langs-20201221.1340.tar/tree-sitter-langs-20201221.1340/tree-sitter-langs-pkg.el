(define-package "tree-sitter-langs" "20201221.1340" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.12.2"))
  :commit "4c46854b716e9efee62df3d794b3a10313525f0b" :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
