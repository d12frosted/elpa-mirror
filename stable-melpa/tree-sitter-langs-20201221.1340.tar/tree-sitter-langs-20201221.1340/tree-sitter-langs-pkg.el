(define-package "tree-sitter-langs" "20201221.1340" "Grammar bundle for tree-sitter"
  '((emacs "25.1")
    (tree-sitter "0.12.2"))
  :commit "a7036676de3ba35b93346f5325ed568240c1ef58" :authors
  (("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  ("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  ("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
