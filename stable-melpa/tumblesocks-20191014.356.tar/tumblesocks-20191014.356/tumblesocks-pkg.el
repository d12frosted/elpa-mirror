(define-package "tumblesocks" "20191014.356" "An Emacs tumblr client."
  '((htmlize "1.39")
    (oauth "1.0.3")
    (markdown-mode "1.8.1"))
  :commit "0e4c3847e31a59d405b9927107a23dde9531d744")
;; Local Variables:
;; no-byte-compile: t
;; End:
