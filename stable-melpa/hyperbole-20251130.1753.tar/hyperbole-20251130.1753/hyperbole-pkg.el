;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251130.1753"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "b860a75af4cf568806c1de062b37511cae7de3a9"
  :revdesc "b860a75af4cf"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
