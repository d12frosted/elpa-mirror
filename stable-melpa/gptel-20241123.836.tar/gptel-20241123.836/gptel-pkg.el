;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241123.836"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "9f820215902e080e7a32115c090277068a4caaa6"
  :revdesc "9f820215902e"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
