;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20261015.1933"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "d239a3c3b8cd9a7210169bb7dd50c94fccfb95c6"
  :revdesc "d239a3c3b8cd"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
