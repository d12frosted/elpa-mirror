;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flywrite" "20260325.151"
  "Inline writing suggestions via LLM."
  '((emacs "29.1"))
  :url "https://github.com/awdeorio/flywrite"
  :commit "223d3f6eb5804a3fe5978851ee431896591796ae"
  :revdesc "223d3f6eb580"
  :keywords '("text" "wp")
  :authors '(("Andrew DeOrio" . "awdeorio@umich.edu"))
  :maintainers '(("Andrew DeOrio" . "awdeorio@umich.edu")))
