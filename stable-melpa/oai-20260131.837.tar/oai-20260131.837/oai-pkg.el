;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260131.837"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "48e74e6c6d7d2ba714dacdddb84566e5629b360e"
  :revdesc "48e74e6c6d7d"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
