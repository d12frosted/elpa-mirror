;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-ascii-plot" "20260111.1140"
  "Unicode-art bar plots in org-mode tables."
  ()
  :url "https://github.com/tbanel/orgtblasciiplot"
  :commit "56d27e6ab021d8aad59372480d4eaedb19850c2d"
  :revdesc "56d27e6ab021"
  :keywords '("org" "table" "ascii" "plot"))
