;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verilog-ts-mode" "20260225.1302"
  "Verilog Tree-sitter major mode."
  '((emacs        "29.1")
    (verilog-mode "2024.3.1.121933719"))
  :url "https://github.com/gmlarumbe/verilog-ts-mode"
  :commit "a804a3e8b744edeaf879705c85aae196f761cba8"
  :revdesc "a804a3e8b744"
  :keywords '("systemverilog" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
