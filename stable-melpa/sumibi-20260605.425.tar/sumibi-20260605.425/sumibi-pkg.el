;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20260605.425"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (markdown-mode  "2.0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "1f80d06f0ac3a31e2370f8cd8eb5eaf4e9022f00"
  :revdesc "1f80d06f0ac3"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
