(define-package "meow" "20211224.1138" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "7244c32cde623bc92c508436e217a8d3082e3d03" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
