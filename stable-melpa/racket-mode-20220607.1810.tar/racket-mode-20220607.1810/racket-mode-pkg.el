(define-package "racket-mode" "20220607.1810" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "1c88636d5da4537b897e7b9b23edfd9495a24d10" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
