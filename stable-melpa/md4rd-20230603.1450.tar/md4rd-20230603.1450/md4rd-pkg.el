(define-package "md4rd" "20230603.1450" "Mode for reddit (browse it)."
  '((emacs "25.1")
    (hierarchy "0.7.0")
    (request "0.3.0")
    (cl-lib "0.6.1")
    (dash "2.12.0")
    (s "1.12.0")
    (tree-mode "1.0.0"))
  :commit "9f649e9b014438ad2289e6194a20c5f719e4fe8a" :authors
  '(("Matthew Carter" . "m@ahungry.com"))
  :maintainers
  '(("Matthew Carter" . "m@ahungry.com"))
  :maintainer
  '("Matthew Carter" . "m@ahungry.com")
  :keywords
  '("ahungry" "reddit" "browse" "news")
  :url "https://github.com/ahungry/md4rd")
;; Local Variables:
;; no-byte-compile: t
;; End:
