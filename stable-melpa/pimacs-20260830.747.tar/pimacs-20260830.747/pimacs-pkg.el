;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260830.747"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "dea4cb9d6c5b06bc32a2d53450bc811f6d9f896c"
  :revdesc "dea4cb9d6c5b"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
