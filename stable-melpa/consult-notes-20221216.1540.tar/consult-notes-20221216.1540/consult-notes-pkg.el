(define-package "consult-notes" "20221216.1540" "Manage notes with consult"
  '((emacs "27.1")
    (consult "0.17")
    (s "1.12.0")
    (dash "2.19"))
  :commit "d3781991611f325c24c2ca00d0691a2c35092489" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience")
  :url "https://github.com/mclear-tools/consult-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
