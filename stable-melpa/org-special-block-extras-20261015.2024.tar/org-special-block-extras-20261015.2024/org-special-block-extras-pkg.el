;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20261015.2024"
  "30 new custom blocks & 34 link types for Org-mode."
  '((s     "1.13.1")
    (dash  "2.18.1")
    (emacs "27.1")
    (org   "9.6")
    (lf    "26.10.1")
    (seq   "2.0"))
  :url "https://alhassy.github.io/org-special-block-extras"
  :commit "4dd9c9e5bed8967c624ae0eab0cdb451de4ad082"
  :revdesc "4dd9c9e5bed8"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
