;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rg" "20251021.2204"
  "A search tool based on ripgrep."
  '((emacs     "26.1")
    (transient "0.9.2")
    (wgrep     "2.1.10"))
  :url "https://github.com/dajva/rg.el"
  :commit "5f9cac413efc9aa14a5c0090775efffc286c3f25"
  :revdesc "5f9cac413efc"
  :keywords '("matching" "tools")
  :authors '(("David Landell" . "david.landell@sunnyhill.email")
             ("Roland McGrath" . "roland@gnu.org"))
  :maintainers '(("David Landell" . "david.landell@sunnyhill.email")
                 ("Roland McGrath" . "roland@gnu.org")))
