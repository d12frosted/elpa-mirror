;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241205.1624"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.74.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "d26534b601c916225f1cbdf3eca0b7ccae5d8d96"
  :revdesc "d26534b601c9")
