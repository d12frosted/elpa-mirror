;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260513.2052"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "fe4abec2c55a1f4a7bc6a8ff22ab564608e5af3a"
  :revdesc "fe4abec2c55a"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
