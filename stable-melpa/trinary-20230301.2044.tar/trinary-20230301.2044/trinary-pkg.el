(define-package "trinary" "20230301.2044" "Trinary logic"
  '((emacs "24"))
  :commit "d4869d260f22d13a9a71327a6d40edc6980d022e" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/emacs-elsa/trinary-logic")
;; Local Variables:
;; no-byte-compile: t
;; End:
