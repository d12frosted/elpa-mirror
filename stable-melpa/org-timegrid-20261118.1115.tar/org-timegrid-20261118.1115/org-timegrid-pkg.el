;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261118.1115"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "dadd3bbb50082988be5bb2271366b36554b3c484"
  :revdesc "dadd3bbb5008"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
