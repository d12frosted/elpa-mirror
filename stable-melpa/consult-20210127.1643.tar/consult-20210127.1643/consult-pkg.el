(define-package "consult" "20210127.1643" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "65a9814ffb47bcdb67459df0d6cace7395371020" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
