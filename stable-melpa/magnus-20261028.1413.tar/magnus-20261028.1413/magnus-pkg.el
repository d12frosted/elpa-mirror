;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20261028.1413"
  "Manage multiple AI coding agents."
  '((emacs         "28.1")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (magit-section "3.3.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "65164f9e108bd2c87cb98574c9933d6071495e6b"
  :revdesc "65164f9e108b"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
