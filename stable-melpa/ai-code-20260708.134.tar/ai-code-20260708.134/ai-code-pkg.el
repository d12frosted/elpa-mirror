;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260708.134"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "83b1b12065288a08d5dd00f0df48ea1d11564628"
  :revdesc "83b1b1206528"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
