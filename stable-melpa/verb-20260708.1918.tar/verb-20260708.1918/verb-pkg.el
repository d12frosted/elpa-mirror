;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "verb" "20260708.1918"
  "Organize and send HTTP requests."
  '((emacs "26.3"))
  :url "https://github.com/federicotdn/verb"
  :commit "ef09a5804cac4816ca9a0d1fb9c71c8ed3d3df8f"
  :revdesc "ef09a5804cac"
  :keywords '("tools")
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
