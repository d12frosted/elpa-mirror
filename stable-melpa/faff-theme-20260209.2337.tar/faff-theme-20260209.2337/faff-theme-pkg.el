;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20260209.2337"
  "Light Emacs color theme on cornsilk3 background."
  ()
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "216b52467e2fbbc61b746c28b5d0bc001345a8eb"
  :revdesc "216b52467e2f"
  :keywords '("color" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
