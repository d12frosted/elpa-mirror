(define-package "elfeed-protocol" "20230926.557" "Provide fever/newsblur/owncloud/ttrss protocols for elfeed"
  '((emacs "24.4")
    (elfeed "2.1.1")
    (cl-lib "0.5"))
  :commit "0fbbfddf316e2b748aa1deed0d9f7b3c9b55fdf9" :authors
  '(("Xu Fasheng <fasheng[AT]fasheng.info>"))
  :maintainers
  '(("Xu Fasheng <fasheng[AT]fasheng.info>"))
  :maintainer
  '("Xu Fasheng <fasheng[AT]fasheng.info>")
  :keywords
  '("news")
  :url "https://github.com/fasheng/elfeed-protocol")
;; Local Variables:
;; no-byte-compile: t
;; End:
