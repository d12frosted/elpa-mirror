;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261015.1606"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "ea43c059bc3c679cf7612c9cc1301dc6cf764023"
  :revdesc "ea43c059bc3c"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
