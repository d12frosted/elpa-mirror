(define-package "verb" "20230301.2117" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "0fa5259eb7e9404a5d665fb3fdf3f2c19d043189" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
