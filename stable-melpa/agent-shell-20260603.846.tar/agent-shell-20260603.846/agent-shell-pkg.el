;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260603.846"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "314d82474591f0b3bc12bb61684b5a25414c9cea"
  :revdesc "314d82474591")
