;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reaper" "20260111.2303"
  "Interact with Harvest time tracking app."
  '((emacs "26.2"))
  :url "https://github.com/xendk/reaper"
  :commit "868fd4cebe7953ea1c6580e78dab873c36de365b"
  :revdesc "868fd4cebe79"
  :keywords '("tools")
  :authors '(("Thomas Fini Hansen" . "xen@xen.dk"))
  :maintainers '(("Thomas Fini Hansen" . "xen@xen.dk")))
