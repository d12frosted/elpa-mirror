;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260326.138"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "7541aa69c9ce2cd67b72971483524f4c61bddc9d"
  :revdesc "7541aa69c9ce"
  :keywords '("faces" "files" "q"))
