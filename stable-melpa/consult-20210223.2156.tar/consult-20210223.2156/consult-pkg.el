(define-package "consult" "20210223.2156" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "db1c91776b9e503ecf34dab0e21e9b8ecb4dfedc" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
