(define-package "keepass-mode" "20211030.948" "Mode for KeePass DB."
  '((emacs "27"))
  :commit "c45e0854041b94e5ad8bc512474b0e3e286f72fc" :authors
  '(("Ignasi Fosch" . "natx@y10k.ws"))
  :maintainer
  '("Ignasi Fosch" . "natx@y10k.ws")
  :keywords
  '("data" "files" "tools")
  :url "https://github.com/ifosch/keepass-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
