;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20250920.1935"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "67bf09d291a7a497aff2446a83922dca415d147a"
  :revdesc "67bf09d291a7")
