;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-vterm-interaction" "20251024.2208"
  "A mode for Python REPL using vterm."
  '((emacs  "27.1")
    (vterm  "0.0.2")
    (python "0.28"))
  :url "https://github.com/vale981/py-vterm-interaction.el"
  :commit "3e79540a715dc69b7998fe7712a0a8183570387d"
  :revdesc "3e79540a715d"
  :keywords '("languages" "python")
  :maintainers '(("Valentin Boettcher" . "hiroatprotagon.space")))
