;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260311.1427"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "2b3ebe3dc180370223a861158ba21f06db4822cd"
  :revdesc "2b3ebe3dc180"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
