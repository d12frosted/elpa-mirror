;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20260403.1127"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "ec9965832f4b94e635478fd6e67c29a523e2e36e"
  :revdesc "ec9965832f4b"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
