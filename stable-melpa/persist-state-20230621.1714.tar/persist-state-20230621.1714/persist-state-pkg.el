(define-package "persist-state" "20230621.1714" "Regularly persist bookmarks, history, recent files and more"
  '((emacs "28.2"))
  :commit "54b7bbae7be181b25d26c3c0d18e66077c143ba1" :authors
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainer
  '("Bram Schoenmakers" . "me@bramschoenmakers.nl")
  :keywords
  '("convenience")
  :url "https://codeberg.org/bram85/emacs-persist-state.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
