(define-package "org-roam-ui" "20211117.1208" "User Interface for Org-roam"
  '((emacs "27.1")
    (org-roam "2.0.0")
    (simple-httpd "20191103.1446")
    (websocket "1.13"))
  :commit "b749a9fb9b3b4c3780c7ff633b963892257a44b3" :authors
  '(("Kirill Rogovoy, Thomas Jorna"))
  :maintainer
  '("Kirill Rogovoy, Thomas Jorna")
  :keywords
  '("files" "outlines")
  :url "https://github.com/org-roam/org-roam-ui")
;; Local Variables:
;; no-byte-compile: t
;; End:
