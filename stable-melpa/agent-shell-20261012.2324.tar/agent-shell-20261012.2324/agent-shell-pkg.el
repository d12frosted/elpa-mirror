;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261012.2324"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.17.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "ff4f524d67b43882a9317c3682a1d79b73164160"
  :revdesc "ff4f524d67b4")
