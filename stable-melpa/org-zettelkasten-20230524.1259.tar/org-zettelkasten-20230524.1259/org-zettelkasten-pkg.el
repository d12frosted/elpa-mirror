(define-package "org-zettelkasten" "20230524.1259" "A Zettelkasten mode leveraging Org"
  '((emacs "25.1")
    (org "9.3"))
  :commit "100d3d9931cc2027e1729df7bf4c6dcfdf9d75aa" :authors
  '(("Yann Herklotz" . "git@yannherklotz.com"))
  :maintainers
  '(("Yann Herklotz" . "git@yannherklotz.com"))
  :maintainer
  '("Yann Herklotz" . "git@yannherklotz.com")
  :keywords
  '("files" "hypermedia" "org" "notes")
  :url "https://sr.ht/~ymherklotz/org-zettelkasten")
;; Local Variables:
;; no-byte-compile: t
;; End:
