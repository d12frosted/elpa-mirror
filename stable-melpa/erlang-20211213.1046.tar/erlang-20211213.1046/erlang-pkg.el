(define-package "erlang" "20211213.1046" "Erlang major mode"
  '((emacs "24.1"))
  :commit "5480e13b1bed38c226345762388a4847f78cf23e" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
