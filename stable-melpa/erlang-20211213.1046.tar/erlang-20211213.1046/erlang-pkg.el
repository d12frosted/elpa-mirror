(define-package "erlang" "20211213.1046" "Erlang major mode"
  '((emacs "24.1"))
  :commit "911c10229d776163c6873e1d83daffdcd8141423" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
