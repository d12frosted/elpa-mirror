(define-package "erlang" "20211213.1046" "Erlang major mode"
  '((emacs "24.1"))
  :commit "c1ab4b5424be7504cfc3c4e87a2116b7731d8f2d" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
