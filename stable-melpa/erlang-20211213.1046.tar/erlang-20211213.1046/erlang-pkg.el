(define-package "erlang" "20211213.1046" "Erlang major mode"
  '((emacs "24.1"))
  :commit "f8e41f8553239fb02598ef6c019cdb8a174d4eea" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
