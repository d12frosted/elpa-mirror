(define-package "thrift" "20231008.729" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "39a490368990882dd7401cf4a7a4fe0f2efba98c" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
