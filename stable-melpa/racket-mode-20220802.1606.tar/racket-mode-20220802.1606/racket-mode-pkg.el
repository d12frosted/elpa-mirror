(define-package "racket-mode" "20220802.1606" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "b80134af1394e82f2761672c4a603e6672e02144" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
