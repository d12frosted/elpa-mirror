;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pimacs" "20260829.735"
  "Emacs Client for Pi."
  '((emacs     "29.1")
    (compat    "31.0")
    (timeout   "2.1.7")
    (pcre2el   "1.12")
    (spinner   "1.7")
    (transient "0.3.7"))
  :url "https://github.com/ananthakumaran/pimacs.el"
  :commit "cfee8d4e64d6f0b142608e22f9f9a64659ce05ea"
  :revdesc "cfee8d4e64d6"
  :keywords '("convenience" "processes")
  :authors '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainers '(("Anantha kumaran" . "ananthakumaran@gmail.com")))
