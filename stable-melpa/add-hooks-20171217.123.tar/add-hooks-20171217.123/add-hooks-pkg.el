;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "add-hooks" "20171217.123"
  "Functions for setting multiple hooks."
  ()
  :url "https://github.com/nickmccurdy/add-hooks"
  :commit "1845137703461fc44bd77cf24014ba58f19c369d"
  :revdesc "184513770346"
  :keywords '("lisp")
  :authors '(("Nick McCurdy" . "nick@nickmccurdy.com"))
  :maintainers '(("Nick McCurdy" . "nick@nickmccurdy.com")))
