;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20261003.1912"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "11d71e13a13d6ba23afd3b3a3f40762b3d3b99d3"
  :revdesc "11d71e13a13d"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
