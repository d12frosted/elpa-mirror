(define-package "side-hustle" "20210627.701" "Hustle through Imenu in a side window"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "1f4cd5e7cfbabb00c6d87e913770f21e3d16c957" :authors
  '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainers
  '(("Paul W. Rankin" . "pwr@bydasein.com"))
  :maintainer
  '("Paul W. Rankin" . "pwr@bydasein.com")
  :keywords
  '("convenience")
  :url "https://github.com/rnkn/side-hustle")
;; Local Variables:
;; no-byte-compile: t
;; End:
