;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260118.2132"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "bcc3d43eee40ca5a4b380a64200336b09462339f"
  :revdesc "bcc3d43eee40"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
