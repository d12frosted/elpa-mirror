;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "20260622.2257"
  "Minimal and elegant modeline."
  '((emacs "29.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "882b440a816865d8db622f9722a6fb71d5ea1e27"
  :revdesc "882b440a8168"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
