(define-package "embark" "20210224.1656" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "6d68f2fe3a7c34df457b634a2a6a0ebe01af3873" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
