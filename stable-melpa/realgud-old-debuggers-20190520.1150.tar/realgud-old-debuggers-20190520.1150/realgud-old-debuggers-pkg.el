(define-package "realgud-old-debuggers" "20190520.1150" "Realgud front-end to older lesser-used debuggers"
  '((realgud "1.4.5")
    (load-relative "1.2")
    (cl-lib "0.5")
    (emacs "24"))
  :commit "0fad38283e885c452160232e01adf3f6ae51983b" :authors
  (("Rocky Bernstein"))
  :maintainer
  ("Rocky Bernstein")
  :url "http://github.com/rocky/realgud-old-debuggers")
;; Local Variables:
;; no-byte-compile: t
;; End:
