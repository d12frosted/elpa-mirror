;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20261008.1539"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "b5c4323a46c99a63c9e5c42e99f53a6b84ba9a9f"
  :revdesc "b5c4323a46c9"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
