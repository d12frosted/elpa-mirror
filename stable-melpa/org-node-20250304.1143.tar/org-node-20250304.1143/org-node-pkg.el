;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250304.1143"
  "Fast org-roam replacement."
  '((emacs         "28.1")
    (compat        "30.0.0.0")
    (el-job        "1.0.2")
    (llama         "0.5.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "51c325e2ba4e4b1b95f4a399dd8256257a6af1eb"
  :revdesc "51c325e2ba4e"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
