;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-history" "20260803.1832"
  "Show Dates for Org headers from vcs + auto-commit."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-org-history"
  :commit "3049ba97830e8dd19a56add34ad2538cf11a0ac8"
  :revdesc "3049ba97830e"
  :keywords '("org" "outline" "vc")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
