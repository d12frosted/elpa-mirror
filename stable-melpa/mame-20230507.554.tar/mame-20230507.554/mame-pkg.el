(define-package "mame" "20230507.554" "A MAME front-end"
  '((emacs "27.1"))
  :commit "fc11ae7b1abe7448dde92a39d2587e71dafe582b" :authors
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainers
  '(("Yong" . "luo.yong.name@gmail.com"))
  :maintainer
  '("Yong" . "luo.yong.name@gmail.com")
  :url "https://github.com/Iacob/elmame")
;; Local Variables:
;; no-byte-compile: t
;; End:
