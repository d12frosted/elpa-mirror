;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk" "20260324.1519"
  "Daredevil SKK (Simple Kana to Kanji conversion program)."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :url "https://github.com/skk-dev/ddskk"
  :commit "7a559322820f9f6e0c947fa4e4b6e51cfdd0dfda"
  :revdesc "7a559322820f"
  :keywords '("japanese" "mule" "input method")
  :authors '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp")))
