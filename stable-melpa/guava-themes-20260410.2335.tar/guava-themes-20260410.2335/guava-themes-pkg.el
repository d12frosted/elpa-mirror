;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260410.2335"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "a3d6fd622090af30f4f8e22a828cf89578a7a19a"
  :revdesc "a3d6fd622090"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
