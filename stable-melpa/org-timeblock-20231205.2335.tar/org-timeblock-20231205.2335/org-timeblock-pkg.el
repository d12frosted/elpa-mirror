(define-package "org-timeblock" "20231205.2335" "Interactive SVG calendar for orgmode tasks"
  '((emacs "28.1")
    (compat "29.1.4.1")
    (org-ql "0.7")
    (org "9.0")
    (svg "1.1")
    (persist "0.5"))
  :commit "a39c1367f0e237f79c26246fe6303413ca3dd05c" :authors
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainers
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainer
  '("Ilya Chernyshov" . "ichernyshovvv@gmail.com")
  :keywords
  '("org" "calendar" "timeblocking" "agenda")
  :url "https://github.com/ichernyshovvv/org-timeblock")
;; Local Variables:
;; no-byte-compile: t
;; End:
