(define-package "eldev" "20210530.1641" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "d51ce6152519b5cf32d0dcc40cad6787eb605997" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
