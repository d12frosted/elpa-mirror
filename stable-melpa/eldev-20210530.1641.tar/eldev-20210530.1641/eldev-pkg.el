(define-package "eldev" "20210530.1641" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "e9af76aa8fd9ce5b7010b7322a73341828cfe690" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
