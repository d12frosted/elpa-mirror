(define-package "w3m" "20211122.335" "an Emacs interface to w3m" 'nil :commit "c28c15f0d1898bceb57cc5751bb9bba0f5150390" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
