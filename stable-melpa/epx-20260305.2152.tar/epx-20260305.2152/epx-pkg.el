;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epx" "20260305.2152"
  "Manage and run project-specific shell commands."
  '((emacs "29.1"))
  :url "https://git.sr.ht/~alex-iam/epx"
  :commit "eba5ae521540e1f77dbd24180c38a8cb84acb8e9"
  :revdesc "eba5ae521540"
  :keywords '("project" "shell" "tools")
  :authors '(("Oleksandr Korzh" . "alex@korzh.me"))
  :maintainers '(("Oleksandr Korzh" . "alex@korzh.me")))
