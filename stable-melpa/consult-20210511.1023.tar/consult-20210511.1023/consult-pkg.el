(define-package "consult" "20210511.1023" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b873ceeefcb80ae0a00aa5e9ce7d70a71680aa4b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
