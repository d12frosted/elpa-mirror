;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "po-mode" "20261114.1902"
  "Major mode for GNU gettext PO files."
  '((emacs "23"))
  :commit "be0c57e778fe90e71abe6a7e68d8961fa1782a97"
  :revdesc "be0c57e778fe"
  :keywords '("i18n" "gettext"))
