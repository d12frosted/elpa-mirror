;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260301.1917"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "532e77c95068dfed6a0f773b7b7f0a78e81e0f45"
  :revdesc "532e77c95068"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
