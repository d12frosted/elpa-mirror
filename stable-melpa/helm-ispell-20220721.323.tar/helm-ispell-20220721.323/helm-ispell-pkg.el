;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ispell" "20220721.323"
  "Ispell-complete-word with helm interface."
  '((helm-core "3.6.0"))
  :url "https://github.com/syohex/emacs-helm-ispell"
  :commit "03e74ae7ebb17589a9f8860d1e2ae37f57378735"
  :revdesc "03e74ae7ebb1"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
