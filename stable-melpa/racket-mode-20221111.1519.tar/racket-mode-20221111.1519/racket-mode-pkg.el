(define-package "racket-mode" "20221111.1519" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "6863a2611fab30c2f05e7012c560eff0b9344991" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
