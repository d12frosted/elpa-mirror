;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ben" "20260526.919"
  "Asynchronous buffer-local environments via `direnv'."
  '((emacs      "29.1")
    (inheritenv "0.1")
    (seq        "2.24"))
  :url "https://codeberg.org/pastor/ben.el"
  :commit "ad761a1d1324bf3fa3e0ce4f0a92e219e9b3a4ab"
  :revdesc "ad761a1d1324"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com")
             ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")
                 ("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
