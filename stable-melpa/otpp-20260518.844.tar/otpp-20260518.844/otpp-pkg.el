;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260518.844"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "20d5b7d751b8fa3d6506e59cffc3ce21f0e272fb"
  :revdesc "20d5b7d751b8"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
