(define-package "jabber" "20230625.254" "A Jabber client for Emacs."
  '((fsm "0.2")
    (srv "0.2"))
  :commit "090dbf5a4d86d1ddf2fa3eed0bf307f7a1c67c48" :authors
  '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainer
  '("wgreenhouse" . "wgreenhouse@tilde.club")
  :keywords
  '("comm")
  :url "https://codeberg.org/emacs-jabber/emacs-jabber")
;; Local Variables:
;; no-byte-compile: t
;; End:
