(define-package "expenses" "20230516.929" "Record and view expenses"
  '((emacs "28.1")
    (dash "2.19.1")
    (ht "2.3"))
  :commit "843d1907f3bae0c76c555856b656b87544057c2d" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("expense tracking" "convenience")
  :url "https://github.com/md-arif-shaikh/expenses")
;; Local Variables:
;; no-byte-compile: t
;; End:
