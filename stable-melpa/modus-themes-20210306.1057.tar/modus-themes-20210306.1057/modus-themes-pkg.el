(define-package "modus-themes" "20210306.1057" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "80f643d89afdd1f53b76c553a8cc6a49ee283096" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
