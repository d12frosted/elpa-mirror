(define-package "loopy" "20230506.2230" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22")
    (compat "29.1.3"))
  :commit "fdc5f6cf687bdde7b19f9252d1d6c0f49d0ede54" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
