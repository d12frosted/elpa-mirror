(define-package "dwim-coder-mode" "20230826.450" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "6d1f3846761f33f2dffc345a866d15e78606bde7" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
