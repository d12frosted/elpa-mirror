(define-package "php-mode" "20210306.1152" "Major mode for editing PHP code"
  '((emacs "24.3"))
  :commit "53da0b4bdb0ff67e7ca66cd63c10f56df7bc20bd" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
