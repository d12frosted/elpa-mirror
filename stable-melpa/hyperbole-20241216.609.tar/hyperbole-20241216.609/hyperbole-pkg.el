;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241216.609"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "c4c5daaa08429e36cc38c68cf5d7381736b38769"
  :revdesc "c4c5daaa0842"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
