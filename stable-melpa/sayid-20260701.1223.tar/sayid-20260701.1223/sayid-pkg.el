;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "20260701.1223"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.23"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "755c0d56bf563fddb1d171030713c788ad0aadb9"
  :revdesc "755c0d56bf56"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
