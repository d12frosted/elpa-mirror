(define-package "modus-themes" "20221231.1304" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "57cb3347ad4a75e31cdb26e9e67a387589ba77c6" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
