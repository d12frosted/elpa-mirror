(define-package "deno-ts-mode" "20230830.116" "Major mode for Deno"
  '((emacs "29.1"))
  :commit "c6f827b998b5d0fbc8bb3254c4d3b1efca0c5c6f" :authors
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainers
  '(("Graham Marlow" . "info@mgmarlow.com"))
  :maintainer
  '("Graham Marlow" . "info@mgmarlow.com")
  :keywords
  '("languages")
  :url "https://git.sr.ht/~mgmarlow/deno-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
