;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simplenote2" "20190321.933"
  "Interact with app.simplenote.com."
  '((request-deferred "0.2.0")
    (uuidgen          "20140918")
    (unicode-escape   "1.1"))
  :url "https://github.com/alpha22jp/simplenote2.el"
  :commit "760ffecda63bd218876b623f46d332e3ef079be6"
  :revdesc "760ffecda63b"
  :keywords '("simplenote")
  :authors '(("alpha22jp" . "alpha22jp@gmail.com"))
  :maintainers '(("alpha22jp" . "alpha22jp@gmail.com")))
