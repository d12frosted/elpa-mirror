;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250622.1758"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "354c94a1fda5c5b84b4f64df8f2fc9fbccfc219f"
  :revdesc "354c94a1fda5"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
