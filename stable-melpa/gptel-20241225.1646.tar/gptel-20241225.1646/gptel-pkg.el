;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241225.1646"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "183c68368cecfbc77a5b9b5fe000225d2984ec21"
  :revdesc "183c68368cec"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
