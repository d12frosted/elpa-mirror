(define-package "telega" "20230313.743" "Telegram client (unofficial)"
  '((emacs "27.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "753b9680ff3f6ea3b868400f4ef83698d60a721d" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
