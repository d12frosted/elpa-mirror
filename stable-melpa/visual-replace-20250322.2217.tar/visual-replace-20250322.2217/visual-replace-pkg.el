;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "20250322.2217"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "http://github.com/szermatt/visual-replace"
  :commit "0b035a0c33d2e56b9b6bb14e05ba54c9bf6a4f65"
  :revdesc "0b035a0c33d2"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
