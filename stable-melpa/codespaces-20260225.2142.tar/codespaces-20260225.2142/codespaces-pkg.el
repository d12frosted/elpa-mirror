;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260225.2142"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "11b8f9d690c0d60300dc9bdda89fb9ac58f7d194"
  :revdesc "11b8f9d690c0"
  :keywords '("comm")
  :authors '(("Fabian Markl" . "fabian@markl.dev"))
  :maintainers '(("Fabian Markl" . "fabian@markl.dev")))
