(define-package "consult" "20211229.2231" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "15ce23520abfe219ff7652f56516cbd38315dee2" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
