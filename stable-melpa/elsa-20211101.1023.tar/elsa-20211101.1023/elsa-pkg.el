(define-package "elsa" "20211101.1023" "Emacs Lisp Static Analyser"
  '((trinary "1.0.0")
    (emacs "25.1")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3"))
  :commit "22bb5bd15e3f4fc2a9f10b998626fec18fd3a1a0" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
