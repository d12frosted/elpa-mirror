(define-package "tide" "20220314.930" "Typescript Interactive Development Environment"
  '((emacs "25.1")
    (dash "2.10.0")
    (s "1.11.0")
    (flycheck "27")
    (typescript-mode "0.1")
    (cl-lib "0.5"))
  :commit "bc2c74fdcf920a258bbdb78c0534078489aaa8cc" :authors
  '(("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainer
  '("Anantha kumaran" . "ananthakumaran@gmail.com")
  :keywords
  '("typescript")
  :url "http://github.com/ananthakumaran/tide")
;; Local Variables:
;; no-byte-compile: t
;; End:
