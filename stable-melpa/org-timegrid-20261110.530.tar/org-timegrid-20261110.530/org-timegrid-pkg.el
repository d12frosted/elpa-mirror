;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261110.530"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "815053785ae3b65df10217c97507d1badc712e5c"
  :revdesc "815053785ae3"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
