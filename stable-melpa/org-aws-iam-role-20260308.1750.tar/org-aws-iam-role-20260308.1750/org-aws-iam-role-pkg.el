;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-aws-iam-role" "20260308.1750"
  "Browse, modify, and simulate AWS IAM Roles in Org Babel."
  '((emacs   "29.1")
    (async   "1.9")
    (promise "1.1"))
  :url "https://github.com/will-abb/org-aws-iam-role"
  :commit "0175d5ac66f43f8d32db64a04421fddf57e10af7"
  :revdesc "0175d5ac66f4"
  :keywords '("aws" "iam" "org" "babel" "tools")
  :authors '(("William Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("William Bosch-Bello" . "williamsbosch@gmail.com")))
