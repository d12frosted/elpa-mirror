(define-package "julia-snail" "20220417.1439" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (vterm "0.0.1"))
  :commit "918ea03bc79b39a7e03ef1492947c0c1dcceb69c" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
