;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260308.1145"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "bb86c8ae0870e48f279136f91c3a0b76ef6661ec"
  :revdesc "bb86c8ae0870"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
