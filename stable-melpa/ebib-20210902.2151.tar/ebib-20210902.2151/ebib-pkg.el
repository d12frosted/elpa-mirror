(define-package "ebib" "20210902.2151" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "85da632406297f7289b9bdd3803684575cfae886" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
