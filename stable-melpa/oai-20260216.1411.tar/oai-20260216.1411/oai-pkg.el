;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260216.1411"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "8afce658553c47990ff9ffa998f82319067d3db0"
  :revdesc "8afce658553c"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
