;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "info-beamer" "20210427.1033"
  "Utilities for working with info-beamer."
  '((emacs "24.4"))
  :url "https://github.com/dakra/info-beamer.el"
  :commit "6b4cc29f1aec72d8e23b2c25a99cdd84e6cdc92b"
  :revdesc "6b4cc29f1aec"
  :keywords '("tools" "processes" "comm")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
