;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sis" "20241224.317"
  "Less manual switch for native or OS input source (input method)."
  '((emacs "27.1"))
  :url "https://github.com/laishulu/emacs-smart-input-source"
  :commit "0aae59cbfeca0960f6859f420c879f51e4903838"
  :revdesc "0aae59cbfeca"
  :keywords '("convenience"))
