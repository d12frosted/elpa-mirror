(define-package "dirvish" "20220209.1137" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "361c9ac62c3a5605e948080d688fc933dca4055f" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
