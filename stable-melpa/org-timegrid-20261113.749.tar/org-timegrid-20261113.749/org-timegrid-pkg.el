;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-timegrid" "20261113.749"
  "SVG week calendar with mouse and keyboard editing."
  '((emacs "29.1")
    (org   "9.6"))
  :url "https://github.com/Gleek/org-timegrid"
  :commit "51cf9dd915c19d15e3b240c6906231c83442b1e6"
  :revdesc "51cf9dd915c1"
  :keywords '("calendar" "outlines" "convenience")
  :authors '(("Umar Ahmad" . "Gleek@users.noreply.github.com"))
  :maintainers '(("Umar Ahmad" . "Gleek@users.noreply.github.com")))
