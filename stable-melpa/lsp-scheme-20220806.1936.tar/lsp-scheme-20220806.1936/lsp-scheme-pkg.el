(define-package "lsp-scheme" "20220806.1936" "Scheme support for lsp-mode"
  '((emacs "25.1")
    (f "0.20.0")
    (lsp-mode "8.0.0"))
  :commit "d406c0ab1c7bb9f7ec5a09e25e4e9f3bc0f44737" :authors
  '(("Ricardo G. Herdt" . "r.herdt@posteo.de"))
  :maintainer
  '("Ricardo G. Herdt" . "r.herdt@posteo.de")
  :keywords
  '("languages" "lisp" "tools")
  :url "https://codeberg.org/rgherdt/emacs-lsp-scheme")
;; Local Variables:
;; no-byte-compile: t
;; End:
