(define-package "wucuo" "20210316.156" "Fastest solution to spell check camel case code or plain text"
  '((emacs "25.1"))
  :commit "986c9d96ff898d346b453422e8e312f7976e6089" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("convenience")
  :url "http://github.com/redguardtoo/wucuo")
;; Local Variables:
;; no-byte-compile: t
;; End:
