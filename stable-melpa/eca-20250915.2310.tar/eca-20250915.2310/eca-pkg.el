;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20250915.2310"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "343dafdfa0cfd7fe720c55d08ee42ad3fe05ce67"
  :revdesc "343dafdfa0cf"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
