(define-package "magit-section" "20210701.1554" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210330"))
  :commit "2ae376e4923e02355828350b81cdc1b0f8fa72ff" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
