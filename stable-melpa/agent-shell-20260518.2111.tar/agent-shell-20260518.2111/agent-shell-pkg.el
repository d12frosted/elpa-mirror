;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260518.2111"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "33cfb8e9827e571806e8b2284c8af96ffa395173"
  :revdesc "33cfb8e9827e")
