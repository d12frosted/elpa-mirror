(define-package "detached" "20221122.1100" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "c47a5ee9d68add7d0ca127958cca3cd5bd3b423c" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
