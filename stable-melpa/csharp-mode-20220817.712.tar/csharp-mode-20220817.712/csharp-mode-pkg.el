(define-package "csharp-mode" "20220817.712" "C# mode derived mode"
  '((emacs "26.1"))
  :commit "fbe090b0e16eccdc2ee06da7f2a0b23ad63f3347" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
