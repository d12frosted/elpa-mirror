(define-package "csharp-mode" "20220817.712" "C# mode derived mode"
  '((emacs "26.1"))
  :commit "772128c8686685010301f2e84e9d3f139f5295e6" :authors
  '(("Theodor Thornhill" . "theo@thornhill.no"))
  :maintainer
  '("Jostein Kjønigsen" . "jostein@gmail.com")
  :keywords
  '("c#" "languages" "oop" "mode")
  :url "https://github.com/emacs-csharp/csharp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
