;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260315.2135"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "e1353c06ff36b65386c81268f1d480384d361c7e"
  :revdesc "e1353c06ff36"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
