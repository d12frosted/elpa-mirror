;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hl-indent-scope" "20260502.926"
  "Highlight indentation by scope."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope"
  :commit "538ddc0295727b11e20a9615a18d0f280bc0212a"
  :revdesc "538ddc029572"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
