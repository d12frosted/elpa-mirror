;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20261103.2143"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "5af5448d41e074d833e67a3709a11c5569083873"
  :revdesc "5af5448d41e0"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
