(define-package "org-runbook" "20210102.252" "Org mode for runbooks"
  '((emacs "25.1")
    (seq "2.3")
    (f "0.20.0")
    (s "1.12.0")
    (dash "2.17.0")
    (mustache "0.24")
    (ht "0.9"))
  :commit "d9f443b01e2105fd08b74efa7bc3dfa1266c0661" :authors
  (("Tyler Dodge"))
  :maintainer
  ("Tyler Dodge")
  :keywords
  ("convenience" "processes" "terminals" "files")
  :url "https://github.com/tyler-dodge/org-runbook")
;; Local Variables:
;; no-byte-compile: t
;; End:
