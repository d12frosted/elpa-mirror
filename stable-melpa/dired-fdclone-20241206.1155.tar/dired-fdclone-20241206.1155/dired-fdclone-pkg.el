;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-fdclone" "20241206.1155"
  "Dired functions and settings to mimic FDclone."
  ()
  :url "https://github.com/knu/dired-fdclone.el"
  :commit "2c911aaee8ad18ce7c92346ba452229a5d7fc1ed"
  :revdesc "2c911aaee8ad"
  :keywords '("unix" "directories" "dired")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
