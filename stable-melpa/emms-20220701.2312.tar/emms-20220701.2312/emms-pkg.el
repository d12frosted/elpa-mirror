(define-package "emms" "20220701.2312" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (seq "0"))
  :commit "9adffa2e362e3d93367f5f69be20d81b969ad00c" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
