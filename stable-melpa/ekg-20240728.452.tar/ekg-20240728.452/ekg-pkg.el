(define-package "ekg" "20240728.452" "A system for recording and linking information"
  '((triples "0.3.5")
    (emacs "28.1")
    (llm "0.17.0"))
  :commit "c31a6e7d049c0dc0a02065993b21c4ffab95fb04" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
