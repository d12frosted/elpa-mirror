(define-package "casual-dired" "20240501.443" "Casual Dired"
  '((emacs "29.1"))
  :commit "bc58d55d18618e3befaec751f659746e3bdcfd9e" :authors
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers
  '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainer
  '("Charles Choi" . "kickingvegas@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kickingvegas/casual-dired")
;; Local Variables:
;; no-byte-compile: t
;; End:
