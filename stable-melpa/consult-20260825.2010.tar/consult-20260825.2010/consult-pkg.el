;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260825.2010"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "dcbc3b8e5347d0c4b5c6187d0e150b1c26c385ff"
  :revdesc "dcbc3b8e5347"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
