;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gl-conf-mode" "20170714.1310"
  "Mode for editing gitolite config files."
  '((emacs "24.3"))
  :url "https://github.com/llloret/gitolite-emacs"
  :commit "9136a9b737e0a5b6471a91571d104c487c43f35b"
  :revdesc "9136a9b737e0"
  :keywords '("git" "gitolite" "languages"))
