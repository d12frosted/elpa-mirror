;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "20260113.1707"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "547d9dd773dd3747c4345cf0b9111ac0ed8c14b4"
  :revdesc "547d9dd773dd"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
