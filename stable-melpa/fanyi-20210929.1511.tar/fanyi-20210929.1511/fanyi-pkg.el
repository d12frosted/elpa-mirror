(define-package "fanyi" "20210929.1511" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "7bab0f74524f51ca14633d6c4519b5f3605c0444" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
