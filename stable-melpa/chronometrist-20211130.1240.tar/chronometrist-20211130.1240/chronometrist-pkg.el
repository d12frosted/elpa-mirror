(define-package "chronometrist" "20211130.1240" "A time tracker with a nice interface"
  '((emacs "25.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "37bc29d9233820486b85c39b93169ba3fef9af4c" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
