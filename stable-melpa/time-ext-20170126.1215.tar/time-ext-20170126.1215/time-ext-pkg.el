;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "time-ext" "20170126.1215"
  "More function for time/date."
  ()
  :url "http://www.emacswiki.org/cgi-bin/wiki/download/time-ext.el"
  :commit "d128becf660fe3f30178eb1b05cd266741f4784a"
  :revdesc "d128becf660f"
  :keywords '("lisp")
  :authors '(("rubikitch" . "rubikitch@ruby-lang.org"))
  :maintainers '(("rubikitch" . "rubikitch@ruby-lang.org")))
