;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260405.131"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "9b50c67292189b599dcb17108f93be520caa5647"
  :revdesc "9b50c6729218"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
