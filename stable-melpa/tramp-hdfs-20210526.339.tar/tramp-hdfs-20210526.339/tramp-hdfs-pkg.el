;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tramp-hdfs" "20210526.339"
  "Tramp extension to access hadoop/hdfs file system in Emacs."
  '((emacs "24.4"))
  :url "https://github.com/raghavgautam/tramp-hdfs"
  :commit "aa93bdbb3d5619c262ce53af1981edcd2a0705e5"
  :revdesc "aa93bdbb3d56"
  :keywords '("tramp" "emacs" "hdfs" "hadoop" "webhdfs" "rest")
  :authors '(("Raghav Kumar Gautam" . "raghav@apache.org"))
  :maintainers '(("Raghav Kumar Gautam" . "raghav@apache.org")))
