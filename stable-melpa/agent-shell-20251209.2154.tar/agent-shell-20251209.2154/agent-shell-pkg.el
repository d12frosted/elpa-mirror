;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251209.2154"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.2")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e6838281ec2a95037b8cd46b03b79d3b33b22271"
  :revdesc "e6838281ec2a")
