;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kwin" "20220120.2125"
  "Communicatewith the KWin window manager."
  ()
  :url "https://github.com/reactormonk/kwin-minor-mode"
  :commit "20fac6508e5535a26df783ba05f04d1800b7382c"
  :revdesc "20fac6508e55")
