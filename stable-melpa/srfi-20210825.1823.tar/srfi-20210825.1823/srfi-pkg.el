(define-package "srfi" "20210825.1823" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "a6bbe36afa229b88aa5b406b9ef6e6393d9b2d5d" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
