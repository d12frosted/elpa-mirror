;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-rst" "20140225.944"
  "Auto-complete extension for ReST and Sphinx."
  '((auto-complete "1.4"))
  :url "https://github.com/tkf/auto-complete-rst"
  :commit "4803ce41a96224e6fa54e6741a5b5f40ebed7351"
  :revdesc "4803ce41a962")
