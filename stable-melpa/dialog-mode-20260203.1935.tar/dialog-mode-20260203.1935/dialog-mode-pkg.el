;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260203.1935"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "e738ecfe0a6d1e28942ecbf9c6a877c5dc3b0741"
  :revdesc "e738ecfe0a6d"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
