;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "20261104.1811"
  "Run REPLs in a terminal backend."
  '((emacs "29.1"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "7b919e672497a463a3e2e15e497919ff4cc5f77f"
  :revdesc "7b919e672497"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
