(define-package "eping" "20201027.2149" "Ping websites to check internet connectivity"
  '((emacs "25.1"))
  :commit "004496ee06c0b8ead4a4f49e17109e8eb32eb49d" :authors
  '(("Sean Hutchings" . "seanhut@yandex.com"))
  :maintainer
  '("Sean Hutchings" . "seanhut@yandex.com")
  :keywords
  '("comm" "processes" "terminals" "unix")
  :url "https://github.com/sean-hut/eping")
;; Local Variables:
;; no-byte-compile: t
;; End:
