;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-ledger" "20210910.250"
  "Fuzzy auto-completion for Ledger & friends."
  '((emacs   "24.3")
    (company "0.8.0"))
  :url "https://github.com/debanjum/company-ledger"
  :commit "55fdddd6c5e9c061c685b474ef5e148a4ac9b576"
  :revdesc "55fdddd6c5e9"
  :keywords '("abbrev" "matching" "auto-complete" "beancount" "ledger" "company")
  :authors '(("Debanjum Singh Solanky" . "debanjumATgmailDOTcom"))
  :maintainers '(("Debanjum Singh Solanky" . "debanjumATgmailDOTcom")))
