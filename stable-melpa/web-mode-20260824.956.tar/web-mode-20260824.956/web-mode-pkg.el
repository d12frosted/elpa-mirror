;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "web-mode" "20260824.956"
  "Major mode for editing web templates."
  '((emacs "24.3.1"))
  :url "https://web-mode.org"
  :commit "f008a28f156452b212a62274d0ef5a9e25074698"
  :revdesc "f008a28f1564"
  :keywords '("languages")
  :maintainers '(("François-Xavier Bois" . "fxbois@gmail.com")))
