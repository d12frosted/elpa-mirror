;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enhanced-evil-paredit" "20251015.1408"
  "Paredit support for evil keybindings."
  '((emacs   "24.1")
    (evil    "1.0.9")
    (paredit "25beta"))
  :url "https://github.com/jamescherti/enhanced-evil-paredit.el"
  :commit "5f92d26baf2498ab53fb9448c8130438f76ee237"
  :revdesc "5f92d26baf24"
  :keywords '("convenience"))
