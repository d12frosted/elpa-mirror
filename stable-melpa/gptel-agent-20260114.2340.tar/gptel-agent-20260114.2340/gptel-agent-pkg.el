;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260114.2340"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "ba4aed51fe4ae4ddf73dc538aeaec7fe9bc364be"
  :revdesc "ba4aed51fe4a"
  :keywords '("comm"))
