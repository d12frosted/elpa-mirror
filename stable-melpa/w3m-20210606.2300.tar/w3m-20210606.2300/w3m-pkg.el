(define-package "w3m" "20210606.2300" "an Emacs interface to w3m" 'nil :commit "75d06685ef4f3350bf443610457520812427e127" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
