(define-package "w3m" "20210606.2300" "an Emacs interface to w3m" 'nil :commit "e2151425cc4e1681a0c6753e82807f2b8ef27b72" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
