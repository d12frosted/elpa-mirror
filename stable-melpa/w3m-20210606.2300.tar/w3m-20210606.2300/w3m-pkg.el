(define-package "w3m" "20210606.2300" "an Emacs interface to w3m" 'nil :commit "ab6aa498b5719a0bcbbfbb248928f541f043aa1e" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
