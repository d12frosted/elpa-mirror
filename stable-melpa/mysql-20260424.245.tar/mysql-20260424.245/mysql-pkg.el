;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20260424.245"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "e8964613c6eb1bd1aeda12e7e78e3b9d81ea70b7"
  :revdesc "e8964613c6eb"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
