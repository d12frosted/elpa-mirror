;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260515.1441"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "35fa167c2de4b7de5669ccd1074c2182df170375"
  :revdesc "35fa167c2de4"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
