(define-package "embark" "20210828.1805" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "0201e2242322410fbfdbd72c193e9ee454bba8ab" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
