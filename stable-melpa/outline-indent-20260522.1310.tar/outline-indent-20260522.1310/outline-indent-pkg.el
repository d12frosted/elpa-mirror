;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260522.1310"
  "Folding text based on indentation (origami alternative)."
  '((emacs    "26.1")
    (kirigami "1.0.5"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "1df9046ef75307a0b9d955aeb42f6c0a4d75d596"
  :revdesc "1df9046ef753"
  :keywords '("outlines")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
