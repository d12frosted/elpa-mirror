;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-table-highlight" "20250717.1449"
  "Highlight Org table columns and rows."
  '((emacs "27.1"))
  :url "https://github.com/llcc/org-table-highlight"
  :commit "ef121565cd100838522a94735c2a9d4e0fb3027a"
  :revdesc "ef121565cd10"
  :keywords '("org-table" "convenience"))
