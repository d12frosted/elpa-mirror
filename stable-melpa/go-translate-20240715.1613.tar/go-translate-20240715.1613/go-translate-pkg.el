(define-package "go-translate" "20240715.1613" "Translation framework, configurable and scalable"
  '((emacs "28.1"))
  :commit "892b6e48c4513fd7df54db05b047c3ba602d1442" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainers
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
