(define-package "bbdb" "20180106.1710" "The Insidious Big Brother Database for GNU Emacs" 'nil :commit "f18720ff5cd963a0bf6fc0e41293e50c0172b8ae")
;; Local Variables:
;; no-byte-compile: t
;; End:
