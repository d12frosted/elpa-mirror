(define-package "mew" "20240513.544" "Messaging in the Emacs World" 'nil :commit "3062560b5daee27c7f4fa73a6b2e3b048b0c3a46" :authors
  '(("Mew developing team"))
  :maintainers
  '(("Mew developing team"))
  :maintainer
  '("Mew developing team"))
;; Local Variables:
;; no-byte-compile: t
;; End:
