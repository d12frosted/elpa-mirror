;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "timp" "20160618.803"
  "Multithreading library."
  '((emacs      "24.4")
    (cl-lib     "0.5")
    (fifo-class "1.0")
    (signal     "1.0"))
  :url "https://github.com/mola-T/timp"
  :commit "59657bf603904635d88c3fe4ff1ce45ee6572428"
  :revdesc "59657bf60390"
  :keywords '("internal" "lisp" "processes" "tools")
  :authors '(("Mola-T" . "Mola@molamola.xyz"))
  :maintainers '(("Mola-T" . "Mola@molamola.xyz")))
