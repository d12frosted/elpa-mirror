(define-package "timp" "20160618.803" "Multithreading library"
  '((emacs "24.4")
    (cl-lib "0.5")
    (fifo-class "1.0")
    (signal "1.0"))
  :commit "59657bf603904635d88c3fe4ff1ce45ee6572428" :authors
  '(("Mola-T" . "Mola@molamola.xyz"))
  :maintainer
  '("Mola-T" . "Mola@molamola.xyz")
  :keywords
  '("internal" "lisp" "processes" "tools")
  :url "https://github.com/mola-T/timp")
;; Local Variables:
;; no-byte-compile: t
;; End:
