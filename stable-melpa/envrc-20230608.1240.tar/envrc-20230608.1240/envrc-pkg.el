(define-package "envrc" "20230608.1240" "Support for `direnv' that operates buffer-locally"
  '((seq "2")
    (emacs "25.1")
    (inheritenv "0.1"))
  :commit "d4d880faf51a3ebbfc2d45633c6c5ff6d1bc8c79" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("processes" "tools")
  :url "https://github.com/purcell/envrc")
;; Local Variables:
;; no-byte-compile: t
;; End:
