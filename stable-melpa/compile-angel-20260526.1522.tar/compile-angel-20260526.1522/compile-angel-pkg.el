;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260526.1522"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "7e966336a8d770668eb9a42eeae5db3c50da2a67"
  :revdesc "7e966336a8d7"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
