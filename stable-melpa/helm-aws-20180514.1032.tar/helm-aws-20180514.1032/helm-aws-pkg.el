;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-aws" "20180514.1032"
  "Manage AWS EC2 server instances directly from Emacs."
  '((helm   "1.5.3")
    (cl-lib "0.5")
    (s      "1.9.0"))
  :url "https://github.com/istib/helm-aws"
  :commit "b36c744b3f00f458635a91d1f5158fccbb5baef6"
  :revdesc "b36c744b3f00")
