(define-package "elsa" "20230222.1941" "Emacs Lisp Static Analyser"
  '((emacs "25.1")
    (trinary "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3")
    (lsp-mode "0"))
  :commit "40b9f4accff4e2fe8027f27fb8c223a7c434cb2a" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
