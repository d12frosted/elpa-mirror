(define-package "org-rainbow-tags" "20230607.1927" "Colorize org tags automatically"
  '((emacs "28.1"))
  :commit "550cc521013ba631bb3ad5fc4acdb72b655b24b7" :authors
  '(("Furkan Karataş" . "furkan.karatas02@gmail.com"))
  :maintainers
  '(("Furkan Karataş" . "furkan.karatas02@gmail.com"))
  :maintainer
  '("Furkan Karataş" . "furkan.karatas02@gmail.com")
  :keywords
  '("faces" "outlines")
  :url "https://github.com/KaratasFurkan/org-rainbow-tags")
;; Local Variables:
;; no-byte-compile: t
;; End:
