(define-package "flycheck-grammalecte" "20200515.1120" "Integrate Grammalecte with Flycheck"
  '((emacs "25.1")
    (flycheck "26"))
  :commit "8608df3144714d79b93afcfe13400693ed763ed8" :keywords
  ("i18n" "text")
  :authors
  (("Guilhem Doulcier" . "guilhem.doulcier@espci.fr")
   ("Étienne Deparis" . "etienne@depar.is"))
  :maintainer
  ("Guilhem Doulcier" . "guilhem.doulcier@espci.fr")
  :url "https://git.deparis.io/flycheck-grammalecte/")
;; Local Variables:
;; no-byte-compile: t
;; End:
