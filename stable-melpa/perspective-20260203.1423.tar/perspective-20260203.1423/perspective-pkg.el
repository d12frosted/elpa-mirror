;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "perspective" "20260203.1423"
  "Switch between named \"perspectives\" of the editor."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "http://github.com/nex3/perspective-el"
  :commit "dfef8817970288322ac2a4a3caaf27ec28f0adab"
  :revdesc "dfef88179702"
  :keywords '("workspace" "convenience" "frames")
  :authors '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers '(("Natalie Weizenbaum" . "nex342@gmail.com")))
