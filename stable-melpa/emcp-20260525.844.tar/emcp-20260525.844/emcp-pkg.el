;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20260525.844"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.1.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "ac5006e6556f59f8105aba398c26d504988837be"
  :revdesc "ac5006e6556f"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
