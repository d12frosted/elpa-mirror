;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250103.932"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "a79f7243ecbb8611032b6453c2a2def062a6f998"
  :revdesc "a79f7243ecbb"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
