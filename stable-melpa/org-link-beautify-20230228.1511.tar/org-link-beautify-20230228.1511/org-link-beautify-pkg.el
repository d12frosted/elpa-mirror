(define-package "org-link-beautify" "20230228.1511" "Beautify Org Links"
  '((emacs "28.1")
    (all-the-icons "5.0.0"))
  :commit "48eb9ac841d660d6f4c3a76a9d1478fc5eb8b896" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
