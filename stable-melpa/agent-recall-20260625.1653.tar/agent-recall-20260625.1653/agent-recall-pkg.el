;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20260625.1653"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "df6765da12dbb6ed4ba29e6f48ac271b91f0264d"
  :revdesc "df6765da12db"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
