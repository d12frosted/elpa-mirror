;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dash" "20250312.1129"
  "A modern list library for Emacs."
  '((emacs "24"))
  :url "https://github.com/magnars/dash.el"
  :commit "4e8e5fae48fe090977ab001c1b19d0b8a5e4001a"
  :revdesc "4e8e5fae48fe"
  :keywords '("extensions" "lisp")
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
