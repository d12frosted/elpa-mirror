;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-capitalize" "20260827.1202"
  "Automatic capitalization with batteries included."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/abdulnafe-t/auto-capitalize.el"
  :commit "0dd2716c3c7cbd8fb98fab6bff797dd21db61e3e"
  :revdesc "0dd2716c3c7c"
  :keywords '("text" "wp" "convenience")
  :maintainers '(("Abdulnafé Toulaïmat" . "abdulnafe.toulaimat@gmail.com")))
