(define-package "easy-kill-extras" "20230829.450" "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :commit "2f94f8148be9796e6a6dadf15084ab43ed7bf91e" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/easy-kill-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
