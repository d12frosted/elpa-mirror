(define-package "embark" "20220418.2042" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "f46b6ba6a567024f28e1e814f402b020e67be882" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
