(define-package "code-compass" "20230527.1309" "Navigate software aided by metrics and visualization"
  '((emacs "26.1")
    (s "1.12.0")
    (dash "2.13")
    (async "1.9.7")
    (simple-httpd "1.5.1"))
  :commit "f55155ef7c098aea4275e18211cd45ad028a5f82" :authors
  '(("Andrea" . "andrea-dev@hotmail.com"))
  :maintainers
  '(("Andrea" . "andrea-dev@hotmail.com"))
  :maintainer
  '("Andrea" . "andrea-dev@hotmail.com")
  :keywords
  '("tools" "extensions" "help")
  :url "https://github.com/ag91/code-compass")
;; Local Variables:
;; no-byte-compile: t
;; End:
