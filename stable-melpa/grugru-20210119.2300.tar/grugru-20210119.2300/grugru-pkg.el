(define-package "grugru" "20210119.2300" "Rotate text at point"
  '((emacs "24.4"))
  :commit "07785f89f8cc1ccca97ef170dc4b3328f5d8b258" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
