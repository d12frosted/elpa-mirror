;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250120.1730"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "40d8000d5f09cd9c31b799095fae4202dae383cd"
  :revdesc "40d8000d5f09"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
