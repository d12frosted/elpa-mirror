;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-journal-list" "20190221.2052"
  "Org mode Journal List."
  '((emacs "25"))
  :url "https://github.com/huytd/org-journal-list"
  :commit "2b26d00181bb49bff64b31ad020490acd1b6ae02"
  :revdesc "2b26d00181bb"
  :authors '(("Huy Tran" . "huytd189@gmail.com"))
  :maintainers '(("Huy Tran" . "huytd189@gmail.com")))
