(define-package "evil-matchit" "20210727.1106" "Vim matchit ported to Evil"
  '((evil "1.14.0")
    (emacs "25.1"))
  :commit "80dc731ab736545541546ca64187e850bf0e39c8" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail DOT com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail DOT com>")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
