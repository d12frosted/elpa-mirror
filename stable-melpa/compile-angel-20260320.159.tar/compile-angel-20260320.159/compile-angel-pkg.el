;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260320.159"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "bb7520e8a1c0a13224515c9358c857ad972a0e72"
  :revdesc "bb7520e8a1c0"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
