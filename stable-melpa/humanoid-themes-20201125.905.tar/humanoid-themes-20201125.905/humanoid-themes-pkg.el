(define-package "humanoid-themes" "20201125.905" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "71fa593d43c1b199d0ea2dc5f10ef00a78883282" :keywords
  ("faces" "color" "theme")
  :authors
  (("Thomas Friese"))
  :maintainer
  ("Thomas Friese")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
