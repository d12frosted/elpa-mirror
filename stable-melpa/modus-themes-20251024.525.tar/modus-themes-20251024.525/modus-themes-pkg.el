;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251024.525"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "21327092f012c54c3f22a62fce63a2010c678d39"
  :revdesc "21327092f012"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
