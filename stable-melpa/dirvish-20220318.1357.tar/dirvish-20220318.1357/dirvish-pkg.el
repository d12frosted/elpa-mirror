(define-package "dirvish" "20220318.1357" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "c3102b42673e8df6035a9172c260c94754d6ded1" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
