;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260411.2204"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "54126e3a92b345e68de2c481ebed6fdd2656a8df"
  :revdesc "54126e3a92b3"
  :keywords '("comm"))
