;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251124.742"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "7a4bd1d4cb06278aca76e0cce0b1b207df365bca"
  :revdesc "7a4bd1d4cb06"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
