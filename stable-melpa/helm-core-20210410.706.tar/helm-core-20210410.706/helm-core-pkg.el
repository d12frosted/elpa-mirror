(define-package "helm-core" "20210410.706" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "baebdbf52e9efb1100b99a51cbe7acdc5c5346da")
;; Local Variables:
;; no-byte-compile: t
;; End:
