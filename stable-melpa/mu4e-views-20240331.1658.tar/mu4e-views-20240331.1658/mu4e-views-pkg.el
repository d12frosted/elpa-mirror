(define-package "mu4e-views" "20240331.1658" "View emails in mu4e using xwidget-webkit"
  '((emacs "26.1")
    (xwidgets-reuse "0.3")
    (ht "2.2")
    (esxml "20210323.1102"))
  :commit "3bb50720b85e916087d8334749d44dc83d7e6e82" :authors
  '(("Boris Glavic" . "lordpretzel@gmail.com"))
  :maintainers
  '(("Boris Glavic" . "lordpretzel@gmail.com"))
  :maintainer
  '("Boris Glavic" . "lordpretzel@gmail.com")
  :keywords
  '("mail")
  :url "https://github.com/lordpretzel/mu4e-views")
;; Local Variables:
;; no-byte-compile: t
;; End:
