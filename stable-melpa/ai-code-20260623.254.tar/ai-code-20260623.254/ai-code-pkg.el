;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260623.254"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "75648e981d433758e9271a671a43af102642f55f"
  :revdesc "75648e981d43"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
