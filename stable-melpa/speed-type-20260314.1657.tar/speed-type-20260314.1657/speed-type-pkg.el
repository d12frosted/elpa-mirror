;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260314.1657"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "ac58e4c6b00388617abb744acf5c71693ef40731"
  :revdesc "ac58e4c6b003"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
