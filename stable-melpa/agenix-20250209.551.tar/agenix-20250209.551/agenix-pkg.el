;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agenix" "20250209.551"
  "Decrypt and encrypt agenix secrets."
  '((emacs "27.1"))
  :url "https://github.com/t4ccer/agenix.el"
  :commit "36ad60f0b7f2a12b730c6f568fcfd4daf2581158"
  :revdesc "36ad60f0b7f2"
  :authors '(("Tomasz Maciosowski" . "t4ccer@gmail.com"))
  :maintainers '(("Tomasz Maciosowski" . "t4ccer@gmail.com")))
