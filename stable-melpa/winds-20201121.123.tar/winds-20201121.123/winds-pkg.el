;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winds" "20201121.123"
  "Window configuration switcher grouped by workspaces."
  '((emacs "25.1"))
  :url "https://github.com/Javyre/winds.el"
  :commit "5827e890059d0ce67ebb4779da63c15afccf0973"
  :revdesc "5827e890059d"
  :keywords '("convenience")
  :authors '(("Javier A. Pollak" . "javi.po.123@gmail.com"))
  :maintainers '(("Javier A. Pollak" . "javi.po.123@gmail.com")))
