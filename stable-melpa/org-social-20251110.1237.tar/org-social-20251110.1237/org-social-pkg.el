;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251110.1237"
  "An Org-social client."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "bc3a4ba29afac6f327b4bc58e49b60baac0bdb18"
  :revdesc "bc3a4ba29afa"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
