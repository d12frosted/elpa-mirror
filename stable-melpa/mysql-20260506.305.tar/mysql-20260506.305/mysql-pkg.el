;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20260506.305"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "3fcb8659e106fc437d7b99dec53451e7e6ebcf81"
  :revdesc "3fcb8659e106"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
