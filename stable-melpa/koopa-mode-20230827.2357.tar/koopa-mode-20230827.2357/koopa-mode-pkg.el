(define-package "koopa-mode" "20230827.2357" "A major mode for Microsoft PowerShell"
  '((company "0.9.13")
    (emacs "27.1"))
  :commit "f8ec7fb56b1b5c387bfe8fd17680fd659cb76eeb" :authors
  '(("Tyler Hooks"))
  :maintainers
  '(("Tyler Hooks"))
  :maintainer
  '("Tyler Hooks")
  :keywords
  '("powershell" "convenience")
  :url "https://github.com/sch0lars/koopa-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
