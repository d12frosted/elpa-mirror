;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250318.1541"
  "Interact with Aider: AI pair programming made simple."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "6037f7b334a733a0261e3252d2347ecc0d1bca2b"
  :revdesc "6037f7b334a7"
  :keywords '("convenience" "tools")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
