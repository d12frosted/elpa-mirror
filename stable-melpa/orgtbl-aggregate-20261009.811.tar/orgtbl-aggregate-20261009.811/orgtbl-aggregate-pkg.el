;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20261009.811"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "0aa4a7e84f1f6df9da69eac5453bee2b60c469ef"
  :revdesc "0aa4a7e84f1f"
  :keywords '("data" "extensions"))
