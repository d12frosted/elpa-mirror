;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "20260127.1319"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "106addd64c9e005972cc498a6ce82805167a95da"
  :revdesc "106addd64c9e"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
