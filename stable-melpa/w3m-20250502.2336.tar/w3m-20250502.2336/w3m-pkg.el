;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "w3m" "20250502.2336"
  "An Emacs interface to w3m."
  ()
  :url "https://github.com/emacs-w3m/emacs-w3m"
  :commit "fd3bd9ec2a3daba46a478365ac5a9769b9483481"
  :revdesc "fd3bd9ec2a3d"
  :keywords '("w3m" "www" "hypermedia"))
