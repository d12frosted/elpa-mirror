(define-package "brutalist-theme" "20230902.932" "Brutalist theme" 'nil :commit "e34b31937092a7c1ac13ff94bccbae28280fba77" :authors
  '(("Gergely Nagy"))
  :maintainers
  '(("Gergely Nagy"))
  :maintainer
  '("Gergely Nagy")
  :url "https://git.madhouse-project.org/algernon/brutalist-theme.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
