;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emacsc" "20260909.242"
  "Helper for emacsc(1)."
  ()
  :url "https://github.com/knu/emacsc"
  :commit "21dc5f44220a3df33cecb76c2521ea6ff4481d19"
  :revdesc "21dc5f44220a"
  :keywords '("tools")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
