(define-package "macports" "20220728.1243" "A porcelain for MacPorts"
  '((emacs "25.1")
    (transient "0.1.0"))
  :commit "8f9c831f68dc050cb081b6c2ac3223f4a4ad8852" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("convenience")
  :url "https://github.com/amake/macports.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
