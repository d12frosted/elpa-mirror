;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperdrive" "20241023.400"
  "P2P filesystem."
  '((emacs              "28.1")
    (map                "3.0")
    (compat             "30.0.0.0")
    (org                "9.7.6")
    (plz                "0.9.1")
    (persist            "0.6.1")
    (taxy-magit-section "0.14")
    (transient          "0.7.7"))
  :url "https://git.sr.ht/~ushin/hyperdrive.el"
  :commit "02747fcd3a27883e37dbb7721fd3e6922e9b6e4e"
  :revdesc "02747fcd3a27"
  :authors '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht")))
