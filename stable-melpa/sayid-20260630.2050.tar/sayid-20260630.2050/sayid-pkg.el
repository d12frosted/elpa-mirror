;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sayid" "20260630.2050"
  "Sayid nREPL middleware client."
  '((emacs "28")
    (cider "1.23"))
  :url "https://github.com/clojure-emacs/sayid"
  :commit "774195ba4bee8feaa5b1aae40ea768a2364bd131"
  :revdesc "774195ba4bee"
  :keywords '("clojure" "cider" "debugger")
  :authors '(("Bill Piel" . "bill@billpiel.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
