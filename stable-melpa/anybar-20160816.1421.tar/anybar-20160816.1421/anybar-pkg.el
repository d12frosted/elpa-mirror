;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anybar" "20160816.1421"
  "Control AnyBar from Emacs."
  ()
  :url "https://github.com/tie-rack/anybar-el"
  :commit "7a0743e0d31bcb36ab1bb2e351f3e7139c422ac5"
  :revdesc "7a0743e0d31b"
  :keywords '("anybar")
  :authors '(("Christopher Shea" . "cmshea@gmail.com"))
  :maintainers '(("Christopher Shea" . "cmshea@gmail.com")))
