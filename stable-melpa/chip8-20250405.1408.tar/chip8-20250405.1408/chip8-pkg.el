;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chip8" "20250405.1408"
  "A CHIP-8 emulator."
  '((emacs "28.1"))
  :url "https://github.com/gabrielelana/chip8.el"
  :commit "e2d0131dc45e65151f9655833807fbe838267dbd"
  :revdesc "e2d0131dc45e"
  :keywords '("chip-8" "game" "games" "emulator")
  :authors '(("Gabriele Lana" . "gabriele.lana@gmail.com"))
  :maintainers '(("Gabriele Lana" . "gabriele.lana@gmail.com")))
