(define-package "embark" "20211224.158" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "407ce267c34d44a35c403ea73512e4abb5c63cf9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
