;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260309.955"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.87.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e877ecf97a6783618a550aa0b33f20ea6527a52c"
  :revdesc "e877ecf97a67")
