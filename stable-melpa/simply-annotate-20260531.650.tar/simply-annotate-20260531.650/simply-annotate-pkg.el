;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260531.650"
  "Enhanced annotation system with threading."
  '((emacs     "27.2")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "fd55a741c88cf22453e95ae20116e0de6ffc9f48"
  :revdesc "fd55a741c88c"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
