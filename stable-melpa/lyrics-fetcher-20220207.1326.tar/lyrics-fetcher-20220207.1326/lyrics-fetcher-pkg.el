(define-package "lyrics-fetcher" "20220207.1326" "Fetch song lyrics and album covers"
  '((emacs "27")
    (emms "7.5")
    (f "0.20.0")
    (request "0.3.2"))
  :commit "06bd0293dfa759df48faefd73be60d43d1febd17" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/lyrics-fetcher.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
