(define-package "jq-ts-mode" "20231025.2319" "Tree-sitter support for jq buffers"
  '((emacs "29.1"))
  :commit "b1abef71843dd99349133a75245804aee503c05d" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("jq" "languages" "tree-sitter")
  :url "https://github.com/nverno/jq-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
