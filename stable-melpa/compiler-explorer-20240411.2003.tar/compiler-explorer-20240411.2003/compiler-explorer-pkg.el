(define-package "compiler-explorer" "20240411.2003" "Compiler explorer client (godbolt.org)"
  '((emacs "26.1")
    (request "0.3.0")
    (eldoc "1.15.0"))
  :commit "f45d71895daca52f656edf1a35b2e283eb2c46d6" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("c" "tools")
  :url "https://github.com/mkcms/compiler-explorer.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
