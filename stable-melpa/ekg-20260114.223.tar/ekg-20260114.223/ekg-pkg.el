;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260114.223"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "893f51cd93e0b2d8be6df83db0348d4a77b5204a"
  :revdesc "893f51cd93e0"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
