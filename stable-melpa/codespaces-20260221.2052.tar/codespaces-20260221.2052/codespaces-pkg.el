;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260221.2052"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "fcdf8f0e888dfb5601d91584fe9b70654cde10d8"
  :revdesc "fcdf8f0e888d"
  :keywords '("comm")
  :authors '(("Patrick Thomson" . "patrickt@github.com"))
  :maintainers '(("Patrick Thomson" . "patrickt@github.com")))
