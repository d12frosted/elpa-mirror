;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251223.1911"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "e66a4212f52811ceffdb1fdbe4ce9c06cdd213a8"
  :revdesc "e66a4212f528"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
