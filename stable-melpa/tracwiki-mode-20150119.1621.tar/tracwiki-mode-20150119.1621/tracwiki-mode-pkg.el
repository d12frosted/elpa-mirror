;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tracwiki-mode" "20150119.1621"
  "Emacs Major mode for working with Trac."
  '((xml-rpc "1.6.8"))
  :url "https://github.com/merickson/tracwiki-mode"
  :commit "6a620444d59b438f42383b48cd4c19c03105dba6"
  :revdesc "6a620444d59b"
  :keywords '("trac" "wiki" "tickets")
  :authors '(("Matthew Erickson" . "peawee@peawee.net"))
  :maintainers '(("Matthew Erickson" . "peawee@peawee.net")))
