;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-index" "20260708.2048"
  "Index for zk."
  '((emacs "28.1")
    (zk    "0.9"))
  :url "https://github.com/localauthor/zk"
  :commit "3ecb5ac3c56f8727c99458b6d3ad8e2c7df25348"
  :revdesc "3ecb5ac3c56f"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
