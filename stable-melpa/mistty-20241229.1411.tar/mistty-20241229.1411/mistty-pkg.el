;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241229.1411"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "4d046c148bb2d099a7a0f88909f027bd322836a3"
  :revdesc "4d046c148bb2"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
