;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20261114.2147"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "c643ad9ab33d0d4c0cd5c920beac92f7c9e53691"
  :revdesc "c643ad9ab33d"
  :keywords '("languages"))
