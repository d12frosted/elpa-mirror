;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "es-windows" "20140211.904"
  "Window-management utilities."
  '((cl-lib "0.3")
    (emacs  "24"))
  :url "https://github.com/sabof/es-windows"
  :commit "7ebe6c6e0831373847d7adbedeaa2e506b54b2af"
  :revdesc "7ebe6c6e0831")
