(define-package "fanyi" "20210828.1906" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "ea86bc54c515064321d98107cbaa3dbbf649c874" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
