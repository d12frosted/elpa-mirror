;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260425.1808"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "28.2")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "02170f7343dcc6e6390fbb076620f64a7847ab72"
  :revdesc "02170f7343dc"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
