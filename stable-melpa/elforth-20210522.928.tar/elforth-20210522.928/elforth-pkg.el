;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elforth" "20210522.928"
  "Do you have what it takes to hack Emacs Lisp in Forth?."
  '((emacs "26.1"))
  :url "https://github.com/lassik/elforth"
  :commit "2d8540434a28e7edaa04a992c3c362832b2fd61e"
  :revdesc "2d8540434a28"
  :keywords '("games")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
