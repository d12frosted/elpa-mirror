;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20260111.1120"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "166da1cd3388c8dbbe0d514b3a1fe8397630d8d5"
  :revdesc "166da1cd3388"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
