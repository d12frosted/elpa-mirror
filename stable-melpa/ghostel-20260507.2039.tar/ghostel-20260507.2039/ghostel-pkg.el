;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260507.2039"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "e6773436994c08a0b2d7a5037752d5007c52ff3f"
  :revdesc "e6773436994c"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
