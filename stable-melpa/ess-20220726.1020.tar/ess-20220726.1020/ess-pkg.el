(define-package "ess" "20220726.1020" "Emacs Speaks Statistics"
  '((emacs "25.1"))
  :commit "238546eae3a4cfc9db9f43dbfa0c3c908ee57a1a" :authors
  '(("David Smith" . "dsmith@stats.adelaide.edu.au")
    ("A.J. Rossini" . "blindglobe@gmail.com")
    ("Richard M. Heiberger" . "rmh@temple.edu")
    ("Kurt Hornik" . "Kurt.Hornik@R-project.org")
    ("Martin Maechler" . "maechler@stat.math.ethz.ch")
    ("Rodney A. Sparapani" . "rsparapa@mcw.edu")
    ("Stephen Eglen" . "stephen@gnu.org")
    ("Sebastian P. Luque" . "spluque@gmail.com")
    ("Henning Redestig" . "henning.red@googlemail.com")
    ("Vitalie Spinu" . "spinuvit@gmail.com")
    ("Lionel Henry" . "lionel.hry@gmail.com")
    ("J. Alexander Branham" . "alex.branham@gmail.com"))
  :maintainer
  '("ESS Core Team" . "ESS-core@r-project.org")
  :url "https://ess.r-project.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
