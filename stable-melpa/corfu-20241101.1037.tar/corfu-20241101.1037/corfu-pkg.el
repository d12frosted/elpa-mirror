;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20241101.1037"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "16d5aef839477ac54790fb797c1e85dfdbbd313f"
  :revdesc "16d5aef83947"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
