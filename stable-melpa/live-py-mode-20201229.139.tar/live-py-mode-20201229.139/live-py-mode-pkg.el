(define-package "live-py-mode" "20201229.139" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "40a5c9cef3ecae289fef73d76d0e3fd006051a21" :authors
  (("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  ("Don Kirkby http://donkirkby.github.io")
  :keywords
  ("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
