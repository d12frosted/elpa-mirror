;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260620.826"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "02c1a4c0c69ed48829610259fe6d8c7342117270"
  :revdesc "02c1a4c0c69e"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
