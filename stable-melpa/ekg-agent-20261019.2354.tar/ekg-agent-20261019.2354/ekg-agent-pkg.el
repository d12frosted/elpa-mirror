;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20261019.2354"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.10.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "3ac9365d2fb0fc27a4ec03f7ac2608a82bf696f4"
  :revdesc "3ac9365d2fb0"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
