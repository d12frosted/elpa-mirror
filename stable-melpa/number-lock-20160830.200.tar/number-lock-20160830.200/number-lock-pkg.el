;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "number-lock" "20160830.200"
  "Enter symbols on your number keys without pressing shift."
  ()
  :url "https://github.com/Liu233w/number-lock.el"
  :commit "1ac1b1a269128ddac820df7d45a8d0c703e9c05c"
  :revdesc "1ac1b1a26912"
  :keywords '("convenience")
  :authors '(("Liu233w" . "wwwlsmcom@outlook.com"))
  :maintainers '(("Liu233w" . "wwwlsmcom@outlook.com")))
