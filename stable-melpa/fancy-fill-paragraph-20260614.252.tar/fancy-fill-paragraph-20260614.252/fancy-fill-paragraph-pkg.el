;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-fill-paragraph" "20260614.252"
  "Fancy paragraph fill."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-fancy-fill-paragraph"
  :commit "cda12c7f5815bf5c8a94e98fc3f0b50f7d26ea41"
  :revdesc "cda12c7f5815"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
