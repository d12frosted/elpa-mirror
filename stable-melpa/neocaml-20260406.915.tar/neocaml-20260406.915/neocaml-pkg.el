;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260406.915"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "625d48b841b98d447a12a1e9eb841c14ade90335"
  :revdesc "625d48b841b9"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
