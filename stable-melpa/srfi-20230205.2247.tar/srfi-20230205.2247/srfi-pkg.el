(define-package "srfi" "20230205.2247" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "7e92ae3b4c4a7f3386bf1d7d620e5cd29e6e3b37" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
