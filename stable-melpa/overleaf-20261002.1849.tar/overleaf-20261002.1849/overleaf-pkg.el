;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20261002.1849"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "3bd7bc03059212a2da6fe7eabeaaec9536281803"
  :revdesc "3bd7bc030592"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
