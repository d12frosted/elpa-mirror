;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20260901.1523"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "2db35e246ef1cbf8d24c3b7c64a3f68959c3c7d9"
  :revdesc "2db35e246ef1"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
