(define-package "embark" "20230128.2006" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "3978c66c055632430d8351a32f84e72c9c3d9357" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
