;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250515.1501"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.8.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "5c68e57e39eba38a8a278bf843facb08ba8f2f59"
  :revdesc "5c68e57e39eb"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
