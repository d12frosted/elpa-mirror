;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zk-luhmann" "20250406.844"
  "Support for Luhmann-style IDs in zk."
  '((emacs    "25.1")
    (zk       "0.7")
    (zk-index "0.10"))
  :url "https://github.com/localauthor/zk-luhmann"
  :commit "1fe0d9053b603037898530ae8aa6361c4e409e46"
  :revdesc "1fe0d9053b60"
  :authors '(("Grant Rosson" . "https://github.com/localauthor"))
  :maintainers '(("Grant Rosson" . "https://github.com/localauthor")))
