;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20250516.1720"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "330e77c247881429cb67b54547ec6772bf3adb0c"
  :revdesc "330e77c24788"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
