;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260106.846"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "d6667354b87de12db24a9733853dd32a77b2e361"
  :revdesc "d6667354b87d"
  :keywords '("convenience" "input method" "dbus"))
