(define-package "sis" "20231028.925" "Less manual switch for native or OS input source (input method)."
  '((emacs "25.1")
    (terminal-focus-reporting "0.0"))
  :commit "aac92f20e897985ffd52b61edcffaf89354b8be1" :keywords
  '("convenience")
  :url "https://github.com/laishulu/emacs-smart-input-source")
;; Local Variables:
;; no-byte-compile: t
;; End:
