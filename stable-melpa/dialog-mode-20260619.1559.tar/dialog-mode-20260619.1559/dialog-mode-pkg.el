;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260619.1559"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "e092fe2c3915e28ae9151f856d340c2ba17ecb68"
  :revdesc "e092fe2c3915"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
