;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250503.1340"
  "Ollama LLM AI Assistant with ChatGPT, Claude, Gemini and Grok Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "139aa7a0a9181ef93999738f40e1aed5294a9bc7"
  :revdesc "139aa7a0a918"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
