(define-package "catppuccin-theme" "20230602.1145" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "bb95920dadaf580bb6ec2461192b946c2f823a24" :authors
  '(("nyxkrage"))
  :maintainers
  '(("Carsten Kragelund" . "carsten@kragelund.me"))
  :maintainer
  '("Carsten Kragelund" . "carsten@kragelund.me")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
