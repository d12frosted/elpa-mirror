;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-company" "20250616.617"
  "Magik backend for company-mode."
  '((emacs      "29.1")
    (magik-mode "0.4.1")
    (company    "1.0.2")
    (yasnippet  "0.14.0"))
  :url "https://github.com/reinierkof/magik-company"
  :commit "dccabc933d4cb2cad1807d7ec643e1536da70d53"
  :revdesc "dccabc933d4c"
  :keywords '("convenience")
  :authors '(("Reinier Koffijberg" . "reinierkof@gmail.com"))
  :maintainers '(("Reinier Koffijberg" . "reinierkof@gmail.com")))
