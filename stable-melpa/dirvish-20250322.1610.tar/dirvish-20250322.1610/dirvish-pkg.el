;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250322.1610"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "2f7887d270e99f974d334e0dc59dc0d4021a633c"
  :revdesc "2f7887d270e9"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
