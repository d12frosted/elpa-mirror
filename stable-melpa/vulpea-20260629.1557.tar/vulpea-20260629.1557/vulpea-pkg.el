;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260629.1557"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "26570ee868244f70bad8e0f7df19517118d00934"
  :revdesc "26570ee86824"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
