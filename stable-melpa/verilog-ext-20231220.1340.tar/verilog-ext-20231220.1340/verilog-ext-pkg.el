(define-package "verilog-ext" "20231220.1340" "SystemVerilog Extensions"
  '((emacs "29.1")
    (verilog-mode "2023.6.6.141322628")
    (verilog-ts-mode "0.1.1")
    (lsp-mode "8.0.0")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (apheleia "3.1")
    (yasnippet "0.14.0")
    (flycheck "32")
    (outshine "3.0.1")
    (async "1.9.7"))
  :commit "ea437a71eadb610399b1dae2b80d7ae266441d73" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
