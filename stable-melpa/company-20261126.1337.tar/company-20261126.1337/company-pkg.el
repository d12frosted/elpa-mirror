;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20261126.1337"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "194eabe9ee43e4b1911dd842070cb50e4a67d741"
  :revdesc "194eabe9ee43"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
