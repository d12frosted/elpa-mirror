;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260524.1531"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b9a1d653974b0111f177e240fcb21eb7e8ec51d1"
  :revdesc "b9a1d653974b")
