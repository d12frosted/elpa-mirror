(define-package "rom-party" "20240324.909" "Rendition of jklm.fun's \"Bomb Party\" game"
  '((emacs "28")
    (dash "2.17.0")
    (f "0.2.0")
    (s "1.12.0")
    (ht "2.3")
    (extmap "1.3")
    (compat "29.1.4.4")
    (async "1.9.7"))
  :commit "e4e8f113b370ceaed0ea28940117bd69f3d3f935" :url "https://github.com/LaurenceWarne/rom-party.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
