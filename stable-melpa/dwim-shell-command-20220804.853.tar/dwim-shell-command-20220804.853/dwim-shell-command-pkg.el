(define-package "dwim-shell-command" "20220804.853" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "8627205f00f4e2eed9607cf80ba116d1c3efae08" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
