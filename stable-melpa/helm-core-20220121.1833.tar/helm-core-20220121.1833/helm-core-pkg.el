(define-package "helm-core" "20220121.1833" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "dd13f19eba2c0206d94b7dd2b171f72bfdb14586")
;; Local Variables:
;; no-byte-compile: t
;; End:
