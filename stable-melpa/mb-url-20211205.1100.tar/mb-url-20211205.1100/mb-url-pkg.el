(define-package "mb-url" "20211205.1100" "Multiple Backends for Emacs URL package"
  '((emacs "25"))
  :commit "59f58a7e236329e14229b0a9f59766f829336b93" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
