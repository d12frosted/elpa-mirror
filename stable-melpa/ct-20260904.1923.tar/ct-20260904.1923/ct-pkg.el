;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ct" "20260904.1923"
  "Color Tools - a color api."
  '((emacs "26.1")
    (dash  "2.18.0")
    (hsluv "1.0.0"))
  :url "https://github.com/neeasade/ct.el"
  :commit "ffa4dc1789a404e92941b7721009b1facad49ac3"
  :revdesc "ffa4dc1789a4"
  :keywords '("convenience" "color" "theming" "background" "rgb" "hsv" "hsl" "hct" "lab" "oklab" "oklch"))
