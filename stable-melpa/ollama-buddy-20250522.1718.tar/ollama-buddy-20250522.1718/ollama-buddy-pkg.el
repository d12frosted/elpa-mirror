;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250522.1718"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "fcc14be96f7b33523172c50ed236f6d78f65aa67"
  :revdesc "fcc14be96f7b"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
