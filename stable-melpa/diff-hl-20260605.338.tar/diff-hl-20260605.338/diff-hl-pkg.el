;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260605.338"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "26.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "ca4391f09e849ffc1c86c4a7ee8a097a838f1cc5"
  :revdesc "ca4391f09e84"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
