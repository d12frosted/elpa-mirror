(define-package "stimmung-themes" "20210610.1256" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "e69b7532ceb27126fb9516c9a8aff652b032088a" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
