;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260301.2200"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "0237787631cbbc733384ad6d83a0ec1108182795"
  :revdesc "0237787631cb"
  :keywords '("files"))
