;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-fdclone" "20241201.1403"
  "Dired functions and settings to mimic FDclone."
  ()
  :url "https://github.com/knu/dired-fdclone.el"
  :commit "57b310d10afe62162ad0141ce43be3d286d01160"
  :revdesc "57b310d10afe"
  :keywords '("unix" "directories" "dired")
  :authors '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers '(("Akinori MUSHA" . "knu@iDaemons.org")))
