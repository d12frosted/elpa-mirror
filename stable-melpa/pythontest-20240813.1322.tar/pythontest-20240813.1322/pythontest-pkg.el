;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pythontest" "20240813.1322"
  "Testing executor for python."
  '((emacs "29.1"))
  :url "https://github.com/erickgnavar/pythontest.el"
  :commit "4bb4f330c13ef82bb6e4a4b15c47cb3fede83523"
  :revdesc "4bb4f330c13e"
  :authors '(("Erick Navarro" . "erick@navarro.io"))
  :maintainers '(("Erick Navarro" . "erick@navarro.io")))
