(define-package "jquery-doc" "20150812.758" "jQuery api documentation interface for emacs" 'nil :commit "24032284919b942ec27707d929bdd8bf48420062" :keywords
  ("docs" "jquery")
  :authors
  (("Anantha kumaran" . "ananthakumaran@gmail.com"))
  :maintainer
  ("Anantha kumaran" . "ananthakumaran@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
