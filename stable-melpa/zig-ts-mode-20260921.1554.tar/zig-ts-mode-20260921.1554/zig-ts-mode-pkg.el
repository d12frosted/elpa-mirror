;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zig-ts-mode" "20260921.1554"
  "Major mode for Zig code."
  '((emacs "30.1"))
  :url "https://codeberg.org/meow_king/zig-ts-mode"
  :commit "004cb409c129f28ce4cf73f0080782f08d1dc724"
  :revdesc "004cb409c129"
  :keywords '("zig" "languages" "tree-sitter")
  :authors '(("meowking" . "mr.meowking@tutamail.com"))
  :maintainers '(("meowking" . "mr.meowking@tutamail.com")))
