;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260529.1928"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "61a81a5375377e1616318797a00be7a36071ac56"
  :revdesc "61a81a537537"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
