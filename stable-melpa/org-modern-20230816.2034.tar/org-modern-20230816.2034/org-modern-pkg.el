(define-package "org-modern" "20230816.2034" "Modern looks for Org"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "905a601796d02283e94a603b6011a537ee7e6090" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "wp")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
