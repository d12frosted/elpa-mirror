(define-package "tempel-collection" "20230302.813" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "6abf8a8c2e6587c061c991f508d7f38288074563" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
