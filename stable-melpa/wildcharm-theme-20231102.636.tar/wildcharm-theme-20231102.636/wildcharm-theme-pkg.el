(define-package "wildcharm-theme" "20231102.636" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "d33441315311692df37e059fa2e95934e81ffec2" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
