;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "atl-long-lines" "20240101.929"
  "Turn off truncate-lines when the line is long."
  '((emacs "24.3"))
  :url "https://github.com/jcs-elpa/atl-long-lines"
  :commit "82cdd4edefba2d5b1d491bf3fcc487385819d713"
  :revdesc "82cdd4edefba"
  :keywords '("convenience" "truncate" "lines" "auto" "long")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
