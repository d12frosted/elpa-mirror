(define-package "emms" "20230727.1543" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (seq "0"))
  :commit "8ad5cf981b24cd9c7748232a843fafd2d62f6e15" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers
  '(("Yoni Rabkin" . "yrk@gnu.org"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
