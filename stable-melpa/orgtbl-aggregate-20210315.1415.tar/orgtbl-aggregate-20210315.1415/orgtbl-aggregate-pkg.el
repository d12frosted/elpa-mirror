(define-package "orgtbl-aggregate" "20210315.1415" "Create an aggregated Org table from another one" 'nil :commit "5156a0eda269f2997b5947c4ea77f771d1662f42" :keywords
  '("org" "table" "aggregation" "filtering"))
;; Local Variables:
;; no-byte-compile: t
;; End:
