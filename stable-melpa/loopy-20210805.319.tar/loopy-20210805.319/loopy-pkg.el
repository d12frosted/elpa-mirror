(define-package "loopy" "20210805.319" "A looping macro" 'nil :commit "0b2120d8e8752fca50d76d17d8edc7a24bbf0ff5" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
