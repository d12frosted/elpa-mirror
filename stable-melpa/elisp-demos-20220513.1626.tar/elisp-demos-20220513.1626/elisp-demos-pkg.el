(define-package "elisp-demos" "20220513.1626" "Elisp API Demos"
  '((emacs "24.4"))
  :commit "01c301b516e9949d0239d20f6834afbc9acf0abb" :authors
  '(("Xu Chunyang"))
  :maintainer
  '("Xu Chunyang")
  :keywords
  '("lisp" "docs")
  :url "https://github.com/xuchunyang/elisp-demos")
;; Local Variables:
;; no-byte-compile: t
;; End:
