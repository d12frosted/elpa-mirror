(define-package "kiwix" "20201219.720" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (cl-lib "0.5")
    (request "0.3.0"))
  :commit "2619c658478e5e9d94f2b4e9daf66b16e9cdb805" :keywords
  ("kiwix" "wikipedia")
  :authors
  (("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  ("stardiviner" . "numbchild@gmail.com")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
