(define-package "org-treeusage" "20200418.1904" "Examine the usage of org headings in a tree-like manner"
  '((emacs "26.1")
    (dash "2.17.0")
    (org "9.1.6"))
  :commit "f2d3e5cfac135dea304a3f75711520b0d80fc847" :authors
  '(("Mehmet Tekman"))
  :maintainer
  '("Mehmet Tekman")
  :keywords
  '("outlines")
  :url "https://github.com/mtekman/org-treeusage.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
