;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-section" "20250610.1113"
  "Sections for read-only buffers."
  '((emacs  "27.1")
    (compat "30.1")
    (llama  "0.6.3")
    (seq    "2.24"))
  :url "https://github.com/magit/magit"
  :commit "925762e957c31e8bdf9e5630d2d99e98e4dc3abe"
  :revdesc "925762e957c3"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.magit@jonas.bernoulli.dev")))
