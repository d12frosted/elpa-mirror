;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "batppuccin" "20260703.608"
  "Batppuccin (Catppuccin) color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/batppuccin-emacs"
  :commit "5fc17c1c403bed4b7728ee0afbb4563749fd381d"
  :revdesc "5fc17c1c403b"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
