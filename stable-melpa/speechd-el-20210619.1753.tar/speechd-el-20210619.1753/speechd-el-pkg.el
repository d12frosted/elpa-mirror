(define-package "speechd-el" "20210619.1753" "Client to speech synthesizers and Braille displays." 'nil :commit "bd21335668ac7ea4d8c992490b4a710053434e74")
;; Local Variables:
;; no-byte-compile: t
;; End:
