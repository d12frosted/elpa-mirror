;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emms" "20241209.2052"
  "The Emacs Multimedia System."
  '((cl-lib  "0.5")
    (nadvice "0.3")
    (seq     "0"))
  :url "https://git.savannah.gnu.org/git/emms.git"
  :commit "15707954561aab8331ae438de372dbf4a7d78373"
  :revdesc "15707954561a"
  :keywords '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :authors '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers '(("Yoni Rabkin" . "yrk@gnu.org")))
