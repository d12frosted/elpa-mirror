(define-package "wordel" "20220508.1745" "An Elisp implementation of \"Wordle\" (aka \"Lingo\")"
  '((emacs "27.1"))
  :commit "d37187bb5abb2fe4a8ba120fad9e52dd74cc220e" :authors
  '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com"))
  :maintainer
  '("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/progfolio/wordel")
;; Local Variables:
;; no-byte-compile: t
;; End:
