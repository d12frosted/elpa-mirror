(define-package "shanty-themes" "20220403.2333" "The themes for digital workers"
  '((emacs "27.2"))
  :commit "a5586a4f76298fb5f7b73007586b6ae9c7d9418e" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
