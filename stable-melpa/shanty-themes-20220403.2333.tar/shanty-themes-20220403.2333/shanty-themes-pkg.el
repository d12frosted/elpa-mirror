(define-package "shanty-themes" "20220403.2333" "The themes for digital workers"
  '((emacs "27.2"))
  :commit "404e721e0cb5dbf813bebc997f9c10623b101c4b" :authors
  '(("Philip Gaber" . "phga@posteo.de"))
  :maintainer
  '("Philip Gaber" . "phga@posteo.de")
  :keywords
  '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :url "https://github.com/qhga/shanty-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
