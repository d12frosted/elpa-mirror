;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251027.2101"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "cbfddd0c5b206d30a123ca4116e58094594b5428"
  :revdesc "cbfddd0c5b20"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
