(define-package "wildcharm-light-theme" "20231117.1137" "Port of vim-wildcharm (light) colorscheme"
  '((emacs "24.1"))
  :commit "db56e01d0740651421680e9e1d8a5000e485dcd7" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
