(define-package "emms" "20231017.1836" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (seq "0"))
  :commit "06d85d52b26accf3e42467214b9dfff9151fcd5d" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainers
  '(("Yoni Rabkin" . "yrk@gnu.org"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
