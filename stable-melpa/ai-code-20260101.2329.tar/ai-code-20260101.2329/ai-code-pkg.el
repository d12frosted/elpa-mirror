;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260101.2329"
  "Unified interface for multiple AI coding CLI tool."
  '((emacs     "26.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "c803e0cc43e89edd84cc40ea5dbf91b21bf124df"
  :revdesc "c803e0cc43e8"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
