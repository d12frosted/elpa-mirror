;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "disproject" "20241125.1814"
  "Dispatch project commands with Transient."
  '((emacs     "29.4")
    (transient "0.7.8"))
  :url "https://github.com/aurtzy/disproject"
  :commit "a8ca923a9fd53dfa4edefd6eea7f79139d085f24"
  :revdesc "a8ca923a9fd5"
  :keywords '("convenience" "files" "vc")
  :authors '(("aurtzy" . "aurtzy@gmail.com"))
  :maintainers '(("aurtzy" . "aurtzy@gmail.com")))
