;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20260413.1507"
  "Light cornsilk theme with warm, earthy colors."
  '((emacs        "28.1")
    (modus-themes "5.0.0"))
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "8f976f810e6f23d2afaaa13f53e11d73e941cbcf"
  :revdesc "8f976f810e6f"
  :keywords '("faces" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
