(define-package "metrics-tracker" "20221030.42" "Generate reports of personal metrics from diary entries"
  '((emacs "24.4")
    (seq "2.3"))
  :commit "ace35dfb6d00749a24993f3fb8f838938826b45e" :authors
  '(("Ian Martins" . "ianxm@jhu.edu"))
  :maintainers
  '(("Ian Martins" . "ianxm@jhu.edu"))
  :maintainer
  '("Ian Martins" . "ianxm@jhu.edu")
  :keywords
  '("calendar")
  :url "https://github.com/ianxm/emacs-tracker")
;; Local Variables:
;; no-byte-compile: t
;; End:
