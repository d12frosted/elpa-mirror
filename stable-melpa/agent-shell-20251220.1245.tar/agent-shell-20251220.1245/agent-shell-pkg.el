;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251220.1245"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a725f9da41a5af27e7fda99da20311d0697eee2c"
  :revdesc "a725f9da41a5")
