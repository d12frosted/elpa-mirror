;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dpkg-dev-el" "20260326.2334"
  "Startup file for the elpa-dpkg-dev-el package."
  '((emacs     "27.1")
    (debian-el "37.0"))
  :commit "f65f60feb19357196594a09ce9fe23da9291cef0"
  :revdesc "f65f60feb193"
  :authors '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers '(("Peter S Galbraith" . "psg@debian.org")))
