(define-package "consult" "20220420.2202" "Consulting completing-read"
  '((emacs "27.1"))
  :commit "69bba57ad7a7943b413a2bdbb41c15ee06a027a6" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
