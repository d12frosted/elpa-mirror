;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250920.927"
  "Consulting completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "13c940db9b6ae34ba61f4081f82c84b83da18dcb"
  :revdesc "13c940db9b6a"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
