(define-package "merlin" "20210129.1443" "Mode for Merlin, an assistant for OCaml." 'nil :commit "4cd797181fcaf0504aeb0fcc804822bfe37c18d6" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
