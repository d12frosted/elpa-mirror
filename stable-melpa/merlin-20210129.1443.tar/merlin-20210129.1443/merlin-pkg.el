(define-package "merlin" "20210129.1443" "Mode for Merlin, an assistant for OCaml." 'nil :commit "36d0aefcecdd69e201f69a55b53b51709cdaf6b4" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
