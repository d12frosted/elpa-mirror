(define-package "merlin" "20210129.1443" "Mode for Merlin, an assistant for OCaml." 'nil :commit "a11b2a35c2f96fd59a5ea67bee87b7e9809137f1" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
