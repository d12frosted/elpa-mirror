(define-package "expenses" "20230503.622" "Record and view expenses"
  '((emacs "28.1")
    (dash "2.19.1")
    (ht "2.3"))
  :commit "4b3e5839cb70e44bb6db20b2826c4cb41d01c33f" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("expense tracking" "convenience")
  :url "https://github.com/md-arif-shaikh/expenses")
;; Local Variables:
;; no-byte-compile: t
;; End:
