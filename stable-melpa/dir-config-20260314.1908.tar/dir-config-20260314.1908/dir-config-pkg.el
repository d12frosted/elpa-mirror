;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "20260314.1908"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "e2168cb2da83b36d071efec3d4e2ee42a599ed36"
  :revdesc "e2168cb2da83"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
