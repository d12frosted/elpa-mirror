(define-package "org-caldav" "20230708.134" "Sync org files with external calendar through CalDAV"
  '((emacs "26.3")
    (org "9.1"))
  :commit "f6bf3c402918d0a5f958a7d18e86ad9df2e4a9bc" :authors
  '(("David Engster" . "deng@randomsample.de"))
  :maintainers
  '(("David Engster" . "deng@randomsample.de"))
  :maintainer
  '("David Engster" . "deng@randomsample.de")
  :keywords
  '("calendar" "caldav")
  :url "https://github.com/dengste/org-caldav/")
;; Local Variables:
;; no-byte-compile: t
;; End:
