(define-package "elsa" "20230207.1358" "Emacs Lisp Static Analyser"
  '((trinary "1.0.0")
    (emacs "25.1")
    (seq "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3"))
  :commit "d058d568a344b4b198e4289df27b521857779780" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
