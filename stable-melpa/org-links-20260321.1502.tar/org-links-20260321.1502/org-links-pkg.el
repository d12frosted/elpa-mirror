;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260321.1502"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "c7a805a19c6ce967daebd80ff269c438059d1a38"
  :revdesc "c7a805a19c6c"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
