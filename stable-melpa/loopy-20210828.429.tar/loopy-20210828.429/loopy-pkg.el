(define-package "loopy" "20210828.429" "A looping macro"
  '((emacs "27.1")
    (map "3.0"))
  :commit "24910b119b9e45a63d398caae256e46e656aca37" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
