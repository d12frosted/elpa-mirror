(define-package "run-command-recipes" "20230521.1950" "This is collection of recipes to `run-command'"
  '((emacs "25.1")
    (dash "2.18.0")
    (f "0.20.0")
    (run-command "0.1.0"))
  :commit "c1fef8edcb23e184ea94905b3f4e1dc34c52691a" :authors
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainers
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainer
  '("semenInRussia" . "hrams205@gmail.com")
  :keywords
  '("extensions" "run-command")
  :url "https://github.com/semenInRussia/emacs-run-command-recipes")
;; Local Variables:
;; no-byte-compile: t
;; End:
