;;; erlang-test.el -*- lexical-binding: t; coding: utf-8-unix -*-

;; %CopyrightBegin%
;;
;; SPDX-License-Identifier: Apache-2.0
;;
;; Copyright Ericsson AB 2016-2025. All Rights Reserved.
;;
;; Licensed under the Apache License, Version 2.0 (the "License");
;; you may not use this file except in compliance with the License.
;; You may obtain a copy of the License at
;;
;;     http://www.apache.org/licenses/LICENSE-2.0
;;
;; Unless required by applicable law or agreed to in writing, software
;; distributed under the License is distributed on an "AS IS" BASIS,
;; WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
;; See the License for the specific language governing permissions and
;; limitations under the License.
;;
;; %CopyrightEnd%

;;; Unit tests for erlang.el.

;; Author: Johan Claesson
;; Created: 2016-05-07
;; Keywords: erlang, languages

;;; Commentary:

;; This library require GNU Emacs 25 or later.
;;
;; There are three ways to run the erlang emacs unit tests.
;;
;; 1. Within a running emacs process.  Load this file.  Then to run
;; all defined test cases:
;;
;; M-x ert RET t RET
;;
;; To run only the erlang test cases:
;;
;; M-x ert RET "^erlang" RET
;;
;;
;; 2. In a new stand-alone emacs process.  This process exits
;; when it executed the tests.  For example:
;;
;; emacs -Q -batch -L . -l erlang.el -l erlang-test.el \
;;       -f ert-run-tests-batch-and-exit
;;
;; The -L option adds a directory to the load-path.  It should be the
;; directory containing erlang.el and erlang-test.el.
;;
;; 3. Run the emacs_SUITE.  The testcases tests_interpreted/1 and
;; tests_compiled/1 in this suite are using the second method.  One
;; way to run this suite is with the ct_run tool, for example like the
;; following when standing at the OTP repo top directory:
;;
;; ct_run -suite lib/tools/test/emacs_SUITE
;;
;; Note that this creates a lot of html log files in the current
;; directory.

;;; Code:

(require 'ert)
(require 'erlang)

(defvar erlang-test-code
  '((nil . "-module(erlang_test).")
    (nil . "-import(lists, [map/2]).")
    (nil . "-compile(export_all).")
    ("SYMBOL" . "-define(SYMBOL, value).")
    ("MACRO" . "-define(MACRO(X), X + X).")
    ("struct" . "-record(struct, {until,maps,are,everywhere}).")
    ("function" . "function() -> #struct{}."))
  "Alist of erlang test code.
Each entry have the format (TAGNAME . ERLANG_CODE).  If TAGNAME
is nil there is no definitions in the ERLANG_CODE.  The
ERLANG_CODE is a single line of erlang code.  These lines will be
concatenated to form an erlang file to test on.")


(ert-deftest erlang-test-tags ()
  (let* ((dir (make-temp-file "erlang-test" t))
         (erlang-file (expand-file-name "erlang_test.erl" dir))
         (tags-file (expand-file-name "TAGS" dir))
         (old-tags-file-name (default-value 'tags-file-name))
         (old-tags-table-list (default-value 'tags-table-list))
         tags-file-name
         tags-table-list
         tags-table-set-list
         tags-add-tables
         tags-completion-table
         erlang-buffer
         erlang-mode-hook
         prog-mode-hook
         erlang-shell-mode-hook)
    (unwind-protect
        (progn
          (setq-default tags-file-name nil)
          (setq-default tags-table-list nil)
          (erlang-test-create-erlang-file erlang-file)
          (erlang-test-compile-tags erlang-file tags-file)
          (setq erlang-buffer (find-file-noselect erlang-file))
          (visit-tags-table tags-file t)
          (erlang-test-complete-at-point tags-file)
          (erlang-test-completion-table)
          (erlang-test-xref-find-definitions erlang-file erlang-buffer))
      (when (buffer-live-p erlang-buffer)
        (kill-buffer erlang-buffer))
      (let ((tags-buffer (find-buffer-visiting tags-file)))
        (when (buffer-live-p tags-buffer)
          (kill-buffer tags-buffer)))
      (when (file-exists-p dir)
        (delete-directory dir t))
      (setq-default tags-file-name old-tags-file-name)
      (setq-default tags-table-list old-tags-table-list))))

(defun erlang-test-create-erlang-file (erlang-file)
  (with-temp-file erlang-file
    (cl-loop for (_ . code) in erlang-test-code
             do (insert code "\n"))))

(defun erlang-test-compile-tags (erlang-file tags-file)
  (should (zerop (call-process "etags" nil nil nil
                               "-o" tags-file
                               erlang-file))))

(defun erlang-test-completion-table ()
  (let ((erlang-replace-etags-tags-completion-table t))
    (setq tags-completion-table nil)
    (tags-completion-table))
  (should (equal (sort tags-completion-table #'string-lessp)
                 (sort (erlang-expected-completion-table) #'string-lessp))))

(defun erlang-expected-completion-table ()
  (append (cl-loop for (symbol . _) in erlang-test-code
                   when (stringp symbol)
                   append (list symbol (concat "erlang_test:" symbol)))
          (list "erlang_test:" "erlang_test:module_info")))

(defun erlang-test-xref-find-definitions (erlang-file erlang-buffer)
  (cl-loop for (tagname . code) in erlang-test-code
           for line = 1 then (1+ line)
           do (when tagname
                (switch-to-buffer erlang-buffer)
                (erlang-test-xref-jump tagname erlang-file line)
                (when (string-equal tagname "function")
                  (erlang-test-xref-jump (concat "erlang_test:" tagname)
                                         erlang-file line))))
  (erlang-test-xref-jump "erlang_test:" erlang-file 1))

(defun erlang-test-xref-jump (id expected-file expected-line)
  (goto-char (point-max))
  (insert "\n%% " id)
  (save-buffer)
  (if (fboundp 'xref-find-definitions)
      (xref-find-definitions (erlang-id-to-string
                              (erlang-get-identifier-at-point)))
    (error "xref-find-definitions not defined (too old emacs?)"))
  (erlang-test-verify-pos expected-file expected-line))

(defun erlang-test-verify-pos (expected-file expected-line)
  (should (string-equal (file-truename expected-file)
                        (file-truename (buffer-file-name))))
  (should (eq expected-line (line-number-at-pos)))
  (should (= (line-beginning-position) (point))))

(defun erlang-test-complete-at-point (tags-file)
  (with-temp-buffer
    (erlang-mode)
    (setq-local tags-file-name tags-file)
    (insert "\nerlang_test:fun")
    (erlang-complete-tag)
    (should (looking-back "erlang_test:function" (line-beginning-position)))
    (insert "\nfun")
    (erlang-complete-tag)
    (should (looking-back "function" (line-beginning-position)))
    (insert "\nerlang_")
    (erlang-complete-tag)
    (should (looking-back "erlang_test:" (line-beginning-position)))))


(ert-deftest erlang-test-compile-options ()
  (erlang-test-format-opt t
                          "t")
  (erlang-test-format-opt nil
                          "nil")
  (erlang-test-format-opt (cons 1 2)
                          "{1, 2}")
  (erlang-test-format-opt (list 1)
                          "[1]")
  (erlang-test-format-opt (list 1 2)
                          "[1, 2]")
  (erlang-test-format-opt (list 1 2 3)
                          "[1, 2, 3]")
  (erlang-test-format-opt 'symbol
                          "symbol")
  (erlang-test-format-opt "string"
                          "\"string\"")
  (erlang-test-format-opt []
                          "{}")
  (erlang-test-format-opt [1]
                          "{1}")
  (erlang-test-format-opt [1 2]
                          "{1, 2}")
  (erlang-test-format-opt [1 2 (3 [4 5 6] 7)]
                          "{1, 2, [3, {4, 5, 6}, 7]}"))

(defun erlang-test-format-opt (elisp &optional expected-erlang)
  (let ((erlang (inferior-erlang-format-opt elisp)))
    (message "%s -> %s" elisp erlang)
    (when expected-erlang
      (should (equal erlang expected-erlang)))
    erlang))



(ert-deftest erlang-test-parse-id ()
  ;; Put it in a lambda to make it work on new (and old) versions
  ;; (with-suppressed-warnings ((ignored-return-value nreverse))
  ;; don't exist on emacs 26.
  (let ((dotest (lambda ()
                  (cl-loop for id-string in '("fun/10"
                                              "qualified-function module:fun/10"
                                              "record reko"
                                              "macro _SYMBOL"
                                              "macro MACRO/10"
                                              "module modula"
                                              "macro"
                                              nil)
                           for id-list in '((nil nil "fun" 10)
                                            (qualified-function "module" "fun" 10)
                                            (record nil "reko" nil)
                                            (macro nil "_SYMBOL" nil)
                                            (macro nil "MACRO" 10)
                                            (module nil "modula" nil)
                                            (nil nil "macro" nil)
                                            nil)
                           for id-list2 = (erlang-id-to-list id-string)
                           do (should (equal id-list id-list2))
                           for id-string2 = (erlang-id-to-string id-list)
                           do (should (equal id-string id-string2))
                           collect id-list2))))
    (funcall dotest)))

(defun erlang-test-string-states (code)
  "Parse CODE in Erlang mode and return the string state at each `@'.
Every `@' character in CODE marks a position of interest and is
removed before parsing.  The returned list holds the `nth' 3
element of the parse state at each of those positions, in order:
nil outside any string, t inside a triple-quoted string, and the
delimiting character inside an ordinary string or a quoted atom.
Font Lock is run first, since that is what used to apply the
syntax properties these tests are about."
  (with-temp-buffer
    (let (positions)
      (insert code)
      (goto-char (point-min))
      (while (search-forward "@" nil t)
        (delete-char -1)
        (push (point) positions))
      (erlang-mode)
      (font-lock-ensure)
      (mapcar (lambda (position) (nth 3 (syntax-ppss position)))
              (nreverse positions)))))


(ert-deftest erlang-test-syntax-dollar-quote ()
  ;; A dollar sign that happens to be the last character of a string
  ;; or of a quoted atom does not escape the quote that ends it.
  (should (equal '(nil) (erlang-test-string-states
                         "f() -> \"ends with $\", @ok.\n")))
  (should (equal '(nil) (erlang-test-string-states
                         "f() -> 'ends with $', @ok.\n")))
  (should (equal '(nil) (erlang-test-string-states
                         "f() -> \"$\", @ok.\n")))
  ;; In code $" and $' are character literals, and the quote does not
  ;; begin a string.  This has to hold on a line that already
  ;; contains a string, which is where the old rules lost track.
  (should (equal '(nil) (erlang-test-string-states
                         "f() -> [$\"], @ok.\n")))
  (should (equal '(nil) (erlang-test-string-states
                         "f() -> [$'], @ok.\n")))
  (should (equal '(nil) (erlang-test-string-states
                         "f(X) -> trim(g(\"ETag\", X), [$\"]), @ok.\n")))
  (should (equal '(nil) (erlang-test-string-states
                         "f(X) -> trim(g('etag', X), [$']), @ok.\n")))
  ;; In $\" and $\' the backslash does the escaping, not the dollar
  ;; sign, so the quote is still part of the character literal.
  (should (equal '(nil) (erlang-test-string-states
                         "f() -> [$\\\"], @ok.\n")))
  (should (equal '(nil) (erlang-test-string-states
                         "f() -> [$\\'], @ok.\n")))
  ;; $$ is the dollar sign character, and does not swallow the quote
  ;; that follows it.
  (should (equal '(?\" nil) (erlang-test-string-states
                             "f() -> $$, \"in@side\", @ok.\n")))
  ;; Strings, quoted atoms and comments still are what they are.
  (should (equal '(?\" nil) (erlang-test-string-states
                             "f() -> \"in@side\", @ok.\n")))
  (should (equal '(?' nil) (erlang-test-string-states
                            "f() -> 'in@side', @ok.\n")))
  (should (equal '(nil) (erlang-test-string-states
                         "%% a comment with \" and '\nf() -> @ok.\n")))
  (should (equal '(?\") (erlang-test-string-states
                         "f() -> \"unterminated\n@g() -> ok.\n"))))


(ert-deftest erlang-test-syntax-triple-quoted-string ()
  ;; A quote inside a triple-quoted string is a character of the
  ;; string, and so is an apostrophe following it.  Reading the quote
  ;; as the end of the string used to leave the rest of the buffer
  ;; inside a quoted atom.
  (should (equal '(t nil)
                 (erlang-test-string-states
                  (concat "-moduledoc \"\"\"\n"
                          "A \"quoted\" phrase@'s body.\n"
                          "\"\"\".\n"
                          "f() -> @ok.\n"))))
  ;; The string is closed by a run of as many quotes as opened it,
  ;; alone on its line, which is how a triple quote is written as
  ;; contents.
  (should (equal '(t t nil)
                 (erlang-test-string-states
                  (concat "-doc \"\"\"\"\n"
                          "@before\n"
                          "\"\"\"\n"
                          "@after\n"
                          "\"\"\"\".\n"
                          "f() -> @ok.\n"))))
  ;; A longer run does not close it either.
  (should (equal '(t nil)
                 (erlang-test-string-states
                  (concat "-doc \"\"\"\n"
                          "\"\"\"\"\n"
                          "@contents\n"
                          "\"\"\".\n"
                          "f() -> @ok.\n"))))
  ;; A sigil prefix does not change the delimiter.
  (should (equal '(t nil)
                 (erlang-test-string-states
                  (concat "f() -> ~b\"\"\"\n"
                          "    @body\n"
                          "    \"\"\",\n"
                          "  @ok.\n"))))
  ;; Contents are verbatim: neither a dollar sign before a quote nor
  ;; a backslash escape is special there.
  (should (equal '(t nil)
                 (erlang-test-string-states
                  (concat "f() -> ~S\"\"\"\n"
                          "    @a\\\"b $\" 'c'\n"
                          "    \"\"\",\n"
                          "  @ok.\n"))))
  (should (equal '(nil) (erlang-test-string-states
                         (concat "-doc \"\"\"\n"
                                 "ends with $\n"
                                 "\"\"\".\n"
                                 "f() -> @ok.\n"))))
  ;; An empty triple-quoted string, and one that is never closed.
  (should (equal '(nil) (erlang-test-string-states
                         (concat "-doc \"\"\"\n"
                                 "\"\"\".\n"
                                 "f() -> @ok.\n"))))
  (should (equal '(t) (erlang-test-string-states
                       (concat "-doc \"\"\"\n"
                               "@unterminated\n"))))
  ;; A run of quotes in a comment delimits nothing, and four quotes
  ;; in an expression are two adjacent empty strings.
  (should (equal '(nil) (erlang-test-string-states
                         "%% see \"\"\" here\nf() -> @ok.\n")))
  (should (equal '(nil) (erlang-test-string-states
                         "f() -> \"\"\"\" ++ X, @ok.\n"))))


(provide 'erlang-test)

;;; erlang-test.el ends here
