(define-package "eldev" "20221111.1951" "Elisp development tool"
  '((emacs "24.4"))
  :commit "00b29384e96c49375112613939e333d46565b310" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
