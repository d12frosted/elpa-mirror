;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-srs" "20251223.1556"
  "A flexible spaced repetition system for Org-mode."
  '((emacs "30.1")
    (org   "9.7")
    (fsrs  "6.0"))
  :url "https://github.com/bohonghuang/org-srs"
  :commit "5e568efdc0690ccbd401758484a4d96785851053"
  :revdesc "5e568efdc069"
  :keywords '("outlines")
  :authors '(("Bohong Huang" . "bohonghuang@qq.com"))
  :maintainers '(("Bohong Huang" . "bohonghuang@qq.com")))
