(define-package "recursion-indicator" "20230904.2050" "Recursion indicator"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "08b2a818fbcb3ea51def2a8d1c19f7dc76967973" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience")
  :url "https://github.com/minad/recursion-indicator")
;; Local Variables:
;; no-byte-compile: t
;; End:
