;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260919.218"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e78b43487007d59415d34c3cec4fadf814b8a373"
  :revdesc "e78b43487007")
