(define-package "tr-ime" "20201110.1428" "Emulator of IME patch for Windows"
  '((emacs "27.1")
    (w32-ime "0.0.1"))
  :commit "a46643231d8e21eeca9ecbc42625c6da274ceab5" :authors
  (("Masamichi Hosoda" . "trueroad@trueroad.jp"))
  :maintainer
  ("Masamichi Hosoda" . "trueroad@trueroad.jp")
  :url "https://github.com/trueroad/tr-emacs-ime-module")
;; Local Variables:
;; no-byte-compile: t
;; End:
