;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260224.1641"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "24.4")
    (s     "1.11.0")
    (dash  "2.9.0")
    (popup "0.5.3"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "41370b040abf7f17bb8d3ffbcf67a0b01c6cfffc"
  :revdesc "41370b040abf"
  :keywords '("programming"))
