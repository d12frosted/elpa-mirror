(define-package "posframe" "20211027.213" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "d2f6d066c9df404788d3dea2e301d8d04502cc71" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
