;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260304.1144"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "dd8b9e80f53b313dff2bb45eb41813598f7f5a31"
  :revdesc "dd8b9e80f53b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
