(define-package "citar-denote" "20230625.2105" "Minor mode to integrate Citar and Denote"
  '((emacs "28.1")
    (citar "1.1")
    (denote "1.2.0")
    (dash "2.19.1"))
  :commit "f2f451f189b04096ba4b2772ac1cca849d050118" :authors
  '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers
  '(("Peter Prevos" . "peter@prevos.net"))
  :maintainer
  '("Peter Prevos" . "peter@prevos.net")
  :url "https://github.com/pprevos/citar-denote")
;; Local Variables:
;; no-byte-compile: t
;; End:
