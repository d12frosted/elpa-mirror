;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250612.1509"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "cc4355a59c368cef7ec9d7e1883b412b22f913da"
  :revdesc "cc4355a59c36"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
