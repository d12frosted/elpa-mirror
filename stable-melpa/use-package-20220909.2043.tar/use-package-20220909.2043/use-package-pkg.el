(define-package "use-package" "20220909.2043" "A configuration macro for simplifying your .emacs"
  '((emacs "24.3")
    (bind-key "2.4"))
  :commit "4db51ba3481ac4216147d774e969cbf0a46ac971" :authors
  '(("John Wiegley" . "johnw@newartisans.com"))
  :maintainer
  '("John Wiegley" . "johnw@newartisans.com")
  :keywords
  '("dotemacs" "startup" "speed" "config" "package")
  :url "https://github.com/jwiegley/use-package")
;; Local Variables:
;; no-byte-compile: t
;; End:
