;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emcp" "20261125.1908"
  "Lets your agent talk to Emacs."
  '((emacs         "30.1")
    (http-server   "0.2.0")
    (elisp-refs    "1.6")
    (magit-section "4.0.0"))
  :url "https://codeberg.org/martenlienen/emcp"
  :commit "580b052ab0914aa4e21fef6a1a7632741eb7d7b8"
  :revdesc "580b052ab091"
  :keywords '("maint")
  :authors '(("Marten Lienen" . "ml@martenlienen.com"))
  :maintainers '(("Marten Lienen" . "ml@martenlienen.com")))
