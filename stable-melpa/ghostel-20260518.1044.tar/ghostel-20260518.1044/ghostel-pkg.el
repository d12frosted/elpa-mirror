;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260518.1044"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "c078cf8438a4a4c6e8ce79b8c4d08ffae226cde0"
  :revdesc "c078cf8438a4"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
