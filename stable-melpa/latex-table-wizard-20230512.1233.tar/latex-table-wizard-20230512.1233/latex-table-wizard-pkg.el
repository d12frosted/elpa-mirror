(define-package "latex-table-wizard" "20230512.1233" "Magic editing of LaTeX tables"
  '((emacs "27.1")
    (auctex "12.1")
    (transient "0.3.7"))
  :commit "b41aac096b96aeb446346c3cbd6537cc0eb1f70d" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainers
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :keywords
  '("convenience")
  :url "https://github.com/enricoflor/latex-table-wizard")
;; Local Variables:
;; no-byte-compile: t
;; End:
