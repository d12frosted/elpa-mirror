;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260426.154"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "14aedcb017c9084d0a6efff77e46fbbc976b971e"
  :revdesc "14aedcb017c9"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
