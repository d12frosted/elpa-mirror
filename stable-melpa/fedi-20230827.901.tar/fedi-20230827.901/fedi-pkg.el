(define-package "fedi" "20230827.901" "Helper functions for fediverse clients"
  '((emacs "28.1"))
  :commit "971a363fba28097f9f6940ace4235b1b8a38d8c1" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
