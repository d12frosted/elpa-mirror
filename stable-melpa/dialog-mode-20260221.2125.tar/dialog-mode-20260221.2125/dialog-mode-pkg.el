;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260221.2125"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "c8f29d6cd7cd4363a7ae1b4912d26acc33fb536d"
  :revdesc "c8f29d6cd7cd"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
