(define-package "org-caldav" "20240302.1807" "Sync org files with external calendar through CalDAV"
  '((emacs "26.3")
    (org "9.1"))
  :commit "7c0ae0dd84d47f7f28a5e74e68ecbbd53df401d8" :authors
  '(("David Engster" . "deng@randomsample.de"))
  :maintainers
  '(("David Engster" . "deng@randomsample.de"))
  :maintainer
  '("David Engster" . "deng@randomsample.de")
  :keywords
  '("calendar" "caldav")
  :url "https://github.com/dengste/org-caldav/")
;; Local Variables:
;; no-byte-compile: t
;; End:
