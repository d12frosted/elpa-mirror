;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20260325.346"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "1db0b0b9203cf293b38ac278273efcfc3581a05f"
  :revdesc "1db0b0b9203c"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
