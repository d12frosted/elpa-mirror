;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "20260829.1025"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "d8dcc82e79445063485f87385c80d15ba66356b7"
  :revdesc "d8dcc82e7944"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
