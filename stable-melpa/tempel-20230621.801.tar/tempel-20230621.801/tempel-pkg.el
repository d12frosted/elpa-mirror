(define-package "tempel" "20230621.801" "Tempo templates/snippets with in-buffer field editing"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "48e227e096e143fa8eadfe3d1e93489fba6da86d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "languages" "tools" "wp")
  :url "https://github.com/minad/tempel")
;; Local Variables:
;; no-byte-compile: t
;; End:
