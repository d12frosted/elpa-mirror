(define-package "guix" "20191121.1620" "Interface for GNU Guix"
  '((emacs "24.3")
    (dash "2.11.0")
    (geiser "0.8")
    (bui "1.2.0")
    (magit-popup "2.1.0")
    (edit-indirect "0.1.4"))
  :commit "c2796e68868c91253b6aca422a9ae07363aa03a9" :authors
  '(("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  '("Alex Kost" . "alezost@gmail.com")
  :keywords
  '("tools")
  :url "https://emacs-guix.gitlab.io/website/")
;; Local Variables:
;; no-byte-compile: t
;; End:
