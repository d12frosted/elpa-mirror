;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lisp-chat" "20260302.7"
  "Emacs client for Lisp Chat."
  '((emacs     "26.1")
    (websocket "1.12"))
  :url "https://github.com/ryukinix/lisp-chat"
  :commit "43bab123c861ed0dd11d076af9a61d641ed259f5"
  :revdesc "43bab123c861"
  :keywords '("comm" "chat" "lisp"))
