(define-package "doom-modeline" "20230303.847" "A minimal and modern mode-line"
  '((emacs "25.1")
    (compat "28.1.1.1")
    (shrink-path "0.2.0"))
  :commit "c705089c8dd689e7d19edd3c148571cee2fb2864" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
