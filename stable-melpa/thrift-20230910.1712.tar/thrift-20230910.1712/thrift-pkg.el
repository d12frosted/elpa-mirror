(define-package "thrift" "20230910.1712" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "9f60376de40b48561ac50263089468b779195003" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
