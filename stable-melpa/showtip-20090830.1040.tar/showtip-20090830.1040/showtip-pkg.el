;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "showtip" "20090830.1040"
  "Show tip at cursor."
  ()
  :url "https://github.com/emacsorphanage/showtip"
  :commit "930da302809a4257e8d69425455b29e1cc91949b"
  :revdesc "930da302809a"
  :keywords '("help")
  :authors '(("Ye Wenbin" . "wenbinye@gmail.com"))
  :maintainers '(("Ye Wenbin" . "wenbinye@gmail.com")))
