(define-package "eldev" "20210515.1721" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "05bcef9b1b9a5590c5e8db1da6e179a0b1a36947" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
