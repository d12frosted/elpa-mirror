(define-package "ue" "20210929.933" "Minor mode for Unreal Engine projects"
  '((emacs "26.1")
    (projectile "2.5.0"))
  :commit "e4f09f207c7b29dbe65cd3150ff12d7f0747230f" :authors
  '(("Oleksandr Manenko" . "seidfzehsd@use.startmail.com"))
  :maintainer
  '("Oleksandr Manenko" . "seidfzehsd@use.startmail.com")
  :keywords
  '("unreal engine" "languages" "tools")
  :url "https://gitlab.com/unrealemacs/ue.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
