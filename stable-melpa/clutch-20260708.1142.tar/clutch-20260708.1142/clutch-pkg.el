;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260708.1142"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "a51255212cf422947aa9e5339d523dc28c2b7e88"
  :revdesc "a51255212cf4"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
