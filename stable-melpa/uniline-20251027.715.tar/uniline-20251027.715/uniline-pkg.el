;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20251027.715"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "c5480e59b7f7e8e046c66a684b50fa03177d068d"
  :revdesc "c5480e59b7f7"
  :keywords '("convenience" "text"))
