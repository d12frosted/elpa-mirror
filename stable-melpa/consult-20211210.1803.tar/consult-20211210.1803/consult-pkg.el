(define-package "consult" "20211210.1803" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "a8dea906824e1e171fb01c3cdb2d7ffa1f24bb5f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
