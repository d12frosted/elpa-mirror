;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20251114.1330"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/dicom"
  :commit "f77583f36740e92ad12148778f746caede1719d9"
  :revdesc "f77583f36740"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
