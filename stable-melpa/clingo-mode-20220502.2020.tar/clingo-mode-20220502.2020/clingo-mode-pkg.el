(define-package "clingo-mode" "20220502.2020" "A major mode for editing Answer Set Programs"
  '((emacs "24.3"))
  :commit "cf56ce6b5c50506f6cea27e1dde0441dd8d15ee9" :authors
  '(("Ivan Uemlianin" . "ivan@llaisdy.com"))
  :maintainers
  '(("Ivan Uemlianin" . "ivan@llaisdy.com"))
  :maintainer
  '("Ivan Uemlianin" . "ivan@llaisdy.com")
  :keywords
  '("asp" "clingo" "answer set programs" "potassco" "major mode" "languages")
  :url "https://github.com/llaisdy/clingo-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
