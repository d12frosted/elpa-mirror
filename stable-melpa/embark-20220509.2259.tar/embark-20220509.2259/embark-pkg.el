(define-package "embark" "20220509.2259" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "5bb0e3aa40d6177a4b377af6da296b33b7ad404a" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
