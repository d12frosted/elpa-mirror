(define-package "embark" "20220509.2259" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "cb5d69987b03029a4727998f098305cd2e212d3f" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
