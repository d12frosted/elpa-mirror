(define-package "tab-bar-buffers" "20240227.1519" "Use tab-bar-mode as a buffer manager"
  '((emacs "28.1"))
  :commit "7c9f56759132637fb8c4786aa45d2cbf61ab41e1" :authors
  '(("Andy Rosen" . "ajr@corp.mlfs.org"))
  :maintainers
  '(("Andy Rosen" . "ajr@corp.mlfs.org"))
  :maintainer
  '("Andy Rosen" . "ajr@corp.mlfs.org")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/ajrosen/tab-bar-buffers")
;; Local Variables:
;; no-byte-compile: t
;; End:
