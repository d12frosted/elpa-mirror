;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260704.1422"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "2b1d3fd2d3850a27e2aded5f32cf248bffa6f072"
  :revdesc "2b1d3fd2d385"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
