(define-package "citre" "20210818.1345" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "0366ec1196b54b381ca01a1b2e37c6912b92fb50" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
