;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-browse-commit" "20260303.403"
  "Browse pull/merge requests from magit-blame."
  '((emacs "25.1")
    (magit "3.0.0")
    (s     "1.12.0"))
  :url "https://github.com/bbw9n/magit-browse-commit"
  :commit "eacd12063f1b497309e5e7dac6c3b8704c6704f2"
  :revdesc "eacd12063f1b"
  :keywords '("vc" "tools" "git")
  :authors '(("Angeldswang" . "bbw9nio@gmail.com"))
  :maintainers '(("Angeldswang" . "bbw9nio@gmail.com")))
