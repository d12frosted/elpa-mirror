;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260701.1725"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "ee6d59b6477e5929bfd754727584c18d8c15ce2b"
  :revdesc "ee6d59b6477e"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
