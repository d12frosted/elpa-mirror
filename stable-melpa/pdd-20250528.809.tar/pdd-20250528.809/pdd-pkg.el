;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250528.809"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "b818a58f6b7a89786081665bc8cec603e4666760"
  :revdesc "b818a58f6b7a"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
