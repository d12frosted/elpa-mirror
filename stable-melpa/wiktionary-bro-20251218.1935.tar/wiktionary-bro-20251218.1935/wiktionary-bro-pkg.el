;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wiktionary-bro" "20251218.1935"
  "Lookup Wiktionary entries."
  '((emacs   "30.1")
    (request "0.3.3"))
  :url "https://github.com/agzam/wiktionary-bro.el"
  :commit "081449dce747524fa91a657c0972f824af1f4eb4"
  :revdesc "081449dce747"
  :keywords '("convenience" "multimedia")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
