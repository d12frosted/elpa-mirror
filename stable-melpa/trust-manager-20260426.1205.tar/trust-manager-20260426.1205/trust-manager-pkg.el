;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "20260426.1205"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "530c559ffa01b99ced8073ba4c74f1b8152a0ef2"
  :revdesc "530c559ffa01"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
