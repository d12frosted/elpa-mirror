;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-fuzzy" "20250422.129"
  "Fuzzy matching for `company-mode'."
  '((emacs   "26.1")
    (company "0.8.12")
    (s       "1.12.0")
    (ht      "2.0"))
  :url "https://github.com/jcs-elpa/company-fuzzy"
  :commit "874c4c4683ba46b4b7f817eda32888dbb1e9dff3"
  :revdesc "874c4c4683ba"
  :keywords '("matching" "auto-complete" "complete" "fuzzy")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
