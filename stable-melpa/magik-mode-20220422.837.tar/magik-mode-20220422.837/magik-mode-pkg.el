(define-package "magik-mode" "20220422.837" "mode for editing Magik + some utils." 'nil :commit "af1b83786c95d448dcb4df5406eb1cdba975abf5" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
