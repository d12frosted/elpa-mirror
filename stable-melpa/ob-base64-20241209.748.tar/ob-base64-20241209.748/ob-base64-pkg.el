;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-base64" "20241209.748"
  "Org-babel for base64 content."
  '((emacs "26.1"))
  :url "https://github.com/keyweeusr/ob-base64"
  :commit "6d3ef9d937838eb69b0a91e4012a0b6084ba26e1"
  :revdesc "6d3ef9d93783"
  :keywords '("convenience" "embedding" "orgmode" "base64" "rendering")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
