(define-package "timecop" "20240105.1901" "Freeze Time for testing"
  '((emacs "26.3")
    (datetime-format "0.0.1"))
  :commit "007dd38851621bee277d11e777c513a806f70c3a" :authors
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers
  '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("lisp" "datetime" "testing")
  :url "https://github.com/emacs-php/emacs-datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
