(define-package "verb" "20210525.2135" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "9e3e8a1edd82f7d056d3744f9e40cf8a5bac4ecc" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
