;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-isearch" "20170308.2010"
  "Flex matching (like ido) in isearch."
  ()
  :url "https://bitbucket.org/jpkotta/flex-isearch"
  :commit "b1f7e04de762282c276343cc2709af9ff4abc9d2"
  :revdesc "b1f7e04de762"
  :keywords '("convenience" "search")
  :authors '(("Jonathan Kotta" . "jpkotta@gmail.com"))
  :maintainers '(("Jonathan Kotta" . "jpkotta@gmail.com")))
