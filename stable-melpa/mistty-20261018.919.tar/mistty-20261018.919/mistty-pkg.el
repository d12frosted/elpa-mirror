;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20261018.919"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "b4c3a6d101aa467ce0e7f933267ef5b6acaad70e"
  :revdesc "b4c3a6d101aa"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
