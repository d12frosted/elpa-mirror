(define-package "evil-pinyin" "20231016.1540" "Evil search Chinese characters by pinyin"
  '((emacs "25")
    (names "0.5")
    (evil "1"))
  :commit "8dfa83b465cd155cbea062c8d279f01f042e1994" :keywords
  '("extensions")
  :url "https://github.com/laishulu/evil-pinyin")
;; Local Variables:
;; no-byte-compile: t
;; End:
