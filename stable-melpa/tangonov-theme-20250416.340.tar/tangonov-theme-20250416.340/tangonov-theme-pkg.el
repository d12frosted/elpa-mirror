;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tangonov-theme" "20250416.340"
  "A 256 color dark theme featuring bright pastels."
  '((emacs "27.1"))
  :url "https://codeberg.org/trevdev/tangonov-theme"
  :commit "cb62069f84c5a475b466e2cc1c252f655c673259"
  :revdesc "cb62069f84c5"
  :keywords '("faces" "theme" "dark" "fringe")
  :authors '(("Trevor Richards" . "trev@trevdev.ca"))
  :maintainers '(("Trevor Richards" . "trev@trevdev.ca")))
