(define-package "doom-themes" "20210204.1733" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "832ef1f546ce73881ed3304192a397f45d8ba5c7" :authors
  '(("Henrik Lissner <http://github/hlissner>"))
  :maintainer
  '("Henrik Lissner" . "henrik@lissner.net")
  :keywords
  '("dark" "light" "blue" "atom" "one" "theme" "neotree" "icons" "faces" "nova")
  :url "https://github.com/hlissner/emacs-doom-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
