(define-package "dracula-theme" "20230922.746" "Dracula Theme"
  '((emacs "24.3"))
  :commit "dabe74904036717b06546c382df6e77a28921cff" :authors
  '(("film42"))
  :maintainers
  '(("Étienne Deparis" . "etienne@depar.is"))
  :maintainer
  '("Étienne Deparis" . "etienne@depar.is")
  :url "https://github.com/dracula/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
