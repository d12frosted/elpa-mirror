;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "django-manage" "20160819.212"
  "Django minor mode for commanding manage.py."
  '((hydra "0.13.2"))
  :url "https://github.com/gopar/django-manage"
  :commit "e72b1cf2fdbb5c624d19169176e60467b4918fe2"
  :revdesc "e72b1cf2fdbb"
  :keywords '("languages")
  :authors '(("Daniel Gopar" . "gopardaniel@yahoo.com"))
  :maintainers '(("Daniel Gopar" . "gopardaniel@yahoo.com")))
