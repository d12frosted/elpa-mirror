;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "20250314.202"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "a9e084a2c50a40dccf74d65757155c19142424f1"
  :revdesc "a9e084a2c50a"
  :keywords '("convenience"))
