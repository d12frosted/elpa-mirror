;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "20260127.1509"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "adaca49699cc149af991825feebaa29624e124b0"
  :revdesc "adaca49699cc"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
