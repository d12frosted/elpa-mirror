;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-transient" "20260306.1530"
  "Command dispatchers for Notmuch."
  '((emacs     "29.1")
    (compat    "30.1")
    (notmuch   "0.39")
    (transient "0.12"))
  :url "https://github.com/tarsius/notmuch-transient"
  :commit "3195a5523dbbce04751b23762845a73f0100172b"
  :revdesc "3195a5523dbb"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-transient@jonas.bernoulli.dev")))
