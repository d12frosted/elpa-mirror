(define-package "ejc-sql" "20220517.1303" "Emacs SQL client uses Clojure JDBC."
  '((emacs "26.3")
    (clomacs "0.0.5")
    (dash "2.16.0")
    (spinner "1.7.3")
    (direx "1.0.0"))
  :commit "5e100426be90fc193154b1219ab1058534a4fb52" :authors
  '(("Kostafey" . "kostafey@gmail.com"))
  :maintainer
  '("Kostafey" . "kostafey@gmail.com")
  :keywords
  '("sql" "jdbc")
  :url "https://github.com/kostafey/ejc-sql")
;; Local Variables:
;; no-byte-compile: t
;; End:
