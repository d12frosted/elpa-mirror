(define-package "apdl-mode" "20210914.1918" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "1f78087e592f66d58b59c8188d63fe97ddb743a0" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
