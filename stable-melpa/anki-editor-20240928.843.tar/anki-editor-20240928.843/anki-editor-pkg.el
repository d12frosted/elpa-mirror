(define-package "anki-editor" "20240928.843" "Minor mode for making Anki cards with Org"
  '((emacs "25.1"))
  :commit "be75eb8b3f476770349b3fe0446fd7ae0edc5357" :url "https://github.com/anki-editor/anki-editor")
;; Local Variables:
;; no-byte-compile: t
;; End:
