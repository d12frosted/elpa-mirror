(define-package "dtache" "20220208.2044" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "e91def3b2192b8a18f116466beb9405733db1487" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
