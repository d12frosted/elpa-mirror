;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hoa-mode" "20251027.1528"
  "Major mode for the HOA format."
  '((emacs "25.1"))
  :url "https://gitlab.lre.epita.fr/spot/emacs-modes"
  :commit "10446387fda1d59d7ef9765d67b8022543697e62"
  :revdesc "10446387fda1"
  :keywords '("major-mode" "automata" "convenience")
  :authors '(("Alexandre Duret-Lutz" . "adl@lrde.epita.fr"))
  :maintainers '(("Alexandre Duret-Lutz" . "adl@lrde.epita.fr")))
