;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260926.912"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/jinx"
  :commit "bccb08062a3372629015bcd2c197490b7d005f37"
  :revdesc "bccb08062a33"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
