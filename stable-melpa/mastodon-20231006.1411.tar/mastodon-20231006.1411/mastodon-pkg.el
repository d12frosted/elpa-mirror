(define-package "mastodon" "20231006.1411" "Client for fediverse services using the Mastodon API"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4"))
  :commit "041cd4d47202a2326bc8a79bac96e951073b0399" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
