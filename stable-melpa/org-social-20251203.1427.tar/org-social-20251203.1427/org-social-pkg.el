;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20251203.1427"
  "An Org-social client."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "79b4963ab1c6d5d91f6f2f3838335ac5e3a69fd4"
  :revdesc "79b4963ab1c6"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
