(define-package "cape" "20220607.1615" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "67c48f1c3609f1426f02c5d8b81e23b1e8b89659" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
