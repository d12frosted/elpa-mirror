;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zathura" "20260603.1620"
  "Summary."
  '((emacs "24.3"))
  :url "https://codeberg.org/treflip/zathura.el"
  :commit "874dadbf07e22811b6b309200cad32b4ccca0e51"
  :revdesc "874dadbf07e2"
  :keywords '("convenience"))
