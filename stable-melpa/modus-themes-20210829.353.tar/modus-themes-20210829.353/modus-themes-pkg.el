(define-package "modus-themes" "20210829.353" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "5df7c22d69c723fda4fb124f48b18945042894af" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
