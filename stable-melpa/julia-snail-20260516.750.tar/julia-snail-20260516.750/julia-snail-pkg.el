;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-snail" "20260516.750"
  "Julia Snail."
  '((emacs      "26.2")
    (dash       "2.16.0")
    (julia-mode "0.3")
    (s          "1.12.0")
    (spinner    "1.7.3")
    (popup      "0.5.9"))
  :url "https://github.com/gcv/julia-snail"
  :commit "90e2278921ff4155577f97b937f375375c32a34f"
  :revdesc "90e2278921ff")
