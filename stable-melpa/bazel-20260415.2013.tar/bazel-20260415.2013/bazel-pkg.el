;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260415.2013"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazelbuild/emacs-bazel-mode"
  :commit "e120b2bd80e192fc7de096e8832c6af73b6e127b"
  :revdesc "e120b2bd80e1"
  :keywords '("build tools" "languages"))
