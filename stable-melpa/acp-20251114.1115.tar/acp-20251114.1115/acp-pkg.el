;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20251114.1115"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "c0bc372d7f5823f0c30cb9de96fd222228451d66"
  :revdesc "c0bc372d7f58")
