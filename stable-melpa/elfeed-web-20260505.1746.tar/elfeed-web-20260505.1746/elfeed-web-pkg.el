;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-web" "20260505.1746"
  "Web interface to Elfeed."
  '((emacs        "28.1")
    (compat       "31")
    (elfeed       "3.4.2")
    (simple-httpd "1.5.1"))
  :url "https://github.com/emacs-elfeed/elfeed-web"
  :commit "8251b0ae8ed4271155b7ba178b6f24a317288b65"
  :revdesc "8251b0ae8ed4"
  :keywords '("network" "hypermedia")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
                 ("Ihor Radchenko" . "yantar92@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
