;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devops" "20261022.1554"
  "Infrastructure as an org file."
  '((emacs "30.1"))
  :url "https://github.com/kpassapk/devops.el"
  :commit "844ef5c3896be02fa9798ef74cf1a2902cad0498"
  :revdesc "844ef5c3896b"
  :keywords '("tools" "processes" "outlines")
  :authors '(("Kyle S Passarelli" . "kyle.passarelli@gmail.com"))
  :maintainers '(("Kyle S Passarelli" . "kyle.passarelli@gmail.com")))
