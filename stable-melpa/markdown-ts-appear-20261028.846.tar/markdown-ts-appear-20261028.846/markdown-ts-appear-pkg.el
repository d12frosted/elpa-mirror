;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "20261028.846"
  "Reveal Markdown source at point."
  '((emacs "31.1"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "812a2155617c6b3175f00ce594f36cea4d84f2f4"
  :revdesc "812a2155617c"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
