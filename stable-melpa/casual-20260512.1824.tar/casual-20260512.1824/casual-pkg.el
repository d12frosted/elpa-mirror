;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260512.1824"
  "Transient user interfaces for various modes."
  '((emacs     "30.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "40fba5437498047005af3aa6de0175f193d3fb22"
  :revdesc "40fba5437498"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
