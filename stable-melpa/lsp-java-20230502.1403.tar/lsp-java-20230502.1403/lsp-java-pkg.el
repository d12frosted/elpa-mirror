(define-package "lsp-java" "20230502.1403" "Java support for lsp-mode"
  '((emacs "25.1")
    (lsp-mode "6.0")
    (markdown-mode "2.3")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.0")
    (request "0.3.0")
    (treemacs "2.5")
    (dap-mode "0.5"))
  :commit "947fa1dc04a2c6ef8be15880ba2e57f336a63264" :keywords
  '("languague" "tools")
  :url "https://github.com/emacs-lsp/lsp-java")
;; Local Variables:
;; no-byte-compile: t
;; End:
