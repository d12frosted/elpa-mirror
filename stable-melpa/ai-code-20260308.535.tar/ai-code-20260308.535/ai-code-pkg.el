;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260308.535"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b871a2a276e97c64bd13c8833ff589a7795d098e"
  :revdesc "b871a2a276e9"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
