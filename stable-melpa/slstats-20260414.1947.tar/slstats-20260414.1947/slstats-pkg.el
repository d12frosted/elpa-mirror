;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slstats" "20260414.1947"
  "Acquire and display stats about Second Life."
  '((emacs "25.1"))
  :url "https://github.com/davep/slstats.el"
  :commit "d6f0c7428e886a39e6061d093b4ef7d8d240ba0d"
  :revdesc "d6f0c7428e88"
  :keywords '("games")
  :authors '(("Dave Pearson" . "davep@davep.org"))
  :maintainers '(("Dave Pearson" . "davep@davep.org")))
