;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "virtual-comment" "20260926.122"
  "Virtual Comments."
  '((emacs "26.1"))
  :url "https://github.com/thanhvg/emacs-virtual-comment"
  :commit "3d4d19f464661352e34fd351557c0af9922c1bb2"
  :revdesc "3d4d19f46466"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
