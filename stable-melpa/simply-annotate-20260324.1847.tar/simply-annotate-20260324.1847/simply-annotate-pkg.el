;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260324.1847"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "03c32ae8855185f5030fa3d064b6cce8502b7015"
  :revdesc "03c32ae88551"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
