(define-package "eldev" "20220211.2131" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "9a5d9067a086e43e38d9435085a1c35d3883a4d3" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
