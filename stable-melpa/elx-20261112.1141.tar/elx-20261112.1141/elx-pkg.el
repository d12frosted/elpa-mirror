;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "20261112.1141"
  "Extract information from Emacs Lisp libraries."
  '((emacs    "30.1")
    (compat   "31.1")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "0ed36cd078a53f86285ce55bb0ee5e84ff0053ad"
  :revdesc "0ed36cd078a5"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
