(define-package "org-link-beautify" "20240529.444" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1")
    (qrencode "1.2"))
  :commit "cf7a385558048ee550e01652670e5ba182553ffe" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
