(define-package "org-newtab" "20240221.211" "Supercharge your browser's new tab page"
  '((emacs "27.1")
    (websocket "1.14")
    (async "1.9.7"))
  :commit "a916b460b5cd0268b1a34f4cb1708dcb27b293b6" :authors
  '(("Zweihänder" . "zweidev@zweihander.me"))
  :maintainers
  '(("Zweihänder" . "zweidev@zweihander.me"))
  :maintainer
  '("Zweihänder" . "zweidev@zweihander.me")
  :keywords
  '("outlines")
  :url "https://github.com/Zweihander-Main/org-newtab")
;; Local Variables:
;; no-byte-compile: t
;; End:
