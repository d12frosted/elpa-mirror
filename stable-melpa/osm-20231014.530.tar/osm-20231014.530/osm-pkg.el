(define-package "osm" "20231014.530" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "1957cf75127471bce0ebe91b5afdf566d5bec033" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("network" "multimedia" "hypermedia" "mouse")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
