;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mysql" "20260526.1431"
  "Pure Elisp MySQL wire protocol client."
  '((emacs "28.1"))
  :url "https://github.com/LuciusChen/mysql.el"
  :commit "24a9754ff3babe0885f38779349b2e4f2c6dfbbd"
  :revdesc "24a9754ff3ba"
  :keywords '("comm" "data")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
