(define-package "modus-themes" "20220331.540" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "b834e5f298f66ba87c89d32b5fb20f2832362ec6" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
