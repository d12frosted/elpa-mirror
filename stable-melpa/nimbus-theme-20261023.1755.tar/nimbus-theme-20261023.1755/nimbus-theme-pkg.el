;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "20261023.1755"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "71196dbef44ff0368984a90688414b8047e7669e"
  :revdesc "71196dbef44f"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
