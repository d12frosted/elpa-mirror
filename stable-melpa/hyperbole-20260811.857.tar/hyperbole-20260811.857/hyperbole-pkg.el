;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260811.857"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "8820a586439402b751cdf06e67d66919d46c8aa4"
  :revdesc "8820a5864394"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
