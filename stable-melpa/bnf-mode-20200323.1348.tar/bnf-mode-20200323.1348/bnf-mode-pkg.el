(define-package "bnf-mode" "20200323.1348" "Major mode for editing BNF grammars."
  '((cl-lib "0.5")
    (emacs "24.3"))
  :commit "d9329dd90e5d4f629295e85898362d9682047898" :authors
  '(("Serghei Iakovlev" . "egrep@protonmail.ch"))
  :maintainer
  '("Serghei Iakovlev" . "egrep@protonmail.ch")
  :keywords
  '("languages")
  :url "https://github.com/sergeyklay/bnf-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
