;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20261027.2125"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "6aa153a032d0637b69f58785a7213df37ed60fcb"
  :revdesc "6aa153a032d0"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
