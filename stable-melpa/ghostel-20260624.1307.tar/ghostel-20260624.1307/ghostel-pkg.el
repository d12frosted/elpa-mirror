;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260624.1307"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "9e8460a697057d4564e19e392e19fe6211cedf43"
  :revdesc "9e8460a69705"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
