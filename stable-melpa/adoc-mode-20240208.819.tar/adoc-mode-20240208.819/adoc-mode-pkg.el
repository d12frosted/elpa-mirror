(define-package "adoc-mode" "20240208.819" "a major-mode for editing AsciiDoc files"
  '((emacs "26"))
  :commit "01f1748b1e0ac45912dd9ae413c88d9ba09c4fca" :authors
  '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.dev")
  :keywords
  '("docs" "wp")
  :url "https://github.com/bbatsov/adoc-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
