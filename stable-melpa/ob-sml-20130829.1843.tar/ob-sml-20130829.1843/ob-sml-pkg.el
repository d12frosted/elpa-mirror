;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-sml" "20130829.1843"
  "Org-babel functions for template evaluation."
  '((sml-mode "6.4"))
  :url "http://orgmode.org"
  :commit "958165c92b6cff6cada5c85c8ae5887806b8451b"
  :revdesc "958165c92b6c"
  :keywords '("literate programming" "reproducible research"))
