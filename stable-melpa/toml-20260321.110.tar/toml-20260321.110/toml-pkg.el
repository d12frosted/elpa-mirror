;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260321.110"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "8ae603269b7c95bff4299d80f84d262a4672a829"
  :revdesc "8ae603269b7c"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
