;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "justl" "20260228.1147"
  "Major mode for driving just files."
  '((transient  "0.1.0")
    (emacs      "27.1")
    (s          "1.2.0")
    (f          "0.20.0")
    (inheritenv "0.2"))
  :url "https://github.com/psibi/justl.el"
  :commit "4a149c0ad91f60c4d4338e7aa0676ad792a52eca"
  :revdesc "4a149c0ad91f"
  :keywords '("just" "justfile" "tools" "processes"))
