;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mcp" "20260714.940"
  "MCP server for Org-mode."
  '((emacs          "28.2")
    (mcp-server-lib "0.4.0"))
  :url "https://github.com/laurynas-biveinis/org-mcp"
  :commit "09e14870640f333a6ee468d60f7ed962c0146b02"
  :revdesc "09e14870640f"
  :keywords '("convenience" "files" "matching" "outlines")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
