(define-package "suomalainen-kalenteri" "20220101.718" "Finnish national and Christian holidays for calendar" 'nil :commit "30103e6c6fa5dcbae70a636b007afdaad2fbcac0" :authors
  '(("Teemu Likonen" . "tlikonen@iki.fi"))
  :maintainer
  '("Teemu Likonen" . "tlikonen@iki.fi")
  :keywords
  '("calendar" "holidays" "finnish")
  :url "https://github.com/tlikonen/suomalainen-kalenteri")
;; Local Variables:
;; no-byte-compile: t
;; End:
