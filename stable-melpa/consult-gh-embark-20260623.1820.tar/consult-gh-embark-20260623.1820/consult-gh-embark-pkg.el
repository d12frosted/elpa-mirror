;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-gh-embark" "20260623.1820"
  "Embark Actions for consult-gh."
  '((emacs          "29.4")
    (consult        "2.0")
    (consult-gh     "3.0")
    (embark-consult "1.1")
    (which-key      "3.6.0"))
  :url "https://github.com/armindarvish/consult-gh"
  :commit "7b0fba0dc81a446c95cd39fa2a6adcd39501df9d"
  :revdesc "7b0fba0dc81a"
  :keywords '("matching" "git" "repositories" "forges" "completion"))
