;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kite-mini" "20160508.1106"
  "Remotely evaluate JavaScript in the WebKit debugger."
  '((dash      "2.11.0")
    (websocket "1.5"))
  :url "https://github.com/tungd/kite-mini.el"
  :commit "48734092e735033ad7664a9933acd4556e095f79"
  :revdesc "48734092e735"
  :keywords '("webkit")
  :authors '(("Tung Dao" . "me@tungdao.com"))
  :maintainers '(("Tung Dao" . "me@tungdao.com")))
