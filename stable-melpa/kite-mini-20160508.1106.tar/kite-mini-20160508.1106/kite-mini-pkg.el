(define-package "kite-mini" "20160508.1106" "Remotely evaluate JavaScript in the WebKit debugger"
  '((dash "2.11.0")
    (websocket "1.5"))
  :commit "48734092e735033ad7664a9933acd4556e095f79" :authors
  '(("Tung Dao" . "me@tungdao.com"))
  :maintainer
  '("Tung Dao" . "me@tungdao.com")
  :keywords
  '("webkit")
  :url "https://github.com/tungd/kite-mini.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
