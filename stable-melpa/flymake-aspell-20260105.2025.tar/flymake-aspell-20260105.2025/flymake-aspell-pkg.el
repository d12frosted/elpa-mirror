;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-aspell" "20260105.2025"
  "Aspell checker for flymake."
  '((emacs "26.1"))
  :url "https://github.com/leotaku/flycheck-aspell"
  :commit "abbac0f6ccd94224f19c70d8545fddfe9c27351f"
  :revdesc "abbac0f6ccd9"
  :keywords '("wp" "flymake" "spell" "aspell")
  :authors '(("Leo Gaskin" . "leo.gaskin@le0.gs"))
  :maintainers '(("Leo Gaskin" . "leo.gaskin@le0.gs")))
