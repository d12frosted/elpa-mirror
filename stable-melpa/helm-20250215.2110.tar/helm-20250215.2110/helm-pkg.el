;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250215.2110"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.1")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "807a7ef45fc01388cfcbc3f2622efb50d117126c"
  :revdesc "807a7ef45fc0"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
