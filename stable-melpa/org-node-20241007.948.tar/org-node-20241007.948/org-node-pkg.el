;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241007.948"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "123a7817682f78af27ba241337d67f9426a4f578"
  :revdesc "123a7817682f"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
