;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anju" "20260424.1819"
  "Mouse UX Customizations."
  '((emacs         "29.1")
    (casual        "2.14.0")
    (markdown-mode "2.7"))
  :url "https://github.com/kickingvegas/anju"
  :commit "b44537683c264d13c05dbeb5bb04792558aaf9b2"
  :revdesc "b44537683c26"
  :keywords '("tools")
  :authors '(("Charles Choi" . "charles.choi@yummymelon.com"))
  :maintainers '(("Charles Choi" . "charles.choi@yummymelon.com")))
