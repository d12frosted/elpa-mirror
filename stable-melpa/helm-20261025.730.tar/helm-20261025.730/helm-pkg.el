;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20261025.730"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.8")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "55efc1816427ca0739d68dcee6b3c3fe9cb94ff7"
  :revdesc "55efc1816427"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
