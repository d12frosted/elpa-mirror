;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20260825.741"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "28.1")
    (epkg  "4.2")
    (magit "4.7"))
  :url "https://github.com/emacscollective/borg"
  :commit "a5f37eea56039cf47c0de71d097afca5140cdc78"
  :revdesc "a5f37eea5603"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
