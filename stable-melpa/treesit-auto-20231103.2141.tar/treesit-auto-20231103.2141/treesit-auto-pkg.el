(define-package "treesit-auto" "20231103.2141" "Automatically use tree-sitter enhanced major modes"
  '((emacs "29.0"))
  :commit "f0cf4cf93f2877a07c61fb4d10d3fe51be4da3a8" :authors
  '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainers
  '(("Robb Enzmann" . "robbenzmann@gmail.com"))
  :maintainer
  '("Robb Enzmann" . "robbenzmann@gmail.com")
  :keywords
  '("treesitter" "auto" "automatic" "major" "mode" "fallback" "convenience")
  :url "https://github.com/renzmann/treesit-auto.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
