;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20260926.1128"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "519e20239d3f4ac21cd9849361622d9c4c8f0e37"
  :revdesc "519e20239d3f"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
