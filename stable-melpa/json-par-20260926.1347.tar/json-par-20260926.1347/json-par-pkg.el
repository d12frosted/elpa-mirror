;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "json-par" "20260926.1347"
  "Minor mode for structural editing of JSON."
  '((emacs "24.4"))
  :url "https://github.com/taku0/json-par"
  :commit "dff1ab465376adffb0ac79ac7de44a4c9b6e82eb"
  :revdesc "dff1ab465376"
  :keywords '("abbrev" "convenience" "files")
  :authors '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainers '(("taku0" . "mxxouy6x3m_github@tatapa.org")))
