(define-package "gumshoe" "20210923.2359" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "b5c7121a4a6e67c7e90bb6d8363936e50876093f" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
