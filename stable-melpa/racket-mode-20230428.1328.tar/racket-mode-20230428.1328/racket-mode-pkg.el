(define-package "racket-mode" "20230428.1328" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "dcb3a8619c6c999816db88737f74d6a68df7d726" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
