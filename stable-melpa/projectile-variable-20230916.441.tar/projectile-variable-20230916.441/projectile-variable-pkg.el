;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-variable" "20230916.441"
  "Store project local variables."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/emacs-php/projectile-variable"
  :commit "fa6bf595529156ee3b6d08f90ebea3b4ab7c5ef8"
  :revdesc "fa6bf5955291"
  :keywords '("project" "convenience")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
