;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20261028.1752"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "903caa63e7f381753a3926b505c326492a6dcbb9"
  :revdesc "903caa63e7f3"
  :keywords '("lisp" "tools" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
