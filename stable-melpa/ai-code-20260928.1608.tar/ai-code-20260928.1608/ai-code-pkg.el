;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260928.1608"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "46e849c99d3c21e154fd9157515311926abc64e8"
  :revdesc "46e849c99d3c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
