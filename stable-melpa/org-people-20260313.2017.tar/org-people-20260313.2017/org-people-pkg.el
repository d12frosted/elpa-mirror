;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260313.2017"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "7c0f3224f6208a44cfc9514b9eb040383d6430c3"
  :revdesc "7c0f3224f620"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
