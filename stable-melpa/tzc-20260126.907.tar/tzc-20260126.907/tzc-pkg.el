;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260126.907"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "524112208fa65652137dc166c812767cf1dfe7fa"
  :revdesc "524112208fa6"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
