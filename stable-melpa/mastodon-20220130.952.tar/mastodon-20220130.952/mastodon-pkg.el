(define-package "mastodon" "20220130.952" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.2")
    (seq "1.0"))
  :commit "5a0cc2fcc5fa0dad2d884dcc9989222d6df9e88e" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://git.blast.noho.st/mouse/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
