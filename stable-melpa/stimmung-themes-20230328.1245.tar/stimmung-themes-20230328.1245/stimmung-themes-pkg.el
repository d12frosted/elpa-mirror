(define-package "stimmung-themes" "20230328.1245" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "edd330a418e39ca06c35993fa6ee6f6f4efea9ee" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
