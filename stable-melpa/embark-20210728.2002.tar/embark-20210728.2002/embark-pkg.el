(define-package "embark" "20210728.2002" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "bdb282f8b1ce265318a5f259b8b08896af7cb1a8" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
