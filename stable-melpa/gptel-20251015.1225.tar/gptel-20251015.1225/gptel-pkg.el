;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251015.1225"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "9d685b9b3400337d6137a2c94903e15e18736aea"
  :revdesc "9d685b9b3400"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
