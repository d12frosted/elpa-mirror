(define-package "verb" "20210331.2123" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "95cb2357ba30f1c746929105bdeefae661a70cb2" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
