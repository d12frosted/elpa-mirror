(define-package "srfi" "20201222.709" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "f26b37d8c32a033ab4dd7d5c707fd2f2dfccf85e" :keywords
  ("languages" "util")
  :authors
  (("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  ("Lassi Kortela" . "lassi@lassi.io")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
