(define-package "gnosis" "20240221.1634" "Spaced Repetition System For Note Taking & Self Testing"
  '((emacs "27.2")
    (compat "29.1.4.2")
    (emacsql "20240124"))
  :commit "8ff330788c29895922ed626266b8095ecbdadde5" :authors
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.org")
  :keywords
  '("extensions")
  :url "https://thanosapollo.org/projects/gnosis")
;; Local Variables:
;; no-byte-compile: t
;; End:
