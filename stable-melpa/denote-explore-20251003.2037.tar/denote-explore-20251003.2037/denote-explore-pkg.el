;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-explore" "20251003.2037"
  "Explore and visualise Denote files."
  '((emacs  "29.1")
    (denote "4.0")
    (dash   "2.19.1"))
  :url "https://github.com/pprevos/denote-explore/"
  :commit "6a3baa7a58857f8be6b7eb09150da16f763f03be"
  :revdesc "6a3baa7a5885"
  :authors '(("Peter Prevos" . "peter@prevos.net"))
  :maintainers '(("Peter Prevos" . "peter@prevos.net")))
