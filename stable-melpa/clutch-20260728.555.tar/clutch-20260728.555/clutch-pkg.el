;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260728.555"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "bb90fa1a5b4a4f8e0a739a63ab9fb25c1e92451f"
  :revdesc "bb90fa1a5b4a"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
