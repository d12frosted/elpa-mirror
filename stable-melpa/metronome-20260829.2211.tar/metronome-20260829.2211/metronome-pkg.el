;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "metronome" "20260829.2211"
  "The missing metronome for GNU Emacs."
  '((emacs "25.1"))
  :url "https://git.sr.ht/~jagrg/metronome"
  :commit "3c601454086f0e6fc29c3c976820e87beedf3c9d"
  :revdesc "3c601454086f"
  :authors '(("Jonathan Gregory" . "jagrgatposteodotcom"))
  :maintainers '(("Jonathan Gregory" . "jagrgatposteodotcom")))
