;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calfw" "20251022.1720"
  "Calendar view framework."
  '((emacs "28.1"))
  :url "https://github.com/haji-ali/emacs-calfw"
  :commit "967b8c6597160b9f4a0809bca1364082099dbc70"
  :revdesc "967b8c659716"
  :keywords '("calendar")
  :authors '(("SAKURAI Masashi" . "m.sakuraiatkiwanami.net"))
  :maintainers '(("Al Haji-Ali" . "abdo.haji.aliatgmail.com")))
