;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mynt-mode" "20150512.2049"
  "Minor mode to work with the mynt static site generator."
  '((virtualenvwrapper "20131514"))
  :url "https://github.com/crshd/mynt-mode"
  :commit "23d4489167bfa899634548cb41ed32fdeb3600c9"
  :revdesc "23d4489167bf"
  :keywords '("convenience"))
