;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mock-fs" "20260708.2247"
  "Virtual filesystem for Emacs Lisp tests."
  '((emacs "27.1"))
  :url "https://codeberg.org/Trevoke/mock-fs.el"
  :commit "b15c34281d076d6aa1ea5820368307694952e2ce"
  :revdesc "b15c34281d07"
  :keywords '("testing" "files"))
