;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-get" "20260607.2213"
  "Manage the external elisp bits and pieces you depend upon."
  ()
  :url "http://www.emacswiki.org/emacs/el-get"
  :commit "c9a738029aa48cfdf994fb2454db091048d87284"
  :revdesc "c9a738029aa4"
  :keywords '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
