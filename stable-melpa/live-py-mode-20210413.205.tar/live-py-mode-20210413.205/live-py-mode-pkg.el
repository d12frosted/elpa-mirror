(define-package "live-py-mode" "20210413.205" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "9f49917b61453f717fd50154f25ab2be4fe2e3ec" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
