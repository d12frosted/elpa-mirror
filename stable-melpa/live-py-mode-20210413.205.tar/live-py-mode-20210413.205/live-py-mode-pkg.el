(define-package "live-py-mode" "20210413.205" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "a37f6b2394dcc2a848a055399dd45b052c9b707d" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
