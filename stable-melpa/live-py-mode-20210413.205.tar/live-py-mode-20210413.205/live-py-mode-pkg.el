(define-package "live-py-mode" "20210413.205" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "26d51013e75ddedd5eb8600a0a3dd035319f9d3f" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
