(define-package "magit-section" "20210806.1607" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "2.18.1"))
  :commit "14ae9f6d9016d8ced2cc8daad949a73b150c2f13" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
