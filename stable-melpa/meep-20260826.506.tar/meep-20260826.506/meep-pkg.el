;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260826.506"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "ddd765698505e2460ea315e55570adac2e10ffec"
  :revdesc "ddd765698505"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
