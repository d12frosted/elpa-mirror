(define-package "srfi" "20210306.18" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "78d65e571a811088d726858f8f60b9c55f26cfcb" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
