(define-package "treebundel" "20230917.1933" "Bundle related git-worktrees together"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "869e79dd95997e76443b3aea1567532d58e61956" :authors
  '(("Ben Whitley"))
  :maintainers
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/treebundel")
;; Local Variables:
;; no-byte-compile: t
;; End:
