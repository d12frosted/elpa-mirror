;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "line-reminder" "20260406.657"
  "Line annotation for changed and saved lines."
  '((emacs         "25.1")
    (fringe-helper "1.0.1")
    (ov            "1.0.6")
    (ht            "2.0"))
  :url "https://github.com/emacs-vs/line-reminder"
  :commit "ff080f2f1b42c627d4720cd23751b93f5c6457c2"
  :revdesc "ff080f2f1b42"
  :keywords '("convenience" "annotation")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
