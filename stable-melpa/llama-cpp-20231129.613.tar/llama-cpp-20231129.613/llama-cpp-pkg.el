(define-package "llama-cpp" "20231129.613" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "21b97fc2339e57fe8cf9754f22e5b71c860e81fa" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
