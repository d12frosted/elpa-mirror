(define-package "spdx" "20230503.110" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "ef48c77e746e93973ae7a43f5b018bc9564eac10" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
