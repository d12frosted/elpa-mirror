(define-package "consult-eglot" "20240316.1747" "A consulting-read interface for eglot"
  '((emacs "27.1")
    (eglot "1.7")
    (consult "0.31")
    (project "0.3.0"))
  :commit "3d8bc8a9a944dcfe919f909a0350a6c86e3a7fe3" :authors
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem"))
  :maintainer
  '("Mohsin Kaleem")
  :keywords
  '("tools" "completion" "lsp")
  :url "https://github.com/mohkale/consult-eglot")
;; Local Variables:
;; no-byte-compile: t
;; End:
