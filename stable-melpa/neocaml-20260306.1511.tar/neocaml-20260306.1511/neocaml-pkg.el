;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260306.1511"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "2782f2b9fbde590789bb75a76f3efc1008b51e78"
  :revdesc "2782f2b9fbde"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
