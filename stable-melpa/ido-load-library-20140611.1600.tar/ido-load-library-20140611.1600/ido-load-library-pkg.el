;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-load-library" "20140611.1600"
  "Load-library alternative using ido-completing-read."
  '((persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/ido-load-library"
  :commit "f439559721c5fecb2572dcaf3e357c5d94a20f4a"
  :revdesc "f439559721c5"
  :keywords '("maint" "completion")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
