;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-phpstan" "20260717.1734"
  "Flymake backend for PHP using PHPStan."
  '((emacs   "27.1")
    (phpstan "0.10.0"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "00942a5d5b28560bd08f7355d131074772bb7a01"
  :revdesc "00942a5d5b28"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
