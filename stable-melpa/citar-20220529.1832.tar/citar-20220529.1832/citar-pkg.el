(define-package "citar" "20220529.1832" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "3.0")
    (org "9.5")
    (citeproc "0.9"))
  :commit "56477158e7fd350c0a3a0f11bc3008a0041c415f" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
