(define-package "citar" "20220529.1832" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (parsebib "3.0")
    (org "9.5")
    (citeproc "0.9"))
  :commit "c32623df2d90e987edaa8a90b53d137c103f7eb1" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
