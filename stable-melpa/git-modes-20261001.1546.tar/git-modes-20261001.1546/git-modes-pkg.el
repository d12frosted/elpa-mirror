;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-modes" "20261001.1546"
  "Major modes for editing Git configuration files."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/magit/git-modes"
  :commit "f8a453725586c8225e47afca4c8cbc2c5585bf33"
  :revdesc "f8a453725586"
  :keywords '("convenience" "vc" "git")
  :authors '(("Sebastian Wiesner" . "lunaryorn@gmail.com")
             ("Rüdiger Sonderfeld" . "ruediger@c-plusplus.net")
             ("Jonas Bernoulli" . "emacs.git-modes@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.git-modes@jonas.bernoulli.dev")))
