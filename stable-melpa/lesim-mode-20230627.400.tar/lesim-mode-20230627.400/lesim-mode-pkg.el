(define-package "lesim-mode" "20230627.400" "Major mode for Learning Simulator scripts"
  '((emacs "28.1"))
  :commit "4f434263ea270864a87adaa8cc1dccfa784d2d60" :authors
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainer
  '("Stefano Ghirlanda" . "drghirlanda@gmail.com")
  :keywords
  '("languages" "faces")
  :url "https://github.com/drghirlanda/lesim-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
