;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260315.818"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "fdfc9f013d93386852db5ebe348295103beb8f96"
  :revdesc "fdfc9f013d93"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
