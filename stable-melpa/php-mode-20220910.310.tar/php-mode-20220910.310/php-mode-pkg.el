(define-package "php-mode" "20220910.310" "Major mode for editing PHP code"
  '((emacs "25.2"))
  :commit "6b24392a51f2689158526a5eca4cb71f112317d1" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
