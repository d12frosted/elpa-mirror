;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250308.1618"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (el-job        "1.0.5")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "d5a685d80675f47d9110f1055ac1f7d74cb7f664"
  :revdesc "d5a685d80675"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
