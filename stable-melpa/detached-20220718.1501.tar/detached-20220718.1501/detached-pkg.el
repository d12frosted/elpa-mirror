(define-package "detached" "20220718.1501" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "d8e657cc569da2ad0f1916aa0b5dbc444f0675ff" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
