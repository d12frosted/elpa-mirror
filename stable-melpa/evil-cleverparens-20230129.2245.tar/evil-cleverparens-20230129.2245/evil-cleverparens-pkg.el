(define-package "evil-cleverparens" "20230129.2245" "Evil friendly minor-mode for editing lisp."
  '((evil "1.0")
    (paredit "1")
    (smartparens "1.6.1")
    (emacs "24.4")
    (dash "2.12.0"))
  :commit "31dece3c78a445a427d7f1af1d9c7da9951777d9" :authors
  '(("Olli Piepponen" . "opieppo@gmail.com"))
  :maintainer
  '("Olli Piepponen" . "opieppo@gmail.com")
  :keywords
  '("convenience" "emulations")
  :url "https://github.com/emacs-evil/evil-cleverparens")
;; Local Variables:
;; no-byte-compile: t
;; End:
