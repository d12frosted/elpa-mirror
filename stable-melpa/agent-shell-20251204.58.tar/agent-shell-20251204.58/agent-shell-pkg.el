;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251204.58"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "24dedec1960e59d093a0c3e4d96354f5553c8ecc"
  :revdesc "24dedec1960e")
