;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddskk" "20260323.1222"
  "Daredevil SKK (Simple Kana to Kanji conversion program)."
  '((ccc "1.43")
    (cdb "20141201.754"))
  :url "https://github.com/skk-dev/ddskk"
  :commit "e1171f53c89cce1ebc1e1cd3a6555cd01f20dc56"
  :revdesc "e1171f53c89c"
  :keywords '("japanese" "mule" "input method")
  :authors '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp")))
