;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20260427.2331"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "b8b1ecca0430ea8bdcd15cb37eba7b38ba797b67"
  :revdesc "b8b1ecca0430"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
