;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agitjo" "20260523.2048"
  "Manage Forgejo PRs with AGit-Flow."
  '((emacs         "30.1")
    (magit         "4.3.8")
    (markdown-mode "2.7")
    (transient     "0.9.1"))
  :url "https://codeberg.org/halvin/agitjo"
  :commit "fa9737479f44c62f76e2dc6561ffb340d8eead3e"
  :revdesc "fa9737479f44"
  :keywords '("convenience" "vc" "tools")
  :authors '(("Alvin Hsu" . "aurtzy@gmail.com"))
  :maintainers '(("Alvin Hsu" . "aurtzy@gmail.com")))
