;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20261023.2028"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "81be7ee737addf7d44c56b54c7f47602e3f2b425"
  :revdesc "81be7ee737ad"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
