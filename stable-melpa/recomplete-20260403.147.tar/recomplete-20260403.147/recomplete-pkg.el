;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "recomplete" "20260403.147"
  "Immediately (re)complete actions."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-recomplete"
  :commit "06ea322d363f547cacc43086dd0a29104b27d25e"
  :revdesc "06ea322d363f"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
