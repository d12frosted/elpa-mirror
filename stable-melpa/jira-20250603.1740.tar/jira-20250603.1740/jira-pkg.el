;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20250603.1740"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "1380f3c6d84f3a576172e0dcd50d3b656a475bc9"
  :revdesc "1380f3c6d84f"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
