(define-package "clojure-mode-extra-font-locking" "20231012.1232" "Extra font-locking for Clojure mode"
  '((clojure-mode "3.0"))
  :commit "661c80e3db9fa5990b39aa5277fb27a047c2546c" :authors
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers
  '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainer
  '("Bozhidar Batsov" . "bozhidar@batsov.dev")
  :keywords
  '("languages" "lisp")
  :url "https://github.com/clojure-emacs/clojure-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
