(define-package "mlscroll" "20231124.310" "A scroll bar for the modeline"
  '((emacs "27.1"))
  :commit "4c3a2fb87f922ead06db43c7a9a57d078a407a76" :authors
  '(("J.D. Smith"))
  :maintainers
  '(("J.D. Smith"))
  :maintainer
  '("J.D. Smith")
  :keywords
  '("convenience")
  :url "https://github.com/jdtsmith/mlscroll")
;; Local Variables:
;; no-byte-compile: t
;; End:
