(define-package "frimacs" "20230409.1041" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "dfba4a1ca94b5f1d29659c3f786647dcdc315672" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainers
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
