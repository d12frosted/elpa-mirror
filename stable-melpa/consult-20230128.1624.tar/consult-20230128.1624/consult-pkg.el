(define-package "consult" "20230128.1624" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.0"))
  :commit "778074acfbacb1f39b497dc5b2a212b83d0f3497" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
