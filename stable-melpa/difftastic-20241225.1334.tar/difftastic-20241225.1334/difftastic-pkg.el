;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "20241225.1334"
  "Wrapper for difftastic."
  '((emacs     "28.1")
    (compat    "29.1.4.2")
    (magit     "4.0.0")
    (transient "0.4.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "ed0a77a4e3703812eda69939c9fdf3f55285d461"
  :revdesc "ed0a77a4e370"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
