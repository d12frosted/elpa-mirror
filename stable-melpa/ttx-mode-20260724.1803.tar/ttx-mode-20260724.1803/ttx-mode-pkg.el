;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ttx-mode" "20260724.1803"
  "TrueType/OpenType font viewer using ttx."
  '((emacs "30.0"))
  :url "https://github.com/wmedrano/ttx-mode"
  :commit "ba9b25a63abdbd97775cd8f0a7e2b81b9410d872"
  :revdesc "ba9b25a63abd"
  :keywords '("tools" "fonts")
  :authors '(("Will Medrano" . "will@wmedrano.dev"))
  :maintainers '(("Will Medrano" . "will@wmedrano.dev")))
