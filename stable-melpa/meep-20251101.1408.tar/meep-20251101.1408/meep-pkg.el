;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251101.1408"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "74d135a0a6cb02c7eee14a11e5a3ba651113b7f7"
  :revdesc "74d135a0a6cb"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
