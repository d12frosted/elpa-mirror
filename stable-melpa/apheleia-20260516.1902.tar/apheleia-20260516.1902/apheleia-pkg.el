;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apheleia" "20260516.1902"
  "Reformat buffer stably."
  '((emacs "27"))
  :url "https://github.com/radian-software/apheleia"
  :commit "b5bf00151a3f49f679020fb0e35a1d264956668a"
  :revdesc "b5bf00151a3f"
  :keywords '("tools")
  :authors '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+apheleia@radian.codes")))
