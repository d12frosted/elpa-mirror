(define-package "universal-sidecar-elfeed-score" "20230923.31" "Show Elfeed Score information in sidecar"
  '((emacs "25.1")
    (universal-sidecar "1.0.0")
    (bibtex-completion "1.0.0")
    (elfeed "3.4.1")
    (elfeed-score "1.2.6"))
  :commit "0cec1fa196df55cfb13c1e2ee226b55ff740e7f2" :authors
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers
  '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainer
  '("Samuel W. Flint" . "me@samuelwflint.com")
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar")
;; Local Variables:
;; no-byte-compile: t
;; End:
