;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tiles" "20260315.2112"
  "Tagged Instant Lightweight Emacs Snippets."
  '((emacs "27.1"))
  :url "https://github.com/ctanas/tiles"
  :commit "f77e2cf19b4895cd7da50922db3a622e3b848ec8"
  :revdesc "f77e2cf19b48"
  :keywords '("files" "text" "convenience")
  :authors '(("Claudiu Tănăselia" . "https://www.tanaselia.ro"))
  :maintainers '(("Claudiu Tănăselia" . "https://www.tanaselia.ro")))
