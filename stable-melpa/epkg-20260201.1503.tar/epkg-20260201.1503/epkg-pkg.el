;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260201.1503"
  "Browse the Emacsmirror package database."
  '((emacs   "28.1")
    (compat  "30.1")
    (closql  "2.4")
    (emacsql "4.3")
    (llama   "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "7758de6c8b6d56829b134be751562b1f885d311b"
  :revdesc "7758de6c8b6d"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
