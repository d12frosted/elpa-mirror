;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20250405.1906"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "b1cb4b559077b0dd76e41039da88cbabe2df2731"
  :revdesc "b1cb4b559077"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
