;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-mode" "20260502.954"
  "A major mode for editing OpenSCAD code."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/openscad/emacs-scad-mode"
  :commit "1b20986e76860514fbf574abeff23676314d7e4c"
  :revdesc "1b20986e7686"
  :keywords '("languages")
  :maintainers '(("Len Trigg" . "lenbok@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
