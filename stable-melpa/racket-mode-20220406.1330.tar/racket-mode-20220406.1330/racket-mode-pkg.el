(define-package "racket-mode" "20220406.1330" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "e7efbb52fdf2219532230a199153d8a33889c26f" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
