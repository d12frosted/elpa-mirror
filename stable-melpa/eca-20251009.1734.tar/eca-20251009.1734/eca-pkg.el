;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20251009.1734"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "a8c219379b2fae2e9226de5b2f0a40e1e1cd8645"
  :revdesc "a8c219379b2f"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
