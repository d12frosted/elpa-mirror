;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hnreader" "20260824.2055"
  "A hackernews reader."
  '((emacs   "25.1")
    (promise "1.1")
    (request "0.3.0")
    (org     "9.2"))
  :url "https://github.com/thanhvg/emacs-hnreader/"
  :commit "3a1ad5f3711b89e3e2f8506cc485ce9f8e8ca216"
  :revdesc "3a1ad5f3711b"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
