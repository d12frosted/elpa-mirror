;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20261116.1212"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "1f7a97bc212fc10ef4fc2d8a0fe981d6bb7346c4"
  :revdesc "1f7a97bc212f"
  :keywords '("convenience" "comm" "hypermedia"))
