(define-package "tmsu" "20230322.2344" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "567ba42958592e632bf611f004d24c09eb2eeac1" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
