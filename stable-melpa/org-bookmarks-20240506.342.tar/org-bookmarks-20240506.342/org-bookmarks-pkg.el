(define-package "org-bookmarks" "20240506.342" "Manage bookmarks in Org mode"
  '((emacs "26.1"))
  :commit "cac6cf89fe8813109dd84ccc612fa14ebfce965a" :keywords
  '("outline" "matching" "hypermedia" "org")
  :url "https://repo.or.cz/org-bookmarks.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
