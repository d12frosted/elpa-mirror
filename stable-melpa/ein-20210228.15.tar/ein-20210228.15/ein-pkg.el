(define-package "ein" "20210228.15" "Emacs IPython Notebook"
  '((emacs "25")
    (websocket "20190620")
    (anaphora "20180618")
    (request "20200117")
    (deferred "0.5")
    (polymode "20190714")
    (dash "2.13.0")
    (with-editor "20200522"))
  :commit "93475858554b74eb76eeecf81cebd7d32065aa07" :keywords
  '("jupyter" "literate programming" "reproducible research")
  :url "https://github.com/dickmao/emacs-ipython-notebook")
;; Local Variables:
;; no-byte-compile: t
;; End:
