(define-package "ox-linuxmag-fr" "20230129.800" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "c3d7c234ff94a47d732c1735832320ef669fa0fe" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
