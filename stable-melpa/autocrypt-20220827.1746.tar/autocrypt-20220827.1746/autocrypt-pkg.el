(define-package "autocrypt" "20220827.1746" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "9e393f869a276c7d7d52b89f0bab79a70455fefa" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
