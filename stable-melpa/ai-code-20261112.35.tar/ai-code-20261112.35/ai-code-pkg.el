;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261112.35"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "35fee381b6900efd01fe7716a92c3d4fdd6bb83f"
  :revdesc "35fee381b690"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
