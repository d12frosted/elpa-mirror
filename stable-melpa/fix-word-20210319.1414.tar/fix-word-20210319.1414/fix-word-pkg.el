;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fix-word" "20210319.1414"
  "Convenient word transformation."
  '((emacs  "24.1")
    (cl-lib "0.5"))
  :url "https://github.com/mrkkrp/fix-word"
  :commit "80cf4529915c34d2d39b4d3410781a19ef264e9f"
  :revdesc "80cf4529915c"
  :keywords '("word" "convenience")
  :authors '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainers '(("Mark Karpov" . "markkarpov92@gmail.com")))
