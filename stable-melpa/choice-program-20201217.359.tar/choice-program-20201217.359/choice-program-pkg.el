(define-package "choice-program" "20201217.359" "Parameter based program"
  '((emacs "26")
    (dash "2.13.0"))
  :commit "27d7219b775f3061536fdca6eb52142d6a21781c" :authors
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("execution" "processes" "unix" "lisp")
  :url "https://github.com/plandes/choice-program")
;; Local Variables:
;; no-byte-compile: t
;; End:
