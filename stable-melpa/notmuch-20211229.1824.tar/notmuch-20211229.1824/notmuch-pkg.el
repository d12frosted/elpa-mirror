(define-package "notmuch" "20211229.1824" "run notmuch within emacs" 'nil :commit "63d3b2b5cf8702b5fecea77392ce46f8a8249175" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
