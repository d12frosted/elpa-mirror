(define-package "notmuch" "20211229.1824" "run notmuch within emacs" 'nil :commit "22e04ed01acc115b7fb25b60231014f585f11c4a" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
