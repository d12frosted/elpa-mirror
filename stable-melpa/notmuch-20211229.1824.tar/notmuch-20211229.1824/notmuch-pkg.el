(define-package "notmuch" "20211229.1824" "run notmuch within emacs" 'nil :commit "6721e2eac5c8698cc7f364c58c646f6b44105b57" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
