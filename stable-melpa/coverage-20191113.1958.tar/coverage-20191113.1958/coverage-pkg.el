;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coverage" "20191113.1958"
  "Code coverage line highlighting."
  '((ov     "1.0")
    (cl-lib "0.5"))
  :url "https://github.com/trezona-lecomte/coverage"
  :commit "6e3c6f2dcb759a76086adeeb1fdfe83e4f082482"
  :revdesc "6e3c6f2dcb75"
  :keywords '("coverage" "metrics" "simplecov" "ruby" "rspec")
  :authors '(("Kieran Trezona-le Comte" . "trezona.lecomte@gmail.com"))
  :maintainers '(("Kieran Trezona-le Comte" . "trezona.lecomte@gmail.com")))
