;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "format-all" "20260616.1201"
  "Auto-format C, C++, JS, Python, Ruby and 50 other languages."
  '((emacs       "24.4")
    (inheritenv  "0.1")
    (language-id "0.20"))
  :url "https://github.com/lassik/emacs-format-all-the-code"
  :commit "a103e2a1b7eb89e48f4f4f3310637bf1033ee456"
  :revdesc "a103e2a1b7eb"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
