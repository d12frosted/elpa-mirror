;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ct" "20260916.1445"
  "Color Tools - a color api."
  '((emacs "26.1")
    (dash  "2.18.0")
    (hsluv "1.0.0"))
  :url "https://github.com/neeasade/ct.el"
  :commit "0183c1120a5b405c9886fa3ec3fabef4dc4f9ec6"
  :revdesc "0183c1120a5b"
  :keywords '("convenience" "color" "theming" "background" "rgb" "hsv" "hsl" "hct" "lab" "oklab" "oklch"))
