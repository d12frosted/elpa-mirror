;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syncthing" "20241210.2246"
  "Client for Syncthing."
  '((emacs "27.1"))
  :url "https://github.com/KeyWeeUsr/emacs-syncthing"
  :commit "30492cfce9982e08a16820e94764bbf1b392d33d"
  :revdesc "30492cfce998"
  :keywords '("convenience" "syncthing" "sync" "client" "view")
  :authors '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers '(("Peter Badida" . "keyweeusr@gmail.com")))
