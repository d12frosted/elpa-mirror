;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250709.1535"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "6fe63fa4e4c50b6b48e88f7683671e8eb5c9bd3f"
  :revdesc "6fe63fa4e4c5"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
