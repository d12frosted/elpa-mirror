(define-package "async" "20221014.515" "Asynchronous processing in Emacs"
  '((emacs "24.4"))
  :commit "0efee626a44f794e061850f605364310953b6b7a" :authors
  '(("John Wiegley" . "jwiegley@gmail.com"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("async")
  :url "https://github.com/jwiegley/emacs-async")
;; Local Variables:
;; no-byte-compile: t
;; End:
