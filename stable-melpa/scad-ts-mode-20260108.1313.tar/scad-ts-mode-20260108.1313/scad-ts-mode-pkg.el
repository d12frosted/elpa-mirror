;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scad-ts-mode" "20260108.1313"
  "Tree-sitter support for OpenSCAD."
  '((emacs "29.3"))
  :url "https://github.com/yoshinari-nomura/scad-ts-mode"
  :commit "3a030b6366ba81a842f8df9421882547f00d1fb7"
  :revdesc "3a030b6366ba"
  :keywords '("openscad" "languages" "tree-sitter")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
