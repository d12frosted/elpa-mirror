(define-package "github-elpa" "20160922.1607" "Build and publish ELPA repositories with GitHub Pages"
  '((package-build "1.0")
    (commander "0.7.0")
    (git "0.1.1"))
  :commit "c5960375ed5d67465412be7eb0ac558082feebc7" :authors
  '((nil . "10sr<8slashes+el@gmail.com>"))
  :maintainer
  '(nil . "10sr<8slashes+el@gmail.com>")
  :url "https://github.com/10sr/github-elpa")
;; Local Variables:
;; no-byte-compile: t
;; End:
