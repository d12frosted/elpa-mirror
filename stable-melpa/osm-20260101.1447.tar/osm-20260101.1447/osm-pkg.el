;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260101.1447"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/osm"
  :commit "0493d3b398ccf42a7c3305c486190ad7e8c41274"
  :revdesc "0493d3b398cc"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
