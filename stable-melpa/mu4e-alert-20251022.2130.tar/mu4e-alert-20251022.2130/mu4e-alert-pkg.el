;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-alert" "20251022.2130"
  "Desktop notification for mu4e."
  '((alert "1.2")
    (s     "1.10.0")
    (ht    "2.0")
    (emacs "24.4"))
  :url "https://github.com/xzz53/mu4e-alert"
  :commit "9f20f30b15a5f5cc43fe448684fe1d4b981639aa"
  :revdesc "9f20f30b15a5"
  :keywords '("mail" "convenience")
  :authors '(("Iqbal Ansari" . "iqbalansari02@yahoo.com"))
  :maintainers '(("Mikhail Rudenko" . "mike.rudenko@gmail.com")))
