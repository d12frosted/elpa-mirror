;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meshmonitor-chat" "20260609.557"
  "Chat client for MeshMonitor (Meshtastic)."
  '((emacs "28.1"))
  :url "https://git.andros.dev/andros/meshmonitor-chat.el"
  :commit "cb89039bb723301d2a69326f98ca1f141d6a0112"
  :revdesc "cb89039bb723"
  :keywords '("comm")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
