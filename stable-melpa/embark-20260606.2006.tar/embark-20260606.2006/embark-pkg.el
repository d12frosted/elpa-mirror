;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark" "20260606.2006"
  "Conveniently act on minibuffer completions."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/oantolin/embark"
  :commit "4555c4d6276965bb00c570cd76a91ddc84e926a0"
  :revdesc "4555c4d62769"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
