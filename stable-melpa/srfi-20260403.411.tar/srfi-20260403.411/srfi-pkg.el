;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260403.411"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "272df3cae401da0853dc50344500b522f96a9286"
  :revdesc "272df3cae401"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
