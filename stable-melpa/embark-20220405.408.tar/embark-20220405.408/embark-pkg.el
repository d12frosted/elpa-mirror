(define-package "embark" "20220405.408" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "b57c947f20dc36faff7a43076b9a3b0358f87921" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
