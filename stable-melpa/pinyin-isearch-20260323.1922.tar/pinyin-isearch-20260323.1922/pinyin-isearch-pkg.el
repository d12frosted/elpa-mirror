;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260323.1922"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "935e582668d6a9a55fd9dd262d46ed1f2bb98f35"
  :revdesc "935e582668d6"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
