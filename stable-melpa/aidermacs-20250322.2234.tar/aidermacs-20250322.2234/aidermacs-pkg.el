;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250322.2234"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "992ab4867452fe2d2ec2153fc172fcc72281a3cd"
  :revdesc "992ab4867452"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
