(define-package "emacsshot" "20191206.137" "Snapshot a frame or window from within"
  '((emacs "24.4"))
  :commit "f0add6820d250875f7d7c21aa5d813dc73dbcf96" :authors
  '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainer
  '("Marco Wahl")
  :keywords
  '("convenience")
  :url "https://github.com/marcowahl/emacsshot")
;; Local Variables:
;; no-byte-compile: t
;; End:
