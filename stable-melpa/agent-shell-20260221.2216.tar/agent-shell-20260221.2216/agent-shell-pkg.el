;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260221.2216"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "cd655a5ce92df48c371e3400591e72841a8b5031"
  :revdesc "cd655a5ce92d")
