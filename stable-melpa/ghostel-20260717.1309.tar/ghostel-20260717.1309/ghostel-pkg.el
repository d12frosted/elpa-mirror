;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260717.1309"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "7aa53db6ce82612b868c70e44087ac55f4354d56"
  :revdesc "7aa53db6ce82"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
