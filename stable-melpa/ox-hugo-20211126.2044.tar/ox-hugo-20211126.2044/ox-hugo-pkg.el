(define-package "ox-hugo" "20211126.2044" "Hugo Markdown Back-End for Org Export Engine"
  '((emacs "24.4")
    (org "9.0"))
  :commit "8bdfa0e3e4b96d8dadf8c97d4e781f32ded9af06" :keywords
  '("org" "markdown" "docs")
  :url "https://ox-hugo.scripter.co")
;; Local Variables:
;; no-byte-compile: t
;; End:
