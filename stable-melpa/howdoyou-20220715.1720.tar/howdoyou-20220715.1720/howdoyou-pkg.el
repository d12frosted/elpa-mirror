(define-package "howdoyou" "20220715.1720" "A stackoverflow and its sisters' sites reader"
  '((emacs "25.1")
    (promise "1.1")
    (request "0.3.3")
    (org "9.2"))
  :commit "f6c659a45f59a08546578c169524a12f0945c29b" :authors
  '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers
  '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainer
  '("Thanh Vuong" . "thanhvg@gmail.com")
  :url "https://github.com/thanhvg/howdoyou/")
;; Local Variables:
;; no-byte-compile: t
;; End:
