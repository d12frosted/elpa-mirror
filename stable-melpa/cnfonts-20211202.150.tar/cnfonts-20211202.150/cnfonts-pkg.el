(define-package "cnfonts" "20211202.150" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "d282125b23c312682a8df80811d8667335bd2072" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
