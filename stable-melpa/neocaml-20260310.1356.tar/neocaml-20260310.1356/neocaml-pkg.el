;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260310.1356"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "b1ce3fd80bbf89836dfe2da97bc44ec2351d968d"
  :revdesc "b1ce3fd80bbf"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
