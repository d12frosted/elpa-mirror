(define-package "xit-mode" "20221006.717" "A [x]it! major mode"
  '((emacs "24.1"))
  :commit "f9f8f07c54090f03107180b125c54e329493a1a7" :keywords
  '("xit" "todo" "tools" "convinience" "project")
  :url "https://github.com/ryanolsonx/xit-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
