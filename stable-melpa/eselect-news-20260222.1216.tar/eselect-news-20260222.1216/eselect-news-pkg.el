;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eselect-news" "20260222.1216"
  "Read Gentoo eselect news."
  '((emacs "27.1"))
  :url "https://gitlab.com/cestrand/emacs-eselect-news"
  :commit "562191c013a20348bd1adbf3be564c6e1d3c52b6"
  :revdesc "562191c013a2"
  :keywords '("gentoo" "convenience")
  :authors '(("Marcin Kolenda" . "https://gitlab.com/cestrand"))
  :maintainers '(("Marcin Kolenda" . "https://gitlab.com/cestrand")))
