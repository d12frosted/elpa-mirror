;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pest" "20200710.2327"
  "Flycheck integration for Pest -."
  '((emacs     "26.3")
    (flycheck  "31")
    (pest-mode "0.1"))
  :url "https://github.com/ksqsf/pest-mode"
  :commit "43447a2c70f98edd1139005e32f437d3f142442b"
  :revdesc "43447a2c70f9"
  :keywords '("convenience" "flycheck")
  :authors '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers '(("Naoya Yamashita" . "conao3@gmail.com")))
