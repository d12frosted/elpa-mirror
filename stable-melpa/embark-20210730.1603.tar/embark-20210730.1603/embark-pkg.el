(define-package "embark" "20210730.1603" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "85bc5599f6eabc8924ec63317e64f740c59375ca" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
