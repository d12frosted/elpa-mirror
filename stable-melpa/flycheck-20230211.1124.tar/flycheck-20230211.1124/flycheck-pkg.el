(define-package "flycheck" "20230211.1124" "On-the-fly syntax checking"
  '((dash "2.12.1")
    (pkg-info "0.4")
    (let-alist "1.0.4")
    (seq "1.11")
    (emacs "24.3"))
  :commit "7f6b1518ec74e3dad813efed3ef84783e5c370de" :authors
  '(("Sebastian Wiesner" . "swiesner@lunaryorn.com"))
  :maintainer
  '("Clément Pit-Claudel" . "clement.pitclaudel@live.com")
  :keywords
  '("convenience" "languages" "tools")
  :url "http://www.flycheck.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
