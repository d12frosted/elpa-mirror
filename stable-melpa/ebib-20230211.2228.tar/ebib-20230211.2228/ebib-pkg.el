(define-package "ebib" "20230211.2228" "a BibTeX database manager"
  '((parsebib "4.0")
    (emacs "26.1"))
  :commit "abe6ed461b334673001b930f7e30752aa8aff526" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
