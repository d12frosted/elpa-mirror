;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20241110.1807"
  "Easily persist and restore your editing sessions."
  '((emacs "25.1")
    (f     "0.18.2"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "07d26a173be3e5eeec2a4ce32d2617bc8d24ea5b"
  :revdesc "07d26a173be3"
  :keywords '("convenience"))
