(define-package "catppuccin-theme" "20230326.319" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "1d88949f2e4b21dcc77879f0fb2cc98a38d66565" :authors
  '(("nyxkrage"))
  :maintainer
  '("Carsten Kragelund" . "carsten@kragelund.me")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
