;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260214.1243"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "http://github.com/bbatsov/neocaml"
  :commit "f416e6fa5413d7283c076f436dfef1108ca05da4"
  :revdesc "f416e6fa5413"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
