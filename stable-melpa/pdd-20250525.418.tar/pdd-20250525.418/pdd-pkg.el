;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250525.418"
  "Modern HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "353301396497c3f37a43f9af51c89d5feb47320a"
  :revdesc "353301396497"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
