;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20250425.1514"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "http://github.com/clojure-emacs/clojure-ts-mode"
  :commit "e960a905ab9ae6c77101ca1e65dd76e59c7f4009"
  :revdesc "e960a905ab9a"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
