;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260707.1612"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "2044ffa4e4335582aae27dfbf763ff9f5ab73f7a"
  :revdesc "2044ffa4e433"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
