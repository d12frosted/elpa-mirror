(define-package "journalctl-mode" "20231110.911" "Sample major mode for  viewing output journalctl"
  '((emacs "27.1"))
  :commit "39054ba8424d5a4aa06a76810da8b3d7bb0a2461" :authors
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainers
  '(("Sebastian Meisel" . "sebastian.meisel@gmail.com"))
  :maintainer
  '("Sebastian Meisel" . "sebastian.meisel@gmail.com")
  :keywords
  '("unix")
  :url "https://github.com/SebastianMeisel/journalctl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
