;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260905.9"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e229500e6264dea6c57b1b1eb11b35e35f6bc68c"
  :revdesc "e229500e6264"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
