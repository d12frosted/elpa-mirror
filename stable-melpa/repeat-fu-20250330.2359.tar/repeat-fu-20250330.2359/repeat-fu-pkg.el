;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20250330.2359"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "fc0cb1cef65ed4e18640119672a4bf97ea80a39e"
  :revdesc "fc0cb1cef65e"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
