(define-package "modus-themes" "20220903.523" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "d0a62f6c9565c39a318c8c586f61066a85773e2f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
