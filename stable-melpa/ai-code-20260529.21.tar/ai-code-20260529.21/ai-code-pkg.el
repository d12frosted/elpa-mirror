;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260529.21"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "336b4c42537ceabdc4585fae0fd6091b1a054f6c"
  :revdesc "336b4c42537c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
