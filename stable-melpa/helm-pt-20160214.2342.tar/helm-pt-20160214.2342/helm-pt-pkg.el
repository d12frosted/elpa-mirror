(define-package "helm-pt" "20160214.2342" "Helm interface to the platinum searcher"
  '((helm "1.5.6"))
  :commit "8acc52911dad1ed0c3975f134a468762afe0b76b" :keywords
  ("helm" "platinum searcher"))
;; Local Variables:
;; no-byte-compile: t
;; End:
