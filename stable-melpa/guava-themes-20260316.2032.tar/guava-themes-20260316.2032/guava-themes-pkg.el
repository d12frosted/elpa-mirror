;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260316.2032"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "0e2763e4edd277a682e74f895e4368a6e37222e2"
  :revdesc "0e2763e4edd2"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
