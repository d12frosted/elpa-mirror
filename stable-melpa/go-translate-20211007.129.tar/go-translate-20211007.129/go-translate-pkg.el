(define-package "go-translate" "20211007.129" "Google Translate"
  '((emacs "26.1"))
  :commit "34ef5de1beeaecfd1d61210988ab5c43fc383129" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
