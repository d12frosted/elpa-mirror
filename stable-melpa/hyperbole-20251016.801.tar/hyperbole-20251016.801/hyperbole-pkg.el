;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251016.801"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "85fcec41239f0ba75aac10570e28a77505f9e60c"
  :revdesc "85fcec41239f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
