(define-package "stimmung-themes" "20220326.815" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "679ff1ca0e68c6076410d3ea2e2815e2a03f7554" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
