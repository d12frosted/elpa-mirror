(define-package "latex-table-wizard" "20221215.2210" "Magic editing of LaTeX tables"
  '((emacs "27.1")
    (auctex "12.1")
    (transient "0.3.7"))
  :commit "9d779a2d9b360e476c824bdbb8b8a4424be690f4" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :keywords
  '("convenience")
  :url "https://github.com/enricoflor/latex-table-wizard")
;; Local Variables:
;; no-byte-compile: t
;; End:
