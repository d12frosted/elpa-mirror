(define-package "citar" "20211121.2050" "Citation-related commands for org, latex, markdown"
  '((emacs "27.1")
    (s "1.12")
    (parsebib "3.0")
    (org "9.5"))
  :commit "35bd665ecbbb2e82e6d3fa31eae1cebb67d36bb2" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
