(define-package "pyinspect" "20211102.1107" "Python object inspector"
  '((emacs "27.1"))
  :commit "c5ddc1758ea518918763a31d7044ec05bd1ad659" :authors
  '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainer
  '("Maor Kadosh" . "git@avocadosh.xyz")
  :keywords
  '("tools")
  :url "https://github.com/it-is-wednesday/pyinspect.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
