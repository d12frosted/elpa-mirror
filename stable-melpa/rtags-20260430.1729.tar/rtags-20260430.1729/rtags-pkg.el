;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rtags" "20260430.1729"
  "A front-end for rtags."
  '((emacs "24.3"))
  :url "https://github.com/Andersbakken/rtags"
  :commit "41b1390ccc92e8a7fde923022f013dee7d1cca50"
  :revdesc "41b1390ccc92"
  :authors '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
             ("Anders Bakken" . "agbakken@gmail.com"))
  :maintainers '(("Jan Erik Hanssen" . "jhanssen@gmail.com")
                 ("Anders Bakken" . "agbakken@gmail.com")))
