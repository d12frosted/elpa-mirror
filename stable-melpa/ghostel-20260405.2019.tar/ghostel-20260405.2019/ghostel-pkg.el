;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260405.2019"
  "Terminal emulator powered by libghostty."
  '((emacs "27.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "416cf7aea4e4c69c0f0eb5b4b19ea693865691e9"
  :revdesc "416cf7aea4e4"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
