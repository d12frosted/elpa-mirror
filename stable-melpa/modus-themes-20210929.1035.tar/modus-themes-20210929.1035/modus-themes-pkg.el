(define-package "modus-themes" "20210929.1035" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "e2f02a54db96277cf7fc14f2a27301dd98fa4d9c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
