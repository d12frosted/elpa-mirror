;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260424.430"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "36049820ca987c79c87cc4d9f21d16ca23ff8ebb"
  :revdesc "36049820ca98"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
