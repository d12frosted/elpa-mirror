(define-package "use-package" "20220808.1925" "A configuration macro for simplifying your .emacs"
  '((emacs "24.3")
    (bind-key "2.4"))
  :commit "d2fb5eec06808156179832b0bc8412a6780cc131" :authors
  '(("John Wiegley" . "johnw@newartisans.com"))
  :maintainer
  '("John Wiegley" . "johnw@newartisans.com")
  :keywords
  '("dotemacs" "startup" "speed" "config" "package")
  :url "https://github.com/jwiegley/use-package")
;; Local Variables:
;; no-byte-compile: t
;; End:
