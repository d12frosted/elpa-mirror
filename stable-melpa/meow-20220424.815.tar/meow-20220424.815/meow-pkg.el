(define-package "meow" "20220424.815" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "1a9cd3c91b06ccfed2b8a81e197a49dffeb1e3f5" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
