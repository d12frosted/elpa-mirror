;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-backend" "20260901.844"
  "LaTeX-to-SVG rendering engine with caching."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/latex-to-svg-backend"
  :commit "62b5d0c6e2ea827e0808f215f0078773a5ae0dd6"
  :revdesc "62b5d0c6e2ea"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
