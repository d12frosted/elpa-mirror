;;; latex-to-svg-backend.el --- LaTeX-to-SVG rendering engine with caching -*- lexical-binding: t -*-

;; Copyright (C) 2026 Andrea Alberti

;; Author: Andrea Alberti <a.alberti82@gmail.com>
;; Maintainer: Andrea Alberti <a.alberti82@gmail.com>
;; Assisted-by: Claude:claude-opus-4-8
;; URL: https://github.com/alberti42/latex-to-svg-backend
;; Package-Version: 20260901.844
;; Package-Revision: 62b5d0c6e2ea
;; Package-Requires: ((emacs "29.1"))
;; Keywords: tex, math, images

;; This package is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.

;; This package is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:
;;
;; A small, buffer-agnostic engine that turns a LaTeX math string into an
;; SVG image suitable for overlaying in an Emacs buffer.  It is the
;; rendering engine behind `agent-shell-math-renderer' (math in agent-shell's
;; chat output) and the `latex-to-svg' preview stack (Org and Markdown).
;; A front-end finds the equations and places the images; the typesetting,
;; caching and sizing happen here.
;;
;; Design (why it is cheap to recolor and rescale):
;;
;;   * Equations are compiled with `latex' + `dvisvgm' to a standalone SVG,
;;     named on disk after its own content (SHA-1 of LaTeX + preamble +
;;     style).  Each unique equation therefore compiles at most once, and
;;     the cache is shared across every front-end.
;;
;;   * The on-disk SVG is COLOR-INDEPENDENT: dvisvgm `--currentcolor' emits
;;     the default ink as the literal token `currentColor', which is
;;     substituted with the buffer foreground at display time.  A theme
;;     switch therefore re-tints from cache with no recompile.  The image
;;     background is transparent, so it always matches the buffer.
;;
;;   * The on-disk SVG is SIZE-INDEPENDENT: it is compiled at dvisvgm
;;     `--scale=1' (natural point dimensions, glyphs as outline paths) and
;;     scaled at display time via `create-image' :scale, computed from the
;;     buffer font height so equations track the font — again no recompile.
;;
;;   * The preamble is PRECOMPILED once to a LaTeX format file (`.fmt') via
;;     the `mylatexformat' package, then loaded by every equation compile
;;     with a `%&' first line (see `latex-to-svg-backend-precompile').  This skips
;;     re-parsing the class and packages (amsmath, ...) on each equation, so
;;     compiles are markedly faster.  It falls back to a full compile when
;;     `mylatexformat' is unavailable or the dump fails.
;;
;;   * The cache is SHARDED into 256 subdirectories (by the first two hex
;;     characters of the content key) so no single directory accumulates
;;     every equation, and is bounded by an age-limited garbage collector
;;     (`latex-to-svg-backend-gc') that deletes equations untouched for a
;;     while and runs automatically about once a day (see
;;     `latex-to-svg-backend-gc-interval').
;;
;; Public entry point:
;;
;;   (latex-to-svg-backend LATEX &key callback color background padding font-height)
;;
;; LATEX is placed *verbatim* in the document body, so the caller passes
;; valid body LaTeX and decides inline vs display by the delimiters it uses
;; (`$x$', `\(x\)', `\[x\]', `\begin{equation}...\end{equation}', ...).
;; The engine is deliberately unaware of that distinction.
;;
;; Returns an image now when one can be produced synchronously (cache /
;; on-disk SVG / placeholder), else nil after scheduling an asynchronous
;; compile; CALLBACK (a zero-argument function) is invoked once the SVG is
;; ready, so the caller can re-query and place the image.  Concurrent
;; requests for the same equation are coalesced onto a single compile.
;;
;; The optional `:color'/`:background'/`:padding' keys override the
;; display-time tint, an optional box color behind the equation, and padding
;; that grows that box beyond the ink (all apply post-compile, no recompile);
;; a front-end owns the user-facing preference and passes it through.
;;
;; Helpers a front-end typically needs for its refresh policy:
;; `latex-to-svg-backend-available-p', `latex-to-svg-backend-appearance',
;; `latex-to-svg-backend-display-scale', and `latex-to-svg-backend-foreground-color'.

;;; Code:

(eval-when-compile
  (require 'cl-lib))
(require 'color)
(require 'seq)
(require 'svg)

(defgroup latex-to-svg-backend nil
  "Render LaTeX math to SVG images with `latex' + `dvisvgm'.
Equations are compiled to a color- and size-independent SVG, cached
on disk by content, then tinted to the buffer foreground and scaled
to the buffer font at display time."
  :group 'tex
  :prefix "latex-to-svg-backend-")

;;;; Customization

(defcustom latex-to-svg-backend-latex-program "latex"
  "Program that compiles a LaTeX document to DVI."
  :type 'string
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-dvisvgm-program "dvisvgm"
  "Program that converts DVI to SVG."
  :type 'string
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-preamble
  "\\documentclass[varwidth,border=2pt]{standalone}
\\usepackage{amsmath}
\\usepackage{amssymb}
\\usepackage{xcolor}"
  "LaTeX preamble (everything before `\\begin{document}') for equations.
The `standalone' class crops the page tightly to the equation, so
no `preview' package is required.  The `varwidth' option is what lets
the verbatim body use *display* math — `\\[...\\]' and display
environments like `equation'/`align' — not just inline `$...$'
\(plain `standalone' typesets its body as a single horizontal box and
errors with \"Missing $ inserted\" on display math).  dvisvgm's
`--exact-bbox' then crops to the actual ink.

See also `latex-to-svg-backend-appended-preamble' for adding extra packages
without replacing this base."
  :type 'string
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-appended-preamble ""
  "Extra LaTeX code appended after `latex-to-svg-backend-preamble'.
Use this to load additional packages (e.g. `\\usepackage{braket}',
`\\usepackage{physics}') without replacing the base preamble.  The
value is folded into the cache key, so changing it automatically
invalidates cached SVGs."
  :type 'string
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-line-width nil
  "Maximum typeset width of an equation, as a LaTeX dimension string.
This caps the width of the `varwidth' box the body is set in (the
`standalone' class's `\\sa@width').  When nil (the default) the class's
default is used (`\\linewidth', ~345pt).

A *numbered* display sets its number flush right at this width, and TeX
drops it onto a second line when the equation is wider, so the number
stays on the line only while the equation fits within it.  Raise it,
say to \"20cm\", when wide numbered equations wrap their number; lower
it, say to \"6cm\", to tuck the number closer to the equation when every
equation is short.  Either way this just moves the right margin; the
one rule is not to set it below your widest numbered equation (which
would wrap).  Unnumbered content is unaffected (cropped to its ink).

The value is folded into the cache key, so changing it re-renders."
  :type '(choice (const :tag "Class default (~345pt)" nil)
                 (string :tag "LaTeX dimension"))
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-precompile t
  "When non-nil, precompile the preamble to a LaTeX format (`.fmt') file.

The class and packages in `latex-to-svg-backend-preamble' /
`latex-to-svg-backend-appended-preamble' are dumped once, with the
`mylatexformat' package, to a format file keyed by the preamble text;
every equation compile then loads it with a `%&' first line instead of
re-reading the preamble, which speeds each compile up noticeably.

Requires `mylatexformat.ltx' on the TeX search path (part of most TeX
distributions).  When it is missing, or the dump fails, or a compile
using the format later fails, the engine transparently falls back to
embedding the full preamble in each equation — correctness never depends
on this option.  A stale format after a TeX toolchain upgrade is detected
and rebuilt automatically (the binary is newer than the `.fmt');
`latex-to-svg-backend-flush-format' is the manual escape hatch."
  :type 'boolean
  :safe #'booleanp
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-cache-directory nil
  "Directory for cached equation SVGs and scratch compiles.
When nil, `$XDG_CACHE_HOME/emacs/latex-to-svg/' (or
`~/.cache/emacs/latex-to-svg/') is used, so equation SVGs persist across
sessions and each unique equation compiles at most once.  Because the
cache is keyed by content and is color/size-independent, it is safe to share
across every front-end and buffer."
  :type '(choice (const :tag "Default XDG cache" nil) directory)
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-cache-max-age 90
  "Delete cached equation SVGs untouched for this many days, or nil for no cap.
The garbage collector (`latex-to-svg-backend-gc') treats each SVG's
modification time as its last-use time (bumped on every load), so this
expires equations that have not been viewed within the given window.
Because the cache is keyed by content and is color/size-independent, an
expired equation simply recompiles the next time it is needed."
  :type '(choice (const :tag "No age limit" nil) (integer :tag "Days"))
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-gc-interval 1
  "Minimum days between automatic cache collections, or nil to disable them.
An idle timer checks this cadence against an on-disk timestamp, so
`latex-to-svg-backend-gc' runs at most once per interval no matter how many
sessions share the cache (and still collects a long-lived daemon daily).
Set to nil to turn off automatic GC entirely; `latex-to-svg-backend-gc'
can always be invoked by hand."
  :type '(choice (const :tag "Disabled" nil) (number :tag "Days"))
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-metadata-prefix nil
  "Line prefix marking compile metadata to capture, or nil to disable.
When a string, after each successful compile the first integer on a LaTeX
log line beginning with it (the FINAL value) is paired with the caller's
`:metadata' value (the INITIAL value) and stored as the plist
`(:nums (INITIAL . FINAL))' in the equation's `.eld' sidecar next to
its SVG, exposed by `latex-to-svg-backend-metadata' (on cache hit or miss).

So the caller supplies INITIAL directly (a value it already knows, in
Elisp), and only FINAL — the thing the compile computes — travels through
LaTeX, emitted with `\\typeout{PREFIX \\arabic{COUNTER}}'.  Keep that line
short: TeX wraps log lines near column 80."
  :type '(choice (const :tag "Disabled" nil) string)
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-font-scale 1.0
  "Size of rendered equations relative to the buffer font.

Equation images are scaled so LaTeX's 10pt body font maps onto the
buffer's font height; this multiplier rides on top of that match.
1.0 makes equation text the same size as the surrounding text;
greater than 1 enlarges, less than 1 shrinks.  Because the match is
recomputed from the current font on each render, equations track the
buffer font across themes, faces, and text scale."
  :type 'number
  :safe #'numberp
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-use-placeholder nil
  "When non-nil, draw the placeholder panel instead of typesetting LaTeX.
Also used as the automatic fallback when the toolchain
\(`latex-to-svg-backend-latex-program' /
`latex-to-svg-backend-dvisvgm-program') is unavailable."
  :type 'boolean
  :safe #'booleanp
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-render-on-non-graphic nil
  "When non-nil, render equation images even on a non-graphical frame.

By default equations are only compiled when the selected frame is
graphical (`display-graphic-p').  In an Emacs daemon a buffer may
be rendered while a TTY frame is selected, yet later viewed in a
graphical frame; without this the equation would never have been
produced and stays raw text in the GUI too.

Set non-nil (typically in a daemon setup) to always compile the
SVG when the build supports it: it is ignored on a TTY frame (the
raw LaTeX shows) but appears as soon as a graphical frame views
the buffer.  The trade-off is that a purely terminal session then
spawns LaTeX compiles whose images it never displays."
  :type 'boolean
  :safe #'booleanp
  :group 'latex-to-svg-backend)

(defcustom latex-to-svg-backend-svg-dpi 96.0
  "Dots-per-inch Emacs's SVG renderer uses to convert points to pixels.

Used to size equation previews to the buffer font: an SVG `pt' is
rendered as `latex-to-svg-backend-svg-dpi' / 72 pixels.  librsvg (Emacs's SVG
backend) converts SVG length units at 96 DPI, so the default suits
almost all systems; override only if previews come out uniformly too
big or too small.  HiDPI is handled separately by `image-scaling-factor'
\(it scales the reference and the equation alike, so it cancels) and
does not belong here.

This replaced a per-frame `image-size' measurement that proved
unreliable on some ports (returning wildly different pixel sizes for
the same undisplayed SVG), which made preview sizing non-deterministic."
  :type 'number
  :safe #'numberp
  :group 'latex-to-svg-backend)

;;;; State

;; image-cache key = content key (sha1 of latex + preamble + style) plus the
;; display scale and tint color, via `latex-to-svg-backend--image-cache-key'.  Folding
;; scale and color in lets images at different font sizes / themes coexist, so
;; a font or theme change just adds an entry (no cache clear) and sibling
;; buffers' warm images survive.  The underlying SVG is still compiled at most
;; once per content key (the disk cache is font- AND color-independent); only
;; the cheap `create-image' is per scale/color.
(defvar latex-to-svg-backend--image-cache (make-hash-table :test 'equal)
  "In-memory map of image-cache key to rendered equation image.")

;; key -> list of zero-argument callbacks awaiting one in-flight compile.
;; Dedupes concurrent compiles of the same equation and records every
;; consumer to notify once the SVG is ready.
(defvar latex-to-svg-backend--pending (make-hash-table :test 'equal)
  "In-memory map of cache key to callbacks awaiting an in-flight compile.")

;; Precompiled-preamble (.fmt) bookkeeping, keyed by format key (a hash of
;; the preamble text + LaTeX program, see `latex-to-svg-backend--format-key').
;; `--format-checked' records keys whose `.fmt' was verified fresh this
;; session, so the freshness (mtime) check runs at most once per key;
;; `--format-blocklist' records keys whose format produced a compile
;; failure, so precompilation is abandoned for them for the rest of the
;; session and the engine falls back to full compiles.
(defvar latex-to-svg-backend--format-checked (make-hash-table :test 'equal)
  "Format keys whose `.fmt' has been verified fresh this session.")

(defvar latex-to-svg-backend--format-blocklist (make-hash-table :test 'equal)
  "Format keys whose `.fmt' failed a compile; precompilation skipped for them.")

;; Content keys whose unreadable `.eld' sidecar has been discarded this
;; session, so the repair is attempted at most once per equation: a sidecar
;; that comes back unreadable after a fresh compile would otherwise recompile
;; on every query.
(defvar latex-to-svg-backend--metadata-repaired (make-hash-table :test 'equal)
  "Content keys whose unreadable metadata sidecar was discarded this session.")

;;;; Error reporting

;; Conditions already reported by `latex-to-svg-backend--warn-once', keyed
;; "CONTEXT/ERROR-SYMBOL" and valued with the time they were reported.  An
;; error the engine recovers from is never silent: the first of each kind
;; warns, so a misconfiguration is diagnosable, while a recurring one does not
;; warn once per equation.
(defvar latex-to-svg-backend--warned (make-hash-table :test 'equal)
  "Context/condition pairs already reported this session, and when.")

;; Buffer-scoped marks live with the buffer, so they are discarded when it is
;; killed and never accumulate for a long-lived process, a rename cannot re-arm
;; them, and a reopened document is genuinely a new one.
(defvar-local latex-to-svg-backend--warned-in-buffer nil
  "Alist of context/condition pairs already reported in this buffer, and when.")

(defconst latex-to-svg-backend--warn-interval 86400
  "Seconds before the same condition is reported again at the same site.
A warning from three weeks ago says nothing about whether the problem is
still there, so a mark goes stale instead of lasting for the life of the
buffer or the process.  A day is long enough that a persistent failure
costs one line in `*Warnings*' per day, and lines up with the default
`latex-to-svg-backend-gc-interval', so a cache directory the collector
cannot write reports once per collection attempt.")

(defun latex-to-svg-backend--warn-once (context err &optional scope)
  "Report ERR under CONTEXT once, and return nil.
For an error the engine recovers from: the recovery is reported rather than
silenced, but a recurring one does not warn per equation.  CONTEXT is a
short phrase naming what failed, e.g. \"recording cache use\".

SCOPE says how often \"once\" is.  Nil means once per session, recorded in
`latex-to-svg-backend--warned'.  `buffer' means once per buffer, marked
buffer-locally in `latex-to-svg-backend--warned-in-buffer': the display
path is entered from the buffer being rendered, so a problem that persists
is re-reported for each document opened, rather than once for the life of a
process -- an Emacs server runs for weeks, and a single warning there is
easily missed or long stale.  Equations within one buffer still share one
warning.

Callers reached from a process sentinel or an idle timer must leave SCOPE
nil: the buffer current there is unrelated to the equation (our own process
output buffer, or whatever the timer interrupted), so marking it would both
misattribute the diagnosis and warn far too often.

Either way a mark goes stale after `latex-to-svg-backend--warn-interval',
so a condition that is still occurring is reported again rather than
resting on a warning from weeks ago."
  (let* ((seen (format "%s/%s" context (car err)))
         (now (float-time))
         (last (if (eq scope 'buffer)
                   (cdr (assoc seen latex-to-svg-backend--warned-in-buffer))
                 (gethash seen latex-to-svg-backend--warned)))
         (fresh (or (null last)
                    (> (- now last) latex-to-svg-backend--warn-interval))))
    (when fresh
      (if (eq scope 'buffer)
          (setf (alist-get seen latex-to-svg-backend--warned-in-buffer
                           nil nil #'equal)
                now)
        (puthash seen now latex-to-svg-backend--warned))
      (display-warning 'latex-to-svg-backend
                       (format "%s: %s" context (error-message-string err))
                       :warning)))
  nil)

;;;; Colors and appearance

(defun latex-to-svg-backend--color-to-hex (color fallback)
  "Return COLOR (a name or `#rrggbb') as a `#rrggbb' string, or FALLBACK.
FALLBACK is returned when COLOR is not a string or can't be resolved
to RGB (e.g. an `unspecified-*' sentinel, or off a window system)."
  ;; `color-name-to-rgb' returns nil for an unknown name or an
  ;; `unspecified-*' sentinel -- no error, just no color.  It signals only
  ;; when the display cannot resolve even white: it normalizes against
  ;; `(float (car (color-values "#ffffffffffff")))', so a colorless display
  ;; gives `wrong-type-argument'.  Report that once; either way, fall back.
  (if-let* (((stringp color))
            (rgb (condition-case err
                     (color-name-to-rgb color)
                   (wrong-type-argument
                    (latex-to-svg-backend--warn-once "resolving a color" err 'buffer)))))
      (apply #'color-rgb-to-hex (append rgb '(2)))
    fallback))

(defun latex-to-svg-backend--svg-color (face attribute fallback)
  "Return FACE's ATTRIBUTE color as a `#rrggbb' string, or FALLBACK.

ATTRIBUTE is `:foreground' or `:background'.  FALLBACK is returned
when the attribute is unspecified or can't be resolved to RGB
\(e.g. on a terminal that reports symbolic colors)."
  (latex-to-svg-backend--color-to-hex
   (face-attribute face attribute nil 'default) fallback))

(defun latex-to-svg-backend-foreground-color ()
  "Return the `#rrggbb' foreground equations should be tinted with now.
Resolved from the `default' face of the selected frame."
  (latex-to-svg-backend--svg-color 'default :foreground "#000000"))

(defun latex-to-svg-backend--current-colors ()
  "Return the (FOREGROUND . BACKGROUND) equations should render for now.
Both are `#rrggbb' strings resolved from the `default' face."
  (cons (latex-to-svg-backend-foreground-color)
        (latex-to-svg-backend--svg-color 'default :background "#ffffff")))

(defun latex-to-svg-backend--font-height ()
  "Return the selected frame's default font pixel height, or nil.
Nil off a graphical frame: there is nothing to measure there, and the
engine deliberately does not search for another frame (a graphical frame
in `frame-list' may be an invisible child frame).  Callers that know the
buffer's real display frame measure it there and pass `:font-height'
instead.

Also nil when the font cannot be measured: on a graphical frame
`default-font-height' reads `font-info', which reports nil for a font it
cannot open, and then signals `wrong-type-argument'.  That is reported once
\(`latex-to-svg-backend--warn-once') and treated as an unknown height, so
sizing is deferred rather than guessed."
  (and (display-graphic-p)
       (condition-case err
           (default-font-height)
         (wrong-type-argument
          (latex-to-svg-backend--warn-once "measuring the buffer font" err 'buffer)))))

(defun latex-to-svg-backend-appearance (&optional font-height)
  "Return the appearance signature equations should render for now.
A list (FOREGROUND BACKGROUND FONT-HEIGHT): the colors equations
are tinted with (see `latex-to-svg-backend--current-colors') and the buffer
font pixel height they are sized to.  FONT-HEIGHT, when non-nil, is
that height (a front-end that knows the buffer's actual display frame
measures it there and passes it, so the signature matches the render);
nil falls back to the selected frame's `default-font-height', or nil
off a graphical frame.  Front-ends compare this against the value
stored at their last render to detect a color *or* font-size change
and refresh."
  (let ((colors (latex-to-svg-backend--current-colors)))
    (list (car colors) (cdr colors)
          (or font-height (latex-to-svg-backend--font-height)))))

;;;; Capability

(defun latex-to-svg-backend-available-p ()
  "Return non-nil when equation images should be produced.

Requires SVG image support in this Emacs build, plus either a
graphical selected frame or `latex-to-svg-backend-render-on-non-graphic'
\(the daemon / mixed TTY+GUI case — the image is ignored on a TTY
frame but shows once a graphical frame views the buffer)."
  (and (image-type-available-p 'svg)
       (or (display-graphic-p)
           latex-to-svg-backend-render-on-non-graphic)))

(defun latex-to-svg-backend-tools-available-p ()
  "Return non-nil when the LaTeX-to-SVG toolchain is on the variable `exec-path'."
  (and (executable-find latex-to-svg-backend-latex-program)
       (executable-find latex-to-svg-backend-dvisvgm-program)))

;;;; Cache addressing

(defun latex-to-svg-backend--cache-dir ()
  "Return the root cache directory, creating it if needed.
Honours `latex-to-svg-backend-cache-directory', else `$XDG_CACHE_HOME'
\(or `~/.cache') under `emacs/latex-to-svg/'.  Files are organised into
`svg/' (sharded equation SVGs + sidecars) and `fmt/' (precompiled
preambles) subdirectories, plus the `gc-timestamp' housekeeping file."
  (let ((dir (or latex-to-svg-backend-cache-directory
                 (expand-file-name
                  "emacs/latex-to-svg/"
                  (or (getenv "XDG_CACHE_HOME")
                      (expand-file-name "~/.cache"))))))
    (unless (file-directory-p dir)
      (make-directory dir t))
    dir))

(defun latex-to-svg-backend--subdir (name)
  "Return subdirectory NAME under the cache directory, creating it."
  (let ((dir (expand-file-name name (latex-to-svg-backend--cache-dir))))
    (unless (file-directory-p dir)
      (make-directory dir t))
    dir))

(defun latex-to-svg-backend--preamble ()
  "Return the full LaTeX preamble: the base plus any appended packages.
This is the exact text embedded before `\\begin{document}' in a full
compile, and the text dumped into the precompiled format file.  When
`latex-to-svg-backend-line-width' is set, a `\\sa@width' override is
appended so the `varwidth' box uses that width (see that variable)."
  (concat
   latex-to-svg-backend-preamble
   (unless (string-empty-p latex-to-svg-backend-appended-preamble)
     (concat "\n" latex-to-svg-backend-appended-preamble))
   ;; Override `standalone's varwidth width (`\sa@width', default
   ;; `\linewidth').  Placed last so it wins over the class default.
   (when latex-to-svg-backend-line-width
     (format "\n\\makeatletter\\def\\sa@width{%s}\\makeatother"
             latex-to-svg-backend-line-width))))

(defconst latex-to-svg-backend--cache-version 1
  "Version number mixed into every cache file name.
See `latex-to-svg-backend--cache-key'.
Raise it by one when a code change makes the *old cached SVGs wrong* even
though the LaTeX and preamble are unchanged — for example if we change a
`dvisvgm' flag, the compile command, or the shape of the SVG we produce.
Because the number is part of the file name, raising it gives every file
a new name, so the stale ones are simply never found again (they get
cleaned up later by the normal cache GC) and everything is recompiled
fresh.

Do NOT tie this to the TeX/dvisvgm version — upgrading TeX Live should
not wipe the cache.  Change it by hand, only for a real incompatibility.")

(defun latex-to-svg-backend--cache-key (latex)
  "Return a stable content cache key for LATEX.
The preamble is folded in so changing it invalidates the cache, as is
`latex-to-svg-backend--cache-version' so a pipeline change re-keys warm
caches.  LATEX is the verbatim document body, so any change to it —
including inline vs display delimiters or an injected `\setcounter' for
equation numbering — changes the key on its own.  The key names the
on-disk SVG, which is both font- AND color-independent (equations
are compiled with dvisvgm `--currentcolor', then sized and tinted at
display time), so neither size nor color is part of this key."
  (secure-hash 'sha1 (format "%d\0%s\0%s"
                             latex-to-svg-backend--cache-version
                             latex
                             (latex-to-svg-backend--preamble))))

(defun latex-to-svg-backend--shard-dir (key)
  "Return the shard subdirectory holding KEY's cache files, creating it.
SVGs live under the `svg/' subdirectory, sharded into 256 buckets by the
first two characters of the (hex) content KEY, so no single directory
accumulates every equation (cf. Git's object store or org-persist's
cache).  All of KEY's files — `.svg', `.eld', `.log' — live together in
`svg/<XX>/'."
  (latex-to-svg-backend--subdir (concat "svg/" (substring key 0 2))))

(defun latex-to-svg-backend--svg-file (key)
  "Return the cache SVG path for KEY (inside its shard subdirectory)."
  (expand-file-name (concat key ".svg")
                    (latex-to-svg-backend--shard-dir key)))

(defun latex-to-svg-backend--meta-file (key)
  "Return the compile-metadata sidecar path for KEY (a `.eld' next to the SVG)."
  (expand-file-name (concat key ".eld")
                    (latex-to-svg-backend--shard-dir key)))

(defun latex-to-svg-backend--touch (file)
  "Bump FILE's modification time to now (a last-use hint for GC).
`latex-to-svg-backend-gc' treats the SVG mtime as the equation's last-use
time, so this is called whenever a cached SVG is (re)loaded.

Signals `file-missing' when FILE is gone -- the caller treats that as a
cache miss (see `latex-to-svg-backend--cached-image').  Any other refusal
by the filesystem is reported once (`latex-to-svg-backend--warn-once') and
then tolerated: the mtime only orders GC, so an entry owned by another
user (a cache populated once under sudo) or on a read-only mount is left
untouched, ages out, and recompiles."
  (condition-case err
      (set-file-times file)
    ;; A collected entry belongs to the caller, which turns it into a miss.
    (file-missing (signal (car err) (cdr err)))
    (file-error
     (latex-to-svg-backend--warn-once "recording cache use" err 'buffer))))

;;;; Scale

(defun latex-to-svg-backend--svg-px-per-pt ()
  "Return how many pixels Emacs renders one SVG point as.
A constant derived from `latex-to-svg-backend-svg-dpi' (SVG `pt' = dpi/72 px).
Not measured — see `latex-to-svg-backend-svg-dpi' for why."
  (/ latex-to-svg-backend-svg-dpi 72.0))

(defun latex-to-svg-backend-display-scale (&optional rescale-by font-height)
  "Return the `create-image' :scale that sizes equations to the buffer font.

Maps the LaTeX document's 10pt body font (the `standalone' default,
compiled at dvisvgm scale 1, so 10pt of LaTeX = 10 SVG points) onto
the buffer's font pixel height, times `latex-to-svg-backend-font-scale'.  An
equation's displayed font height is (10 * px-per-pt * scale) px, so
scale = target * font-scale / (10 * px-per-pt), where px-per-pt is the
deterministic `latex-to-svg-backend-svg-dpi' / 72.

RESCALE-BY (default 1.0) is a per-call multiplier on top of the global
`latex-to-svg-backend-font-scale'; a front-end uses it to size, say, display
equations slightly larger than inline ones, without touching the
global base.

The target font height comes from FONT-HEIGHT when given -- a front-end
that knows the buffer's actual display frame measures `default-font-height'
there and passes it, so sizing never depends on which frame happens to be
selected.  Otherwise the selected frame is measured, but only when it is
graphical (so a buffer-local text scale is honoured).  Returns nil when
no height is known (no FONT-HEIGHT and a non-graphical selected frame,
e.g. an async/daemon render of a buffer shown nowhere): the engine has
nothing trustworthy to size against, so the caller should defer building
the display image until the buffer is shown -- the on-disk SVG is size-
independent, so it can be compiled now and sized later with no recompile."
  (when-let* ((target (or font-height (latex-to-svg-backend--font-height))))
    (/ (* target latex-to-svg-backend-font-scale (or rescale-by 1.0))
       (* 10.0 (latex-to-svg-backend--svg-px-per-pt)))))

;;;; Image build

(defun latex-to-svg-backend--pad-svg (data pad background)
  "Expand DATA's SVG viewport by PAD on all sides; fill BACKGROUND behind.
PAD is a number in the SVG's own units (pt, at dvisvgm `--scale=1'),
so it scales with the equation when the image is displayed.  The root
`<svg>' `width'/`height'/`viewBox' are grown by 2*PAD and, when
BACKGROUND (a color string) is non-nil, a filled `<rect>' covering the
padded viewport is inserted behind the content so the box color extends
PAD beyond the ink.  Returns DATA unchanged if the root tag can't be
parsed (defensive: never break rendering over a padding request)."
  (if-let* (((> pad 0))
            ((string-match "<svg\\b[^>]*>" data))
            (beg (match-beginning 0))
            (end (match-end 0))
            (tag (match-string 0 data))
            ((string-match "\\bwidth='\\([0-9.eE+-]+\\)pt'" tag))
            (w (string-to-number (match-string 1 tag)))
            ((string-match "\\bheight='\\([0-9.eE+-]+\\)pt'" tag))
            (h (string-to-number (match-string 1 tag)))
            ((string-match
              (concat "\\bviewBox='\\([0-9.eE+-]+\\) \\([0-9.eE+-]+\\) "
                      "\\([0-9.eE+-]+\\) \\([0-9.eE+-]+\\)'")
              tag))
            (vx (string-to-number (match-string 1 tag)))
            (vy (string-to-number (match-string 2 tag)))
            (vw (string-to-number (match-string 3 tag)))
            (vh (string-to-number (match-string 4 tag))))
      (let* ((nx (- vx pad)) (ny (- vy pad))
             (nw (+ vw (* 2 pad))) (nh (+ vh (* 2 pad)))
             (new-tag tag)
             (rect (if background
                       (format "<rect x='%s' y='%s' width='%s' height='%s' fill='%s'/>"
                               nx ny nw nh background)
                     "")))
        (setq new-tag (replace-regexp-in-string
                       "\\bwidth='[0-9.eE+-]+pt'"
                       (format "width='%spt'" (+ w (* 2 pad))) new-tag nil t)
              new-tag (replace-regexp-in-string
                       "\\bheight='[0-9.eE+-]+pt'"
                       (format "height='%spt'" (+ h (* 2 pad))) new-tag nil t)
              new-tag (replace-regexp-in-string
                       "\\bviewBox='[^']*'"
                       (format "viewBox='%s %s %s %s'" nx ny nw nh) new-tag nil t))
        (concat (substring data 0 beg) new-tag rect (substring data end)))
    data))

(defun latex-to-svg-backend--load-svg-image (file &optional scale color background padding)
  "Return an SVG image from FILE, tinted COLOR and sized to the buffer font.
The on-disk SVG emits its default ink as the literal token
`currentColor' (dvisvgm `--currentcolor'); when COLOR (a `#rrggbb'
string) is given it is substituted in, so the equation matches the
buffer foreground without recompiling.  Scaled by SCALE (default
`latex-to-svg-backend-display-scale') so the body font matches the
surrounding text, and centred vertically for inline display.

The SVG is transparent; BACKGROUND, when non-nil (a color string),
is painted behind it without recompiling.  Nil (the default) keeps
the equation transparent so it blends into the buffer.  PADDING, a
number of pt > 0, grows the SVG viewport on all sides (via
`latex-to-svg-backend--pad-svg'), so the BACKGROUND box extends PADDING
beyond the ink; it scales with the equation.  With PADDING the box is
baked into the SVG (a `<rect>'); without it BACKGROUND is applied as
`create-image' `:background'."
  (let ((data (with-temp-buffer
                (insert-file-contents file)
                (buffer-string)))
        (pad (and padding (> padding 0) padding)))
    (when color
      (setq data (replace-regexp-in-string "currentColor" color data t t)))
    (when pad
      (setq data (latex-to-svg-backend--pad-svg data pad background)))
    (apply #'create-image data 'svg t
           :scale (or scale 1.0)
           :ascent 'center
           ;; With padding the box is a baked-in <rect>; otherwise let
           ;; `create-image' composite the background behind the SVG.
           (and background (not pad) (list :background background)))))

(defun latex-to-svg-backend--image-cache-key (key scale color &optional background padding)
  "Return the image-cache key for KEY at SCALE, COLOR, BACKGROUND, PADDING.
KEY names the font- and color-independent on-disk SVG; the cached
image object bakes in a display `:scale', a tint COLOR, an optional
BACKGROUND box, and its PADDING, so the in-memory key adds all four.
Images at different font sizes, tints, box colors, or paddings coexist,
so any such change just creates a new entry — no cache clearing, and a
sibling buffer's warm images survive."
  (format "%s@%s@%s@%s@%s" key scale color background padding))

(defun latex-to-svg-backend--cached-image (key &optional rescale-by color background padding font-height)
  "Return the rendered image for content KEY at the current font and color.
Checks the in-memory cache (keyed by KEY, the display scale, the tint
color, the box background, and PADDING via
`latex-to-svg-backend--image-cache-key', so each variant has its own image),
else loads KEY's on-disk SVG and caches a freshly scaled, tinted image.
RESCALE-BY (default 1.0) multiplies the display scale (see
`latex-to-svg-backend-display-scale') and, via the scale, feeds the cache key,
so different per-call sizes of the same equation coexist.  FONT-HEIGHT is
passed through to `latex-to-svg-backend-display-scale' (the buffer font pixel
height measured by the caller); COLOR (a color string) overrides the
tint, nil follows the buffer foreground
\(`latex-to-svg-backend-foreground-color').  BACKGROUND (a color string) paints
a box behind the equation; nil (the default) keeps it transparent.
PADDING (pt) grows the BACKGROUND box beyond the ink.  All apply at
display time only — same on-disk SVG, no recompile — and fold into the
cache key so variants coexist.  Returns nil when the SVG isn't on disk
yet (its compile hasn't finished) OR when no font height is known (see
`latex-to-svg-backend-display-scale'): with no trustworthy size the caller
should defer to display time rather than size against a guess."
  (when-let* ((scale (latex-to-svg-backend-display-scale rescale-by font-height)))
    (let* ((color (latex-to-svg-backend--color-to-hex
                   (or color (latex-to-svg-backend-foreground-color)) "#000000"))
           ;; Resolve BACKGROUND to `#rrggbb' too: with padding it is baked
           ;; into the SVG as a `<rect fill=...>', where an Emacs/X11 name
           ;; (e.g. "gray97") is not valid; fall back to the original string
           ;; if unresolvable (a valid CSS name / hex passes through).
           (background (and background
                            (latex-to-svg-backend--color-to-hex background background)))
           (image-key (latex-to-svg-backend--image-cache-key
                       key scale color background padding)))
      (or (gethash image-key latex-to-svg-backend--image-cache)
          (let ((file (latex-to-svg-backend--svg-file key)))
            (when (file-exists-p file)
              ;; The cache is shared across sessions, so another session's GC
              ;; can collect the entry between the check above and the read
              ;; below.  That is a miss -- the caller recompiles -- not an
              ;; error to raise from the display path.
              (condition-case err
                  (progn
                    ;; Record the access for the LRU garbage collector.
                    (latex-to-svg-backend--touch file)
                    (puthash image-key
                             (latex-to-svg-backend--load-svg-image
                              file scale color background padding)
                             latex-to-svg-backend--image-cache))
                (file-missing
                 (latex-to-svg-backend--warn-once
                  "cache entry collected while rendering" err 'buffer)))))))))

;;;; Placeholder

(defun latex-to-svg-backend--placeholder (latex)
  "Return a placeholder SVG image boxing the raw LATEX, or nil.

This does NOT typeset LATEX — it draws the source inside a bordered
panel.  Used when `latex-to-svg-backend-use-placeholder' is set or the
toolchain is unavailable, so math still has a visible (if un-typeset)
rendering.  Returns nil when equations aren't renderable (see
`latex-to-svg-backend-available-p'), so callers fall back to the raw text.

LATEX is the equation source with the surrounding delimiters
already stripped, e.g. \"E=mc^2\"."
  (when (latex-to-svg-backend-available-p)
    (let* ((lines (split-string latex "\n"))
           ;; `frame-char-width' / `-height' give per-char pixel
           ;; dimensions on a graphical frame and stay robust off it
           ;; (unlike `default-font-width', which calls `font-info' and
           ;; errors with no live font).  Good enough for placeholder
           ;; sizing; real typesetting will set its own dimensions.
           (char-w (frame-char-width))
           (char-h (frame-char-height))
           (pad char-h)
           (badge-h char-h)
           (text-w (* char-w (apply #'max 1 (mapcar #'length lines))))
           (width (+ text-w (* 2 pad)))
           (height (+ badge-h (* char-h (length lines)) (* 2 pad)))
           (fg (latex-to-svg-backend--svg-color 'default :foreground "#000000"))
           (border (latex-to-svg-backend--svg-color 'shadow :foreground "#888888"))
           (panel (latex-to-svg-backend--svg-color 'default :background "#f4f4f4"))
           (svg (svg-create width height)))
      (svg-rectangle svg 0 0 width height
                     :rx (/ char-h 2)
                     :fill panel
                     :stroke border
                     :stroke-width 1)
      (svg-text svg "tex"
                :x pad
                :y (* badge-h 0.85)
                :font-size (* badge-h 0.7)
                :font-style "italic"
                :fill border)
      (seq-do-indexed
       (lambda (line i)
         (svg-text svg (if (string-empty-p line) " " line)
                   :x pad
                   :y (+ badge-h pad (* char-h (1+ i)) (- (/ char-h 4)))
                   :font-family "monospace"
                   :font-size char-h
                   :fill fg))
       lines)
      (svg-image svg :scale 1.0 :ascent 'center))))

;;;; Preamble precompilation (.fmt)

;; Speedup: dump the preamble (class + packages) to a LaTeX format file once,
;; then load it from every equation compile with a `%&' first line instead of
;; re-reading and re-loading amsmath/xcolor/... each time.  Uses the
;; `mylatexformat' package.  Entirely optional: on any hiccup the engine
;; falls back to embedding the full preamble in each equation, so a `.fmt' is
;; a pure performance optimization, never a correctness dependency.

(defun latex-to-svg-backend--latex-binary ()
  "Return the path to the LaTeX executable, or nil.
Honours an absolute `latex-to-svg-backend-latex-program', else resolves the
command name on variable `exec-path'.  Used for the format freshness check."
  (let ((prog (car (split-string latex-to-svg-backend-latex-program))))
    (if (file-name-absolute-p prog)
        (and (file-executable-p prog) prog)
      (executable-find prog))))

(defun latex-to-svg-backend--latex-format-name ()
  "Return the base LaTeX format to preload when dumping (e.g. \"latex\").
The `&NAME' the `-ini' dump reads before `mylatexformat.ltx'."
  (file-name-nondirectory (car (split-string latex-to-svg-backend-latex-program))))

(defun latex-to-svg-backend--format-key ()
  "Return the cache key naming the precompiled preamble format file.
Folds in the full preamble and the LaTeX program, so any change to
either yields a distinct `.fmt' (and a rebuild on the next render)."
  (secure-hash 'sha1 (format "%s\0%s"
                             (latex-to-svg-backend--preamble)
                             latex-to-svg-backend-latex-program)))

(defun latex-to-svg-backend--fmt-dir ()
  "Return the subdirectory holding precompiled `.fmt' files, creating it."
  (latex-to-svg-backend--subdir "fmt"))

(defun latex-to-svg-backend--format-file (fkey)
  "Return the precompiled format file path (`.fmt') for FKEY."
  (expand-file-name (concat fkey ".fmt") (latex-to-svg-backend--fmt-dir)))

(defun latex-to-svg-backend--precompile-available-p ()
  "Return non-nil when the preamble can be dumped to a `.fmt'.
Requires the `mylatexformat' package: `mylatexformat.ltx' must be
findable via `kpsewhich'.

A `kpsewhich' that exits non-zero just means the package is not installed.
A `kpsewhich' that cannot be started at all (moved by a toolchain upgrade
mid-session) is a different matter: it is reported once
\(`latex-to-svg-backend--warn-once') and treated as unavailable, so the
engine falls back to full compiles."
  (and (executable-find "kpsewhich")
       (eql 0 (condition-case err
                  (call-process "kpsewhich" nil nil nil "mylatexformat.ltx")
                (file-error
                 (latex-to-svg-backend--warn-once
                  "probing for mylatexformat" err))))))

(defun latex-to-svg-backend--build-format (fkey)
  "Dump the preamble to a precompiled format file for FKEY, synchronously.
Return the `.fmt' path on success, nil on failure.  Writes the preamble
followed by `\\endofdump' to a scratch `.tex' in the `fmt/' subdirectory
and runs `latex-to-svg-backend-latex-program' in `-ini' mode with
`mylatexformat.ltx' to dump `<cache>/fmt/FKEY.fmt'.  The build log is in the
`*latex-to-svg-backend-precompile*' buffer for inspection.

A preamble that will not dump exits non-zero and yields nil (the caller
falls back to a full compile, which reports the real LaTeX error).  A LaTeX
program that cannot be started at all is reported once instead."
  (let* ((dir (latex-to-svg-backend--fmt-dir))
         (base (expand-file-name fkey dir))
         (fmt (concat base ".fmt"))
         (pre-tex (concat base ".tex"))
         (log (concat base ".log"))
         (buffer (get-buffer-create "*latex-to-svg-backend-precompile*")))
    (with-current-buffer buffer (erase-buffer))
    (with-temp-file pre-tex
      (insert (latex-to-svg-backend--preamble) "\n\\endofdump\n"))
    (message "latex-to-svg-backend: precompiling LaTeX preamble...")
    (let ((rv (condition-case err
                  (call-process latex-to-svg-backend-latex-program nil buffer nil
                                (concat "-output-directory=" dir)
                                "-ini"
                                (concat "-jobname=" fkey)
                                (concat "&" (latex-to-svg-backend--latex-format-name))
                                "mylatexformat.ltx" pre-tex)
                ;; The program was on `exec-path' when the toolchain was
                ;; checked but cannot be started now (a TeX Live upgrade
                ;; mid-session moves it).  Report it once; the caller falls
                ;; back to a full compile, which reports its own failure.
                (file-error
                 (latex-to-svg-backend--warn-once
                  "dumping the LaTeX preamble" err)))))
      (delete-file pre-tex)
      (if (and (eql rv 0) (file-exists-p fmt))
          (progn (delete-file log) fmt)
        (delete-file fmt)
        nil))))

(defun latex-to-svg-backend--ensure-format ()
  "Return a fresh precompiled preamble format file path, or nil.
Builds the `.fmt' on first use (synchronously, once per session per
preamble) and caches it on disk.  Rebuilds it when the LaTeX binary is
newer than the `.fmt' (e.g. after a TeX toolchain upgrade, which would
otherwise fail every compile with a format-version mismatch).  Returns
nil — so the caller uses a full compile — when precompilation is off,
`mylatexformat' is unavailable, the dump fails, or the format has been
blocklisted after an earlier failure."
  (when latex-to-svg-backend-precompile
    (let ((fkey (latex-to-svg-backend--format-key)))
      (unless (gethash fkey latex-to-svg-backend--format-blocklist)
        (let ((fmt (latex-to-svg-backend--format-file fkey))
              (latex-bin (latex-to-svg-backend--latex-binary)))
          (cond
           ;; Verified fresh already this session.
           ((and (gethash fkey latex-to-svg-backend--format-checked)
                 (file-exists-p fmt))
            fmt)
           ;; On disk and newer than the engine binary -> trust it.
           ((and (file-exists-p fmt)
                 (or (null latex-bin)
                     (file-newer-than-file-p fmt latex-bin)))
            (puthash fkey t latex-to-svg-backend--format-checked)
            fmt)
           ;; Missing or stale -> (re)build, if mylatexformat is available.
           ((latex-to-svg-backend--precompile-available-p)
            (delete-file fmt)
            (if-let* ((built (latex-to-svg-backend--build-format fkey)))
                (progn
                  (puthash fkey t latex-to-svg-backend--format-checked)
                  built)
              ;; The dump failed.  Give up on this preamble for the session:
              ;; retrying would run a synchronous `latex -ini' for every
              ;; equation, and a preamble that will not dump does not start
              ;; dumping on the next attempt.
              (latex-to-svg-backend--block-format fmt)
              nil))))))))

(defun latex-to-svg-backend--block-format (format-file)
  "Abandon FORMAT-FILE and skip precompilation for its preamble this session.
Deletes the `.fmt' (if any) and blocklists its key, so `--ensure-format'
returns nil for this preamble for the rest of the session and the engine
falls back to full compiles.  Warns once — one warning per preamble, since
the blocklist short-circuits every later call.

Called from the two ways precompilation can fail: the dump itself failed
\(see `latex-to-svg-backend--build-format'; the log stays in the
`*latex-to-svg-backend-precompile*' buffer), or the dump succeeded but a
compile that loaded it failed.  In the latter case the same equation is
about to be retried with the full inline preamble, so a genuinely broken
equation is not mistaken for a broken format."
  (let ((fkey (file-name-base format-file)))
    (puthash fkey t latex-to-svg-backend--format-blocklist)
    (remhash fkey latex-to-svg-backend--format-checked)
    (delete-file format-file)
    (display-warning
     'latex-to-svg-backend
     "Precompiled LaTeX preamble failed; falling back to full compiles."
     :warning)))

;;;; Async compile

(defun latex-to-svg-backend--process-output (buffer)
  "Return BUFFER's process output as an unpropertized string."
  (if (buffer-live-p buffer)
      (with-current-buffer buffer
        (buffer-substring-no-properties (point-min) (point-max)))
    ""))

(defun latex-to-svg-backend--append-process-log (buffer message)
  "Append MESSAGE as a line to process log BUFFER when possible.
Diagnostics are best-effort: a killed, read-only, or otherwise
unwritable BUFFER must never prevent the process chain from settling."
  (when (buffer-live-p buffer)
    (condition-case nil
        (with-current-buffer buffer
          (let ((inhibit-read-only t))
            (goto-char (point-max))
            (unless (bolp)
              (insert "\n"))
            (insert message)
            (unless (string-suffix-p "\n" message)
              (insert "\n"))))
      (error nil))))

(defun latex-to-svg-backend--start-process
    (stage command dir output-buffer sentinel)
  "Start STAGE directly with argv COMMAND in DIR.
Send stdout and stderr to OUTPUT-BUFFER and install SENTINEL.  No
shell is involved, so this is independent of `shell-file-name'."
  (latex-to-svg-backend--append-process-log
   output-buffer (format "[%s] %S" stage command))
  (let ((default-directory (file-name-as-directory dir)))
    (make-process
     :name (format "latex-to-svg-backend-%s" stage)
     :buffer output-buffer
     :command command
     :connection-type 'pipe
     :noquery t
     :sentinel sentinel)))

(defun latex-to-svg-backend--run-process-chain
    (dir output-buffer stages done)
  "Run STAGES sequentially in DIR, logging to OUTPUT-BUFFER, then call DONE.
Each element of STAGES is (NAME COMMAND OUTPUT-FILE), where COMMAND
is an argv list passed directly to `make-process'.  Each stage's
terminal status, exit status, and sentinel event are logged to
OUTPUT-BUFFER.  A stage succeeds only when it exits with status zero
and OUTPUT-FILE exists.  DONE is called once with non-nil on complete
success and nil on any failed exit, signal, missing output, or process
startup error."
  (cl-labels
      ((run
        (remaining)
        (if (null remaining)
            (funcall done t)
          (pcase-let* ((`(,stage ,command ,output-file) (car remaining))
                       (settled nil))
            (condition-case err
                (latex-to-svg-backend--start-process
                 stage command dir output-buffer
                 (lambda (process event)
                   (let ((status (process-status process)))
                     (when (and (not settled)
                                (memq status '(exit signal)))
                       (setq settled t)
                       (let* ((exit-status (process-exit-status process))
                              (output-exists (file-exists-p output-file)))
                         (let ((print-escape-newlines t))
                           (latex-to-svg-backend--append-process-log
                            output-buffer
                            (format "[%s] status=%s exit-status=%d event=%S"
                                    stage status exit-status event)))
                         (when (and (eq status 'exit)
                                    (zerop exit-status)
                                    (not output-exists))
                           (latex-to-svg-backend--append-process-log
                            output-buffer
                            (format "[%s] expected output missing: %S"
                                    stage output-file)))
                         (if (and (eq status 'exit)
                                  (zerop exit-status)
                                  output-exists)
                             (run (cdr remaining))
                           (funcall done nil)))))))
              (error
               (latex-to-svg-backend--append-process-log
                output-buffer
                (format "[%s] failed to start: %s"
                        stage (error-message-string err)))
               (funcall done nil)))))))
    (run stages)))

(defun latex-to-svg-backend--compile-failed
    (key latex dir &optional process-output)
  "Handle a failed LaTeX-to-SVG compile for KEY with source LATEX.
DIR is the scratch directory containing equation.log when LaTeX
created one.  PROCESS-OUTPUT is the captured stdout and stderr from
the direct LaTeX/dvisvgm processes.  A persistent log containing the
available diagnostics is written to the cache directory, and a
warning is emitted with a clickable link to it.

The log is copied byte-for-byte (`raw-text' in and out): a TeX log
echoing an unencodable Unicode character would otherwise make
`write-region' prompt for a coding system from a background compile."
  (let* ((log-src (expand-file-name "equation.log" dir))
         (log-dst (expand-file-name (concat key ".log")
                                    (latex-to-svg-backend--shard-dir key)))
         (have-tex-log (file-exists-p log-src))
         (have-output (not (string-empty-p (or process-output ""))))
         (snippet (truncate-string-to-width latex 60 nil nil t)))
    (when (or have-tex-log have-output)
      (let ((coding-system-for-read 'raw-text)
            (coding-system-for-write 'raw-text))
        (with-temp-file log-dst
          (when have-tex-log
            (insert-file-contents log-src)
            (goto-char (point-max))
            (unless (bolp)
              (insert "\n")))
          (when have-output
            (when have-tex-log
              (insert "\n--- process output ---\n"))
            (insert process-output)))))
    (display-warning
     'latex-to-svg-backend
     (format "LaTeX-to-SVG compile failed for: %s\nSee log: %s"
             snippet
             (if (file-exists-p log-dst) log-dst "(no log available)"))
     :warning)
    (when (and (file-exists-p log-dst) (get-buffer "*Warnings*"))
      (with-current-buffer "*Warnings*"
        (let ((inhibit-read-only t))
          (goto-char (point-max))
          (save-excursion
            (when (search-backward log-dst nil t)
              (make-text-button (point) (+ (point) (length log-dst))
                                'action (lambda (_) (find-file log-dst))
                                'help-echo "Open LaTeX log"))))))))

(defun latex-to-svg-backend--write-metadata (key dir initial)
  "Write KEY's `.eld' sidecar pairing INITIAL with the compile's FINAL.
Scans the just-finished compile's `equation.log' in scratch DIR for the
first integer on a line beginning with `latex-to-svg-backend-metadata-prefix'
\(FINAL), and writes `(:nums (INITIAL . FINAL))' to `<KEY>.eld'.
INITIAL is the caller's value (from `latex-to-svg-backend's `:metadata'), stored
verbatim.  Writes nothing when the prefix is nil or no FINAL was found.
Called on a successful compile, before DIR is cleaned up."
  (when latex-to-svg-backend-metadata-prefix
    (let ((log (expand-file-name "equation.log" dir))
          (final nil))
      (when (file-readable-p log)
        (with-temp-buffer
          (let ((coding-system-for-read 'raw-text))
            (insert-file-contents log))
          (goto-char (point-min))
          (while (and (not final) (not (eobp)))
            (let ((line (buffer-substring-no-properties
                         (line-beginning-position) (line-end-position))))
              (when (string-prefix-p latex-to-svg-backend-metadata-prefix line)
                (let ((rest (substring line (length latex-to-svg-backend-metadata-prefix))))
                  (when (string-match "-?[0-9]+" rest)
                    (setq final (string-to-number (match-string 0 rest)))))))
            (forward-line 1))))
      (when final
        (condition-case err
            (with-temp-file (latex-to-svg-backend--meta-file key)
              (prin1 (list :nums (cons initial final)) (current-buffer)))
          ;; This runs in the compile sentinel, *before* the pending callbacks
          ;; fire: signalling here would leave a successfully compiled equation
          ;; unplaced.  The sidecar is a cache, so report the failure once and
          ;; let the equation through.
          (file-error
           (latex-to-svg-backend--warn-once "writing compile metadata" err)))))))

(defun latex-to-svg-backend--compile (key latex &optional metadata no-format)
  "Asynchronously compile LATEX to the color-independent cache SVG for KEY.
METADATA, when non-nil, is stored as the INITIAL value in KEY's `.eld'
sidecar alongside the FINAL captured from the log (see
`latex-to-svg-backend--write-metadata').

LATEX is placed verbatim in the document body (the caller supplies
valid body LaTeX and chooses inline vs display via delimiters).
Writes a standalone LaTeX document, runs `latex-to-svg-backend-latex-program'
then `latex-to-svg-backend-dvisvgm-program' in a scratch directory, and on
success caches the SVG and notifies every callback queued for KEY
\(see `latex-to-svg-backend--enqueue').  The scratch directory is removed when
the process exits.

The preamble is loaded from a precompiled format file (`.fmt') when one
is available (see `latex-to-svg-backend-precompile'), via a `%&' first line;
otherwise the full preamble is embedded in the document.  On failure,
if a format was used it may be the culprit: the format is abandoned (see
`latex-to-svg-backend--block-format') and the same equation is retried once with
the full inline preamble.  Only when a full-preamble compile fails is
the log saved and a warning emitted (see `latex-to-svg-backend--compile-failed')
and queued callbacks dropped.  NO-FORMAT forces that inline path (it is
set on the retry).

No color is baked in: the equation's default ink is emitted as the
literal `currentColor' (dvisvgm `--currentcolor'), so the SVG is
color-independent and is tinted to the buffer foreground at display
time (`latex-to-svg-backend--load-svg-image').  A theme change therefore
re-tints from cache without recompiling."
  (let* ((dir (make-temp-file "latex-to-svg-backend" t))
         (tex (expand-file-name "equation.tex" dir))
         (dvi (expand-file-name "equation.dvi" dir))
         (svg (latex-to-svg-backend--svg-file key))
         (format-file (and (not no-format) (latex-to-svg-backend--ensure-format)))
         (cleanup (lambda () (delete-directory dir t)))
         (output-buffer (generate-new-buffer
                         (format " *latex-to-svg-backend-%s*" key))))
    (with-temp-file tex
      (if format-file
          ;; Load the precompiled preamble: the `%&' line must be first, and
          ;; names the format file by absolute path without its `.fmt'
          ;; extension.  The class + packages are already in the format, so
          ;; only the document body is compiled here.
          (insert "%& " (file-name-sans-extension format-file) "\n"
                  "\\begin{document}\n"
                  latex "\n"
                  "\\end{document}\n")
        (insert (latex-to-svg-backend--preamble) "\n"
                "\\begin{document}\n"
                ;; LATEX is inserted verbatim: it already carries its own math
                ;; delimiters / environment (chosen by the front-end), which
                ;; also decide inline vs display sizing.  No `\color' —
                ;; `--currentcolor' below turns the default (black) ink into
                ;; the `currentColor' token, tinted at display.
                latex "\n"
                "\\end{document}\n")))
    ;; Compile at dvisvgm scale 1: the SVG is vector (glyphs are outline
    ;; paths via --no-fonts), so the scale doesn't affect quality, and the
    ;; displayed size is set later by `latex-to-svg-backend-display-scale'.  Fixing
    ;; it at 1 means the SVG carries the equation's natural point dimensions.
    ;; `--currentcolor' rewrites the default ink to the `currentColor' token
    ;; so the file is color-independent (tinted at display time).
    (latex-to-svg-backend--run-process-chain
     dir output-buffer
     (list
      (list 'latex
            (list latex-to-svg-backend-latex-program
                  "-interaction=nonstopmode"
                  "-halt-on-error"
                  tex)
            dvi)
      (list 'dvisvgm
            (list latex-to-svg-backend-dvisvgm-program
                  "--no-fonts"
                  "--exact-bbox"
                  "--currentcolor"
                  "--scale=1"
                  "-o"
                  svg
                  dvi)
            svg))
     (lambda (success)
       (let ((retry-format (and (not success) format-file)))
         (unwind-protect
             (cond
              (success
               ;; Capture compile metadata before DIR is cleaned up.
               (latex-to-svg-backend--write-metadata key dir metadata)
               (dolist (cb (gethash key latex-to-svg-backend--pending))
                 (condition-case cb-err
                     (funcall cb)
                   (error
                    (message "latex-to-svg-backend: callback error: %S"
                             cb-err)))))
              ;; A failed precompiled-format attempt is retried once with the
              ;; full inline preamble; keep the pending callback queue intact.
              (retry-format
               (latex-to-svg-backend--block-format format-file))
              ;; Genuine failure (full preamble): persist diagnostics.
              (t
               (latex-to-svg-backend--compile-failed
                key latex dir
                (latex-to-svg-backend--process-output output-buffer))))
           (unless retry-format
             (remhash key latex-to-svg-backend--pending))
           (when (buffer-live-p output-buffer)
             (kill-buffer output-buffer))
           (funcall cleanup))
         (when retry-format
           (latex-to-svg-backend--compile key latex metadata t)))))))

(defun latex-to-svg-backend--enqueue (key latex callback &optional metadata)
  "Queue CALLBACK for KEY and start a compile if none is running.

KEY identifies the equation; LATEX is forwarded to
`latex-to-svg-backend--compile' for the render, along with METADATA (the INITIAL
value for the `.eld' sidecar).  Multiple callbacks sharing KEY (the same
equation requested more than once) are coalesced onto a single in-flight
compile; all are notified when it finishes."
  (let ((pending (gethash key latex-to-svg-backend--pending)))
    (puthash key (cons callback pending) latex-to-svg-backend--pending)
    (unless pending
      (latex-to-svg-backend--compile key latex metadata))))

;;;; Public entry point

(cl-defun latex-to-svg-backend (latex &key callback metadata rescale-by color background padding font-height)
  "Return an SVG image for LATEX, or nil while it compiles.

METADATA, when non-nil and `latex-to-svg-backend-metadata-prefix' is set, is the
INITIAL value stored in this equation's `.eld' sidecar (see
`latex-to-svg-backend-metadata'); the FINAL value is captured from the compile
log.  It is only recorded when a compile actually runs (a miss).

RESCALE-BY (default 1.0) multiplies the base display size for this one
call, on top of the global `latex-to-svg-backend-font-scale'.  The engine has no
inline/display awareness; a front-end that wants display equations a
touch larger than inline passes, say, `:rescale-by 1.1' for display and
nothing for inline.  It is applied at display time only -- same on-disk SVG,
no recompile — and folds into the in-memory image cache key, so the two
sizes coexist.

COLOR overrides the tint for this one call (a color string — `#rrggbb'
or any name `color-name-to-rgb' understands); nil (the default) tints
to the buffer foreground (`latex-to-svg-backend-foreground-color'), which
tracks the theme.  BACKGROUND paints a box color behind the otherwise
transparent equation (a color string); nil (the default) keeps it
transparent so it blends into the buffer.  PADDING (a number of pt >
0) grows that box beyond the ink on all sides (it scales with the
equation); nil / 0 (the default) crops the box to the ink.  All apply
at display time only -- same on-disk SVG, no recompile -- and fold
into the in-memory image cache key, so tinted / boxed / padded
variants coexist.  The engine has no tint policy of its own beyond
following the buffer face; a front-end owns the user preference and
passes it here.

FONT-HEIGHT (pixels) is the buffer font height to size against.  A
front-end that knows the buffer's actual display frame measures
`default-font-height' there and passes it, so sizing never depends on
which frame is selected.  When omitted, the selected frame is measured
if graphical.  When no height is known (omitted and the selected frame
is non-graphical -- e.g. an async/daemon render of a buffer shown
nowhere), the engine still ensures the (size-independent) SVG is
compiled and cached, but returns nil instead of sizing against a guess:
the caller re-queries once the buffer is displayed (where a trustworthy
height exists) and the image is built then, from cache, with no
recompile.

LATEX is placed *verbatim* in the LaTeX document body, so it must be
valid there: pass math with its delimiters (`$x$', `\\(x\\)', `\\[x\\]')
or a full environment (`\\begin{equation}...\\end{equation}').  The
delimiters also choose inline vs display sizing — the engine does not.

Returns immediately with:

  * the placeholder panel image, when `latex-to-svg-backend-use-placeholder'
    is set or the toolchain is unavailable (see
    `latex-to-svg-backend--placeholder');
  * the cached / on-disk equation image when it is ready;
  * nil when equations aren't renderable (see
    `latex-to-svg-backend-available-p') — the caller keeps the raw text.

When the equation is renderable but not yet compiled, returns nil and
schedules an asynchronous compile; CALLBACK (a zero-argument function)
is invoked once, when the SVG is ready, so the caller can re-query
\(call `latex-to-svg-backend' again, which now returns the image) and place
it.  Concurrent requests for the same equation share one compile.

The image is tinted to the current buffer foreground and scaled to
the buffer font at build time, so call within the target buffer."
  (when (latex-to-svg-backend-available-p)
    (cond
     ((or latex-to-svg-backend-use-placeholder
          (not (latex-to-svg-backend-tools-available-p)))
      (latex-to-svg-backend--placeholder latex))
     (t
      (let* ((key (latex-to-svg-backend--cache-key latex))
             (compiled (file-exists-p (latex-to-svg-backend--svg-file key)))
             (image (and compiled
                         (latex-to-svg-backend--cached-image
                          key rescale-by color background padding font-height))))
        (cond
         ;; SVG on disk and a trustworthy size: return the display image.
         (image)
         ;; Compiled, but no size context yet (buffer shown nowhere): defer.
         ;; The caller re-renders when the buffer is displayed.
         (compiled nil)
         ;; Not compiled: ensure it is (eagerly, even with no size context),
         ;; so it is ready when the buffer is later displayed; CALLBACK fires
         ;; on completion so the caller re-queries and sizes it then.
         (t (when callback
              (latex-to-svg-backend--enqueue key latex callback metadata))
            nil)))))))

;;;###autoload
(defun latex-to-svg-backend-invalidate (latex)
  "Forget any cached render of LATEX and force a recompile next time.

Deletes LATEX's on-disk SVG (named after LATEX's content) and drops every
in-memory image built from it (all sizes / colors), so a subsequent
`latex-to-svg-backend' for LATEX recompiles from scratch.  Use this to recover
from a stale or corrupt cached SVG — ordinarily the content hash makes
that impossible, so this is an escape hatch, not part of the normal
flow."
  (let* ((key (latex-to-svg-backend--cache-key latex))
         (file (latex-to-svg-backend--svg-file key))
         (meta (latex-to-svg-backend--meta-file key))
         (prefix (concat key "@"))
         (stale nil))
    (when (file-exists-p file)
      (delete-file file))
    ;; Keep the metadata sidecar coupled to its SVG.
    (when (file-exists-p meta)
      (delete-file meta))
    (maphash (lambda (k _v)
               (when (string-prefix-p prefix k)
                 (push k stale)))
             latex-to-svg-backend--image-cache)
    (dolist (k stale)
      (remhash k latex-to-svg-backend--image-cache))))

;;;###autoload
(defun latex-to-svg-backend-flush-format ()
  "Delete all precompiled preamble format files and forget them.

Removes every `.fmt' in the cache `fmt/' subdirectory and clears this session's
freshness and blocklist tracking, so the next render dumps a fresh
format from the current preamble.  An escape hatch for a stale format
the automatic freshness check missed — normally a TeX toolchain upgrade
is handled on its own (the binary is newer than the `.fmt'), so this is
rarely needed."
  (interactive)
  (clrhash latex-to-svg-backend--format-checked)
  (clrhash latex-to-svg-backend--format-blocklist)
  (let ((dir (expand-file-name "fmt" (latex-to-svg-backend--cache-dir))))
    (when (file-directory-p dir)
      (dolist (f (directory-files dir t "\\.fmt\\'"))
        (delete-file f)))))

;;;###autoload
(defun latex-to-svg-backend-metadata (latex)
  "Return cached compile metadata for LATEX, or nil.

Returns the plist `(:nums (INITIAL . FINAL))' read from LATEX's
`.eld' sidecar: INITIAL is the caller's `:metadata' at render time and
FINAL is the first integer the compile emitted on a
`latex-to-svg-backend-metadata-prefix' line.  Available on cache hit or miss
once LATEX has compiled at least once with the prefix set; nil otherwise.

A sidecar that cannot be parsed (truncated by a crash mid-write) also
yields nil, but it is not left to rot: only a compile can rewrite it, and
the cached SVG would keep any compile from happening, so LATEX's whole
cache entry is discarded (`latex-to-svg-backend-invalidate') and the next
render rebuilds both the SVG and the sidecar.  Done at most once per
equation per session."
  (let* ((key (latex-to-svg-backend--cache-key latex))
         (file (latex-to-svg-backend--meta-file key)))
    (when (file-readable-p file)
      (condition-case err
          (with-temp-buffer
            (insert-file-contents file)
            (read (current-buffer)))
        ;; Unreadable syntax: repairable, by making the entry compile again.
        ((end-of-file invalid-read-syntax)
         (latex-to-svg-backend--warn-once
          "discarding an unreadable metadata sidecar" err)
         (unless (gethash key latex-to-svg-backend--metadata-repaired)
           (puthash key t latex-to-svg-backend--metadata-repaired)
           (latex-to-svg-backend-invalidate latex))
         nil)
        ;; Not repairable by recompiling -- and the deletions that a repair
        ;; would attempt are exactly what is failing here.  Report it.
        (file-error
         (latex-to-svg-backend--warn-once
          "reading compile metadata" err 'buffer))))))

;;;; Cache maintenance (garbage collection)

(defun latex-to-svg-backend--delete-entry (svg)
  "Delete cache SVG and its `.eld'/`.log' siblings.  Return the bytes freed."
  (let ((base (file-name-sans-extension svg))
        (freed 0))
    (dolist (ext '(".svg" ".eld" ".log"))
      (let ((f (concat base ext)))
        (when (file-exists-p f)
          (cl-incf freed (or (file-attribute-size (file-attributes f)) 0))
          ;; No guard needed: `delete-file' ignores ENOENT, so another session
          ;; collecting the same shared cache entry first is not an error --
          ;; while a real one (unwritable cache) still signals.
          (delete-file f))))
    freed))

(defun latex-to-svg-backend--gc-stamp-file ()
  "Return the path of the file recording the last GC time."
  (expand-file-name "gc-timestamp" (latex-to-svg-backend--cache-dir)))

(defun latex-to-svg-backend--last-gc-time ()
  "Return the `float-time' of the last recorded GC, or 0 if never / unreadable.
An unusable stamp is reported once and treated as \"never collected\", which
is self-healing: the next GC runs and rewrites the stamp."
  (let ((f (latex-to-svg-backend--gc-stamp-file)))
    (or (and (file-readable-p f)
             (condition-case err
                 (let ((stamp (with-temp-buffer
                                (insert-file-contents f)
                                (read (current-buffer)))))
                   (if (numberp stamp)
                       stamp
                     ;; Parsed, but not a time -- corrupt just the same.
                     (latex-to-svg-backend--warn-once
                      "reading the GC timestamp"
                      (list 'invalid-read-syntax f))))
               ((end-of-file invalid-read-syntax file-error)
                (latex-to-svg-backend--warn-once
                 "reading the GC timestamp" err))))
        0)))

(defun latex-to-svg-backend--record-gc-time ()
  "Persist the current time as the last GC time (for the daily cadence).
A cache directory that cannot be written is reported once; the cadence is
then simply not persisted, so the next idle check collects again -- harmless,
since collecting an already-collected cache frees nothing."
  (condition-case err
      (with-temp-file (latex-to-svg-backend--gc-stamp-file)
        (prin1 (float-time) (current-buffer)))
    (file-error
     (latex-to-svg-backend--warn-once "recording the GC timestamp" err))))

;;;###autoload
(defun latex-to-svg-backend-gc ()
  "Prune the on-disk equation cache of entries untouched for too long.

Deletes every cached SVG (with its `.eld' / `.log' siblings) whose
modification time is older than `latex-to-svg-backend-cache-max-age' days.
The SVG mtime is a last-use hint, bumped whenever an equation is (re)loaded
\(see `latex-to-svg-backend--touch'), so equations you keep viewing are kept;
a pruned one simply recompiles the next time it is needed.

Runs automatically about once a day (see `latex-to-svg-backend-gc-interval');
this command forces a run now.  Returns a cons (DELETED . BYTES-FREED)."
  (interactive)
  (let* ((svg-dir (expand-file-name "svg" (latex-to-svg-backend--cache-dir)))
         (svgs (and (file-directory-p svg-dir)
                    (directory-files-recursively svg-dir "\\.svg\\'")))
         (now (float-time))
         (max-age (and latex-to-svg-backend-cache-max-age
                       (* latex-to-svg-backend-cache-max-age 86400)))
         (deleted 0) (freed 0))
    (when max-age
      (dolist (f svgs)
        (let ((mtime (float-time (file-attribute-modification-time
                                  (file-attributes f)))))
          (when (> (- now mtime) max-age)
            (cl-incf freed (latex-to-svg-backend--delete-entry f))
            (cl-incf deleted)))))
    (latex-to-svg-backend--record-gc-time)
    (when (called-interactively-p 'interactive)
      (message "latex-to-svg-backend: GC removed %d equation(s), freed %s"
               deleted (file-size-human-readable freed)))
    (cons deleted freed)))

;;;###autoload
(defun latex-to-svg-backend-clear-cache ()
  "Delete every cached equation SVG and its `.eld'/`.log' siblings.

Empties the on-disk equation cache (all shards) and the in-memory image
cache; precompiled `.fmt' format files are kept (see
`latex-to-svg-backend-flush-format').  Every equation simply recompiles on
next use — a blunt companion to `latex-to-svg-backend-gc' and
`latex-to-svg-backend-invalidate'."
  (interactive)
  (let ((svg-dir (expand-file-name "svg" (latex-to-svg-backend--cache-dir))))
    (when (file-directory-p svg-dir)
      (delete-directory svg-dir t)))
  (clrhash latex-to-svg-backend--image-cache))

(defvar latex-to-svg-backend--gc-timer nil
  "Idle timer that periodically triggers `latex-to-svg-backend--maybe-gc', or nil.")

(defun latex-to-svg-backend--maybe-gc ()
  "Run `latex-to-svg-backend-gc' unless a GC ran within the interval.
Idle-timer entry point.  Honours `latex-to-svg-backend-gc-interval' (nil
disables automatic GC) and enforces the cadence via the on-disk timestamp,
so the cache is collected at most once per interval across every session
that shares it — including a daemon left running for days."
  (when (and latex-to-svg-backend-gc-interval
             (> (- (float-time) (latex-to-svg-backend--last-gc-time))
                (* latex-to-svg-backend-gc-interval 86400)))
    (latex-to-svg-backend-gc)))

;; Install the periodic GC.  The short idle period only decides how soon
;; after going idle the cadence check runs; the real frequency is bounded by
;; `latex-to-svg-backend-gc-interval' via the on-disk timestamp.  Skipped in
;; batch (tests drive `latex-to-svg-backend-gc' directly).
(unless (or noninteractive latex-to-svg-backend--gc-timer)
  (setq latex-to-svg-backend--gc-timer
        (run-with-idle-timer 300 t #'latex-to-svg-backend--maybe-gc)))

(provide 'latex-to-svg-backend)

;;; latex-to-svg-backend.el ends here
