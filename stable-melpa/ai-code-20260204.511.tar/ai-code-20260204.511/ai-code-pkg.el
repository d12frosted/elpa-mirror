;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260204.511"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "ec388214c5b5553c2a0a546791ba6c4141c6efe6"
  :revdesc "ec388214c5b5"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
