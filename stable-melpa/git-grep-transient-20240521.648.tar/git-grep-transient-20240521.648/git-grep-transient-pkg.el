;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-grep-transient" "20240521.648"
  "Search for text using git grep command."
  '((emacs          "27.1")
    (magit          "3.3.0")
    (transient      "0.6.0")
    (symbol-overlay "4.2"))
  :url "https://github.com/adelplanque/git-grep-transient"
  :commit "c9eb6d76e6b0600d2f90d009fdc28a171f69dd80"
  :revdesc "c9eb6d76e6b0"
  :keywords '("git" "tools" "vc")
  :authors '(("Alain Delplanque" . "alaindelplanque@mailoo.org"))
  :maintainers '(("Alain Delplanque" . "alaindelplanque@mailoo.org")))
