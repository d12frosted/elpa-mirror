(define-package "wildcharm-theme" "20230914.2328" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "ea7ca5641eaa32707a619588fe1b3465bdd0eec6" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
