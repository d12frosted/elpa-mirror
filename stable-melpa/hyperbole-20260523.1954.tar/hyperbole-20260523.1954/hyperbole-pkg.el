;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260523.1954"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "db74c18ddb5fd0fde94136a755ecdbad561c157d"
  :revdesc "db74c18ddb5f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
