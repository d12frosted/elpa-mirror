;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons" "20251212.806"
  "Emacs Nerd Font Icons Library."
  '((emacs "25.1"))
  :url "https://github.com/rainstormstudio/nerd-icons.el"
  :commit "1cc5b4da6bb62ad7afadcbbdaf43b632aa1aa7b3"
  :revdesc "1cc5b4da6bb6"
  :keywords '("lisp")
  :authors '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
             ("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Hongyu Ding" . "rainstormstudio@yahoo.com")
                 ("Vincent Zhang" . "seagle0128@gmail.com")))
