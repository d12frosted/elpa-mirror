;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260524.1429"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.30.2")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "9d87cb9e039e03226a0d47205be26cc39764315f"
  :revdesc "9d87cb9e039e"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
