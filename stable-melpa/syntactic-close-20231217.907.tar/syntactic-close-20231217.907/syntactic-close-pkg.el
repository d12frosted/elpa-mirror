(define-package "syntactic-close" "20231217.907" "Insert closing delimiter"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "f7940bc9971a61fee99e8fba96f7c846a4b298a5" :authors
  '(("Andreas Röhler" . "andreas.roehler@online.de")
    ("Emacs User Group Berlin" . "emacs-berlin@emacs-berlin.org"))
  :maintainers
  '(("Andreas Röhler" . "andreas.roehler@online.de"))
  :maintainer
  '("Andreas Röhler" . "andreas.roehler@online.de")
  :keywords
  '("languages" "convenience")
  :url "https://github.com/emacs-berlin/syntactic-close")
;; Local Variables:
;; no-byte-compile: t
;; End:
