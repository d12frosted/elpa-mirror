;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260329.1820"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "357c54fc03ae90c3e4eeec65cf3859ee6a050bba"
  :revdesc "357c54fc03ae"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
