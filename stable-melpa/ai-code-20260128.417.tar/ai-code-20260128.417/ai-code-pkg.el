;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260128.417"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "7e60511603dd0e5db931f769de1bdb0966d417ad"
  :revdesc "7e60511603dd"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
