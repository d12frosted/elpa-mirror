;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moe-theme" "20260206.314"
  "A colorful eye-candy theme. Moe, moe, kyun!."
  ()
  :url "https://github.com/kuanyui/moe-theme.el"
  :commit "536f86bf526f023cd033c67e08b820975c7e4198"
  :revdesc "536f86bf526f"
  :keywords '("themes")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
