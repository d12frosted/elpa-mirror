;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260129.811"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "3bb181034b3bde81491e38440ab5c0d0771eb553"
  :revdesc "3bb181034b3b"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
