(define-package "wordel" "20230109.1407" "An Elisp implementation of \"Wordle\" (aka \"Lingo\")"
  '((emacs "27.1"))
  :commit "77999d75c5eae29e22b8e3f8859b62c6e30aa65f" :authors
  '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com"))
  :maintainers
  '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com"))
  :maintainer
  '("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/progfolio/wordel")
;; Local Variables:
;; no-byte-compile: t
;; End:
