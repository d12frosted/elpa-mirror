;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260408.1810"
  "A sqlite-based note-taking package based on tags."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "cda27dc2be9c08b994b9a4dc8b68f16f4e74c19e"
  :revdesc "cda27dc2be9c"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
