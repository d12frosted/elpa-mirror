;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261023.2255"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "ea7ce562b7da6b6008f3d758457086dc705ec05b"
  :revdesc "ea7ce562b7da")
