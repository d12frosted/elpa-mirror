;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260401.442"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "1ee50a7490fddb51e9283aec33d65c8a077b36a3"
  :revdesc "1ee50a7490fd"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
