(define-package "modus-themes" "20230112.503" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "6afb2448d27f26bc73ac7472833280de9c01268e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
