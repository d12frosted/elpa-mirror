(define-package "gdscript-mode" "20201026.1319" "Major mode for Godot's GDScript language"
  '((emacs "26.3"))
  :commit "20fc7e438170b8a2e03378956c1a501fbc49aee4" :keywords
  ("languages")
  :authors
  (("Nathan Lovato <nathan@gdquest.com>, Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainer
  (nil . "nathan@gdquest.com")
  :url "https://github.com/GDQuest/emacs-gdscript-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
