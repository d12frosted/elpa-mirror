;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cmake-mode" "20261002.1529"
  "Major-mode for editing CMake sources."
  '((emacs "24.1"))
  :commit "2e0b3aec14fe2e3e555faac4698e281749aae4b5"
  :revdesc "2e0b3aec14fe")
