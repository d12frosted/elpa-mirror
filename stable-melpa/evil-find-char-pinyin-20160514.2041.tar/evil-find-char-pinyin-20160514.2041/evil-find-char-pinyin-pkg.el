;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-find-char-pinyin" "20160514.2041"
  "Evil's f/F/t/T/evil-snipe commands with Pinyin support."
  '((evil      "1.2.12")
    (pinyinlib "0.1.0"))
  :url "https://github.com/cute-jumper/evil-find-char-pinyin"
  :commit "04e277946d658f1a73c68dcbbadea9c21097a31c"
  :revdesc "04e277946d65"
  :keywords '("extensions")
  :authors '(("Junpeng Qiu" . "qjpchmail@gmail.com"))
  :maintainers '(("Junpeng Qiu" . "qjpchmail@gmail.com")))
