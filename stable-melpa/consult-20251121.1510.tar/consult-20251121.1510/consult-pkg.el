;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20251121.1510"
  "Consulting completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "0d23a785416ae929f68ad2d4aea5dea8f2952aa5"
  :revdesc "0d23a785416a"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
