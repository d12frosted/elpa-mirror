(define-package "proof-general" "20201207.2131" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.3"))
  :commit "ad5105b58374f9ed5f83d5272688f5475bc0293b")
;; Local Variables:
;; no-byte-compile: t
;; End:
