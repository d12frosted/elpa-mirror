(define-package "consult-org-roam" "20221105.1202" "Consult integration for org-roam"
  '((emacs "27.1")
    (org-roam "2.2.0")
    (consult "0.16"))
  :commit "b93cc856d1d2dd0719926e51c5a6309bbbf60b19" :authors
  '(("jgru <https://github.com/jgru>"))
  :maintainer
  '("jgru <https://github.com/jgru>")
  :url "https://github.com/jgru/consult-org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
