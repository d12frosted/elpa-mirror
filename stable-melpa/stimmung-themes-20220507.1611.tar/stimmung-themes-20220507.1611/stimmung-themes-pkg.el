(define-package "stimmung-themes" "20220507.1611" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "f84278803ab61fabf25ed6c6fb5b3dc4822b162c" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
