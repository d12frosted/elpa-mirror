;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261103.958"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "3261e641c47121cda28a23a51fcafb60a48cba0b"
  :revdesc "3261e641c471"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
