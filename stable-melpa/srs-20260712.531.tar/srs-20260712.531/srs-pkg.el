;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "20260712.531"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "4f8312989e673ec38a3f1abb301aa9cd3355f0fb"
  :revdesc "4f8312989e67"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
