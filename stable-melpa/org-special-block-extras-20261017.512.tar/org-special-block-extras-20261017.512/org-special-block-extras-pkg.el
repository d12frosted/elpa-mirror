;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-special-block-extras" "20261017.512"
  "46 new custom blocks & 57 link types for Org-mode."
  '((s     "1.13.1")
    (dash  "2.18.1")
    (emacs "28.2")
    (org   "9.8")
    (lf    "26.10.1")
    (seq   "2.0"))
  :url "https://alhassy.com/org-special-block-extras"
  :commit "4ef6f4e7323850fdb0a2947e8b4645deb431ed39"
  :revdesc "4ef6f4e73238"
  :keywords '("org" "blocks" "colors" "convenience")
  :authors '(("Musa Al-hassy" . "alhassy@gmail.com"))
  :maintainers '(("Musa Al-hassy" . "alhassy@gmail.com")))
