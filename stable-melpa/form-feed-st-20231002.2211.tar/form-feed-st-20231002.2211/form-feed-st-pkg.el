;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "form-feed-st" "20231002.2211"
  "Display ^L glyphs as full-width horizontal lines."
  '((emacs "25.1"))
  :url "https://github.com/leodag/form-feed-st"
  :commit "f91c8daf35b7588e0aa24c8716c8cfd8ff0067c8"
  :revdesc "f91c8daf35b7"
  :keywords '("faces"))
