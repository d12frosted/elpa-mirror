(define-package "osm" "20220402.241" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "277de5f785c0300f54a7ba27c585fa1d79d00d6f" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
