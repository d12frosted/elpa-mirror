;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20251013.1314"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "764bfe60f2d143a20c911d3d591153b52086df50"
  :revdesc "764bfe60f2d1"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
