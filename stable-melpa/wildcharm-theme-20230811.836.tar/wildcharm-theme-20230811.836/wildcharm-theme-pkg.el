(define-package "wildcharm-theme" "20230811.836" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "d08d1c1414e0fd02d5286ceff0e9188cdbf57519" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
