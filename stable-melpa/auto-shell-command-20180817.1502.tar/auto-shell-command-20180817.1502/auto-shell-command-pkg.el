;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-shell-command" "20180817.1502"
  "Run the shell command asynchronously that you specified when you save the file."
  '((deferred "20130312")
    (popwin   "20130329"))
  :url "https://github.com/ongaeshi/auto-shell-command"
  :commit "a8f9213e3c773b5687b81881240e6e648f2f56ba"
  :revdesc "a8f9213e3c77"
  :keywords '("shell" "save" "async" "deferred" "auto"))
