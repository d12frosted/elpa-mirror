;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-wild-notifier" "20260126.1831"
  "Customizable org-agenda notifications."
  '((alert "1.2")
    (async "1.9.3")
    (dash  "2.18.0")
    (emacs "27.1"))
  :url "https://github.com/emacsorphanage/org-wild-notifier.el"
  :commit "2c830dc17e97db5444571beefe3dcf743ea63cf3"
  :revdesc "2c830dc17e97"
  :keywords '("calendar" "convenience")
  :authors '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainers '(("Artem Khramov" . "akhramov+emacs@pm.me")))
