;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20241211.619"
  "Major mode for Clojure code."
  '((emacs "25.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "740ca698b02725a6506aad873ff080c51982e5e7"
  :revdesc "740ca698b027"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
