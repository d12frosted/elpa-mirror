(define-package "fountain-mode" "20240624.601" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "3d389c0b65dc6cb8dcdc130a9f80f41599b793e7" :authors
  '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainers
  '(("Paul W. Rankin" . "rnkn@rnkn.xyz"))
  :maintainer
  '("Paul W. Rankin" . "rnkn@rnkn.xyz")
  :keywords
  '("wp" "text")
  :url "https://www.fountain-mode.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
