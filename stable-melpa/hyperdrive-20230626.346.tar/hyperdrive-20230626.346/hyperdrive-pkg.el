(define-package "hyperdrive" "20230626.346" "P2P filesystem in Emacs"
  '((emacs "27.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.6pre")
    (persist "0.5"))
  :commit "0bcc75f946ead0174e9d947fdd7c216dc90f8bbb" :authors
  '(("Joseph Turner"))
  :maintainers
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainer
  '("Joseph Turner" . "joseph@ushin.org")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
