(define-package "verb" "20240625.1833" "Organize and send HTTP requests"
  '((emacs "26.3"))
  :commit "d96ffeb8b8442c857c5aff0650bc75c4b5faa5da" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
