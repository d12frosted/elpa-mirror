(define-package "ebib" "20220313.721" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "0c94f61f4b30dccd484f185def835a7a9a6e1d3d" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
