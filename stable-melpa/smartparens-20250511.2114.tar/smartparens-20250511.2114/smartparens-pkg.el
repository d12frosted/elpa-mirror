;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smartparens" "20250511.2114"
  "Automatic insertion, wrapping and paredit-like navigation with user defined pairs."
  '((dash "2.13.0"))
  :url "https://github.com/Fuco1/smartparens"
  :commit "773f930196c48b9b4d94a84a8cdceb04ada3801a"
  :revdesc "773f930196c4"
  :keywords '("abbrev" "convenience" "editing")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
