(define-package "mark-thing-at" "20230805.1701" "Mark a pattern at the current point"
  '((emacs "26")
    (choice-program "0.14"))
  :commit "22ce137450890421c8dce79943c96dec79a65d77" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("mark" "point" "lisp")
  :url "https://github.com/plandes/mark-thing-at")
;; Local Variables:
;; no-byte-compile: t
;; End:
