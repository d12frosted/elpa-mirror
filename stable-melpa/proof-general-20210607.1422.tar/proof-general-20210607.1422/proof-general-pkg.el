(define-package "proof-general" "20210607.1422" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "24.5"))
  :commit "bc86736abb728ec0d28abc90ef0adae21d29a66a" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
