(define-package "consult" "20230204.1129" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.2"))
  :commit "07b6a91f1a43e64e68b02dface961b839b6abcba" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
