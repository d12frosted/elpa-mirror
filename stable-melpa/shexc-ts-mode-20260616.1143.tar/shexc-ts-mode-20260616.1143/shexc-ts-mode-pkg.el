;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "20260616.1143"
  "Tree-sitter major mode for ShExC."
  '((emacs "29.1"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "4107c1563131ba564f93e8ce26e1e5c27653373d"
  :revdesc "4107c1563131"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
