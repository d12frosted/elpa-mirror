(define-package "fennel-mode" "20230421.952" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "097b83951f082a93430c3b5a32c67c9c68a1f2a8" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
