(define-package "dwim-coder-mode" "20230811.1407" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "06ad57b434a3fcb5e25d9feeb2bb154b783b9ee0" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
