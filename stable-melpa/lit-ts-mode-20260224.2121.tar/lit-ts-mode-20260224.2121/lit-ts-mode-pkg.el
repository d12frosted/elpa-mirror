;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lit-ts-mode" "20260224.2121"
  "Lit-aware JS/TS modes with tree-sitter support."
  '((emacs                     "30.1")
    (template-literals-ts-mode "0.1.0"))
  :url "https://github.com/ispringle/lit-ts-mode"
  :commit "9dae586c13b28c467cda462c767d10e2ade3658f"
  :revdesc "9dae586c13b2"
  :keywords '("languages" "javascript" "typescript" "tree-sitter" "lit")
  :authors '(("Ian S. Pringle" . "ian@dapringles.com"))
  :maintainers '(("Ian S. Pringle" . "ian@dapringles.com")))
