;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260319.248"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "d83124b15200c297a9c34e01994bfd157372264e"
  :revdesc "d83124b15200"
  :keywords '("faces" "files" "q"))
