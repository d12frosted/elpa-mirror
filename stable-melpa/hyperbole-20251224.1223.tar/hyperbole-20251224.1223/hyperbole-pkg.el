;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251224.1223"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "4ba5f37bbdb535d232a715fdc765e782a2382d02"
  :revdesc "4ba5f37bbdb5"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
