(define-package "datetime" "20240331.2024" "Parsing, formatting and matching timestamps"
  '((emacs "25.1")
    (extmap "1.1.1"))
  :commit "a71c4abd7993ab207fc33527f4d9aa09d116a0fb" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
