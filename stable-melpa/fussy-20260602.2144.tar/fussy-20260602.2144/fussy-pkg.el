;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260602.2144"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "8769483bf181f16cfdb336ccf8b18bdcf216f540"
  :revdesc "8769483bf181"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
