;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260504.1029"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "cfb304b04d9097b12825ab5e109f837f94ae7c37"
  :revdesc "cfb304b04d90"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
