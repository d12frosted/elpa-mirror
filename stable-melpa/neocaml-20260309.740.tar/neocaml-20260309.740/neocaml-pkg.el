;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260309.740"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "a19f1939d857c5c24979e84e877cd3651d9c3c45"
  :revdesc "a19f1939d857"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
