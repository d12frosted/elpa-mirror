(define-package "call-graph" "20210724.1106" "Library to generate call graph for c/c++ functions"
  '((emacs "25")
    (cl-lib "0.6.1")
    (hierarchy "0.7.0")
    (tree-mode "1.0.0")
    (ivy "0.10.0")
    (anaconda-mode "0.1.13"))
  :commit "f2e1116e48e46b6058319fe00997ef0bf2783352" :authors
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainer
  '("Huming Chen" . "chenhuming@gmail.com")
  :keywords
  '("programming" "convenience")
  :url "https://github.com/beacoder/call-graph")
;; Local Variables:
;; no-byte-compile: t
;; End:
