(define-package "dir-treeview" "20221027.110" "A directory tree browser and simple file manager"
  '((emacs "24.4")
    (treeview "1.1.1"))
  :commit "972a315f5718abdc5d3419f5591d1f0190f0998e" :authors
  '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainer
  '("Tilman Rassy" . "tilman.rassy@googlemail.com")
  :keywords
  '("tools" "convenience" "files")
  :url "https://github.com/tilmanrassy/emacs-dir-treeview")
;; Local Variables:
;; no-byte-compile: t
;; End:
