;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260203.447"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "d41a0d9ef7babee384c19f299e9d06852f3be8ad"
  :revdesc "d41a0d9ef7ba"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
