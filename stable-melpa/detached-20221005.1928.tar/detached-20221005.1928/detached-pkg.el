(define-package "detached" "20221005.1928" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "c2c2cc5d488cb5ac9b83621dfc50a1ec99391ec9" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
