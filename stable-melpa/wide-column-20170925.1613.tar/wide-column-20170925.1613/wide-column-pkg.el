;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wide-column" "20170925.1613"
  "Calls functions dependant on column position."
  ()
  :url "https://github.com/phillord/wide-column"
  :commit "ce9ef4675485a7bea381077866368ef875226b10"
  :revdesc "ce9ef4675485"
  :keywords '("minor mode" "cursor colour" "column width")
  :authors '(("Phillip Lord" . "p.lord@russet.org.uk"))
  :maintainers '(("Phillip Lord" . "p.lord@russet.org.uk")))
