;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code" "20260506.1909"
  "Run Claude Code sessions."
  '((emacs         "28.1")
    (projectile    "2.5.0")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (markdown-mode "2.5"))
  :url "https://github.com/yuya373/claude-code-emacs"
  :commit "176345f719a7227fef935d56d40dd50bf47597f6"
  :revdesc "176345f719a7"
  :keywords '("tools" "convenience"))
