(define-package "org-dp" "20180311.923" "Declarative Local Programming with Org Elements"
  '((cl-lib "0.5"))
  :commit "334fefd06eb925c86b1642787b2a088aa0932bab" :authors
  '(("Thorsten Jolitz <tjolitz AT gmail DOT com>"))
  :maintainer
  '("Thorsten Jolitz <tjolitz AT gmail DOT com>")
  :url "https://github.com/tj64/org-dp")
;; Local Variables:
;; no-byte-compile: t
;; End:
