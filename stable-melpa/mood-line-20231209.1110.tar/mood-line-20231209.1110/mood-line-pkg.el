(define-package "mood-line" "20231209.1110" "A minimal mode line inspired by doom-modeline"
  '((emacs "26.1"))
  :commit "10b5195f1b400d64d646f73a21bf5469612a375b" :authors
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainers
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainer
  '("Jessie Hildebrandt <jessieh.net>")
  :keywords
  '("mode-line" "faces")
  :url "https://gitlab.com/jessieh/mood-line")
;; Local Variables:
;; no-byte-compile: t
;; End:
