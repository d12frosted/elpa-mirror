;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260517.1941"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "370b32afaabcbe8948b986c7cea0d40aa192afda"
  :revdesc "370b32afaabc"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
