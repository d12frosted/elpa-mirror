(define-package "catppuccin-theme" "20221207.928" "Catppuccin Theme"
  '((emacs "25.1"))
  :commit "9d9339b649ea63888bc074605b03276f538ca074" :authors
  '(("pspiagicw"))
  :maintainer
  '("Name" . "namesexistsinemails@gmail.com")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
