;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260304.1607"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "da8a095551d564be48dd27f3abac476ef00631a9"
  :revdesc "da8a095551d5"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
