;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elcute" "20241115.1015"
  "Commands for marking and killing lines electrically."
  '((emacs "29.1"))
  :url "https://codeberg.org/vilij/slurpbarf-elcute"
  :commit "2d6d79c29cf2d791cc14f61e6e706bf4c8647176"
  :revdesc "2d6d79c29cf2"
  :keywords '("convenience"))
