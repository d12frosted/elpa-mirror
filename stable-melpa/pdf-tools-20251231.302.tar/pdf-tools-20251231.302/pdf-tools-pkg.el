;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdf-tools" "20251231.302"
  "Support library for PDF documents."
  '((emacs     "26.3")
    (tablist   "1.0")
    (let-alist "1.0.4"))
  :url "http://github.com/vedang/pdf-tools/"
  :commit "804d183c59c7804f94fab652658fa7d4c4fd6ca0"
  :revdesc "804d183c59c7"
  :keywords '("files" "multimedia")
  :authors '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainers '(("Vedang Manerikar" . "vedang.manerikar@gmail.com")))
