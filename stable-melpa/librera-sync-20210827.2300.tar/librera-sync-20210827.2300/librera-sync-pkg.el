(define-package "librera-sync" "20210827.2300" "Sync document's position with Librera Reader for Android"
  '((emacs "26.1")
    (f "0.17"))
  :commit "b6b97adc08c26b1595249e1c129793100f4ca26e" :authors
  '(("Dmitriy Pshonko" . "jumper047@gmail.com"))
  :maintainer
  '("Dmitriy Pshonko" . "jumper047@gmail.com")
  :keywords
  '("multimedia" "sync")
  :url "https://github.com/jumper047/librera-sync")
;; Local Variables:
;; no-byte-compile: t
;; End:
