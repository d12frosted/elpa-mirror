(define-package "ox-gfm" "20220910.1321" "Github Flavored Markdown Back-End for Org Export Engine" 'nil :commit "46faa67dbb3fb0cd7a76c3fe518f16e4195c22c7" :authors
  '(("Lars Tveito"))
  :maintainers
  '(("Lars Tveito"))
  :maintainer
  '("Lars Tveito")
  :keywords
  '("org" "wp" "markdown" "github"))
;; Local Variables:
;; no-byte-compile: t
;; End:
