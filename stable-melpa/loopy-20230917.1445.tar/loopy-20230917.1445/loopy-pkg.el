(define-package "loopy" "20230917.1445" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22")
    (compat "29.1.3"))
  :commit "311e9b7fabe18ed3fad6392b29897d4c58579159" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
