;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260504.1514"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "30e45edb782b5d8ee068ac6a85c49b1770396e74"
  :revdesc "30e45edb782b"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
