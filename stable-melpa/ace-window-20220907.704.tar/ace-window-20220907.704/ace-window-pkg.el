(define-package "ace-window" "20220907.704" "Quickly switch windows."
  '((avy "0.5.0"))
  :commit "aec8fd680aabd57170fc8181913f2cb6a8dbc68b" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("window" "location")
  :url "https://github.com/abo-abo/ace-window")
;; Local Variables:
;; no-byte-compile: t
;; End:
