;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250420.1925"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f7015e625fabb74b1ad20d1b6676c06c30058cac"
  :revdesc "f7015e625fab"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
