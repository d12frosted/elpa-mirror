;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260504.1546"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "4e6e594c5e00d2feedcf6e4e3abedc4327a4a91c"
  :revdesc "4e6e594c5e00"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
