(define-package "alarm-clock" "20221106.1409" "Alarm Clock"
  '((emacs "24.4"))
  :commit "01f43a74591c4b0de34804e126b671990c7360b4" :authors
  '(("Steve Lemuel" . "wlemuel@hotmail.com"))
  :maintainer
  '("Steve Lemuel" . "wlemuel@hotmail.com")
  :keywords
  '("calendar" "tools" "convenience")
  :url "https://github.com/wlemuel/alarm-clock")
;; Local Variables:
;; no-byte-compile: t
;; End:
