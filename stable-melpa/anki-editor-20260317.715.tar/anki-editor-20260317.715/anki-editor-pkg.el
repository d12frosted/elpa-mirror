;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anki-editor" "20260317.715"
  "Minor mode for making Anki cards with Org."
  '((emacs "29.1"))
  :url "https://github.com/anki-editor/anki-editor"
  :commit "982a9d141fe87b1378f6695c3804e30446cbeac2"
  :revdesc "982a9d141fe8")
