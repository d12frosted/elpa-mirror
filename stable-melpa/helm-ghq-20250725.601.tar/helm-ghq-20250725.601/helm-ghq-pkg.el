;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-ghq" "20250725.601"
  "Ghq with helm interface."
  '((emacs "24")
    (helm  "3.8.0"))
  :url "https://github.com/masutaka/emacs-helm-ghq"
  :commit "d321d7801f8ac1af885551a5be6d39e1562e7ee2"
  :revdesc "d321d7801f8a"
  :authors '(("Takashi Masuda" . "masutaka.net@gmail.com"))
  :maintainers '(("Takashi Masuda" . "masutaka.net@gmail.com")))
