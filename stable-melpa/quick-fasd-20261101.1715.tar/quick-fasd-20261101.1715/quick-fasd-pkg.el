;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20261101.1715"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "b7b24f884df970229b23caff959eebe2b75fca85"
  :revdesc "b7b24f884df9"
  :keywords '("convenience" "files" "tools"))
