;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "libmpdel" "20250611.805"
  "Communication with an MPD server."
  '((emacs "25.1"))
  :url "https://github.com/mpdel/libmpdel"
  :commit "6fc98552ea0864a9072beeac5cbc4d43d61925f2"
  :revdesc "6fc98552ea08"
  :keywords '("multimedia")
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
