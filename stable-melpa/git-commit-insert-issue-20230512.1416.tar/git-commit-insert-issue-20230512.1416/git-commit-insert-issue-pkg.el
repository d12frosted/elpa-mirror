;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-commit-insert-issue" "20230512.1416"
  "Get issues list when typing \"Fixes #\"."
  '((emacs      "25")
    (projectile "0")
    (s          "0")
    (ghub       "0")
    (bitbucket  "0"))
  :url "https://gitlab.com/emacs-stuff/git-commit-insert-issue/"
  :commit "df7ce0549d1db7bab27d401a351ea0d187c4a673"
  :revdesc "df7ce0549d1d"
  :keywords '("tools" "vc" "github" "gitlab" "bitbucket" "commit" "issues"))
