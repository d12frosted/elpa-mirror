(define-package "org-tag-beautify" "20231104.222" "Beautify Org mode tags"
  '((emacs "26.1")
    (nerd-icons "0.0.1"))
  :commit "581c86c9d2a803fa1eeb1b13432f4050c001aaa0" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-tag-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
