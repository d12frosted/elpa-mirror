(define-package "julia-mode" "20210824.747" "Major mode for editing Julia source code"
  '((emacs "24.3"))
  :commit "dc1794335bb584b5937e995d61ad4732f06dcd5a" :keywords
  '("languages")
  :url "https://github.com/JuliaEditorSupport/julia-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
