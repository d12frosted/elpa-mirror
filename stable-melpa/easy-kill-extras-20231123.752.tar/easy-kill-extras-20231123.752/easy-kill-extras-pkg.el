(define-package "easy-kill-extras" "20231123.752" "Extra functions for easy-kill."
  '((easy-kill "0.9.4"))
  :commit "e271915fe0a480954c1471d746e666ba2ea71d9f" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainers
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("killing" "convenience")
  :url "https://github.com/knu/easy-kill-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
