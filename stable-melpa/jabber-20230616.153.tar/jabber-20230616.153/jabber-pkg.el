(define-package "jabber" "20230616.153" "A Jabber client for Emacs."
  '((fsm "0.2")
    (srv "0.2"))
  :commit "b608552ad12dd7964f461982b7d4a2e2288d8da7")
;; Local Variables:
;; no-byte-compile: t
;; End:
