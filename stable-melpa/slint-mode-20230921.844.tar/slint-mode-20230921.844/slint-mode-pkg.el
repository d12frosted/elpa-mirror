(define-package "slint-mode" "20230921.844" "Major-mode for the Slint UI language"
  '((emacs "24.4")
    (lsp-mode "6.0"))
  :commit "795d9b07a20d3a7ffb09bb5271b42aa8ce68e4d0" :authors
  '(("Niklas Cathor" . "niklas.cathor@gmx.de"))
  :maintainers
  '(("Niklas Cathor" . "niklas.cathor@gmx.de"))
  :maintainer
  '("Niklas Cathor" . "niklas.cathor@gmx.de")
  :keywords
  '("languages")
  :url "https://github.com/nilclass/slint-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
