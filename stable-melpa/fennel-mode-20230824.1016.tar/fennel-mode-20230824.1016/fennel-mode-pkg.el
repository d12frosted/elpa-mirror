(define-package "fennel-mode" "20230824.1016" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "260ec80b9507d32ca2bda9aad55e9ed25b1927f4" :authors
  '(("Phil Hagelberg"))
  :maintainers
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://git.sr.ht/~technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
