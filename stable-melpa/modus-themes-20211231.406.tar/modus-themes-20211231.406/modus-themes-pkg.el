(define-package "modus-themes" "20211231.406" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "2d5ed2ff2965167a4c28b1623565629cf5208fc7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
