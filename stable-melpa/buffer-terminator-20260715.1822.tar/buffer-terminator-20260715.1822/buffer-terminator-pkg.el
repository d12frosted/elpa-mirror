;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260715.1822"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "68dbf7e34babe0467886132c641c54372d369acb"
  :revdesc "68dbf7e34bab"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
