;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260702.633"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "2554ce128652842078c8ccdc98e8fbec8ba7fb64"
  :revdesc "2554ce128652"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
