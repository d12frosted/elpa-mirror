;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-complete-exuberant-ctags" "20140320.724"
  "Exuberant ctags auto-complete.el source."
  '((auto-complete "1.4.0"))
  :url "http://code.101000lab.org"
  :commit "ff6121ff8b71beb5aa606d28fd389c484ed49765"
  :revdesc "ff6121ff8b71"
  :keywords '("anto-complete" "exuberant ctags")
  :authors '(("Kenichirou Oyama" . "k1lowxb@gmail.com"))
  :maintainers '(("Kenichirou Oyama" . "k1lowxb@gmail.com")))
