;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynaring" "20241126.202"
  "A dynamically sized ring structure."
  '((emacs "25.1"))
  :url "https://github.com/countvajhula/dynaring"
  :commit "61f7eef54f80c568e3a7c48f877d86776dd07fc6"
  :revdesc "61f7eef54f80"
  :authors '(("Mike Mattie" . "codermattie@gmail.com")
             ("Sid Kasivajhula" . "sid@countvajhula.com"))
  :maintainers '(("Sid Kasivajhula" . "sid@countvajhula.com")))
