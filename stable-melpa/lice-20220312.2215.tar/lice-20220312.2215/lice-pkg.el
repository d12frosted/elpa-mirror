(define-package "lice" "20220312.2215" "License And Header Template" 'nil :commit "0b69ba54057146f1473e85c0760029e584e3eb13" :authors
  '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainer
  '("Taiki Sugawara" . "buzz.taiki@gmail.com")
  :keywords
  '("template" "license" "tools")
  :url "https://github.com/buzztaiki/lice-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
