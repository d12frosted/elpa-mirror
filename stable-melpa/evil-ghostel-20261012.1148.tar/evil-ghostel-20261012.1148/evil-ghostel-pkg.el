;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20261012.1148"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "abaae8b3ba5501566a376d8b6f23c12fb6f55d2a"
  :revdesc "abaae8b3ba55"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
