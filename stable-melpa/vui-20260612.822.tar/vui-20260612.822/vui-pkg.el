;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260612.822"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "a3d4d3edc303cb8fd41556625a3482b2fa521f08"
  :revdesc "a3d4d3edc303"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
