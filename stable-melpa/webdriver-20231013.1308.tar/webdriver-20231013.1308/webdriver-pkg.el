(define-package "webdriver" "20231013.1308" "WebDriver local end implementation"
  '((emacs "27.1"))
  :commit "1c598fefbc2310c4add920c1da9f0c5bc1018372" :authors
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainers
  '(("Mauro Aranda" . "maurooaranda@gmail.com"))
  :maintainer
  '("Mauro Aranda" . "maurooaranda@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/mauroaranda/emacs-webdriver")
;; Local Variables:
;; no-byte-compile: t
;; End:
