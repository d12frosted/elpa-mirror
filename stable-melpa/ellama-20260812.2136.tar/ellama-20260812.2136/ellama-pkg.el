;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260812.2136"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.31.1")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "a86e9154ae88907d3de2710195810cda986ef0d8"
  :revdesc "a86e9154ae88"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
