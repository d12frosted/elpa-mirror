;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-bookmarks" "20251203.2059"
  "Add bookmark handling for notmuch buffers."
  '((seq     "2.20")
    (emacs   "26.1")
    (notmuch "0.29.3"))
  :url "https://github.com/publicimageltd/notmuch-bookmarks"
  :commit "11375003fc0a8440b7ff721b786a8eb4493af45f"
  :revdesc "11375003fc0a"
  :keywords '("mail")
  :authors '(("Jörg Volbers" . "joerg@joergvolbers.de"))
  :maintainers '(("Jörg Volbers" . "joerg@joergvolbers.de")))
