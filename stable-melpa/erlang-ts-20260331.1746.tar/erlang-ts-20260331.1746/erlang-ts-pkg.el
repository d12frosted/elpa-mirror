;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang-ts" "20260331.1746"
  "Major modes for editing Erlang."
  '((emacs  "29.2")
    (erlang "27.2"))
  :url "https://github.com/erlang/emacs-erlang-ts"
  :commit "7680c827adf17ad8b17ac94d56602c2b8645440a"
  :revdesc "7680c827adf1"
  :keywords '("erlang" "languages" "treesitter"))
