;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20260104.425"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "d766cb196c10230ac7d3ffe23a7a3fb8f4f4e32e"
  :revdesc "d766cb196c10"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
