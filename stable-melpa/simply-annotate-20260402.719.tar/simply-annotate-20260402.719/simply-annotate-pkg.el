;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260402.719"
  "Enhanced annotation system with threading."
  '((emacs "27.2"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "d9f9e69c1700c39cad744c64f051538a9986458b"
  :revdesc "d9f9e69c1700"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
