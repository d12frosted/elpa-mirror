(define-package "lacquer" "20210928.1043" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "53f78259023d7aa58045d63e74bab0279f2678fc" :authors
  '(("dingansich_kum0" . "zy.hua1122@outlook.com"))
  :maintainer
  '("dingansich_kum0" . "zy.hua1122@outlook.com")
  :keywords
  '("tools")
  :url "https://github.com/dingansichKum0/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
