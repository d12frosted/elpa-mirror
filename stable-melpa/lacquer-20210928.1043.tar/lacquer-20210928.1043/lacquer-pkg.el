(define-package "lacquer" "20210928.1043" "Switch theme/font by selecting from a cache"
  '((emacs "25.2"))
  :commit "18380ed840d85505cfa4b33ef6b553fb7297a48f" :authors
  '(("dingansich_kum0" . "zy.hua1122@outlook.com"))
  :maintainer
  '("dingansich_kum0" . "zy.hua1122@outlook.com")
  :keywords
  '("tools")
  :url "https://github.com/dingansichKum0/lacquer")
;; Local Variables:
;; no-byte-compile: t
;; End:
