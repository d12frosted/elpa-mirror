;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260527.1047"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "2dd5fd105c115fb7bafd657f5be99d417f3b9ad8"
  :revdesc "2dd5fd105c11"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
