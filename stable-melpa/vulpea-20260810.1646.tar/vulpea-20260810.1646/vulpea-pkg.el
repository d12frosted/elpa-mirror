;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260810.1646"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "7f23630a1f8136b0273daf9a16b109532c7c6381"
  :revdesc "7f23630a1f81"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
