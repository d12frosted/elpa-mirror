(define-package "elisp-autofmt" "20230102.215" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "65ff732193aa30de64556ba3a88ceb06c8c18d93" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
