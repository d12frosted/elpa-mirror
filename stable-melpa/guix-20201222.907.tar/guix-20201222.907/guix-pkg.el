(define-package "guix" "20201222.907" "Interface for GNU Guix"
  '((emacs "24.3")
    (dash "2.11.0")
    (geiser "0.8")
    (bui "1.2.0")
    (magit-popup "2.1.0")
    (edit-indirect "0.1.4"))
  :commit "bb2a0539f8d68b2292b3d0f3174c139b4c304028" :keywords
  ("tools")
  :authors
  (("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  ("Alex Kost" . "alezost@gmail.com")
  :url "https://emacs-guix.gitlab.io/website/")
;; Local Variables:
;; no-byte-compile: t
;; End:
