(define-package "syntactic-close" "20231216.1609" "Insert closing delimiter"
  '((emacs "24")
    (cl-lib "0.5"))
  :commit "395f3cf5f37b85bf7d7ce88fd58a0d0632414792" :keywords
  '("languages" "convenience")
  :url "https://github.com/emacs-berlin/syntactic-close")
;; Local Variables:
;; no-byte-compile: t
;; End:
