(define-package "srfi" "20210504.632" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "ce69158f5efb3040a00e89ffef0d1931e5038f53" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
