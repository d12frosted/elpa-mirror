;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20260316.2146"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "197f56bf7a38b564cc5dec26d66b5f494da39783"
  :revdesc "197f56bf7a38"
  :keywords '("languages"))
