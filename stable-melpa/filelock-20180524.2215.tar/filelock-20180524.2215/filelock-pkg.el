;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "filelock" "20180524.2215"
  "Functions for manipulating file locks."
  '((emacs  "24")
    (cl-lib "0")
    (f      "0"))
  :url "https://github.com/DarwinAwardWinner/emacs-filelock"
  :commit "17a5ca6e0dee14d2e7d92c84be91143bca9d9663"
  :revdesc "17a5ca6e0dee"
  :keywords '("extensions" "files" "tools"))
