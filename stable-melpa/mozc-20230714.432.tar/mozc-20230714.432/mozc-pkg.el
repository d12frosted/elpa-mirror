(define-package "mozc" "20230714.432" "minor mode to input Japanese with Mozc" 'nil :commit "f14a3f49cb56adb4386cb264133a01b32929dfb7" :keywords
  '("mule" "multilingual" "input method"))
;; Local Variables:
;; no-byte-compile: t
;; End:
