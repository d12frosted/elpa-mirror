(define-package "dirvish" "20220416.535" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e9a5ad5664a900659d8f15d0fd91785769c38282" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
