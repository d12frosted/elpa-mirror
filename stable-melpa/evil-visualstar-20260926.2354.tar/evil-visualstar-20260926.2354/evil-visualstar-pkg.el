;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-visualstar" "20260926.2354"
  "Starts a * or # search from the visual selection."
  '((emacs "24.4")
    (evil  "0"))
  :url "https://github.com/bling/evil-visualstar"
  :commit "1584f0c4842dbdf67fc9414a59ac0375f2a00a3c"
  :revdesc "1584f0c4842d"
  :keywords '("evil" "vim" "visualstar"))
