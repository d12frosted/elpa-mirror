;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260224.1133"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.1.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "f365e87b801b47306a39fabbbf4405d9355b8458"
  :revdesc "f365e87b801b"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
