;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20250628.342"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1")
    (mozc           "0"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "aaed807e08f50888b215adff98d4c1ee28f8fd7e"
  :revdesc "aaed807e08f5"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
