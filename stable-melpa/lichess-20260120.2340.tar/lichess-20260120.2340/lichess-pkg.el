;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "20260120.2340"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "a4e8fcaf03e91367fe512ba95c203528eb8b5684"
  :revdesc "a4e8fcaf03e9"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
