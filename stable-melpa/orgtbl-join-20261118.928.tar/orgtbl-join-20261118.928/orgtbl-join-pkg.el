;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20261118.928"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "0582e954b45d0d23301a5a102e65063d3cc418d6"
  :revdesc "0582e954b45d"
  :keywords '("data" "extensions"))
