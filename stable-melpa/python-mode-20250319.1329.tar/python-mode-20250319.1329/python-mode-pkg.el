;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250319.1329"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "e6785d015046e298f4bc19e70777b12b88516bcb"
  :revdesc "e6785d015046"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
