;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stripspace" "20260715.1824"
  "Auto remove trailing whitespace and restore column."
  '((emacs "24.3"))
  :url "https://github.com/jamescherti/stripspace.el"
  :commit "35e6e86195a1192822ed13090b60426d4a768d95"
  :revdesc "35e6e86195a1"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
