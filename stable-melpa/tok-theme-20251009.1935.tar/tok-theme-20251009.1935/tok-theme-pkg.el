;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tok-theme" "20251009.1935"
  "Minimal monochromatic theme with restrained color highlights."
  '((emacs "27.0"))
  :url "https://github.com/topikettunen/tok-theme"
  :commit "62d0b1e93911049d29d315e1c415db249a2142cd"
  :revdesc "62d0b1e93911"
  :authors '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainers '(("Topi Kettunen" . "topi@topikettunen.com")))
