(define-package "gnuplot" "20201212.1946" "Major-mode and interactive frontend for gnuplot"
  '((emacs "24.3"))
  :commit "62117fe6f0010e7dbe0b31e9ab6b82c01bae1e95" :keywords
  ("data" "gnuplot" "plotting")
  :authors
  (("Jon Oddie")
   ("Bruce Ravel")
   ("Phil Type"))
  :maintainer
  ("Bruce Ravel" . "bruceravel1@gmail.com")
  :url "https://github.com/emacsorphanage/gnuplot")
;; Local Variables:
;; no-byte-compile: t
;; End:
