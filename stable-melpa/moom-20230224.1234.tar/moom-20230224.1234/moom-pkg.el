(define-package "moom" "20230224.1234" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "864bee4e121771a055fab2b9f3e53cb3b8a8e02a" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
