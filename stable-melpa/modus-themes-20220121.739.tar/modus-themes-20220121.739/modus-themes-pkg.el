(define-package "modus-themes" "20220121.739" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "445b60525f3d9853fc5ed94f613956adc4519f49" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
