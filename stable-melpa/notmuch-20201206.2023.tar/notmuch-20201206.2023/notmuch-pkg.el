(define-package "notmuch" "20201206.2023" "run notmuch within emacs" 'nil :commit "06a629826208358dc6448986a47423124d7e0479" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
