(define-package "notmuch" "20201206.2023" "run notmuch within emacs" 'nil :commit "adfded9ed0a5a4b06886f462314cd4511cb72d47" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
