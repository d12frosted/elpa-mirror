(define-package "notmuch" "20201206.2023" "run notmuch within emacs" 'nil :commit "ced341e82e8cb84dc2c90187d208838335511f6e" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
