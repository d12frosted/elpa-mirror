;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260322.1411"
  "Highlight window and cursor at switching."
  '((emacs "25.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "be44b9b41402d7beaf56fe3aef27fe3f0f54910c"
  :revdesc "be44b9b41402"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
