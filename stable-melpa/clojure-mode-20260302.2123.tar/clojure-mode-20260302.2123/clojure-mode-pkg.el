;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260302.2123"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "22616ac12d5893fcf270e903a58d34c365156ea1"
  :revdesc "22616ac12d58"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
