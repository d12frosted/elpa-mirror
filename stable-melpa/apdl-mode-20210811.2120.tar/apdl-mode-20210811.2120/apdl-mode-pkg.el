(define-package "apdl-mode" "20210811.2120" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "4da7c47e0499c157e6952d1b2f261208f992dfbd" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
