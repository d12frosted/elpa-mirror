(define-package "chronometrist-key-values" "20210617.1707" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "8838d409b0fbce52e1317ff5c229a0ee8d74ecd1" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
