;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "greger" "20250630.2048"
  "Agentic coding environment with tool use, using Claude."
  '((emacs "29.1"))
  :url "https://github.com/andreasjansson/greger.el"
  :commit "48256f127043dd7e78a4bff3d5fe1b477a929fd6"
  :revdesc "48256f127043"
  :keywords '("agent" "agentic" "ai" "chat" "language-models" "tools")
  :authors '(("Andreas Jansson" . "andreas@jansson.me.uk"))
  :maintainers '(("Andreas Jansson" . "andreas@jansson.me.uk")))
