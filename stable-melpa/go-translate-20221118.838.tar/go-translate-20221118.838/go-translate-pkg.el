(define-package "go-translate" "20221118.838" "Translation framework supports multiple engines such as Google/Bing/DeepL"
  '((emacs "27.1"))
  :commit "b6260aa10941ed893bbe1798edcc34dde22ca529" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
