;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cpu-sos" "20200409.2356"
  "S.O.S. from a CPU in distress."
  '((emacs "25.1"))
  :url "https://github.com/oitofelix/cpu-sos"
  :commit "1594b76d4ad3a6e3c471d82da366226d156e6226"
  :revdesc "1594b76d4ad3"
  :keywords '("processes")
  :authors '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org"))
  :maintainers '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org")))
