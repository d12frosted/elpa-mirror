;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent-harness" "20260826.1001"
  "Autonomous coding-agent harness for gptel-agent."
  '((emacs       "29.1")
    (compat      "30.1.0.0")
    (gptel       "0.9.9")
    (gptel-agent "0.0.1"))
  :url "https://github.com/beacoder/gptel-agent-harness"
  :commit "56f53ece82d48a87c192476b273b21eeba1d26ce"
  :revdesc "56f53ece82d4"
  :keywords '("programming" "convenience" "ai" "agent")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
