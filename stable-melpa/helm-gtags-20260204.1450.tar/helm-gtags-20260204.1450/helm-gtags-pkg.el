;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-gtags" "20260204.1450"
  "GNU GLOBAL helm interface."
  '((emacs "27.1")
    (helm  "3.0"))
  :url "https://github.com/syohex/emacs-helm-gtags"
  :commit "93371709d0265baf85bc649f096c0e532a0c2dd8"
  :revdesc "93371709d026"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
