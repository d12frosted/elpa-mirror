(define-package "w3m" "20220508.2259" "an Emacs interface to w3m" 'nil :commit "bbcebbe20ebfa807a3e4beaadf40ce6f4be213e7" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
