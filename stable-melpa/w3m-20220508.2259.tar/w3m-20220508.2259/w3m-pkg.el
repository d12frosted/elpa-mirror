(define-package "w3m" "20220508.2259" "an Emacs interface to w3m" 'nil :commit "9422b583d0113ccc699618d0e475d3dbd5a49170" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
