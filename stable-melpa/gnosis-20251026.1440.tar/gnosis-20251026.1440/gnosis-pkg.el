;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20251026.1440"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "7a41e6c44d27fce0ef81a2e8d32e24e121d99248"
  :revdesc "7a41e6c44d27"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
