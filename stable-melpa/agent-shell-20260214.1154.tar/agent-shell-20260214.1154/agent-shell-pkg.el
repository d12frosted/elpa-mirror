;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260214.1154"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "3be56ea888b10fa710df00f69fad4042696db252"
  :revdesc "3be56ea888b1")
