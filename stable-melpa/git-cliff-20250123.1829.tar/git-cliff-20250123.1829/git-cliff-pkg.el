;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-cliff" "20250123.1829"
  "Generate and update changelog using git-cliff."
  '((emacs     "29.1")
    (transient "0.6.0")
    (dash      "2.19.1"))
  :url "https://github.com/eki3z/git-cliff.el"
  :commit "e2bb130a7fa35b47bd90d43af0c17d3bf6ea655b"
  :revdesc "e2bb130a7fa3"
  :keywords '("tools")
  :authors '(("Eki Zhang" . "liuyinz95@gmail.com"))
  :maintainers '(("Eki Zhang" . "liuyinz95@gmail.com")))
