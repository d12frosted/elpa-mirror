(define-package "elixir-mode" "20211005.1542" "Major mode for editing Elixir files"
  '((emacs "25"))
  :commit "e44d5bfd68d735c4d93df9d2ae8e78ed9cb52d31" :keywords
  '("languages" "elixir")
  :url "https://github.com/elixir-editors/emacs-elixir")
;; Local Variables:
;; no-byte-compile: t
;; End:
