;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260921.1352"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "de5b6be5213fa8ea83808f69ccd42faf98105516"
  :revdesc "de5b6be5213f"
  :keywords '("languages"))
