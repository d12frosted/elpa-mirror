(define-package "elcord" "20230203.101" "Allows you to integrate Rich Presence from Discord"
  '((emacs "25.1"))
  :commit "43ae6c375811754e640b0bae4678bf33e72988e9" :authors
  '(("heatingdevice")
    ("Wilfredo Velázquez-Rodríguez" . "zulu.inuoe@gmail.com"))
  :maintainer
  '("heatingdevice")
  :keywords
  '("games")
  :url "https://github.com/Mstrodl/elcord")
;; Local Variables:
;; no-byte-compile: t
;; End:
