;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260706.944"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (compat      "31.0.0.0")
    (shell-maker "0.93.3")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "4f05fcf13f0c5a8116f11d7763e2ad96bd54f88a"
  :revdesc "4f05fcf13f0c")
