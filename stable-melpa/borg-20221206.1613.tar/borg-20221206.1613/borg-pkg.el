(define-package "borg" "20221206.1613" "Assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "4930f349d902889522a3f9b5ba582bf23c895277" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
