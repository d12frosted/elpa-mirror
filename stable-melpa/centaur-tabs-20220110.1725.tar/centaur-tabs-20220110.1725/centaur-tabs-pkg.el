(define-package "centaur-tabs" "20220110.1725" "Aesthetic, modern looking customizable tabs plugin"
  '((emacs "24.4")
    (powerline "2.4")
    (cl-lib "0.5"))
  :commit "8b21f429591c52cfbd663d1516e6ac7ebce07654" :authors
  '(("Emmanuel Bustos" . "ema2159@gmail.com"))
  :maintainer
  '("Emmanuel Bustos" . "ema2159@gmail.com")
  :url "https://github.com/ema2159/centaur-tabs")
;; Local Variables:
;; no-byte-compile: t
;; End:
