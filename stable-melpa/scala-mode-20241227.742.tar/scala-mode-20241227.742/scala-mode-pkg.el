;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scala-mode" "20241227.742"
  "Major mode for editing Scala."
  '((emacs "24.2"))
  :url "https://github.com/hvesalai/emacs-scala-mode"
  :commit "8c224580754762a8e7af7fe58bd41a29b5645b18"
  :revdesc "8c2245807547"
  :keywords '("languages"))
