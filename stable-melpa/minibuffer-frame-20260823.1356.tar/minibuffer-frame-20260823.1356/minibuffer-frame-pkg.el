;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuffer-frame" "20260823.1356"
  "Minibuffer in centered child frame."
  '((emacs "28.1"))
  :url "https://github.com/zHaOdANiuu/minibuffer-frame"
  :commit "69bb3b62b74e6272ed350284d591f2b28e1b8269"
  :revdesc "69bb3b62b74e"
  :keywords '("convenience" "minibuffer" "child-frame")
  :authors '(("Daniu Zhao" . "zhaodaniu1@gmail.com"))
  :maintainers '(("Daniu Zhao" . "zhaodaniu1@gmail.com")))
