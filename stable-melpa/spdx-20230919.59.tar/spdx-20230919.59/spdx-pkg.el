(define-package "spdx" "20230919.59" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "7a509494e834d4fda41f6e4e5c4c5ac97aef5ec8" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
