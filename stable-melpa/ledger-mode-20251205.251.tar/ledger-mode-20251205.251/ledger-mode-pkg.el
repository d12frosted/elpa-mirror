;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "20251205.251"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "1c77506d995be0d0e2ee8d113104e9a0874b8163"
  :revdesc "1c77506d995b")
