(define-package "dwim-shell-command" "20221113.904" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "b98f45c7901446cf1ab60be2ab648c623e774427" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
