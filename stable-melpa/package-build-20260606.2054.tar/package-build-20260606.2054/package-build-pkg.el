;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260606.2054"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "31.0"))
  :url "https://github.com/melpa/package-build"
  :commit "9bbffb87dfa1b5dcf55236003ef4b3a6eec159e7"
  :revdesc "9bbffb87dfa1"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
