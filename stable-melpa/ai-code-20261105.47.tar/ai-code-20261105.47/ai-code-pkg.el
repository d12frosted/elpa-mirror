;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261105.47"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e5f1c76d4dc22b54f4c331f7ab9e7c023b804f23"
  :revdesc "e5f1c76d4dc2"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
