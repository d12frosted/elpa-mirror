(define-package "jsdoc" "20240916.1846" "Insert JSDoc comments"
  '((emacs "29.1")
    (dash "2.11.0")
    (s "1.12.0"))
  :commit "36d750448eedad47f9f9d2cfd422e5992d6322e3" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/jsdoc.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
