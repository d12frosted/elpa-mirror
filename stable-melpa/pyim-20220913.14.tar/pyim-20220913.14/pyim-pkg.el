(define-package "pyim" "20220913.14" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "25.1")
    (async "1.6")
    (xr "1.13"))
  :commit "3263ac79fa5a6521b692256458a98f8ffc95dc06" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
