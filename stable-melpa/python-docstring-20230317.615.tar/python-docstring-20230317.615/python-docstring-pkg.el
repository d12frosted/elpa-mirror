(define-package "python-docstring" "20230317.615" "Smart Python docstring formatting" 'nil :commit "a1deba56a9cc5dd9ef9c303e95b1b0dedfbc0fb8")
;; Local Variables:
;; no-byte-compile: t
;; End:
