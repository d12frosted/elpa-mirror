;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kubel" "20260217.1416"
  "Control Kubernetes with limited permissions."
  '((transient "0.1.0")
    (emacs     "25.3")
    (dash      "2.12.0")
    (s         "1.2.0")
    (yaml-mode "0.0.14"))
  :url "https://github.com/abrochard/kubel"
  :commit "28b5bbf1a0263440af5a14977ffda06013f50e4c"
  :revdesc "28b5bbf1a026"
  :keywords '("kubernetes" "k8s" "tools" "processes"))
