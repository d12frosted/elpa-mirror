;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnomenm" "20150316.1918"
  "Emacs interface to Gnome nmcli command."
  '((s    "1.9.0")
    (dash "2.3.0")
    (kv   "0.0.19"))
  :url "https://github.com/nicferrier/emacs-nm"
  :commit "9065cda44ffc9e06239b8189a0154d31314c3b4d"
  :revdesc "9065cda44ffc"
  :keywords '("processes" "hardware")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
