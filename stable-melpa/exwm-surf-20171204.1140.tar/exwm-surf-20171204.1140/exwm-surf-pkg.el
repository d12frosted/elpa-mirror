;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-surf" "20171204.1140"
  "Interface for Surf (surf.suckless.org) under exwm."
  '((emacs "24.4")
    (exwm  "0.16"))
  :url "https://github.com/ecraven/exwm-surf"
  :commit "6c17e2c1597fe4b7b454a1dac23b9127ac951e94"
  :revdesc "6c17e2c1597f"
  :keywords '("extensions")
  :authors '(("Peter" . "craven@gmx.net"))
  :maintainers '(("Peter" . "craven@gmx.net")))
