(define-package "tree-sitter" "20210831.1217" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.15.1"))
  :commit "0ffa20aa2e8c8633cc23f25196b7329941b5c2c0" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/emacs-tree-sitter/elisp-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
