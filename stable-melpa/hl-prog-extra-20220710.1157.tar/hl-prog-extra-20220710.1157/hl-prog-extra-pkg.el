(define-package "hl-prog-extra" "20220710.1157" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "286a4916ad4dd764ead07fb17000ad64cbcf11bd" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
