(define-package "shimbun" "20231023.653" "interfacing with web newspapers" 'nil :commit "55baf2bcb1a583d3baae1d37ad0e17b0480ffd02" :authors
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
    ("Akihiro Arisawa   " . "ari@mbf.sphere.ne.jp")
    ("Yuuichi Teranishi " . "teranisi@gohome.org")
    ("Katsumi Yamaoka   " . "yamaoka@jpl.org"))
  :maintainers
  '(("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org"))
  :maintainer
  '("TSUCHIYA Masatoshi" . "tsuchiya@namazu.org")
  :keywords
  '("news"))
;; Local Variables:
;; no-byte-compile: t
;; End:
