;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20260125.1927"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "affe8f8068a595edb30a3ef58245742dc77d6edc"
  :revdesc "affe8f8068a5"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
