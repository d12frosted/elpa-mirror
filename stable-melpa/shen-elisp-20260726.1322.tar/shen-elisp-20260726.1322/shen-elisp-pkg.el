;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shen-elisp" "20260726.1322"
  "An implementation of the Shen programming language."
  '((emacs "24.4"))
  :url "https://github.com/deech/shen-elisp"
  :commit "0a58aca68c40c2a38b5634d7fe66829f88d44386"
  :revdesc "0a58aca68c40"
  :keywords '("shen" "elisp")
  :authors '(("Aditya Siram" . "aditya.siram@gmail.com"))
  :maintainers '(("Aditya Siram" . "aditya.siram@gmail.com")))
