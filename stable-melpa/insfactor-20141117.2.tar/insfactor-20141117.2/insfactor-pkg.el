;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "insfactor" "20141117.2"
  "Client for a Clojure project with insfactor in it."
  ()
  :url "https://github.com/duelinmarkers/insfactor.el"
  :commit "7ef5446cebb08a17d4106d2e6f3c053e49e1e829"
  :revdesc "7ef5446cebb0"
  :keywords '("clojure")
  :authors '(("John D. Hume" . "duelin.markers@gmail.com"))
  :maintainers '(("John D. Hume" . "duelin.markers@gmail.com")))
