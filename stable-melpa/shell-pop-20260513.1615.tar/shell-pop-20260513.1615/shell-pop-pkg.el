;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260513.1615"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "623a97bd9f9440d15a8d4bf3c64fa23fcd68042c"
  :revdesc "623a97bd9f94"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
