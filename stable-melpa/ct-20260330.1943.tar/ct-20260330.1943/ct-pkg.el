;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ct" "20260330.1943"
  "Color Tools - a color api."
  '((emacs "26.1")
    (dash  "2.18.0")
    (hsluv "1.0.0"))
  :url "https://github.com/neeasade/ct.el"
  :commit "d47271cc1b5ef55cf74a3e25ac45a187b36910d5"
  :revdesc "d47271cc1b5e"
  :keywords '("convenience" "color" "theming" "rgb" "hsv" "hsl" "lab" "oklab" "background"))
