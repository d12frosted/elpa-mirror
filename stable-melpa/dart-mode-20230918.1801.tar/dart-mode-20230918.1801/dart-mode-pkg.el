(define-package "dart-mode" "20230918.1801" "Major mode for editing Dart files"
  '((emacs "26.3"))
  :commit "2cb4dabe5c404b97d70febfdfdc1dcba76b6feee" :authors
  '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers
  '(("Brady Trainor"))
  :maintainer
  '("Brady Trainor")
  :keywords
  '("languages")
  :url "https://github.com/emacsorphanage/dart-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
