(define-package "kmacro-x" "20230303.1741" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "757c582cba626afbf82a25d069eff4f7abd122c6" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
