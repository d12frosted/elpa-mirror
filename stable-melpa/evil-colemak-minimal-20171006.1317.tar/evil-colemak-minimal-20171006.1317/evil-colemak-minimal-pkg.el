;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-colemak-minimal" "20171006.1317"
  "Minimal Colemak key bindings for evil-mode."
  '((emacs "24")
    (evil  "1.2.12"))
  :url "https://github.com/bmallred/evil-colemak-minimal"
  :commit "6d98b6da60f414524a0d718f76024c26dce742b3"
  :revdesc "6d98b6da60f4"
  :keywords '("colemak" "evil")
  :authors '(("Bryan Allred" . "bryan@revolvingcow.com"))
  :maintainers '(("Bryan Allred" . "bryan@revolvingcow.com")))
