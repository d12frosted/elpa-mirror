(define-package "pillar" "20141112.1811" "Major mode for editing Pillar files"
  '((makey "0.3"))
  :commit "13a7f676544cc66005ccd8e6fc1c25e4ccd6f909" :authors
  '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainer
  '("Damien Cassou" . "damien.cassou@gmail.com")
  :keywords
  '("markup" "major-mode")
  :url "http://github.com/DamienCassou/pillar-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
