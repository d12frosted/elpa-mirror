;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hmac" "20201004.1819"
  "Hash-based message authentication code."
  '((emacs "25.1"))
  :url "https://github.com/grimnebulin/emacs-hmac"
  :commit "f2b99a9a10becfff207cf9418c6dce78364b1a4b"
  :revdesc "f2b99a9a10be")
