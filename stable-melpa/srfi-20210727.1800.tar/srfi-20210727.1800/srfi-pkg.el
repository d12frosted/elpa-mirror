(define-package "srfi" "20210727.1800" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "70935753de73724f338700725462dec2cfda90f7" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
