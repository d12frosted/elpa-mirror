(define-package "helm-ls-git" "20230819.1409" "list git files."
  '((helm "1.7.8"))
  :commit "d48113dd727073d99c2dc4ac39d5daf1676133e5")
;; Local Variables:
;; no-byte-compile: t
;; End:
