(define-package "cool-mode" "20220612.1904" "Major mode for cool compiler language"
  '((emacs "25"))
  :commit "8b2f5d0f7d821599ef4ab99c5ba42d55cd04168d" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :url "https://github.com/nverno/cool-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
