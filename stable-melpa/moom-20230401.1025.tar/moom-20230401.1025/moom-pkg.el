(define-package "moom" "20230401.1025" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "c7f319c29e5740b03910e75e89bfb2379d4ed680" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainers
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
