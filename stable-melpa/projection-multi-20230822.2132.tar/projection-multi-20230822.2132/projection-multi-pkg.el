(define-package "projection-multi" "20230822.2132" "Projection integration for `compile-multi'"
  '((emacs "29")
    (projection "0.1")
    (compile-multi "0.5"))
  :commit "d043418c707d5637d869c488e8abe2186e55b5fe" :authors
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@kisara.moe")
  :keywords
  '("project" "convenience")
  :url "https://github.com/mohkale/projection")
;; Local Variables:
;; no-byte-compile: t
;; End:
