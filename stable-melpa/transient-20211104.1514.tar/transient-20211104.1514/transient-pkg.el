(define-package "transient" "20211104.1514" "Transient commands"
  '((emacs "25.1"))
  :commit "fa523dee70f2242efeb49148ceb9e71a2202de97" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("bindings")
  :url "https://github.com/magit/transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
