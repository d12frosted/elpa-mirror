;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-editor" "20261002.2059"
  "Use the Emacsclient as $EDITOR."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0"))
  :url "https://github.com/magit/with-editor"
  :commit "b9163645d8ae44065cd7fee09a7ee8eb0c372592"
  :revdesc "b9163645d8ae"
  :keywords '("processes" "terminals")
  :authors '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.with-editor@jonas.bernoulli.dev")))
