;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "adoc-mode" "20260220.1619"
  "A major-mode for editing AsciiDoc files."
  '((emacs "28.1"))
  :url "https://github.com/bbatsov/adoc-mode"
  :commit "85532b60322c838af6e6bfcb099c5d4ef31834ac"
  :revdesc "85532b60322c"
  :keywords '("docs" "wp")
  :authors '(("Florian Kaufmann" . "sensorflo@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
