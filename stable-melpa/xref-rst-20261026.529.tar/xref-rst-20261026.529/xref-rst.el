;;; xref-rst.el --- Lookup reStructuredText symbols -*- lexical-binding: t -*-

;; SPDX-License-Identifier: GPL-2.0-or-later
;; Copyright (C) 2020  Campbell Barton

;; Author: Campbell Barton <ideasman42@gmail.com>

;; URL: https://codeberg.org/ideasman42/emacs-xref-rst
;; Package-Version: 20261026.529
;; Package-Revision: 41aa52e73d33
;; Package-Requires: ((emacs "29.1"))

;;; Commentary:

;; This package provides functions to lookup symbols under the cursor using xref.
;; Supported types include "doc", "ref", "term", hyperlink references (to titles & targets)
;; and file-paths (typically used in an index).

;;; Usage:

;; ;; Enable the Xref back-end in RST mode.
;; (add-hook 'rst-mode-hook
;;   (lambda ()
;;     (xref-rst-mode)))

;;; Code:


(require 'subr-x) ; For `string-trim', `string-join', `string-blank-p'.
(require 'thingatpt) ; For `thing-at-point-looking-at'.
(require 'vc) ; For `vc-responsible-backend' and `vc-call-backend'.
(require 'xref) ; For `xref' integration.
(require 'map) ; For `map-elt'.


;; ---------------------------------------------------------------------------
;; Custom Variables

(defgroup xref-rst nil
  "Cross-reference (XREF) support for reStructuredText."
  :group 'xref)

;; Most uses should convert into a REGEX using `xref-rst--file-match-regex'
(defcustom xref-rst-extensions '(".rst" ".txt")
  "Extensions (must include the period character before the extension)."
  :type '(repeat string))

;; We must match last or second last groups here, annoying,
;; but I'm not sure there is a good way around this.
(defconst xref-rst--regex-any-role-data
  (concat
   ":\\([a-zA-Z0-9_]+\\):`"
   ;; Start group, only for "OR".
   "\\(?:"
   ;; With brackets.
   "[^<`\n]*<\\([^>\n]+\\)>"
   ;; Or...
   "\\|"
   ;; Without brackets.
   "\\([^`\n]+\\)"
   ;; End non-matching group.
   "\\)`"))


(defconst xref-rst--regex-ref-declare
  (concat
   ;; Prefix.
   "\\(^[[:blank:]]*\\.\\.[[:blank:]]+_\\)"
   ;; Reference ID.
   "\\([a-zA-Z0-9_.\\-]+\\)"
   ;; End.
   ":"))

(defconst xref-rst--regex-glossary-directive
  (concat
   ;; White space prefix.
   "\\(^[[:blank:]]*\\)"
   ;; Prefix.
   "\\.\\.[[:blank:]]+"
   ;; Reference ID.
   "glossary"
   ;; End.
   "::"))

;; NOTE: quoted section names in comments refer to the reStructuredText specification, see:
;; https://docutils.sourceforge.io/docs/ref/rst/restructuredtext.html

;; Unlike `xref-rst--regex-ref-declare', names may contain spaces (used by hyperlink references).
;; See: "Hyperlink Targets".
;; Group 1 is the target name (for either form).
(defconst xref-rst--regex-hyperlink-target
  (concat
   ;; Prefix.
   "^[[:blank:]]*\\.\\.[[:blank:]]+_"
   ;; Start group, only for "OR".
   "\\(?:"
   ;; Back-quoted, may contain colons (can't begin with white-space).
   "`\\(?1:[^`[:blank:]\n][^`\n]*\\)`"
   ;; Or...
   "\\|"
   ;; Without back-quotes, colons must be escaped.
   "\\(?1:"
   ;; First character, an escape or anything besides white-space
   ;; or an underscore (used for anonymous targets).
   "\\(?:\\\\.\\|[^\\\\:`_[:blank:]\n]\\)"
   ;; Remaining characters, escapes or anything besides a colon.
   "\\(?:\\\\.\\|[^\\\\:`\n]\\)*"
   ;; End group.
   "\\)"
   ;; End non-matching group.
   "\\)"
   ;; End.
   ":\\(?:[[:blank:]]\\|$\\)"))

;; Group 1 is the reference (including back-ticks), group 2 is the reference text.
;; Anonymous references (ending with two underscores) must be excluded by the caller.
(defconst xref-rst--regex-hyperlink-ref
  (concat
   ;; Can't follow a word character, a looser version of the start-string rule
   ;; (see: "Inline markup recognition rules"),
   ;; without this a match could begin at the closing back-tick of a previous reference.
   ;; NOTE: `^' also matches the start of a string, this is needed so the identifier
   ;; can be matched as a whole (see `xref-rst--find-definitions-impl').
   "\\(?:^\\|[^[:alnum:]`\\_]\\)"
   ;; Start the reference group.
   "\\(?1:`"
   ;; Reference text, may wrap onto the next line but not past a blank line.
   "\\(?2:\\(?:[^`\n]\\|\n[[:blank:]]*[^`[:blank:]\n]\\)+\\)"
   ;; End.
   "`_\\)"))

;; Group 1 is the escaped character (unset for escaped white-space, which is removed).
;; See: "Escaping Mechanism".
(defconst xref-rst--regex-escape
  (concat
   ;; Backslash.
   "\\\\"
   ;; Start group, only for "OR".
   "\\(?:"
   ;; Escaped white-space.
   "[ \t]"
   ;; Or...
   "\\|"
   ;; Escaped line break & the following indentation.
   "\n[[:blank:]]*"
   ;; Or...
   "\\|"
   ;; Any other character.
   "\\(.\\)"
   ;; End non-matching group.
   "\\)"))

;; Strong & emphasis, group 1 is the text (escapes are not removed).
(defconst xref-rst--regex-emphasis
  (concat
   ;; Opening asterisks.
   "\\*\\{1,2\\}"
   ;; Start the text group.
   "\\("
   ;; First character, an escape or anything besides white-space or an asterisk.
   "\\(?:\\\\.\\|[^\\\\*[:blank:]]\\)"
   ;; Remaining characters, escapes or anything besides an asterisk,
   ;; ending with an escape or anything besides white-space or an asterisk.
   "\\(?:\\(?:\\\\.\\|[^\\\\*]\\)*\\(?:\\\\.\\|[^\\\\*[:blank:]]\\)\\)?"
   ;; End the text group.
   "\\)"
   ;; Closing asterisks.
   "\\*\\{1,2\\}"))

;; Inline markup removed from section titles, see `xref-rst--section-title-ref-name'.
;; Group 1 is the emphasis text, group 2 is the literal text (neither are set for escapes).
(defconst xref-rst--regex-title-markup
  (concat
   ;; Escape.
   "\\\\."
   ;; Or...
   "\\|"
   ;; Strong & emphasis (group 1).
   xref-rst--regex-emphasis
   ;; Or...
   "\\|"
   ;; Inline literal.
   "``\\(?2:[^`]+\\)``"))

;; Matches the section adornment pattern used by docutils.
;; See: "Sections".
(defconst xref-rst--regex-section-adornment
  (concat
   ;; Any 7-bit non-alphanumeric character.
   "^\\([!-/:-@[-`{-~]\\)"
   ;; Repeated.
   "\\1*"
   ;; Trailing white-space.
   "[[:blank:]]*$"))


;; ---------------------------------------------------------------------------
;; Internal Functions (Generic)

(defun xref-rst--range-of-block-at-current-indent (pos)
  "Return the beginning/end point of lines at the indentation level of POS."
  (declare (important-return-value t))
  (let ((beg nil)
        (end nil))
    (save-excursion
      (goto-char pos)
      (back-to-indentation)
      (let ((col (current-column)))
        (dolist (dir (list -1 1))
          (let ((last-pos pos))
            (while (and (zerop (forward-line dir))
                        (progn
                          (back-to-indentation)
                          (eq col (current-column))))
              (setq last-pos (point)))
            (goto-char last-pos)
            (cond
             ((< dir 0)
              (setq beg (pos-bol)))
             (t
              (setq end (pos-eol))))))))
    (cons beg end)))

(defun xref-rst--find-next-indent-level-as-string (pos pos-end)
  "Find the next indent level at POS, that does not exceed POS-END.

Return the blank text representing the indentation or nil if none is found."
  (declare (important-return-value t))
  (save-excursion
    (goto-char pos)
    (back-to-indentation)
    (let ((first-indent (current-column))
          (result nil))

      ;; Scan forward lines until we hit the next indentation level.
      (while (and (null result)
                  ;; Stop when we hit the end of the buffer.
                  (zerop (forward-line 1))
                  ;; Don't read past this point.
                  (< (point) pos-end))

        (let ((beg (pos-bol))
              (end (pos-eol)))

          ;; Skip blank lines.
          (unless (string-match-p "^[[:blank:]]*$" (buffer-substring-no-properties beg end))
            (back-to-indentation)

            (let ((current-indent (current-column)))
              (cond
               ;; Indented, set the result.
               ((> current-indent first-indent)
                (setq result (buffer-substring-no-properties beg (point))))

               ;; Less indentation on non-blank line, early exit.
               ((< current-indent first-indent)
                (setq result t)))))))

      ;; Only yield result if it's a string,
      ;; allow for true value to exit the loop but not return.
      (and (stringp result) result))))

(defun xref-rst--maybe-char-regex (str)
  "Return a regex for STR where each character is optionally matched."
  (declare (important-return-value t))
  (let ((regex-list (list)))
    (dotimes (i (length str))
      (push (concat "\\(?:" (regexp-quote (char-to-string (aref str i))) "\\)?") regex-list))
    (string-join (nreverse regex-list))))


;; ---------------------------------------------------------------------------
;; Internal Functions (reStructuredText)

(defun xref-rst--is-point-in-glossary-body (pos)
  "Return t if POS is within the glossary body."
  (declare (important-return-value t))
  (save-match-data
    (save-excursion
      (goto-char pos)
      (when (re-search-backward xref-rst--regex-glossary-directive nil t)
        ;; Ensure we're not on the glossary line.
        (when (> pos (pos-eol))
          (forward-line 1)
          (goto-char (pos-bol))
          (let* ((current-indent (match-string-no-properties 1))
                 (glossary-end-pos
                  (save-excursion
                    (cond
                     ((re-search-forward (concat
                                          "^"
                                          (xref-rst--maybe-char-regex current-indent)
                                          "[^[:blank:]\n]")
                                         nil t)
                      (point))
                     (t
                      (point-max))))))
            (<= pos glossary-end-pos)))))))

(defun xref-rst--regex-role-data-by-type (role-id)
  "Return the regular expression to match ROLE-ID."
  (declare (important-return-value t))
  (concat
   ":" role-id ":`"
   ;; Start group, only for "OR".
   "\\(?:"
   ;; With brackets.
   "[^<`\n]*<\\([^>\n]+\\)>"
   ;; Or...
   "\\|"
   ;; Without brackets.
   "\\([^`\n]+\\)"
   ;; End non-matching group.
   "\\)`"))

(defun xref-rst--unescape (str)
  "Return STR with backslash escapes removed."
  (declare (important-return-value t))
  ;; Escaped white-space is removed entirely (including the indentation after a line break),
  ;; this must be done in a single pass so an escaped backslash before a space is kept.
  (save-match-data (replace-regexp-in-string xref-rst--regex-escape "\\1" str t)))

(defun xref-rst--normalize-ref-name (str)
  "Return the reference name STR with case & white-space normalized."
  (declare (important-return-value t))
  ;; See: "Reference Names", for white-space & case insensitive matching.
  ;; Match the white-space Python's `str.split' uses (as docutils does), except for
  ;; line/paragraph separators & control characters which are very unlikely in documents.
  ;; Split string modifies match-data.
  (save-match-data (downcase (string-join (split-string str "[[:blank:]\n\v\f\r]+" t) " "))))

(defun xref-rst--hyperlink-ref-name (rst-ref-text)
  "Return the target name of the hyperlink reference RST-REF-TEXT (unescaped, not normalized)."
  (declare (important-return-value t))
  (xref-rst--unescape
   (save-match-data
     (cond
      ;; Embedded alias or URI, e.g. "Text <target_>" or "Text <https://...>".
      ;; See: "Embedded URIs and Aliases".
      ((string-match "\\(?:\\`\\|[ \t\n]\\)<\\([^<>]+\\)>\\'" rst-ref-text)
       (let ((embedded (match-string-no-properties 1 rst-ref-text)))
         ;; An alias ends with an (unescaped) underscore.
         (unless (string-match-p "[^\\]_\\'" embedded)
           (user-error "Embedded URI %S has no definition" embedded))
         (string-trim (substring embedded 0 -1) "`" "`")))
      (t
       rst-ref-text)))))

(defun xref-rst--section-title-ref-name (title)
  "Return the reference name of the section TITLE (unescaped, not normalized)."
  (declare (important-return-value t))
  ;; NOTE: docutils uses the titles plain text, only common inline markup is removed here.
  ;; Handling all markup (roles for e.g.) would need a much more complete parser,
  ;; since titles rarely contain other markup, leave as-is.
  (save-match-data
    ;; Escapes, emphasis & inline literals are handled in a single pass,
    ;; so an escaped asterisk isn't treated as emphasis
    ;; and markup within an inline literal is kept.
    (replace-regexp-in-string xref-rst--regex-title-markup
                              (lambda (match)
                                (cond
                                 ;; Inline literals are kept as-is (escapes aren't removed).
                                 ((match-beginning 2)
                                  (match-string-no-properties 2 match))
                                 ;; Strong & emphasis.
                                 ((match-beginning 1)
                                  (xref-rst--unescape (match-string-no-properties 1 match)))
                                 ;; Escapes.
                                 (t
                                  (xref-rst--unescape match))))
                              title
                              t t)))

(defun xref-rst--section-title-at-underline (pos)
  "Return (BEG . TITLE) for the section title underlined by the line at POS.

BEG is the start of the title and TITLE is its text (without surrounding white-space).

The line at POS must match `xref-rst--regex-section-adornment'.
Return nil when the line isn't a title underline (an overline or a transition for e.g.)."
  (declare (important-return-value t))
  (save-match-data
    (save-excursion
      (goto-char pos)
      (let ((underline (string-trim-right (buffer-substring-no-properties (pos-bol) (pos-eol)))))
        (when (zerop (forward-line -1))
          (let ((title-bol (pos-bol))
                (title-line (buffer-substring-no-properties (pos-bol) (pos-eol))))
            (unless (or (string-blank-p title-line)
                        (string-match-p xref-rst--regex-section-adornment title-line))
              (let ((title (string-trim title-line "[ \t]+" "[ \t]+"))
                    (above-line
                     (and (zerop (forward-line -1))
                          (buffer-substring-no-properties (pos-bol) (pos-eol)))))
                (when (and (or
                            ;; Over-lined titles may be indented (see: "Sections").
                            (and above-line
                                 (string-equal underline (string-trim-right above-line)))
                            ;; Otherwise the title can't be indented and must begin a paragraph,
                            ;; docutils treats an underline after multiple lines as an error.
                            ;;
                            ;; A blank line after a title is optional (see: "Sections"),
                            ;; so the line above may also be the underline of another title.
                            (and (null (memq (aref title-line 0) (list ?\s ?\t)))
                                 (or (null above-line)
                                     (string-blank-p above-line)
                                     (and (string-match-p
                                           xref-rst--regex-section-adornment above-line)
                                          (xref-rst--section-title-at-underline (pos-bol))))))
                           ;; Matches docutils, which treats a short underline as text
                           ;; when it's also shorter than the title
                           ;; (see docutils `Text.underline').
                           (null
                            (and (< (length underline) 4)
                                 (> (string-width title) (length underline)))))
                  (cons (+ title-bol (string-match-p "[^ \t]" title-line)) title))))))))))


(defun xref-rst--file-match-regex ()
  "Return `xref-rst-extensions' as a file matching REGEX."
  (declare (important-return-value t))
  ;; Converts:
  ;;    '(".rst" ".txt")
  ;; Into:
  ;;    "\\`[^.].*\\(\\.rst\\|\\.txt\\)\\'"
  ;;
  ;; Skip files starting with a dot (typically hidden/backup files).
  (concat "\\`[^.].*" "\\(" (mapconcat #'regexp-quote xref-rst-extensions "\\|") "\\)\\'"))

(defun xref-rst--dirs-recursive (root)
  "Recursively scan ROOT for RST files."
  (declare (important-return-value t))
  (let ((rst-file-match-regex (xref-rst--file-match-regex)))
    (directory-files-recursively root rst-file-match-regex
                                 nil
                                 ;; Ignore hidden directories too.
                                 (lambda (dir)
                                   (null
                                    (string-equal
                                     "." (substring (file-name-nondirectory dir) 0 1)))))))

(defun xref-rst--file-vars (error-prefix)
  "Access the current buffers file with ERROR-PREFIX for any errors.

Return a list of the directory & file path."
  (declare (important-return-value t))
  (let* ((buf (current-buffer))
         (current-filepath
          (or (buffer-file-name buf)
              (user-error (concat error-prefix "current buffer has no path, exiting!"))))
         (current-dir
          (or (file-name-directory current-filepath)
              (user-error (concat error-prefix "unable to get directory name")))))
    (list current-dir current-filepath)))

(defun xref-rst--project-root (current-dir current-filepath error-prefix)
  "Return the project root of CURRENT-DIR & CURRENT-FILEPATH with ERROR-PREFIX for any errors."
  (declare (important-return-value t))
  (or
   ;; Sphinx convention.
   (locate-dominating-file current-dir "conf.py")

   ;; Base-dir from VC.
   (let ((vc-backend
          (ignore-errors
            (vc-responsible-backend current-filepath))))
     (when vc-backend
       (vc-call-backend vc-backend 'root current-filepath)))

   (user-error (concat error-prefix "unable to find project root"))))

(defun xref-rst--project-vars (error-prefix)
  "Access project with ERROR-PREFIX for any errors."
  (declare (important-return-value t))
  (pcase-let ((`(,current-dir ,current-filepath) (xref-rst--file-vars error-prefix)))
    (list
     (xref-rst--project-root current-dir current-filepath error-prefix)
     current-dir
     current-filepath)))


;; ---------------------------------------------------------------------------
;; Internal Functions (Find)

(defun xref-rst--lookup-ref (current-project-root rst-role-data)
  "Lookup the location of the `ref' RST-ROLE-DATA in the CURRENT-PROJECT-ROOT."
  (declare (important-return-value t))
  (let ((matches (list))
        (all-files
         (let ((case-fold-search t)) ; Case insensitive search.
           (xref-rst--dirs-recursive current-project-root))))
    (with-temp-buffer
      (setq buffer-undo-list t)
      (set-buffer-multibyte nil)
      (let ((coding-system-for-read 'no-conversion))
        (dolist (rst-file-iter all-files)
          (insert-file-contents rst-file-iter)
          (goto-char (point-min))
          (while (re-search-forward xref-rst--regex-ref-declare nil t)
            (when (string-equal rst-role-data (match-string-no-properties 2))
              (let ((bol (pos-bol))
                    (eol (pos-eol)))

                (push (xref-rst--candidate
                       ;; Symbol.
                       rst-role-data
                       ;; Filename.
                       rst-file-iter
                       ;; Line number.
                       (1+ (count-lines (point-min) (match-beginning 0)))
                       ;; Column number.
                       (- (match-beginning 2) bol)
                       ;; Display text.
                       (buffer-substring-no-properties bol eol))
                      matches))))
          (erase-buffer))))
    matches))

(defun xref-rst--lookup-term (current-project-root rst-role-data)
  "Lookup the location of the `term' RST-ROLE-DATA in the CURRENT-PROJECT-ROOT."
  (declare (important-return-value t))
  (let ((matches (list))
        (all-files
         (let ((case-fold-search t)) ; Case insensitive search.
           (xref-rst--dirs-recursive current-project-root))))

    (with-temp-buffer
      (setq buffer-undo-list t)
      (set-buffer-multibyte nil)
      (let ((coding-system-for-read 'no-conversion))
        (dolist (rst-file-iter all-files)
          (insert-file-contents rst-file-iter)
          (goto-char (point-min))
          (while (re-search-forward xref-rst--regex-glossary-directive nil t)
            (let* ((current-indent (match-string-no-properties 1)) ; Indent then term.

                   ;; Find the end of this glossary directive.
                   ;; This is done by finding the same indent level, or less indentation.
                   ;; `xref-rst--maybe-char-regex' is used to search for
                   ;; lower levels of indentation.
                   (glossary-end-pos
                    (save-excursion
                      (cond
                       ((re-search-forward (concat
                                            "^"
                                            (xref-rst--maybe-char-regex current-indent)
                                            "[^[:blank:]\n]")
                                           nil t)
                        (point))
                       (t
                        (point-max)))))

                   ;; Although this should never be nil, there is some small chance it could be
                   ;; if - for example there is odd mixing of tabs/spaces,
                   ;; so use a fallback if it can't be detected.
                   (next-indent
                    (xref-rst--find-next-indent-level-as-string (point) glossary-end-pos))

                   (term-regex
                    (concat
                     "^"
                     ;; Match indentation.
                     "\\("
                     ;; The next indent level, be exact so we don't match any of the body text.
                     ;;
                     ;; Fall back to any indent greater than the current indent
                     ;; while not perfect in that it may match the body text of the glossary,
                     ;; the chance it fails is very low, so it's not a bad fallback.
                     (cond
                      (next-indent
                       (regexp-quote next-indent))
                      (t
                       (concat (regexp-quote current-indent) "[[:blank:]]+")))
                     ;; End group.
                     "\\)"
                     ;; The term.
                     "\\(" (regexp-quote rst-role-data) "\\)"
                     ;; Allow for keys (they're ignored, but support finding entries with keys).
                     "\\([[:blank:]]*\\|[[:blank:]]+:[[:blank:]]+.*\\)$")))

              (when (re-search-forward term-regex glossary-end-pos t)
                (let ((bol (pos-bol))
                      (eol (pos-eol)))
                  (push (xref-rst--candidate
                         ;; Symbol.
                         rst-role-data
                         ;; Filename.
                         rst-file-iter
                         ;; Line number.
                         (1+ (count-lines (point-min) (match-beginning 1)))
                         ;; Column number.
                         (- (match-beginning 2) bol)
                         ;; Display text.
                         (buffer-substring-no-properties bol eol))
                        matches)))

              (goto-char glossary-end-pos)))
          (erase-buffer))))
    matches))

(defun xref-rst--lookup-doc (current-project-root current-dir rst-role-data)
  "Lookup the location of the `doc' RST-ROLE-DATA.

This is done relative to CURRENT-PROJECT-ROOT or CURRENT-DIR."
  (declare (important-return-value t))
  (let* ((rst-filepath-no-ext
          (cond
           ((string-equal "/" (substring rst-role-data 0 1))
            (file-name-concat current-project-root (substring rst-role-data 1)))
           (t
            (file-name-concat current-dir rst-role-data))))
         (rst-file-part (file-name-nondirectory rst-role-data))
         (rst-dir-part (file-name-directory rst-filepath-no-ext))
         (rst-files-test
          (directory-files rst-dir-part t (concat "^" (regexp-quote rst-file-part))))
         (rst-filepath-found
          (catch 'result
            ;; Case insensitive extension comparison.
            (let ((case-fold-search t)
                  (rst-file-match-regex (xref-rst--file-match-regex)))
              (save-match-data
                (dolist (rst-test rst-files-test)
                  (let ((rst-file-only (file-name-nondirectory rst-test)))
                    (when (string-match rst-file-match-regex rst-file-only)
                      ;; While it's unlikely, this could match a word
                      ;; that has extra characters at the end.
                      (when (zerop (match-beginning 0))
                        (throw 'result rst-test))))))))))

    (unless rst-filepath-found
      (user-error "Could not find a file: %S with extensions matching %S"
                  rst-filepath-no-ext
                  xref-rst-extensions))

    ;; Result (list of one).
    (list (xref-rst--candidate rst-role-data rst-filepath-found 1 0 ""))))

(defun xref-rst--lookup-hyperlink-ref (current-filepath rst-ref-text)
  "Lookup the target of the hyperlink reference RST-REF-TEXT in the current buffer.

CURRENT-FILEPATH is used for the location of the results."
  (declare (important-return-value t))
  ;; NOTE: only the current document is searched since docutils & Sphinx
  ;; resolve hyperlink references within the document, links between documents use `ref'.
  (let* ((matches (list))
         (ref-name (xref-rst--hyperlink-ref-name rst-ref-text))
         (ref-name-normal (xref-rst--normalize-ref-name ref-name))
         (make-candidate-fn
          (lambda (pos)
            (save-excursion
              (goto-char pos)
              (xref-rst--candidate
               ;; Symbol.
               ref-name
               ;; Filename.
               current-filepath
               ;; Line number.
               (line-number-at-pos)
               ;; Column number.
               (- pos (pos-bol))
               ;; Display text.
               (buffer-substring-no-properties (pos-bol) (pos-eol)))))))

    (save-excursion
      (save-restriction
        (widen)

        ;; Explicit targets, e.g. ".. _Some Name:".
        ;; These are found first as they take precedence over section titles
        ;; (matching docutils, see `document.set_duplicate_name').
        (goto-char (point-min))
        (while (re-search-forward xref-rst--regex-hyperlink-target nil t)
          (when (string-equal
                 ref-name-normal
                 (xref-rst--normalize-ref-name
                  (xref-rst--unescape (match-string-no-properties 1))))
            (push (funcall make-candidate-fn (match-beginning 1)) matches)))

        ;; Implicit targets from section titles.
        (goto-char (point-min))
        (while (re-search-forward xref-rst--regex-section-adornment nil t)
          (pcase (xref-rst--section-title-at-underline (match-beginning 0))
            (`(,beg . ,title)
             (when (string-equal
                    ref-name-normal
                    (xref-rst--normalize-ref-name (xref-rst--section-title-ref-name title)))
               (push (funcall make-candidate-fn beg) matches)))))))

    (nreverse matches)))

(defun xref-rst--find-definitions-impl (symbol)
  "Lookup SYMBOL, returning a list of matching items from `xref-rst--candidate'."
  (declare (important-return-value t))
  (let ((error-prefix "RST-reference: ")
        (matches (list)))
    ;; NOTE: the project root is only found for roles as it's not needed for other lookups,
    ;; which only use the current file or directory, so they work outside of a project.
    (pcase-let ((`(,current-dir ,current-filepath) (xref-rst--file-vars error-prefix)))

      (save-excursion
        (save-match-data
          (cond
           ;; Handle RST role, both:
           ;; - :role:`data`
           ;; - :role:`Text <data>`
           ((string-match xref-rst--regex-any-role-data symbol)
            (let* ((rst-role-id (match-string-no-properties 1 symbol))
                   (rst-role-data
                    (or (match-string-no-properties 2 symbol)
                        (match-string-no-properties 3 symbol)))
                   ;; Last, as this may modify the match-data.
                   (current-project-root
                    (xref-rst--project-root current-dir current-filepath error-prefix)))

              ;; Act on roles.
              (cond
               ((string-equal rst-role-id "ref")
                (setq matches (xref-rst--lookup-ref current-project-root rst-role-data)))

               ((string-equal rst-role-id "term")
                (setq matches (xref-rst--lookup-term current-project-root rst-role-data)))

               ((string-equal rst-role-id "doc")
                (setq matches
                      (xref-rst--lookup-doc current-project-root current-dir rst-role-data))))))

           ;; Handle RST hyperlink references, both:
           ;; - `Title`_
           ;; - `Text <target_>`_
           ((string-match (concat "\\`" xref-rst--regex-hyperlink-ref "\\'") symbol)
            (setq matches
                  (xref-rst--lookup-hyperlink-ref
                   current-filepath (match-string-no-properties 2 symbol))))

           ;; Not an RST role,
           ;; fall-back to looking up a file path as is used within an index.
           (t
            (let ((rst-found-file
                   (concat
                    current-dir
                    ;; Extract "file.rst" from "Some Title <file.rst>".
                    ;; if this syntax is used in index listings.
                    (cond
                     ((string-match "[[:blank:]]+<\\(.*\\)>[[:blank:]]*$" symbol)
                      (match-string-no-properties 1 symbol))
                     (t
                      symbol)))))
              (unless (file-exists-p rst-found-file)
                (user-error
                 (concat error-prefix "not over an RST role or filename at the cursor")))

              (push (xref-rst--candidate symbol rst-found-file 1 0 "") matches)))))))
    matches))


;; ---------------------------------------------------------------------------
;; Internal Functions (Usage)

(defun xref-rst--find-references-to-ref (symbol)
  "Lookup references to SYMBOL using the :ref: role."
  (declare (important-return-value t))

  (let ((error-prefix "RST-reference-usage: ")
        (xrefs (list))
        (rst-role-data nil)
        (regex-ref-role-data (xref-rst--regex-role-data-by-type "ref")))

    (pcase-let ((`(,current-project-root ,_current-dir ,_current-filepath)
                 (xref-rst--project-vars error-prefix)))

      ;; The current line is a role.

      ;; Find "ref" usage.
      (setq rst-role-data
            (save-match-data
              (when (string-match xref-rst--regex-ref-declare symbol)
                (match-string-no-properties 2 symbol))))

      (when rst-role-data
        (let ((all-files
               (let ((case-fold-search t)) ; Case insensitive search.
                 (xref-rst--dirs-recursive current-project-root))))
          (with-temp-buffer
            (setq buffer-undo-list t)
            (set-buffer-multibyte nil)
            (let ((coding-system-for-read 'no-conversion))
              (dolist (rst-file-iter all-files)
                (insert-file-contents rst-file-iter)
                (goto-char (point-min))
                (while (re-search-forward regex-ref-role-data nil t)
                  (when (string-equal
                         rst-role-data
                         (or (match-string-no-properties 1) (match-string-no-properties 2)))
                    (let ((bol (pos-bol))
                          (eol (pos-eol)))
                      (push (xref-make
                             ;; Display text.
                             (buffer-substring-no-properties bol eol)
                             ;; Location.
                             (xref-make-file-location
                              ;; File path:
                              rst-file-iter
                              ;; Line: +1 is important or we won't account
                              ;; for the newline directly before the ':ref:'.
                              (count-lines (point-min) (1+ (match-beginning 0)))
                              ;; Column: skip the ':ref:`'.
                              (+ (length ":ref:`") (- (match-beginning 0) bol))))
                            xrefs))))

                (erase-buffer))))

          (unless xrefs
            (user-error
             (concat
              error-prefix
              (format "could not find any references to %S under %S within %d files!"
                      rst-role-data current-project-root (length all-files))))))

        ;; Show collected Xref list.
        xrefs))))


(defun xref-rst--find-references-to-term (symbol)
  "Lookup references to SYMBOL using the :term: role."
  (declare (important-return-value t))

  (let ((error-prefix "RST-term-usage: ")
        (xrefs (list))
        (rst-terms-data nil)
        (regex-term-role-data (xref-rst--regex-role-data-by-type "term")))

    (pcase-let ((`(,current-project-root ,_current-dir ,_current-filepath)
                 (xref-rst--project-vars error-prefix)))

      ;; First check we're in the glossary,
      ;; tsk, we need to get the surrounding context from the symbol.
      (let ((symbol-context (get-text-property 0 'xref-rst-context symbol)))
        (when symbol-context
          (pcase-let ((`(,symbol-buffer . ,symbol-point) symbol-context))
            (with-current-buffer symbol-buffer
              (when (xref-rst--is-point-in-glossary-body symbol-point)
                (pcase-let ((`(,beg . ,end)
                             (xref-rst--range-of-block-at-current-indent symbol-point)))
                  (setq rst-terms-data
                        ;; Split string modifies match-data.
                        (save-match-data
                          (mapcar
                           (lambda (str)
                             (string-trim
                              ;; Ignore the "key".
                              (car (split-string str ":"))))
                           (split-string (buffer-substring-no-properties beg end) "\n"))))))))))

      (when rst-terms-data
        (let ((rst-terms-data-regex
               (concat "\\(" (mapconcat #'regexp-quote rst-terms-data "\\|") "\\)"))
              (all-files
               (let ((case-fold-search t)) ; Case insensitive search.
                 (xref-rst--dirs-recursive current-project-root))))

          (with-temp-buffer
            (setq buffer-undo-list t)
            (set-buffer-multibyte nil)
            (let ((coding-system-for-read 'no-conversion))
              (dolist (rst-file-iter all-files)
                (insert-file-contents rst-file-iter)
                (goto-char (point-min))
                (while (re-search-forward regex-term-role-data nil t)
                  (when (string-match-p
                         rst-terms-data-regex
                         (or (match-string-no-properties 1) (match-string-no-properties 2)))
                    (let ((bol (pos-bol))
                          (eol (pos-eol)))

                      (push (xref-make
                             ;; Display text.
                             (buffer-substring-no-properties bol eol)
                             ;; Location.
                             (xref-make-file-location
                              ;; File path:
                              rst-file-iter
                              ;; Line: +1 is important or we won't account
                              ;; for the newline directly before the ':term:'.
                              (count-lines (point-min) (1+ (match-beginning 0)))
                              ;; Column: skip the ':term:`'.
                              (+ (length ":term:`") (- (match-beginning 0) bol))))
                            xrefs))))

                (erase-buffer)))

            (unless xrefs
              (user-error
               (concat
                error-prefix
                (format "could not find any references to %S under %S within %d files!"
                        rst-terms-data current-project-root (length all-files)))))))

        ;; Show collected Xref list.
        xrefs))))

(defun xref-rst--find-references-impl (symbol)
  "Show usages of SYMBOL."
  (declare (important-return-value t))
  (let ((xrefs (list)))

    (cond
     ;; found ':ref:'
     ((setq xrefs (xref-rst--find-references-to-ref symbol)))

     ;; found ':term:'
     ((setq xrefs (xref-rst--find-references-to-term symbol)))

     (t
      (user-error
       (concat
        "RST usage: "
        (format "unable to determine a reference type from %S"
                (substring-no-properties symbol))))))

    xrefs))


;; ---------------------------------------------------------------------------
;; Xref Utilities

;; Use for creating targets to display.
(defun xref-rst--candidate (symbol file line col line-text)
  "Return a candidate association-list.
This is built from SYMBOL, FILE, LINE, COL and a raw LINE-TEXT result."
  (declare (important-return-value t))
  (list
   (cons 'file file)
   (cons 'line line)
   (cons 'column col)
   (cons 'symbol symbol)
   (cons 'match line-text)))


;; Use for finding links to this item.
(defun xref-rst--make-xref (candidate)
  "Return a new Xref object built from CANDIDATE."
  (declare (important-return-value t))
  (xref-make
   (map-elt candidate 'match)
   (xref-make-file-location
    (map-elt candidate 'file) (map-elt candidate 'line) (map-elt candidate 'column))))


;; ---------------------------------------------------------------------------
;; Xref Back-End

(cl-defmethod xref-backend-identifier-at-point ((_backend (eql xref-rst)))
  "Return either an RST role, a hyperlink reference or a file name."
  (let ((symbol
         (save-match-data
           (cond
            ;; Roles can't span lines, limit the search to the current line,
            ;; otherwise the search begins at the start of the buffer.
            ((save-restriction
               (narrow-to-region (pos-bol) (pos-eol))
               (thing-at-point-looking-at xref-rst--regex-any-role-data))
             (match-string-no-properties 0))
            ;; Hyperlink references can't span a blank line, limit the search to the paragraph,
            ;; otherwise the search begins at the start of the buffer.
            ;; Exclude anonymous references, e.g. `Text`__.
            ;; The surrounding blank lines are included, this is harmless as they can't match.
            ((and (save-restriction
                    (narrow-to-region
                     (save-excursion
                       (goto-char (pos-bol))
                       (re-search-backward "^[[:blank:]]*$" nil 'move)
                       (point))
                     (save-excursion
                       (goto-char (pos-eol))
                       (re-search-forward "^[[:blank:]]*$" nil 'move)
                       (point)))
                    (thing-at-point-looking-at xref-rst--regex-hyperlink-ref))
                  (null (eq ?_ (char-after (match-end 0)))))
             (match-string-no-properties 1))
            (t
             (string-trim (thing-at-point 'line t)))))))

    (propertize symbol 'xref-rst-context (cons (current-buffer) (point)))))

(cl-defmethod xref-backend-definitions ((_backend (eql xref-rst)) symbol)
  "Find definitions of SYMBOL."
  (mapcar #'xref-rst--make-xref (xref-rst--find-definitions-impl symbol)))

(cl-defmethod xref-backend-references ((_backend (eql xref-rst)) symbol)
  "Show references to SYMBOL."
  (xref-rst--find-references-impl symbol))

(defun xref-rst-xref-backend ()
  "Xref-RST back-end for Xref."
  (declare (important-return-value t))
  'xref-rst)

;;;###autoload
(define-minor-mode xref-rst-mode
  "Enable Xref for RST files."
  :global nil
  :lighter ""

  (cond
   (xref-rst-mode
    (add-hook 'xref-backend-functions #'xref-rst-xref-backend nil t))
   (t
    (remove-hook 'xref-backend-functions #'xref-rst-xref-backend t))))

(provide 'xref-rst)
;; Local Variables:
;; fill-column: 99
;; indent-tabs-mode: nil
;; elisp-autofmt-load-packages-local: ("xref")
;; End:
;;; xref-rst.el ends here
