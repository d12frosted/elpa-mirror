;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "share2computer" "20200316.31"
  "Elisp helper of android ShareToComputer."
  '((emacs "25.1"))
  :url "https://github.com/tumashu/share2computer"
  :commit "15da47625a800e3310b8dc714bd4e41e32966d6a"
  :revdesc "15da47625a80"
  :keywords '("convenience" "comm")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
