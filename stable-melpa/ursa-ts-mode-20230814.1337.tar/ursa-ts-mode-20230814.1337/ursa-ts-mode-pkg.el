(define-package "ursa-ts-mode" "20230814.1337" "Tree-sitter support for Ursa"
  '((emacs "29.1"))
  :commit "a1141c424e607850b12059d95f7f9eebeb409b89" :authors
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainers
  '(("Reuben Thomas" . "rrt@sc3d.org"))
  :maintainer
  '("Reuben Thomas" . "rrt@sc3d.org")
  :keywords
  '("ursalang" "languages" "tree-sitter")
  :url "https://github.com/ursalang/ursa-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
