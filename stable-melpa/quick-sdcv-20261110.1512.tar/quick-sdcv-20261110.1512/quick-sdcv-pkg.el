;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-sdcv" "20261110.1512"
  "Offline dictionary using 'sdcv' (StartDict cli dictionary)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/quick-sdcv.el"
  :commit "c689c93fad9be15dca8f8d45ae19a8ca78d65563"
  :revdesc "c689c93fad9b"
  :keywords '("tools" "convenience" "text"))
