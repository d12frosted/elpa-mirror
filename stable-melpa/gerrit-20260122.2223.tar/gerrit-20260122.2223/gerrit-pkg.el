;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gerrit" "20260122.2223"
  "Gerrit client."
  '((emacs "29.1")
    (magit "2.13.1")
    (s     "1.12.0")
    (dash  "0.2.15"))
  :url "https://github.com/twmr/gerrit.el"
  :commit "7b77b1117afeb6654f0e181176782baf65549f8b"
  :revdesc "7b77b1117afe"
  :keywords '("extensions")
  :authors '(("Thomas Wimmer" . "thomaswimmer@posteo.com"))
  :maintainers '(("Thomas Wimmer" . "thomaswimmer@posteo.com")))
