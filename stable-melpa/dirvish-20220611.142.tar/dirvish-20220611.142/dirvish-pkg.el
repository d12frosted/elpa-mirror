(define-package "dirvish" "20220611.142" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "4cfefd1bc3b71f19acb631af109d92be3d40157e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
