;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260201.1857"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "da92457bd6fe3c9ef408567d86ab3ca020677a55"
  :revdesc "da92457bd6fe"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
