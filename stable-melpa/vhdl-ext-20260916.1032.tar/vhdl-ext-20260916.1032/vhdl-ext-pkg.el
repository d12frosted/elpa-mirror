;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ext" "20260916.1032"
  "VHDL Extensions."
  '((emacs        "29.1")
    (vhdl-ts-mode "0.3.3")
    (lsp-mode     "8.0.0")
    (rg           "2.3.0")
    (hydra        "0.15.0")
    (flycheck     "32")
    (async        "1.9.7"))
  :url "https://github.com/gmlarumbe/vhdl-ext"
  :commit "70718eb2320662c6f2de80e5872c3d9bb989c7b9"
  :revdesc "70718eb23206"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
