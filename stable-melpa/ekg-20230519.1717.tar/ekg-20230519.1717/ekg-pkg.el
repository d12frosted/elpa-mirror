(define-package "ekg" "20230519.1717" "A system for recording and linking information"
  '((triples "0.2.7")
    (emacs "28.1"))
  :commit "da6a3b3073374e868f157fe7dc24be7b889af8fd" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
