;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260922.549"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "f87171ddffb20a270236360f40eb7f6c59673f76"
  :revdesc "f87171ddffb2"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
