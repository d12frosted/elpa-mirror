(define-package "detached" "20221123.1722" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "7b263b51232fee664f35b3d432de75334cde5e7f" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
