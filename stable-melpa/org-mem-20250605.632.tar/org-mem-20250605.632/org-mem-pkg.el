;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250605.632"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "5374bb4ca25d20a7c036ac48729090ba25d31fdd"
  :revdesc "5374bb4ca25d"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
