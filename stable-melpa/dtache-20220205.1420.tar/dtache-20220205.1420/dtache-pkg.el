(define-package "dtache" "20220205.1420" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "c9f7c16d4d703c8890deea6a9c9b9d30e65e1737" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
