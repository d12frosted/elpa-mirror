;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260513.1752"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/melpa/package-build"
  :commit "f290c0e7acbf057886f50db7c22e6f5565c69d43"
  :revdesc "f290c0e7acbf"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")))
