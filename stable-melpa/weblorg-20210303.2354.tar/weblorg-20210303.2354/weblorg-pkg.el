(define-package "weblorg" "20210303.2354" "Static Site Generator for org-mode"
  '((templatel "0.1.4")
    (emacs "26.1"))
  :commit "41a9f969c80678c1311eb9d5ae757862202e02fa" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
