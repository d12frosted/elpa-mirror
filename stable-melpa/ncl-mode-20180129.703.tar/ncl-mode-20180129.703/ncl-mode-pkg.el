;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ncl-mode" "20180129.703"
  "Major Mode for editing NCL scripts."
  '((emacs "24"))
  :url "https://github.com/yyr/ncl-mode"
  :commit "602292712a9e6b7e7c25155978999e77d06b7338"
  :revdesc "602292712a9e"
  :keywords '("ncl" "major mode" "ncl-mode" "atmospheric science.")
  :authors '(("Yagnesh Raghava Yakkala" . "hi@yagnesh.org"))
  :maintainers '(("Yagnesh Raghava Yakkala" . "hi@yagnesh.org")))
