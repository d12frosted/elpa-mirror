;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260513.744"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ae2fddbe2a1a0831c30f08b5b4871ab35b967aa1"
  :revdesc "ae2fddbe2a1a"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
