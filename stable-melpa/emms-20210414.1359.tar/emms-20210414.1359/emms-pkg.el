(define-package "emms" "20210414.1359" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (seq "0"))
  :commit "5b1cfb12b49390328f68f351ab677c27c5c3e980" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
