;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "markdown-ts-appear" "20261020.1302"
  "Reveal Markdown source at point."
  '((emacs "31.1"))
  :url "https://github.com/Thysrael/markdown-ts-appear"
  :commit "4b130c5c4fd3fbf62e13af856845fcd91699bb14"
  :revdesc "4b130c5c4fd3"
  :keywords '("text" "convenience")
  :authors '(("Thysrael" . "thysrael@163.com"))
  :maintainers '(("Thysrael" . "thysrael@163.com")))
