;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261107.2358"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "4bed2ceaa493927021c6525d34e18ce53524d9dc"
  :revdesc "4bed2ceaa493"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
