;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260217.2032"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.29.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "e615d8d5fe32101f8d659690efc5a39799daa775"
  :revdesc "e615d8d5fe32"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
