(define-package "epkg" "20210615.1503" "browse the Emacsmirror package database"
  '((closql "1.0.5")
    (emacs "25.1"))
  :commit "34f1cdb871b75396eb7601ac83d60a39f5602b3a" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
