(define-package "dwim-shell-command" "20221022.926" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "f8b567e78e293e05f5834ee66cbe064a6674aa5e" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
