(define-package "emms" "20210223.2000" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (seq "0"))
  :commit "75ae9329a1c2e630613c1e836dc71322ea806fe7" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
