;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260530.1801"
  "Enhanced annotation system with threading."
  '((emacs     "27.2")
    (transient "0.4"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "31fca09220fb1dc3ec9922fe9760ae98c8ba7b57"
  :revdesc "31fca09220fb"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
