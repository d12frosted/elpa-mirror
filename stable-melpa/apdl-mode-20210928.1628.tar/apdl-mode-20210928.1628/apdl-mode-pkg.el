(define-package "apdl-mode" "20210928.1628" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "f7a6e278e11bc725b6e4d56c5cc166790fec4740" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
