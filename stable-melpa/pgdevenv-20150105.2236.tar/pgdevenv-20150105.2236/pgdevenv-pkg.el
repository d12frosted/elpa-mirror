(define-package "pgdevenv" "20150105.2236" "Manage your PostgreSQL development envs" 'nil :commit "7f1d5bc734750aca98cf67a9491cdbd5615fd132" :keywords
  ("emacs" "postgresql" "development" "environment" "shell" "debug" "gdb")
  :authors
  (("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainer
  ("Dimitri Fontaine" . "dim@tapoueh.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
