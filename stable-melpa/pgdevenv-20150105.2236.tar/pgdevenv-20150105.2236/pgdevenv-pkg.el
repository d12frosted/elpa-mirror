;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pgdevenv" "20150105.2236"
  "Manage your PostgreSQL development envs."
  ()
  :url "https://github.com/dimitri/pgdevenv-el"
  :commit "7f1d5bc734750aca98cf67a9491cdbd5615fd132"
  :revdesc "7f1d5bc73475"
  :keywords '("emacs" "postgresql" "development" "environment" "shell" "debug" "gdb")
  :authors '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainers '(("Dimitri Fontaine" . "dim@tapoueh.org")))
