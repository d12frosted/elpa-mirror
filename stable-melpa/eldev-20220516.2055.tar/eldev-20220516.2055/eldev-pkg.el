(define-package "eldev" "20220516.2055" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "a17357a24cf8fd2f6b16b50266a6ae8b842a9ec7" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
