;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260310.436"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "80a958cafc7b5a05acce4fb8585d0a3be53f7457"
  :revdesc "80a958cafc7b")
