;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeater" "20180418.1212"
  "Repeat recent repeated commands."
  '((emacs "24.4"))
  :url "https://github.com/xuchunyang/repeater"
  :commit "854b874542b186b2408cbc58ad0591fe8eb70b6c"
  :revdesc "854b874542b1"
  :keywords '("convenience")
  :authors '(("Xu Chunyang" . "mail@xuchunyang.me"))
  :maintainers '(("Xu Chunyang" . "mail@xuchunyang.me")))
