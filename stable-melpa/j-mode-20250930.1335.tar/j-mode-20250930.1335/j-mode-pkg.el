;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "j-mode" "20250930.1335"
  "Major mode for editing J programs."
  ()
  :url "http://github.com/zellio/j-mode"
  :commit "3fb692cc7618c5d109aaa7dd8b800e42fa1d8b77"
  :revdesc "3fb692cc7618"
  :keywords '("j" "langauges"))
