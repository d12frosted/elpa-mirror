(define-package "boon" "20210227.2007" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "5bc40ef5b114239ba67a1a80170b15d0687ce300")
;; Local Variables:
;; no-byte-compile: t
;; End:
