(define-package "avk-emacs-themes" "20220908.1022" "Collection of avk themes" 'nil :commit "598a2a56601db1f474ed3f34a1cc4fb37921c21a" :authors
  '(("Alex V. Koval" . "alex@koval.kharkov.ua"))
  :maintainer
  '("Alex V. Koval" . "alex@koval.kharkov.ua")
  :keywords
  '("theme")
  :url "https://github.com/avkoval/avk-emacs-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
