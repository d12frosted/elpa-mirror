;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gumshoe" "20260110.1840"
  "Scoped spatial and temporal POINT movement tracking."
  '((emacs "25.1"))
  :url "https://github.com/Overdr0ne/gumshoe"
  :commit "2f4f54a584d4460b838ae8e366c07eb0f040d408"
  :revdesc "2f4f54a584d4"
  :keywords '("tools"))
