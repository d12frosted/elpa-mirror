;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250604.1109"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "2aad0e762519b38bcbbbae9ee28b229e83d725b8"
  :revdesc "2aad0e762519"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
