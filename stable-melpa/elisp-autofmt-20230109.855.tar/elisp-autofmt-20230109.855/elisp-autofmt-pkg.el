(define-package "elisp-autofmt" "20230109.855" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "e1fa500b3967320c70c9dcb31d0aef5351759ef1" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
