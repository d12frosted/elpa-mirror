;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-aibo" "20250310.248"
  "An AI Writing Assistant."
  '((emacs "27.1")
    (gptel "0.9.7"))
  :url "https://github.com/dolmens/gptel-aibo"
  :commit "de2734945a393a36900beef6524aea3ba4431391"
  :revdesc "de2734945a39"
  :keywords '("emacs" "tools" "editing" "gptel" "ai" "assistant" "code-completion" "productivity")
  :authors '(("Sun Yi Ming" . "dolmens@gmail.com"))
  :maintainers '(("Sun Yi Ming" . "dolmens@gmail.com")))
