;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "navigel" "20251012.613"
  "Facilitate the creation of tabulated-list based UIs."
  '((emacs   "25.1")
    (tablist "1.0"))
  :url "https://github.com/DamienCassou/navigel"
  :commit "84b520d518a40cd4d8e91979267c43526c6e27a1"
  :revdesc "84b520d518a4"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
