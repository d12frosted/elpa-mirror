;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20261103.1821"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "6db7ef9e2ad7ef5ccdaa8ab596643d19a694356f"
  :revdesc "6db7ef9e2ad7"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
