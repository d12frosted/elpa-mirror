;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260506.1926"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "3f4be666d95681eb4e49d124f82e7eec298457dc"
  :revdesc "3f4be666d956"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
