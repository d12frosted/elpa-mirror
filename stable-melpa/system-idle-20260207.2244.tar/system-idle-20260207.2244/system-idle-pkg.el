;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "system-idle" "20260207.2244"
  "Poll the system-wide idle time."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/system-idle"
  :commit "7522fdf0fc60f5a842d2d9967947dd7cfcd66bd0"
  :revdesc "7522fdf0fc60"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
