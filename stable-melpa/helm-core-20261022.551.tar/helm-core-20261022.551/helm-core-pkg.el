;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20261022.551"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "9f62a1d36796c254b0a545d28d3c7bd30fec0395"
  :revdesc "9f62a1d36796"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
