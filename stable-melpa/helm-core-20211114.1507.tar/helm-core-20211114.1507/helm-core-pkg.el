(define-package "helm-core" "20211114.1507" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "34562dbcf57d99845a786c6f0a4d91c2a5c3ba9a")
;; Local Variables:
;; no-byte-compile: t
;; End:
