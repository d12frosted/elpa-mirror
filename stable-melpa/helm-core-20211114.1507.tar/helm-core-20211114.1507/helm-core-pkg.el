(define-package "helm-core" "20211114.1507" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "87c5af3dcf3680062b9523736344c23c543ed8f0")
;; Local Variables:
;; no-byte-compile: t
;; End:
