(define-package "kotlin-ts-mode" "20231026.1000" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "4812049a52d2c1facc640abe0facbbe6aeaa1902" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
