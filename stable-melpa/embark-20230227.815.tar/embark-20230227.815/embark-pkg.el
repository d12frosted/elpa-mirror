(define-package "embark" "20230227.815" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "da144277663d761a22e0425117528b19b4fd43ba" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
