;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "20260820.2207"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "bf090daf2942968d9523e25bcd3bbad22f8079bb"
  :revdesc "bf090daf2942"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
