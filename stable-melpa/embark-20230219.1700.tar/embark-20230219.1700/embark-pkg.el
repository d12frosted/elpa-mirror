(define-package "embark" "20230219.1700" "Conveniently act on minibuffer completions"
  '((emacs "27.1")
    (compat "29.1.3.4"))
  :commit "8e7c53a8ec6969a8d54a22c7cb76f15e2e7fa3f9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
