;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260805.802"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ba802e9128444ef9bb94ce382139b17a0db08cb8"
  :revdesc "ba802e912844"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
