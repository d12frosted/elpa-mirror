(define-package "org-roam-bibtex" "20221104.2139" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "2.2.0")
    (bibtex-completion "2.0.0"))
  :commit "3810ddcd9d69ab27a40d5ba88b553df8db1b4884" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
