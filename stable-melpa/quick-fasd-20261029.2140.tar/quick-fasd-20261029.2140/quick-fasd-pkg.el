;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20261029.2140"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "e473c802ae7f98f4c022de2581f2988f2852bfb2"
  :revdesc "e473c802ae7f"
  :keywords '("convenience" "files" "tools"))
