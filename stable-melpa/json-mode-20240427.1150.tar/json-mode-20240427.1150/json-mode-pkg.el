(define-package "json-mode" "20240427.1150" "Major mode for editing JSON files"
  '((json-snatcher "1.0.0")
    (emacs "24.4"))
  :commit "9a46569f81c048ce2b7b683cc0b3836f1c160b64" :authors
  '(("Josh Johnston")
    ("taku0"))
  :maintainers
  '(("Josh Johnston"))
  :maintainer
  '("Josh Johnston")
  :url "https://github.com/joshwnj/json-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
