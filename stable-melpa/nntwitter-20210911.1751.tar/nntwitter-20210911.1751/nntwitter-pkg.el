(define-package "nntwitter" "20210911.1751" "Gnus Backend For Twitter"
  '((emacs "25.1")
    (dash "20190401")
    (anaphora "20180618")
    (request "20190819"))
  :commit "a802ef9b589dda41bcb5d6cfce2faf8948c20c8c" :keywords
  '("news")
  :url "https://github.com/dickmao/nntwitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
