;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "php-mode" "20260824.1843"
  "Major mode for editing PHP code."
  '((emacs "27.1"))
  :url "https://github.com/emacs-php/php-mode"
  :commit "3d57e94aa7ec2b94c6b0f39d39a70c79c7326e25"
  :revdesc "3d57e94aa7ec"
  :keywords '("languages" "php")
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
