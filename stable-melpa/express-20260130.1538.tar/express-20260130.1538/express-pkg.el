;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "express" "20260130.1538"
  "Alternatives to `message'."
  '((emacs        "24.3")
    (string-utils "0.3.2"))
  :url "http://github.com/rolandwalker/express"
  :commit "0841be4795c1a7d05108df1c49585dd16f52cc48"
  :revdesc "0841be4795c1"
  :keywords '("extensions" "message" "interface")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
