;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-aibo" "20250226.947"
  "An AI Writing Assistant."
  '((emacs "27.1")
    (gptel "0.9.7"))
  :url "https://github.com/dolmens/gptel-aibo"
  :commit "0ff632104fcd0b3b7079f00441393c305ca02ce2"
  :revdesc "0ff632104fcd"
  :keywords '("emacs" "tools" "editing" "gptel" "ai" "assistant" "code-completion" "productivity")
  :authors '(("Sun Yi Ming" . "dolmens@gmail.com"))
  :maintainers '(("Sun Yi Ming" . "dolmens@gmail.com")))
