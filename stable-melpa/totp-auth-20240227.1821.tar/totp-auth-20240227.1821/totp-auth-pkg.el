(define-package "totp-auth" "20240227.1821" "RFC6238 TOTP"
  '((emacs "27.1")
    (base32 "0.1"))
  :commit "927257e97a602b6979a75028e8417bf1499582d4" :authors
  '(("Vivek Das Mohapatra" . "vivek@etla.org"))
  :maintainers
  '(("Vivek Das Mohapatra" . "vivek@etla.org"))
  :maintainer
  '("Vivek Das Mohapatra" . "vivek@etla.org")
  :keywords
  '("2fa" "two-factor" "totp" "otp" "password" "comm")
  :url "https://gitlab.com/fledermaus/totp.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
