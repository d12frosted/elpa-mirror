;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sekka" "20260414.1258"
  "Pure Elisp Japanese IME inspired by SKK."
  '((emacs "25.1")
    (popup "0.5.2"))
  :url "https://github.com/kiyoka/sekka"
  :commit "d55f6df4ef13090b7c556d6791c91a24c9bb107b"
  :revdesc "d55f6df4ef13"
  :keywords '("i18n")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
