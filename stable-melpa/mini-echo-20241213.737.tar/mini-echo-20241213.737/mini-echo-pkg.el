;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mini-echo" "20241213.737"
  "Echo buffer status in minibuffer window."
  '((emacs          "29.1")
    (dash           "2.19.1")
    (hide-mode-line "1.0.3"))
  :url "https://github.com/liuyinz/mini-echo.el"
  :commit "bac89f0554bcb70f8f87ec11ca0db9fd689ee219"
  :revdesc "bac89f0554bc"
  :keywords '("frames")
  :authors '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers '(("liuyinz" . "liuyinz95@gmail.com")))
