(define-package "loopy" "20240309.252" "A looping macro"
  '((emacs "27.1")
    (map "3.3.1")
    (seq "2.22")
    (compat "29.1.3"))
  :commit "0e08afc6fe8ab24ecfb7d975e85723ebe146de9a" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
