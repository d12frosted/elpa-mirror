;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20250604.2146"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/casual"
  :commit "5ed2c8d5a1f9dd8d45206955e7aedb436d05f05c"
  :revdesc "5ed2c8d5a1f9"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
