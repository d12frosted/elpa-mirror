;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20251017.611"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "96beaffb737a80b9a8e0ad00773d443ae29a1e34"
  :revdesc "96beaffb737a"
  :keywords '("languages"))
