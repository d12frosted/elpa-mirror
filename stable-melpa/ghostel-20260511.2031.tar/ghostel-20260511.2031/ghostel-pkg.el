;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260511.2031"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "148e699d889d02aefb5b2ab13e70a7204cbe79cf"
  :revdesc "148e699d889d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
