;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260301.1455"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "a44b87b3efc614ecc4ee82972036b198f8db986f"
  :revdesc "a44b87b3efc6"
  :keywords '("hypermedia"))
