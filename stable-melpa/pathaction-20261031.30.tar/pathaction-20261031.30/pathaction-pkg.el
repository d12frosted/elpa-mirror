;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20261031.30"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "72876dbbd48508cd00681657a37ee0dafd543dcc"
  :revdesc "72876dbbd485"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
