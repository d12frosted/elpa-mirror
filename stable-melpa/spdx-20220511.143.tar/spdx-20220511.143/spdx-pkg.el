(define-package "spdx" "20220511.143" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "701e7c49c38babaa2b2071febd2b112fef600683" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
