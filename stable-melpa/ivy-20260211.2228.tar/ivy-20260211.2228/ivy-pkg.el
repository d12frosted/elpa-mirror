;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy" "20260211.2228"
  "Incremental Vertical completYon."
  '((emacs "24.5"))
  :url "https://github.com/abo-abo/swiper"
  :commit "7c4fa07ea806e6875e55427a6abedbac28a82bd9"
  :revdesc "7c4fa07ea806"
  :keywords '("matching")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
