(define-package "spdx" "20230127.116" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "0b4a7d8b761c553c4380e9a881e69276213172fc" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
