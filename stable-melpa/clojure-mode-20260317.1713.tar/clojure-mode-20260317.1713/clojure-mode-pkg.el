;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260317.1713"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "b3d29761aac3984b2840c30e36af884fea74574d"
  :revdesc "b3d29761aac3"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
