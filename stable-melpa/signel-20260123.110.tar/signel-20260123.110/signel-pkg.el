;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "signel" "20260123.110"
  "Signal client for Emacs via signal-cli JSON-RPC."
  '((emacs "27.1"))
  :url "https://github.com/keenban/signel"
  :commit "598766a0df19f69a5d3fe8c4d2817b72a8996500"
  :revdesc "598766a0df19"
  :authors '(("Keenan Salandy" . "keenan@salandy.dev"))
  :maintainers '(("Keenan Salandy" . "keenan@salandy.dev")))
