;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orderless" "20261128.1159"
  "Completion style for matching regexps in any order."
  '((emacs  "27.1")
    (compat "31"))
  :url "https://github.com/oantolin/orderless"
  :commit "4ca773f20884ce49d142bd9f45da067edb415473"
  :revdesc "4ca773f20884"
  :keywords '("matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
