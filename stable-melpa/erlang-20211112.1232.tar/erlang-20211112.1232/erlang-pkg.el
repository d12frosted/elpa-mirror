(define-package "erlang" "20211112.1232" "Erlang major mode"
  '((emacs "24.1"))
  :commit "beccfcc8fa6c5528ea6fec0abc602de12946967f" :authors
  '(("Anders Lindgren"))
  :maintainer
  '("Anders Lindgren")
  :keywords
  '("erlang" "languages" "processes"))
;; Local Variables:
;; no-byte-compile: t
;; End:
