;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit" "20260717.1740"
  "Support for Org links to Magit buffers."
  '((emacs    "29.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (magit    "4.6")
    (org      "9.8"))
  :url "https://github.com/magit/orgit"
  :commit "47b3568fce775c756fb5bb3545c2edd48b8e2fc1"
  :revdesc "47b3568fce77"
  :keywords '("hypermedia" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.orgit@jonas.bernoulli.dev")))
