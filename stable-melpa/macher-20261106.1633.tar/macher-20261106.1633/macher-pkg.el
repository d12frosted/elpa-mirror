;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20261106.1633"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "443c3a12d2c9bc808d10cd3d81f1319bcef66b37"
  :revdesc "443c3a12d2c9"
  :keywords '("convenience" "gptel" "llm")
  :authors '(("Kevin Montag" . "https://github.com/kmontag"))
  :maintainers '(("Kevin Montag" . "https://github.com/kmontag")))
