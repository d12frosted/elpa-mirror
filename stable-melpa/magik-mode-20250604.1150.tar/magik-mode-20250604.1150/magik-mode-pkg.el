;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250604.1150"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "da0448581fa9c1fa6c85738d7f591a300492d874"
  :revdesc "da0448581fa9"
  :keywords '("languages"))
