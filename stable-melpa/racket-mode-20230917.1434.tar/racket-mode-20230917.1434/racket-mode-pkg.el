(define-package "racket-mode" "20230917.1434" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "363246ac70b48f18d35c393a581e740663a4abed" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
