(define-package "smudge" "20231213.2105" "Control the Spotify app"
  '((emacs "27.1")
    (simple-httpd "20230821.1458")
    (request "0.3")
    (oauth2 "0.16"))
  :commit "43812b705f967d2d8bc7c281debd7a57dc2fc4ba" :keywords
  '("multimedia" "music" "spotify" "smudge")
  :url "https://github.com/danielfm/smudge")
;; Local Variables:
;; no-byte-compile: t
;; End:
