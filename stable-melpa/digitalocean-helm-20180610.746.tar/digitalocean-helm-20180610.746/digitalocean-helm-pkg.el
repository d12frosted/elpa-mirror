;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "digitalocean-helm" "20180610.746"
  "Create and manipulate digitalocean droplets."
  '((emacs        "24.3")
    (helm         "2.5")
    (digitalocean "0.1"))
  :url "https://gitlab.com/olymk2/digitalocean-api"
  :commit "b125c9882eded7d73ec109d152b26625f333440b"
  :revdesc "b125c9882ede"
  :keywords '("processes" "tools")
  :authors '(("Oliver Marks" . "oly@digitaloctave.com"))
  :maintainers '(("Oliver Marks" . "oly@digitaloctave.com")))
