;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mxf-view" "20180501.740"
  "Simple MXF viewer."
  '((emacs "25"))
  :url "https://github.com/t-suwa/mxf-view"
  :commit "c4825f35fad81c4624a2fcaea95cc605addf5cbc"
  :revdesc "c4825f35fad8"
  :keywords '("data" "multimedia")
  :authors '(("Tomotaka SUWA" . "tomotaka.suwa@gmail.com"))
  :maintainers '(("Tomotaka SUWA" . "tomotaka.suwa@gmail.com")))
