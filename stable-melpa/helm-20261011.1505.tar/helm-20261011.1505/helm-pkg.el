;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20261011.1505"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.7")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "eb7f3a91146d07c4c06cf7eed5efd4a30c289807"
  :revdesc "eb7f3a91146d"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help" "package")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
