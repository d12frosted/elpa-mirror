;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "danneskjold-theme" "20260311.2056"
  "Beautiful high-contrast Emacs theme."
  ()
  :url "https://github.com/rails-to-cosmos/danneskjold-theme"
  :commit "f9554c4f77394318d320910c7c5551237027cd41"
  :revdesc "f9554c4f7739"
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
