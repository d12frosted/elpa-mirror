(define-package "syslog-mode" "20210819.2049" "Major-mode for viewing log files & strace output"
  '((hide-lines "20130623")
    (ov "20150311"))
  :commit "014d78269daa99937fb4fa8f5d34e2b3eb368a5f" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
