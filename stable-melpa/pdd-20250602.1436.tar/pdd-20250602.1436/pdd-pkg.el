;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250602.1436"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "aab8a55a55845b9903ca59ed300734e6f1302ad2"
  :revdesc "aab8a55a5584"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
