(define-package "modus-themes" "20210528.2052" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "8ce97d81fd9be9ebdcf9fef1469590b8ea3ca084" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
