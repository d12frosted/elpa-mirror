(define-package "apdl-mode" "20210916.1533" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "d36fc8a8142201f4b7e0671a1f20164a0a7752df" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
