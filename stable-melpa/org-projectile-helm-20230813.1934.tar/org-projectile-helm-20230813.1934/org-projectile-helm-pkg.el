(define-package "org-projectile-helm" "20230813.1934" "helm functions for org-projectile"
  '((org-projectile "1.0.0")
    (helm "2.3.1")
    (emacs "25"))
  :commit "07a9e561f043cfa143f0f8f12a502c229ee96ae4" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org" "projectile" "todo" "helm" "outlines")
  :url "https://github.com/IvanMalison/org-projectile")
;; Local Variables:
;; no-byte-compile: t
;; End:
