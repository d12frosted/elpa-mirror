;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260425.817"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "25bc9a8f77509ed9227818a5bc3f86301ad78153"
  :revdesc "25bc9a8f7750")
