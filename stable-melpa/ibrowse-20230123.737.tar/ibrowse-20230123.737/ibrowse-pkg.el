(define-package "ibrowse" "20230123.737" "Interact with your browser"
  '((emacs "27.1"))
  :commit "b42685528d7bb2ca968fbf536d8745838e633828" :authors
  '(("Nicolas Graves" . "ngraves@ngraves.fr"))
  :maintainer
  '("Nicolas Graves" . "ngraves@ngraves.fr")
  :keywords
  '("comm" "data" "files" "tools")
  :url "https://git.sr.ht/~ngraves/ibrowse.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
