(define-package "po-mode" "20230309.2313" "major mode for GNU gettext PO files" 'nil :commit "e70aab72a6331bd55f69893fa152be80c44d1bf6" :keywords
  '("i18n" "gettext"))
;; Local Variables:
;; no-byte-compile: t
;; End:
