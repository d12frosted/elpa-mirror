;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-wild-notifier" "20260127.533"
  "Customizable org-agenda notifications."
  '((alert "1.2")
    (async "1.9.3")
    (dash  "2.18.0")
    (emacs "27.1"))
  :url "https://github.com/emacsorphanage/org-wild-notifier.el"
  :commit "9211d14128a1097f78081dd7f8ba849671604575"
  :revdesc "9211d14128a1"
  :keywords '("calendar" "convenience")
  :authors '(("Artem Khramov" . "akhramov+emacs@pm.me"))
  :maintainers '(("Artem Khramov" . "akhramov+emacs@pm.me")))
