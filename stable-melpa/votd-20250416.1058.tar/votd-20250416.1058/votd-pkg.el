;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "votd" "20250416.1058"
  "Bible Verse Of The Day."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/votd"
  :commit "ee1466b21cff9188d61f77703ef2bb8285cbb6fb"
  :revdesc "ee1466b21cff"
  :keywords '("convenience" "comm" "hypermedia"))
