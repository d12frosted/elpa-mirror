(define-package "osm" "20230405.1939" "OpenStreetMap viewer"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "b3d90704b4e3caa5bf94216124ecdb9f9ae15207" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
