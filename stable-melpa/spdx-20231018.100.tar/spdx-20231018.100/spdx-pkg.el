(define-package "spdx" "20231018.100" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "8381f01a0a24274942170e1d746794cc26989905" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
