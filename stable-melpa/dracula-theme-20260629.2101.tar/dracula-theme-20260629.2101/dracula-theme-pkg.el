;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dracula-theme" "20260629.2101"
  "Dracula Theme."
  '((emacs "24.3"))
  :url "https://github.com/dracula/emacs"
  :commit "fa562443129993e3408ea300595b230874da33db"
  :revdesc "fa5624431299"
  :maintainers '(("tienne Deparis" . "etienne@depar.is")))
