(define-package "borg" "20211111.2352" "assimilate Emacs packages as Git submodules"
  '((emacs "26")
    (epkg "3.3.0")
    (magit "3.0.0"))
  :commit "bcae8f00dc60eca1a7cdd837e9be3b0fc942097d" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
