(define-package "embark" "20220505.615" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "f29dc5a0a26a077918b75f2b36e778a45e6ec7e1" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
