(define-package "embark" "20220505.615" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "80ff7d105afc090817c4162ec021758e586272f2" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
