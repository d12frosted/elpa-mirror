(define-package "csound-mode" "20220919.1033" "A major mode for interacting and coding Csound"
  '((emacs "25")
    (shut-up "0.3.2")
    (multi "2.0.1")
    (dash "2.16.0")
    (highlight "0"))
  :commit "eae7a91c42d28a7a2a88fbd3cc02a0fc7b4a62af" :authors
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainer
  '("Hlöðver Sigurðsson" . "hlolli@gmail.com")
  :url "https://github.com/hlolli/csound-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
