(define-package "yeetube" "20231003.1112" "YouTube Front End"
  '((emacs "29.1"))
  :commit "04b47217d03da9892c94ca5105c28db81be89905" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.com/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
