;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250623.2329"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "5c50e723f54b30f0b65eca1becddbe6af2e58153"
  :revdesc "5c50e723f54b"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
