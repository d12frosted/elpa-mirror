;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "system-idle" "20260215.1611"
  "Poll the system-wide idle time."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/system-idle"
  :commit "74ae4437f2b151aaada98fd5fa99177b21394b7c"
  :revdesc "74ae4437f2b1"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
