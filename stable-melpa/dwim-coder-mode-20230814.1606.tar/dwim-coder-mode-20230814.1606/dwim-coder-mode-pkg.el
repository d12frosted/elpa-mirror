(define-package "dwim-coder-mode" "20230814.1606" "DWIM keybindings for C, Python, Rust, and more"
  '((emacs "29"))
  :commit "d6b195fffc9e8083a2f245b52640067119015e3e" :authors
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainers
  '(("Mohammed Sadiq" . "sadiq@sadiqpk.org"))
  :maintainer
  '("Mohammed Sadiq" . "sadiq@sadiqpk.org")
  :keywords
  '("convenience" "hacks")
  :url "https://sadiqpk.org/projects/dwim-coder-mode.html")
;; Local Variables:
;; no-byte-compile: t
;; End:
