;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250720.502"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "c6f12073f341a8d00a5c0b10a25a9f5f86da1f43"
  :revdesc "c6f12073f341"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
