;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wavedrom-mode" "20260715.1713"
  "WaveDrom Integration."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/wavedrom-mode"
  :commit "5d59b7ca2bdf355d9d2f00d563acf4e17e8ba8b9"
  :revdesc "5d59b7ca2bdf"
  :keywords '("fpga" "asic" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
