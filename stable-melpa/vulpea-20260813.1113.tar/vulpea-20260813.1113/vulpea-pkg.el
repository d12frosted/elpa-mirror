;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260813.1113"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "ef02a22bf09b4336998da495da1a4faa0991cbbe"
  :revdesc "ef02a22bf09b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
