;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-cmd" "20260906.2126"
  "Send commands from programs running in term.el."
  '((emacs "27.2")
    (dash  "2.12.0")
    (f     "0.18.2"))
  :url "https://codeberg.org/calliecameron/term-cmd"
  :commit "aaa31894c75ed7f5036e510113909cff0fd88c0f"
  :revdesc "aaa31894c75e"
  :keywords '("processes")
  :authors '(("Callie Cameron" . "callie@calliecameron.com"))
  :maintainers '(("Callie Cameron" . "callie@calliecameron.com")))
