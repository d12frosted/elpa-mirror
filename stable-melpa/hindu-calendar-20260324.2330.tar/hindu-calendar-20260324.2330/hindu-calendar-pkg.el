;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hindu-calendar" "20260324.2330"
  "Astronomical traditional Hindu calendar (panchanga)."
  '((emacs "24.3"))
  :url "https://github.com/bdsatish/hindu-calendar"
  :commit "8589e9cafb642e53d788ced049c361e1ce1a84b6"
  :revdesc "8589e9cafb64"
  :keywords '("calendar" "panchanga" "hindu" "indian")
  :authors '(("B.D.Satish" . "bdsatish@gmail.com"))
  :maintainers '(("B.D.Satish" . "bdsatish@gmail.com")))
