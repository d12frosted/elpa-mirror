;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyim" "20261029.35"
  "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "27.1")
    (async "1.6")
    (xr    "1.13"))
  :url "https://github.com/tumashu/pyim"
  :commit "fa9044a9284ecb6136a976338b546247521feb3e"
  :revdesc "fa9044a9284e"
  :keywords '("convenience" "chinese" "pinyin" "input-method")
  :authors '(("Ye Wenbin" . "wenbinye@163.com")
             ("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
