;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-roam-ql" "20261105.2128"
  "Interface to query and view results from org-roam."
  '((emacs         "28")
    (org-roam      "2.2.0")
    (s             "1.12.0")
    (magit-section "3.3.0")
    (transient     "0.4")
    (dash          "2.0"))
  :url "https://github.com/ahmed-shariff/org-roam-ql"
  :commit "04d9278296004088606a48bbda9aa611d84ec964"
  :revdesc "04d927829600")
