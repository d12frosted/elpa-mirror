;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20250410.747"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "http://github.com/clojure-emacs/clojure-ts-mode"
  :commit "897659a3098c8e56585890f312f87f14598b9c28"
  :revdesc "897659a3098c"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Danny Freeman" . "danny@dfreeman.email")))
