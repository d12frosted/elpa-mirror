;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "window-end-visible" "20140508.2041"
  "Find the last visible point in a window."
  ()
  :url "https://github.com/rolandwalker/window-end-visible"
  :commit "f0ed55aa5f7875634fb4c8b6fbaa93633bc57d85"
  :revdesc "f0ed55aa5f78"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
