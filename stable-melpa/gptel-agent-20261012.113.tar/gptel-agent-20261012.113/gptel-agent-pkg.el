;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20261012.113"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "5ed66625b3ba9ad09cb7d4aa3746ab8ec5eb45ba"
  :revdesc "5ed66625b3ba"
  :keywords '("comm"))
