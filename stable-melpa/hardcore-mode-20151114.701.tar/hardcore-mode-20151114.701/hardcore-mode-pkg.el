;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hardcore-mode" "20151114.701"
  "Disable arrow keys + optionally backspace and return."
  ()
  :url "https://github.com/magnars/hardcore-mode.el"
  :commit "b1dda19692b4a7a58a689e81784a9b35be39e70d"
  :revdesc "b1dda19692b4"
  :authors '(("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Magnar Sveen" . "magnars@gmail.com")))
