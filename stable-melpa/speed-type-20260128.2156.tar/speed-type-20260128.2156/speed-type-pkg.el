;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260128.2156"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "63b356d6b0380e13b65136cc502ef08a250096d0"
  :revdesc "63b356d6b038"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
