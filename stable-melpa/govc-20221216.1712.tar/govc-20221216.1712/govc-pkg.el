(define-package "govc" "20221216.1712" "Interface to govc for managing VMware ESXi and vCenter"
  '((emacs "24.3")
    (dash "1.5.0")
    (s "1.9.0")
    (magit-popup "2.0.50")
    (json-mode "1.6.0"))
  :commit "c82a709c50c0cd1ae560dd4c8da2d5b266114c50" :authors
  '(("The govc developers"))
  :maintainers
  '(("The govc developers"))
  :maintainer
  '("The govc developers")
  :keywords
  '("convenience")
  :url "https://github.com/vmware/govmomi/tree/main/govc/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
