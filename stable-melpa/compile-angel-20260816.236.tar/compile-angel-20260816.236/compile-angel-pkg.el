;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260816.236"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "8bf2bf6ccf9f85634ef7b096c6284d2f9065790a"
  :revdesc "8bf2bf6ccf9f"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
