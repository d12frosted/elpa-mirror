;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imake" "20260601.1510"
  "Simple, opinionated make target runner."
  '((emacs  "28.1")
    (compat "31.0"))
  :url "https://github.com/tarsius/imake"
  :commit "19447819b9e27421fff8381873489938978d220e"
  :revdesc "19447819b9e2"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.imake@jonas.bernoulli.dev")))
