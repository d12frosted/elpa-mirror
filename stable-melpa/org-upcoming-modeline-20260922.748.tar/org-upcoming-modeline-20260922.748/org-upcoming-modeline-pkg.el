;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-upcoming-modeline" "20260922.748"
  "Show next org event in mode line."
  '((emacs  "26.1")
    (ts     "0.2")
    (org-ql "0.6"))
  :url "https://github.com/unhammer/org-upcoming-modeline"
  :commit "1ca60020e0e92eddb1c4fed4018a4c80441fdefa"
  :revdesc "1ca60020e0e9"
  :keywords '("convenience" "calendar")
  :authors '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org"))
  :maintainers '(("Kevin Brubeck Unhammer" . "unhammer@fsfe.org")))
