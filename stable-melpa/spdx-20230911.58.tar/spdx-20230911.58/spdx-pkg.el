(define-package "spdx" "20230911.58" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "242e5df5adc0721f97d8b5fe161a2e0d2fed0aa7" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
