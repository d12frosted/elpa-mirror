;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "literate-elisp" "20260728.123"
  "Load Emacs Lisp code blocks from Org files."
  '((emacs "30.1"))
  :url "https://github.com/jingtaozf/literate-elisp"
  :commit "423df58f7e4565f842b9a220af04abce3c3dc818"
  :revdesc "423df58f7e45"
  :keywords '("lisp" "docs" "extensions" "tools")
  :authors '(("Jingtao Xu" . "jingtaozf@gmail.com"))
  :maintainers '(("Jingtao Xu" . "jingtaozf@gmail.com")))
