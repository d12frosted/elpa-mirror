;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260227.1704"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "f76cac7384fddca9f9033dccc128185a3992fd24"
  :revdesc "f76cac7384fd"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
