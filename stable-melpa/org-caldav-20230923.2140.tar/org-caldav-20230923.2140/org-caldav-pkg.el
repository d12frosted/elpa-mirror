(define-package "org-caldav" "20230923.2140" "Sync org files with external calendar through CalDAV"
  '((emacs "26.3")
    (org "9.1"))
  :commit "2bbd36a2e6917e0f003ddc0192c5f3cc1f1d29ec" :authors
  '(("David Engster" . "deng@randomsample.de"))
  :maintainers
  '(("David Engster" . "deng@randomsample.de"))
  :maintainer
  '("David Engster" . "deng@randomsample.de")
  :keywords
  '("calendar" "caldav")
  :url "https://github.com/dengste/org-caldav/")
;; Local Variables:
;; no-byte-compile: t
;; End:
