;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-lark" "20260519.225"
  "Export Lark docs to Org."
  '((emacs "27.1"))
  :url "https://github.com/bbw9n/org-lark"
  :commit "15becd41979df4a03f8b6628b296386addbb7567"
  :revdesc "15becd41979d"
  :keywords '("outlines" "hypermedia" "tools")
  :authors '(("bbw9n" . "bbw9nio@gmail.com"))
  :maintainers '(("bbw9n" . "bbw9nio@gmail.com")))
