;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250323.2145"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "993d875ace54df546258b5f2c0e690d36c3f0d43"
  :revdesc "993d875ace54"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
