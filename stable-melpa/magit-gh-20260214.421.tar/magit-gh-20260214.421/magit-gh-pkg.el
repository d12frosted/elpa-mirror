;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gh" "20260214.421"
  "GitHub CLI integration for Magit."
  '((emacs     "29.1")
    (magit     "4.0.0")
    (transient "0.5.0"))
  :url "https://github.com/jonathanchu/magit-gh"
  :commit "522570f327e0e000a6d2ad6b1b53a30db5e1a430"
  :revdesc "522570f327e0"
  :keywords '("git" "tools" "vc" "github")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
