(define-package "tree-sitter" "20210328.434" "Incremental parsing system"
  '((emacs "25.1")
    (tsc "0.15.1"))
  :commit "4d453aed51d78fb733d74be22ed201d901773df9" :authors
  '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainer
  '("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com")
  :keywords
  '("languages" "tools" "parsers" "tree-sitter")
  :url "https://github.com/ubolonton/emacs-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
