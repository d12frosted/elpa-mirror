;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kele" "20251126.253"
  "Spritzy Kubernetes cluster management."
  '((emacs   "29.1")
    (async   "1.9.7")
    (dash    "2.19.1")
    (f       "0.20.0")
    (memoize "0")
    (plz     "0.8.0")
    (s       "1.13.0")
    (yaml    "0.5.1"))
  :url "https://github.com/jinnovation/kele.el"
  :commit "b4815c943d936326032c22504e3de4ed75dc67ab"
  :revdesc "b4815c943d93"
  :keywords '("kubernetes" "tools")
  :authors '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainers '(("Jonathan Jin" . "me@jonathanj.in")))
