(define-package "project-tab-groups" "20220720.2109" "Support a \"one tab group per project\" workflow"
  '((emacs "28.1"))
  :commit "2d348279876f3073176048d903f9672f3c933ca5" :authors
  '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers
  '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainer
  '("Fritz Grabo" . "hello@fritzgrabo.com")
  :keywords
  '("convenience")
  :url "https://github.com/fritzgrabo/project-tab-groups")
;; Local Variables:
;; no-byte-compile: t
;; End:
