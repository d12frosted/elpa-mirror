;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-repeat-by-cron" "20260302.256"
  "An Org mode task repeater based on Cron expressions."
  '((emacs "24.4"))
  :url "https://github.com/TomoeMami/org-repeat-by-cron.el"
  :commit "252b82757d1e96b63ec652773e8efa93c0d477a5"
  :revdesc "252b82757d1e"
  :keywords '("calendar")
  :authors '(("TomoeMami" . "trembleafterme@outlook.com"))
  :maintainers '(("TomoeMami" . "trembleafterme@outlook.com")))
