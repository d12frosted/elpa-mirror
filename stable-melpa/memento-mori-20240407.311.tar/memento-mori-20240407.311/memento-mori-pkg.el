(define-package "memento-mori" "20240407.311" "Reminder of our mortality"
  '((emacs "24.4"))
  :commit "35e74e29d77288b3c0a3028f49f53f8f541f94d9" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Ivan Andrus" . "darthandrus@gmail.com"))
  :maintainer
  '("Ivan Andrus" . "darthandrus@gmail.com")
  :keywords
  '("help")
  :url "https://github.com/gvol/emacs-memento-mori")
;; Local Variables:
;; no-byte-compile: t
;; End:
