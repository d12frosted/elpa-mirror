;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260116.214"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "934763b559686fe6920a5fbcbae2df9d5647c15a"
  :revdesc "934763b55968"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
