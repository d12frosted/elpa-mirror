;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260717.2134"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "3ea7ac9fc6f881ce63e8ab06dc71f4f383016c6f"
  :revdesc "3ea7ac9fc6f8"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
