;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260717.2134"
  "Agentic actions for ekg."
  '((emacs "28.1")
    (ekg   "0.8.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "3ea7ac9fc6f881ce63e8ab06dc71f4f383016c6f"
  :revdesc "3ea7ac9fc6f8"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
