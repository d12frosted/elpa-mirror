;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kotlin-ts-mode" "20260430.1314"
  "A mode for editing Kotlin files based on tree-sitter."
  '((emacs "30.1"))
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode"
  :commit "588764613a45a0baf3adffcd68066991f9e56191"
  :revdesc "588764613a45"
  :authors '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers '(("Alex Figl-Brick" . "alex@alexbrick.me")))
