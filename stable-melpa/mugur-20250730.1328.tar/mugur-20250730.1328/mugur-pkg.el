;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mugur" "20250730.1328"
  "Configurator for QMK compatible keyboards."
  '((emacs    "26.1")
    (s        "1.12.0")
    (anaphora "1.0.4")
    (dash     "2.18.1")
    (cl-lib   "1.0"))
  :url "https://github.com/mihaiolteanu/mugur"
  :commit "ee43cd1ab5ae687882b7d5f3eb05b0e34c3fc0a0"
  :revdesc "ee43cd1ab5ae"
  :keywords '("multimedia")
  :authors '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")))
