(define-package "graphviz-dot-mode" "20200125.1504" "Mode for the dot-language used by graphviz (att)."
  '((emacs "25.0"))
  :commit "80b9c5e7f464c70cfa423e5ee3237581bc69d643" :maintainer
  '("Pieter Pareit" . "pieter.pareit@gmail.com")
  :keywords
  '("mode" "dot" "dot-language" "dotlanguage" "graphviz" "graphs" "att")
  :url "https://ppareit.github.io/graphviz-dot-mode/")
;; Local Variables:
;; no-byte-compile: t
;; End:
