;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "e2wm-term" "20240107.850"
  "Perspective of e2wm.el for work in terminal."
  '((e2wm       "1.2")
    (log4e      "0.2.0")
    (yaxception "1.0.0"))
  :url "https://github.com/aki2o/e2wm-term"
  :commit "4542e52138484933dd99a497ff1b048ea42f9246"
  :revdesc "4542e5213848"
  :keywords '("tools" "window manager")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
