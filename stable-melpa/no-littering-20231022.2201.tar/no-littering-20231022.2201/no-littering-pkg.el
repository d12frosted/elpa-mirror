(define-package "no-littering" "20231022.2201" "Help keeping ~/.config/emacs clean"
  '((emacs "25.1")
    (compat "29.1.4.2"))
  :commit "b8bee95c44eb5b7eb419f1f1436f5ad2bc9d0a24" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("convenience")
  :url "https://github.com/emacscollective/no-littering")
;; Local Variables:
;; no-byte-compile: t
;; End:
