;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "20251130.829"
  "Run REPLs in a terminal backend."
  '((emacs "29.1"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "52e7470fbd91797a44ba5414e15d1f833a5abae8"
  :revdesc "52e7470fbd91"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
