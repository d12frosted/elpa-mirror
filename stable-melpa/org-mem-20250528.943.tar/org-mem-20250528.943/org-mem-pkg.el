;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250528.943"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "2751f2879de249a74683a4883b42fec80433d823"
  :revdesc "2751f2879de2"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
