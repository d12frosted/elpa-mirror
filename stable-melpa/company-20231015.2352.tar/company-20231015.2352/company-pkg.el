(define-package "company" "20231015.2352" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "98d8894271b6a7aed85d279f70098ba6cbae10c7" :authors
  '(("Nikolaj Schumacher"))
  :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
