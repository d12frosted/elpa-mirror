;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20260908.1828"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "1a1e0e3a5e5600138d9205291e2d9befdb269bea"
  :revdesc "1a1e0e3a5e56"
  :keywords '("languages" "lisp" "slime"))
