;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260403.836"
  "XMPP/Jabber client."
  '((emacs "29.1")
    (fsm   "0.2.0"))
  :url "https://git.thanosapollo.org/emacs-jabber"
  :commit "0f430137a3082f79e8c0ee292b7ee8dc5d80e73a"
  :revdesc "0f430137a308"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
