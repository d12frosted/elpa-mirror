;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-god-toggle" "20260519.1626"
  "Toggle Evil and God Mode."
  '((emacs    "28.1")
    (evil     "1.0.8")
    (god-mode "2.12.0"))
  :url "https://github.com/jam1015/evil-god-toggle"
  :commit "30f6dee8421cbd2d014eafa24657f6e510e3e6ff"
  :revdesc "30f6dee8421c"
  :keywords '("convenience" "emulation" "evil" "god-mode")
  :authors '(("Jordan Mandel" . "jordan.mandel@live.com"))
  :maintainers '(("Jordan Mandel" . "jordan.mandel@live.com")))
