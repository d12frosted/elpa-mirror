;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-lib-babel" "20180510.1324"
  "Helm insertion of babel function references."
  '((cl-lib "0.5")
    (helm   "1.9.2")
    (emacs  "24.4"))
  :url "https://github.com/dfeich/helm-lib-babel.el"
  :commit "41bc0cdea8a604c6c8dc83ed5066644d33688fad"
  :revdesc "41bc0cdea8a6"
  :keywords '("convenience")
  :authors '(("Derek Feichtinger" . "dfeich@gmail.com"))
  :maintainers '(("Derek Feichtinger" . "dfeich@gmail.com")))
