;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260103.102"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "1ffac67a2de404270b2fbb1a604bdf778d63f253"
  :revdesc "1ffac67a2de4"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
