(define-package "starhugger" "20230717.1036" "Hugging Face/AI-powered text & code completion client"
  '((emacs "28.2")
    (compat "29.1.4.0")
    (dash "2.18.0")
    (s "1.13.1")
    (spinner "1.7.4"))
  :commit "8b429cb2f7b5ad0d9c89db4577df5c7f8f5d8f6b" :keywords
  '("completion" "convenience" "languages")
  :url "https://gitlab.com/daanturo/starhugger.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
