(define-package "dashboard" "20221204.415" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "87778851160a07c831197df83e4d399f671ea3c6" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
