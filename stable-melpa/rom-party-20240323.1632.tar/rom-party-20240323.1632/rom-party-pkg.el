(define-package "rom-party" "20240323.1632" "Rendition of jklm.fun's \"Bomb Party\" game"
  '((emacs "28")
    (dash "2.17.0")
    (f "0.2.0")
    (s "1.12.0")
    (ht "2.3")
    (extmap "1.3")
    (compat "29.1.4.4")
    (async "1.9.7"))
  :commit "a60980be9a5faefc325e6fd4cc0c719149000298" :authors
  '(("Laurence Warne"))
  :maintainers
  '(("Laurence Warne"))
  :maintainer
  '("Laurence Warne")
  :url "https://github.com/LaurenceWarne/rom-party.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
