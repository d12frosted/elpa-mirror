;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modelica-mode" "20230508.1020"
  "Major mode for editing Modelica files."
  '((emacs "27.1"))
  :url "https://github.com/modelica-tools/modelica-mode"
  :commit "7064a4abdae68fc074a85a2e7c159e067c44c0e1"
  :revdesc "7064a4abdae6"
  :keywords '("languages" "continuous system modeling"))
