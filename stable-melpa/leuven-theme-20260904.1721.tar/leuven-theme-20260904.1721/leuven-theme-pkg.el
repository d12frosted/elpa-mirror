;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "20260904.1721"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "c696b5b41e32ec23d535f3fcdd0d720678d90909"
  :revdesc "c696b5b41e32"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
