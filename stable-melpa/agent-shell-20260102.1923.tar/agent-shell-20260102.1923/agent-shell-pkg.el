;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260102.1923"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "cacbaca4f5f729b612ae22d96118b88564f2bd35"
  :revdesc "cacbaca4f5f7")
