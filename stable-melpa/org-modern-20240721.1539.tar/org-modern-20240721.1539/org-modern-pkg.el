(define-package "org-modern" "20240721.1539" "Modern looks for Org"
  '((emacs "27.1")
    (compat "30"))
  :commit "1074133d9dd1ce4eb6c9ab1d1dbc7b78b3d8733b" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "text")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
