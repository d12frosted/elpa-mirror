(define-package "srfi" "20221116.52" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "689d27ed94254e3a3ce5a104057acc525e68a2ff" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
