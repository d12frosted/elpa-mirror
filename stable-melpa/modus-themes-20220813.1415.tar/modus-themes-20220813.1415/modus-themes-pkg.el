(define-package "modus-themes" "20220813.1415" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "d40d5a5a1edc56d6d5a91f7ebd9edbf296e3469c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
