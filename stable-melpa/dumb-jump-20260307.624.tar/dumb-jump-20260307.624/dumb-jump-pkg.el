;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260307.624"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "26.1"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "2ee9d3617fb9612ad4b0e098231253ed567a9069"
  :revdesc "2ee9d3617fb9"
  :keywords '("programming"))
