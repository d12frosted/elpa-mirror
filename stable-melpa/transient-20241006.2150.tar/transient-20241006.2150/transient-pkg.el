;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20241006.2150"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.0.0.0")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "92df5a4f40d08bc61f0d546dd3a693e4ae2c8f92"
  :revdesc "92df5a4f40d0"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
