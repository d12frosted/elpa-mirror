(define-package "bufler" "20231027.1517" "Group buffers into workspaces with programmable rules"
  '((emacs "26.3")
    (burly "0.4pre")
    (dash "2.18")
    (f "0.17")
    (pretty-hydra "0.2.2")
    (magit-section "0.1")
    (map "2.1"))
  :commit "d8d52767b3e0afe00a5166f00897c6d7baea1f90" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/bufler.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
