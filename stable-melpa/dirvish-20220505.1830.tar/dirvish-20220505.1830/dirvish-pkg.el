(define-package "dirvish" "20220505.1830" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "8c55a5e89237b68866f2653e99b5cf746cd58b9e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
