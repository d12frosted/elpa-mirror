(define-package "pyim-wbdict" "20220531.607" "Some wubi dicts for pyim"
  '((pyim "3.7"))
  :commit "7e658fe0dc861433ef23676704b7547ea3a5156b" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/tumashu/pyim-wbdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
