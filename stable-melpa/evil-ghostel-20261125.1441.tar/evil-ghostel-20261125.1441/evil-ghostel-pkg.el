;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20261125.1441"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.64.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "b0330a90b46fde82c47122add00d4440cef35711"
  :revdesc "b0330a90b46f"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
