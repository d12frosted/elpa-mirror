(define-package "immaterial-theme" "20210914.909" "A flexible theme based on material design principles"
  '((emacs "25"))
  :commit "b2b625f690e207bab7b60a23585eba9c2831607a" :authors
  '(("Peter Gardfjäll"))
  :maintainer
  '("Peter Gardfjäll")
  :keywords
  '("themes")
  :url "https://github.com/petergardfjall/emacs-immaterial-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
