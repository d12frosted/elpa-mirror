(define-package "el-spice" "20201013.1729" "Extra spice for emacs lisp programming" 'nil :commit "a1adde201ee10881b522e67aa2c605378943a28d" :authors
  '(("Vedang Manerikar" . "vedang.manerikar@gmail.com"))
  :maintainer
  '("Vedang Manerikar" . "vedang.manerikar@gmail.com")
  :keywords
  '("languages" "extensions")
  :url "https://github.com/vedang/el-spice")
;; Local Variables:
;; no-byte-compile: t
;; End:
