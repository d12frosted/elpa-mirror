(define-package "elisp-autofmt" "20230808.1344" "Emacs lisp auto-format"
  '((emacs "29.1"))
  :commit "8096cea983af9b067b3fafcb36a3e95560401a37" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
