(define-package "w3m" "20210902.2305" "an Emacs interface to w3m" 'nil :commit "c3edb8db0aafce9b3af4b587e3edc52a6656c159" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
