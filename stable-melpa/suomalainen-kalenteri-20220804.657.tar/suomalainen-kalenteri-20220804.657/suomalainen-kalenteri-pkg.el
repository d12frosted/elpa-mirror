(define-package "suomalainen-kalenteri" "20220804.657" "Finnish national and Christian holidays for calendar" 'nil :commit "8a41d16371ffaface70739ec861709f674b4a94a" :authors
  '(("Teemu Likonen" . "tlikonen@iki.fi"))
  :maintainer
  '("Teemu Likonen" . "tlikonen@iki.fi")
  :keywords
  '("calendar" "holidays" "finnish")
  :url "https://github.com/tlikonen/suomalainen-kalenteri")
;; Local Variables:
;; no-byte-compile: t
;; End:
