;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-cmd" "20260905.1505"
  "Send commands from programs running in term.el."
  '((emacs "27.2")
    (dash  "2.12.0")
    (f     "0.18.2"))
  :url "https://codeberg.org/calliecameron/term-cmd"
  :commit "2c74382c7395fea61a2378bc63e7b774c2a7d0e6"
  :revdesc "2c74382c7395"
  :keywords '("processes")
  :authors '(("Callie Cameron" . "callie@calliecameron.com"))
  :maintainers '(("Callie Cameron" . "callie@calliecameron.com")))
