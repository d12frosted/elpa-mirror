;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261112.1735"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "022dec8c2688bbefa8c61f1cca55ccb8d2f33e13"
  :revdesc "022dec8c2688"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
