;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "russian-calendar" "20260716.1708"
  "Russian holidays and conferences. Updated 2025-09-30."
  '((emacs "29.4"))
  :url "https://github.com/Anoncheg1/emacs-russian-calendar"
  :commit "866716a5a0d9fde508d689ee676116d2018dc5d1"
  :revdesc "866716a5a0d9"
  :keywords '("calendar" "holidays"))
