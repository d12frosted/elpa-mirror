(define-package "imbot" "20210319.126" "Automatic system input method switcher"
  '((emacs "25.1"))
  :commit "0fdc71bfa66ecc1f8a54cdcd2458eb47eab41ecd" :keywords
  '("convenience")
  :url "https://github.com/QiangF/imbot")
;; Local Variables:
;; no-byte-compile: t
;; End:
