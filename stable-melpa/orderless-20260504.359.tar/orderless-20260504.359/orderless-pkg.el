;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orderless" "20260504.359"
  "Completion style for matching regexps in any order."
  '((emacs  "27.1")
    (compat "31"))
  :url "https://github.com/oantolin/orderless"
  :commit "a5e960f5a9a080d982aba86378da1d12641cae5c"
  :revdesc "a5e960f5a9a0"
  :keywords '("matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
