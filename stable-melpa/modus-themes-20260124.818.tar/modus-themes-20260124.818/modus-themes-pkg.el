;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260124.818"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "0f6ce4f8bb1ca7862c6000099183d3c5e68ff91b"
  :revdesc "0f6ce4f8bb1c"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
