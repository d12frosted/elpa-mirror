(define-package "logview" "20230615.1759" "Major mode for viewing log files"
  '((emacs "25.1")
    (datetime "0.6.1")
    (extmap "1.0"))
  :commit "7d89613a29221fcd0064ecb31904a95ec7169342" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("files" "tools")
  :url "https://github.com/doublep/logview")
;; Local Variables:
;; no-byte-compile: t
;; End:
