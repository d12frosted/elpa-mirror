(define-package "merlin" "20210707.901" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "6060708fd70224d4d6540179af5c4aca33d497d2" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
