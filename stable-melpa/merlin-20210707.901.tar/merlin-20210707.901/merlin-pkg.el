(define-package "merlin" "20210707.901" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "a8fa9db9ce3ded131f32d7e97090e876fc4f50dd" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
