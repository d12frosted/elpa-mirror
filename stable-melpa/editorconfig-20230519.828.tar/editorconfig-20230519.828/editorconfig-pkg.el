(define-package "editorconfig" "20230519.828" "EditorConfig Emacs Plugin"
  '((emacs "26.1")
    (nadvice "0.3"))
  :commit "ed760770ed5397120b3d68b69afc0778c48d3a47" :authors
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainers
  '(("EditorConfig Team" . "editorconfig@googlegroups.com"))
  :maintainer
  '("EditorConfig Team" . "editorconfig@googlegroups.com")
  :keywords
  '("convenience" "editorconfig")
  :url "https://github.com/editorconfig/editorconfig-emacs#readme")
;; Local Variables:
;; no-byte-compile: t
;; End:
