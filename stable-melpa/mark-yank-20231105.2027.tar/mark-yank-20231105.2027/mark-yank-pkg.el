;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mark-yank" "20231105.2027"
  "Set region to the last yank."
  '((emacs "24.4"))
  :url "https://github.com/mkleehammer/mark-yank"
  :commit "7207aabe9edd0872ec6d506a58b942b43926c122"
  :revdesc "7207aabe9edd"
  :authors '(("Michael Kleehammer" . "michael@kleehammer.com"))
  :maintainers '(("Michael Kleehammer" . "michael@kleehammer.com")))
