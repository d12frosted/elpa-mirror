(define-package "kiwix" "20210724.1237" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (request "0.3.0")
    (elquery "0.1.0"))
  :commit "71e770ce1e9994cf3e035cbcc7a2f26b1922323c" :authors
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
