;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260808.1056"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "6a4c1a088ae3d8640f6d50794bc772c045ee26aa"
  :revdesc "6a4c1a088ae3"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
