;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mood-one-theme" "20221222.1214"
  "A dark color scheme inspired by the Doom One theme."
  '((emacs "27.1"))
  :url "https://gitlab.com/jessieh/mood-one-theme"
  :commit "dfbc81900737d3382a340feeed24d2bcd9bdedb0"
  :revdesc "dfbc81900737"
  :keywords '("mode-line" "faces")
  :authors '(("Jessie Hildebrandt" . "jessieh.net"))
  :maintainers '(("Jessie Hildebrandt" . "jessieh.net")))
