;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "synaxis" "20260730.1047"
  "Feed reader with SQLite storage."
  '((emacs        "29.1")
    (keymap-popup "0.2.1"))
  :url "https://git.thanosapollo.org/synaxis"
  :commit "5f2edb9b19a2ea0c6e3cfdce1100ab160ca3a552"
  :revdesc "5f2edb9b19a2"
  :keywords '("news" "hypermedia" "rss" "atom")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
