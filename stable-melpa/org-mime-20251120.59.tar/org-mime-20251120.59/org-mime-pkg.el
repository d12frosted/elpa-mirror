;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mime" "20251120.59"
  "Org html export for text/html MIME emails."
  '((emacs "27.1"))
  :url "http://github.com/org-mime/org-mime"
  :commit "6bfc61cebc4bab04f286028f1802dd26b8e96670"
  :revdesc "6bfc61cebc4b"
  :keywords '("mime" "mail" "email" "html")
  :maintainers '(("Chen Bin" . "chenbin.sh@gmail.com")))
