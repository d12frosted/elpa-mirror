;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260701.2203"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "679b113a4890c67fc6df06df38908af3773ba451"
  :revdesc "679b113a4890"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
