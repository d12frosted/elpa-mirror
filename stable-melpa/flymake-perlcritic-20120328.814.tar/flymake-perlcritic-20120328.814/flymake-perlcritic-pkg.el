(define-package "flymake-perlcritic" "20120328.814" "Flymake handler for Perl to invoke Perl::Critic"
  '((flymake "0.3"))
  :commit "a0bc983c6187c03b72a93e78371c391a28321b81" :authors
  '(("Sam Graham <libflymake-perlcritic-emacs BLAHBLAH illusori.co.uk>"))
  :maintainer
  '("Sam Graham <libflymake-perlcritic-emacs BLAHBLAH illusori.co.uk>")
  :url "https://github.com/illusori/emacs-flymake-perlcritic")
;; Local Variables:
;; no-byte-compile: t
;; End:
