(define-package "hyperdrive" "20240430.54" "P2P filesystem"
  '((emacs "28.1")
    (map "3.0")
    (compat "29.1.4.4")
    (plz "0.7.2")
    (persist "0.6")
    (taxy-magit-section "0.13")
    (transient "0.6.0"))
  :commit "5fcd2eb57f529dc8f8cfbce0d9a2ba544150dd14" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
