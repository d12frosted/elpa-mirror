;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260102.2051"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "b3c0dfc31fcab354d9d48b9e46364535eee47cc7"
  :revdesc "b3c0dfc31fca"
  :keywords '("convenience" "comm" "hypermedia"))
