;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251021.923"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "bfc134bb94eea89350e2cdb1c1896527da99ca49"
  :revdesc "bfc134bb94ee"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
