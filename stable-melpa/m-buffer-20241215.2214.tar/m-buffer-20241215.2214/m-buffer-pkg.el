;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "m-buffer" "20241215.2214"
  "List-Oriented, Functional Buffer Manipulation."
  '((seq "2.14"))
  :url "https://github.com/phillord/m-buffer-el"
  :commit "5e7714835b2289f61dad24c0b5cf98d28fc313b0"
  :revdesc "5e7714835b22"
  :authors '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainers '(("Phillip Lord" . "phillip.lord@russet.rg.uk")))
