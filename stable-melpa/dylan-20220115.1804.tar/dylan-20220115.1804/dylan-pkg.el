(define-package "dylan" "20220115.1804" "Dylan editing modes"
  '((emacs "25.1"))
  :commit "9d2891e3e06405b75072d296f385fa795aeb9835" :url "https://opendylan.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
