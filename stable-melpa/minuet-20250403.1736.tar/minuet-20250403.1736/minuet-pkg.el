;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20250403.1736"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "03726e4605757b43ad9bf5cfbee9b2e2e68c7622"
  :revdesc "03726e460575"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
