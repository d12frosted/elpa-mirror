;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260709.1227"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "8f96f68c9de25e125e1095006316bcb48695dbca"
  :revdesc "8f96f68c9de2"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
