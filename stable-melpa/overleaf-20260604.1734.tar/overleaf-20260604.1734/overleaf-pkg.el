;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20260604.1734"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "506fe07b79ceefce3e53196711e10700da344d49"
  :revdesc "506fe07b79ce"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
