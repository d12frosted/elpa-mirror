(define-package "modus-themes" "20210308.1053" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "8d24289c81a8b9fb1ef2b401b430655807c20d4e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
