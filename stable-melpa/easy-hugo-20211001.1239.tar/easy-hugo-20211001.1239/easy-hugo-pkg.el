(define-package "easy-hugo" "20211001.1239" "Write blogs made with hugo by markdown or org-mode"
  '((emacs "25.1")
    (popup "0.5.3")
    (request "0.3.0")
    (transient "0.3.6"))
  :commit "751fdb95d0fb239b3204b6e4cde78006a5b95ec7" :authors
  '(("Masashi Miyaura"))
  :maintainer
  '("Masashi Miyaura")
  :url "https://github.com/masasam/emacs-easy-hugo")
;; Local Variables:
;; no-byte-compile: t
;; End:
