;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251118.1811"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "a6577d0cda8b86ab854430bc9da5511c3fa06e7c"
  :revdesc "a6577d0cda8b"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
