(define-package "dirvish" "20220108.627" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "e2ff994b2610f7ae54d7d877ab5beb21d7c9880e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
