;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "password-store-menu" "20260423.1011"
  "A better, more complete UI for password-store."
  '((emacs          "29.1")
    (password-store "2.3.2")
    (transient      "0.8.3"))
  :url "https://github.com/rjekker/password-store-menu"
  :commit "b007d990f895a9bc41048080cb1dd2c2b7f1b92c"
  :revdesc "b007d990f895"
  :keywords '("convenience" "data" "files")
  :authors '(("Reindert-Jan Ekker" . "info@rjekker.nl"))
  :maintainers '(("Reindert-Jan Ekker" . "info@rjekker.nl")))
