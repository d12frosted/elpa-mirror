(define-package "for" "20220909.1231" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "86bc3b3fd78646ffe2f3bb195d3e10a5a048048f" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
