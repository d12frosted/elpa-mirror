(define-package "helm-core" "20231103.557" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "60ed8db14881f02f08d3e29a98f8b0a9d44ad4fa" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
