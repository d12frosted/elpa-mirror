(define-package "kurecolor" "20220814.1501" "color editing goodies"
  '((emacs "28.1")
    (s "1.12"))
  :commit "91609f4e89cf2237df4bb104c32eca2cc694158c" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
