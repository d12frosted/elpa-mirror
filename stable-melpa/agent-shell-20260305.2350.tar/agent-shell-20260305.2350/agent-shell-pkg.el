;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260305.2350"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.86.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "898fb88873ff46f4500545f3e6d73717e89fdea9"
  :revdesc "898fb88873ff")
