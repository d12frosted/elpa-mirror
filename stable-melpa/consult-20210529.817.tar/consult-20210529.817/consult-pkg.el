(define-package "consult" "20210529.817" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "34e4a8f06dd543cafa7b1fd2ef12da93b2390149" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
