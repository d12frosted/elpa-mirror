(define-package "swagg" "20240326.236" "Swagger UI"
  '((emacs "27.1")
    (compat "29.1.4.0")
    (request "0.3.3")
    (dash "2.19.1")
    (yaml "0.5.1")
    (s "1.13.1"))
  :commit "259a294a2fb84d8c0b6c45ece802375841083f10" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :keywords
  '("tools" "convenience")
  :url "https://github.com/isamert/swagg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
