;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erc-youtube" "20150603.2136"
  "Show info about a YouTube URL in an ERC buffer."
  ()
  :url "https://github.com/kidd/erc-youtube.el"
  :commit "97054ba8475b442e2aa81e5a291f668b7f28697f"
  :revdesc "97054ba8475b"
  :keywords '("multimedia")
  :authors '(("Raimon Grau Cuscó" . "raimonster@gmail.com"))
  :maintainers '(("Raimon Grau Cuscó" . "raimonster@gmail.com")))
