(define-package "org-roam-bibtex" "20201127.2234" "Org Roam meets BibTeX"
  '((emacs "27.1")
    (org-roam "1.2.2")
    (bibtex-completion "2.0.0"))
  :commit "085ca626fff08995816ad2000142013dc61eea5f" :keywords
  ("bib" "hypermedia" "outlines" "wp")
  :authors
  (("Leo Vivier" . "leo.vivier+dev@gmail.com")
   ("Mykhailo Shevchuk" . "mail@mshevchuk.com")
   ("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  ("Leo Vivier" . "leo.vivier+dev@gmail.com")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
