;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250104.1756"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "94c7a978398c2d8648521213c9648758789a11ca"
  :revdesc "94c7a978398c"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
