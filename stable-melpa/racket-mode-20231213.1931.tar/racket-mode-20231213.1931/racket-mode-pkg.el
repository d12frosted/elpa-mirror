(define-package "racket-mode" "20231213.1931" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "6c141166ef6b3aba48f975530d6e7a7500f771e2" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
