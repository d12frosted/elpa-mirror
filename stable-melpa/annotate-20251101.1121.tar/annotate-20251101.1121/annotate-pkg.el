;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "annotate" "20251101.1121"
  "Annotate files without changing them."
  '((emacs "27.1"))
  :url "https://github.com/bastibe/annotate.el"
  :commit "1040335fbc383d05ec2a13033940aa7b0c5f3994"
  :revdesc "1040335fbc38"
  :maintainers '(("Bastian Bechtold" . "bastibe.dev@mailbox.org")
                 ("cage" . "cage-dev@twistfold.it")))
