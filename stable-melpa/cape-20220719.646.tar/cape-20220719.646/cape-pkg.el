(define-package "cape" "20220719.646" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "ad13cc9e3a505fc3fa56ac559d15e3eca7bcc731" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
