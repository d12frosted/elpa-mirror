(define-package "cape" "20220719.646" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "6cfc9574358c98f24c9f58e7004d6753ddb27a89" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
