(define-package "cape" "20220719.646" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "be078bfb331df23418be6657e0320d81f1d363f4" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
