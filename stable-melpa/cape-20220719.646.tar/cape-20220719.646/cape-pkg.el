(define-package "cape" "20220719.646" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "da0bd307266649a7403694b35d6a21dd6d28682d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
