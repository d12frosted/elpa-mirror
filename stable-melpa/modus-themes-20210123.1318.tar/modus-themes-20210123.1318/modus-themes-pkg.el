(define-package "modus-themes" "20210123.1318" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "496df049fc27d2312bbc06efd89d4be3e4598278" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
