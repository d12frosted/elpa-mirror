(define-package "ox-tufte" "20230612.1902" "Tufte HTML org-mode export backend"
  '((org "8.2")
    (emacs "24.4"))
  :commit "ef218789f853cf56b2283fb28b2d869aa79345bd" :authors
  '(("M. Lee Hinman"))
  :maintainers
  '(("The Bayesians Inc."))
  :maintainer
  '("The Bayesians Inc.")
  :keywords
  '("org" "tufte" "html" "outlines" "hypermedia" "calendar" "wp")
  :url "https://github.com/ox-tufte/ox-tufte")
;; Local Variables:
;; no-byte-compile: t
;; End:
