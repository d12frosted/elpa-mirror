;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jmespath" "20240115.1310"
  "Query JSON using jmespath."
  '((emacs "24.3"))
  :url "https://github.com/unresolvedcold/jmespath"
  :commit "d3a4a4abdd6804d3aef5e0d0c538abd27667b4c3"
  :revdesc "d3a4a4abdd68"
  :keywords '("json" "data" "languages" "tools")
  :authors '(("Shubham Kumar" . "unresolved.shubham@gmail.com"))
  :maintainers '(("Shubham Kumar" . "unresolved.shubham@gmail.com")))
