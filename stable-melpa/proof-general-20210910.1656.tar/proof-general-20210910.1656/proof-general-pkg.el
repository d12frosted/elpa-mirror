(define-package "proof-general" "20210910.1656" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "25.1"))
  :commit "eb978573c372913a7465817ce00a9fdf2871648f" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
