(define-package "proof-general" "20210910.1656" "A generic front-end for proof assistants (interactive theorem provers)"
  '((emacs "25.1"))
  :commit "32b15ff26be8722950e5f67a087e6fd9d67197bd" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
