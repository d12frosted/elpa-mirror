(define-package "csound-mode" "20230825.946" "A major mode for interacting and coding Csound"
  '((emacs "25")
    (shut-up "0.3.2")
    (multi "2.0.1")
    (dash "2.16.0")
    (highlight "0"))
  :commit "21b2841696fed1b3d8103ad58202d5604326fcc1" :authors
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainers
  '(("Hlöðver Sigurðsson" . "hlolli@gmail.com"))
  :maintainer
  '("Hlöðver Sigurðsson" . "hlolli@gmail.com")
  :url "https://github.com/hlolli/csound-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
