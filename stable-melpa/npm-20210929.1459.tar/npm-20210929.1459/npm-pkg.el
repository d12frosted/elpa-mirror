(define-package "npm" "20210929.1459" "Run your npm workflows"
  '((emacs "25.1")
    (transient "0.1.0")
    (jest "20200625"))
  :commit "44b193dbea645149104ace949cfd77c4cf2fcc05" :authors
  '(("Shane Kennedy"))
  :maintainer
  '("Shane Kennedy")
  :keywords
  '("tools")
  :url "https://github.com/shaneikennedy/npm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
