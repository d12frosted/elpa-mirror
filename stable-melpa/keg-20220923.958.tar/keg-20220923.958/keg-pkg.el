(define-package "keg" "20220923.958" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "7fbfd987d35e29eaab2ebad4f0ed6ee2e2adfe28" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainers
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
