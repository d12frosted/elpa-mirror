;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261114.506"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "b5ed11a19ff6df6b3d70abcd3814d3a26daf2c8e"
  :revdesc "b5ed11a19ff6"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
