;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polymode" "20250603.2059"
  "Extensible framework for multiple major modes."
  '((emacs "25"))
  :url "https://github.com/polymode/polymode"
  :commit "96d56e72f98703fd93fe2442acf539987295f6cc"
  :revdesc "96d56e72f987"
  :keywords '("languages" "multi-modes" "processes")
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
