;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20250616.2150"
  "Simple annotation system."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "c20653ec7508ba83897fa2f19a6a76f03d27546b"
  :revdesc "c20653ec7508"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
