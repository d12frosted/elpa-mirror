(define-package "chronometrist-key-values" "20220215.1904" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "2b2bfa27787ae524852abcb75408b0b1927aa2e1" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
