(define-package "stimmung-themes" "20210920.1345" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "caf1c099ee5da59c6686af99c36eb846ebb7a610" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
