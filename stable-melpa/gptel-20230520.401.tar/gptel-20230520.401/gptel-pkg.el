(define-package "gptel" "20230520.401" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "706ad703db40945457b678314faa7d081f1a201b" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
