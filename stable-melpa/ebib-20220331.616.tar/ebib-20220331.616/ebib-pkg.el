(define-package "ebib" "20220331.616" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "87d8f7d6e34d2ecc04118806a48d7fd9a53a4aad" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
