;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-du-duc" "20260205.1758"
  "Speed up dired-du with duc."
  '((emacs    "29.1")
    (dired-du "0.5.2"))
  :url "https://github.com/meedstrom/dired-du-duc"
  :commit "f7f1a915e5a39109c00cabc3ab2a38c77750c195"
  :revdesc "f7f1a915e5a3"
  :keywords '("files")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
