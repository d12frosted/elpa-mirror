;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mcp-server-lib" "20251008.1306"
  "Model Context Protocol server library."
  '((emacs "27.1"))
  :url "https://github.com/laurynas-biveinis/mcp-server-lib.el"
  :commit "c1955e7a758de4717087756c51a8d7bc6301dd49"
  :revdesc "c1955e7a758d"
  :keywords '("comm" "tools")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
