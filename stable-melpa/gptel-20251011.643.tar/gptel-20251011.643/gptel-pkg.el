;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251011.643"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "0c32dbdbf4319b9d3cdd4302249d25c2a3495f1e"
  :revdesc "0c32dbdbf431"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
