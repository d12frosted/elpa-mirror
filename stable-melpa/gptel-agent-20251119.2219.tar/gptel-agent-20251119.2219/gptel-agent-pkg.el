;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20251119.2219"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "e8266da2c8923bf270127a757d8d787a0f8e7302"
  :revdesc "e8266da2c892"
  :keywords '("comm"))
