(define-package "consult" "20210626.1840" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "c85cf2bed85fbca6c4c37978df90b2f4559e327b" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
