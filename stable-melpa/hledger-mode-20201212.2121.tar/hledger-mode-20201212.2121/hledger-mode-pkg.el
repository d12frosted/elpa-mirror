(define-package "hledger-mode" "20201212.2121" "A mode for writing journal entries for hledger."
  '((emacs "24.4")
    (popup "0.5.3")
    (async "1.9")
    (htmlize "1.47"))
  :commit "bad680b33c2ca20a6088986a10735a5df3cb9996" :authors
  (("Narendra Joshi" . "narendraj9@gmail.com"))
  :maintainer
  ("Narendra Joshi" . "narendraj9@gmail.com")
  :keywords
  ("data")
  :url "https://github.com/narendraj9/hledger-mode.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
