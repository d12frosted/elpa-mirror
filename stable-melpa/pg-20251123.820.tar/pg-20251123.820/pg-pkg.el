;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20251123.820"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "0f909d6f00ce2c6eac1711739296d1054b5cfdb1"
  :revdesc "0f909d6f00ce"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
