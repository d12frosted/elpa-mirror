(define-package "powerline" "20210526.1345" "Rewrite of Powerline"
  '((cl-lib "0.2"))
  :commit "e5680a3ce2d9c7c86c0416f8609b390fc4e9a637" :authors
  '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainer
  '("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
  :keywords
  '("mode-line")
  :url "http://github.com/milkypostman/powerline/")
;; Local Variables:
;; no-byte-compile: t
;; End:
