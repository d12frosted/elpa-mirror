;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20241022.1403"
  "Major mode for MATLAB(R) dot-m files."
  ()
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "880bca72fd5a50d36aa739c8ebf76d062e9f9373"
  :revdesc "880bca72fd5a"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")))
