;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260317.307"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "99c5effab845dc5858f49aba6ac270bf77b5ece3"
  :revdesc "99c5effab845"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
