;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20260531.807"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "2cf2ddb9c8e7a0e909b3606ce65f7f6e3c485920"
  :revdesc "2cf2ddb9c8e7"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
