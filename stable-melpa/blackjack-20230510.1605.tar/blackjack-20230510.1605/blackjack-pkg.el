(define-package "blackjack" "20230510.1605" "The game of Blackjack"
  '((emacs "26.2"))
  :commit "c3a5f6fd2c9c4ea8f9391acde35323fc7362c058" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
