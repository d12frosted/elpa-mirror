;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marginalia" "20251006.1124"
  "Enrich existing commands with completion annotations."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/marginalia"
  :commit "aaef4fa6eefe02812a50eaf21411681c74fc941d"
  :revdesc "aaef4fa6eefe"
  :keywords '("docs" "help" "matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
