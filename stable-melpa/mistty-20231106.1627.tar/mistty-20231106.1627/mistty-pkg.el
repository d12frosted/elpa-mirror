(define-package "mistty" "20231106.1627" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "7f9d259db5e50bbb13876b5927ee78b3d7d127ea" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
