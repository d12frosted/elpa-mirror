(define-package "ivy" "20210225.1251" "Incremental Vertical completYon"
  '((emacs "24.5"))
  :commit "1deef7672b25e2cb89dfe5cc6e8865bc6f2bcd4e" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("matching")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
