(define-package "tabspaces" "20231119.1824" "Leverage tab-bar and project for buffer-isolated workspaces"
  '((emacs "27.1")
    (project "0.8.1"))
  :commit "75cbfc0540887f1f6dc4f4f4ccaaa7c93adca5a6" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainers
  '(("Colin McLear"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/mclear-tools/tabspaces")
;; Local Variables:
;; no-byte-compile: t
;; End:
