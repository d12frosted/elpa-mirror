;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dune" "20260721.729"
  "Integration with the dune build system."
  ()
  :url "https://github.com/ocaml/dune"
  :commit "a5d7d322823927dd5d85ae102fd7d442be2f7e66"
  :revdesc "a5d7d3228239")
