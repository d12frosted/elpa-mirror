(define-package "wand" "20200302.1536" "Magic wand for Emacs - Select and execute"
  '((dash "2.15.0")
    (s "0.1.1"))
  :commit "731b5ca33269fe563239bff16da6c41489432b80" :authors
  '(("Ha-Duong Nguyen <cmpitgATgmail>"))
  :maintainer
  '("Ha-Duong Nguyen <cmpitgATgmail>")
  :keywords
  '("extensions" "tools")
  :url "https://github.com/cmpitg/wand")
;; Local Variables:
;; no-byte-compile: t
;; End:
