;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261101.1018"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "0139d3819d81a3e80ab2661c2b911e504cec74ca"
  :revdesc "0139d3819d81"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
