;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "arjen-grey-theme" "20170522.2047"
  "A soothing dark grey theme."
  ()
  :url "https://github.com/credmp/arjen-grey"
  :commit "4cd0be72b65d42390e2105cfdaa408a1ead8d8d1"
  :revdesc "4cd0be72b65d"
  :keywords '("faces")
  :authors '(("Arjen Wiersma" . "arjen@wiersma.org"))
  :maintainers '(("Arjen Wiersma" . "arjen@wiersma.org")))
