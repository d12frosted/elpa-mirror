(define-package "sketch-themes" "20210325.1700" "Sketch color themes"
  '((emacs "26.1"))
  :commit "407094c03e934043aa6d70369bf3e1bd841d1c91" :authors
  '(("Daw-Ran Liou" . "hi@dawranliou.com"))
  :maintainer
  '("Daw-Ran Liou" . "hi@dawranliou.com")
  :keywords
  '("faces")
  :url "https://github.com/dawranliou/sketch-themes/")
;; Local Variables:
;; no-byte-compile: t
;; End:
