(define-package "stimmung-themes" "20220328.728" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "b4c97df76f3cb56dec92678b449e2a1ca3f40289" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
