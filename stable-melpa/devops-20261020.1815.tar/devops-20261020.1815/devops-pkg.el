;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devops" "20261020.1815"
  "Infrastructure as an org file."
  '((emacs "30.1"))
  :url "https://github.com/kpassapk/devops.el"
  :commit "032293538e74344012e9063d21d51fc416ee8761"
  :revdesc "032293538e74"
  :keywords '("tools" "processes" "outlines")
  :authors '(("Kyle S Passarelli" . "kyle.passarelli@gmail.com"))
  :maintainers '(("Kyle S Passarelli" . "kyle.passarelli@gmail.com")))
