(define-package "consult" "20220805.1719" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "39452ddbcd403f9fe7ad18270f124a8c98896c88" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
