;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260104.218"
  "Unified interface for multiple AI coding CLI tool."
  '((emacs     "26.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "d4a8b000ce685a01eea0205166e40f8d5bc05e99"
  :revdesc "d4a8b000ce68"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
