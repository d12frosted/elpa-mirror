;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-switch-to-repl" "20210206.844"
  "Helm action to switch directory in REPLs."
  '((emacs "26.1")
    (helm  "3"))
  :url "https://github.com/emacs-helm/helm-switch-to-repl"
  :commit "f0e732e7217fc0373b0805245fa15920cf676619"
  :revdesc "f0e732e7217f"
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
