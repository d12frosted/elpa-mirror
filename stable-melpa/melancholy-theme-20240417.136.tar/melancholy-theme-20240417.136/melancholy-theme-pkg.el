;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "melancholy-theme" "20240417.136"
  "A dark theme that's pretty sad  -*- lexical-binding: t; -."
  '((emacs "27.1"))
  :url "https://gitlab.com/baaash/melancholy-theme"
  :commit "7ba2bb3f062e798236bfb589381691c5bd9a22be"
  :revdesc "7ba2bb3f062e"
  :keywords '("faces" "frames")
  :authors '(("@baaash" . "bleat@baaa.sh"))
  :maintainers '(("@baaash" . "bleat@baaa.sh")))
