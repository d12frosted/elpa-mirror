;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xresources-theme" "20221208.2015"
  "Use your .Xresources as your emacs theme."
  ()
  :url "https://github.com/martenlienen/xresources-theme"
  :commit "76532fc4330e9e31accc580708514b83b15d70a7"
  :revdesc "76532fc4330e"
  :keywords '("xresources" "theme")
  :authors '(("Marten Lienen" . "marten.lienen@gmail.com"))
  :maintainers '(("Marten Lienen" . "marten.lienen@gmail.com")))
