;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sparkline" "20150101.1319"
  "Make sparkline images from a list of numbers."
  '((cl-lib "0.3"))
  :url "https://github.com/woudshoo/sparkline"
  :commit "a2b5d817d272d6363b67ed8f8cc75499a19fa8d2"
  :revdesc "a2b5d817d272"
  :keywords '("extensions")
  :authors '(("Willem Rein Oudshoorn" . "woudshoo@xs4all.nl"))
  :maintainers '(("Willem Rein Oudshoorn" . "woudshoo@xs4all.nl")))
