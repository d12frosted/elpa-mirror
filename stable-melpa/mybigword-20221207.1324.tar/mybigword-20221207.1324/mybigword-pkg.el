(define-package "mybigword" "20221207.1324" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "26.1")
    (avy "0.5.0"))
  :commit "152eaf9b1f661677bd120f6f6ad0a20064c6150c" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
