;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20260202.529"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.18.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "796e808fcfcabd544c7cc257f972f2fc9b7a0969"
  :revdesc "796e808fcfca"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
