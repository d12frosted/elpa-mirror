(define-package "live-py-mode" "20230408.607" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "4e312c322e1520f71c192ad40eb210469cef3d70" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
