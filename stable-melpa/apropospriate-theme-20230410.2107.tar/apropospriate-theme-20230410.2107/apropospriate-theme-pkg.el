(define-package "apropospriate-theme" "20230410.2107" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "1ac38ed16dc7a8d8a9d1617aeaecb8e988750348" :authors
  '(("Justin Talbott" . "justin@waymondo.com"))
  :maintainer
  '("Justin Talbott" . "justin@waymondo.com")
  :url "http://github.com/waymondo/apropospriate-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
