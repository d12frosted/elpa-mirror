(define-package "fanyi" "20211005.1414" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "87abf98ad049d8a9f6f649324ec76864a4bfc087" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
