;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shanty-themes" "20230123.2111"
  "The themes for digital workers."
  '((emacs "24.5.1"))
  :url "https://github.com/qhga/shanty-themes"
  :commit "3f678d953771c4a109bd16f6d7def6bd9bbc811d"
  :revdesc "3f678d953771"
  :keywords '("faces" "theme" "blue" "yellow" "gold" "dark" "light")
  :authors '(("Philip Gaber" . "phga@posteo.de"))
  :maintainers '(("Philip Gaber" . "phga@posteo.de")))
