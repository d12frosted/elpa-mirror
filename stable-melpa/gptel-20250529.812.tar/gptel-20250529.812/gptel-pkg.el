;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250529.812"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "875be7b2fa0ded95328542e499cf69865d557306"
  :revdesc "875be7b2fa0d"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
