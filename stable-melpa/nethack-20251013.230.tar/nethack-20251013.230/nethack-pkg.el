;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nethack" "20251013.230"
  "Run Nethack as a subprocess."
  '((emacs "27.1"))
  :url "https://github.com/Feyorsh/nethack-el"
  :commit "52bbbd80602e150f7e063c2fe319fd1eeedf617a"
  :revdesc "52bbbd80602e"
  :keywords '("games")
  :authors '(("Ryan Yeske" . "rcyeske@vcn.bc.ca"))
  :maintainers '(("George Huebner" . "george@feyor.sh")))
