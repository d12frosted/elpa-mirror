(define-package "darkman" "20230306.21" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "3a0505fa79fd6feefbbde5c0af7292e484e5b715" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://grtcdr.tn/darkman.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
