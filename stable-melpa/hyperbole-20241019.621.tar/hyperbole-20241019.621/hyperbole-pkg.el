;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241019.621"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "c2a8ffc440227003c536d72cf52c904035e49e2e"
  :revdesc "c2a8ffc44022"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
