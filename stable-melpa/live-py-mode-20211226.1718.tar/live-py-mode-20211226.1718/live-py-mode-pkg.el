(define-package "live-py-mode" "20211226.1718" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "d5bb9187d773a815e22d4c97b6c66d67978e3917" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
