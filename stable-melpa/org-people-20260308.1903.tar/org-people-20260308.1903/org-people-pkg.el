;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260308.1903"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "a8798a298a16dda24fdcc3eab97284c967b70b20"
  :revdesc "a8798a298a16"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
