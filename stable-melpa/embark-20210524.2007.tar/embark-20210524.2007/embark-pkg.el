(define-package "embark" "20210524.2007" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c1450983ba272993094e3048eb8b134c162bcb7d" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
