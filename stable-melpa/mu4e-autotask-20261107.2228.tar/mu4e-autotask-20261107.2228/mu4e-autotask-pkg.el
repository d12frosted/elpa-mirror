;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mu4e-autotask" "20261107.2228"
  "Email automation for mu4e."
  '((emacs "29.1"))
  :url "https://github.com/laurynas-biveinis/mu4e-autotask"
  :commit "7455c51445e4be07da9255c1394d6ec6fa92f027"
  :revdesc "7455c51445e4"
  :keywords '("mail")
  :authors '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com"))
  :maintainers '(("Laurynas Biveinis" . "laurynas.biveinis@gmail.com")))
