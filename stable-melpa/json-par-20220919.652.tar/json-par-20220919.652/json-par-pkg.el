(define-package "json-par" "20220919.652" "Minor mode for structural editing of JSON"
  '((emacs "24.4")
    (json-mode "1.7.0"))
  :commit "2dd58826eef67a656efd9897f65d306b5c3eb8b0" :authors
  '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainer
  '("taku0" . "mxxouy6x3m_github@tatapa.org")
  :keywords
  '("abbrev" "convenience" "files")
  :url "https://github.com/taku0/json-par")
;; Local Variables:
;; no-byte-compile: t
;; End:
