(define-package "workgroups2" "20211222.918" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "112bb1c81315e4a5d0b94abd4fd758d4e379703b" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
