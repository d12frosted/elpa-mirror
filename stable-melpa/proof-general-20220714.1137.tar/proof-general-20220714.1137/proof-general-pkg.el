(define-package "proof-general" "20220714.1137" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "e06a7704a53ee43c4695681c0e40edfdf9b1124d" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
