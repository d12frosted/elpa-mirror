(define-package "proof-general" "20220714.1137" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "e8dadc6ea7d94e355c39776ad7940c8daaa659a6" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
