;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "almost-mono-themes" "20250515.630"
  "Almost monochromatic color themes."
  '((emacs "24"))
  :url "https://github.com/cryon/almost-mono-themes"
  :commit "2bad73bca68ff372b4781b70f5f16b269b5d018a"
  :revdesc "2bad73bca68f"
  :keywords '("faces")
  :authors '(("John Olsson" . "john@cryon.se"))
  :maintainers '(("John Olsson" . "john@cryon.se")))
