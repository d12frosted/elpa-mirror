;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tzc" "20260204.1721"
  "Converts time between different time zones."
  '((emacs "28.1"))
  :url "https://github.com/md-arif-shaikh/tzc"
  :commit "de2e90b1f1958503d699b19766bd618b7a38cb33"
  :revdesc "de2e90b1f195"
  :keywords '("convenience")
  :authors '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainers '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")))
