(define-package "tss" "20140914.1004" "provide a interface for auto-complete.el/flymake.el on typescript-mode."
  '((auto-complete "1.4.0")
    (json-mode "1.1.0")
    (log4e "0.2.0")
    (yaxception "0.1"))
  :commit "1f302deea3d74462c71a9c62031f48b753e8915f" :authors
  '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainer
  '("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")
  :keywords
  '("typescript" "completion")
  :url "https://github.com/aki2o/emacs-tss")
;; Local Variables:
;; no-byte-compile: t
;; End:
