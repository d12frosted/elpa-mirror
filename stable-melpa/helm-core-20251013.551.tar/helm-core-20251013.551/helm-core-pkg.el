;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251013.551"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "b36c3777b20c962503a4195275950a5d039716b9"
  :revdesc "b36c3777b20c"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
