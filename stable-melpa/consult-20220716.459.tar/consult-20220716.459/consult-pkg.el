(define-package "consult" "20220716.459" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "a7db54eab58d8859922ffdb07141f6466fd6079d" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
