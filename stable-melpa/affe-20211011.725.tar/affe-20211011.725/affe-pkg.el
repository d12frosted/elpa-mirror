(define-package "affe" "20211011.725" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.12"))
  :commit "8bf8b0a365e7a4c0a7088ca47553d437de19f45a" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
