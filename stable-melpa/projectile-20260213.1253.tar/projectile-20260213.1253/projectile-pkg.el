;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260213.1253"
  "Manage and navigate projects in Emacs easily."
  '((emacs "26.1"))
  :url "https://github.com/bbatsov/projectile"
  :commit "86724c53bdb0d97d2a0af99373a7bc61c43abc57"
  :revdesc "86724c53bdb0"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
