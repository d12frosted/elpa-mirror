(define-package "modaled" "20230617.130" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "1c3b5377d1bfc65b75d7520bee9dda6e946e7820" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
