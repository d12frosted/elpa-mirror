;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20261029.929"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "70457a671a6590681a805e403e62c3cd448e8f7b"
  :revdesc "70457a671a65"
  :keywords '("data" "extensions"))
