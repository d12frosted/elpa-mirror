(define-package "tok-theme" "20220122.1852" "My theme"
  '((emacs "24.3"))
  :commit "0e015504f8ec8040171c901ab3f19625dcaabcc9" :authors
  '(("Topi Kettunen" . "topi@topikettunen.com"))
  :maintainer
  '("Topi Kettunen" . "topi@topikettunen.com")
  :url "https://github.com/topikettunen/tok-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
