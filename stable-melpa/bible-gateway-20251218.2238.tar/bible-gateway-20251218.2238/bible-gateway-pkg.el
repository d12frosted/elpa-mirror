;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20251218.2238"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "631a2e07ef8b0760f58ca3ce0e20184bddf80da7"
  :revdesc "631a2e07ef8b"
  :keywords '("convenience" "comm" "hypermedia"))
