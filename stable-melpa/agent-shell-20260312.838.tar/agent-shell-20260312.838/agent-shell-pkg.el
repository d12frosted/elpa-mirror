;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260312.838"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "fd898b9ea464a16e4a8e42b1df64bcd0172e7dc8"
  :revdesc "fd898b9ea464")
