;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260310.1057"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "6078e2868ad2aea0626c6f79598055dfc87c2eb0"
  :revdesc "6078e2868ad2"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
