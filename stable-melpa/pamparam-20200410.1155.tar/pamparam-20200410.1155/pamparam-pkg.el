(define-package "pamparam" "20200410.1155" "Simple and fast flashcards."
  '((emacs "24.3")
    (lispy "0.26.0")
    (worf "0.1.0")
    (hydra "0.13.4"))
  :commit "f9d83bbf5eb883bce6873dd6fd97484b6805215c" :keywords
  ("outlines" "hypermedia" "flashcards" "memory")
  :authors
  (("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  ("Oleh Krehel" . "ohwoeowho@gmail.com")
  :url "https://github.com/abo-abo/pamparam")
;; Local Variables:
;; no-byte-compile: t
;; End:
