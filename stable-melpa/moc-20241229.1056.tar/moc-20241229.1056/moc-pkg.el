;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moc" "20241229.1056"
  "Master of Ceremonies."
  '((emacs          "29.4")
    (hide-mode-line "1.0.3")
    (transient      "0.7.2"))
  :url "https://github.com/positron-solutions/moc"
  :commit "84acdd7d74cfd3b35637b84d49c53db203f657ce"
  :revdesc "84acdd7d74cf"
  :keywords '("convenience" "outline")
  :authors '(("Positron Solutions" . "contact@positron.solutions"))
  :maintainers '(("Positron Solutions" . "contact@positron.solutions")))
