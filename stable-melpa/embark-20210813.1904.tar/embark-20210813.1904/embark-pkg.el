(define-package "embark" "20210813.1904" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "fcd70f55918e0f015418cb00c20b04d282cb211b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
