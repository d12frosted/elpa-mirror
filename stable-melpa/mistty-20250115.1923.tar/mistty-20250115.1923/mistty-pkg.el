;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250115.1923"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "50898bd61bbe648e939714e0871f8a94c0f122f9"
  :revdesc "50898bd61bbe"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
