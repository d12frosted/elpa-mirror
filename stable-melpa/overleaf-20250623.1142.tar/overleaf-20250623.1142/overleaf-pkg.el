;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250623.1142"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "a2c6ac99524781f1815e107164b9254e211d6fb2"
  :revdesc "a2c6ac995247"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
