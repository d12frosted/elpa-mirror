;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jinx" "20260104.1105"
  "Enchanted Spell Checker."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/jinx"
  :commit "331ed3d8f45db3c4b6b494d88abd388569f9bc0e"
  :revdesc "331ed3d8f45d"
  :keywords '("convenience" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
