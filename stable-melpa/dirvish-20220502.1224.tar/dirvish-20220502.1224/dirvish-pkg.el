(define-package "dirvish" "20220502.1224" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "acfcd7f367cd5a624876afd64fbb16c06800f4bf" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
