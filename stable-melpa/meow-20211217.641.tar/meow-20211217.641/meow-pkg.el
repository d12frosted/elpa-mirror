(define-package "meow" "20211217.641" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "594182d5f6659fa75fe4c2ae9bf9b5dda242ef44" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
