;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20250617.1222"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "72b23724aad52b9163a16be4398b32c2a7261861"
  :revdesc "72b23724aad5"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
