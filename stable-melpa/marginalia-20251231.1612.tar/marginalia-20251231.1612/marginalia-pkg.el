;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marginalia" "20251231.1612"
  "Enrich existing commands with completion annotations."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/marginalia"
  :commit "49bda384bc9b4d88518255de8d1ac3b32e76c783"
  :revdesc "49bda384bc9b"
  :keywords '("docs" "help" "matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
