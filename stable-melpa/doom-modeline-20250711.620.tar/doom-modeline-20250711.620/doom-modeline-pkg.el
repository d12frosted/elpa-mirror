;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20250711.620"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "726bd2b921953b2953803547d9c6cbc287d5477e"
  :revdesc "726bd2b92195"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
