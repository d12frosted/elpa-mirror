(define-package "dirvish" "20220117.1342" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "32e58955da1f653660b6a9843c42e9a2d43ccfb2" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
