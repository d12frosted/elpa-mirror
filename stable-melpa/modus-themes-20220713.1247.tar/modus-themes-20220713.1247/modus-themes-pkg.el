(define-package "modus-themes" "20220713.1247" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "bee9dda7ac94f985f9ad7545b985dc50569b4eb4" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
