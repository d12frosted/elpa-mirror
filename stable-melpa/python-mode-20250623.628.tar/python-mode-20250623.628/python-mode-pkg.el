;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20250623.628"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "a9d5b4c12bf55f94e63aeca59de85ef5bd8476fe"
  :revdesc "a9d5b4c12bf5"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
