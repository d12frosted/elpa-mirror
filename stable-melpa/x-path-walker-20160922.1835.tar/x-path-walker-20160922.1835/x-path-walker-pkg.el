(define-package "x-path-walker" "20160922.1835" "Navigation feature for JSON/XML/HTML based on path (imenu like)"
  '((helm-core "1.9.2"))
  :commit "3b01dbd7a039c6c84fdf8c8ee53ba72090ee950a" :keywords
  ("convenience")
  :authors
  ((nil . "<lompik@ArchOrion>"))
  :maintainer
  (nil . "<lompik@ArchOrion>"))
;; Local Variables:
;; no-byte-compile: t
;; End:
