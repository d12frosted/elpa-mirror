;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "term-cmd" "20260510.1834"
  "Send commands from programs running in term.el."
  '((emacs "27.2")
    (dash  "2.12.0")
    (f     "0.18.2"))
  :url "https://github.com/calliecameron/term-cmd"
  :commit "15f737427b21adc722a76a71c0aaeb2dcb95efbc"
  :revdesc "15f737427b21"
  :keywords '("processes")
  :authors '(("Callie Cameron" . "callie@calliecameron.com"))
  :maintainers '(("Callie Cameron" . "callie@calliecameron.com")))
