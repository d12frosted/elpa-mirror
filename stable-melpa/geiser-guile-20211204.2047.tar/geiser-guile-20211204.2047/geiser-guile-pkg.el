(define-package "geiser-guile" "20211204.2047" "Guile's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.19"))
  :commit "adf31d3a36bf9be4b92d5c8854b4a055b1ef6f1f" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "guile" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/guile")
;; Local Variables:
;; no-byte-compile: t
;; End:
