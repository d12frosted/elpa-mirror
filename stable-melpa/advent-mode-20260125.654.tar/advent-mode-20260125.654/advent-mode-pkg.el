;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "advent-mode" "20260125.654"
  "Advent of Code mode."
  '((emacs "29.1"))
  :url "https://github.com/vkazanov/advent-mode"
  :commit "6b24e8e62d4c6abdd383b5a0c5efe031680d2538"
  :revdesc "6b24e8e62d4c"
  :keywords '("lisp")
  :authors '(("Vladimir Kazanov" . "@vkazanov"))
  :maintainers '(("Vladimir Kazanov" . "@vkazanov")))
