;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bible-gateway" "20260212.2155"
  "A Simple BibleGateway Client."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/bible-gateway"
  :commit "ef0c29d327f43456e3b41a3c0e59eacd1ada3b5f"
  :revdesc "ef0c29d327f4"
  :keywords '("convenience" "comm" "hypermedia"))
