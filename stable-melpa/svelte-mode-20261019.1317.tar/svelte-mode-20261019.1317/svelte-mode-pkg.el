;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "svelte-mode" "20261019.1317"
  "Emacs major mode for Svelte."
  '((emacs "26.1"))
  :url "https://github.com/leafOfTree/svelte-mode"
  :commit "c61161c4cdcab490b8990d1a675a9f0d63a691d3"
  :revdesc "c61161c4cdca"
  :keywords '("wp" "languages")
  :authors '(("Leaf" . "leafvocation@gmail.com"))
  :maintainers '(("Leaf" . "leafvocation@gmail.com")))
