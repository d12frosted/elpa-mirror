;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260301.150"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "74035635e1ac21d7f14a3e564fb13032743d328c"
  :revdesc "74035635e1ac"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
