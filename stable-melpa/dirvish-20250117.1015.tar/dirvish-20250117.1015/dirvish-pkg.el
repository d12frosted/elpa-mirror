;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250117.1015"
  "A modern file manager based on dired mode."
  '((emacs     "27.1")
    (transient "0.3.7"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "02c94ab28e0943358390a32984a95699989ac98d"
  :revdesc "02c94ab28e09"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
