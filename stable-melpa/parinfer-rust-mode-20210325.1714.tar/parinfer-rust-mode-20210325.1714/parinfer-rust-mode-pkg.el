(define-package "parinfer-rust-mode" "20210325.1714" "An interface for the parinfer-rust library"
  '((emacs "26.1"))
  :commit "a92e39e86ec24fbc536c68765b4af6f4c6ff24c5" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
