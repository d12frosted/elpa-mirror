;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ll-debug" "20211002.1031"
  "Low level debug tools."
  '((emacs "24.3"))
  :url "https://github.com/replrep/ll-debug"
  :commit "a2cfeab46e5100c348b35987fae34f9ea76d7c0b"
  :revdesc "a2cfeab46e51"
  :keywords '("abbrev" "convenience" "tools" "c" "lisp")
  :authors '(("Claus Brunzema" . "mail@cbrunzema.de"))
  :maintainers '(("Claus Brunzema" . "mail@cbrunzema.de")))
