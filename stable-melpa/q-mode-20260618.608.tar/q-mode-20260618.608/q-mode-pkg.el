;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260618.608"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "f7422398c8560c86cec71841c4aed71ca6537d2d"
  :revdesc "f7422398c856"
  :keywords '("faces" "files" "q"))
