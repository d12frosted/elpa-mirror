(define-package "ivy" "20210903.1814" "Incremental Vertical completYon"
  '((emacs "24.5"))
  :commit "9baa4422d4cfc32d527e85e37ccaa5abd7491a05" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("matching")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
