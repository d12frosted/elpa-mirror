(define-package "centaur-tabs" "20230108.320" "Aesthetic, modern looking customizable tabs plugin"
  '((emacs "24.4")
    (powerline "2.4")
    (cl-lib "0.5"))
  :commit "b25391006524d7b47bb98ee1a42334059c7c2057" :authors
  '(("Emmanuel Bustos" . "ema2159@gmail.com"))
  :maintainer
  '("Emmanuel Bustos" . "ema2159@gmail.com")
  :url "https://github.com/ema2159/centaur-tabs")
;; Local Variables:
;; no-byte-compile: t
;; End:
