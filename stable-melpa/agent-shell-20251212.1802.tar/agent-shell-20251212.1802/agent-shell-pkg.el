;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251212.1802"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.4")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "99476e788cc90a52b8dce7b23532ae4f62d174a7"
  :revdesc "99476e788cc9")
