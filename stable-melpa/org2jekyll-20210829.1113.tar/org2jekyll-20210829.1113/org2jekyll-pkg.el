(define-package "org2jekyll" "20210829.1113" "Minor mode to publish org-mode post to jekyll without specific yaml"
  '((dash "2.18.0")
    (s "1.9.0"))
  :commit "ed460cae30495053ce035cc9996309ae77df0b5a" :authors
  '(("Antoine R. Dumont (@ardumont)" . "antoine.romain.dumont@gmail.com"))
  :maintainer
  '("Antoine R. Dumont (@ardumont)" . "antoine.romain.dumont@gmail.com")
  :keywords
  '("org-mode" "jekyll" "blog" "publish")
  :url "https://github.com/ardumont/org2jekyll")
;; Local Variables:
;; no-byte-compile: t
;; End:
