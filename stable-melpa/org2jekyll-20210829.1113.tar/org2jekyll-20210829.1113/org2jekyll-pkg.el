(define-package "org2jekyll" "20210829.1113" "Minor mode to publish org-mode post to jekyll without specific yaml"
  '((dash "2.18.0")
    (s "1.9.0"))
  :commit "e1197fff05c9f07d88cf1f9bb971c1859b547d39" :authors
  '(("Antoine R. Dumont (@ardumont)" . "antoine.romain.dumont@gmail.com"))
  :maintainer
  '("Antoine R. Dumont (@ardumont)" . "antoine.romain.dumont@gmail.com")
  :keywords
  '("org-mode" "jekyll" "blog" "publish")
  :url "https://github.com/ardumont/org2jekyll")
;; Local Variables:
;; no-byte-compile: t
;; End:
