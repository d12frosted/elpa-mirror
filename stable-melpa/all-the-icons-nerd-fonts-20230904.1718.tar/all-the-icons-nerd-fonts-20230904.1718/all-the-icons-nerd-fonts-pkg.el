(define-package "all-the-icons-nerd-fonts" "20230904.1718" "Nerd font integration for all-the-icons"
  '((emacs "28.1")
    (all-the-icons "5.0")
    (nerd-icons "0.0.1"))
  :commit "db513dafaa8b73b5abcf9737939863d0e5b2f03d" :authors
  '(("Mohsin Kaleem" . "mohkale@gmail.com"))
  :maintainers
  '(("Mohsin Kaleem" . "mohkale@gmail.com"))
  :maintainer
  '("Mohsin Kaleem" . "mohkale@gmail.com")
  :keywords
  '("convenience" "lisp")
  :url "https://github.com/mohkale/all-the-icons-nerd-fonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
