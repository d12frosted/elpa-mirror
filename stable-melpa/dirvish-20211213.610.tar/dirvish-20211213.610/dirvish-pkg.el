(define-package "dirvish" "20211213.610" "A modern file manager based on dired mode"
  '((emacs "27.1")
    (posframe "1.1.2"))
  :commit "e92752e7ebbe527b00a104d56c68607e917eae9e" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
