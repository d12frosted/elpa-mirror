(define-package "evil-test-helpers" "20230813.1704" "unit test helpers for Evil"
  '((evil "1.15.0"))
  :commit "b7b4961a14cd1a51e9a10564fd6c741567d39891" :authors
  '(("Vegard Øye <vegard_oye at hotmail.com>"))
  :maintainers
  '(("Vegard Øye <vegard_oye at hotmail.com>"))
  :maintainer
  '("Vegard Øye <vegard_oye at hotmail.com>"))
;; Local Variables:
;; no-byte-compile: t
;; End:
