;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphviz-dot-mode" "20260904.1519"
  "Mode for the dot-language used by graphviz (att)."
  '((emacs "25.0"))
  :url "https://ppareit.github.io/graphviz-dot-mode/"
  :commit "768862938805ed234868d5de3c846e624c715ee4"
  :revdesc "768862938805"
  :keywords '("mode" "dot" "dot-language" "dotlanguage" "graphviz" "graphs" "att")
  :authors '(("Pieter Pareit" . "pieter.pareit@gmail.com")
             ("Rubens Ramos" . "rubensrATusers.sourceforge.net"))
  :maintainers '(("Pieter Pareit" . "pieter.pareit@gmail.com")))
