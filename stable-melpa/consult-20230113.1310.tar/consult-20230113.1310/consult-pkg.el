(define-package "consult" "20230113.1310" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.1.0"))
  :commit "5b2b7d39534314c53e95958c3d9daeee40329c28" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
