;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "llm-test" "20260405.1450"
  "LLM-driven testing for packages."
  '((emacs "29.1")
    (llm   "0.18.0")
    (yaml  "0.5.0")
    (futur "1.2"))
  :url "https://github.com/ahyatt/llm-test"
  :commit "eb69f90def15e60bc23ef1abbaf9888d2c4fd644"
  :revdesc "eb69f90def15"
  :keywords '("testing" "tools")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
