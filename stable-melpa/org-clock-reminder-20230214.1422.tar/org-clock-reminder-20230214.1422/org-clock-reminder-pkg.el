(define-package "org-clock-reminder" "20230214.1422" "Notifications that remind you about clocked-in tasks"
  '((emacs "26.1"))
  :commit "5fac482608926a4e2ebc69e269ac555a7d63db47" :authors
  '(("Nikolay Brovko" . "i@nickey.ru"))
  :maintainer
  '("Nikolay Brovko" . "i@nickey.ru")
  :keywords
  '("calendar" "convenience")
  :url "https://github.com/inickey/org-clock-reminder")
;; Local Variables:
;; no-byte-compile: t
;; End:
