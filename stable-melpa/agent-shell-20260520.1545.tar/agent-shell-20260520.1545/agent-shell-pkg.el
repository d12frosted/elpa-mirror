;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260520.1545"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.91.2")
    (acp         "0.12.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "530620eab82a7c71e379bb44a75561e6532ca1bb"
  :revdesc "530620eab82a")
