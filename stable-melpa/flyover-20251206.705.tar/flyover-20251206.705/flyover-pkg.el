;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyover" "20251206.705"
  "Display Flycheck and Flymake errors with overlays."
  '((emacs   "27.1")
    (flymake "1.0"))
  :url "https://github.com/konrad1977/flyover"
  :commit "d5bd86a837d3ba867b1ce2ec95c3fd487483e626"
  :revdesc "d5bd86a837d3"
  :keywords '("convenience" "tools" "flycheck" "flymake")
  :authors '(("Mikael Konradsson" . "mikael.konradsson@outlook.com"))
  :maintainers '(("Mikael Konradsson" . "mikael.konradsson@outlook.com")))
