;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "isortify" "20230821.1632"
  "(automatically) format python buffers using isort."
  '((emacs    "25")
    (pythonic "0.1.0"))
  :url "https://github.com/proofit404/isortify"
  :commit "5ee404c5bee2772b4f3ee424df0a5b0aef7e6982"
  :revdesc "5ee404c5bee2"
  :keywords '("convenience" "isort")
  :authors '(("Artem Malyshev" . "proofit404@gmail.com"))
  :maintainers '(("Artem Malyshev" . "proofit404@gmail.com")))
