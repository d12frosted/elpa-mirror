(define-package "modus-themes" "20210710.1611" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "00beb65433a88d4e9b790a00f91bc70f542369b7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
