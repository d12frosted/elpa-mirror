;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grove" "20260823.313"
  "Obsidian-like note-taking for org files."
  '((emacs "29.1"))
  :url "https://github.com/jonathanchu/grove"
  :commit "1c93f2876c537356971724d050f6c3353f4f0fb5"
  :revdesc "1c93f2876c53"
  :keywords '("notes" "outlines" "tools")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
