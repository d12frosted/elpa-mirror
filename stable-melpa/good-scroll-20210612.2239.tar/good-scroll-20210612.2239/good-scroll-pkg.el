(define-package "good-scroll" "20210612.2239" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "0c1ded4bcca0acd9a6fc5508b102b2adb77a8dfa" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
