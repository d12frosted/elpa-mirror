;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260627.148"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "3da12174e9a2548f62979f276c8cc23694cc0f05"
  :revdesc "3da12174e9a2"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
