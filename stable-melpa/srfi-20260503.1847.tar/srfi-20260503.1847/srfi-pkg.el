;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260503.1847"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "1ec9447f2673d9d6a906507c962d07266853c98c"
  :revdesc "1ec9447f2673"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
