(define-package "ready-player" "20240913.841" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "6f2032f12ead4ec719f0afc0a62e0b37429251e2" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
