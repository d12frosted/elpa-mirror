;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "punctuality-logger" "20141120.2031"
  "Punctuality logger for Emacs."
  ()
  :url "https://gitlab.com/elzair/punctuality-logger"
  :commit "d76c5d5589a4f8a94cc5537686d9a3b46ea7cc59"
  :revdesc "d76c5d5589a4"
  :keywords '("reminder" "calendar")
  :authors '(("Philip Woods" . "elzairthesorcerer@gmail.com"))
  :maintainers '(("Philip Woods" . "elzairthesorcerer@gmail.com")))
