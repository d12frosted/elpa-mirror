(define-package "epkg" "20230407.2200" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "29.1.3.4")
    (closql "20230220")
    (emacsql "20230220")
    (llama "0.2.0"))
  :commit "c1117eb93f65c15c81cb4822c5eec9a12fe268ed" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
