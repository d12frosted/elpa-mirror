;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260513.1720"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "ec7e5d0a5a5b5ab56eb1cabd4f7a754ca1992f56"
  :revdesc "ec7e5d0a5a5b"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
