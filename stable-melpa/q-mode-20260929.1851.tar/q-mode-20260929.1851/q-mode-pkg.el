;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260929.1851"
  "A q editing mode."
  '((emacs "28"))
  :url "https://github.com/psaris/q-mode"
  :commit "9b86222d5fca4e329a5eb1884fb775eb4e5e333d"
  :revdesc "9b86222d5fca"
  :keywords '("faces" "files" "q"))
