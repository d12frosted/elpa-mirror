(define-package "abs-mode" "20240718.914" "Major mode for the modeling language Abs"
  '((emacs "26.1")
    (erlang "2.8")
    (maude-mode "0.3")
    (flymake "1.0")
    (yasnippet "0.14.0"))
  :commit "005fcf4c4017bac5f515e89cd81683b477d1839c" :authors
  '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainers
  '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainer
  '("Rudi Schlatte" . "rudi@constantly.at")
  :keywords
  '("languages")
  :url "https://github.com/abstools/abs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
