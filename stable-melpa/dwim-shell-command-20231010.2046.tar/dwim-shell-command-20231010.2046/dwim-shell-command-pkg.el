(define-package "dwim-shell-command" "20231010.2046" "Shell commands with DWIM behaviour"
  '((emacs "28.1"))
  :commit "1f865701105de5bbc62d88071a05381c14026732" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
