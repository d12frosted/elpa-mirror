;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20250227.211"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "afad6615fe54893cb3fe0ef4657399ff02f8405a"
  :revdesc "afad6615fe54"
  :keywords '("outlines"))
