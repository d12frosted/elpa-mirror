;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geiser-guile" "20260510.2113"
  "Guile and Geiser talk to each other."
  '((emacs     "27.1")
    (transient "0.3")
    (geiser    "0.33"))
  :url "https://gitlab.com/emacs-geiser/guile"
  :commit "5bc32c715e7ade96e813526190a9745db7916c4b"
  :revdesc "5bc32c715e7a"
  :keywords '("languages" "guile" "scheme" "geiser")
  :authors '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)"))
  :maintainers '(("Jose Antonio Ortega Ruiz" . "(jao@gnu.org)")))
