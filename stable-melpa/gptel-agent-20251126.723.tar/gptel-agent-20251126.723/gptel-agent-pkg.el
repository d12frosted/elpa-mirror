;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20251126.723"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "320c6327a16d0792409f6901234dbdf9611cc613"
  :revdesc "320c6327a16d"
  :keywords '("comm"))
