;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250111.1849"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "a44f6d1799a2ff0e7ee3728c5221f4ee7827b4e9"
  :revdesc "a44f6d1799a2"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
