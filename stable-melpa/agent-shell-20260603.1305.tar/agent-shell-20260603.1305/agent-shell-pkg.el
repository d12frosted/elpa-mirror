;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260603.1305"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "86a431899582ee3c49e70b301031463246ea2764"
  :revdesc "86a431899582")
