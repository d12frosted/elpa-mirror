(define-package "citre" "20210721.1328" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "a281c6fe03e9211a094cfe056479bd2b69c9dc66" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
