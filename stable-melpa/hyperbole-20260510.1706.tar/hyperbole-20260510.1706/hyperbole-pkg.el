;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260510.1706"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "5aa860baf9f0c111b95cc3a4b147bc99a26bd58b"
  :revdesc "5aa860baf9f0"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
