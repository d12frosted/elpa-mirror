(define-package "eldev" "20221218.2216" "Elisp development tool"
  '((emacs "24.4"))
  :commit "8d93a0940069e560b2483e605c9756c8540c797f" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
