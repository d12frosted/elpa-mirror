;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260129.1535"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "38692d2d78998c36279de0f7b9d5bbda6d6c592c"
  :revdesc "38692d2d7899"
  :keywords '("convenience"))
