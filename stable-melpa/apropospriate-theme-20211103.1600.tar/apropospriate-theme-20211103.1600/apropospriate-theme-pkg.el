(define-package "apropospriate-theme" "20211103.1600" "A colorful, low-contrast, light & dark theme set for Emacs with a fun name." 'nil :commit "008cd61d8b42367316b147eef2a81636f01faeee")
;; Local Variables:
;; no-byte-compile: t
;; End:
