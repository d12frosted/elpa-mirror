(define-package "math-tex-convert" "20220912.57" "Convert LaTeX macros to unicode and back"
  '((emacs "26.1")
    (math-symbol-lists "1.3")
    (auctex "12.1"))
  :commit "8978aa5a14afc59fbcda54444dd64b7c9e93572b" :authors
  '(("Enrico Flor" . "enrico@eflor.net"))
  :maintainer
  '("Enrico Flor" . "enrico@eflor.net")
  :url "https://github.com/enricoflor/math-tex-convert")
;; Local Variables:
;; no-byte-compile: t
;; End:
