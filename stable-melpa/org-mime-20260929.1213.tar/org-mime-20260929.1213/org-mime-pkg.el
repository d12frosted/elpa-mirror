;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mime" "20260929.1213"
  "Org html export for text/html MIME emails."
  '((emacs "29.1"))
  :url "https://github.com/org-mime/org-mime"
  :commit "18b421f9a73428a49d9a534d3920e63ca21bea5b"
  :revdesc "18b421f9a734"
  :keywords '("mime" "mail" "email" "html")
  :maintainers '(("Chen Bin" . "chb_shAThotmailDOTcom")))
