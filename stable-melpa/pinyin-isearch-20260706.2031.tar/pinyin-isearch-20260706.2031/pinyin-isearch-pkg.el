;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260706.2031"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "760dcef81a7f5df886f8ae277a8d729795e78864"
  :revdesc "760dcef81a7f"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
