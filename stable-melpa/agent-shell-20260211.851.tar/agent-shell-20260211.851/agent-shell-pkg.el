;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260211.851"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "385df6216590f85e06ff3addc45bf50d99c0962e"
  :revdesc "385df6216590")
