;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pg" "20250707.1253"
  "Socket-level interface to the PostgreSQL database."
  '((emacs "28.1")
    (peg   "1.0.1"))
  :url "https://github.com/emarsden/pg-el"
  :commit "5d3928aadd8b6fa3dde78a8a4a54db6dbea7a9cd"
  :revdesc "5d3928aadd8b"
  :keywords '("data" "comm" "database" "postgresql")
  :authors '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers '(("Eric Marsden" . "eric.marsden@risk-engineering.org")))
