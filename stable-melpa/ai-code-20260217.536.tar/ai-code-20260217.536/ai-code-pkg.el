;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260217.536"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "c450238ea4db92a8631d96cebbfdfcd4a5b0a091"
  :revdesc "c450238ea4db"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
