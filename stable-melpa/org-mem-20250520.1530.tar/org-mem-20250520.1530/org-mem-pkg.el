;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250520.1530"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "828d87d882ab321c1bcb99f32e8fee4ef6260a86"
  :revdesc "828d87d882ab"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
