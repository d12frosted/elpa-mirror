(define-package "nndiscourse" "20210820.1503" "Gnus backend for Discourse"
  '((emacs "25.1")
    (dash "2.18.1")
    (anaphora "1.0.4")
    (rbenv "0.0.3")
    (json-rpc "0.0.1"))
  :commit "ea5505e8074814f2359783c80bf5d88bd2b6ff1d" :keywords
  '("news")
  :url "https://github.com/dickmao/nndiscourse")
;; Local Variables:
;; no-byte-compile: t
;; End:
