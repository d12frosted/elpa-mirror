(define-package "nndiscourse" "20210820.1503" "Gnus backend for Discourse"
  '((emacs "25.1")
    (dash "2.18.1")
    (anaphora "1.0.4")
    (rbenv "0.0.3")
    (json-rpc "0.0.1"))
  :commit "1b064aa49da9ab24fb36d208ec35a40c29d9e5b3" :keywords
  '("news")
  :url "https://github.com/dickmao/nndiscourse")
;; Local Variables:
;; no-byte-compile: t
;; End:
