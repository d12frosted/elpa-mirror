;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260627.1003"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "43d253b84902a239f7e040d42235a5c322ce0a31"
  :revdesc "43d253b84902"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
