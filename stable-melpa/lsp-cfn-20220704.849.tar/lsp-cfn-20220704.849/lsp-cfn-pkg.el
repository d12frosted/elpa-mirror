(define-package "lsp-cfn" "20220704.849" "LSP integration for cfn-lsp-extra"
  '((emacs "27.0")
    (lsp-mode "8.0.0")
    (yaml-mode "0.0.15"))
  :commit "924808977d7e5c4068ac92eca22b82fdeb4fff86" :authors
  '(("Laurence Warne"))
  :maintainer
  '("Laurence Warne")
  :url "https://github.com/LaurenceWarne/lsp-cfn.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
