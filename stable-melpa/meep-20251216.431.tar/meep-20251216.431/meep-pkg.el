;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251216.431"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "e02d8ad928be30b528edab09daa7d32a9da39752"
  :revdesc "e02d8ad928be"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
