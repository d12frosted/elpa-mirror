;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ruled-switch-buffer" "20211205.636"
  "Rule based buffer switching."
  '((emacs "24.3"))
  :url "https://github.com/kzkn/ruled-switch-buffer"
  :commit "99b53f7679e3eb868e4b4585085bbed102e5fce7"
  :revdesc "99b53f7679e3"
  :keywords '("convenience")
  :authors '(("Kazuki Nishikawa" . "kzkn@hey.com"))
  :maintainers '(("Kazuki Nishikawa" . "kzkn@hey.com")))
