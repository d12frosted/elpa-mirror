(define-package "vertico" "20231226.1303" "VERTical Interactive COmpletion"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "996d1223d2be41023c0331f00176a633a84a7d1d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "files" "matching" "completion")
  :url "https://github.com/minad/vertico")
;; Local Variables:
;; no-byte-compile: t
;; End:
