(define-package "hl-prog-extra" "20230709.2303" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "3ac2508a2220138ef97155624cb2f12e74b985a2" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
