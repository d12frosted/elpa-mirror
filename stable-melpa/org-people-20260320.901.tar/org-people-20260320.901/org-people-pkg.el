;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260320.901"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "2c6afef0b55c5e6d8999b6f3ceab4a9061fec79e"
  :revdesc "2c6afef0b55c"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
