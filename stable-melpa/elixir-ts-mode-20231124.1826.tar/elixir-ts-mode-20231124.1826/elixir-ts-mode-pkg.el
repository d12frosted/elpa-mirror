(define-package "elixir-ts-mode" "20231124.1826" "Major mode for Elixir with tree-sitter support"
  '((emacs "29.1")
    (heex-ts-mode "1.3"))
  :commit "70254355700ea5fa7fdfb5da42908f7b19cddb25" :authors
  '(("Wilhelm H Kirschbaum"))
  :maintainers
  '(("Wilhelm H Kirschbaum"))
  :maintainer
  '("Wilhelm H Kirschbaum")
  :keywords
  '("elixir" "languages" "tree-sitter")
  :url "https://github.com/wkirschbaum/elixir-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
