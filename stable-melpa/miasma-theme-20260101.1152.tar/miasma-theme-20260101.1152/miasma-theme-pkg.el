;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20260101.1152"
  "Miasma: color theme inspired by the woods."
  ()
  :url "http://github.com/daut/miasma-theme.el"
  :commit "ddc35014103d3b8bfbffe295afd5a86d6574c07e"
  :revdesc "ddc35014103d")
