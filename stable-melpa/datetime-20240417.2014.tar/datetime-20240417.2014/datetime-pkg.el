(define-package "datetime" "20240417.2014" "Parsing, formatting and matching timestamps"
  '((emacs "25.1")
    (extmap "1.1.1"))
  :commit "31afcecc780d1cec3abc48276c8e1b13ca7a4be1" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("lisp" "i18n")
  :url "https://github.com/doublep/datetime")
;; Local Variables:
;; no-byte-compile: t
;; End:
