;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-treeview" "20241025.2251"
  "A directory tree browser and simple file manager."
  '((emacs    "25.1")
    (treeview "1.3.0"))
  :url "https://github.com/tilmanrassy/emacs-dir-treeview"
  :commit "09cf976b0f5999e378141bb66361395f1832aeae"
  :revdesc "09cf976b0f59"
  :keywords '("tools" "convenience" "files")
  :authors '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainers '(("Tilman Rassy" . "tilman.rassy@googlemail.com")))
