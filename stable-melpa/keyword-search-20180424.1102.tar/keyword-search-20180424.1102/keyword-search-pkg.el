(define-package "keyword-search" "20180424.1102" "browser keyword search from Emacs" 'nil :commit "f8475ecaddb8804a9be6bee47678207c86ac8dee" :keywords
  ("web" "search" "keyword")
  :maintainer
  ("Jens Petersen")
  :url "https://github.com/juhp/keyword-search")
;; Local Variables:
;; no-byte-compile: t
;; End:
