(define-package "apdl-mode" "20210923.1933" "Major mode for the APDL programming language."
  '((emacs "25.1"))
  :commit "2f013b082582e1b491eee6a4173f2699ab7adf97" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("languages" "convenience" "tools" "ansys" "apdl")
  :url "https://github.com/dieter-wilhelm/apdl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
