(define-package "conventional-changelog" "20230101.1656" "Conventional Changelog Generator"
  '((emacs "26.3")
    (transient "0.3.7"))
  :commit "56f0e134f0edc1964965575dea259b186d34155a" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/liuyinz/emacs-conventional-changelog")
;; Local Variables:
;; no-byte-compile: t
;; End:
