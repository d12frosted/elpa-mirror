;;; ttl-ts-mode.el --- RDF Turtle editing mode -*- lexical-binding: t; -*-

;;; Copyright © 2026 Julian Flake <flake@uni-koblenz.de>

;; Author: Julian Flake <flake@uni-koblenz.de>
;; Maintainer: Julian Flake <flake@uni-koblenz.de>
;; Package-Version: 20261003.2135
;; Package-Revision: 2c6ad692170e
;; Package-Requires: ((emacs "29.1"))
;; Keywords: languages files rdf turtle treesitter
;; URL: https://codeberg.org/nutcase/ttl-ts-mode

;; This file is *NOT* part of GNU Emacs.

;; This package is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This package is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this package.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; A major mode for editing turtle files, powered by a tree-sitter parser
;; provided by https://github.com/GordianDziwis/tree-sitter-turtle
;;
;; Install the needed tree-sitter grammar by running
;; @code{ttl-ts-mode-install-grammar}.  Grammar downloader inspired by and
;; adopted from https://github.com/leon-barrett/just-ts-mode.el

;;; Code:

(require 'prog-mode)
(require 'treesit)

(defconst ttl-ts-mode--keywords
  '("@base" "BASE" "PREFIX" "@prefix" "GRAPH" "a"))

(defconst ttl-ts-mode--constants
  '("true" "false"))

(defconst ttl-ts-mode--indent-offset 2)

(defun ttl-ts-mode-setup ()
  "Set up treesit for \"ttl-ts-mode\"."
  (setq-local comment-start "#")
  (setq-local comment-end "")
  (setq-local treesit-font-lock-feature-list
	      '((comments)
		(keywords functions types variables constants)
		(strings)))
  (setq-local
   treesit-font-lock-settings
   (treesit-font-lock-rules
    :default-language 'turtle
    :feature 'comments
    '((comment) @font-lock-comment-face)
    :feature 'keywords
    `([,@ttl-ts-mode--keywords] @font-lock-keyword-face)
    :feature 'functions
    '((iri_reference) @font-lock-function-name-face)
    :feature 'types
    '((namespace) @font-lock-type-face)
    :feature 'variables
    '((pn_local) @font-lock-variable-name-face)
    :feature 'constants
    '((boolean_literal) @font-lock-constant-face
      (integer) @font-lock-constant-face
      (decimal) @font-lock-constant-face
      (double) @font-lock-constant-face)
    :feature 'strings
    `((rdf_literal) @font-lock-string-face)))
  (setq-local
   treesit-simple-indent-rules
   '((turtle
      ((node-is "property_list") prev-line ttl-ts-mode--indent-offset)
      ((node-is "property") first-sibling 0)
      ((parent-is "document") column-0 0))))
  (treesit-major-mode-setup))

;;;###autoload
(define-derived-mode ttl-ts-mode prog-mode "Turtle[ts]"
  "Major mode for editing turtle files using treesitter."

  (unless (treesit-ready-p 'turtle)
    (error "Tree-Sitter for `turtle' isn't available"))
  (treesit-parser-create 'turtle)
  (ttl-ts-mode-setup))

;; Language grammar installation

(defconst ttl-ts-mode-treesit-language-source
  '(turtle "https://github.com/GordianDziwis/tree-sitter-turtle"
	   :source-dir "src"
	   :commit "7f789ea7ef765080f71a298fc96b7c957fa24422")
  "The language source entry for the associated turtle language parser.")

(defun ttl-ts-mode-install-grammar ()
  "Install the language grammar for `ttl-ts-mode'.

The function removes existing entries for the turtle language in
`treesit-language-source-alist' and adds the entry stored in
`ttl-ts-mode-treesit-language-source'."
  (interactive)
  ;; Remove existing entries
  (setq treesit-language-source-alist
        (assq-delete-all 'turtle treesit-language-source-alist))
  ;; Add the correct entry
  (add-to-list 'treesit-language-source-alist
               ttl-ts-mode-treesit-language-source)
  ;; Install the grammar
  (treesit-install-language-grammar 'turtle))


(provide 'ttl-ts-mode)

;;;###autoload
(add-to-list 'auto-mode-alist '("\\.ttl\\'" . ttl-ts-mode))

;;; ttl-ts-mode.el ends here
