(define-package "kotlin-ts-mode" "20230531.901" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29"))
  :commit "422e294cb08356d61eef06424e85f400f395b1b9" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
