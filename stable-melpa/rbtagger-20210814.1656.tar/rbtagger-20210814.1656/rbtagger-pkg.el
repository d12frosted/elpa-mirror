(define-package "rbtagger" "20210814.1656" "Ruby tagging tools"
  '((emacs "25.1"))
  :commit "1cc5e965a221a5987ce0e075825d8002f0862f33" :authors
  '(("Thiago Araújo" . "thiagoaraujos@gmail.com"))
  :maintainer
  '("Thiago Araújo" . "thiagoaraujos@gmail.com")
  :keywords
  '("languages" "tools")
  :url "https://www.github.com/thiagoa/rbtagger")
;; Local Variables:
;; no-byte-compile: t
;; End:
