;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251109.211"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "41a5446083fcd497d62414ca3212b1c5a02118b0"
  :revdesc "41a5446083fc"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
