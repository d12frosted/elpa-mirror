;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "burnt-toast" "20201113.814"
  "Elisp integration with the BurntToast PowerShell module."
  '((emacs "25.1")
    (dash  "2.10")
    (alert "1.2"))
  :url "https://github.com/cedarbaum/burnt-toast.el"
  :commit "e9cf41928b7b502fdfa43718c35a24e503db32e2"
  :revdesc "e9cf41928b7b"
  :keywords '("alert" "notifications" "powershell" "comm")
  :authors '(("Sam Cedarbaum" . "(scedarbaum@gmail.com)"))
  :maintainers '(("Sam Cedarbaum" . "(scedarbaum@gmail.com)")))
