(define-package "burnt-toast" "20201113.814" "Elisp integration with the BurntToast PowerShell module"
  '((emacs "25.1")
    (dash "2.10")
    (alert "1.2"))
  :commit "eed66036d65b0ee26ce02371d14dce16a360acb4" :authors
  '(("Sam Cedarbaum" . "scedarbaum@gmail.com"))
  :maintainer
  '("Sam Cedarbaum" . "scedarbaum@gmail.com")
  :keywords
  '("alert" "notifications" "powershell" "comm")
  :url "https://github.com/cedarbaum/burnt-toast.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
