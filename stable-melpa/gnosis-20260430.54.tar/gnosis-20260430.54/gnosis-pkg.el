;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260430.54"
  "Knowledge System."
  '((emacs        "29.1")
    (compat       "29.1.4.2")
    (keymap-popup "0.2.0"))
  :url "https://codeberg.org/thanosapollo/emacs-gnosis"
  :commit "a912d97aee4ca4445b6a4f6c2427ac954328ee30"
  :revdesc "a912d97aee4c"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
