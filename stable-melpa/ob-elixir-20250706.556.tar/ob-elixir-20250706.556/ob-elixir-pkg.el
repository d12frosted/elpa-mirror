;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-elixir" "20250706.556"
  "Org-babel functions for elixir evaluation."
  '((org "8"))
  :url "https://github.com/zweifisch/ob-elixir"
  :commit "8e5d2f3c7adb0d5acde390264fec94627aa7af31"
  :revdesc "8e5d2f3c7adb"
  :keywords '("org" "babel" "elixir")
  :authors '(("ZHOU Feng" . "zf.pascal@gmail.com"))
  :maintainers '(("ZHOU Feng" . "zf.pascal@gmail.com")))
