(define-package "dracula-theme" "20220116.904" "Dracula Theme"
  '((emacs "24.3"))
  :commit "4b32fc5634e3fa786a73dc052b97dcf48e4fcf6a" :authors
  '(("film42"))
  :maintainer
  '("Étienne Deparis" . "etienne@depar.is")
  :url "https://github.com/dracula/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
