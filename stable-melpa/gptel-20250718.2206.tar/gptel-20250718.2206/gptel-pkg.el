;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250718.2206"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "dd48317a1ba3e0af0ffd5dc4b99191c27fff10f9"
  :revdesc "dd48317a1ba3"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
