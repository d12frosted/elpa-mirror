;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250513.904"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.76.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "80c75e0775f171d537ea4fd3d44ce9cdcf6b28a7"
  :revdesc "80c75e0775f1")
