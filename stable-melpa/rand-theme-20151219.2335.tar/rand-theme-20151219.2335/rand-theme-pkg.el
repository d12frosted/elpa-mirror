;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rand-theme" "20151219.2335"
  "Random Emacs theme at start-up!."
  '((cl-lib "0.5"))
  :url "https://github.com/gopar/rand-theme"
  :commit "65a00e5c5150f857aa96803b68f50bc8da0215b7"
  :revdesc "65a00e5c5150")
