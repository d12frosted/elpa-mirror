(define-package "modus-themes" "20220511.1618" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "3d6221e28481a62355a4b8d532aa82a8894a7a36" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
