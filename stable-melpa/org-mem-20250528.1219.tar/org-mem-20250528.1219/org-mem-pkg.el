;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250528.1219"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "9be6b76279b77429104a113b88cd4b069a3c755c"
  :revdesc "9be6b76279b7"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
