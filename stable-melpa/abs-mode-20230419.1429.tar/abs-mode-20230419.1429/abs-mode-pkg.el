(define-package "abs-mode" "20230419.1429" "Major mode for the modeling language Abs"
  '((emacs "26.1")
    (erlang "2.8")
    (maude-mode "0.3")
    (flymake "1.0")
    (yasnippet "0.14.0"))
  :commit "ce3bab5a6b2ec22810a20a6bd8aa2c014a5938a1" :authors
  '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainer
  '("Rudi Schlatte" . "rudi@constantly.at")
  :keywords
  '("languages")
  :url "https://github.com/abstools/abs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
