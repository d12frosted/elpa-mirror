;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20260313.1638"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "0e22fe420b5e24c2d0571896558b3d92c99f4736"
  :revdesc "0e22fe420b5e"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
