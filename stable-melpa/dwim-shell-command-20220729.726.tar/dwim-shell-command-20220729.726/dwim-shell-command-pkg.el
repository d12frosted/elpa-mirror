(define-package "dwim-shell-command" "20220729.726" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "4ea25d1cac537625bc13cf53c30ae78ee7be8061" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
