;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260804.1357"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "0e9e87de9a8a4ad47788af23869431a8ed4a7972"
  :revdesc "0e9e87de9a8a"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
