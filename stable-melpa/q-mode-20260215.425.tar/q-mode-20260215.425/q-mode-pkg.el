;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260215.425"
  "A q editing mode."
  '((emacs "24"))
  :url "https://github.com/psaris/q-mode"
  :commit "d37d99d3e917d2a80c02c14bb9560f4fd6177087"
  :revdesc "d37d99d3e917"
  :keywords '("faces" "files" "q"))
