;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "acp" "20260201.1911"
  "An ACP (Agent Client Protocol) implementation."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/acp.el"
  :commit "771e01e8605c7ce1b9618ba503a8f4139cbb4f95"
  :revdesc "771e01e8605c")
