;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-join" "20260621.722"
  "Join columns from other Org Mode tables."
  '((emacs "24.3"))
  :url "https://github.com/tbanel/orgtbljoin/blob/master/README.org"
  :commit "27e9658a8572a7030bd1eb5e4f416f45d04a5aac"
  :revdesc "27e9658a8572"
  :keywords '("data" "extensions"))
