(define-package "stimmung-themes" "20230209.1359" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "518b7ad3b6b8234d5a34dca1301f218f786e0a1c" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
