(define-package "org-contacts" "20240228.330" "Contacts management system for Org Mode"
  '((emacs "27.1")
    (org "9.3.4"))
  :commit "fe1f566f1b5cd0f5a7cf0d6f1c5cac99948d0493" :authors
  '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :url "https://repo.or.cz/org-contacts.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
