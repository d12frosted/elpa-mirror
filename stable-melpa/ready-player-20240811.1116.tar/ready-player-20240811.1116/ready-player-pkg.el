(define-package "ready-player" "20240811.1116" "Open media files in ready-player major mode"
  '((emacs "28.1"))
  :commit "92e219d8d1c5a2b21aa035ea5cf0c8c7422fc301" :url "https://github.com/xenodium/ready-player")
;; Local Variables:
;; no-byte-compile: t
;; End:
