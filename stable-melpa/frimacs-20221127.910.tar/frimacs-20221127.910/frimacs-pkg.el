(define-package "frimacs" "20221127.910" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "2aa343d743e70fa90ae06927fa2c7dabeca04fa2" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
