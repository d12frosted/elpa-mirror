;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260522.134"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "591324f248948f25de7d8a6607decf1566b1a80c"
  :revdesc "591324f24894"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
