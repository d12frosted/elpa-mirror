;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260314.118"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.89.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "76d818941769d32f74bebe48cec7d09523fc968a"
  :revdesc "76d818941769")
