(define-package "asm-blox" "20220124.1430" "Programming game involving WAT and YAML"
  '((emacs "26.1")
    (yaml "0.3.4"))
  :commit "ad00c5eb90f189223ef8a0b49c1dc5fef1ef26b0" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
