;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-diagrams" "20160407.1237"
  "Org-babel functions for diagrams evaluation."
  ()
  :url "http://orgmode.org"
  :commit "be45815f5596d181592fae709096b7b5f4a71992"
  :revdesc "be45815f5596"
  :keywords '("literate programming" "reproducible research"))
