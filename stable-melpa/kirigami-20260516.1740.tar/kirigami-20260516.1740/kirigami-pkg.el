;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260516.1740"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "a4c67ed19356b14450e63316ad817391387b2e35"
  :revdesc "a4c67ed19356"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
