;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20251206.718"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "47ecde2e815e4540bbb110bee1c0d5c50569f6f8"
  :revdesc "47ecde2e815e"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
