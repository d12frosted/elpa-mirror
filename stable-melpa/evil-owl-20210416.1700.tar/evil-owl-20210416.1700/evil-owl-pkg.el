;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-owl" "20210416.1700"
  "Preview evil registers and marks before using them."
  '((emacs "25.1")
    (evil  "1.2.13"))
  :url "https://github.com/mamapanda/evil-owl"
  :commit "a41a6d28e26052b25f3d21da37ccf1d8fde1e6aa"
  :revdesc "a41a6d28e260"
  :keywords '("emulations" "evil" "visual")
  :authors '(("Daniel Phan" . "daniel.phan36@gmail.com"))
  :maintainers '(("Daniel Phan" . "daniel.phan36@gmail.com")))
