;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lodgeit" "20190802.1308"
  "Paste to a lodgeit powered pastebin."
  ()
  :url "https://github.com/ionrock/lodgeit-el"
  :commit "442637194d48a7105b7747b8d98772f5899f9e21"
  :revdesc "442637194d48"
  :keywords '("pastebin" "lodgeit")
  :authors '(("Eric Larson" . "eric@ionrock.org"))
  :maintainers '(("Eric Larson" . "eric@ionrock.org")))
