;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-py-mode" "20251229.206"
  "Live Coding in Python."
  '((emacs "24.3"))
  :url "http://donkirkby.github.io/live-py-plugin/"
  :commit "7d47a58f52bab72de742e5ffced5dfb4c344de1d"
  :revdesc "7d47a58f52ba"
  :keywords '("live" "coding"))
