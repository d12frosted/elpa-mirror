(define-package "citre" "20221201.1131" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "0d6252ff912f629fec100187921cb5ec00436682" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
