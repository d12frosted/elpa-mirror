;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20250515.2317"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "bc46df5351b75a3fac39ae7636b796f15bec1698"
  :revdesc "bc46df5351b7"
  :keywords '("languages"))
