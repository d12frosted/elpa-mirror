(define-package "org-ml" "20211213.105" "Functional Org Mode API"
  '((emacs "26.1")
    (org "9.3")
    (dash "2.17")
    (s "1.12"))
  :commit "4fdf359fb716bf9b606650ac119ba10021f94f26" :authors
  '(("Nathan Dwarshuis" . "ndwar@yavin4.ch"))
  :maintainer
  '("Nathan Dwarshuis" . "ndwar@yavin4.ch")
  :keywords
  '("org-mode" "outlines")
  :url "https://github.com/ndwarshuis/org-ml")
;; Local Variables:
;; no-byte-compile: t
;; End:
