(define-package "lsp-docker" "20240318.1700" "LSP Docker integration"
  '((emacs "27.1")
    (dash "2.14.1")
    (lsp-mode "6.2.1")
    (f "0.20.0")
    (s "1.13.0")
    (yaml "0.2.0")
    (ht "2.0"))
  :commit "e4401a4a4ef43451fdaaf76e146359a3f6118d95" :authors
  '(("Ivan Yonchovski" . "yyoncho@gmail.com"))
  :maintainers
  '(("Ivan Yonchovski" . "yyoncho@gmail.com"))
  :maintainer
  '("Ivan Yonchovski" . "yyoncho@gmail.com")
  :keywords
  '("languages" "langserver")
  :url "https://github.com/emacs-lsp/lsp-docker")
;; Local Variables:
;; no-byte-compile: t
;; End:
