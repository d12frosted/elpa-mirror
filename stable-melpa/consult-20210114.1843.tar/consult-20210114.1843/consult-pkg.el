(define-package "consult" "20210114.1843" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7f45542d9f9013e422f293cc1aa3089cd6317e16" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
