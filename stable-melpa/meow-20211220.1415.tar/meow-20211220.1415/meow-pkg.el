(define-package "meow" "20211220.1415" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "a4b218f51d02775c9e0c647e79f07136b670a9fa" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
