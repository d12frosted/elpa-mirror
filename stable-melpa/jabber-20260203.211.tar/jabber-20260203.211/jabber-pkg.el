;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260203.211"
  "A minimal Jabber client."
  '((emacs "27.1")
    (fsm   "0.2.0")
    (srv   "0.2"))
  :url "https://codeberg.org/emacs-jabber/emacs-jabber"
  :commit "2b9dd87f8a182502383c9d4a72a140b1cc3ec8c2"
  :revdesc "2b9dd87f8a18"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("wgreenhouse" . "wgreenhouse@tilde.club")))
