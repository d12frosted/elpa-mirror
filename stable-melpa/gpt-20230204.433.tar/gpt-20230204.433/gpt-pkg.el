(define-package "gpt" "20230204.433" "Run instruction-following language models"
  '((emacs "24.4"))
  :commit "a5eb9ce9cced47c26ecac5fa6bee044054ef948e" :authors
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainers
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainer
  '("Andreas Stuhlmueller" . "andreas@ought.org")
  :keywords
  '("gpt3" "language" "copilot" "convenience" "tools")
  :url "https://github.com/stuhlmueller/gpt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
