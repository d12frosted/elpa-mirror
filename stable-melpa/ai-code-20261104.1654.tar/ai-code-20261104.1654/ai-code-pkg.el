;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261104.1654"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3d66ea59d6ffd218b69b82dee4ec6c5256537d37"
  :revdesc "3d66ea59d6ff"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
