(define-package "evil-matchit" "20220513.1221" "Vim matchit ported to Evil"
  '((evil "1.14.0")
    (emacs "25.1"))
  :commit "ec7a8479fec4c9249b52be9fd8e201bb0f3206f2" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("matchit" "vim" "evil")
  :url "http://github.com/redguardtoo/evil-matchit")
;; Local Variables:
;; no-byte-compile: t
;; End:
