(define-package "verilog-ext" "20231016.1156" "SystemVerilog Extensions"
  '((emacs "29.1")
    (verilog-mode "2023.6.6.141322628")
    (verilog-ts-mode "0.1.1")
    (lsp-mode "8.0.0")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (apheleia "3.1")
    (yasnippet "0.14.0")
    (flycheck "32")
    (outshine "3.0.1")
    (async "1.9.7"))
  :commit "a8e96554fd39c4be997a3c53a7cfec56c8669848" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("verilog" "ide" "tools")
  :url "https://github.com/gmlarumbe/verilog-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
