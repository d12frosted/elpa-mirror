;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251030.1027"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "223e81380587cf6c4c8a0ead4d3ae47e580bec24"
  :revdesc "223e81380587"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
