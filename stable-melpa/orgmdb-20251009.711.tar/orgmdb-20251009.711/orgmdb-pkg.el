;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgmdb" "20251009.711"
  "An OMDb API client with some convenience functions."
  '((emacs "27.1")
    (dash  "2.11.0")
    (s     "1.12.0")
    (org   "8.0.0"))
  :url "https://github.com/isamert/orgmdb.el"
  :commit "405df0ac4045c9cb794348f95f24a8b8fb777c42"
  :revdesc "405df0ac4045"
  :authors '(("Isa Mert Gurbuz" . "isamert@protonmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamert@protonmail.com")))
