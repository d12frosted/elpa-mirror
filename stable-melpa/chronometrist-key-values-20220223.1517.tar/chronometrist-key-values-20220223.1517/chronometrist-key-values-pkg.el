(define-package "chronometrist-key-values" "20220223.1517" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "7334be5743f27a965bcf1a2ad06650d7fa8d907b" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
