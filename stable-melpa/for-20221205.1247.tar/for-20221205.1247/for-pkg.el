(define-package "for" "20221205.1247" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "6fcd8ef4e9d6d22d67c833e760078e0cea5a9d58" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
