;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-cpp-complete" "20260110.37"
  "GPTel-powered C++ completion."
  '((emacs "30.1")
    (eglot "1.19")
    (gptel "0.9.8"))
  :url "https://github.com/beacoder/gptel-cpp-complete"
  :commit "4c7e79426ff61a3190c8aef24395dceb1ab9e943"
  :revdesc "4c7e79426ff6"
  :keywords '("programming" "convenience")
  :authors '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainers '(("Huming Chen" . "chenhuming@gmail.com")))
