(define-package "elisp-autofmt" "20221229.1127" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "983ecc268719c423f6fd3608eee75f351419951e" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
