;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260605.923"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "8301ff3af4b513934b1aeba6dfdc58015615cfab"
  :revdesc "8301ff3af4b5")
