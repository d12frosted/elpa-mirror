(define-package "magik-mode" "20210903.1345" "mode for editing Magik + some utils." 'nil :commit "d5da43b6a49b7b6a0b6b9ed19c13ac5a076b79b2" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
