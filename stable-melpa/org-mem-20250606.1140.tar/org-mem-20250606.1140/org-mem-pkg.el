;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250606.1140"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "2bc42e9e64c0be284e86854a0f9b1449cb7d1222"
  :revdesc "2bc42e9e64c0"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
