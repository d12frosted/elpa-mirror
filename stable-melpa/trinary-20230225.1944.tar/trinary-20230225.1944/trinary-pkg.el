(define-package "trinary" "20230225.1944" "Trinary logic"
  '((emacs "24"))
  :commit "fba6d32abe77466a3a8c5eac8e41a8f19c8c0c8d" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages")
  :url "https://github.com/emacs-elsa/trinary-logic")
;; Local Variables:
;; no-byte-compile: t
;; End:
