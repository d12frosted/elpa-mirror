;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfengine-code-style" "20171111.1027"
  "C code style for CFEngine project."
  ()
  :url "https://github.com/cfengine/core"
  :commit "92a25872a6d1de00c5bfc2b9455ccb0082bf6569"
  :revdesc "92a25872a6d1"
  :authors '(("Mikhail Gusarov" . "mikhail.gusarov@cfengine.com"))
  :maintainers '(("Mikhail Gusarov" . "mikhail.gusarov@cfengine.com")))
