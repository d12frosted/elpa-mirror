;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spotify" "20250106.1015"
  "Control the spotify application from emacs."
  '((cl-lib "0.5"))
  :url "https://codeberg.org/rwv/spotify-el"
  :commit "d918b5187638e0c44a2a2584f3980244b6aae3fa"
  :revdesc "d918b5187638"
  :keywords '("convenience"))
