(define-package "borg" "20230215.1517" "Assimilate Emacs packages as Git submodules"
  '((emacs "27.1")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "15a89056ceccb611c28aed8943faabec0539494a" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
