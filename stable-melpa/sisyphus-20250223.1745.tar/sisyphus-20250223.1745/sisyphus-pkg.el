;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sisyphus" "20250223.1745"
  "Create releases of Emacs packages."
  '((emacs  "27.1")
    (compat "30.0.1.0")
    (elx    "2.0.4")
    (llama  "0.4.1")
    (magit  "4.2.0"))
  :url "https://github.com/magit/sisyphus"
  :commit "1f908c997ed06bc826aef5a43b219e1e6c8fad8a"
  :revdesc "1f908c997ed0"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.sisyphus@jonas.bernoulli.dev")))
