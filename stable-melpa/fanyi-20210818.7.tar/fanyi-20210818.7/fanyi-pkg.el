(define-package "fanyi" "20210818.7" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "476f51f31fc558040ecbf0c95135bf9f1400e153" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
