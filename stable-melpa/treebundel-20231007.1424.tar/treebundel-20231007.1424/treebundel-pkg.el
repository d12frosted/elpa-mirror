(define-package "treebundel" "20231007.1424" "Bundle related git-worktrees together"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "0e63d0b3c9029b63b3e446e6317bd7d366c0436a" :authors
  '(("Ben Whitley"))
  :maintainers
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/treebundel")
;; Local Variables:
;; no-byte-compile: t
;; End:
