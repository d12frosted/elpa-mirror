;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asciidoc-mode" "20260604.1422"
  "Major mode for AsciiDoc markup."
  '((emacs "30.1"))
  :url "https://github.com/bbatsov/asciidoc-mode"
  :commit "d4d766e6e159b0e45624c7a1bbcf64bc72637147"
  :revdesc "d4d766e6e159"
  :keywords '("text" "asciidoc" "languages" "tree-sitter")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
