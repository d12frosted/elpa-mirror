(define-package "tree-edit" "20230419.1753" "A library for structural refactoring and editing"
  '((emacs "29.0")
    (dash "2.19")
    (reazon "0.4.0")
    (s "0.0.0"))
  :commit "e15b61e7e4ff98c44e6684fd2007bd1cbb31570e" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
