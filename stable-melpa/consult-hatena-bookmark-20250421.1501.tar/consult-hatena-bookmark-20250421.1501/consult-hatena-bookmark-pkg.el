;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-hatena-bookmark" "20250421.1501"
  "Consult commands for the Hatena Bookmark."
  '((emacs   "27.1")
    (consult "2.0"))
  :url "https://github.com/Nyoho/consult-hatena-bookmark"
  :commit "8f2e48688455711df89533a7fe5af1d9cd02c137"
  :revdesc "8f2e48688455")
