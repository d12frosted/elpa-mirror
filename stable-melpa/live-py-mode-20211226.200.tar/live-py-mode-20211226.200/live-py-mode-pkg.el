(define-package "live-py-mode" "20211226.200" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "c52678654478d43eb13b6bb540dab92436bff8c4" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
