(define-package "fussy" "20221010.2026" "Fuzzy completion style using `flx'"
  '((emacs "27.2")
    (flx "0.5"))
  :commit "0fbfcbace0729dba685da9b9a74566639b840ec3" :authors
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainers
  '(("James Nguyen" . "james@jojojames.com"))
  :maintainer
  '("James Nguyen" . "james@jojojames.com")
  :keywords
  '("matching")
  :url "https://github.com/jojojames/fussy")
;; Local Variables:
;; no-byte-compile: t
;; End:
