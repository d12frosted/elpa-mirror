(define-package "himalaya" "20230531.1417" "Interface for the himalaya email client"
  '((emacs "27.1"))
  :commit "d1694b760508bc2c3c50945e837b92959c34df31" :authors
  '(("Dante Catalfamo")
    ("soywod" . "clement.douin@posteo.net"))
  :maintainers
  '(("Dante Catalfamo"))
  :maintainer
  '("Dante Catalfamo")
  :keywords
  '("mail" "comm")
  :url "https://github.com/dantecatalfamo/himalaya-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
