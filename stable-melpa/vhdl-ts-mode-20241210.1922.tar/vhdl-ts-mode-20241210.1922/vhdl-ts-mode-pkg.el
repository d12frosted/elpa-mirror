;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ts-mode" "20241210.1922"
  "VHDL Tree-sitter major mode."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/vhdl-ts-mode"
  :commit "50c989fe4e656a82265c853ab834f70d406853e5"
  :revdesc "50c989fe4e65"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
