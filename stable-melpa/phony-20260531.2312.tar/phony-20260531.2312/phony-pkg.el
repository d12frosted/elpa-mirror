;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phony" "20260531.2312"
  "Speech bindings for Elisp."
  '((emacs      "29.1")
    (simulacrum "1.0.0"))
  :url "https://github.com/ErikPrantare/phony.el"
  :commit "1129dd32bb51cde770e62f56b7da50acd79790a4"
  :revdesc "1129dd32bb51"
  :keywords '("files"))
