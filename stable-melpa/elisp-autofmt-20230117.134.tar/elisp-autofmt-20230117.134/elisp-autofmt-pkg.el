(define-package "elisp-autofmt" "20230117.134" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "c900d444bbb33f956fdaa7e71a6945d64689e6f6" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
