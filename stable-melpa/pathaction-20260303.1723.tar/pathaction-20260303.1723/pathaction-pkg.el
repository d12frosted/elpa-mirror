;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260303.1723"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "40d5dd85467c51fa87da7b2beb4749fa3b0e34e2"
  :revdesc "40d5dd85467c"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
