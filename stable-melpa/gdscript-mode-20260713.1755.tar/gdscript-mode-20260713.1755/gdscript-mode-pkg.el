;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260713.1755"
  "Major mode for Godot's GDScript language."
  '((emacs "29.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "0b3711ad17cac5647875a2de8673e0fe46cd516c"
  :revdesc "0b3711ad17ca"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
