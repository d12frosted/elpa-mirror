(define-package "gptai" "20230316.1710" "Integrate with the OpenAI API"
  '((emacs "24.1"))
  :commit "0de1f190b018123000c66d2860a5d8feecad4335" :authors
  '(("Anton Hibl" . "antonhibl11@gmail.com"))
  :maintainer
  '("Anton Hibl" . "antonhibl11@gmail.com")
  :keywords
  '("comm" "convenience")
  :url "https://github.com/antonhibl/gptai")
;; Local Variables:
;; no-byte-compile: t
;; End:
