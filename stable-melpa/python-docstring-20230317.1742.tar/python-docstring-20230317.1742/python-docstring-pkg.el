(define-package "python-docstring" "20230317.1742" "Smart Python docstring formatting" 'nil :commit "3fe87a28acdc83e63191a29fed8649f57d075e3b")
;; Local Variables:
;; no-byte-compile: t
;; End:
