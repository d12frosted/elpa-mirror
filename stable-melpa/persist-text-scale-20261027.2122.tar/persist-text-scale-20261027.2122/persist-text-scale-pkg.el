;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20261027.2122"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "3bca6787c7066621f8d48794f33d0ab7f4e7e9b2"
  :revdesc "3bca6787c706"
  :keywords '("convenience" "faces")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
