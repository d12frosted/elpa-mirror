;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260228.1815"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "78dafe64014ac5cdaa0325b2d5d90d2bf8b0cc51"
  :revdesc "78dafe64014a"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
