(define-package "major-mode-icons" "20170514.2315" "display icon for major-mode on mode-line."
  '((emacs "24.3")
    (powerline "2.4")
    (all-the-icons "2.3.0"))
  :commit "4ea38d22cd5c3ecaddd036ad56309d42bc2cab84" :keywords
  '("frames" "multimedia")
  :url "http://github.com/stardiviner/major-mode-icons")
;; Local Variables:
;; no-byte-compile: t
;; End:
