;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251205.1127"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "b3f59f0c52bd7dddb272227d4dc89a690f4bc2dd"
  :revdesc "b3f59f0c52bd"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
