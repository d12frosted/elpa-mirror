;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elx" "20260516.2125"
  "Extract information from Emacs Lisp libraries."
  '((emacs  "29.1")
    (compat "31.0")
    (llama  "1.0"))
  :url "https://github.com/emacscollective/elx"
  :commit "a5cbbac74c847819422a1424e7ee821829f2bbc1"
  :revdesc "a5cbbac74c84"
  :keywords '("docs" "libraries" "packages")
  :authors '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.elx@jonas.bernoulli.dev")))
