;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20260524.1818"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "8c9cdb1502fbd749dca6553ca350fc3da371263d"
  :revdesc "8c9cdb1502fb"
  :keywords '("maint")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
