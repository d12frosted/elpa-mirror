;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241216.411"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "0f4136e93b10d474eb832c85c29b68d553c0a3b2"
  :revdesc "0f4136e93b10"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
