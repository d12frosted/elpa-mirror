(define-package "boon" "20210921.1154" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "ee88a9bbb3d39e2fa216984b6349a122a80e3c99")
;; Local Variables:
;; no-byte-compile: t
;; End:
