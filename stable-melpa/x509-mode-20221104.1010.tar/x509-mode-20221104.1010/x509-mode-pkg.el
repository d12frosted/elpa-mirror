(define-package "x509-mode" "20221104.1010" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "297d12c00ccc2c4d0e9082d41d1dfa3b51f84daa" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
