(define-package "modus-themes" "20211203.1953" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "35827cbe6458e8854ef55fb24fccb808d72cfa48" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
