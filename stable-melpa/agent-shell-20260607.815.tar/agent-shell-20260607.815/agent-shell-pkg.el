;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260607.815"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e58909d79ae8b57ca392560a9e66e653902fe60e"
  :revdesc "e58909d79ae8")
