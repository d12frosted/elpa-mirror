;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260727.1215"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "1d56a87a5790b7f26562a58c46139ae33fde0da8"
  :revdesc "1d56a87a5790"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
