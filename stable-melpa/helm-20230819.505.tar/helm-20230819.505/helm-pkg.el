(define-package "helm" "20230819.505" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.4")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "8d48f2224f07dac10a5af4f375e4d8b9763726e5" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
