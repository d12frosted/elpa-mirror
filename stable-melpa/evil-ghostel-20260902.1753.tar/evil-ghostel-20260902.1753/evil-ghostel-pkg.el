;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260902.1753"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.52.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "2bea18f3b52bf97d8222fea706da6fabdfc2cbb8"
  :revdesc "2bea18f3b52b"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
