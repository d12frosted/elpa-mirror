(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "97f16b26518036b2c493dd6af11d98006ca49f77" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
