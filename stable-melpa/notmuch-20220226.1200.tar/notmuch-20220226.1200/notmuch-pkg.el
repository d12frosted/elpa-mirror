(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "0d0cc2a547b67183406458eba701427aa1f6fbbe" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
