(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "e3ad0087f3453c89871acac8b11da8bab1ac54df" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
