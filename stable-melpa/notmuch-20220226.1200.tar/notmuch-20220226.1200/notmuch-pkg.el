(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "8ed6a172b35708428f84f30af44fa81c12852e43" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
