(define-package "notmuch" "20220226.1200" "run notmuch within emacs" 'nil :commit "78aaef9a0b6f106e648367b18b46b48d885f9213" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
