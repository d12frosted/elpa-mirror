;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260321.802"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "ad619463d1a9cb466b8dd575cc905f2554886cd7"
  :revdesc "ad619463d1a9"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
