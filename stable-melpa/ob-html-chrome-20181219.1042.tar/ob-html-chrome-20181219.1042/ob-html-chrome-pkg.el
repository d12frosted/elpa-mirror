;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-html-chrome" "20181219.1042"
  "HTML code blocks converted to PNG using Chrome."
  '((emacs "24.4")
    (f     "0.20.0")
    (s     "1.7.0"))
  :url "https://github.com/nikclayton/ob-html-chrome"
  :commit "7af6e4a24ed0aaf67751bdf752c7ca0ba02bb8d4"
  :revdesc "7af6e4a24ed0"
  :keywords '("languages" "org" "org-babel" "chrome" "html")
  :authors '((nil . "NikClaytonnik@ngo.org.uk"))
  :maintainers '((nil . "NikClaytonnik@ngo.org.uk")))
