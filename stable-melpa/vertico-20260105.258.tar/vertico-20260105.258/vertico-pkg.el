;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20260105.258"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "11200d9a2dfc9f4ffdbf0b06c64cccafddf73906"
  :revdesc "11200d9a2dfc"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
