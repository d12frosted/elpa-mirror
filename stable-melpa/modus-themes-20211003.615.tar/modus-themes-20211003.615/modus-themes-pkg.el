(define-package "modus-themes" "20211003.615" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "96ead8ff4ceefed0cfe8a0059b5c96b3e7a532fe" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
