(define-package "ert-runner" "20201005.2336" "Opinionated Ert testing workflow"
  '((s "1.6.1")
    (dash "1.8.0")
    (f "0.10.0")
    (commander "0.2.0")
    (ansi "0.1.0")
    (shut-up "0.1.0"))
  :commit "80cf4f60ec8c1f04f58054ed8ad2dcfacc17d8b5" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("test")
  :url "http://github.com/rejeep/ert-runner.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
