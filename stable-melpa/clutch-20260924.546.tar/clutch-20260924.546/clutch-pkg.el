;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260924.546"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "4f72f569bbb4b62d84b8562c9e954fcd5bab9f09"
  :revdesc "4f72f569bbb4"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
