;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg-marginalia" "20261112.1443"
  "Show Epkg information in completion annotations."
  '((emacs      "29.1")
    (compat     "31.1")
    (cond-let   "1.1")
    (epkg       "4.2")
    (marginalia "2.13"))
  :url "https://github.com/emacscollective/epkg-marginalia"
  :commit "266a94f0b9f51c1722b4dcf0ac87c8aa8a99d75c"
  :revdesc "266a94f0b9f5"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg-marginalia@jonas.bernoulli.dev")))
