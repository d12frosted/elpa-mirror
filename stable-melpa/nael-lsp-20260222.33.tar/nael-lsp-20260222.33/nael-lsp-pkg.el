;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nael-lsp" "20260222.33"
  "Nael and lsp-mode."
  '((emacs    "29.1")
    (lsp-mode "9")
    (nael     "0.8.2"))
  :url "https://codeberg.org/mekeor/nael"
  :commit "fbfb6757365cbde89d7ae0b56727315db15d31e4"
  :revdesc "fbfb6757365c"
  :keywords '("languages")
  :authors '(("Mekeor Melire" . "mekeor@posteo.de"))
  :maintainers '(("Mekeor Melire" . "mekeor@posteo.de")))
