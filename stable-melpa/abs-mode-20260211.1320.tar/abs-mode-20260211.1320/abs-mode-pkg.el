;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "abs-mode" "20260211.1320"
  "Major mode for the modeling language Abs."
  '((emacs      "27.1")
    (erlang     "2.8")
    (maude-mode "0.3")
    (flymake    "1.0")
    (yasnippet  "0.14.0"))
  :url "https://github.com/abstools/abs-mode"
  :commit "aaf97a11ef799d424f34de9a651dcbe601e85b63"
  :revdesc "aaf97a11ef79"
  :keywords '("languages")
  :authors '(("Rudi Schlatte" . "rudi@constantly.at"))
  :maintainers '(("Rudi Schlatte" . "rudi@constantly.at")))
