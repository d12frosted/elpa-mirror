;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260601.525"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "583db9cd54845fbcc19af2015b249eaf5163e1c9"
  :revdesc "583db9cd5484"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
