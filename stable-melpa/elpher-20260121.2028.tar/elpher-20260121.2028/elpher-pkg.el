;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpher" "20260121.2028"
  "A friendly gopher and gemini client."
  '((emacs "27.1"))
  :url "https://thelambdalab.xyz/elpher"
  :commit "11d59512609db1220c1137014d97a4373e36155a"
  :revdesc "11d59512609d"
  :keywords '("comm" "gopher" "gemini")
  :authors '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainers '(("Tim Vaughan" . "plugd@thelambdalab.xyz")))
