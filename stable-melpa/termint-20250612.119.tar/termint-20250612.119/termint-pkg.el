;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "termint" "20250612.119"
  "Run REPLs in a terminal backend."
  '((emacs "29"))
  :url "https://github.com/milanglacier/termint.el"
  :commit "7e9744db13c0d122e4f60378923f688d3ef245c3"
  :revdesc "7e9744db13c0"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
