(define-package "bluesound" "20231123.909" "Play, pause, resume music on a Bluesound player"
  '((emacs "26.1"))
  :commit "f0383eac7c4b412f6e40ba79fa1ff91b124bb4d1" :authors
  '(("R.W. van 't Veer"))
  :maintainers
  '(("R.W. van 't Veer"))
  :maintainer
  '("R.W. van 't Veer")
  :keywords
  '("convenience" "multimedia")
  :url "https://git.sr.ht/~rwv/bluesound-el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
