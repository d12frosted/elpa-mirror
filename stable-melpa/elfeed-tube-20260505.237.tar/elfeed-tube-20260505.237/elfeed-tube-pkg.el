;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "20260505.237"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.2")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "2d7251d8363661f7bae3fd6b27ef88edc65d25ed"
  :revdesc "2d7251d83636"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
