;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260712.1350"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "62e8394f87ef1fe45df45bed81d1b3d26ec84f1c"
  :revdesc "62e8394f87ef"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
