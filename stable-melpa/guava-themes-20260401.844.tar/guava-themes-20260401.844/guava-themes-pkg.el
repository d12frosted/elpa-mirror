;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260401.844"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "f04dfba9cadc87a7c608c30591c60e9b2db4a731"
  :revdesc "f04dfba9cadc"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
