(define-package "ob-swiftui" "20231007.1736" "Org babel functions for SwiftUI evaluation"
  '((emacs "25.1")
    (swift-mode "8.2.0")
    (org "9.2.0"))
  :commit "fd2efd2150b644eb52945e9535b9c34aca2d3500" :authors
  '(("Alvaro Ramirez"))
  :maintainers
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/ob-swiftui")
;; Local Variables:
;; no-byte-compile: t
;; End:
