(define-package "binky" "20231020.1213" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "43a22709312be36bf4ce2960b3f7bd5a9075586e" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
