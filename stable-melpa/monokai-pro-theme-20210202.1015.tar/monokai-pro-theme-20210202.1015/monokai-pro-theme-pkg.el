(define-package "monokai-pro-theme" "20210202.1015" "A simple theme based on the Monokai Pro Sublime color schemes" 'nil :commit "3622b8ac0f36138eefa234846f5f886e794914ff" :authors
  '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/belak/emacs-monokai-pro-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
