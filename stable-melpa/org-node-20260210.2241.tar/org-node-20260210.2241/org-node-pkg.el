;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260210.2241"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.28.0")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "f08632a8d9aa8996a3ab6396fda89f8b7f173e80"
  :revdesc "f08632a8d9aa"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
