(define-package "moom" "20220901.1114" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "d36b315dd8dd647184d7396d4595e12d076f24bc" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
