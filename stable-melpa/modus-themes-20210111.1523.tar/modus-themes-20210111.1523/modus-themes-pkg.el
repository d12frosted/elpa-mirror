(define-package "modus-themes" "20210111.1523" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "2b52e60c2bf70ebbe071db5437e865380b5b65cb" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
