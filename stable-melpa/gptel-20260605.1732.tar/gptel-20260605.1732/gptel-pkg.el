;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260605.1732"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "bd2419a36f443edde22ae34f23aafbda1cbd5738"
  :revdesc "bd2419a36f44"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
