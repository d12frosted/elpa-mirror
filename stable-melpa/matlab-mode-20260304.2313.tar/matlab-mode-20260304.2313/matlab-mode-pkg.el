;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "matlab-mode" "20260304.2313"
  "Major mode for MATLAB(R) dot-m files."
  '((emacs "27.2"))
  :url "https://github.com/mathworks/Emacs-MATLAB-Mode"
  :commit "0ae8e73bd61a05225656dc8fb040e16bffd47c6a"
  :revdesc "0ae8e73bd61a"
  :keywords '("matlab(r)")
  :authors '(("Matt Wette" . "mwette@alumni.caltech.edu")
             ("Eric M. Ludlam" . "eludlam@mathworks.com"))
  :maintainers '(("Eric M. Ludlam" . "eludlam@mathworks.com")
                 ("Uwe Brauer" . "oub@mat.ucm.es")
                 ("John Ciolfi" . "john.ciolfi.32@gmail.com")))
