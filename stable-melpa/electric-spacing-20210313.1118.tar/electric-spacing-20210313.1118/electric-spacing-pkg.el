(define-package "electric-spacing" "20210313.1118" "Insert operators with surrounding spaces smartly" 'nil :commit "fb1437a3386f55440abdbe7c107c86e5b028bdc5" :authors
  '(("William Xu" . "william.xwl@gmail.com"))
  :maintainer
  '("William Xu" . "william.xwl@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
