;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260827.1500"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "c4e840dc24b9fa2dc4b53761b59c7e8f7f30a665"
  :revdesc "c4e840dc24b9"
  :keywords '("languages"))
