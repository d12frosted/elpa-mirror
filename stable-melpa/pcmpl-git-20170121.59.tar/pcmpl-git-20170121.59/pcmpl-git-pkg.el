(define-package "pcmpl-git" "20170121.59" "pcomplete for git" 'nil :commit "9472ac70baeda025ef7becd1cf141d72aec93f32" :keywords
  ("tools")
  :authors
  (("Leo Liu" . "sdl.web@gmail.com"))
  :maintainer
  ("Leo Liu" . "sdl.web@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
