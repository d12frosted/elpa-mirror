;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260314.1745"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.1"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "558c93631f6916d3bb46db9084447add13e30f6b"
  :revdesc "558c93631f69"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
