;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260215.2153"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "4de82266d54bfe8454e2f1364545922df0d76e51"
  :revdesc "4de82266d54b"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
