(define-package "llama-cpp" "20230915.1941" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "09cf982e421e5b0d66a1ee16ed77d4301b80e2a2" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
