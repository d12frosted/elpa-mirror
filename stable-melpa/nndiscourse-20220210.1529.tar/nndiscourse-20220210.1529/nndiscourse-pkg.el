(define-package "nndiscourse" "20220210.1529" "Gnus backend for Discourse"
  '((emacs "25.1")
    (dash "2.18.1")
    (anaphora "1.0.4")
    (rbenv "0.0.3")
    (json-rpc "0.0.1"))
  :commit "1b7d7bfc99b104b7c4948af9f3394b416105e9d9" :keywords
  '("news")
  :url "https://github.com/dickmao/nndiscourse")
;; Local Variables:
;; no-byte-compile: t
;; End:
