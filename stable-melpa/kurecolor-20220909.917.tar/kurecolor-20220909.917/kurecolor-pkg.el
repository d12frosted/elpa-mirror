(define-package "kurecolor" "20220909.917" "color editing goodies"
  '((emacs "24.4")
    (s "1.12"))
  :commit "abd50472915490966a1c7611e634b6244464ff32" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
