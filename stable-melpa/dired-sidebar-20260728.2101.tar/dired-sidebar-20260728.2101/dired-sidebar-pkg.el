;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-sidebar" "20260728.2101"
  "Tree browser leveraging dired."
  '((emacs  "29.1")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/dired-sidebar"
  :commit "8159b8a8134c9b6d65e3b3b22c54e034ae54db0b"
  :revdesc "8159b8a8134c"
  :keywords '("dired" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
