;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250626.225"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "806985902e88dc7af8c6d7c7bb6e1567c1674719"
  :revdesc "806985902e88"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
