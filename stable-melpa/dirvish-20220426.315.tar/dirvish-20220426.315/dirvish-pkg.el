(define-package "dirvish" "20220426.315" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "4c7628c2bab6b9109b1c2c63c4f2ac9a44f39a89" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
