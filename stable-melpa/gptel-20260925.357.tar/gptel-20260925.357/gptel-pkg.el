;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260925.357"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "ec25a41fb8bebf5ea08341a9d8c70c0ee907ee23"
  :revdesc "ec25a41fb8be"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
