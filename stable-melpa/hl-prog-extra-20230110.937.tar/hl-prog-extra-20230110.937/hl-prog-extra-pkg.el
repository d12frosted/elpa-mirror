(define-package "hl-prog-extra" "20230110.937" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "1d7b58df59639bd1b4487cdc4c9a455ada550d21" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
