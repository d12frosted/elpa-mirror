;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell-math-renderer" "20260927.934"
  "Display-math rendering for agent-shell."
  '((emacs                "29.1")
    (agent-shell          "0.66.1")
    (latex-to-svg-backend "0.10.0"))
  :url "https://github.com/alberti42/agent-shell-math-renderer"
  :commit "d78eff583fc54e5f7b49d2b309d1ffbc7604f5cb"
  :revdesc "d78eff583fc5"
  :keywords '("tex" "llm" "math" "education")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
