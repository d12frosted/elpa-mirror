;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260123.1535"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "a92bbc11318e0a258770ce3018f7e357fd320f46"
  :revdesc "a92bbc11318e")
