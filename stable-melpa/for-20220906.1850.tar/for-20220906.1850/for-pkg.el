(define-package "for" "20220906.1850" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "ef4a4f2e3762eca65552428ca56db4d49f0db4e2" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
