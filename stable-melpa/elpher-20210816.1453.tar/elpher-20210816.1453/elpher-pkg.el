(define-package "elpher" "20210816.1453" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "0916ee629368e59197a8c4c9869e31be397b17f6" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
