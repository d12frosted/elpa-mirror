;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spacebar" "20190719.334"
  "Workspaces Bar."
  '((eyebrowse "0.7.7")
    (emacs     "25.4.0"))
  :url "https://github.com/matthias-margush/spacebar"
  :commit "2b2cd0e786877273103f048e62a06b0027deca2d"
  :revdesc "2b2cd0e78687"
  :keywords '("convenience")
  :authors '(("Matthias Margush" . "matthias.margush@gmail.com"))
  :maintainers '(("Matthias Margush" . "matthias.margush@gmail.com")))
