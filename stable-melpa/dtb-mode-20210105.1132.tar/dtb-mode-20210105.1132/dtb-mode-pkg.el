;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dtb-mode" "20210105.1132"
  "Show device tree souce in dtbs."
  '((emacs "25"))
  :url "https://github.com/schspa/dtb-mode"
  :commit "d5bca7d1afaac5615c586b60c7314a1d0e2514dc"
  :revdesc "d5bca7d1afaa"
  :keywords '("dtb" "dts" "convenience")
  :authors '(("Schspa Shi" . "schspa@gmail.com"))
  :maintainers '(("Schspa Shi" . "schspa@gmail.com")))
