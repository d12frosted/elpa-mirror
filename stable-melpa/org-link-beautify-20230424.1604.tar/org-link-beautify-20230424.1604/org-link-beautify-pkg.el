(define-package "org-link-beautify" "20230424.1604" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1"))
  :commit "6e7f1303ec4e89b64ccde1ef0147db4fb46bf99b" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
