;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pophint" "20250202.713"
  "Provide navigation using pop-up tips, like Firefox's Vimperator Hint Mode."
  '((log4e      "0.4.0")
    (yaxception "1.0.0"))
  :url "https://github.com/aki2o/emacs-pophint"
  :commit "c37195caec62a56af77432a8bd92ac720689b5fe"
  :revdesc "c37195caec62"
  :keywords '("popup")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
