(define-package "modus-themes" "20220121.1841" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "1d799887cd3c8692c4bb05602f7d34c29cc57f37" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
