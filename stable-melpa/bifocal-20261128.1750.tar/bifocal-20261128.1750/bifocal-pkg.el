;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bifocal" "20261128.1750"
  "Split-screen scrolling for comint-mode buffers."
  '((emacs "24.4"))
  :url "https://github.com/riscy/bifocal-mode"
  :commit "0c6ac55eeb4c8919a0876ee12c1cd1f3f915674a"
  :revdesc "0c6ac55eeb4c"
  :keywords '("frames" "processes")
  :authors '((nil . "https://github.com/riscy/bifocal-mode/graphs/contributors"))
  :maintainers '(("Chris Rayner" . "dchrisrayner@gmail.com")))
