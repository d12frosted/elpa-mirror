(define-package "sly" "20210720.2128" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "5a05c033197693462e67004549c24e0676eed53b" :keywords
  '("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
