;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260926.1647"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "1a30a313f8236be51184e6993cf5ea418d537349"
  :revdesc "1a30a313f823"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
