;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zetteldesk-ref" "20250405.1601"
  "A zetteldesk extension for interfacing with literature nodes."
  '((zetteldesk        "1.0")
    (bibtex-completion "1.0")
    (emacs             "26.1"))
  :url "https://github.com/Vidianos-Giannitsis/zetteldesk-ref.el"
  :commit "0196835c5d6df65d46a4f642b716e6901ad0f4c1"
  :revdesc "0196835c5d6d"
  :authors '(("Vidianos Giannitsis" . "vidianosgiannitsis@gmail.com"))
  :maintainers '(("Vidianos Giannitsis" . "vidianosgiannitsis@gmail.com")))
