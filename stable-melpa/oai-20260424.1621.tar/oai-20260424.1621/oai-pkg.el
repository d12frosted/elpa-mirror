;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260424.1621"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "c0337224ed909e315665060b4fe4bb6b66d9b279"
  :revdesc "c0337224ed90"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
