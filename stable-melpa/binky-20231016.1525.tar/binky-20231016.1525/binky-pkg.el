(define-package "binky" "20231016.1525" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "bc07b17338f7ea1ed7c152cc698f89d3a3cc5f71" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
