;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20260113.1800"
  "Miasma: color theme inspired by the woods."
  ()
  :url "http://github.com/daut/miasma-theme.el"
  :commit "998aa50769722f1a92f99124d76a1689c2d9eaf1"
  :revdesc "998aa5076972")
