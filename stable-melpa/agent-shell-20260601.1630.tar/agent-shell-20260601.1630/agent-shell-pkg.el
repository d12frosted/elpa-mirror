;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260601.1630"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.92.2")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e01e5773e12aabb9076b027e2ff7aba64e573d5b"
  :revdesc "e01e5773e12a")
