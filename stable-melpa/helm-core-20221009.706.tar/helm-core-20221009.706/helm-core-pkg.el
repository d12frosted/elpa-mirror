(define-package "helm-core" "20221009.706" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "2f90302701a6e40727b1e3c97018a41a53856350" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
