;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261029.2127"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "17630296e9447dace7dc55ae2f495e9cabc41b0e"
  :revdesc "17630296e944"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
