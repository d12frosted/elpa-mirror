;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "the-matrix-theme" "20251101.1305"
  "Green-on-black dark theme inspired by \"The Matrix\" movie."
  '((emacs "26.1"))
  :url "https://github.com/monkeyjunglejuice/matrix-emacs-theme"
  :commit "fcf886a41d55d1e94681d50ff5180524e7cd7e0c"
  :revdesc "fcf886a41d55"
  :keywords '("faces" "theme")
  :authors '(("Dan Dee" . "monkeyjunglejuice@pm.me"))
  :maintainers '(("Dan Dee" . "monkeyjunglejuice@pm.me")))
