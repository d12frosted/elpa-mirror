;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-msg" "20260129.1431"
  "Org mode to send and reply to email in HTML."
  '((emacs   "24.4")
    (htmlize "1.54"))
  :url "https://github.com/jeremy-compostella/org-msg"
  :commit "0c93f4d6250c207099a3bcbd15dfd3fc91135515"
  :revdesc "0c93f4d6250c"
  :keywords '("extensions" "mail")
  :authors '(("Jérémy Compostella" . "jeremy.compostella@gmail.com"))
  :maintainers '(("Jérémy Compostella" . "jeremy.compostella@gmail.com")))
