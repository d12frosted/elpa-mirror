(define-package "x509-mode" "20230113.1259" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "6d153ade83edaa37df1c5bc528d600fdb63161b2" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
