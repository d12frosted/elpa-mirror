(define-package "modus-themes" "20220809.1644" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "2b0c31b94ddb82307181dcf0078cee2f3c187aec" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
