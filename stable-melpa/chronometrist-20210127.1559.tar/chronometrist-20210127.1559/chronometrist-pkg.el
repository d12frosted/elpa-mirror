(define-package "chronometrist" "20210127.1559" "A time tracker with a nice interface"
  '((emacs "25.1")
    (dash "2.16.0")
    (seq "2.20")
    (s "1.12.0")
    (ts "0.2")
    (anaphora "1.0.4"))
  :commit "22ea8b4e99bc354861a0331c6b33c53da736ab9c" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabber.fr"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabber.fr")
  :keywords
  '("calendar")
  :url "https://github.com/contrapunctus-1/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
