(define-package "embark" "20210730.14" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d40d4268e15a2a78a9675039d092a2f8ca257c9c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
