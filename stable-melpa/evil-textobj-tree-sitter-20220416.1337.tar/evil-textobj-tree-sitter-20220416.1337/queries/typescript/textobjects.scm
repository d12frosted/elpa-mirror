; inherits: javascript

