;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "phpstan" "20250407.1624"
  "Interface to PHPStan."
  '((emacs       "25.1")
    (compat      "30")
    (php-mode    "1.22.3")
    (php-runtime "0.2"))
  :url "https://github.com/emacs-php/phpstan.el"
  :commit "e90ed7c4521c825633c3c5aef4e047afd03c010d"
  :revdesc "e90ed7c4521c"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
