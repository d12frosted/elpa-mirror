;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260309.612"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "6006855aa4633966893a9c38fd3d6fc96e6cca1e"
  :revdesc "6006855aa463"
  :keywords '("languages"))
