(define-package "citre" "20220320.1714" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "b84428d282533069718ba10aa237df54024d5ca1" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
