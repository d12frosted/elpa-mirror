(define-package "sly" "20201125.1907" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "68561f1b7b66fa0240766ece836bb04da31ea17d" :keywords
  ("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
