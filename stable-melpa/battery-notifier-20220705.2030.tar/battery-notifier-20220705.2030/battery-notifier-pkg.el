;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "battery-notifier" "20220705.2030"
  "Notify when battery capacity is low."
  '((alert "1.3"))
  :url "https://github.com/jasonmj/battery-notifier"
  :commit "b7301d3633afff78609afd45dcf78268f98d52d3"
  :revdesc "b7301d3633af"
  :keywords '("hardware" "battery")
  :authors '(("Jason Johnson" . "(jason@fullsteamlabs.com)"))
  :maintainers '(("Jason Johnson" . "(jason@fullsteamlabs.com)")))
