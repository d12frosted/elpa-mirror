(define-package "modus-themes" "20211011.1643" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "67c57ba4dd5e262a92138e922a1e7454f13a330c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
