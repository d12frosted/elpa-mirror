(define-package "rescript-mode" "20230309.2126" "A major mode for editing ReScript"
  '((emacs "26.1"))
  :commit "924869f3b76f93860250a7783aeaf9da239355f8" :authors
  '(("Karl Landstrom" . "karl.landstrom@brgeight.se")
    ("Daniel Colascione" . "dancol@dancol.org")
    ("John Lee" . "jjl@pobox.com"))
  :maintainer
  '("John Lee" . "jjl@pobox.com")
  :keywords
  '("languages" "rescript")
  :url "https://github.com/jjlee/rescript-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
