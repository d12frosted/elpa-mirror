;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "comware-router-mode" "20240103.907"
  "Major mode for editing Comware configuration files."
  '((dash  "2.16.0")
    (emacs "24.3"))
  :url "https://github.com/daviderestivo/comware-router-mode"
  :commit "e1671efe5e0ade2dcbea0c17697d460cd8f0ba67"
  :revdesc "e1671efe5e0a"
  :keywords '("convenience" "faces")
  :authors '(("Davide Restivo" . "davide.restivo@yahoo.it"))
  :maintainers '(("Davide Restivo" . "davide.restivo@yahoo.it")))
