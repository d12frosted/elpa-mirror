;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "coq-commenter" "20170822.2309"
  "Coq commenting minor mode for proof."
  '((dash   "2.13.0")
    (s      "1.11.0")
    (cl-lib "0.5"))
  :url "https://github.com/ailrun/coq-commenter"
  :commit "7fe9a2cc0ebdb0b1e54a24eb7971d757fb588ac3"
  :revdesc "7fe9a2cc0ebd"
  :keywords '("comment" "coq" "proof")
  :authors '(("Junyoung Clare Jang" . "jjc9310@gmail.com"))
  :maintainers '(("Junyoung Clare Jang" . "jjc9310@gmail.com")))
