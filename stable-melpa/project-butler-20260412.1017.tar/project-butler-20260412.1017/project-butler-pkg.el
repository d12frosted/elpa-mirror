;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-butler" "20260412.1017"
  "Lay out a project's buffers."
  '((emacs "28.1"))
  :url "https://codeberg.org/jabbo/project-butler"
  :commit "87e5c035a4602fa4400a44a3dd413dfbf5e5c2e4"
  :revdesc "87e5c035a460"
  :keywords '("convenience" "projects")
  :authors '(("Stefan Thesing" . "software@webdings.de"))
  :maintainers '(("Stefan Thesing" . "software@webdings.de")))
