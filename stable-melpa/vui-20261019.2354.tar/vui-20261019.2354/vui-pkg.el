;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261019.2354"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "2529f0370de45e6ecb87192cd8c6a789381d0daf"
  :revdesc "2529f0370de4"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
