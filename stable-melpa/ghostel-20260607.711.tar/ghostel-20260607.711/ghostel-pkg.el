;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260607.711"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "bdc8205f1a6072aaae76fed2085a7fab865f2b8b"
  :revdesc "bdc8205f1a60"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
