(define-package "gumshoe" "20211023.1734" "Scoped spatial and temporal POINT movement tracking"
  '((emacs "25.1"))
  :commit "567539b97d1e8fe4b59e5383d24d48b32de1f927" :authors
  '(("overdr0ne"))
  :maintainer
  '("overdr0ne")
  :keywords
  '("tools")
  :url "https://github.com/Overdr0ne/gumshoe")
;; Local Variables:
;; no-byte-compile: t
;; End:
