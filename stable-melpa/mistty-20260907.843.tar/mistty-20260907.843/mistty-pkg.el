;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20260907.843"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "1fef33f5cd799f29b99519f5dab8c7171772542f"
  :revdesc "1fef33f5cd79"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
