;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sekka" "20260411.1026"
  "Pure Elisp Japanese IME inspired by SKK."
  '((emacs "25.1")
    (popup "0.5.2"))
  :url "https://github.com/kiyoka/sekka"
  :commit "d1ee0160385e4b39bb426110b906cb5d3eea3c6e"
  :revdesc "d1ee0160385e"
  :keywords '("i18n")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
