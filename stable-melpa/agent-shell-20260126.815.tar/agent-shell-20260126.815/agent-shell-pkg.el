;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260126.815"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e594fa748114cceacaf01d1ad721ed295fc5620f"
  :revdesc "e594fa748114")
