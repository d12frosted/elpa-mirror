(define-package "howm" "20230730.534" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "4b68c83cd2398dabec7c10ea73526659e0d27231" :authors
  '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com"))
  :maintainers
  '(("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "kakkokakko@gmail.com")
  :url "https://kaorahi.github.io/howm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
