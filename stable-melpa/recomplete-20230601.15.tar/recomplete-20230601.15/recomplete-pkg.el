(define-package "recomplete" "20230601.15" "Immediately (re)complete actions"
  '((emacs "26.1"))
  :commit "296ed0ecce65066f513182bbde2045fca9c1e035" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-recomplete")
;; Local Variables:
;; no-byte-compile: t
;; End:
