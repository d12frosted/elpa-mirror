;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ess" "20260408.952"
  "Emacs Speaks Statistics."
  '((emacs "25.1"))
  :url "https://ess.r-project.org/"
  :commit "d8d8e4e87a663edbeb42d7e43f8096c95bbb6e15"
  :revdesc "d8d8e4e87a66"
  :authors '(("David Smith" . "dsmith@stats.adelaide.edu.au")
             ("A.J. Rossini" . "blindglobe@gmail.com")
             ("Richard M. Heiberger" . "rmh@temple.edu")
             ("Kurt Hornik" . "Kurt.Hornik@R-project.org")
             ("Martin Maechler" . "maechler@stat.math.ethz.ch")
             ("Rodney A. Sparapani" . "rsparapa@mcw.edu")
             ("Stephen Eglen" . "stephen@gnu.org")
             ("Sebastian P. Luque" . "spluque@gmail.com")
             ("Henning Redestig" . "henning.red@googlemail.com")
             ("Vitalie Spinu" . "spinuvit@gmail.com")
             ("Lionel Henry" . "lionel.hry@gmail.com")
             ("J. Alexander Branham" . "alex.branham@gmail.com"))
  :maintainers '(("ESS Core Team" . "ESS-core@r-project.org")))
