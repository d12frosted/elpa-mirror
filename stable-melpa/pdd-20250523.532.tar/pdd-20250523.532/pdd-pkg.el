;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250523.532"
  "Mordern HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "b82a34b3dd2a70cddf74de2d29fc8754a50548b6"
  :revdesc "b82a34b3dd2a"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
