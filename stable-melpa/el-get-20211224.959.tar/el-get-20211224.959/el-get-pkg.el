(define-package "el-get" "20211224.959" "Manage the external elisp bits and pieces you depend upon" 'nil :commit "91352ca0f895d099f608644c8e9ad8e844b5c520" :authors
  '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainer
  '("Dimitri Fontaine" . "dim@tapoueh.org")
  :keywords
  '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :url "http://www.emacswiki.org/emacs/el-get")
;; Local Variables:
;; no-byte-compile: t
;; End:
