(define-package "el-get" "20211224.959" "Manage the external elisp bits and pieces you depend upon" 'nil :commit "a620c91fe7d6d482c0e7538df75e10af0af1bb16" :authors
  '(("Dimitri Fontaine" . "dim@tapoueh.org"))
  :maintainer
  '("Dimitri Fontaine" . "dim@tapoueh.org")
  :keywords
  '("emacs" "package" "elisp" "install" "elpa" "git" "git-svn" "bzr" "cvs" "svn" "darcs" "hg" "apt-get" "fink" "pacman" "http" "http-tar" "emacswiki")
  :url "http://www.emacswiki.org/emacs/el-get")
;; Local Variables:
;; no-byte-compile: t
;; End:
