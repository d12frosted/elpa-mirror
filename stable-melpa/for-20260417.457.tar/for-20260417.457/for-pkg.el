;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "for" "20260417.457"
  "Iteration and sequence."
  '((emacs "28.1"))
  :url "https://github.com/usaoc/elisp-for"
  :commit "2e18cf627ecf4c390e295a73d61ab1eba7d076f4"
  :revdesc "2e18cf627ecf"
  :keywords '("extensions")
  :authors '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainers '(("Wing Hei Chan" . "whmunkchan@outlook.com")))
