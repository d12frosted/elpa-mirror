(define-package "flexoki-themes" "20231121.1653" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "1b871e57e989d58a793cbfef7b4996a6bd47ba9f" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
