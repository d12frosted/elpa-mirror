(define-package "helm-core" "20210318.1327" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "5903bfc005cecdfffa121bb3a8ca0d92d0de93ce")
;; Local Variables:
;; no-byte-compile: t
;; End:
