;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20260305.1317"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (cond-let      "0.2")
    (llama         "1.0")
    (magit-section "4.3.0")
    (org-mem       "0.34.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "9a946ec6df977df9c39fc924cc2c0834f3cc0d2e"
  :revdesc "9a946ec6df97"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
