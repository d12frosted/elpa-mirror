;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260110.1530"
  "Unified interface for AI coding CLI tool such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "26.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "1c17cf94a4f38a918a5ed61fc2958232c42a50fe"
  :revdesc "1c17cf94a4f3"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
