(define-package "ejc-sql" "20221208.2116" "Emacs SQL client uses Clojure JDBC."
  '((emacs "26.3")
    (clomacs "0.0.5")
    (dash "2.16.0")
    (spinner "1.7.3"))
  :commit "c236f79b48c0f4691500723841a9d356203a4b13" :authors
  '(("Kostafey" . "kostafey@gmail.com"))
  :maintainer
  '("Kostafey" . "kostafey@gmail.com")
  :keywords
  '("sql" "jdbc")
  :url "https://github.com/kostafey/ejc-sql")
;; Local Variables:
;; no-byte-compile: t
;; End:
