;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-table-highlight" "20250718.12"
  "Highlight Org table columns and rows."
  '((emacs "27.1"))
  :url "https://github.com/llcc/org-table-highlight"
  :commit "cc12de2cd5baa4d2c6cd6d214577e439948b5595"
  :revdesc "cc12de2cd5ba"
  :keywords '("org-table" "convenience"))
