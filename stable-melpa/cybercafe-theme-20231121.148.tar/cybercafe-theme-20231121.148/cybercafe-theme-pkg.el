(define-package "cybercafe-theme" "20231121.148" "Cybercafe color theme"
  '((emacs "24.1"))
  :commit "f43d0af87d9969dc46405c7415db8ce9deca9c52" :authors
  '((nil . "Gabriel de Brito gabrielgbrito@icloud.com"))
  :maintainers
  '((nil . "Gabriel de Brito gabrielgbrito@icloud.com"))
  :maintainer
  '(nil . "Gabriel de Brito gabrielgbrito@icloud.com")
  :keywords
  '("faces")
  :url "http://github.com/gboncoffee/cybercafe-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
