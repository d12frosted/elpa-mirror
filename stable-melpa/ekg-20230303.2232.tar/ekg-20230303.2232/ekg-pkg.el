(define-package "ekg" "20230303.2232" "A system for recording and linking information"
  '((triples "0.2.5")
    (emacs "28.1"))
  :commit "77fd7a825557bdf6581fc23761dce36246a3b6de" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
