(define-package "asm-blox" "20221101.148" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "adead194f258ce8f283887318bac71dc1eaa87b1" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
