;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "no-littering" "20260513.1803"
  "Help keeping ~/.config/emacs clean."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/emacscollective/no-littering"
  :commit "251cf4f9d33d8f1c4cee55a8c408f1b676920d0d"
  :revdesc "251cf4f9d33d"
  :keywords '("convenience")
  :authors '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.no-littering@jonas.bernoulli.dev")))
