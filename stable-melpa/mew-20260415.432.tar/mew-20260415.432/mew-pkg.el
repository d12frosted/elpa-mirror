;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260415.432"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "d1ddc69cd00859c916e7a9b908afbcd5721fc7be"
  :revdesc "d1ddc69cd008")
