(define-package "dylan-mode" "20210301.529" "Major mode for the Dylan programming language. http://opendylan.org" 'nil :commit "a37b045157a331d60bd832b292339464ac4a59e2" :authors
  '(("Robert Stockton" . "rgs@cs.cmu.edu"))
  :maintainer
  '("Chris Page" . "cpage@opendylan.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
