(define-package "loco" "20240717.2051" "Enter complex key sequences with ease!"
  '((emacs "29.1"))
  :commit "40c970600c1b1c775eb2a938a8f335fe456b2642" :authors
  '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainers
  '(("Chris McLaren" . "csmclaren@me.com"))
  :maintainer
  '("Chris McLaren" . "csmclaren@me.com")
  :keywords
  '("abbrev" "convenience")
  :url "https://github.com/csmclaren/loco")
;; Local Variables:
;; no-byte-compile: t
;; End:
