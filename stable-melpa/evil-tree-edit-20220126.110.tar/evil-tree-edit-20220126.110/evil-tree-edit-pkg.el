(define-package "evil-tree-edit" "20220126.110" "Evil structural editing for any language!"
  '((emacs "27.1")
    (tree-edit "0.1.0")
    (tree-sitter "0.15.0")
    (evil "1.0.0")
    (avy "0.5.0")
    (s "0.0.0"))
  :commit "0a718e473651d4443f24d0f6625f96822be21cd0" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
