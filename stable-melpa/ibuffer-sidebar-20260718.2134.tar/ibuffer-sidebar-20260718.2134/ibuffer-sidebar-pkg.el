;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ibuffer-sidebar" "20260718.2134"
  "Sidebar for `ibuffer'."
  '((emacs "29.1"))
  :url "https://github.com/jojojames/ibuffer-sidebar"
  :commit "b9b985f4ceb627521ed78cfdc4270305f3b0f272"
  :revdesc "b9b985f4ceb6"
  :keywords '("ibuffer" "files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
