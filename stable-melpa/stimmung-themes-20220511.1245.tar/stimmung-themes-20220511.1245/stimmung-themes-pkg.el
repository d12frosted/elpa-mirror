(define-package "stimmung-themes" "20220511.1245" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "d34e83d6a00c248c7ce9ab34425773c30910f634" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
