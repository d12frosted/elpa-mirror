;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260207.2005"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "1e3b452483bda3b450ccc8b98ba256992f86dc2d"
  :revdesc "1e3b452483bd"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
