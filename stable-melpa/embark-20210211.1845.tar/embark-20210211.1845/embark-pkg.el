(define-package "embark" "20210211.1845" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "34e9070140f63627929a88503659fe82bef75d46" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
