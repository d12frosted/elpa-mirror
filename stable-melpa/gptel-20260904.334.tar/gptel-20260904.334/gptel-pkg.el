;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260904.334"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "cf0eb7d2289581e7d1f0eed52b29870d8739d4f2"
  :revdesc "cf0eb7d22895"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
