(define-package "ein" "20200127.249" "Emacs IPython Notebook"
  '((emacs "25")
    (websocket "20191017.30")
    (auto-complete "1.4.0")
    (request "20190621.1622")
    (deferred "0.5")
    (polymode "20190426.1729")
    (markdown-mode "20171116.756")
    (dash "2.13.0")
    (s "1.11.0")
    (skewer-mode "1.6.2"))
  :commit "42f8efc54bfb915248972490a4b438b8d5bda381" :authors
  '(("John Miller <millejoh at millejoh.com>, Takafumi Arakaki <aka.tkf at gmail.com>"))
  :maintainer
  '("John Miller <millejoh at millejoh.com>, Takafumi Arakaki <aka.tkf at gmail.com>")
  :keywords
  '("jupyter" "literate programming" "reproducible research")
  :url "http://millejoh.github.io/emacs-ipython-notebook/")
;; Local Variables:
;; no-byte-compile: t
;; End:
