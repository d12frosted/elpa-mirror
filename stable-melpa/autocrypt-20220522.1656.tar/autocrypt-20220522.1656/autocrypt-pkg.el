(define-package "autocrypt" "20220522.1656" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "a89bbd717edfd0d0b9826b38d5300f8f5c86006b" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
