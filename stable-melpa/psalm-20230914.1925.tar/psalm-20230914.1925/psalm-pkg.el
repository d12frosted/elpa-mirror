;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "psalm" "20230914.1925"
  "Interface to Psalm."
  '((emacs    "27.1")
    (php-mode "1.22.3"))
  :url "https://github.com/emacs-php/psalm.el"
  :commit "9449c09b8d570705aa74b5aef7651893b482cc66"
  :revdesc "9449c09b8d57"
  :keywords '("tools" "php")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
