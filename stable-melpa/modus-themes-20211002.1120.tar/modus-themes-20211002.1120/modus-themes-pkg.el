(define-package "modus-themes" "20211002.1120" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "393c5c2fdf81f24370eb7e42944d5e949f2e4daa" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
