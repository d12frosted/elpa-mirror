;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "global-tags" "20211120.347"
  "Elisp API and editor integration for GNU global."
  '((emacs   "26.1")
    (async   "1.9.4")
    (project "0.5.2")
    (ht      "2.3"))
  :url "https://launchpad.net/global-tags.el"
  :commit "aaa37da4c538f35a90149ef4ad3d8b0922af54ab"
  :revdesc "aaa37da4c538"
  :keywords '("convenience" "matching" "tools")
  :authors '(("Felipe Lema" . "felipelema@mortemale.org"))
  :maintainers '(("Felipe Lema" . "felipelema@mortemale.org")))
