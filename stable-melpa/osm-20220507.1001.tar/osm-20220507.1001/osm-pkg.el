(define-package "osm" "20220507.1001" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "17884f69eb9681db880865af73762686c8e83cc0" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
