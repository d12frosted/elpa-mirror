(define-package "shell-command-x" "20231106.1958" "Extensions for shell commands"
  '((emacs "28.1"))
  :commit "4b844554ee6250983717d136b2eadebcece945e3" :authors
  '(("Eliza Velasquez"))
  :maintainers
  '(("Eliza Velasquez"))
  :maintainer
  '("Eliza Velasquez")
  :keywords
  '("convenience" "processes" "unix")
  :url "https://github.com/elizagamedev/shell-command-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
