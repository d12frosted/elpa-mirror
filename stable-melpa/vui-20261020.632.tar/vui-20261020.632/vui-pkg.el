;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261020.632"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "6e2296118467b10d54fc801b54bf496349ee0362"
  :revdesc "6e2296118467"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
