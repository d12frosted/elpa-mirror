(define-package "chatgpt-shell" "20240611.1755" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.50.1"))
  :commit "6493a482e57e63cf301eac8997394a01d39f566e" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
