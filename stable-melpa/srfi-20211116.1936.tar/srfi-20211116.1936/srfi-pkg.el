(define-package "srfi" "20211116.1936" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "8874e933643b91d9c545fd4ca3f0ea986561da31" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
