(define-package "lem" "20240225.1034" "A lemmy client"
  '((emacs "29.1")
    (fedi "0.2")
    (markdown-mode "2.5"))
  :commit "f289ef0fe54f2f4d36653c0443d57094542a2000" :authors
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainers
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainer
  '("martian hiatus <martianhiatus [a t] riseup [d o t] net>")
  :keywords
  '("multimedia" "comm" "web" "fediverse")
  :url "https://codeberg.org/martianh/lem.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
