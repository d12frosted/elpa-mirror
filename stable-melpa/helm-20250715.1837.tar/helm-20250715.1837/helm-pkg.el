;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250715.1837"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "02db3a26223c59dd5c80b53626c69c6bca62d000"
  :revdesc "02db3a26223c"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
