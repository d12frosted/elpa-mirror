(define-package "immersive-translate" "20230821.145" "Translate the current buffer immersively"
  '((emacs "28.2"))
  :commit "7fe460980907f75217c0ecd3b6865f72f325ee90" :authors
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainers
  '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainer
  '("Eli Qian" . "eli.q.qian@gmail.com")
  :keywords
  '("convenience" "help" "translate")
  :url "https://github.com/Elilif/emacs-immersive-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
