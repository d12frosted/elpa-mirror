(define-package "org-caldav" "20230625.35" "Sync org files with external calendar through CalDAV"
  '((emacs "26.3")
    (org "9.1"))
  :commit "43fba8b59ff89903d1313c3343722160b7d5ff8b" :authors
  '(("David Engster" . "deng@randomsample.de"))
  :maintainers
  '(("David Engster" . "deng@randomsample.de"))
  :maintainer
  '("David Engster" . "deng@randomsample.de")
  :keywords
  '("calendar" "caldav")
  :url "https://github.com/dengste/org-caldav/")
;; Local Variables:
;; no-byte-compile: t
;; End:
