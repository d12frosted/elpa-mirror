;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "triode" "20261005.339"
  "Interface to Triode app, macOS internet radio."
  '((emacs     "30.1")
    (transient "0.9.0")
    (restlib   "0.1.5")
    (shazam    "1.0.0"))
  :url "https://github.com/kickingvegas/triode"
  :commit "1c8af892bd8ba477fccd281271a9bbaee9f606ec"
  :revdesc "1c8af892bd8b"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
