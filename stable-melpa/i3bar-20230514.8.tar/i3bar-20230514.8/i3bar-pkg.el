(define-package "i3bar" "20230514.8" "Display status from an i3status command in the tab bar"
  '((emacs "28.1"))
  :commit "6bbad0891d330b119c77c036643bfb5f9d4d25e3" :authors
  '(("Steven Allen" . "steven@stebalien.com"))
  :maintainers
  '(("Steven Allen" . "steven@stebalien.com"))
  :maintainer
  '("Steven Allen" . "steven@stebalien.com")
  :keywords
  '("unix")
  :url "https://github.com/Stebalien/i3bar.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
