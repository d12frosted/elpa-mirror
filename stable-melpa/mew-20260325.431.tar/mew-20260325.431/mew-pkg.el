;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260325.431"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "59ec3fa2ec13238509f5caf46b80c5c8fc4c1a3c"
  :revdesc "59ec3fa2ec13")
