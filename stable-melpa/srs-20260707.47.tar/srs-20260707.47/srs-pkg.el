;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srs" "20260707.47"
  "Spaced repetition in plain text."
  '((emacs     "30.2")
    (transient "0.12.0"))
  :url "https://github.com/Duncan-Britt/srs.el"
  :commit "0d7f8f0a0c0adabe212210439676cdd933091df9"
  :revdesc "0d7f8f0a0c0a"
  :keywords '("hypermedia" "srs" "memory")
  :authors '(("Duncan Britt" . "duncanbritt.com"))
  :maintainers '(("Duncan Britt" . "duncanbritt.com")))
