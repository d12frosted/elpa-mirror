(define-package "sly-named-readtables" "20191013.2138" "Support named readtables in Common Lisp files"
  '((sly "1.0.0beta2"))
  :commit "a5a42674ccffa97ccd5e4e9742beaf3ea719931f" :keywords
  ("languages" "lisp" "sly")
  :authors
  (("João Távora" . "joaotavora@gmail.com"))
  :maintainer
  ("João Távora" . "joaotavora@gmail.com")
  :url "https://github.com/capitaomorte/sly-named-readtables")
;; Local Variables:
;; no-byte-compile: t
;; End:
