;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-racer" "20170114.809"
  "Auto-complete source of racer."
  '((emacs         "24.3")
    (auto-complete "1.5.0")
    (racer         "0.0.2"))
  :url "https://github.com/syohex/emacs-ac-racer"
  :commit "4408c2d652dec0432e20c05e001db8222d778c6b"
  :revdesc "4408c2d652de"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
