(define-package "dirvish" "20220614.1823" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "40397c02aa5a08f78cc1b8ead702285364f1cf34" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
