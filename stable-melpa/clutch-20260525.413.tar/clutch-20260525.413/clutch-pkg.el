;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260525.413"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.1")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "3b8fb5b274236b144341a019fb19a380b650e675"
  :revdesc "3b8fb5b27423"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
