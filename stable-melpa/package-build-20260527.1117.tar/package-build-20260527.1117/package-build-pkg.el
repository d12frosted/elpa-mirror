;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260527.1117"
  "Curate an Emacs Lisp package archive."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/melpa/package-build"
  :commit "dd951e217c0844512a011e6bf739562dfc909f69"
  :revdesc "dd951e217c08"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
