(define-package "npm" "20200812.1850" "Run your npm workflows"
  '((emacs "25.1")
    (transient "0.1.0")
    (jest "20200625"))
  :commit "26d5cf79dfd1a2a74a66c44de129483d26354345" :keywords
  ("tools")
  :authors
  (("Shane Kennedy"))
  :maintainer
  ("Shane Kennedy")
  :url "https://github.com/shaneikennedy/npm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
