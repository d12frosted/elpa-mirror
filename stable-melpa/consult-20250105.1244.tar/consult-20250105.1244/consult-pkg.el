;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20250105.1244"
  "Consulting completing-read."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "fd85f17d6f9931b76f4f4630c08e690e52b548ac"
  :revdesc "fd85f17d6f99"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
