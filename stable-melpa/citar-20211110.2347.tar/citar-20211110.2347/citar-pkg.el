(define-package "citar" "20211110.2347" "Citation-related commands for org, latex, markdown."
  '((emacs "27.1")
    (s "1.12")
    (parsebib "3.0")
    (org "9.5"))
  :commit "c83217282f1f0acff8507c8a9b0b3730a7546cac" :authors
  '(("Bruce D'Arcus <https://github.com/bdarcus>"))
  :maintainer
  '("Bruce D'Arcus <https://github.com/bdarcus>")
  :url "https://github.com/bdarcus/citar")
;; Local Variables:
;; no-byte-compile: t
;; End:
