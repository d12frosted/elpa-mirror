(define-package "embark" "20220329.34" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "8460d47768cba7b0019c59f4007120bd94109a1b" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
