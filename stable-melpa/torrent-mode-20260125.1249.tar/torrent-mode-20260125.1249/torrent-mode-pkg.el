;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "torrent-mode" "20260125.1249"
  "Display torrent files in a tabulated view."
  '((emacs     "26.1")
    (tablist   "1.0")
    (bencoding "1.0"))
  :url "https://github.com/sarg/torrent-mode.el"
  :commit "951f79f65e49fcad038b69bfcaf8968d6f8a3b2f"
  :revdesc "951f79f65e49"
  :authors '(("Sergey Trofimov" . "sarg@sarg.org.ru"))
  :maintainers '(("Sergey Trofimov" . "sarg@sarg.org.ru")))
