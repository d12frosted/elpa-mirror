;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "avy-flycheck" "20260815.506"
  "Jump to and fix syntax errors using `flycheck' with `avy' interface."
  '((emacs    "24.1")
    (flycheck "0.14")
    (seq      "1.11")
    (avy      "0.4.0"))
  :url "https://github.com/magicdirac/avy-flycheck"
  :commit "2279e2461d4a1ec1481e760c911defd84fc91742"
  :revdesc "2279e2461d4a"
  :keywords '("tools" "convenience" "avy" "flycheck")
  :authors '(("Xu Ma" . "magicdirac@gmail.com"))
  :maintainers '(("Xu Ma" . "magicdirac@gmail.com")))
