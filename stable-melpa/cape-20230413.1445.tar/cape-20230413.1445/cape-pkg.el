(define-package "cape" "20230413.1445" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "9a0da574607b3c943569f6843d926697ffc6586d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
