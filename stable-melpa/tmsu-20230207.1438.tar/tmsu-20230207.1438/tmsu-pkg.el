(define-package "tmsu" "20230207.1438" "A basic TMSU interface"
  '((emacs "28.1"))
  :commit "26fb81d2667c88bef4f571c87bd9842d1be21234" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("files")
  :url "https://github.com/vifon/tmsu.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
