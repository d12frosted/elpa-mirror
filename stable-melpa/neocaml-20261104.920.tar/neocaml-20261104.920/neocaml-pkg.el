;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20261104.920"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "210c66a67796888df22dfbe825d5b617dfc21428"
  :revdesc "210c66a67796"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
