;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250519.1503"
  "A family of utilities to interact with LLMs (ChatGPT, Claude, DeepSeek, Gemini, Kagi, Ollama, Perplexity)."
  '((emacs       "28.1")
    (shell-maker "0.76.3"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "65be81b78ee60f3dbc243ba69add4a4cc9c681cc"
  :revdesc "65be81b78ee6")
