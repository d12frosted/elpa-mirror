(define-package "org-node" "20240916.37" "Link org-id entries into a network"
  '((emacs "28.1")
    (compat "30")
    (dash "2.19.1")
    (transient "0.4.3")
    (persist "0.6.1"))
  :commit "03c7e26611b1097fade5a016a96e6ad8d7d34908" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node")
;; Local Variables:
;; no-byte-compile: t
;; End:
