;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250626.327"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "ecb93c3c6db72f49e647618d6d5122bfa29f0499"
  :revdesc "ecb93c3c6db7"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
