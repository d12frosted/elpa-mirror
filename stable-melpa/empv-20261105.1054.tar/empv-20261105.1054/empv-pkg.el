;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "empv" "20261105.1054"
  "A multimedia player/manager, YouTube interface."
  '((emacs  "28.1")
    (s      "1.13.0")
    (compat "29.1.4.4"))
  :url "https://github.com/isamert/empv.el"
  :commit "6c60b0af2e43b1128950f79002dea226cc1cdee3"
  :revdesc "6c60b0af2e43"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
