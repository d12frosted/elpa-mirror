(define-package "doom-modeline" "20220804.508" "A minimal and modern mode-line"
  '((emacs "25.1")
    (compat "28.1.1.1")
    (shrink-path "0.2.0"))
  :commit "4c4b451fcf705f58e6ca41339f22365434b664cb" :authors
  '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainer
  '("Vincent Zhang" . "seagle0128@gmail.com")
  :keywords
  '("faces" "mode-line")
  :url "https://github.com/seagle0128/doom-modeline")
;; Local Variables:
;; no-byte-compile: t
;; End:
