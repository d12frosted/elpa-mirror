;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260426.654"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "9fe3a1c3fa576022542eb46173be7d481438458d"
  :revdesc "9fe3a1c3fa57"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
