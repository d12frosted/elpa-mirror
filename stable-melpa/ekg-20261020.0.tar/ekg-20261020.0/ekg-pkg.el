;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261020.0"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "b6e73a1425988f70fedba7d31beee25e1e3296aa"
  :revdesc "b6e73a142598"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
