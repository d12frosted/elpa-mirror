(define-package "elfeed-score" "20210301.334" "Gnus-style scoring for Elfeed"
  '((emacs "26.1")
    (elfeed "3.3.0"))
  :commit "9fe6285666560c81907b984b74e1bd9a34bc79ba" :authors
  '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainer
  '("Michael Herstine" . "sp1ff@pobox.com")
  :keywords
  '("news")
  :url "https://github.com/sp1ff/elfeed-score")
;; Local Variables:
;; no-byte-compile: t
;; End:
