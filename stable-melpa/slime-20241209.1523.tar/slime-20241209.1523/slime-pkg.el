;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slime" "20241209.1523"
  "Superior Lisp Interaction Mode for Emacs."
  '((emacs     "24.3")
    (macrostep "0.9"))
  :url "https://github.com/slime/slime"
  :commit "1bad2ceff8e8bdc8638a3dc159bad81693387a21"
  :revdesc "1bad2ceff8e8"
  :keywords '("languages" "lisp" "slime"))
