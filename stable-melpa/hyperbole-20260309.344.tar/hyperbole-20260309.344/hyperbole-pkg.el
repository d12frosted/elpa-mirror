;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260309.344"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "f6f5bfcc1fc88b48c24f8321490fdfd30d4dc616"
  :revdesc "f6f5bfcc1fc8"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
