(define-package "git-assembler-mode" "20221205.1014" "git-assembler major mode"
  '((emacs "24.4"))
  :commit "e88d69d1fd93f166d8b31e02790a1d241fea44aa" :authors
  '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainers
  '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainer
  '("Yuri D'Elia" . "wavexx@thregr.org")
  :keywords
  '("git" "git-assembler" "languages" "highlight" "syntax")
  :url "https://gitlab.com/wavexx/git-assembler-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
