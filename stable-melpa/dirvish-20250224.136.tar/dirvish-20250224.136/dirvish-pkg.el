;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250224.136"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "ee55249c3ffae864bef7a45c4d5337f374d1a7b1"
  :revdesc "ee55249c3ffa"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
