(define-package "related-files" "20221101.1909" "Easily find files related to the current one"
  '((emacs "28.2"))
  :commit "4085ed9c235983e530da24cb1fbe33a5b7928ab3" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("tools")
  :url "https://www.gnu.org/software/emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
