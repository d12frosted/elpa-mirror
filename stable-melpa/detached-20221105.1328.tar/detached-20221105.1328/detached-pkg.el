(define-package "detached" "20221105.1328" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "8be0a4827cc112c861b2e55ceea83bf5c4e92a69" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
