;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "smartscan" "20260710.1518"
  "Jumps between other symbols found at point."
  ()
  :url "https://github.com/mickeynp/smart-scan"
  :commit "5e283b92b5c5826e194043b0314e0d6d88a94a62"
  :revdesc "5e283b92b5c5"
  :keywords '("extensions")
  :authors '(("Mickey Petersen" . "mickey@masteringemacs.org"))
  :maintainers '(("Mickey Petersen" . "mickey@masteringemacs.org")))
