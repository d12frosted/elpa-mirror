;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260713.1604"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "1eefec99a8340afedb485383a1544205cc62c685"
  :revdesc "1eefec99a834"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
