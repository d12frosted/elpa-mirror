;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mugur" "20261108.1639"
  "Configurator for QMK compatible keyboards."
  '((emacs    "26.1")
    (s        "1.12.0")
    (anaphora "1.0.4")
    (dash     "2.18.1")
    (cl-lib   "1.0"))
  :url "https://github.com/mihaiolteanu/mugur"
  :commit "2e16f1168b8b488a0816e4cdaf1fd1bc98ad5325"
  :revdesc "2e16f1168b8b"
  :keywords '("multimedia")
  :authors '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm"))
  :maintainers '(("Mihai Olteanu" . "mihai_olteanu@fastmail.fm")))
