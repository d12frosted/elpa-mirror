(define-package "popper" "20240324.2216" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "28f18827baefe5012c4480a89a2cf8c1fa381132" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
