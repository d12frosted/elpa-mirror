;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260624.304"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "4d46eafaa087f5570ece9d2e5f5d2ba6bc0d824e"
  :revdesc "4d46eafaa087"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
