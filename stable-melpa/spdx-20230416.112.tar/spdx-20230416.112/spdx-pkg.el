(define-package "spdx" "20230416.112" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "99fddb7b9d7b0a857eaa412306b11504bf3d64c9" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
