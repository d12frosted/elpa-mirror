;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "geeknote" "20220213.612"
  "Use Evernote in Emacs through geeknote."
  '((emacs "24"))
  :url "https://github.com/avendael/emacs-geeknote"
  :commit "ce2738aebeeda35f9d31027e9b7bad0813b975c3"
  :revdesc "ce2738aebeed"
  :keywords '("evernote" "geeknote" "note" "emacs-evernote" "evernote-mode"))
