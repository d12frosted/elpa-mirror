;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260620.1902"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "c07ed16da91c66162d3b3dcf06ed076440445a1a"
  :revdesc "c07ed16da91c"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
