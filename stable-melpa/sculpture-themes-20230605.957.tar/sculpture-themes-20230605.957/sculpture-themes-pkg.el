(define-package "sculpture-themes" "20230605.957" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "9ff7c01fa089e98015c4d2d5492391ec12a53c4a" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainers
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
