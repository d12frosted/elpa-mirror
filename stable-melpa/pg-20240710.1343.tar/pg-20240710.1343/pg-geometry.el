;;; pg-geometry.el --- Support for PostgreSQL geometric types -*- lexical-binding: t -*-
;;
;; Copyright: (C) 2024  Eric Marsden
;; Author: Eric Marsden <eric.marsden@risk-engineering.org>
;; SPDX-License-Identifier: GPL-2.0-or-later


;;; Commentary:

;; Geometric data types, per https://www.postgresql.org/docs/current/datatype-geometric.html


;;; Code:

(require 'cl-lib)
(require 'peg)

(declare-function pg-register-parser "pg" (type-name parser))
(declare-function pg-register-textual-serializer "pg" (type-name serializer))


(defun pg--point-parser (str _encoding)
  (with-temp-buffer
    (insert str)
    (goto-char (point-min))
    (with-peg-rules
     ((point (or with-parens without-parens))
      (with-parens (* [space]) (* "(") x-comma-y (* ")") (* [space]) (eol))
      (without-parens x-comma-y (* [space]) (eol))
      (x-comma-y (* [space]) float (* [space]) ","
                 (* [space]) float (* [space]) (* ")")
                 `(x y -- (cons x y)))
      (float (substring sign (+ [digit]) (* "." (+ [digit])) (* "e" sign (+ [digit])))
             `(str -- (string-to-number str)))
      (sign (or "+" "-" "")))
     (car (peg-run (peg point))))))

(defun pg--serialize-point (point)
  (cl-assert (consp point) t)
  (cl-assert (numberp (car point)) t)
  (cl-assert (numberp (cdr point)) t)
  (format "(%s,%s)" (car point) (cdr point)))

;; A line is represented in Emacs Lisp by a 3-element vector.
(defun pg--line-parser (str _encoding)
  (with-temp-buffer
    (insert str)
    (goto-char (point-min))
    (with-peg-rules
     ((line (* [space]) "{" float ","
            (* [space]) float ","
            (* [space]) float "}" (* [space]) (eol)
            `(a b c -- (vector a b c)))
      (float (substring sign (+ [digit]) (* "." (+ [digit])) (* "e" sign (+ [digit])))
             `(str -- (string-to-number str)))
      (sign (or "+" "-" "")))
     (car (peg-run (peg line))))))

(defun pg--serialize-line (line)
  (cl-assert (vectorp line))
  (cl-assert (numberp (aref line 0)))
  (cl-assert (numberp (aref line 1)))
  (cl-assert (numberp (aref line 2)))
  (format "{%f,%f,%f}" (aref line 0) (aref line 1) (aref line 2)))

;; An lseg is represented in Emacs Lisp by a two-element vector of points.
(defun pg--lseg-parser (str _encoding)
  (with-temp-buffer
    (insert str)
    (goto-char (point-min))
    (with-peg-rules
     ((lseg (* [space]) "[" point "," (* [space]) point (* [space]) "]" (* [space]) (eol)
            `(p1 p2 -- (vector p1 p2)))
      (point "(" x-comma-y ")")
      (x-comma-y (* [space]) float (* [space]) ","
                 (* [space]) float (* [space])
                 `(x y -- (cons x y)))
      (float (substring sign (+ [digit]) (* "." (+ [digit])) (* "e" sign (+ [digit])))
             `(str -- (string-to-number str)))
      (sign (or "+" "-" "")))
     (car (peg-run (peg lseg))))))

;; [(x1,y1),(x2,y2)]
(defun pg--serialize-lseg (lseg)
  (cl-assert (vectorp lseg))
  (cl-assert (eql 2 (length lseg)))
  (format "[(%f,%f),(%f,%f)]"
          (car (aref lseg 0))
          (cdr (aref lseg 0))
          (car (aref lseg 1))
          (cdr (aref lseg 1))))

;; ( x1 , y1 ) , ( x2 , y2 )
(defun pg--box-parser (str _encoding)
  (with-temp-buffer
    (insert str)
    (goto-char (point-min))
    (with-peg-rules
        ((box (* [space]) point "," (* [space]) point (* [space]) (eol)
               `(p1 p2 -- (vector p1 p2)))
         (point "(" x-comma-y ")")
         (x-comma-y (* [space]) float (* [space]) ","
                    (* [space]) float (* [space])
                    `(x y -- (cons x y)))
         (float (substring sign (+ [digit]) (* "." (+ [digit])) (* "e" sign (+ [digit])))
                `(str -- (string-to-number str)))
         (sign (or "+" "-" "")))
      (car (peg-run (peg box))))))

(defun pg--serialize-box (box)
  (format "(%f,%f),(%f,%f)"
          (car (aref box 0))
          (cdr (aref box 0))
          (car (aref box 1))
          (cdr (aref box 1))))


;; type is one of :open, :closed
(cl-defstruct pg-geometry-path type points)

(defun pg--path-parser (str _encoding)
  (with-temp-buffer
    (insert str)
    (goto-char (point-min))
    (with-peg-rules
     ((path (* [space]) (or open-path closed-path) (* [space]) (eol))
      (open-path "[" (* [space]) (list point-list) (* [space]) "]"
                 `(points -- (make-pg-geometry-path :type :open :points points)))
      (closed-path "(" (* [space]) (list point-list) (* [space]) ")"
                   `(points -- (make-pg-geometry-path :type :closed :points points)))
      (point-list point (* "," (* [space]) point-list))
      (point "(" x-comma-y ")")
      (x-comma-y (* [space]) float (* [space]) ","
                 (* [space]) float (* [space])
                 `(x y -- (cons x y)))
      (float (substring sign (+ [digit]) (* "." (+ [digit])) (* "e" sign (+ [digit])))
             `(str -- (string-to-number str)))
      (sign (or "+" "-" "")))
     (car (peg-run (peg path))))))

(defun pg--serialize-path (path)
  (cl-assert (pg-geometry-path-p path))
  (let ((type (pg-geometry-path-type path))
        (points (pg-geometry-path-points path)))
    (format "%s%s%s"
            (if (eq :open type) "[" "(")
            (string-join (mapcar #'pg--serialize-point points) ",")
            (if (eq :open type) "]" ")"))))

(cl-defstruct pg-geometry-polygon points)

;; ( ( x1 , y1 ) , ... , ( xn , yn ) )
(defun pg--polygon-parser (str _encoding)
  (with-temp-buffer
    (insert str)
    (goto-char (point-min))
    (with-peg-rules
     ((polygon (* [space]) "(" (* [space]) (list point-list) (* [space]) ")" (* [space]) (eol)
               `(points -- (make-pg-geometry-polygon :points points)))
      (point-list point (* "," (* [space]) point-list))
      (point "(" x-comma-y ")")
      (x-comma-y (* [space]) float (* [space]) ","
                 (* [space]) float (* [space])
                 `(x y -- (cons x y)))
      (float (substring sign (+ [digit]) (* "." (+ [digit])) (* "e" sign (+ [digit])))
             `(str -- (string-to-number str)))
      (sign (or "+" "-" "")))
     (car (peg-run (peg polygon))))))

(defun pg--serialize-polygon (polygon)
  (cl-assert (pg-geometry-polygon-p polygon))
  (let* ((points (pg-geometry-polygon-points polygon))
         (spoints (mapcar #'pg--serialize-point points)))
    (format "(%s)" (string-join spoints ","))))


(cl-eval-when (load)
  (pg-register-parser "point" #'pg--point-parser)
  (pg-register-textual-serializer "point" #'pg--serialize-point)
  (pg-register-parser "line" #'pg--line-parser)
  (pg-register-textual-serializer "line" #'pg--serialize-line)
  (pg-register-parser "lseg" #'pg--lseg-parser)
  (pg-register-textual-serializer "lseg" #'pg--serialize-lseg)
  (pg-register-parser "box" #'pg--box-parser)
  (pg-register-textual-serializer "box" #'pg--serialize-box)
  (pg-register-parser "path" #'pg--path-parser)
  (pg-register-textual-serializer "path" #'pg--serialize-path)
  (pg-register-parser "polygon" #'pg--polygon-parser)
  (pg-register-textual-serializer "polygon" #'pg--serialize-polygon))

(provide 'pg-geometry)

;;; pg-geometry.el ends here
