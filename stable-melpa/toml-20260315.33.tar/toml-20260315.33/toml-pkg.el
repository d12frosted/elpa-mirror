;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260315.33"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "dcf6fb48a383717119270e85187ea4a0a150faa2"
  :revdesc "dcf6fb48a383"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
