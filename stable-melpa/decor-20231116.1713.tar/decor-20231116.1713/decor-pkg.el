(define-package "decor" "20231116.1713" "Modify visual decorations"
  '((emacs "24.1"))
  :commit "add132447ade02afef1328bf50040f77cbd86087" :authors
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainer
  '("Peter Badida" . "keyweeusr@gmail.com")
  :keywords
  '("convenience" "window" "decoration" "distraction" "xprop" "xwayland")
  :url "https://github.com/KeyWeeUsr/decor")
;; Local Variables:
;; no-byte-compile: t
;; End:
