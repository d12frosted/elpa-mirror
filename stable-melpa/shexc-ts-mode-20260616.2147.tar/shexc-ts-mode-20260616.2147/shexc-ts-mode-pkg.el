;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shexc-ts-mode" "20260616.2147"
  "Tree-sitter major mode for ShExC."
  '((emacs "29.1"))
  :url "https://github.com/ericprud/shexc-mode-for-emacs"
  :commit "944e97c158b9daabac31ee39f602c54411cc1f42"
  :revdesc "944e97c158b9"
  :keywords '("languages")
  :authors '(("Eric Prud'hommeaux" . "eric@w3.org"))
  :maintainers '(("Eric Prud'hommeaux" . "eric@w3.org")))
