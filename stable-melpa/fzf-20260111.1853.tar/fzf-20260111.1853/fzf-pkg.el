;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf" "20260111.1853"
  "A front-end for fzf."
  '((emacs "24.4"))
  :url "https://github.com/bling/fzf.el"
  :commit "7bd12faa84f0ddcbc1e76ab416bb43e36fbf9c1f"
  :revdesc "7bd12faa84f0"
  :keywords '("fzf" "fuzzy" "search"))
