(define-package "ego" "20200803.1101" "a static site generator based on org mode, forked from org-page."
  '((emacs "24.5")
    (ht "1.5")
    (mustache "0.22")
    (htmlize "1.47")
    (org "8.0")
    (dash "2.0.0"))
  :commit "211c4cb2af2582849d9df984fb2346deecaf79be" :authors
  (("Feng Shu  <tumashu AT 163.com>")
   ("Kelvin Hu <ini DOT kelvin AT gmail DOT com>")
   ("Kuangdash <kuangdash AT 163.com>"))
  :maintainer
  ("Feng Shu  <tumashu AT 163.com>")
  :keywords
  ("org-mode" "convenience" "beautify")
  :url "https://github.com/emacs-china/EGO")
;; Local Variables:
;; no-byte-compile: t
;; End:
