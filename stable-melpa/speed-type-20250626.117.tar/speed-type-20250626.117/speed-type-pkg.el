;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20250626.117"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3")
    (dash   "2.19.1"))
  :url "https://github.com/dakra/speed-type"
  :commit "e676217a7f474628eae0736e2ff38de28888c455"
  :revdesc "e676217a7f47"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
