(define-package "helm-core" "20210914.749" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "b92b5415c75b4adf1994b4ef5cc81da71b089edc")
;; Local Variables:
;; no-byte-compile: t
;; End:
