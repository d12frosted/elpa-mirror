(define-package "slime" "20240928.1056" "Superior Lisp Interaction Mode for Emacs"
  '((emacs "24.3")
    (macrostep "0.9"))
  :commit "6818b5bd3c8d6df18375a0d30b0bc9c8fa69bdca" :keywords
  '("languages" "lisp" "slime")
  :url "https://github.com/slime/slime")
;; Local Variables:
;; no-byte-compile: t
;; End:
