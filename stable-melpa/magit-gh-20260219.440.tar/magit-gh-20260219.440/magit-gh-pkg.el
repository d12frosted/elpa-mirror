;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magit-gh" "20260219.440"
  "GitHub CLI integration for Magit."
  '((emacs     "29.1")
    (magit     "4.0.0")
    (transient "0.5.0"))
  :url "https://github.com/jonathanchu/magit-gh"
  :commit "9fb03c0265e9fffe0a3ceb31c65398e344389a02"
  :revdesc "9fb03c0265e9"
  :keywords '("git" "tools" "vc" "github")
  :authors '(("Jonathan Chu" . "me@jonathanchu.is"))
  :maintainers '(("Jonathan Chu" . "me@jonathanchu.is")))
