;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260224.457"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "7799a5a143550b33677ad21a3403fef759102482"
  :revdesc "7799a5a14355"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
