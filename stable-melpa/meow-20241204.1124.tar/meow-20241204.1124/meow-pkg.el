;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241204.1124"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "c82a324dd9379178f55ccb351882635761474726"
  :revdesc "c82a324dd937"
  :keywords '("convenience" "modal-editing"))
