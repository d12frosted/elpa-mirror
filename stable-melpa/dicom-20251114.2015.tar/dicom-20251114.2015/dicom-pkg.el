;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20251114.2015"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/dicom"
  :commit "a4483e6e0c54a1363c37415b878cdb17fc174673"
  :revdesc "a4483e6e0c54"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
