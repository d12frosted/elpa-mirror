(define-package "elisp-autofmt" "20230119.145" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "e35b6d90bf11c61aff7cce190b25b676ea21be56" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
