;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "parinfer-rust-mode" "20251231.1003"
  "An interface for the parinfer-rust library."
  '((emacs         "26.1")
    (track-changes "1.1"))
  :url "https://github.com/justinbarclay/parinfer-rust-mode"
  :commit "505c4f7a0a4df19486b91eb9d023b27c5d6240d4"
  :revdesc "505c4f7a0a4d"
  :keywords '("lisp" "tools")
  :authors '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainers '(("Justin Barclay" . "justinbarclay@gmail.com")))
