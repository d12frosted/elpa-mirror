;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otpp" "20260522.1558"
  "One tab per project, with unique names."
  '((emacs  "28.1")
    (compat "29.1"))
  :url "https://github.com/abougouffa/one-tab-per-project"
  :commit "95510a72fc167886b60135fbecf4bbed5fed5515"
  :revdesc "95510a72fc16"
  :keywords '("convenience")
  :authors '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")"))
  :maintainers '(("Abdelhak Bougouffa (rot13" . "\"nobhtbhssn@srqbencebwrpg.bet\")")))
