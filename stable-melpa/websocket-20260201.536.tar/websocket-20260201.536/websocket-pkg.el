;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "websocket" "20260201.536"
  "Emacs WebSocket client and server."
  '((cl-lib "0.5"))
  :url "https://github.com/ahyatt/emacs-websocket"
  :commit "3b463380e4add168238728fba69c215b24dabbad"
  :revdesc "3b463380e4ad"
  :keywords '("communication" "websocket" "server")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
