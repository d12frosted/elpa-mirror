(define-package "icomplete-vertical" "20210105.500" "Display icomplete candidates vertically"
  '((emacs "25.1"))
  :commit "cc5bb819839f8bfed4853cbcb1a3b0cd6ccc67d1" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
