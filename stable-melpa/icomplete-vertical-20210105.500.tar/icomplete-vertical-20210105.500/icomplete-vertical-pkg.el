(define-package "icomplete-vertical" "20210105.500" "Display icomplete candidates vertically"
  '((emacs "25.1"))
  :commit "288166784de29db2f5f61722cc11151deca3f34a" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
