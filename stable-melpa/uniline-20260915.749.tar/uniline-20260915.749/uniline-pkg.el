;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260915.749"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "bff9d27a497c6aafdaa791a9633f456dec741f52"
  :revdesc "bff9d27a497c"
  :keywords '("convenience" "text"))
