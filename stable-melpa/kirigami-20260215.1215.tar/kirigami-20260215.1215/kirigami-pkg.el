;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260215.1215"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "e4ddb608483cd17eb8bf3f5909072eca36d6e5b7"
  :revdesc "e4ddb608483c"
  :keywords '("convenience"))
