(define-package "cnfonts" "20211128.1555" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "6444fd86d227909c842c3614d9050d1429dcb29b" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
