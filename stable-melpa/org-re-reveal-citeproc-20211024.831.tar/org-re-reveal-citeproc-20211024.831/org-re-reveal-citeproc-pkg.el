(define-package "org-re-reveal-citeproc" "20211024.831" "Citations and bibliography for org-re-reveal"
  '((emacs "25.1")
    (org "9.5")
    (citeproc "0.9")
    (org-re-reveal "3.0.0"))
  :commit "f1f5a00fc8570234a8d421868b170aa9819c792a" :authors
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "bibliography")
  :url "https://gitlab.com/oer/org-re-reveal-citeproc")
;; Local Variables:
;; no-byte-compile: t
;; End:
