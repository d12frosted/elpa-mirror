(define-package "call-graph" "20220528.27" "Generate call graph for c/c++ functions"
  '((emacs "25.1")
    (hierarchy "0.7.0")
    (tree-mode "1.0.0")
    (ivy "0.10.0"))
  :commit "b37836ed04a1268301c0ef84496f165c671f55e4" :authors
  '(("Huming Chen" . "chenhuming@gmail.com"))
  :maintainer
  '("Huming Chen" . "chenhuming@gmail.com")
  :keywords
  '("programming" "convenience")
  :url "https://github.com/beacoder/call-graph")
;; Local Variables:
;; no-byte-compile: t
;; End:
