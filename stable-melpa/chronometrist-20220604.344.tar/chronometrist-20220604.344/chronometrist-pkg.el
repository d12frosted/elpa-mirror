(define-package "chronometrist" "20220604.344" "Friendly and powerful personal time tracker and analyzer"
  '((emacs "27.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "05514a014f2f4bf261a3d4ac0992a9cdfa2f515e" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
