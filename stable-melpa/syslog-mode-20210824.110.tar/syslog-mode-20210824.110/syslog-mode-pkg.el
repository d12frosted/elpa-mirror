(define-package "syslog-mode" "20210824.110" "Major-mode for viewing log files & strace output"
  '((hide-lines "20130623")
    (ov "20150311"))
  :commit "5b2082f93a30d9b48b0ff6cb9d9761e31a7e36c3" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
