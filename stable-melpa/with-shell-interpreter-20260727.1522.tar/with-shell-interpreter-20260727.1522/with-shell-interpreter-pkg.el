;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "with-shell-interpreter" "20260727.1522"
  "Helper for shell command APIs."
  '((emacs  "25.1")
    (cl-lib "0.6.1"))
  :url "https://github.com/p3r7/with-shell-interpreter"
  :commit "8191d0b745dda30c7f6d225eb86598d8337c6b82"
  :revdesc "8191d0b745dd"
  :keywords '("processes" "terminals"))
