(define-package "asm-blox" "20220731.1602" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "87009cbdc790f835a4d049aec4977d020e4746d3" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
