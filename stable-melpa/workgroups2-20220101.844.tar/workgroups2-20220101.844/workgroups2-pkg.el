(define-package "workgroups2" "20220101.844" "New workspaces for Emacs"
  '((emacs "25.1"))
  :commit "f2493b9c312106d50829159be2329a879a80e026" :authors
  '(("Sergey Pashinin <sergey at pashinin dot com>"))
  :maintainer
  '("Sergey Pashinin <sergey at pashinin dot com>")
  :keywords
  '("session" "management" "window-configuration" "persistence")
  :url "https://github.com/pashinin/workgroups2")
;; Local Variables:
;; no-byte-compile: t
;; End:
