(define-package "org-tag-beautify" "20231031.553" "Beautify Org mode tags"
  '((emacs "26.1")
    (nerd-icons "0.0.1"))
  :commit "433cce19914cbefa979e413ca895e375b0aef32a" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-tag-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
