;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "electric-ospl" "20260108.1622"
  "Electric OSPL Mode."
  '((emacs "26.1"))
  :url "https://git.sr.ht/~swflint/electric-ospl-mode"
  :commit "8599de5864e20831f2a3719f83da6690e0575c56"
  :revdesc "8599de5864e2"
  :keywords '("convenience" "text")
  :authors '(("Samuel W. Flint" . "swflint@flintfam.org"))
  :maintainers '(("Samuel W. Flint" . "swflint@flintfam.org")))
