;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260709.126"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "1a6fe1ba0925ea7872050127cd3ff57c998ab569"
  :revdesc "1a6fe1ba0925"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
