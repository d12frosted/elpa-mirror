;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "raycast-mode" "20230607.2107"
  "Develop Raycast Extensions."
  '((emacs "26.1"))
  :url "https://github.com/nhojb/raycast-mode"
  :commit "f6401605cc9dfacdcaaf98d5844348b818cfc010"
  :revdesc "f6401605cc9d"
  :keywords '("convenience" "languages" "tools")
  :authors '(("John Buckley" . "nhoj.buckley@gmail.com"))
  :maintainers '(("John Buckley" . "nhoj.buckley@gmail.com")))
