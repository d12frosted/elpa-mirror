(define-package "binky" "20231017.1600" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "7cb000b91ba3dd63194ad61f16d4652f58ad8644" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
