;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-bbdb" "20260721.2037"
  "Helm interface for bbdb."
  '((emacs "26.1")
    (helm  "1.5")
    (bbdb  "3.1.2"))
  :url "https://github.com/emacs-helm/helm-bbdb"
  :commit "2382e11c2fa119b9c3e66adb692a3ffe29d0027d"
  :revdesc "2382e11c2fa1"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Jonathan Gregory" . "jgrg@autistici.org")))
