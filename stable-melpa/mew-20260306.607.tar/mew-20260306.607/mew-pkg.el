;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260306.607"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "535defc7582b2d80d41828ed1bde306337665ffb"
  :revdesc "535defc7582b")
