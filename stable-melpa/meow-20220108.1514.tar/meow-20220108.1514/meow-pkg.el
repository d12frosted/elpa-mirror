(define-package "meow" "20220108.1514" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "b4eefbfb1e0d8a766757f2f4f0ceaaf533bc617c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
