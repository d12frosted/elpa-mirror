;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250524.251"
  "Mordern HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "5d69a15d4bfbe219ca698673f7a4913a354885eb"
  :revdesc "5d69a15d4bfb"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
