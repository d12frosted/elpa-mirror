;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20250306.1140"
  "A multi-LLM shell (ChatGPT, Claude, Gemini, Kagi, Ollama, Perplexity) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.76.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "7144f5efcc7b473894c4f32b5bb8a0612a435b10"
  :revdesc "7144f5efcc7b")
