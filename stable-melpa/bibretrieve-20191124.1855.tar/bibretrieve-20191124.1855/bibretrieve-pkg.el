;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bibretrieve" "20191124.1855"
  "Retrieve BibTeX entries from the internet."
  '((auctex "11.87")
    (emacs  "24.3"))
  :url "https://github.com/pzorin/bibretrieve"
  :commit "81dc8e0db3629cc180eafb2bc34b60dcd8980316"
  :revdesc "81dc8e0db362"
  :keywords '("bibtex" "bibliography" "mathscinet" "arxiv" "zbmath")
  :maintainers '(("Pavel Zorin-Kranich" . "pzorin@uni-bonn.de")))
