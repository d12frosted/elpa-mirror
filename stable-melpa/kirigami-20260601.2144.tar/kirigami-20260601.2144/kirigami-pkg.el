;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260601.2144"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "211ffb8ae799fa39884f537642fd2e6dee1f2dbb"
  :revdesc "211ffb8ae799"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
