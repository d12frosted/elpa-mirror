(define-package "helm-core" "20231107.455" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "a6305b0554ad717df58baa494c8e1ea7ff4d1316" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
