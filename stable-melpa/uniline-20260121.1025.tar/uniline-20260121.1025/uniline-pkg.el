;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260121.1025"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "fc1baea921198301937a3f1ecfbc28dabfa6d551"
  :revdesc "fc1baea92119"
  :keywords '("convenience" "text"))
