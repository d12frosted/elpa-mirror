(define-package "lice" "20220215.303" "License And Header Template" 'nil :commit "b15230dbfc66cc92bbde8f9fd369522d7666c0c7" :authors
  '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainer
  '("Taiki Sugawara" . "buzz.taiki@gmail.com")
  :keywords
  '("template" "license" "tools")
  :url "https://github.com/buzztaiki/lice-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
