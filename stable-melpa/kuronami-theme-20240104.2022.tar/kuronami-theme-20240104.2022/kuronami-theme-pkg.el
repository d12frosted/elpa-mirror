;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kuronami-theme" "20240104.2022"
  "A deep blue theme with cool autumnal colors."
  '((emacs "24.1"))
  :url "https://github.com/inj0h/kuronami"
  :commit "4d0a9e5f789e5768a0c2ea7dec31f98ea95c7372"
  :revdesc "4d0a9e5f789e"
  :authors '(("inj0h" . ""))
  :maintainers '(("inj0h" . "")))
