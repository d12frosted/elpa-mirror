;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260327.1333"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "a04006a9e499e60e1ac221f02b0735dc69818205"
  :revdesc "a04006a9e499"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
