(define-package "fedi" "20230813.1959" "Helper functions for fediverse clients"
  '((emacs "28.1"))
  :commit "a02136c01751405ba19b9b928fecc932907ca547" :authors
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/fedi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
