;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260312.1015"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "8e6849888d2a35979dbd4295bf7478ae8057a6a1"
  :revdesc "8e6849888d2a"
  :keywords '("data" "extensions"))
