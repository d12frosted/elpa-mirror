(define-package "company" "20200725.2348" "Modular text completion framework"
  '((emacs "24.3"))
  :commit "656ad10670512e135a0a5881f127bb7a789ef8ca" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
