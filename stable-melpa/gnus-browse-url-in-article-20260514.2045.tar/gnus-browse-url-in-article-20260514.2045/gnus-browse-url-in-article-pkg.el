;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnus-browse-url-in-article" "20260514.2045"
  "Smarter browse-url for Gnus articles."
  '((emacs "27.1"))
  :url "https://github.com/jmibanez/gnus-browse-url-in-article"
  :commit "45d1cbc7bcb55d25d215d4ae39bf6dedf357853a"
  :revdesc "45d1cbc7bcb5"
  :keywords '("convenience" "mail" "gnus")
  :authors '(("JM Ibañez" . "jm@jmibanez.com"))
  :maintainers '(("JM Ibañez" . "jm@jmibanez.com")))
