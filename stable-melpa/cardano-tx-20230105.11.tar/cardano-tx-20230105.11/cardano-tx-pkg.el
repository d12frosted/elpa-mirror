(define-package "cardano-tx" "20230105.11" "Cardano transaction editor"
  '((emacs "27.1")
    (f "0.20.0")
    (yasnippet "0.14.0")
    (yaml-mode "0.0.15")
    (yaml "0.1.0")
    (helm "3.6.2")
    (cbor "0.2.3")
    (bech32 "0.2.1")
    (readable-numbers "0.1.0")
    (emacsql "3.0.0")
    (emacsql-sqlite "3.1.1"))
  :commit "6ce650972d949228b17dc03c6ff809f67f22f35a" :authors
  '(("Oscar Najera <https://oscarnajera.com>"))
  :maintainer
  '("Oscar Najera" . "hi@oscarnajera.com")
  :url "https://github.com/Titan-C/cardano.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
