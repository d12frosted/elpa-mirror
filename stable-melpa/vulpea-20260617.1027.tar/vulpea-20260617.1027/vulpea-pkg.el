;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260617.1027"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "5177bdd4b15e0f9bbe4e3721d40bd73117a255f8"
  :revdesc "5177bdd4b15e"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
