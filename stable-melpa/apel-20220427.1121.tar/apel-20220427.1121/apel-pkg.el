(define-package "apel" "20220427.1121" "A Portable Emacs Library provides support for portable Emacs Lisp programs"
  '((emacs "24.5"))
  :commit "6947dc4605ebbb87762edf7051a78a3f7b5f17c5")
;; Local Variables:
;; no-byte-compile: t
;; End:
