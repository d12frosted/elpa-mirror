;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20250422.43"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "0ace9c59c11e1631e3a8bd41b42e18b1eedff5ae"
  :revdesc "0ace9c59c11e"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
