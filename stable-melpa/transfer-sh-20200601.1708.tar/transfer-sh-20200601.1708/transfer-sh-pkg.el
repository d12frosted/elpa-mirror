;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transfer-sh" "20200601.1708"
  "Simple interface for sending buffer contents to transfer.sh."
  '((emacs "24.3")
    (async "1.0"))
  :url "https://gitlab.com/tuedachu/transfer-sh.el"
  :commit "0621a66d00ec91a209a542c10b158095088bd44d"
  :revdesc "0621a66d00ec"
  :keywords '("comm" "convenience" "files")
  :authors '(("S. Roskamp" . "steffen.roskamp@gmail.com")
             ("A. Hoffmann" . "tuedachu@gmail.com"))
  :maintainers '(("S. Roskamp" . "steffen.roskamp@gmail.com")
                 ("A. Hoffmann" . "tuedachu@gmail.com")))
