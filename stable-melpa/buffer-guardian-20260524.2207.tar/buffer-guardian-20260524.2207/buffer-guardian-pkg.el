;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20260524.2207"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "1edaa2fa99b5bd70dc883c9cbf6049f5683d1f7a"
  :revdesc "1edaa2fa99b5"
  :keywords '("maint")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
