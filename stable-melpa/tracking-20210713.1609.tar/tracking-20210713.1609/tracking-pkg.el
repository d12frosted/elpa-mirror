(define-package "tracking" "20210713.1609" "Buffer modification tracking" 'nil :commit "41cdc116b09818d33f5cb0fc1d72c025c23aa2f1" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/emacs-circe/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
