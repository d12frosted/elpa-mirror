(define-package "tracking" "20210713.1609" "Buffer modification tracking" 'nil :commit "07d6d82cba864b1e38d3bd46654f2e1928a997c2" :authors
  '(("Jorgen Schaefer" . "forcer@forcix.cx"))
  :maintainer
  '("Jorgen Schaefer" . "forcer@forcix.cx")
  :url "https://github.com/emacs-circe/circe/wiki/Tracking")
;; Local Variables:
;; no-byte-compile: t
;; End:
