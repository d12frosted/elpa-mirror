(define-package "consult" "20210111.1535" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "bc70effa14c71699cef9db82284b201999f99ce7" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
