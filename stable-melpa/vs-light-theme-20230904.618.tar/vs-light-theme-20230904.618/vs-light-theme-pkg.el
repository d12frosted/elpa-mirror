(define-package "vs-light-theme" "20230904.618" "Visual Studio IDE light theme"
  '((emacs "24.1"))
  :commit "9271b350651c7404a1b71559df9feb4647879613" :authors
  '(("Jen-Chieh Shen"))
  :maintainers
  '(("Jen-Chieh Shen"))
  :maintainer
  '("Jen-Chieh Shen")
  :url "https://github.com/emacs-vs/vs-light-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
