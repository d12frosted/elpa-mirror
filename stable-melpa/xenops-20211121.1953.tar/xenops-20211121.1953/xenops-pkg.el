(define-package "xenops" "20211121.1953" "A LaTeX editing environment for mathematical documents"
  '((emacs "26.1")
    (aio "1.0")
    (auctex "12.2.0")
    (avy "0.5.0")
    (dash "2.18.0")
    (f "0.20.0")
    (s "1.12.0"))
  :commit "c5fafbc41ae5c4d20a1eb2de3b3226f8a55eb65e" :authors
  '(("Dan Davison" . "dandavison7@gmail.com"))
  :maintainer
  '("Dan Davison" . "dandavison7@gmail.com")
  :url "https://github.com/dandavison/xenops")
;; Local Variables:
;; no-byte-compile: t
;; End:
