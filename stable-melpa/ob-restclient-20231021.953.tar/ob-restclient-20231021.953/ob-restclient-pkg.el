(define-package "ob-restclient" "20231021.953" "org-babel functions for restclient-mode"
  '((restclient "0"))
  :commit "aaa2ddd2b20f5abda16efb3e5eaf98d358d76a02" :authors
  '(("Alf Lervåg"))
  :maintainers
  '(("Alf Lervåg"))
  :maintainer
  '("Alf Lervåg")
  :keywords
  '("literate programming" "reproducible research")
  :url "https://github.com/alf/ob-restclient.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
