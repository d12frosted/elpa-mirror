(define-package "racket-mode" "20211023.1542" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "f1e0d1259616f7ded4a16b4d63e7710ea79ad321" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
