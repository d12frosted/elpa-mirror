(define-package "elisp-autofmt" "20230101.1936" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "d2bf6268c1957f1cdd6cd6efa6e39bb98ea80e32" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
