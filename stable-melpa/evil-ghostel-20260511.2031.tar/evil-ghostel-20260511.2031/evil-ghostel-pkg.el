;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20260511.2031"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.8.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "148e699d889d02aefb5b2ab13e70a7204cbe79cf"
  :revdesc "148e699d889d"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
