;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sleek-modeline" "20261123.1729"
  "Minimal and elegant modeline."
  '((emacs "30.1"))
  :url "https://github.com/abidanBrito/sleek-modeline"
  :commit "e8e3c868d8d42b1af0e9324b387b11792abaa2bc"
  :revdesc "e8e3c868d8d4"
  :keywords '("mode-line" "faces")
  :authors '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com"))
  :maintainers '(("Abidán Brito Clavijo" . "abidan.brito@gmail.com")))
