(define-package "ekg" "20230620.1807" "A system for recording and linking information"
  '((triples "0.3.2")
    (emacs "28.1"))
  :commit "9fa918ae4b3a7a8541e570fc358174346d875e85" :authors
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers
  '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainer
  '("Andrew Hyatt" . "ahyatt@gmail.com")
  :keywords
  '("outlines" "hypermedia")
  :url "https://github.com/ahyatt/ekg")
;; Local Variables:
;; no-byte-compile: t
;; End:
