(define-package "lab" "20230617.1339" "An interface for GitLab"
  '((emacs "27.1")
    (memoize "1.1")
    (request "0.3.2")
    (s "1.10.0"))
  :commit "e4973c99af5837260122de0b8e234a4d87af2356" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/lab.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
