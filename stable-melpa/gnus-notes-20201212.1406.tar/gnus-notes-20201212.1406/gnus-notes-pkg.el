(define-package "gnus-notes" "20201212.1406" "Keep handy notes of read Gnus articles with helm and org"
  '((emacs "27.1")
    (bbdb "3.1")
    (helm "3.1")
    (hydra "0.13.0")
    (org "8.3")
    (s "0.0")
    (lv "0.0")
    (async "1.9.1"))
  :commit "c404a9f79e34ff7bffa1a7f67d2f4fb7a0c0d588" :keywords
  ("convenience" "mail" "bbdb" "gnus" "helm" "org" "hydra")
  :authors
  (("Deus Max" . "deusmax@gmx.com"))
  :maintainer
  ("Deus Max" . "deusmax@gmx.com")
  :url "https://github.com/deusmax/gnus-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
