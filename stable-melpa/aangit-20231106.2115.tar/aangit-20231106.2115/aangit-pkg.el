;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aangit" "20231106.2115"
  "Quickly scaffold new Angular apps with Aangit."
  '((emacs     "29.1")
    (transient "0.4")
    (s         "1.13"))
  :url "https://github.com/stephenwithav/aangit"
  :commit "7527a366c542cb7b09672597876e83f429ca6b46"
  :revdesc "7527a366c542"
  :keywords '("angular" "tools")
  :authors '(("Steven Edwards" . "steven@stephenwithav.io"))
  :maintainers '(("Steven Edwards" . "steven@stephenwithav.io")))
