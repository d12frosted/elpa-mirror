;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "taskpaper-mode" "20260414.1851"
  "Major mode for TaskPaper files."
  '((emacs "25.1"))
  :url "https://github.com/saf-dmitry/taskpaper-mode"
  :commit "809c15fe893bb4ffa17bf515908a37c97e74afb9"
  :revdesc "809c15fe893b"
  :keywords '("outlines" "notetaking" "task management" "productivity" "taskpaper")
  :authors '(("Dmitry Safronov" . "saf.dmitry@gmail.com"))
  :maintainers '(("Dmitry Safronov" . "saf.dmitry@gmail.com")))
