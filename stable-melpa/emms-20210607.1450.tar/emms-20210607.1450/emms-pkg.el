(define-package "emms" "20210607.1450" "The Emacs Multimedia System"
  '((cl-lib "0.5")
    (nadvice "0.3")
    (seq "0"))
  :commit "c360a8934c1e07ddab4e12d28800d362d254ccbd" :authors
  '(("Jorgen Schäfer" . "forcer@forcix.cx"))
  :maintainer
  '("Yoni Rabkin" . "yrk@gnu.org")
  :keywords
  '("emms" "mp3" "ogg" "flac" "music" "mpeg" "video" "multimedia")
  :url "https://www.gnu.org/software/emms/")
;; Local Variables:
;; no-byte-compile: t
;; End:
