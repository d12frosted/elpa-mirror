(define-package "pdf-tools" "20220103.308" "Support library for PDF documents"
  '((emacs "24.3")
    (nadvice "0.3")
    (tablist "1.0")
    (let-alist "1.0.4"))
  :commit "d570624871016fae7e01d84645ca91f679ed6fb3" :authors
  '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainer
  '("Vedang Manerikar" . "vedang.manerikar@gmail.com")
  :keywords
  '("files" "multimedia")
  :url "http://github.com/vedang/pdf-tools/")
;; Local Variables:
;; no-byte-compile: t
;; End:
