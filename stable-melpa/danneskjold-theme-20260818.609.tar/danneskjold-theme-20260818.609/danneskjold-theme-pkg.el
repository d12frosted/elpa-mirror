;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "danneskjold-theme" "20260818.609"
  "Beautiful high-contrast Emacs theme."
  ()
  :url "https://github.com/rails-to-cosmos/danneskjold-theme"
  :commit "6c2fe929bfd0757163e1b7c5c7cbcd4dd18a256b"
  :revdesc "6c2fe929bfd0"
  :authors '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com"))
  :maintainers '(("Dmitry Akatov" . "dmitry.akatov@protonmail.com")))
