;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250528.1211"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.12.3")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "c15051ac252063299ce7de57e93137a28a4e5887"
  :revdesc "c15051ac2520"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
