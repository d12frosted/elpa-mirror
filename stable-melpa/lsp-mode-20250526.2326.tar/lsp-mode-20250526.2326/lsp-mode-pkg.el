;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20250526.2326"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "199eaa9b4e5fe0f5cf27be540fbe4af574b2aee4"
  :revdesc "199eaa9b4e5f"
  :keywords '("languages"))
