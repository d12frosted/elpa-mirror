;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinot" "20140211.2026"
  "Emacs interface to pinot-search."
  ()
  :url "https://github.com/tkf/emacs-pinot-search"
  :commit "67fda555a155b22bb2ce44ba618b4bd6fc5f144a"
  :revdesc "67fda555a155"
  :authors '(("Takafumi Arakaki" . "aka.tkfatgmail.com"))
  :maintainers '(("Takafumi Arakaki" . "aka.tkfatgmail.com")))
