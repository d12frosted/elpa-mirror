(define-package "pinot" "20140211.2026" "Emacs interface to pinot-search" 'nil :commit "67fda555a155b22bb2ce44ba618b4bd6fc5f144a" :authors
  (("Takafumi Arakaki <aka.tkf at gmail.com>"))
  :maintainer
  ("Takafumi Arakaki <aka.tkf at gmail.com>"))
;; Local Variables:
;; no-byte-compile: t
;; End:
