(define-package "whois" "20231215.2317" "Syntax highlighted domain name queries using system whois"
  '((emacs "24"))
  :commit "10e0b8cf2db52e32c3a23465756379d455722712" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("network" "comm")
  :url "https://github.com/lassik/emacs-whois")
;; Local Variables:
;; no-byte-compile: t
;; End:
