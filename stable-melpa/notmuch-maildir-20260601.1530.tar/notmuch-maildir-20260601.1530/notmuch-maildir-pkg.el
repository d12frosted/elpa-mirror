;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "notmuch-maildir" "20260601.1530"
  "Display maildirs as a tree."
  '((emacs   "29.1")
    (compat  "31.0")
    (notmuch "0.39"))
  :url "https://github.com/tarsius/notmuch-maildir"
  :commit "1ed7738468da9910a9bd32f3c44201ab1e9db242"
  :revdesc "1ed7738468da"
  :keywords '("mail")
  :authors '(("Jonas Bernoulli" . "emacs.notmuch-maildir@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.notmuch-maildir@jonas.bernoulli.dev")))
