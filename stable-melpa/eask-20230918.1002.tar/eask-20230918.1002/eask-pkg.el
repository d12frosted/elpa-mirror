(define-package "eask" "20230918.1002" "Core Eask APIs, for Eask CLI development"
  '((emacs "26.1")
    (dash "2.14.1"))
  :commit "10fb16bc07a745933161fba8547ff25348330b02" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("lisp" "eask" "api")
  :url "https://github.com/emacs-eask/eask")
;; Local Variables:
;; no-byte-compile: t
;; End:
