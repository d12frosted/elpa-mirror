;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260925.1502"
  "Curate an Emacs Lisp package archive."
  '((emacs  "29.1")
    (compat "31.1"))
  :url "https://github.com/melpa/package-build"
  :commit "44b058f0d4d91baed23322feef224096c3b975b0"
  :revdesc "44b058f0d4d9"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "jonas@bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoulli.dev")))
