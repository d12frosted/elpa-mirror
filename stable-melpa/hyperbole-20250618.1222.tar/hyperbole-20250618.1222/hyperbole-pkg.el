;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250618.1222"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "fec6d8b33c0c5f1641c619ac7bb228d1d46ffff5"
  :revdesc "fec6d8b33c0c"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
