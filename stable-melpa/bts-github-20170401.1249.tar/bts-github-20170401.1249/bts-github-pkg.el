;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bts-github" "20170401.1249"
  "A plugin of bts.el for GitHub."
  '((bts "0.0.1")
    (gh  "0.8.2"))
  :url "https://github.com/aki2o/emacs-bts-github"
  :commit "ef2cf9202dc2128e5efdb613bfde9276a8cd95ad"
  :revdesc "ef2cf9202dc2"
  :keywords '("convenience" "git" "github")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
