;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260630.1535"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "7857e88d5e91dbba2b4d3dc481325a409b513f2f"
  :revdesc "7857e88d5e91"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
