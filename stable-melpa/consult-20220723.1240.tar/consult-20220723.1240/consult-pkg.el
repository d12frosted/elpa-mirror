(define-package "consult" "20220723.1240" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "7c5a98a6abe5a42a9005d8c83a7ebef849e33e63" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
