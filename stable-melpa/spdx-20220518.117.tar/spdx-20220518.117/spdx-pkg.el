(define-package "spdx" "20220518.117" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "d45eb907c004212cac68aee3cf7287a85589ffd5" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
