(define-package "consult" "20210414.1119" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "48502b71e596b6532102cf2efcfc290122272aa1" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
