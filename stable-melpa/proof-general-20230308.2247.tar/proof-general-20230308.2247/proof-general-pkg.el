(define-package "proof-general" "20230308.2247" "A generic Emacs interface for proof assistants"
  '((emacs "25.2"))
  :commit "bf43cfb39a6deaea56a96d8e889e91319ec4dbc1" :maintainer
  '(nil . "proof-general-maintainers@groupes.renater.fr")
  :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
