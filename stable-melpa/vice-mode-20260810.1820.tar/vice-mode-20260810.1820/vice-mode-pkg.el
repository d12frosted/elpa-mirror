;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vice-mode" "20260810.1820"
  "VIm-like Commands Extension."
  '((emacs "29.1"))
  :url "https://github.com/gpapadok/vice"
  :commit "1de53ed04d7c2f084e6177e53e18d72e9716cb68"
  :revdesc "1de53ed04d7c"
  :keywords '("convenience" "emulations")
  :authors '(("Giorgos Papadokostakis" . "giorgos.papadokostakis@proton.me"))
  :maintainers '(("Giorgos Papadokostakis" . "giorgos.papadokostakis@proton.me")))
