(define-package "consult" "20231123.1803" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "9b2d0fbf837ec4e520df90794ce1ee7032634ce3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
