(define-package "markdown-toc" "20210629.931" "A simple TOC generator for markdown file"
  '((s "1.9.0")
    (dash "2.11.0")
    (markdown-mode "2.1"))
  :commit "8692f2df396aaf8a05215851f2fdd64f35576187" :authors
  '((nil . "Antoine R. Dumont (@ardumont)"))
  :maintainer
  '(nil . "Antoine R. Dumont (@ardumont)")
  :keywords
  '("markdown" "toc" "tools")
  :url "http://github.com/ardumont/markdown-toc")
;; Local Variables:
;; no-byte-compile: t
;; End:
