;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20251108.1423"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "9b1997c30dc3dcbbb0dee48b85cae0911f188a4a"
  :revdesc "9b1997c30dc3"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
