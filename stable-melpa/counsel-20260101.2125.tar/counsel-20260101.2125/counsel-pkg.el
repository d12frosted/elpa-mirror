;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel" "20260101.2125"
  "Various completion functions using Ivy."
  '((emacs  "24.5")
    (ivy    "0.15.1")
    (swiper "0.15.1"))
  :url "https://github.com/abo-abo/swiper"
  :commit "d489b4f0d48fd215119261d92de103c5b5580895"
  :revdesc "d489b4f0d48f"
  :keywords '("convenience" "matching" "tools")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Basil L. Contovounesios" . "basil@contovou.net")))
