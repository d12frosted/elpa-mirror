(define-package "darkman" "20230327.113" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "3960a534781368c82737ee5d2c4c9e0cef22bf8f" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainers
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://grtcdr.tn/darkman.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
