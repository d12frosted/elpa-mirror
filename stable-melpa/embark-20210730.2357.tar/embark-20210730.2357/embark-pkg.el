(define-package "embark" "20210730.2357" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "4d70178294ba17e42b718552713fc93227e254cb" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
