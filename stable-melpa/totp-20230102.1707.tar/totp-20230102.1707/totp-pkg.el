(define-package "totp" "20230102.1707" "Time-based One-time Password (TOTP)"
  '((emacs "27.1"))
  :commit "a5e059b8475b32bc7f5ddadda248cf84449ed722" :authors
  '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainers
  '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainer
  '("Jürgen Hötzel" . "juergen@hoetzel.info")
  :keywords
  '("tools" "pass" "password")
  :url "https://github.com/juergenhoetzel/emacs-totp")
;; Local Variables:
;; no-byte-compile: t
;; End:
