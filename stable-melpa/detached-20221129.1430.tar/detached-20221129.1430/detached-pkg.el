;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "detached" "20221129.1430"
  "A package to launch, and manage, detached processes."
  '((emacs "27.1"))
  :url "https://sr.ht/~niklaseklund/detached.el/"
  :commit "6b64d4d8064cee781e071e825857b442ea96c3d9"
  :revdesc "6b64d4d8064c"
  :keywords '("convenience" "processes")
  :authors '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainers '(("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")))
