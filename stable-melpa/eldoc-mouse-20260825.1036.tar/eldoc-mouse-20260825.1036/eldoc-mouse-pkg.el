;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20260825.1036"
  "Display documentation for mouse hover."
  '((emacs    "27.1")
    (posframe "1.5.1")
    (eglot    "1.23"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "0bcefa8d1bc33f251ea10b138fc4e5dbfedb92ed"
  :revdesc "0bcefa8d1bc3"
  :keywords '("tools" "languages" "convenience" "mouse" "hover")
  :authors '(("Huang Feiyu" . "sibadake1@163.com"))
  :maintainers '(("Huang Feiyu" . "sibadake1@163.com")))
