(define-package "futhark-mode" "20221217.2342" "major mode for editing Futhark source files"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "b9b2fa9c99b17bd6e662f1379fdb6ef2b4e0042d" :keywords
  '("languages")
  :url "https://github.com/diku-dk/futhark-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
