;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shift-text" "20130831.1655"
  "Move the region in 4 directions, in a way similar to Eclipse's."
  '((cl-lib "1.0")
    (es-lib "0.3"))
  :url "https://github.com/sabof/shift-text"
  :commit "1be9cbf994000022172ceb746fe1d597f57ea8ba"
  :revdesc "1be9cbf99400")
