;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycast" "20260517.1634"
  "Show current command and its binding."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/keycast"
  :commit "f1a2c1466369c0a412220b299da5deeb816254c4"
  :revdesc "f1a2c1466369"
  :keywords '("multimedia")
  :authors '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.keycast@jonas.bernoulli.dev")))
