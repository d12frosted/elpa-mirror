(define-package "cape" "20231208.721" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "a878347ebd20e4e410133f3547f16a925b7c6d16" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
