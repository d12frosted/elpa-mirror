(define-package "forge" "20211203.132" "Access Git forges from Magit."
  '((emacs "25.1")
    (closql "1.2.0")
    (dash "2.19.1")
    (emacsql-sqlite "3.0.0")
    (ghub "3.5.4")
    (let-alist "1.0.6")
    (magit "3.3.0")
    (markdown-mode "2.4")
    (transient "0.3.6")
    (yaml "0.3.4"))
  :commit "c5bbddfa98a0e2b990e1c94e1cb88724186b8e40" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
