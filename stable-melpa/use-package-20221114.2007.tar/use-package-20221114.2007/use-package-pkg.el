(define-package "use-package" "20221114.2007" "A configuration macro for simplifying your .emacs"
  '((emacs "24.3")
    (bind-key "2.4"))
  :commit "87c03dffc79e7980468231a797c412d88aed9bc7" :authors
  '(("John Wiegley" . "johnw@newartisans.com"))
  :maintainer
  '("John Wiegley" . "johnw@newartisans.com")
  :keywords
  '("dotemacs" "startup" "speed" "config" "package")
  :url "https://github.com/jwiegley/use-package")
;; Local Variables:
;; no-byte-compile: t
;; End:
