(define-package "lister" "20220117.2053" "Yet another list printer"
  '((emacs "26.1"))
  :commit "c88fe7afc644e3a9459cc95bf34c3a899f9483e5" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
