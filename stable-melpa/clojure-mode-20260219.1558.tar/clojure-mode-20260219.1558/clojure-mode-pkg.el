;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20260219.1558"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "8409c78c3912ea4a2fbe50f6a7d1b139205c5d34"
  :revdesc "8409c78c3912"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
