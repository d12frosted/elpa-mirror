;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-template-helper-mode" "20260102.1449"
  "Overlay Go template highlighting."
  '((emacs "28.1"))
  :url "https://codeberg.org/rch/go-template-helper-mode"
  :commit "34ba1fa917da78f9926fa909056bd9e1e5dd2837"
  :revdesc "34ba1fa917da"
  :keywords '("tools" "faces")
  :authors '(("Robert Charusta" . "rch-public@posteo.net"))
  :maintainers '(("Robert Charusta" . "rch-public@posteo.net")))
