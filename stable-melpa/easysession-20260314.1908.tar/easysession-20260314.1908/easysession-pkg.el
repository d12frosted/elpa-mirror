;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260314.1908"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "f93be7a5f4bc9d3a2d87c7968668e5d9b7b6fd5a"
  :revdesc "f93be7a5f4bc"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
