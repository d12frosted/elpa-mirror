;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20260516.1839"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "cec25f367cb1641dc1c94a837f876214c89081fc"
  :revdesc "cec25f367cb1"
  :keywords '("languages"))
