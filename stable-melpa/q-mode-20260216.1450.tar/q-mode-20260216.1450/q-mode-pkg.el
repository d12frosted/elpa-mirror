;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "q-mode" "20260216.1450"
  "A q editing mode."
  '((emacs "24"))
  :url "https://github.com/psaris/q-mode"
  :commit "766e7b58b666de13cd0dced7828c762be92f08cc"
  :revdesc "766e7b58b666"
  :keywords '("faces" "files" "q"))
