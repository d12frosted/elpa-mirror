;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241126.943"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.70.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "0a2c697f20b41a18680aa1fe26a5faa49c1a231f"
  :revdesc "0a2c697f20b4")
