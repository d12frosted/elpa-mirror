;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cape" "20251108.1649"
  "Completion At Point Extensions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/cape"
  :commit "e39fa24b8a15af5ba865563d0c639e74691853f3"
  :revdesc "e39fa24b8a15"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
