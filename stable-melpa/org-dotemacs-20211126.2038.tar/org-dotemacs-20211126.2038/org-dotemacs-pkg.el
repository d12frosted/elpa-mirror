;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dotemacs" "20211126.2038"
  "Store your emacs config as an org file, and choose which bits to load."
  '((org    "7.9.3")
    (cl-lib "0.5"))
  :url "https://github.com/vapniks/org-dotemacs"
  :commit "598759f4a139f94da62836e8f8064da6377536b2"
  :revdesc "598759f4a139"
  :keywords '("local")
  :authors '(("Joe Bloggs" . "vapniks@yahoo.com"))
  :maintainers '(("Joe Bloggs" . "vapniks@yahoo.com")))
