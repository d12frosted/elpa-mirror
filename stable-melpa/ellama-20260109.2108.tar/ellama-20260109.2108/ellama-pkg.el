;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260109.2108"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "064eb0778d43b093c495fe142e6fef07fe3a5c68"
  :revdesc "064eb0778d43"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
