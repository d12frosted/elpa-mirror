;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-if" "20150920.1513"
  "Interactive Fiction Authoring System for Org-Mode."
  ()
  :url "https://gitlab.com/elzair/org-if"
  :commit "fab602cc1bbee7a4e99c0083e129219d3f9ed2e8"
  :revdesc "fab602cc1bbe"
  :keywords '("if" "org-if" "org org-mode")
  :authors '(("Philip Woods" . "elzairthesorcerer@gmail.com"))
  :maintainers '(("Philip Woods" . "elzairthesorcerer@gmail.com")))
