(define-package "icomplete-vertical" "20210227.2146" "Display icomplete candidates vertically"
  '((emacs "26.1"))
  :commit "e490b01f7420bc15bc8e7b4594964208c3d31107" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience" "completion")
  :url "https://github.com/oantolin/icomplete-vertical")
;; Local Variables:
;; no-byte-compile: t
;; End:
