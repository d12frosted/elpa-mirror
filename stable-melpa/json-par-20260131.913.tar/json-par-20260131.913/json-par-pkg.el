;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "json-par" "20260131.913"
  "Minor mode for structural editing of JSON."
  '((emacs "24.4"))
  :url "https://github.com/taku0/json-par"
  :commit "1c0e363a8d28bf66187d082c97370c2fa11adfcc"
  :revdesc "1c0e363a8d28"
  :keywords '("abbrev" "convenience" "files")
  :authors '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainers '(("taku0" . "mxxouy6x3m_github@tatapa.org")))
