;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250111.1431"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "f4f04a4a01d60c3f6632939820ccf0d92a5d2c53"
  :revdesc "f4f04a4a01d6"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
