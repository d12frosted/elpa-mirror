(define-package "org-modern" "20240721.2133" "Modern looks for Org"
  '((emacs "27.1")
    (compat "30"))
  :commit "63df971a82d03e9007c671de5edc5d3549f90df5" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "text")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
