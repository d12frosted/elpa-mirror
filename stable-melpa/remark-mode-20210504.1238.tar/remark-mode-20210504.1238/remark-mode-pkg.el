(define-package "remark-mode" "20210504.1238" "Major mode for the remark slideshow tool"
  '((emacs "25.1")
    (markdown-mode "2.0"))
  :commit "9f15285445fdb53e720ffe72f5cf05231d340906" :authors
  '(("@torgeir"))
  :maintainer
  '("@torgeir")
  :keywords
  '("remark" "slideshow" "markdown" "hot reload"))
;; Local Variables:
;; no-byte-compile: t
;; End:
