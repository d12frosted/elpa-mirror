(define-package "gptel" "20231023.1745" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "62a602030245881ddf445cef5649aef70d4d9495" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
