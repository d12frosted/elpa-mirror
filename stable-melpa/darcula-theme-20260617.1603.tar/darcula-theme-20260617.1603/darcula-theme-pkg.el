;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "darcula-theme" "20260617.1603"
  "Inspired by IntelliJ's Darcula theme."
  ()
  :url "https://gitlab.com/fommil/emacs-darcula-theme"
  :commit "89e81a156f375306aa0aa639b3d0161543ce514f"
  :revdesc "89e81a156f37"
  :keywords '("faces")
  :authors '(("Sam Halliday" . "Sam.Halliday@gmail.com"))
  :maintainers '(("Sam Halliday" . "Sam.Halliday@gmail.com")))
