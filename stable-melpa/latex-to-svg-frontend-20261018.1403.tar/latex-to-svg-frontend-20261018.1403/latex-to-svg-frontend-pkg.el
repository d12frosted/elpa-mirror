;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261018.1403"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.15.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "47f7dd8a544447e883c2f83b1fcc967950574e1e"
  :revdesc "47f7dd8a5444"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
