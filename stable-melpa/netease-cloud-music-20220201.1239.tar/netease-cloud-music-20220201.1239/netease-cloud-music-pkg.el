(define-package "netease-cloud-music" "20220201.1239" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "e60b98274f7b21b95e89ea13ba754be1ee20bb3c" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
