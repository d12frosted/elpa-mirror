;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "anyins" "20131229.1041"
  "Insert content at multiple places from shell command or kill-ring."
  ()
  :url "https://github.com/antham/anyins"
  :commit "cd5e3c1abd471c8a67aafc42c4c985a2796f4b9f"
  :revdesc "cd5e3c1abd47"
  :keywords '("insert" "rectangular")
  :authors '(("Anthony HAMON" . "hamon.anth@gmail.com"))
  :maintainers '(("Anthony HAMON" . "hamon.anth@gmail.com")))
