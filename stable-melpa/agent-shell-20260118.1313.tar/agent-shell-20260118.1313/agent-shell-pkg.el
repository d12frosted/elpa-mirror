;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260118.1313"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.8")
    (acp         "0.8.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6ed52b9f9c705dc26e53d4a4da5609757cd614a0"
  :revdesc "6ed52b9f9c70")
