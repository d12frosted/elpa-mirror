(define-package "emacsql-psql" "20220101.1820" "EmacSQL back-end for PostgreSQL via psql"
  '((emacs "25.1")
    (emacsql "2.0.0"))
  :commit "374726060d74df0e2bcb9d0355ff41e2c400ed30" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/emacsql")
;; Local Variables:
;; no-byte-compile: t
;; End:
