(define-package "elpher" "20210810.949" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "11d905f730e73f72cc35bbdcb5989ead112b7c4a" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
