;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260323.829"
  "Highlight window and cursor at switching."
  '((emacs "25.1"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "62f316e4857adfde6ceab674b34635600f86de57"
  :revdesc "62f316e4857a"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '(("Anoncheg" . "vitalij@gmx.com"))
  :maintainers '(("Anoncheg" . "vitalij@gmx.com")))
