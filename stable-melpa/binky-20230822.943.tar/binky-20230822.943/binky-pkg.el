(define-package "binky" "20230822.943" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "7f35d460f0028a6737a41df2522616b97b91dbd0" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
