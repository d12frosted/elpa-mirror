(define-package "racket-mode" "20220818.1323" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "56df0bdf81070a45a524c94cbfe6354ad613dcbe" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
