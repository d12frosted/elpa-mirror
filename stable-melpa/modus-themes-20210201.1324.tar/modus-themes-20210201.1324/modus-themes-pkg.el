(define-package "modus-themes" "20210201.1324" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "e6094b65e6766f7ee98a974099074b18c7e1834b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
