(define-package "detached" "20221027.944" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "565d7bf8d7c5153d6b3f4c6abc5f989deac1e8b9" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
