;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20260126.955"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "18b797c367f7b136db910b9f4dad0813a6fa3bd7"
  :revdesc "18b797c367f7"
  :keywords '("convenience" "text"))
