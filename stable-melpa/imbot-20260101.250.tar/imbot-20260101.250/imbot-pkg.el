;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260101.250"
  "[No description available]."
  ()
  :url "https://github.com/QiangF/imbot"
  :commit "6dd59b39f29c689c866b1c5de19722dea3f5e6a8"
  :revdesc "6dd59b39f29c")
