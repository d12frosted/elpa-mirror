(define-package "paimon" "20220214.2145" "A major mode for Splunk"
  '((aio "1.0")
    (closql "1.2.0")
    (emacs "27.1")
    (emacsql "3.0.0")
    (emacsql-sqlite "3.0.0")
    (f "0.20.0")
    (ht "2.4")
    (transient "0.3.7")
    (request "0.3.3"))
  :commit "826a11d449a6cc8453093d79a8c031f43f753139" :authors
  '(("r0man" . "roman@burningswell.com"))
  :maintainer
  '("r0man" . "roman@burningswell.com")
  :keywords
  '("paimon" "search" "tools")
  :url "https://github.com/r0man/paimon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
