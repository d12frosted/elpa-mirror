;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-coq" "20260218.2114"
  "A collection of extensions for Proof General's Coq mode."
  '((cl-lib       "0.5")
    (dash         "2.12.1")
    (yasnippet    "0.11.0")
    (company      "0.8.12")
    (company-math "1.1"))
  :url "https://github.com/cpitclaudel/company-coq"
  :commit "617d92dcad3bea224f9552c11afdc6472710d744"
  :revdesc "617d92dcad3b"
  :keywords '("convenience" "languages")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
