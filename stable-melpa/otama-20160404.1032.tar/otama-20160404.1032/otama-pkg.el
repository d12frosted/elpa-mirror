;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "otama" "20160404.1032"
  "Org-table Manipulator."
  ()
  :url "https://github.com/yoshinari-nomura/otama"
  :commit "b69e0740846ace7885b0c0717f7abe8d0419eefd"
  :revdesc "b69e0740846a"
  :keywords '("database" "org-mode")
  :authors '(("Yoshinari Nomura" . "nom@quickhack.net"))
  :maintainers '(("Yoshinari Nomura" . "nom@quickhack.net")))
