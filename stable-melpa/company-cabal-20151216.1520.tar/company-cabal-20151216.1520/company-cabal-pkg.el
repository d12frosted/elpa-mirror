(define-package "company-cabal" "20151216.1520" "company-mode cabal backend"
  '((cl-lib "0.5")
    (company "0.8.0")
    (emacs "24"))
  :commit "f458de88cad16ed48a605e8347e56433e73dcef8" :authors
  '(("Iku Iwasa" . "iku.iwasa@gmail.com"))
  :maintainer
  '("Iku Iwasa" . "iku.iwasa@gmail.com")
  :url "https://github.com/iquiw/company-cabal")
;; Local Variables:
;; no-byte-compile: t
;; End:
