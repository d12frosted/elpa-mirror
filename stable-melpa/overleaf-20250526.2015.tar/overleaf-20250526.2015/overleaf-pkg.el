;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250526.2015"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "13a19bf72eafe615eb7432ad7a9e8119a7d85b82"
  :revdesc "13a19bf72eaf"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
