(define-package "boon" "20220918.1931" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "987e8fc4d530e2f2b9d92bdc7384810433317951")
;; Local Variables:
;; no-byte-compile: t
;; End:
