(define-package "aozora-view" "20140310.1317" "Aozora Bunko text Emacs viewer." 'nil :commit "b0390616d19e45f15f9a2f5d5688274831e721fd" :authors
  (("KAWABATA, Taichi <kawabata.taichi_at_gmail.com>"))
  :maintainer
  ("KAWABATA, Taichi <kawabata.taichi_at_gmail.com>")
  :keywords
  ("text")
  :url "https://github.com/kawabata/aozora-view")
;; Local Variables:
;; no-byte-compile: t
;; End:
