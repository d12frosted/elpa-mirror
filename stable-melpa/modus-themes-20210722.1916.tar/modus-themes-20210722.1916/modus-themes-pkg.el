(define-package "modus-themes" "20210722.1916" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "fd61a0c67ceafa3aeb0aeebddb93955148376b7e" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
