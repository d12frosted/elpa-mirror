(define-package "clips-mode" "20170909.823" "Major mode for editing CLIPS code and REPL" 'nil :commit "dd38e2822640a38f7d8bfec4f69d8dd24be27074")
;; Local Variables:
;; no-byte-compile: t
;; End:
