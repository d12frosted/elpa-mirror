(define-package "opam-switch-mode" "20230620.2144" "Select OCaml opam switches via a menu"
  '((emacs "25.1"))
  :commit "2312ccd149cee5b9c43b4bd1ed397440addf7027" :maintainers
  '((nil . "proof-general-maintainers@groupes.renater.fr"))
  :maintainer
  '(nil . "proof-general-maintainers@groupes.renater.fr")
  :url "https://github.com/ProofGeneral/opam-switch-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
