(define-package "helm-core" "20230907.1530" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "7dbdf3e999ccae2700b669b02ada6728c805542f" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
