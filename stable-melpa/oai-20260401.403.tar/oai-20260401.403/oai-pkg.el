;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260401.403"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "b903e6b495b2b8355e611d3eb3a5622d47801fdd"
  :revdesc "b903e6b495b2"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
