;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20250405.1023"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "d8d36c40e17bab3d1d6cd3c3009af6296a762b4e"
  :revdesc "d8d36c40e17b"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
