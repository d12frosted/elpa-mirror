;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20241118.950"
  "Link org-id entries into a network."
  '((emacs  "28.1")
    (compat "30")
    (el-job "0.3.2")
    (llama  "0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "d6effa3c6611d6a75bd4acfe80b66682856c0da5"
  :revdesc "d6effa3c6611"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
