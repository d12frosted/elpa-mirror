;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "miasma-theme" "20241219.2022"
  "Miasma: color theme inspired by the woods."
  ()
  :url "https://github.com/daut/miasma-theme.el"
  :commit "1c37cc2b8a6c5e1d31c764c259b551e57bc88669"
  :revdesc "1c37cc2b8a6c")
