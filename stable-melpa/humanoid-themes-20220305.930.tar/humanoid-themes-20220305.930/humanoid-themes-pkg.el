(define-package "humanoid-themes" "20220305.930" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "5828705bcc3eab9af9dd36fd7dc96d48c3020d85" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
