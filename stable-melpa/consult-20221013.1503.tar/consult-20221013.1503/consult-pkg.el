(define-package "consult" "20221013.1503" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "45a05fbbcaf67f5b60c4d614bafce3b9b8279ea0" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
