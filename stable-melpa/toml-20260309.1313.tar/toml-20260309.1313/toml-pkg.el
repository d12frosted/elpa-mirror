;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260309.1313"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "b4d0ef28419cebcfc345b90fce31bddb6fabf515"
  :revdesc "b4d0ef28419c"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
