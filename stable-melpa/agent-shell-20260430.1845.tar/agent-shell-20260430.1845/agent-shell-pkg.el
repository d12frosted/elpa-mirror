;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260430.1845"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "d48c239046e28c49a551b3ffaa657891304091b9"
  :revdesc "d48c239046e2")
