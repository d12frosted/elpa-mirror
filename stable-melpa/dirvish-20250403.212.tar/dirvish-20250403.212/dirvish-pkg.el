;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250403.212"
  "A modern file manager based on dired mode."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "8a0df38f19832fbf8ffc38b022fb13d8aa8807bc"
  :revdesc "8a0df38f1983"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
