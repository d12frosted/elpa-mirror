;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260330.420"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "cd5eb261c1007443576ce13a1820c1af84cf594f"
  :revdesc "cd5eb261c100"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
