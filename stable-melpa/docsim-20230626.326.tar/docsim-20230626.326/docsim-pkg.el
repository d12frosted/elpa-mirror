(define-package "docsim" "20230626.326" "Search and compare notes with a local search engine"
  '((emacs "24.4")
    (org "8.0"))
  :commit "e90f3610908301e9cb585c1b57e0d5c8e710ad2a" :authors
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainers
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainer
  '("Harry R. Schwartz" . "hello@harryrschwartz.com")
  :url "https://github.com/hrs/docsim.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
