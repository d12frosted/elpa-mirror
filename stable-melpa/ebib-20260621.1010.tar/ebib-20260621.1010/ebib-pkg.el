;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebib" "20260621.1010"
  "A BibTeX database manager."
  '((parsebib "6.0")
    (emacs    "27.1")
    (compat   "29.1.4.3"))
  :url "http://joostkremers.github.io/ebib/"
  :commit "75c1eda30c8d5f33eb725191c03b6306efa253f7"
  :revdesc "75c1eda30c8d"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
