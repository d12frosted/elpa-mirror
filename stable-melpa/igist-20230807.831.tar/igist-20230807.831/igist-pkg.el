(define-package "igist" "20230807.831" "List, create, update and delete GitHub gists"
  '((emacs "27.1")
    (ghub "3.5.6")
    (transient "0.3.7"))
  :commit "ff8be673decc92d1dbfbfbb66785aaa2adec0b63" :authors
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainer
  '("Karim Aziiev" . "karim.aziiev@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/KarimAziev/igist")
;; Local Variables:
;; no-byte-compile: t
;; End:
