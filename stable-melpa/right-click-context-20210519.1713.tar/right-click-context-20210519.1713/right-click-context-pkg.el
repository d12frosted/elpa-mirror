;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "right-click-context" "20210519.1713"
  "Right Click Context menu."
  '((emacs   "24.3")
    (popup   "0.5")
    (ordinal "0.0.1"))
  :url "https://github.com/zonuexe/right-click-context"
  :commit "c3c9d36ffbc9fb2bc7c2c4b75291dbcdb1c5f531"
  :revdesc "c3c9d36ffbc9"
  :keywords '("mouse" "menu" "rightclick")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
