;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260320.121"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "ebb50b50122ff373e850e7f95b1873e7a4a19f85"
  :revdesc "ebb50b50122f"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
