(define-package "kurecolor" "20220830.1019" "color editing goodies"
  '((emacs "24.4")
    (s "1.12"))
  :commit "ccea37ec5e09011fa5260347b8f727100622e932" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
