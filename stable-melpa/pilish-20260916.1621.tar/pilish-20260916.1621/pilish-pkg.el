;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "20260916.1621"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.4.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "ef41a0c121cc316d317fac804d7f6808effde90e"
  :revdesc "ef41a0c121cc"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
