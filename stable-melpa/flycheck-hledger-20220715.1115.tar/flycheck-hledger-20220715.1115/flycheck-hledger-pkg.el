(define-package "flycheck-hledger" "20220715.1115" "Flycheck module to check hledger journals"
  '((emacs "27.1")
    (flycheck "31"))
  :commit "c360025b8433abc4da89b0bfcc7ed1ff27004c64" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :url "https://github.com/DamienCassou/flycheck-hledger/")
;; Local Variables:
;; no-byte-compile: t
;; End:
