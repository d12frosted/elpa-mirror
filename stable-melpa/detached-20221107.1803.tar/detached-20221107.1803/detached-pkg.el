(define-package "detached" "20221107.1803" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "7f70f00340f11d41fa3d561787386f3e70cef75b" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
