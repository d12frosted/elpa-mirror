(define-package "kubedoc" "20230513.2014" "Kubernetes API Documentation"
  '((emacs "27.1"))
  :commit "c07e356326b6f373694d43369c7110c2873e24cd" :authors
  '(("Dean Lindqvist Todevski <https://github.com/r0bobo>"))
  :maintainers
  '(("Dean Lindqvist Todevski"))
  :maintainer
  '("Dean Lindqvist Todevski")
  :keywords
  '("docs" "help" "k8s" "kubernetes" "tools")
  :url "https://github.com/r0bobo/kubedoc.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
