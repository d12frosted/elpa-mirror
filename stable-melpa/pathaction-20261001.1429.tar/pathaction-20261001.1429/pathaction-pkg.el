;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20261001.1429"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "072674fa710bc0f5512b9ae6e06aeeb8868fd1bc"
  :revdesc "072674fa710b"
  :keywords '("tools" "processes" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
