(define-package "modus-themes" "20211104.736" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "ef234d41fd2d45f32e7c40e6f334231916c9dad9" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
