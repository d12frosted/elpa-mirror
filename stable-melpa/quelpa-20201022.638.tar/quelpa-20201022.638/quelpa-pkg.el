(define-package "quelpa" "20201022.638" "Emacs Lisp packages built directly from source"
  '((emacs "25.1"))
  :commit "8e59bf825629388384324b3eea5d51958d7fd34e" :authors
  (("steckerhalter"))
  :maintainer
  ("steckerhalter")
  :keywords
  ("tools" "package" "management" "build" "source" "elpa")
  :url "https://github.com/quelpa/quelpa")
;; Local Variables:
;; no-byte-compile: t
;; End:
