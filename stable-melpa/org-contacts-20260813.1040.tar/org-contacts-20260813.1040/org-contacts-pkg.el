;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-contacts" "20260813.1040"
  "Contacts management system for Org mode."
  '((emacs "29.1")
    (org   "9.7"))
  :url "https://repo.or.cz/org-contacts.git"
  :commit "7c5e35336ebf10c3f29008d100cb965d53bd860e"
  :revdesc "7c5e35336ebf"
  :keywords '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :authors '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
