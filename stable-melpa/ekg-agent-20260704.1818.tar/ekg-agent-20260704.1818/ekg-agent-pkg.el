;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260704.1818"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "370f4bce464acd3930ae5181833854983bb40072"
  :revdesc "370f4bce464a"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
