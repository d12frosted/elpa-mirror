;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-py-mode" "20251225.426"
  "Live Coding in Python."
  '((emacs "24.3"))
  :url "http://donkirkby.github.io/live-py-plugin/"
  :commit "78ae1d25f4c101b2804eecc2d01e1cc3223fd795"
  :revdesc "78ae1d25f4c1"
  :keywords '("live" "coding"))
