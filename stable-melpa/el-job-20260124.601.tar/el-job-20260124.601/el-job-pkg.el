;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "el-job" "20260124.601"
  "Contrived way to call a function using all CPU cores."
  '((emacs "29.1"))
  :url "https://github.com/meedstrom/el-job"
  :commit "f4ea8f705026546b401fb0912ffe2105ff084562"
  :revdesc "f4ea8f705026"
  :keywords '("processes")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
