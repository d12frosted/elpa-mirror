;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trailing-newline-indicator" "20260112.1713"
  "Show an indicator for the trailing newline."
  '((emacs "26.1"))
  :url "https://github.com/saulotoledo/trailing-newline-indicator"
  :commit "f53d9e139f734d9ea35a907a6c44b70795d81737"
  :revdesc "f53d9e139f73"
  :keywords '("convenience" "display" "editing")
  :authors '(("Saulo S. de Toledo" . "saulotoledo@gmail.com"))
  :maintainers '(("Saulo S. de Toledo" . "saulotoledo@gmail.com")))
