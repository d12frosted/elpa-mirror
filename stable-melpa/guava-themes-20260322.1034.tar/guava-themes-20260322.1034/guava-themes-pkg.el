;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260322.1034"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "c5585927b5d5c81e876027b85df483b3dbdebcfa"
  :revdesc "c5585927b5d5"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
