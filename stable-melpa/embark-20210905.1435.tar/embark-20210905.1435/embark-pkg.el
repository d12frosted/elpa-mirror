(define-package "embark" "20210905.1435" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d21277a638827623ab84e9e6341312a2da5062ab" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
