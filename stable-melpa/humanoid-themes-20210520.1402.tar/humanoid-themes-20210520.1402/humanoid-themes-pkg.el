(define-package "humanoid-themes" "20210520.1402" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "75256f16ab5bbd934a74bcfb6d24974d857e6664" :authors
  '(("Thomas Friese"))
  :maintainer
  '("Thomas Friese")
  :keywords
  '("faces" "color" "theme")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
