(define-package "diff-hl" "20201220.38" "Highlight uncommitted changes using VC"
  '((cl-lib "0.2")
    (emacs "24.3"))
  :commit "b8b4f43af73f109bf1af0453a076c274164488cf" :authors
  '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("vc" "diff")
  :url "https://github.com/dgutov/diff-hl")
;; Local Variables:
;; no-byte-compile: t
;; End:
