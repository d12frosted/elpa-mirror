(define-package "grugru" "20201116.430" "Rotate text at point"
  '((emacs "24.4"))
  :commit "ce3cc60a3ff3dc2fdc0e3edef7cc51fd4ccb3411" :keywords
  ("convenience" "abbrev" "tools")
  :authors
  (("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  ("ROCKTAKEY" . "rocktakey@gmail.com")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
