(define-package "grugru" "20201116.430" "Rotate text at point"
  '((emacs "24.4"))
  :commit "521d51a02a3fb76b01b35090ee102d0562cba0e4" :keywords
  ("convenience" "abbrev" "tools")
  :authors
  (("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  ("ROCKTAKEY" . "rocktakey@gmail.com")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
