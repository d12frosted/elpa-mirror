;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "debian-el" "20250407.837"
  "Startup file for the debian-el package."
  ()
  :commit "7459b21a4cefa285db428860ae94e2a31555e4b9"
  :revdesc "7459b21a4cef"
  :keywords '("debian" "apt" "elisp")
  :authors '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org"))
  :maintainers '(("Debian Emacsen Team" . "debian-emacsen@lists.debian.org")))
