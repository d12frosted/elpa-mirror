;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20260125.14"
  "A looping macro."
  '((emacs  "28.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "d34569439eec8f4bd6becd4e7a46107644c1f82c"
  :revdesc "d34569439eec"
  :keywords '("extensions"))
