;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "erlang" "20260326.1431"
  "Major modes for editing and running Erlang."
  '((emacs "27.1"))
  :url "https://github.com/erlang/otp"
  :commit "b7dfac8a1bc13f931f953e25610da4e019df414a"
  :revdesc "b7dfac8a1bc1"
  :keywords '("erlang" "languages" "processes"))
