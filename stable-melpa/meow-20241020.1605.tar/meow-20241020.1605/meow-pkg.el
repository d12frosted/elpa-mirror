;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meow" "20241020.1605"
  "Yet Another modal editing."
  '((emacs "27.1"))
  :url "https://github.com/meow-edit/meow"
  :commit "ebf7ebb5eb3ac7bb3cfaca9c32d9063f385aee9a"
  :revdesc "ebf7ebb5eb3a"
  :keywords '("convenience" "modal-editing"))
