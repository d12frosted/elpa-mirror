(define-package "eask" "20240414.1111" "Core Eask APIs, for Eask CLI development"
  '((emacs "26.1"))
  :commit "85b93afb96e2f9c8fa9b1091e1a95c532b42dd97" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("lisp" "eask" "api")
  :url "https://github.com/emacs-eask/eask")
;; Local Variables:
;; no-byte-compile: t
;; End:
