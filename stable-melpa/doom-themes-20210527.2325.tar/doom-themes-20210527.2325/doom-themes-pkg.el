(define-package "doom-themes" "20210527.2325" "an opinionated pack of modern color-themes"
  '((emacs "25.1")
    (cl-lib "0.5"))
  :commit "c5afb32901d08995747d764589c2c26bec358c52" :authors
  '(("Henrik Lissner <http://github/hlissner>"))
  :maintainer
  '("Henrik Lissner" . "henrik@lissner.net")
  :keywords
  '("dark" "light" "blue" "atom" "one" "theme" "neotree" "icons" "faces" "nova")
  :url "https://github.com/hlissner/emacs-doom-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
