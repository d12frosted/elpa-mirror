;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "preseed-generic-mode" "20180210.500"
  "Debian preseed file major mode."
  ()
  :url "https://github.com/suntong/preseed-generic-mode"
  :commit "3aa8806c4a659064baa01751400c53fbaf847f66"
  :revdesc "3aa8806c4a65"
  :authors '(("Tong Sun" . "suntong@users.sourceforge.net"))
  :maintainers '(("Tong Sun" . "suntong@users.sourceforge.net")))
