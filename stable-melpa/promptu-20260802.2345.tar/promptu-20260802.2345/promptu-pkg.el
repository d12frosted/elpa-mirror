;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "20260802.2345"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "37a3c801596d6f0fdab5ae74d2c631c8d65643d7"
  :revdesc "37a3c801596d"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
