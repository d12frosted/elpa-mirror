(define-package "helm-ls-git" "20230617.1533" "list git files."
  '((helm "1.7.8"))
  :commit "91e4ee3bcfe8a8a4c46124aff7803623edd8accd")
;; Local Variables:
;; no-byte-compile: t
;; End:
