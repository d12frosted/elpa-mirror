;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260619.1606"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.1")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "bb1bcfa97231d35f498197ac647debcc128ee3c4"
  :revdesc "bb1bcfa97231")
