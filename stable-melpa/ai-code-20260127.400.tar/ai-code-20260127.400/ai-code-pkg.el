;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260127.400"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "d0d02c8fee6403f8545b7d932be4620e3e20d0ca"
  :revdesc "d0d02c8fee64"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
