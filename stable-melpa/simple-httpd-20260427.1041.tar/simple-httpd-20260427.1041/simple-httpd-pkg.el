;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260427.1041"
  "Pure Elisp HTTP server."
  '((emacs  "26.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "8f0c79371e796c99700947b5b43d291fcf1ec69c"
  :revdesc "8f0c79371e79"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Christopher Wellons" . "wellons@nullprogram.com")))
