;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250319.44"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (llama  "0.5.0")
    (el-job "2.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "297ce158e7cd2d0ba2d79e20d4c6178cd602255d"
  :revdesc "297ce158e7cd"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
