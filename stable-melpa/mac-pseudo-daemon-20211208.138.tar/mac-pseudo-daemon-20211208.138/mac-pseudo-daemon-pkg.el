;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mac-pseudo-daemon" "20211208.138"
  "Daemon mode that plays nice with Mac OS."
  '((cl-lib "0.1"))
  :url "https://github.com/DarwinAwardWinner/mac-pseudo-daemon"
  :commit "462031a53255185ae25eb10ae1f4272e49ad70f7"
  :revdesc "462031a53255"
  :keywords '("convenience" "osx" "mac"))
