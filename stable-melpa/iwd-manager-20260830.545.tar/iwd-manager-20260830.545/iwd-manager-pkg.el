;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "iwd-manager" "20260830.545"
  "Manage IWD via the D-Bus interface."
  '((emacs   "26.1")
    (promise "1.1"))
  :url "https://github.com/sarg/wpa-manager.el"
  :commit "c3d53040c7be1222bab8b80a9646eac7dd9cc522"
  :revdesc "c3d53040c7be"
  :authors '(("Sergey Trofimov" . "sarg@sarg.org.ru"))
  :maintainers '(("Sergey Trofimov" . "sarg@sarg.org.ru")))
