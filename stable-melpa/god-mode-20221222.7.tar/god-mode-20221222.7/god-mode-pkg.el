(define-package "god-mode" "20221222.7" "Minor mode for God-like command entering"
  '((emacs "25.1"))
  :commit "c7754eaadaeabae2df94e23317b4a04d19b3f9e0" :authors
  '(("Chris Done" . "chrisdone@gmail.com"))
  :maintainer
  '("Chris Done" . "chrisdone@gmail.com")
  :url "https://github.com/emacsorphanage/god-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
