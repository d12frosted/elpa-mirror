(define-package "gptel" "20230403.2108" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "d77c8f37c56515bf53213f3e32a5ed99d6041a6d" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
