;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "20260810.1345"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "926bf7507d550efc7c86a84a3aa906e91116d663"
  :revdesc "926bf7507d55"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
