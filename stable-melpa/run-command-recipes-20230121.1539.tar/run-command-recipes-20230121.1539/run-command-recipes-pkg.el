(define-package "run-command-recipes" "20230121.1539" "This is collection of recipes to `run-command'"
  '((emacs "25.1")
    (dash "2.18.0")
    (f "0.20.0")
    (run-command "0.1.0"))
  :commit "ad9bd01b9c55a295be39e5334110900690ff21f6" :authors
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainer
  '("semenInRussia" . "hrams205@gmail.com")
  :keywords
  '("extensions" "run-command")
  :url "https://github.com/semenInRussia/emacs-run-command-recipes")
;; Local Variables:
;; no-byte-compile: t
;; End:
