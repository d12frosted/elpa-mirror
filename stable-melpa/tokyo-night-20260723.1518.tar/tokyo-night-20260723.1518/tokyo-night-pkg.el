;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tokyo-night" "20260723.1518"
  "Tokyo Night color themes."
  '((emacs "27.1"))
  :url "https://github.com/bbatsov/tokyo-night-emacs"
  :commit "36f98fcf965b3d5d027f4fab2d004123ed1d7355"
  :revdesc "36f98fcf965b"
  :keywords '("faces" "themes")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
