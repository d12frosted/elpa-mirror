(define-package "hl-indent-scope" "20230116.1013" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "47fcf4257d1aad2bd18f3ef0ccb14f3e21ff7b7a" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
