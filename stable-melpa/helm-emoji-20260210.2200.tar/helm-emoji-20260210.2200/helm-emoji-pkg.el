;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-emoji" "20260210.2200"
  "Select emojis with Helm."
  '((emacs "29.1")
    (helm  "3.9.6"))
  :url "https://codeberg.org/timmli/helm-emoji"
  :commit "ed523bea5717c722196cdd69eb1e2939b4712efa"
  :revdesc "ed523bea5717"
  :keywords '("matching")
  :authors '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de"))
  :maintainers '(("Timm Lichte" . "timm.lichte@uni-tuebingen.de")))
