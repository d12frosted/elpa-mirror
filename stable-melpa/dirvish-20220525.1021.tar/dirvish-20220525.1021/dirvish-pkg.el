(define-package "dirvish" "20220525.1021" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "b1afa4393a4a7123a9f056fbe6ebdd32a5674a83" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
