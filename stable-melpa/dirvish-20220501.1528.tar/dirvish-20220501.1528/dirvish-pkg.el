(define-package "dirvish" "20220501.1528" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "4cf24f974a4d3c47fa18d499a62a3d969e2cd21c" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
