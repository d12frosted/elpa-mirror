;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20251117.703"
  "Consulting completing-read."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/consult"
  :commit "6d736a767c8eb06b7a9a1964fb9c7be17b1aacf6"
  :revdesc "6d736a767c8e"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
