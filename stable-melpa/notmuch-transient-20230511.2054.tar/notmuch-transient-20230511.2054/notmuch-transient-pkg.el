(define-package "notmuch-transient" "20230511.2054" "Command dispatchers for Notmuch"
  '((emacs "27.1")
    (compat "29.1.4.1")
    (notmuch "0.37")
    (transient "0.4.0"))
  :commit "3eeabdd9c922836d24433786265ef7c25fb599b2" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("mail")
  :url "https://git.sr.ht/~tarsius/notmuch-transient")
;; Local Variables:
;; no-byte-compile: t
;; End:
