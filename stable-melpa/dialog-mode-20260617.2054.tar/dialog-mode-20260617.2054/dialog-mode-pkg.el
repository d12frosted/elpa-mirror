;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260617.2054"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "88190ed31ee37cc27626af0d42f5faaac5bb60fa"
  :revdesc "88190ed31ee3"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
