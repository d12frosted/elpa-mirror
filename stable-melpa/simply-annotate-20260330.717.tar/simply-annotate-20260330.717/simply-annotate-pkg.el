;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simply-annotate" "20260330.717"
  "Enhanced annotation system with threading."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/simply-annotate"
  :commit "a6018fa3b19cdbc5a8687d89856823e5952fec37"
  :revdesc "a6018fa3b19c"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
