(define-package "ebib" "20210915.806" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "a2ba91cf2f96e0b494bb8ce5dc965f8302d3b261" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
