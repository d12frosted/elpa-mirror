;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-social" "20260223.924"
  "An Org-social client for Emacs."
  '((emacs   "30.1")
    (org     "9.0")
    (request "0.3.0")
    (seq     "2.20")
    (emojify "1.2"))
  :url "https://github.com/tanrax/org-social.el"
  :commit "367ab5cf6ae12715bb9cade7a8eb45cf8d7f8723"
  :revdesc "367ab5cf6ae1"
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
