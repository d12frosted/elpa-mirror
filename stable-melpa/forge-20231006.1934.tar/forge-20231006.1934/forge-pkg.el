(define-package "forge" "20231006.1934" "Access Git forges from Magit."
  '((emacs "25.1")
    (compat "29.1.4.1")
    (closql "20230407")
    (dash "2.19.1")
    (emacsql "20230409")
    (ghub "20220621")
    (let-alist "1.0.6")
    (magit "20230319")
    (markdown-mode "2.4")
    (seq "2.24")
    (transient "0.4.0")
    (yaml "0.5.2"))
  :commit "5b3c64d6a81f3ac759fc30ecfd30945ab780f36e" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
