(define-package "citre" "20210703.1428" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "9976fb468c19e2c088fdab9449ac369645549dd1" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
