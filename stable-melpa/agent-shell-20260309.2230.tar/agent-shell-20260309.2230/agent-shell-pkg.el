;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260309.2230"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.88.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "41c4b2143a6b583f3f7e886e0b93943e0abced18"
  :revdesc "41c4b2143a6b")
