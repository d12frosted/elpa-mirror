(define-package "totp" "20230101.1617" "Time-based One-time Password (TOTP)"
  '((emacs "27.1"))
  :commit "19d3890e811e0565869590f0bc2b137f9b11fd4e" :authors
  '(("Jürgen Hötzel" . "juergen@hoetzel.info"))
  :maintainer
  '("Jürgen Hötzel" . "juergen@hoetzel.info")
  :keywords
  '("tools" "pass" "password")
  :url "https://github.com/juergenhoetzel/emacs-totp")
;; Local Variables:
;; no-byte-compile: t
;; End:
