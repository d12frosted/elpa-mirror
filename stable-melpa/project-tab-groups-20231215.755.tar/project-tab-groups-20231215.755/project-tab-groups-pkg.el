;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-tab-groups" "20231215.755"
  "Support a \"one tab group per project\" workflow."
  '((emacs "28.1"))
  :url "https://github.com/fritzgrabo/project-tab-groups"
  :commit "2658405d5f3c539fbd9ccf95297a016a2c91816a"
  :revdesc "2658405d5f3c"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
