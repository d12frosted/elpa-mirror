(define-package "detached" "20221122.2023" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "c41e6a035b05fb7c26c30c3f1c9572fbea05a0f9" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
