;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20241104.120"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "aa9d4d19be3c7ba510ed1a7bc33ad94991c5a0c5"
  :revdesc "aa9d4d19be3c"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
