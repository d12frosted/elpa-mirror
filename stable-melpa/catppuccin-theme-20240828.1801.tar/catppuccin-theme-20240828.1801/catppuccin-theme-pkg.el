(define-package "catppuccin-theme" "20240828.1801" "Catppuccin for Emacs - 🍄 Soothing pastel theme for Emacs"
  '((emacs "25.1"))
  :commit "fe83fa19fad9d39b9921ae84dd974e0806ebf18a" :maintainers
  '(("Jeremy Baxter" . "jeremy@baxters.nz"))
  :maintainer
  '("Jeremy Baxter" . "jeremy@baxters.nz")
  :url "https://github.com/catppuccin/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
