;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "litex-mode" "20221107.147"
  "Minor mode for converting lisp to LaTeX."
  '((emacs      "24.4")
    (units-mode "0.1.1"))
  :url "https://github.com/Atreyagaurav/litex-mode"
  :commit "45004b3a865771799b739d17ebb7849190fffa63"
  :revdesc "45004b3a8657"
  :keywords '("calculator" "lisp" "latex")
  :authors '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainers '(("Gaurav Atreya" . "allmanpride@gmail.com")))
