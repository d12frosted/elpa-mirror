(define-package "litex-mode" "20221107.147" "Minor mode for converting lisp to LaTeX"
  '((emacs "24.4")
    (units-mode "0.1.1"))
  :commit "45004b3a865771799b739d17ebb7849190fffa63" :authors
  '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainer
  '("Gaurav Atreya" . "allmanpride@gmail.com")
  :keywords
  '("calculator" "lisp" "latex")
  :url "https://github.com/Atreyagaurav/litex-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
