(define-package "ebib" "20220407.2003" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "a4f3016c77dfa1e9cbdd87e0e34e310e5c22a86a" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
