(define-package "ebib" "20220407.2003" "a BibTeX database manager"
  '((parsebib "2.3")
    (emacs "25.1"))
  :commit "6a044c9cc3429ff6c4072be1c184e0c6ffc49b58" :authors
  '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainer
  '("Joost Kremers" . "joostkremers@fastmail.fm")
  :keywords
  '("text" "bibtex")
  :url "http://joostkremers.github.io/ebib/")
;; Local Variables:
;; no-byte-compile: t
;; End:
