;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark" "20250702.731"
  "Conveniently act on minibuffer completions."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/oantolin/embark"
  :commit "e8e412f301577fe7302a9f23f0545bf416afdd4c"
  :revdesc "e8e412f30157"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
