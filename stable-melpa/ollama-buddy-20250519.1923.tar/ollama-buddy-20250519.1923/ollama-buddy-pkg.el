;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250519.1923"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Support."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "4efd37c36f9bca77ab556d7ea1e6369a5a12670f"
  :revdesc "4efd37c36f9b"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
