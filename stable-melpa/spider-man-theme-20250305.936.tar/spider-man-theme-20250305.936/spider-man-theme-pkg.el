;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spider-man-theme" "20250305.936"
  "A Vibrant Spider-Man Inspired Theme."
  '((emacs "24.1"))
  :url "https://github.com/madara123pain/unique-emacs-theme-pack"
  :commit "43afeb68b3ba0394f8cc925ebb90e9a6620b4b28"
  :revdesc "43afeb68b3ba"
  :keywords '("faces" "theme" "spiderman" "dark" "red" "blue"))
