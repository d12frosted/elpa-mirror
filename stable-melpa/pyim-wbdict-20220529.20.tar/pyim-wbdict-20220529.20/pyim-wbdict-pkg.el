(define-package "pyim-wbdict" "20220529.20" "Some wubi dicts for pyim"
  '((pyim "3.7"))
  :commit "0adf8372a9e983ee2c0b6ad35480d45e11c2e68d" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/tumashu/pyim-wbdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
