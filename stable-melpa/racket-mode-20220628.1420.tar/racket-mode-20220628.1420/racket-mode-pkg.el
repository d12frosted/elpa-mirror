(define-package "racket-mode" "20220628.1420" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "77c2d41c9ab041c383dfc60ed6ae562c4e953130" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
