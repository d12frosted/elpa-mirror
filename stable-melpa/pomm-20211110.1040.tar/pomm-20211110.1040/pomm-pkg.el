(define-package "pomm" "20211110.1040" "Yet another Pomodoro timer implementation"
  '((emacs "27.1")
    (alert "1.2")
    (seq "2.22")
    (transient "0.2.0"))
  :commit "62832704ba72613af8dbe0a6bf6d4daa89a21e12" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/pomm.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
