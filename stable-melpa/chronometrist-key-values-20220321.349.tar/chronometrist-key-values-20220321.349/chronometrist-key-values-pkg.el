;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chronometrist-key-values" "20220321.349"
  "Add key-values to Chronometrist data."
  '((chronometrist "0.7.0"))
  :url "https://tildegit.org/contrapunctus/chronometrist"
  :commit "239f733dd8f784a5251ae253d350a99fb739da6e"
  :revdesc "239f733dd8f7"
  :keywords '("calendar")
  :authors '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainers '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de")))
