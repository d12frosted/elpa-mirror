(define-package "geben" "20210827.342" "DBGp protocol frontend, a script debugger"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :commit "dd05dc37d17947bb5bfbc1969ba6f0c8d5a43016" :authors
  '(("Matthew Carter" . "m@ahungry.com"))
  :maintainer
  '("Matthew Carter" . "m@ahungry.com")
  :keywords
  '("c" "comm" "tools")
  :url "https://github.com/ahungry/geben")
;; Local Variables:
;; no-byte-compile: t
;; End:
