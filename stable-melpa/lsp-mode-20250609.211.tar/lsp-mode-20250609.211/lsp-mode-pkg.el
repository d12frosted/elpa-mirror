;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20250609.211"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "869fdf549afa2032e586b5db9205d70f045371a4"
  :revdesc "869fdf549afa"
  :keywords '("languages"))
