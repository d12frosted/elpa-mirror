;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20261126.1917"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "1f8ba511bd094b1f5c77b59ac2f04cc391d5b209"
  :revdesc "1f8ba511bd09"
  :keywords '("build tools" "languages"))
