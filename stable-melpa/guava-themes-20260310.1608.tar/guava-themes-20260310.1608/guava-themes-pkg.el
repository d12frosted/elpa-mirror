;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260310.1608"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "c93b434686948d78722f081d522c3519486c3afc"
  :revdesc "c93b43468694"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
