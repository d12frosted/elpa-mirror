(define-package "speechd-el" "20210702.1954" "Client to speech synthesizers and Braille displays." 'nil :commit "7f3d3d3545078df2f4a37094c618993145c731d2")
;; Local Variables:
;; no-byte-compile: t
;; End:
