(define-package "consult" "20210625.2238" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "5cef041e001548874dd1aa98e2764e0518d9a92d" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
