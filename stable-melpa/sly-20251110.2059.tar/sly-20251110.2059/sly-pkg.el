;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20251110.2059"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.3"))
  :url "https://github.com/joaotavora/sly"
  :commit "4743fb71d3026c00bf2059cda9ec7d13727474de"
  :revdesc "4743fb71d302"
  :keywords '("languages" "lisp" "sly"))
