;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-minor-faces" "20261001.1533"
  "Highlight only section headings."
  '((emacs    "28.1")
    (compat   "31.1")
    (cond-let "1.1"))
  :url "https://github.com/tarsius/outline-minor-faces"
  :commit "e875898cb0f2c617b056f6d2e6e24a0981b78792"
  :revdesc "e875898cb0f2"
  :keywords '("faces" "outlines")
  :authors '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.outline-minor-faces@jonas.bernoulli.dev")))
