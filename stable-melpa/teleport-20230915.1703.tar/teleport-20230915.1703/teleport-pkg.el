(define-package "teleport" "20230915.1703" "Integration for tsh (goteleport.com)"
  '((emacs "27.1")
    (dash "2.18.0"))
  :commit "a5262b0434b1b0c672e5b4bb625ea8d70a337b12" :authors
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainers
  '(("Caramel Hooves" . "caramel.hooves@protonmail.com"))
  :maintainer
  '("Caramel Hooves" . "caramel.hooves@protonmail.com")
  :keywords
  '("tools")
  :url "https://github.com/caramelhooves/teleport.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
