(define-package "lambdapi-mode" "20200929.612" "A major mode for editing Lambdapi source code"
  '((emacs "26.1")
    (eglot "1.5")
    (math-symbol-lists "1.2.1")
    (highlight "20190710.1527"))
  :commit "75449aee4864f46dd75738206ce01ea6f54c1d7f" :keywords
  ("languages")
  :authors
  (("Rodolphe Lepigre, Gabriel Hondet"))
  :maintainer
  ("Deducteam" . "dedukti-dev@inria.fr")
  :url "https://github.com/Deducteam/lambdapi")
;; Local Variables:
;; no-byte-compile: t
;; End:
