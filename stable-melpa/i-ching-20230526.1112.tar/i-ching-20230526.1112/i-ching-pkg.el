(define-package "i-ching" "20230526.1112" "The Book of Changes"
  '((emacs "25.1")
    (request "0.3"))
  :commit "ab9eaa445d21349213043298bbfe07e81c20a2e3" :authors
  '(("nik gaffney" . "nik@fo.am"))
  :maintainers
  '(("nik gaffney" . "nik@fo.am"))
  :maintainer
  '("nik gaffney" . "nik@fo.am")
  :keywords
  '("games" "divination" "stochastism" "cleromancy" "change")
  :url "https://github.com/zzkt/i-ching")
;; Local Variables:
;; no-byte-compile: t
;; End:
