;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenburn-theme" "20261128.1346"
  "A low contrast color theme."
  ()
  :url "https://github.com/bbatsov/zenburn-emacs"
  :commit "3419d856acb71b20c124e5921d8d11a9418ccf55"
  :revdesc "3419d856acb7"
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
