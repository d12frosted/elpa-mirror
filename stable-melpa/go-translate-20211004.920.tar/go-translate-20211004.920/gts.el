;;; gts.el --- translation -*- lexical-binding: t -*-
;;; Commentary:
;;; Code:

(require 'go-translate)

(require 'url)
(require 'facemenu)
(require 'gts-core)
(require 'gts-implements)
(require 'gts-google)

(setq gts-default-http-client (gts-url-http-client))
(setq gts-translate-pairs '(("en" "zh") ("fr" "zh")))

(defvar gts-default-picker (gts-prompt-picker :texter (gts-current-or-selection-texter)))
(defvar gts-default-engine (gts-google-engine :parser (gts-google-parser)))
(defvar gts-default-me-engine (gts-google-engine :parser (gts-google-summary-parser)))
(defvar gts-default-render (gts-buffer-render))

(defvar gts-default-translator)

(setq gts-default-translator
      (gts-translator

       :picker
       ;;(gts-prompt-picker :single t) ;; (a, b)
       (gts-noprompt-picker)
       ;;(gts-noprompt-picker :texter (gts-whole-buffer-texter))

       :engines
       (list
        ;;(gts-google-engine :parser (gts-google-summary-parser))
        (gts-google-engine :parser (gts-google-parser))
        )

       :render
       ;;(gts-kill-ring-render)
       ;;(gts-buffer-render)
       ;;(gts-posframe-pop-render :backcolor "#333333" :forecolor "#ffffff")
       (gts-posframe-pin-render)
       ))

(defun xxx ()
  "Xxx."
  (interactive)
  (gts-translate gts-default-translator)
  )

;; (setq a (gts-noprompt-picker))
;; (gts-all-paths a)
;; (gts-matched-paths a "hhk")
;; (gts-matched-paths a "hhk看")
;; (gts-matched-paths a "もののけ姫")
;; (gts-path a "kkk")
;; (gts-next-path a "kk看" "ja" "zh")

(provide 'gts)

;;; gts.el ends here
