(define-package "go-translate" "20211004.920" "Google Translate"
  '((emacs "26.1"))
  :commit "cb39628ba2570fbe89f23b072a332c3c4abc50a3" :authors
  '(("lorniu" . "lorniu@gmail.com"))
  :maintainer
  '("lorniu" . "lorniu@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/lorniu/go-translate")
;; Local Variables:
;; no-byte-compile: t
;; End:
