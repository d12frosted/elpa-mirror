;;; gts-google-tk.el --- google translate's tk algorithm  -*- lexical-binding: t -*-
;;; Commentary:

;; The tk algorithm from `google-translate' project.
;; https://github.com/atykhonov/google-translate/blob/master/google-translate-tk.el

;;; Code:

(defvar gts-google-token--bit-v-len 32)

(defun gts-google-token--bit-v-2comp (v)
  "Return the two's complement of V."
  (let* ((vc (vconcat v))
         (len (length vc)))
    ;; Complement of v
    (cl-loop for i from 0 below len do
             (aset vc i (logxor (aref vc i) 1)))
    ;; vc = complement of v + 1
    (cl-loop for i downfrom (1- len) to 0
             do (aset vc i (logxor (aref vc i) 1))
             when (> (aref vc i) 0) return nil)
    vc))

(defun gts-google-token--number-to-bit-v (n)
  "Return a bit vector from N."
  (if (< n 0) (gts-google-token--bit-v-2comp
               (gts-google-token--number-to-bit-v (abs n)))
    (let ((v (make-vector gts-google-token--bit-v-len 0)))
      (cl-loop for i downfrom (1- gts-google-token--bit-v-len) to 0
               with q
               when (< n 1) return nil do
               (setq q (ffloor (* n 0.5)))
               (aset v i (floor (- n (* 2.0 q))))
               (setq n q))
      v)))

(defun gts-google-token--bit-v-to-number (v)
  "Return a floating-point number from V."
  (if (and (> (aref v 0) 0)
           ;; Exclude [1 0 ... 0]
           (cl-loop for i from 1 below gts-google-token--bit-v-len
                    thereis (> (aref v i) 0)))
      (- (gts-google-token--bit-v-to-number (gts-google-token--bit-v-2comp v)))
    (funcall (if (> (aref v 0) 0)  #'- #'+)
             (cl-reduce (lambda (acc e) (+ (* acc 2.0) e))
                        v :initial-value 0.0))))

(defun gts-google-token--logfn (fn n1 n2)
  "Helper function for logical FN with N1 and N2."
  (let ((v1 (gts-google-token--number-to-bit-v n1))
        (v2 (gts-google-token--number-to-bit-v n2))
        (v (make-vector gts-google-token--bit-v-len 0)))
    (cl-loop for i from 0 below gts-google-token--bit-v-len do
             (aset v i (funcall fn (aref v1 i) (aref v2 i))))
    (gts-google-token--bit-v-to-number v)))

(defun gts-google-token--logand (n1 n2)
  "Return a floating-point number from N1 and N2."
  (gts-google-token--logfn #'logand n1 n2))

(defun gts-google-token--logxor (n1 n2)
  "Return a floating-point number from N1 and N2."
  (gts-google-token--logfn #'logxor n1 n2))

(defun gts-google-token--lsh (n d)
  "Return a floating-point number.
Shift the bits in N to the left or rihgt D places.
D is an integer."
  (let ((v (gts-google-token--number-to-bit-v n))
        (v-result (make-vector gts-google-token--bit-v-len 0)))
    (if (< d 0)
        ;; Shift Right Logical
        (cl-loop for i from (abs d) below gts-google-token--bit-v-len
                 for j from 0 do
                 (aset v-result i (aref v j)))
      ;; Shift Left Logical
      (cl-loop for i from d below gts-google-token--bit-v-len
               for j from 0 do
               (aset v-result j (aref v i))))
    (gts-google-token--bit-v-to-number v-result)))

(defun gts-google-token--gen-rl (a b)
  "Gen rl from A and B."
  (cl-loop for c from 0 below (- (length b) 2) by 3
           for d = (aref b (+ c 2)) do
           (setq d (if (>= d ?a) (- d 87) (- d ?0)))
           (setq d (if (= (aref b (1+ c)) ?+)
                       (gts-google-token--lsh a (- d))
                     (gts-google-token--lsh a d)))
           (setq a (if (= (aref b c) ?+)
                       (gts-google-token--logand (+ a d) 4294967295.0)
                     (gts-google-token--logxor a d))))
  a)


(defun gts-google-tkk (token text)
  "Calculate the Token for search TEXT.

It will use the tkk from Google translate page."
  (let* ((b (car token))
         (d1 (cdr token))
         (ub "+-3^+b+-f")
         (vb "+-a^+6")
         (a (cl-loop for c across (encode-coding-string text 'utf-8)
                     for rr = (gts-google-token--gen-rl (+ (or rr b) c) vb)
                     finally (return rr))))
    (setq a (gts-google-token--gen-rl a ub))
    (setq a (gts-google-token--logxor a d1))
    (if (< a 0) (setq a (+ (gts-google-token--logand a 2147483647.0) 2147483648.0)))
    (setq a (ffloor (mod a 1e6)))
    (format "%s.%s"
            (car (split-string (number-to-string a) "\\."))
            (car (split-string (number-to-string
                                (gts-google-token--logxor a b)) "\\.")))))


(provide 'gts-google-tk)

;;; gts-google-tk.el ends here
