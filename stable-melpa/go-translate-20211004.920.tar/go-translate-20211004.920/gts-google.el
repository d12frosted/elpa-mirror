;;; gts-google.el --- Google translate module -*- lexical-binding: t -*-
;;; Commentary:
;;; Code:

(require 'gts-core)
(require 'gts-google-tk)
(require 'facemenu)

(defcustom gts-tts-speaker (or (executable-find "mpv")
                               (executable-find "mplayer"))
  "The program to use to speak the translation.

On Windows, if it is not found, will fallback to use `powershell`
to do the job. Although it is not perfect, it seems to work."
  :type 'string
  :group 'gts)


;;; Engine

(defclass gts-google-engine (gts-engine)
  ((tag                :initform "Google")
   (base-url           :initform "http://translate.googleapis.com" :initarg :url)
   (sub-url            :initform "/translate_a/single")
   (token              :initform (cons 430675 2721866130))
   (token-time         :initform t)
   (token-expired-time :initform (* 30 60))))

(cl-defmethod gts-gen-url ((o gts-google-engine) text from to)
  "Generate the url with TEXT, FROM and TO. Return a (url text from to) list."
  (let* ((params `(("client" . "gtx")
                   ("ie"     . "UTF-8")
                   ("oe"     . "UTF-8")
                   ("dt"     . "bd")
                   ("dt"     . "ex")
                   ("dt"     . "ld")
                   ("dt"     . "md")
                   ("dt"     . "qc")
                   ("dt"     . "rw")
                   ("dt"     . "rm")
                   ("dt"     . "ss")
                   ("dt"     . "t")
                   ("dt"     . "at")
                   ("pc"     . "1")
                   ("otf"    . "1")
                   ("srcrom" . "1")
                   ("ssel"   . "0")
                   ("tsel"   . "0")
                   ("hl"     . ,to)
                   ("sl"     . ,from)
                   ("tl"     . ,to)
                   ("q"      . ,text)
                   ("tk"     . ,(gts-google-tkk (oref o token) text))))
         (url (format "%s%s?%s"
                      (oref o base-url)
                      (oref o sub-url)
                      (mapconcat (lambda (p)
                                   (format "%s=%s"
                                           (url-hexify-string (car p))
                                           (url-hexify-string (cdr p))))
                                 params "&"))))
    url))

(cl-defmethod gts-token-available-p ((o gts-google-engine))
  (let ((tt (oref o token-time)))
    (and (oref o token)
         (or (eq tt t)
             (and tt
                  (<= (float-time (time-subtract (current-time) tt))
                      (oref o token-expired-time)))))))

(cl-defmethod gts-with-token ((o gts-google-engine) callback)
  (with-slots (token token-time base-url) o
    (if (gts-token-available-p o)
        (funcall callback)
      (gts-do-request base-url nil
                      (lambda ()
                        (condition-case _err
                            (progn
                              (re-search-forward ",tkk:'\\([0-9]+\\)\\.\\([0-9]+\\)")
                              (let ((token (cons (string-to-number (match-string 1))
                                                 (string-to-number (match-string 2)))))
                                (setf token token)
                                (setf token-time (current-time))
                                (funcall callback)))
                          (error (user-error "Error when fetching Token-Key. Check your network and proxy, or retry later"))))
                      (lambda (status)
                        (user-error (format "ERR: %s" status)))))))

(cl-defmethod gts-translate ((o gts-google-engine) &optional text from to renderfun)
  (gts-with-token o (lambda ()
                      (gts-do-request
                       (gts-gen-url o text from to) nil
                       (lambda ()
                         (let* ((parser (oref o parser))
                                (result (gts-parse parser text (buffer-string))))
                           (funcall renderfun result)))
                       (lambda (status)
                         (funcall renderfun status))))))

;; tts

(cl-defmethod gts-tts-gen-urls ((o gts-google-engine) text lang)
  "Generate the tts urls for TEXT to LANGUAGE."
  (cl-loop with texts = (gts-tts-text-spliter o text)
           for total = (length texts)
           for index from 0
           for piece in texts
           collect
           (let ((params `(("ie"      . "UTF-8")
                           ("client"  . "gtx")
                           ("prev"    . "input")
                           ("q"       . ,text)
                           ("tl"      . ,lang)
                           ("total"   . ,(number-to-string total))
                           ("idx"     . ,(number-to-string index))
                           ("textlen" . ,(number-to-string (length piece)))
                           ("tk"      . ,(gts-google-tkk (oref o token) piece)))))
             (format "%s/translate_tts?%s"
                     (oref o base-url)
                     (mapconcat (lambda (p)
                                  (format "%s=%s"
                                          (url-hexify-string (car p))
                                          (url-hexify-string (cdr p))))
                                params "&")))))

(cl-defmethod gts-tts-text-spliter ((_ gts-google-engine) text)
  "Split TEXT by maxlen at applicable point for translating.
Code from `google-translate', maybe improve it someday."
  (let (result (maxlen 200))
    (if (or (null maxlen) (<= maxlen 0))
	    (push text result)
      ;; split long text?
      (with-temp-buffer
	    (save-excursion (insert text))
	    ;; strategy to split at applicable point
	    ;; 1) fill-region remaining text by maxlen
	    ;; 2) find end of sentence, end of punctuation, word boundary
	    ;; 3) consume from remaining text between start and (2)
	    ;; 4) repeat
	    (let ((fill-column (* maxlen 3))
	          (sentence-end-double-space nil)
	          (pos (point-min)))
	      (while (< pos (point-max))
	        (save-restriction
	          (narrow-to-region pos (point-max))
	          (fill-region pos (point-max))
	          (let ((limit (+ pos maxlen)))
		        (if (>= limit (point-max))
		            (setq limit (point-max))
		          (goto-char limit)
		          ;; try to split at end of sentence
		          (if (> (backward-sentence) pos)
		              (setq limit (point))
		            ;; try to split at end of punctuation
		            (goto-char limit)
		            (if (re-search-backward "[,、]" pos t)
			            (setq limit (1+ (point))) ; include punctuation
		              (goto-char limit)
		              ;; try to split at word boundary
		              (forward-word-strictly -1)
		              (when (> (point) pos)
			            (setq limit (point))))))
		        (push (buffer-substring-no-properties pos limit) result)
		        (goto-char limit)
		        (setq pos limit)))))))
    (reverse result)))

(cl-defmethod gts-do-tts ((o gts-google-engine) text lang)
  (cond (gts-tts-speaker
         (let ((urls (gts-tts-gen-urls o text lang)))
           (with-temp-message "Speaking..."
             (apply #'call-process gts-tts-speaker nil nil nil urls))))
        ((executable-find "powershell")
         (let ((cmd (format "$w = New-Object -ComObject SAPI.SpVoice; $w.speak(\\\"%s\\\")" text)))
           (shell-command (format "powershell -Command \"& {%s}\""
                                  (encode-coding-string
                                   (replace-regexp-in-string "\n" " " cmd)
                                   (keyboard-coding-system))))))
        (t (user-error "Program mplayer/powershell or others is need for tts"))))


;;; Result Formatter

(defvar gts-google-buffer-headline-face
  '(:inherit font-lock-function-name-face :weight bold)
  "Propertize the headline in buffer rendering.")


(defclass gts-google-parser (gts-parser)
  ((tag :initform "Detail")))

(cl-defmethod gts-decode ((_ gts-google-parser) resp)
  (with-temp-buffer
    (insert resp)
    (goto-char (point-min))
    (condition-case nil
        (progn
          (re-search-forward "\n\n")
          (let ((result (buffer-substring-no-properties (point) (point-max))))
            (gts-google-result--to-json result)))
      (error ""))))

(cl-defmethod gts-parse ((o gts-google-parser) text resp)
  (let ((json (gts-decode o resp)))
    (cond ((stringp json) ; an error occurred
           (insert text)
           (propertize (concat "\n\n\n" json) 'face 'font-lock-warning-face))
          (t
           (let* ((tbeg)
                  (tend)
                  (result)
                  (details     (gts-google-result--details json))
                  (definitions (gts-google-result--definitions json))
                  (suggestion  (gts-google-result--suggestion json))
                  (phonetic (lambda (ph)
                              (if (and (or definitions definitions) (> (length ph) 0))
                                  (propertize (format " [%s]" ph) 'face '(:inherit font-lock-string-face :slant normal))
                                "")))
                  (headline (lambda (headline)
                              (propertize (format "[%s]\n" headline) 'face gts-google-buffer-headline-face)))
                  (singlep (or details definitions)))
             (with-temp-buffer
               ;; source
               (insert text)
               ;; phonetic & translate
               (if singlep
                   (progn
                     (insert (funcall phonetic (gts-google-result--text-phonetic json)) " ")
                     (setq tbeg (point))
                     (insert (propertize (gts-google-result--translation json) 'face '(:weight bold)))
                     (setq tend (point))
                     (insert (funcall phonetic (gts-google-result--translation-phonetic json)) "\n\n"))
                 (setq send (point))
                 (facemenu-add-face 'font-lock-doc-face (point-min) (point))
                 (insert "\n\n")
                 (setq tbeg (point))
                 (insert (gts-google-result--translation json))
                 (setq tend (point))
                 (insert "\n"))
               ;; suggestion
               (when (> (length suggestion) 0)
                 (insert (funcall headline "Suggestion") "\n")
                 (insert (propertize "Did you mean:" 'face 'font-lock-warning-face) " ")
                 (insert (propertize suggestion 'face '((t (:slant italic :underline t)))) "\n"))
               ;; details
               (when details
                 (insert (funcall headline "Details"))
                 (cl-loop for item across details
                          for label = (aref item 0)
                          unless (string-equal label "")
                          do (let ((index 0))
                               (insert (format "\n%s:\n" label))
                               (cl-loop for trans across (aref item 2)
                                        for content = (format "%s (%s)" (aref trans 0)
                                                              (mapconcat #'identity (aref trans 1) ", "))
                                        do (insert (format "%2d. %s\n" (cl-incf index) content)))))
                 (insert "\n"))
               ;; definitions
               (when definitions
                 (insert (funcall headline "Definitions"))
                 (cl-loop for item across definitions
                          for label = (aref item 0)
                          unless (string-equal label "")
                          do (let ((index 0))
                               (insert (format "\n%s:\n" label))
                               (cl-loop for def across (aref item 1)
                                        for content = (concat (aref def 0)
                                                              (when (> (length def) 2)
                                                                (propertize
                                                                 (format "\n    %s" (aref def 2))
                                                                 'face 'font-lock-string-face)))
                                        do (insert (format "%2d. " (cl-incf index)) content "\n"))))
                 (insert "\n"))
               ;; at last, fill and return
               (setq result (buffer-string))
               (add-text-properties 0 1 `(text ,text tbeg ,tbeg tend ,tend) result)
               result))))))


(defclass gts-google-summary-parser (gts-google-parser)
  ((tag :initform "Summary")))

(cl-defmethod gts-parse ((o gts-google-summary-parser) text resp)
  (let* ((json (gts-decode o resp))
         (result (gts-google-result--translation json)))
    (add-text-properties 0 1 `(text ,text tbeg 1 tend ,(+ 1 (length result))) result)
    result))


;;; Functions

(defun gts-google-result--to-json (result)
  "Strip the string RESULT and then convert it to JSON."
  (setq result (replace-regexp-in-string "[[:space:]\n\r]+" " " result))
  (setq result (replace-regexp-in-string "[ \t\n\r]*\\'" "" result))
  (setq result (replace-regexp-in-string "\\`[ \t\n\r]*" "" result))
  (setq result (with-temp-buffer
                 (set-buffer-multibyte t)
                 (insert result)
                 (goto-char (point-min))
                 (while (re-search-forward "\\(\\[,\\|,,\\|,\\]\\)" (point-max) t)
                   (backward-char)
                   (insert "null"))
                 (buffer-string)))
  (json-read-from-string (decode-coding-string result 'utf-8)))

(defun gts-google-result--text-phonetic (json)
  "Get the text phonetic from JSON."
  (mapconcat (lambda (item) (if (> (length item) 3) (aref item 3) "")) (aref json 0) ""))

(defun gts-google-result--translation (json)
  "Get the translation text from JSON."
  (mapconcat (lambda (item) (aref item 0)) (aref json 0) ""))

(defun gts-google-result--translation-phonetic (json)
  "Get the translation phonetic from JSON."
  (mapconcat (lambda (item) (if (> (length item) 2) (aref item 2) "")) (aref json 0) ""))

(defun gts-google-result--suggestion (json)
  "Get the suggestion from JSON."
  (let ((info (aref json 7))) (unless (seq-empty-p info) (aref info 1))))

(defun gts-google-result--details (json)
  "Get the details from JSON."
  (aref json 1))

(defun gts-google-result--definitions (json)
  "Get the definitions from JSON."
  (if (> (length json) 12) (aref json 12)))


(provide 'gts-google)

;;; gts-google.el ends here
