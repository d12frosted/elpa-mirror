(define-package "org-tree-slide" "20230826.846" "A presentation tool for org-mode"
  '((emacs "25.2"))
  :commit "7085f35e78147816b42d29382b3a631122013d17" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainers
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("convenience" "org-mode" "presentation" "narrowing")
  :url "https://github.com/takaxp/org-tree-slide")
;; Local Variables:
;; no-byte-compile: t
;; End:
