(define-package "detached" "20220907.1105" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "463107a73b7af4bc11750d83ba72fcb0c30fb5d5" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
