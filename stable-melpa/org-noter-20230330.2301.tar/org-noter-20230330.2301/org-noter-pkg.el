(define-package "org-noter" "20230330.2301" "A synchronized, Org-mode, document annotator"
  '((emacs "24.4")
    (cl-lib "0.6")
    (org "9.0"))
  :commit "870109330a337751e44042d1b407d90d42ca9130" :authors
  '(("Gonçalo Santos (github.com/weirdNox)" . "in@bsentia")
    ("   Maintainer Dmitry M" . "dmitrym@gmail.com"))
  :maintainer
  '("Peter Mao" . "peter.mao@gmail.com")
  :keywords
  '("lisp" "pdf" "interleave" "annotate" "external" "sync" "notes" "documents" "org-mode")
  :url "https://github.com/org-noter/org-noter")
;; Local Variables:
;; no-byte-compile: t
;; End:
