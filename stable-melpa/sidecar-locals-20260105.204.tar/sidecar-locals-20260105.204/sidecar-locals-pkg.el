;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sidecar-locals" "20260105.204"
  "A flexible alternative to built-in dir-locals."
  '((emacs "28.1"))
  :url "https://codeberg.org/ideasman42/emacs-sidecar-locals"
  :commit "dff34937eeb7bdd1db5210701491cbe0101415de"
  :revdesc "dff34937eeb7"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
