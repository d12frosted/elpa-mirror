(define-package "keg" "20211103.1042" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "3d20af2e09ffd63243bdbd37261421a4e5d4a31f" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
