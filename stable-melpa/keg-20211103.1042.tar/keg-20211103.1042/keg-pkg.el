(define-package "keg" "20211103.1042" "Modern Elisp package development system"
  '((emacs "24.1"))
  :commit "697f730a37219f9b135a4c0630f4251b971796bf" :authors
  '(("Naoya Yamashita" . "conao3@gmail.com"))
  :maintainer
  '("Naoya Yamashita" . "conao3@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/conao3/keg.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
