;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apt-sources-list" "20180527.1241"
  "Mode for editing APT source.list files."
  '((emacs "24.4"))
  :url "https://git.korewanetadesu.com/apt-sources-list.git"
  :commit "44112833b3fa7f4d7e43708e5996782e22bb2fa3"
  :revdesc "44112833b3fa"
  :authors '(("Dr. Rafael Sepúlveda" . "drs@gnulinux.org.mx"))
  :maintainers '(("Joe Wreschnig" . "joe.wreschnig@gmail.com")))
