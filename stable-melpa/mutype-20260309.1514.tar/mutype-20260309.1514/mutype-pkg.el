;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mutype" "20260309.1514"
  "Type into stillness."
  '((emacs "25.1"))
  :url "https://github.com/suxiaogang223/mutype"
  :commit "26f41b3966d4cdbd7a54e7c840e6509a92d98770"
  :revdesc "26f41b3966d4"
  :keywords '("convenience" "typing")
  :authors '(("Xiaogang Su" . "https://github.com/suxiaogang223"))
  :maintainers '(("Xiaogang Su" . "https://github.com/suxiaogang223")))
