;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lush-theme" "20180816.2200"
  "A dark theme with lush colors."
  '((emacs "24"))
  :url "https://github.com/andre-richter/emacs-lush-theme"
  :commit "7cfc993709d712f75c51b505078608c9e1c11466"
  :revdesc "7cfc993709d7"
  :keywords '("theme" "dark" "strong colors")
  :authors '(("Andre Richter" . "andre.o.richter@gmail.com"))
  :maintainers '(("Andre Richter" . "andre.o.richter@gmail.com")))
