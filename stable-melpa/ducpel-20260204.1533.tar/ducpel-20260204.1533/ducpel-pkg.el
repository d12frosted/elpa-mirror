;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ducpel" "20260204.1533"
  "Logic game with sokoban elements."
  '((emacs "29.1"))
  :url "https://github.com/alezost/ducpel"
  :commit "bb0275a8aa7e8aa0895979711b037573544d50c1"
  :revdesc "bb0275a8aa7e"
  :keywords '("games")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
