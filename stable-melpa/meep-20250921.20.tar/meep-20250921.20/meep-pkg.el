;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250921.20"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "68ee73364cdeee60955e7105584b5dc28b507cf5"
  :revdesc "68ee73364cde"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
