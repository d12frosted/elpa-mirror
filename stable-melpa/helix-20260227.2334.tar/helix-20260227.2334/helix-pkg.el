;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helix" "20260227.2334"
  "A minor mode emulating Helix keybindings."
  '((emacs "29.1"))
  :url "https://github.com/mgmarlow/helix-mode"
  :commit "f97bda708771202ae9860800349f8f0114c81869"
  :revdesc "f97bda708771"
  :keywords '("convenience"))
