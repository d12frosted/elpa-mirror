;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251031.1719"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "46d5c857c649a1dbcc47b5d2439f12da05d8fd1d"
  :revdesc "46d5c857c649"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
