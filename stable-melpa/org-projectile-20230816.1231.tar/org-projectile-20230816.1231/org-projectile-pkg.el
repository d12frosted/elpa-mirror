(define-package "org-projectile" "20230816.1231" "Repository todo capture and management for org-mode with projectile"
  '((projectile "2.3.0")
    (dash "2.10.0")
    (org-project-capture "3.0.1"))
  :commit "418ec0311ff3dde2578930d834cdb507158797e7" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "projectile" "todo" "tools" "outlines" "project" "capture")
  :url "https://github.com/colonelpanic8/org-project-capture")
;; Local Variables:
;; no-byte-compile: t
;; End:
