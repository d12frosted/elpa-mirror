(define-package "org-tidy" "20230724.46" "A minor mode to tidy org-mode buffers"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "c89b0279833c07e5276a8c7009a41e9085b5e9b4" :authors
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainers
  '(("Xuqing Jia" . "jxq@jxq.me"))
  :maintainer
  '("Xuqing Jia" . "jxq@jxq.me")
  :keywords
  '("convenience" "org")
  :url "https://github.com/jxq0/org-tidy")
;; Local Variables:
;; no-byte-compile: t
;; End:
