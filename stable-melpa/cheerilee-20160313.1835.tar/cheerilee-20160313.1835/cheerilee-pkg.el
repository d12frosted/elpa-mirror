(define-package "cheerilee" "20160313.1835" "Toolkit library"
  '((xelb "0.1"))
  :commit "41bd81b5b0bb657241ceda5be6af5e07254d7376" :keywords
  ("tools"))
;; Local Variables:
;; no-byte-compile: t
;; End:
