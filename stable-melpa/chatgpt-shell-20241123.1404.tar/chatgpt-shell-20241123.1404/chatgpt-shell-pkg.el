;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241123.1404"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.70.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "b455f1a0e0041b572700683f1e18435e6d7a687a"
  :revdesc "b455f1a0e004")
