;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260316.2100"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "030be5fa926ef1aac1f30e49d4fa1cf9ab7078c1"
  :revdesc "030be5fa926e"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
