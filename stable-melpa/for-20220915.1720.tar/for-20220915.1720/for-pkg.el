(define-package "for" "20220915.1720" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "a2fe4af8c395c88e612174aa35d84a6c6fd1b300" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
