;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260223.1300"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "22294ff47c55a132e57facf4fd294d5a6759c678"
  :revdesc "22294ff47c55"
  :keywords '("languages"))
