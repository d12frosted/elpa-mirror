(define-package "corfu" "20240926.923" "COmpletion in Region FUnction"
  '((emacs "28.1")
    (compat "30"))
  :commit "4ccfa33026163d9fadcaf254eae1eba2f0ffaaca" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "text")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
