(define-package "obsidian" "20230821.1111" "Obsidian Notes interface"
  '((emacs "27.2")
    (s "1.12.0")
    (dash "2.13")
    (markdown-mode "2.5")
    (elgrep "1.0.0")
    (yaml "0.5.1"))
  :commit "c7cec01bcc4bbee18c9e5b5e7ddb33e4b09d03ff" :authors
  '(("Mykhaylo Bilyanskyy"))
  :maintainers
  '(("Mykhaylo Bilyanskyy"))
  :maintainer
  '("Mykhaylo Bilyanskyy")
  :keywords
  '("obsidian" "pkm" "convenience")
  :url "https://github.com./licht1stein/obsidian.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
