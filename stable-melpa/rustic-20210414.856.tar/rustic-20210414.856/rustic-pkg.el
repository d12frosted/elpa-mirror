(define-package "rustic" "20210414.856" "Rust development environment"
  '((emacs "26.1")
    (xterm-color "1.6")
    (dash "2.13.0")
    (s "1.10.0")
    (f "0.18.2")
    (markdown-mode "2.3")
    (spinner "1.7.3")
    (let-alist "1.0.4")
    (seq "2.3")
    (ht "2.0")
    (project "0.3.0"))
  :commit "c66086fa49d983a49758598b33f6e1585b3d6c74" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
