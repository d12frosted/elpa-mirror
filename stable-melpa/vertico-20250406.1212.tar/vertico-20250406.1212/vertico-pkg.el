;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20250406.1212"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "d16007b7f71962ef42be448eb9d54c2d4dfd19b4"
  :revdesc "d16007b7f719"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
