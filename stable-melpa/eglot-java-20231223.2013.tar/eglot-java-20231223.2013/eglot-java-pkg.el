(define-package "eglot-java" "20231223.2013" "Java extension for the eglot LSP client"
  '((emacs "26.1")
    (eglot "1.0")
    (jsonrpc "1.0.0"))
  :commit "18ce693b03286e5a3aab9243552c8cf168dd1c2b" :authors
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainers
  '(("Yves Zoundi" . "yves_zoundi@hotmail.com"))
  :maintainer
  '("Yves Zoundi" . "yves_zoundi@hotmail.com")
  :keywords
  '("convenience" "languages")
  :url "https://github.com/yveszoundi/eglot-java")
;; Local Variables:
;; no-byte-compile: t
;; End:
