;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-cfn" "20240512.2341"
  "Flycheck backend for AWS cloudformation."
  '((emacs    "27.0")
    (flycheck "31"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "b26a95a219aa700256b22fd026cace57bce1701b"
  :revdesc "b26a95a219aa"
  :keywords '("convenience")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
