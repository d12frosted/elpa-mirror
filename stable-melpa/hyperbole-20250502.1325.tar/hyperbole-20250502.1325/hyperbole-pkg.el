;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250502.1325"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "9ced23a3c86a3d5abb2d65c12ea74d4e420576fa"
  :revdesc "9ced23a3c86a"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
