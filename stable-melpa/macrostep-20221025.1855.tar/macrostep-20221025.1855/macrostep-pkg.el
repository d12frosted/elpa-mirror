(define-package "macrostep" "20221025.1855" "interactive macro expander"
  '((cl-lib "0.5"))
  :commit "4c3c2609647f4b98061cdea4cd30abaace1ed8a1" :authors
  '(("Jon Oddie" . "j.j.oddie@gmail.com"))
  :maintainer
  '("Jon Oddie" . "j.j.oddie@gmail.com")
  :keywords
  '("lisp" "languages" "macro" "debugging")
  :url "https://github.com/emacsorphanage/macrostep")
;; Local Variables:
;; no-byte-compile: t
;; End:
