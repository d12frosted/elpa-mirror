;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aes" "20211204.2348"
  "Implementation of AES."
  '((emacs "26.1"))
  :url "https://github.com/Sauermann/emacs-aes"
  :commit "c9cd12d6c1dbc18603eb4703276132cea59d5c78"
  :revdesc "c9cd12d6c1db"
  :keywords '("data" "tools")
  :authors '(("Markus Sauermann" . "emacs-aes@sauermann-consulting.de"))
  :maintainers '(("Markus Sauermann" . "emacs-aes@sauermann-consulting.de")))
