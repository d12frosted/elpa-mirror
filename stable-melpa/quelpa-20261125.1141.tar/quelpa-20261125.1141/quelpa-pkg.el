;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quelpa" "20261125.1141"
  "Emacs Lisp packages built directly from source."
  '((emacs "25.1"))
  :url "https://github.com/quelpa/quelpa"
  :commit "eb66ce40ef93da963c725775682a952265599777"
  :revdesc "eb66ce40ef93"
  :keywords '("tools" "package" "management" "build" "source" "elpa"))
