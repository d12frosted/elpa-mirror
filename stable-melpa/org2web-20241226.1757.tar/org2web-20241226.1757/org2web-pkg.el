;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org2web" "20241226.1757"
  "Static site generator based on org mode."
  '((cl-lib       "1.0")
    (ht           "1.5")
    (mustache     "0.22")
    (htmlize      "1.47")
    (org          "8.0")
    (dash         "2.0.0")
    (el2org       "0.10")
    (simple-httpd "0.1"))
  :url "https://github.com/tumashu/org2web"
  :commit "0e343770b9785f6150afc98153cd00a316d88d01"
  :revdesc "0e343770b978"
  :keywords '("org-mode" "convenience" "beautify")
  :authors '(("Feng Shu" . "tumashuAT163.com")
             ("Jorge Javier Araya Navarro" . "elcorreoATdeshackra.com")
             ("Kelvin Hu" . "iniDOTkelvinATgmailDOTcom"))
  :maintainers '(("Feng Shu" . "tumashuAT163.com")
                 ("Jorge Javier Araya Navarro" . "elcorreoATdeshackra.com")
                 ("Kelvin Hu" . "iniDOTkelvinATgmailDOTcom")))
