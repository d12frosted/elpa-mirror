;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20260104.2328"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "c42b3bafa12be5d01c990fab33e80ebd7a30f5af"
  :revdesc "c42b3bafa12b"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
