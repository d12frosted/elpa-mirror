;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elune-theme" "20231009.1709"
  "Elune theme."
  ()
  :url "https://github.com/xcatalyst/elune-theme"
  :commit "4d0217a7601e34fa84fc174ccf7945cd598d4135"
  :revdesc "4d0217a7601e"
  :authors '(("ağan Korkmaz" . "xcatalystt@gmail.com"))
  :maintainers '(("ağan Korkmaz" . "xcatalystt@gmail.com")))
