(define-package "consult" "20210716.1109" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "8250b7ac9a0c2d4acb869df393bddb1070fd24cc" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
