(define-package "consult" "20231127.953" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "44beaa209f2a1f9351b0156c483c09dbe9a84aac" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("matching" "files" "completion")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
