;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-side-windows" "20260817.938"
  "Simplified buffer management for side windows."
  '((emacs "30.1"))
  :url "https://github.com/MArpogaus/auto-side-windows"
  :commit "84ef9cac92053f95c011c903f81ad36a21e0f1a6"
  :revdesc "84ef9cac9205"
  :keywords '("convenience" "windows" "buffers")
  :authors '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz"))
  :maintainers '(("Marcel Arpogaus" . "znepry.necbtnhf@tznvy.pbz")))
