(define-package "embark" "20221108.1906" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "09a7d69b01816f5b3a190d50d6091425863ab167" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
