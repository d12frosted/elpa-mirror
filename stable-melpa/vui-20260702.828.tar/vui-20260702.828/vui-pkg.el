;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260702.828"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "59aeeb7d1c50f7291b91ac35c2a6917857f6f5d0"
  :revdesc "59aeeb7d1c50"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
