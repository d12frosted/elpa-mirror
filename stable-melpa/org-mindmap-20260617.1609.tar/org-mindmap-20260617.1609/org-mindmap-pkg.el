;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mindmap" "20260617.1609"
  "Editable mindmap visualization in org-mode."
  '((emacs "29.1")
    (org   "9.1"))
  :url "https://github.com/krvkir/org-mindmap"
  :commit "128e8fb853718bb4a04aff29703b927276a8b24c"
  :revdesc "128e8fb85371"
  :keywords '("org" "tools" "outlines")
  :authors '(("krvkir" . "krvkir@gmail.com"))
  :maintainers '(("krvkir" . "krvkir@gmail.com")))
