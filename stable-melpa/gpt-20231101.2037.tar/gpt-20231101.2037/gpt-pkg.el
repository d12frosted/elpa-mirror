(define-package "gpt" "20231101.2037" "Run instruction-following language models"
  '((emacs "24.4"))
  :commit "86da4fee59f17b65abf6168676303dbda787e39e" :authors
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainers
  '(("Andreas Stuhlmueller" . "andreas@ought.org"))
  :maintainer
  '("Andreas Stuhlmueller" . "andreas@ought.org")
  :keywords
  '("gpt3" "language" "copilot" "convenience" "tools")
  :url "https://github.com/stuhlmueller/gpt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
