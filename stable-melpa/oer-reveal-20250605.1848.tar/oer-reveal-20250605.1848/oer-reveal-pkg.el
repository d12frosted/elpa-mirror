;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oer-reveal" "20250605.1848"
  "OER with reveal.js, plugins, and org-re-reveal."
  '((emacs         "24.4")
    (org-re-reveal "3.35.0"))
  :url "https://gitlab.com/oer/oer-reveal"
  :commit "f58d121d2e666c9810aabb2b078f14c5bbe613a0"
  :revdesc "f58d121d2e66"
  :keywords '("hypermedia" "tools" "slideshow" "presentation" "oer"))
