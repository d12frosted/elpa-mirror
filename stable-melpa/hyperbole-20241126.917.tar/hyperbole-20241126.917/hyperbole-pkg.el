;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241126.917"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "e2749c6348f4783c5175b225e0f964d23c1ccc1f"
  :revdesc "e2749c6348f4"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
