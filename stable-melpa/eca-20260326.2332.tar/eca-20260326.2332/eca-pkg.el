;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260326.2332"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "9897ccfc702747276ea4b4fc98f2f8a4c8c47a6f"
  :revdesc "9897ccfc7027"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
