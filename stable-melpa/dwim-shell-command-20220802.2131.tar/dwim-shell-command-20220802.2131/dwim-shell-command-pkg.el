(define-package "dwim-shell-command" "20220802.2131" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "c1aab70ef9b5cff4a796ee033c5e3132d16b9ecb" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
