;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-ghq" "20231111.1303"
  "Ghq interface using consult."
  '((emacs   "26.1")
    (consult "0.8"))
  :url "https://github.com/tomoya/consult-ghq"
  :commit "65a99980fb313d473376542cb87464a8a44ff25e"
  :revdesc "65a99980fb31"
  :keywords '("convenience" "usability" "consult" "ghq")
  :authors '(("Tomoya Otake" . "tomoya.ton@gmail.com"))
  :maintainers '(("Tomoya Otake" . "tomoya.ton@gmail.com")))
