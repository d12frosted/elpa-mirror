;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dir-config" "20260114.1604"
  "Find and evaluate .dir-config.el (dir-locals alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/dir-config.el"
  :commit "4ac26d4698b841f438c0896896f39db90c120571"
  :revdesc "4ac26d4698b8"
  :keywords '("convenience"))
