(define-package "phpactor" "20210513.1901" "Interface to Phpactor"
  '((emacs "25.1")
    (f "0.17")
    (php-runtime "0.2")
    (composer "0.2.0")
    (async "1.9.3"))
  :commit "98b345c6751009d17c92fa3ade5bddce8f64e0c4" :authors
  '(("USAMI Kenta" . "tadsan@zonu.me")
    ("Mikael Kermorgant" . "mikael@kgtech.fi"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("tools" "php")
  :url "https://github.com/emacs-php/phpactor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
