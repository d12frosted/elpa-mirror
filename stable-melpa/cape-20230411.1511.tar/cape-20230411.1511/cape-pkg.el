(define-package "cape" "20230411.1511" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "1c7028109353c60e0f46295248d86618477eb4c5" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "wp")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
