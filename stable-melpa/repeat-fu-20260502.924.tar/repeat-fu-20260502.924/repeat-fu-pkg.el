;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20260502.924"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "3bf3de5a899167870fcbd486daeb5653338402bf"
  :revdesc "3bf3de5a8991"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
