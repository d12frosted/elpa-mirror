;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "newlisp-mode" "20160226.1545"
  "NewLISP editing mode for Emacs."
  ()
  :url "https://github.com/kosh04/newlisp-mode"
  :commit "ac23be40c81a360988ab803d365f1510733f6db4"
  :revdesc "ac23be40c81a"
  :keywords '("language" "lisp" "newlisp")
  :authors '(("KOBAYASHI Shigeru" . "shigeru.kb[at]gmail.com"))
  :maintainers '(("KOBAYASHI Shigeru" . "shigeru.kb[at]gmail.com")))
