(define-package "docsim" "20230619.251" "Search and compare notes with a local search engine"
  '((emacs "24.4")
    (org "8.0"))
  :commit "d0345061658de86ebb40a8e0db7f83e33d638dd8" :authors
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainers
  '(("Harry R. Schwartz" . "hello@harryrschwartz.com"))
  :maintainer
  '("Harry R. Schwartz" . "hello@harryrschwartz.com")
  :url "https://github.com/hrs/docsim.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
