(define-package "starhugger" "20230901.1922" "Hugging Face/AI-powered text & code completion client"
  '((emacs "28.2")
    (compat "29.1.4.0")
    (dash "2.18.0")
    (s "1.13.1")
    (spinner "1.7.4"))
  :commit "32c362a31fab1deedd37d787812e399fbee0d870" :keywords
  '("completion" "convenience" "languages")
  :url "https://gitlab.com/daanturo/starhugger.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
