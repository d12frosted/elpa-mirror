;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20261031.30"
  "Folding text based on indentation (origami alternative)."
  '((emacs    "26.1")
    (kirigami "1.0.5"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "dc4e8cad6cff4ec63d5659f1997157213c3a4917"
  :revdesc "dc4e8cad6cff"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
