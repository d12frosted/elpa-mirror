(define-package "org-web-track" "20240719.1127" "Web data tracking framework in Org Mode"
  '((emacs "29.1")
    (request "0.3.0")
    (enlive "0.0.1"))
  :commit "eff66fc207411d5a5265d4ee5232f13d268f252f" :authors
  '(("p-snow" . "public@p-snow.org"))
  :maintainers
  '(("p-snow" . "public@p-snow.org"))
  :maintainer
  '("p-snow" . "public@p-snow.org")
  :keywords
  '("org" "agenda" "web" "hypermedia")
  :url "https://github.com/p-snow/org-web-track")
;; Local Variables:
;; no-byte-compile: t
;; End:
