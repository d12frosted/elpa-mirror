;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260129.2143"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "f101ff2e4f5c02bd4718a89b30ed3c9470c9d295"
  :revdesc "f101ff2e4f5c"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
