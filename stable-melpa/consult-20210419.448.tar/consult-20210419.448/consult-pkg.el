(define-package "consult" "20210419.448" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "d321642973c6b62947d004bd6b3f387a84c5c131" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
