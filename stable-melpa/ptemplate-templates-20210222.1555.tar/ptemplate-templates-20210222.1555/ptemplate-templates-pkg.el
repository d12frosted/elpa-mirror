(define-package "ptemplate-templates" "20210222.1555" "Official templates"
  '((emacs "25.1")
    (ptemplate "2.0.0"))
  :commit "f65acbb4991470cb5ae513c9f2a8197ead297704" :authors
  '(("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainer
  '("Nikita Bloshchanevich" . "nikblos@outlook.com")
  :url "https://github.com/nbfalcon/ptemplate-templates")
;; Local Variables:
;; no-byte-compile: t
;; End:
