(define-package "x509-mode" "20220902.534" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "24.3"))
  :commit "a4ac0f352a01e4908bfcb03bd56047e68cc70cbd" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmai.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmai.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
