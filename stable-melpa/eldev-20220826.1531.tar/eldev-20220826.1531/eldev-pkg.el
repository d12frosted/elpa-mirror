(define-package "eldev" "20220826.1531" "Elisp development tool"
  '((emacs "24.4"))
  :commit "f41699dcb7dba5db3eecd8b0e5024e37b90e5e31" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
