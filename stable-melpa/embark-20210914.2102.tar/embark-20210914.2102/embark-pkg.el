(define-package "embark" "20210914.2102" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "64c4132c6e29d2e415325a50f190ab8a0732a4e4" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
