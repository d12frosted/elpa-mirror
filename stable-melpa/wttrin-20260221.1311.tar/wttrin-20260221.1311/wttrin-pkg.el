;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20260221.1311"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "b74b98f177d92d50ddbede900ba41212e07c5f63"
  :revdesc "b74b98f177d9"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
