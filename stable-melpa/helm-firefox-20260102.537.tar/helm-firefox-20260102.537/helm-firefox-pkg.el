;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-firefox" "20260102.537"
  "Firefox bookmarks."
  '((helm   "1.5")
    (cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/emacs-helm/helm-firefox"
  :commit "9356ace9fac469b94121c36e5960cc1f5ce14663"
  :revdesc "9356ace9fac4")
