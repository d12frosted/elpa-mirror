;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graphene" "20180529.1112"
  "Newbie-friendly defaults."
  ()
  :url "https://github.com/rdallasgray/graphene"
  :commit "cc8477fcfb7771ea4e5bbaf3c01f9e679234c1c1"
  :revdesc "cc8477fcfb77"
  :keywords '("defaults")
  :authors '(("Robert Dallas Gray" . "mail@robertdallasgray.com"))
  :maintainers '(("Robert Dallas Gray" . "mail@robertdallasgray.com")))
