(define-package "dirvish" "20220202.1133" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "5c3787fa06a3c8cee967d1dfa9700e4c917fb65c" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
