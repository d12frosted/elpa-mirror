;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copy-file-on-save" "20260728.802"
  "Copy file on save, automatic deployment it."
  '((emacs  "24.3")
    (compat "29"))
  :url "https://github.com/emacs-php/emacs-auto-deployment"
  :commit "5c9b80897ecaad2c4f47a2a473b88c25ee7885e2"
  :revdesc "5c9b80897eca"
  :keywords '("files" "comm" "deploy")
  :authors '(("USAMI Kenta" . "tadsan@zonu.me"))
  :maintainers '(("USAMI Kenta" . "tadsan@zonu.me")))
