;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20250210.1111"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "cfeaf8bb9b3ab3438defe8642302c951426da7b4"
  :revdesc "cfeaf8bb9b3a"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
