;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moe-theme" "20260811.1919"
  "A colorful eye-candy theme. Moe, moe, kyun!."
  ()
  :url "https://github.com/kuanyui/moe-theme.el"
  :commit "d091865eeb97b0894e6517137dc0544560bc57fb"
  :revdesc "d091865eeb97"
  :keywords '("themes")
  :authors '(("kuanyui" . "azazabc123@gmail.com"))
  :maintainers '(("kuanyui" . "azazabc123@gmail.com")))
