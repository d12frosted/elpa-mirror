(define-package "dir-treeview-themes" "20221103.37" "Themes for dir-treeview"
  '((emacs "24.4")
    (dir-treeview "1.3.3"))
  :commit "0fdc3f67d4959ac11bc2f44bf84ab8c9b32e6c64" :authors
  '(("Tilman Rassy" . "tilman.rassy@googlemail.com"))
  :maintainer
  '("Tilman Rassy" . "tilman.rassy@googlemail.com")
  :keywords
  '("tools" "convenience" "files")
  :url "https://github.com/tilmanrassy/emacs-dir-treeview-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
