(define-package "emacsc" "20210226.555" "helper for emacsc(1)" 'nil :commit "75761078047f2a28d74eab527b881128faaa4b75" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("tools")
  :url "https://github.com/knu/emacsc")
;; Local Variables:
;; no-byte-compile: t
;; End:
