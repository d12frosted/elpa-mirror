;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250516.1059"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "764fb2c239a775e7018737347811e32d524597bc"
  :revdesc "764fb2c239a7"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
