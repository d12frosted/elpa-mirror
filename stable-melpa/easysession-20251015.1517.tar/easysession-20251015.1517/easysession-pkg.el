;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20251015.1517"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "bdfa8eed769d56262d3c09986cbe3386b104de50"
  :revdesc "bdfa8eed769d"
  :keywords '("convenience"))
