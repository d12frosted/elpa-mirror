(define-package "meow" "20220409.24" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "ec03160337ea0c9f073b137791eea908491ff840" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
