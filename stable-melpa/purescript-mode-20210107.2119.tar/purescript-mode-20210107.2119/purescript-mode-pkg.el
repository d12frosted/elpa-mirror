(define-package "purescript-mode" "20210107.2119" "A PureScript editing mode"
  '((emacs "24")
    (cl-lib "0.6"))
  :commit "f61f8559ae8f64e41c2d44a0080bffa693f31ed1" :authors
  '(("1992      Simon Marlow")
    ("1997-1998 Graeme E Moss" . "gem@cs.york.ac.uk")
    ("Tommy Thorn" . "thorn@irisa.fr")
    ("2001-2002 Reuben Thomas (>=v1.4)")
    ("2003      Dave Love" . "fx@gnu.org")
    ("2014      Tim Dysinger" . "tim@dysinger.net"))
  :maintainer
  '("1992      Simon Marlow")
  :keywords
  '("faces" "files" "purescript")
  :url "https://github.com/purescript-emacs/purescript-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
