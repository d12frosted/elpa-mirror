;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20251005.2243"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "275757d382ff5afe6a80fab9098bb0c7605aa351"
  :revdesc "275757d382ff"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
