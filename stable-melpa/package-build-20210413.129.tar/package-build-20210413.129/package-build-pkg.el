(define-package "package-build" "20210413.129" "Tools for assembling a package archive"
  '((cl-lib "0.5")
    (emacs "25.1"))
  :commit "047801d301a73d4932f33f768d94a8ed26b8d524" :authors
  '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net"))
  :maintainer
  '("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
  :keywords
  '("tools")
  :url "https://github.com/melpa/package-build")
;; Local Variables:
;; no-byte-compile: t
;; End:
