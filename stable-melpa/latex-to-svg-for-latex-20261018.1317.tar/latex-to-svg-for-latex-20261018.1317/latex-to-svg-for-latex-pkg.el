;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-latex" "20261018.1317"
  "Preview LaTeX math as SVG in LaTeX buffers."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.22.2"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "ae570650d79a73da03546d8cb8cbb8f95f77a8ce"
  :revdesc "ae570650d79a"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
