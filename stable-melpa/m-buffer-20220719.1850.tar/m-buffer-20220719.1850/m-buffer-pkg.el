(define-package "m-buffer" "20220719.1850" "List-Oriented, Functional Buffer Manipulation"
  '((seq "2.14"))
  :commit "d2e35bf9293367f1a2d19f259f32a35bd9f4788b" :authors
  '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainer
  '("Phillip Lord" . "phillip.lord@russet.rg.uk"))
;; Local Variables:
;; no-byte-compile: t
;; End:
