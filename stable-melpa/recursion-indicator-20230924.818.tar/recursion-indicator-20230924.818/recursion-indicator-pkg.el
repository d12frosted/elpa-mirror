(define-package "recursion-indicator" "20230924.818" "Recursion indicator"
  '((emacs "27.1")
    (compat "29.1.4.2"))
  :commit "52b40acd95d1be370cad90805acd6f1a9a02f596" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience")
  :url "https://github.com/minad/recursion-indicator")
;; Local Variables:
;; no-byte-compile: t
;; End:
