(define-package "racket-mode" "20220320.1401" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "681aaf07d6b8dfa4e662452b45e943d913cca962" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
