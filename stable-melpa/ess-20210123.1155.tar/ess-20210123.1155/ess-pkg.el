(define-package "ess" "20210123.1155" "Emacs Speaks Statistics"
  '((emacs "25.1"))
  :commit "af7a718d0b82da451bb547e775a166dac4b60841" :authors
  '(("David Smith" . "dsmith@stats.adelaide.edu.au")
    ("A.J. Rossini" . "blindglobe@gmail.com")
    ("Richard M. Heiberger" . "rmh@temple.edu")
    ("Kurt Hornik" . "Kurt.Hornik@R-project.org")
    ("Martin Maechler" . "maechler@stat.math.ethz.ch")
    ("Rodney A. Sparapani" . "rsparapa@mcw.edu")
    ("Stephen Eglen" . "stephen@gnu.org")
    ("Sebastian P. Luque" . "spluque@gmail.com")
    ("Henning Redestig" . "henning.red@googlemail.com")
    ("Vitalie Spinu" . "spinuvit@gmail.com")
    ("Lionel Henry" . "lionel.hry@gmail.com")
    ("J. Alexander Branham" . "alex.branham@gmail.com"))
  :maintainer
  '("ESS Core Team" . "ESS-core@r-project.org")
  :url "https://ess.r-project.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
