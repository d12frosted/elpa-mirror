;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250526.442"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "22f743287c011f8c31b1f123a2e38a502e28f474"
  :revdesc "22f743287c01"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
