;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "enh-ruby-mode" "20260107.824"
  "Major mode for editing Ruby files."
  '((emacs "25.1"))
  :url "https://github.com/zenspider/Enhanced-Ruby-Mode"
  :commit "1a3a93a6ba51798baa7364589136d974b19fd8d8"
  :revdesc "1a3a93a6ba51"
  :keywords '("languages" "elisp" "ruby"))
