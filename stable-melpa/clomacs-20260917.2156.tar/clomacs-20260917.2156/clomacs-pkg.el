;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clomacs" "20260917.2156"
  "Simplifies Emacs Lisp interaction with Clojure."
  '((emacs        "24.3")
    (cider        "0.22.1")
    (s            "1.12.0")
    (simple-httpd "1.4.6")
    (dash         "2.19.1"))
  :url "https://github.com/clojure-emacs/clomacs"
  :commit "cfd7893a12391ed9aeb19984b843edae2d7e800c"
  :revdesc "cfd7893a1239"
  :keywords '("clojure" "interaction")
  :authors '(("Kostafey" . "kostafey@gmail.com"))
  :maintainers '(("Kostafey" . "kostafey@gmail.com")))
