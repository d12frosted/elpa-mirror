;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260603.1956"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "51c3982c94454fe71201fc376603f30c0ec0024a"
  :revdesc "51c3982c9445"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
