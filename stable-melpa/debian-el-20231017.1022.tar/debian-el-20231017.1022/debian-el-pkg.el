(define-package "debian-el" "20231017.1022" "Emacs helpers specific to Debian users" 'nil :commit "60aa194454a7adb82790b6455c130ecbe93cb2a7")
;; Local Variables:
;; no-byte-compile: t
;; End:
