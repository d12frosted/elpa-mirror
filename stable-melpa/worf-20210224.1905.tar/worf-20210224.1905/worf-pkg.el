(define-package "worf" "20210224.1905" "A warrior does not press so many keys! (in org-mode)"
  '((swiper "0.11.0")
    (ace-link "0.1.0")
    (hydra "0.13.0")
    (zoutline "0.1.0"))
  :commit "eed052db551f60483b4189e9c87cbb16f6d5947a" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("lisp")
  :url "https://github.com/abo-abo/worf")
;; Local Variables:
;; no-byte-compile: t
;; End:
