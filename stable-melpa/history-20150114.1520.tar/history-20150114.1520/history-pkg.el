(define-package "history" "20150114.1520" "History utility for source code navigation"
  '((emacs "24.3"))
  :commit "adef53ecc2f6067bb61f020a2b66c5185a51632d" :authors
  '(("boyw165"))
  :maintainer
  '("boyw165")
  :url "https://github.com/boyw165/history")
;; Local Variables:
;; no-byte-compile: t
;; End:
