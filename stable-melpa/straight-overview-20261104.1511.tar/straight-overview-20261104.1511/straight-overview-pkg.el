;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "straight-overview" "20261104.1511"
  "Selective upgrade UI for straight.el packages."
  '((emacs "29.1"))
  :url "https://github.com/alberti42/straight-overview"
  :commit "e606284b50f720b9387f32af84afd1c2299c788f"
  :revdesc "e606284b50f7"
  :keywords '("convenience" "tools" "vc")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
