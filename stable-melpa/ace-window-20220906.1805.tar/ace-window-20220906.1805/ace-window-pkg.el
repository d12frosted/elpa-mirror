(define-package "ace-window" "20220906.1805" "Quickly switch windows."
  '((avy "0.5.0"))
  :commit "e3e6ec105ae8d18208f7a56fc1b068dd1427f1d4" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("window" "location")
  :url "https://github.com/abo-abo/ace-window")
;; Local Variables:
;; no-byte-compile: t
;; End:
