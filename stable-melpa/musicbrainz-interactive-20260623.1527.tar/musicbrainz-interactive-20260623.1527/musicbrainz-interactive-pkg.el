;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "musicbrainz-interactive" "20260623.1527"
  "Interactive commands for MusicBrainz related things."
  '((emacs       "28.1")
    (musicbrainz "0.1"))
  :url "https://github.com/zzkt/metabrainz"
  :commit "bdb68a7034039c78acc62aa753401f84e1bd0217"
  :revdesc "bdb68a703403"
  :keywords '("data" "convenience" "music")
  :authors '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me"))
  :maintainers '(("Oliwier Czerwiński" . "oliwier.czerwi@proton.me")))
