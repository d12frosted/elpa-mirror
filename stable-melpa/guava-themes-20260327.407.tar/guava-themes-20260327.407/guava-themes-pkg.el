;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260327.407"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "6de9162a786ca0cbf7712d6ace1674f7b20c3651"
  :revdesc "6de9162a786c"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
