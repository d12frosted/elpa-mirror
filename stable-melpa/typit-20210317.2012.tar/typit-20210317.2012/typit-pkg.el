(define-package "typit" "20210317.2012" "Typing game similar to tests on 10 fast fingers"
  '((emacs "24.4")
    (f "0.18")
    (mmt "0.1.1"))
  :commit "a056f132832a222533e631e0fc397ab82a0a691a" :authors
  '(("Mark Karpov" . "markkarpov92@gmail.com"))
  :maintainer
  '("Mark Karpov" . "markkarpov92@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/mrkkrp/typit")
;; Local Variables:
;; no-byte-compile: t
;; End:
