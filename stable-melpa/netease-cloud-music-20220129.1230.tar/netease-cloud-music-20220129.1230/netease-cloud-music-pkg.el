(define-package "netease-cloud-music" "20220129.1230" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "ae0d94e743788def8deea527408aa636507900db" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
