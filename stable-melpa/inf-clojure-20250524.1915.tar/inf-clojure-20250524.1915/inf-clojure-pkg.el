;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-clojure" "20250524.1915"
  "Run an external Clojure process in an Emacs buffer."
  '((emacs        "26.2")
    (clojure-mode "5.11"))
  :url "http://github.com/clojure-emacs/inf-clojure"
  :commit "ece16ffeefc5ab23a31012d10765c34197510220"
  :revdesc "ece16ffeefc5"
  :keywords '("processes" "comint" "clojure")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
