;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-bashate" "20261028.1753"
  "A Flymake backend for bashate, a Bash scripts style checker."
  '((flymake-quickdef "1.0.0")
    (emacs            "27.1"))
  :url "https://github.com/jamescherti/flymake-bashate.el"
  :commit "a9c23cd7cb33b25c015e9f09d4a9673e8d5b588b"
  :revdesc "a9c23cd7cb33"
  :keywords '("tools" "languages")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
