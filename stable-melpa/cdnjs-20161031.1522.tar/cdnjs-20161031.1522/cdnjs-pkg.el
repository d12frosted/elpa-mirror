;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cdnjs" "20161031.1522"
  "A front end for http://cdnjs.com."
  '((dash     "2.13.0")
    (deferred "0.4")
    (f        "0.17.2")
    (pkg-info "0.5"))
  :url "https://github.com/yasuyk/cdnjs.el"
  :commit "ce19880d3ec3d81e6c665d0b1dfea99cc7a3f908"
  :revdesc "ce19880d3ec3"
  :keywords '("tools")
  :authors '(("Yasuyuki Oka" . "yasuyk@gmail.com"))
  :maintainers '(("Yasuyuki Oka" . "yasuyk@gmail.com")))
