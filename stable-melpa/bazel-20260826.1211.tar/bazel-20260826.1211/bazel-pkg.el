;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260826.1211"
  "Bazel support for Emacs."
  '((emacs "30.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "abf801d360474f09647a9b6e5fd5ad8e88d72971"
  :revdesc "abf801d36047"
  :keywords '("build tools" "languages"))
