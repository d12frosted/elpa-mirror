(define-package "mc-extras" "20170825.539" "Extra functions for multiple-cursors mode."
  '((multiple-cursors "1.2.1"))
  :commit "f0ba639e9b18cc56e80ae45bbb2b694dbad9171a" :authors
  '(("Akinori MUSHA" . "knu@iDaemons.org"))
  :maintainer
  '("Akinori MUSHA" . "knu@iDaemons.org")
  :keywords
  '("editing" "cursors")
  :url "https://github.com/knu/mc-extras.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
