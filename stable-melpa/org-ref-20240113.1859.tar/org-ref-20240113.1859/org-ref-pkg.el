(define-package "org-ref" "20240113.1859" "citations, cross-references and bibliographies in org-mode"
  '((org "9.4")
    (dash "0")
    (s "0")
    (f "0")
    (htmlize "0")
    (hydra "0")
    (avy "0")
    (parsebib "0")
    (bibtex-completion "0")
    (citeproc "0")
    (ox-pandoc "0"))
  :commit "ceaf7b9d96a705238cdfebb00ed27a53a30825af" :authors
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainers
  '(("John Kitchin" . "jkitchin@andrew.cmu.edu"))
  :maintainer
  '("John Kitchin" . "jkitchin@andrew.cmu.edu")
  :keywords
  '("org-mode" "cite" "ref" "label")
  :url "https://github.com/jkitchin/org-ref")
;; Local Variables:
;; no-byte-compile: t
;; End:
