(define-package "devil" "20230816.2251" "Minor mode for translating key sequences"
  '((emacs "24.4"))
  :commit "95677d158fba0f0248e9cf5aa1357bee4b293d8e" :authors
  '(("Susam Pal" . "susam@susam.net"))
  :maintainers
  '(("Susam Pal" . "susam@susam.net"))
  :maintainer
  '("Susam Pal" . "susam@susam.net")
  :keywords
  '("convenience" "abbrev")
  :url "https://github.com/susam/devil")
;; Local Variables:
;; no-byte-compile: t
;; End:
