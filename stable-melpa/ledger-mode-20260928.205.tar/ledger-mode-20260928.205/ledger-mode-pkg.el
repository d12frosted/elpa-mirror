;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "20260928.205"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "26.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "9539ff67a9ac491be4b382530bdbba9558379700"
  :revdesc "9539ff67a9ac")
