(define-package "notmuch" "20210627.1528" "run notmuch within emacs" 'nil :commit "5cc106b0e3e53f56b189ef067753ea5f29cb4243" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
