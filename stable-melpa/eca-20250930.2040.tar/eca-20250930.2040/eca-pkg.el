;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20250930.2040"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "a67d8f5f7d2c37cfa4b2a50334a73867f4b12b16"
  :revdesc "a67d8f5f7d2c"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
