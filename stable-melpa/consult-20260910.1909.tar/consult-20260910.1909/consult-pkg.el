;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult" "20260910.1909"
  "Search and navigate via completing-read."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/consult"
  :commit "f10cf28d3df1e43a8069f5a507c82654834c8b09"
  :revdesc "f10cf28d3df1"
  :keywords '("matching" "files" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
