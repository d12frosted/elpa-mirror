(define-package "citre" "20210709.2132" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "abb73157f57f40d3c310fda91e00722490b47e34" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
