;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260724.2207"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "f01c55cdc0c4b49c6c56e9d462831ada9d68f0f2"
  :revdesc "f01c55cdc0c4"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
