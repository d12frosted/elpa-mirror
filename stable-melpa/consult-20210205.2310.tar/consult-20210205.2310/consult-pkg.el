(define-package "consult" "20210205.2310" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "2f93d94f4312ec0246d6eaebda61256a09a50e7b" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
