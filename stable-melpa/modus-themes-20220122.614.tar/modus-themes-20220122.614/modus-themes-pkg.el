(define-package "modus-themes" "20220122.614" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "8396118da7d275ad27c25d8154aa89ae875f9dfd" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
