;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diff-hl" "20260625.426"
  "Highlight uncommitted changes using VC."
  '((cl-lib "0.2")
    (emacs  "27.1"))
  :url "https://github.com/dgutov/diff-hl"
  :commit "4905749ad29be958e1ad7353b1557fdc5716847a"
  :revdesc "4905749ad29b"
  :keywords '("vc" "diff")
  :authors '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
