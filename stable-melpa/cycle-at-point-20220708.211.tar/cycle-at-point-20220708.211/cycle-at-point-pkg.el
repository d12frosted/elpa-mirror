(define-package "cycle-at-point" "20220708.211" "Cycle (rotate) the thing under the cursor"
  '((emacs "28.1")
    (recomplete "0.2"))
  :commit "60f883b9894cfda262edefe3c2372366e57ad2be" :authors
  '(("Campbell Barton"))
  :maintainer
  '("Campbell Barton")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-cycle-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
