;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260414.1238"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "7bbc7bfa60c2b3c7f39f75e1600b13260315271e"
  :revdesc "7bbc7bfa60c2"
  :keywords '("files"))
