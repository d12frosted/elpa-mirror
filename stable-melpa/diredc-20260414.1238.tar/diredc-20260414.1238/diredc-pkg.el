;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "diredc" "20260414.1238"
  "Midnight Commander features (plus) for dired."
  '((emacs      "26.1")
    (key-assist "1.0"))
  :url "https://github.com/Boruch-Baum/emacs-diredc"
  :commit "ee9f2e615ff1c307cb363e4d9212de64ef54bb1a"
  :revdesc "ee9f2e615ff1"
  :keywords '("files"))
