;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260809.2344"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazel-contrib/bazel.el"
  :commit "984343f657e4ba24e1c84bc8b3b2d04f55f517d7"
  :revdesc "984343f657e4"
  :keywords '("build tools" "languages"))
