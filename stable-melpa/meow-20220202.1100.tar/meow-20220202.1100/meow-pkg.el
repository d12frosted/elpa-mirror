(define-package "meow" "20220202.1100" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "39fe100cfc2ee623399eb1da3d313378eacd7ed0" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
