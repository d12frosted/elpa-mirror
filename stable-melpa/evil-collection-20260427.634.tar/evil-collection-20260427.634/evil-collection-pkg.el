;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260427.634"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "3bb356bf3a196da0e14be2fc56d62920311bcc51"
  :revdesc "3bb356bf3a19"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
