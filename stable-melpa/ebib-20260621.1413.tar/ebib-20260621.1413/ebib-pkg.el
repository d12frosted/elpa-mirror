;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ebib" "20260621.1413"
  "A BibTeX database manager."
  '((parsebib "6.0")
    (emacs    "27.1")
    (compat   "29.1.4.3"))
  :url "http://joostkremers.github.io/ebib/"
  :commit "32c6ab8ce418af10b54f497a404b9b33a67d48fc"
  :revdesc "32c6ab8ce418"
  :keywords '("text" "bibtex")
  :authors '(("Joost Kremers" . "joostkremers@fastmail.fm"))
  :maintainers '(("Joost Kremers" . "joostkremers@fastmail.fm")))
