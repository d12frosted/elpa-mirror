(define-package "wildcharm-theme" "20231114.1157" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "735ffe1bcc8b5da4a1ecb99ec4a013ed33d5676c" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
