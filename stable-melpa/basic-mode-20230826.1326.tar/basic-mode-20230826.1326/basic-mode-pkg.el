(define-package "basic-mode" "20230826.1326" "Major mode for editing BASIC code"
  '((seq "2.20")
    (emacs "25.1"))
  :commit "be6924991b8eaeb14df0bf198a73ae8ac51df17c" :authors
  '(("Johan Dykstrom"))
  :maintainers
  '(("Johan Dykstrom"))
  :maintainer
  '("Johan Dykstrom")
  :keywords
  '("basic" "languages")
  :url "https://github.com/dykstrom/basic-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
