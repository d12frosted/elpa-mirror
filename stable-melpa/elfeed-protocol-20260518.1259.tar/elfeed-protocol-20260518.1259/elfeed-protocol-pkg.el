;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-protocol" "20260518.1259"
  "Provide fever/newsblur/owncloud/ttrss protocols for elfeed."
  '((emacs  "24.4")
    (elfeed "2.1.1")
    (cl-lib "0.5"))
  :url "https://github.com/fasheng/elfeed-protocol"
  :commit "089142fdeffad527237a8de4047cd9158f46c28a"
  :revdesc "089142fdeffa"
  :keywords '("news")
  :authors '(("Xu Fasheng" . "fasheng[AT]fasheng.info"))
  :maintainers '(("Xu Fasheng" . "fasheng[AT]fasheng.info")))
