(define-package "linguistic" "20181129.2116" "A package for basic linguistic analysis." 'nil :commit "23e47e98cdb09ee61883669b6d8a11bf6449862c" :keywords
  ("linguistics" "text analysis" "matching")
  :authors
  (("Andrew Favia <drewlinguistics01 at gmail dot com>"))
  :maintainer
  ("Andrew Favia <drewlinguistics01 at gmail dot com>")
  :url "https://github.com/andcarnivorous/linguistic")
;; Local Variables:
;; no-byte-compile: t
;; End:
