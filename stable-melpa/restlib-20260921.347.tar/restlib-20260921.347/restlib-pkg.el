;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "restlib" "20260921.347"
  "Utility library for building REST clients."
  '((emacs "30.1"))
  :url "https://github.com/kickingvegas/restlib"
  :commit "a2ee43ecab7fb7fb4b230cd2697db15adfcf32ff"
  :revdesc "a2ee43ecab7f"
  :keywords '("tools")
  :authors '(("Charles Y. Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Y. Choi" . "kickingvegas@gmail.com")))
