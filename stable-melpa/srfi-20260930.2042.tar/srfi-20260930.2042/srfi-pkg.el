;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20260930.2042"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "289960e5a20a3ecc82bde1d1e85d250255e2da63"
  :revdesc "289960e5a20a"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
