(define-package "git-attr" "20180925.2003" "Git attributes of buffer file"
  '((emacs "24.3"))
  :commit "3e43a0cf616b00a4bbd3c6b49fd2397f3103796f" :authors
  '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainer
  '("Arne Jørgensen" . "arne@arnested.dk")
  :keywords
  '("vc")
  :url "https://github.com/arnested/emacs-git-attr")
;; Local Variables:
;; no-byte-compile: t
;; End:
