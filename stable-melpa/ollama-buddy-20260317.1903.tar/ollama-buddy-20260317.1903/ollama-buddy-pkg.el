;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260317.1903"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral DeepSeek OpenRouter Support."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "146148bba940a32fdc02dc32e93da7737eafe1ee"
  :revdesc "146148bba940"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
