(define-package "nordic-night-theme" "20230822.1608" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "66aa555af2552fe6d1efd3170f199edd0d44fced" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
