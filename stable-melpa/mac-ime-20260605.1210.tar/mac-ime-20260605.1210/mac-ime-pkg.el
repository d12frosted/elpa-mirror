;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mac-ime" "20260605.1210"
  "Seamless macOS IME integration without any IME patches."
  '((emacs "27.1"))
  :url "https://github.com/ma0001/mac-ime"
  :commit "0a8f40c6ad8d02f9b99e3eaa5a68e625b87e7f30"
  :revdesc "0a8f40c6ad8d"
  :keywords '("i18n" "convenience"))
