;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20261027.2126"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "27.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "cd99f402d9b142bf378aaf939f279b78f4e93170"
  :revdesc "cd99f402d9b1"
  :keywords '("convenience" "files")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
