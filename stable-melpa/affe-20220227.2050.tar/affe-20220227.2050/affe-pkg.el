(define-package "affe" "20220227.2050" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.12"))
  :commit "33aeeac9b56ba0dc36c1399999212ca54ea5ed0e" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
