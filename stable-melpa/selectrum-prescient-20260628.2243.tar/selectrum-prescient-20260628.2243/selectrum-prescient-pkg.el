;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selectrum-prescient" "20260628.2243"
  "Prescient.el + Selectrum."
  '((emacs     "25.1")
    (prescient "6.1.0")
    (selectrum "3.1"))
  :url "https://github.com/raxod502/prescient.el"
  :commit "5649977fa7789e4615efeca09397ed7eccd06dfc"
  :revdesc "5649977fa778"
  :keywords '("extensions")
  :authors '(("Radian LLC" . "contact+prescient@radian.codes"))
  :maintainers '(("Radian LLC" . "contact+prescient@radian.codes")))
