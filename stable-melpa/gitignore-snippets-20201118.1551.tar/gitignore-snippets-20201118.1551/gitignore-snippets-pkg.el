(define-package "gitignore-snippets" "20201118.1551" "Gitignore.io templates for Yasnippet"
  '((emacs "26")
    (yasnippet "0.8.0"))
  :commit "f91b3397526fe09d2e4a1f507a73b06bc7542cf7" :authors
  '(("Seong Yong-ju" . "sei40kr@gmail.com"))
  :maintainer
  '("Seong Yong-ju" . "sei40kr@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/sei40kr/gitignore-snippets")
;; Local Variables:
;; no-byte-compile: t
;; End:
