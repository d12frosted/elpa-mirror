;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-dt" "20260330.1927"
  "Dynamic templating loader."
  '((emacs "29.1"))
  :url "https://codeberg.org/niqc/org-dynamic-templates"
  :commit "aad20f4e6208077825f4b6cd8fc90dffcc1f5cbd"
  :revdesc "aad20f4e6208"
  :keywords '("convenience"))
