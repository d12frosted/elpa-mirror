;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hookify" "20141216.2209"
  "Interactive commands to create temporary hooks."
  '((s    "1.9.0")
    (dash "1.5.0"))
  :url "https://github.com/Silex/hookify"
  :commit "e76127230716f7fab6662410c03c3872d17a172b"
  :revdesc "e76127230716"
  :keywords '("hook" "convenience")
  :authors '(("Philippe Vaucher" . "philippe.vaucher@gmail.com"))
  :maintainers '(("Philippe Vaucher" . "philippe.vaucher@gmail.com")))
