;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260629.921"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b2ee5a6374c614af1cf673f9af7f5f57698ee44d"
  :revdesc "b2ee5a6374c6"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
