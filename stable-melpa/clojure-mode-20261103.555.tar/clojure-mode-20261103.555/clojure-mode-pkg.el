;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-mode" "20261103.555"
  "Major mode for Clojure code."
  '((emacs "27.1"))
  :url "https://github.com/clojure-emacs/clojure-mode"
  :commit "370c7ffe3a0511e02b071579ddf4fa9ddbf5cef1"
  :revdesc "370c7ffe3a05"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :authors '(("Jeffrey Chu" . "jochu0@gmail.com")
             ("Lennart Staflin" . "lenst@lysator.liu.se")
             ("Phil Hagelberg" . "technomancy@gmail.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev")
             ("Artur Malabarba" . "bruce.connor.am@gmail.com")
             ("Magnar Sveen" . "magnars@gmail.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
