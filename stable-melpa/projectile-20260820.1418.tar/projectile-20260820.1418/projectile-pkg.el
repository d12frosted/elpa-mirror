;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260820.1418"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "d55703534b57d75a7370f46f68763322e3219e61"
  :revdesc "d55703534b57"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
