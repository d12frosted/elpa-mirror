(define-package "magit-libgit" "20220422.1903" "."
  '((emacs "25.1")
    (compat "28.1.0.4")
    (libgit "0")
    (magit "20211004"))
  :commit "713bebef9e7ff2a730282a934463d332147b6816" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
