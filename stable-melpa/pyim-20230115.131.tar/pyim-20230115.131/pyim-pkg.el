(define-package "pyim" "20230115.131" "A Chinese input method support quanpin, shuangpin, wubi, cangjie and rime."
  '((emacs "27.1")
    (async "1.6")
    (xr "1.13"))
  :commit "777f4c6b652063cac877013a0fe81b231b95e8fe" :authors
  '(("Ye Wenbin" . "wenbinye@163.com")
    ("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method")
  :url "https://github.com/tumashu/pyim")
;; Local Variables:
;; no-byte-compile: t
;; End:
