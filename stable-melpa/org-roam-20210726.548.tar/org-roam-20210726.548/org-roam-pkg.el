(define-package "org-roam" "20210726.548" "Roam Research replica with Org-mode"
  '((emacs "26.1")
    (dash "2.13")
    (f "0.17.2")
    (org "9.4")
    (emacsql "3.0.0")
    (emacsql-sqlite "1.0.0")
    (magit-section "2.90.1"))
  :commit "6dc8dda5e59765d3e4629469f4a400b315e92a51" :authors
  '(("Jethro Kuan" . "jethrokuan95@gmail.com"))
  :maintainer
  '("Jethro Kuan" . "jethrokuan95@gmail.com")
  :keywords
  '("org-mode" "roam" "convenience")
  :url "https://github.com/org-roam/org-roam")
;; Local Variables:
;; no-byte-compile: t
;; End:
