(define-package "spdx" "20230801.115" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "1108679041fad34229558ba9b969d2a1cfe189ed" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
