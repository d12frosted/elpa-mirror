;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250616.524"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.3")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "52bfa4b198a7e36cc010a2d8d11d94174d009a90"
  :revdesc "52bfa4b198a7"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
