(define-package "dart-mode" "20230925.2315" "Major mode for editing Dart files"
  '((emacs "27.1"))
  :commit "2c7bebed15af8e2f6e40118e031ba7136f8ced96" :authors
  '(("Natalie Weizenbaum" . "nex342@gmail.com"))
  :maintainers
  '(("Brady Trainor"))
  :maintainer
  '("Brady Trainor")
  :keywords
  '("languages")
  :url "https://github.com/emacsorphanage/dart-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
