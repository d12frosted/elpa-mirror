;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260315.55"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "3553d30f10f5f427fd458a4717278bc0c246b179"
  :revdesc "3553d30f10f5"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
