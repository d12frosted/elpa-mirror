(define-package "netease-cloud-music" "20210815.1439" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "3b6d2623ebfd43cdbe3dcf13e31c254930e85fbf" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
