(define-package "embark" "20210729.1843" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "4f969299a4726058fae8773bd9c4fb7c58371c86" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
