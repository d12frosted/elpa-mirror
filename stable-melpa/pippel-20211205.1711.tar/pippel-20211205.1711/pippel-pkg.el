(define-package "pippel" "20211205.1711" "Frontend to python package manager pip"
  '((emacs "25.1")
    (s "1.11.0")
    (dash "2.12.0"))
  :commit "1e96053ffdcbf64e4c8a0a622feddc3cb0a82ded" :authors
  '(("Fritz Stelzer" . "brotzeitmacher@gmail.com"))
  :maintainer
  '("Arif Er" . "arifer612@protonmail.me")
  :url "https://github.com/arifer612/pippel")
;; Local Variables:
;; no-byte-compile: t
;; End:
