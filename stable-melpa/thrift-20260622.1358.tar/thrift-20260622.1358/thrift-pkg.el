;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260622.1358"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "72ab4f622ea110381e11f8a9981d863e5cbe5735"
  :revdesc "72ab4f622ea1"
  :keywords '("languages"))
