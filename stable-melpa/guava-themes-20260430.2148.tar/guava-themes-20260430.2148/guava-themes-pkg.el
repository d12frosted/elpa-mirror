;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260430.2148"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "d046689855de95a37ce703216da39f6acf9a1f40"
  :revdesc "d046689855de"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
