;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20260107.1343"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "6f8d727ca17098e7e4cf59a5d693b897c50e5223"
  :revdesc "6f8d727ca170"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
