(define-package "constant-theme" "20180921.1012" "A calm, dark, almost monochrome color theme."
  '((emacs "24.1"))
  :commit "0feb9f99d708633d62fa548c953ebbe68fd70de0" :authors
  '(("Jannis Pohlmann" . "contact@jannispohlmann.de"))
  :maintainer
  '("Jannis Pohlmann" . "contact@jannispohlmann.de")
  :keywords
  '("themes")
  :url "https://github.com/jannis/emacs-constant-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
