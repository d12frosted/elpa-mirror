;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260623.919"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "25ad76bd01d6e94b1eada4c19d52a6245a87bbba"
  :revdesc "25ad76bd01d6"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
