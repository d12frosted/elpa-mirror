;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-org" "20261008.1604"
  "Preview Org LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.19.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "b381d878aa7c78ea6339f8dd17258b36b7e29ac1"
  :revdesc "b381d878aa7c"
  :keywords '("tex" "org" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
