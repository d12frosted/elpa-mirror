;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250303.513"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "7cd0724bf26a858d8e5c78742740760bbea65ff9"
  :revdesc "7cd0724bf26a"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
