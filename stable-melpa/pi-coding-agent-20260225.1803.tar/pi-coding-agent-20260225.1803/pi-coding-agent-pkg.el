;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260225.1803"
  "Emacs frontend for pi coding agent."
  '((emacs         "28.1")
    (markdown-mode "2.6")
    (transient     "0.9.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "8608994cd84388363aff5cbb0f99a1ec48ddf4f7"
  :revdesc "8608994cd843"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
