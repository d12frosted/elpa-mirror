(define-package "embark" "20211018.1541" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "c530b09bd89c745a6feee559dd2cbc8ea0df3f77" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
