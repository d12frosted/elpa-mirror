(define-package "build-farm" "20181218.2002" "Interface for Nix and Guix build farms (Hydra and Cuirass)"
  '((emacs "24.4")
    (bui "1.2.1")
    (magit-popup "2.1.0"))
  :commit "5c268a3c235ace0d79ef1ec82c440120317e06f5" :authors
  '(("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  '("Alex Kost" . "alezost@gmail.com")
  :keywords
  '("tools")
  :url "https://gitlab.com/alezost-emacs/build-farm")
;; Local Variables:
;; no-byte-compile: t
;; End:
