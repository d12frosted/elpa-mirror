;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "build-farm" "20181218.2002"
  "Interface for Nix and Guix build farms (Hydra and Cuirass)."
  '((emacs       "24.4")
    (bui         "1.2.1")
    (magit-popup "2.1.0"))
  :url "https://gitlab.com/alezost-emacs/build-farm"
  :commit "5c268a3c235ace0d79ef1ec82c440120317e06f5"
  :revdesc "5c268a3c235a"
  :keywords '("tools")
  :authors '(("Alex Kost" . "alezost@gmail.com"))
  :maintainers '(("Alex Kost" . "alezost@gmail.com")))
