(define-package "dashboard" "20220326.725" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "5703cf163d8f308010d1535955f49d7f05b57bce" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
