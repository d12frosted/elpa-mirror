(define-package "dashboard" "20220326.725" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "5569586bbb5c5cd235b47377cb96f6c5b89bc1f9" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
