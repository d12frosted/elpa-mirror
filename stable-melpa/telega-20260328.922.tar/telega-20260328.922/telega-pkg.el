;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260328.922"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "b58b4376945125ca138cca001c8216708be48ab1"
  :revdesc "b58b43769451"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
