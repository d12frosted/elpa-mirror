;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20261108.1326"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "6017a6d38482b94bd4e77214e407b5fe1a3f178f"
  :revdesc "6017a6d38482"
  :keywords '("hypermedia")
  :authors '(("stardiviner" . "numbchild@gmail.com"))
  :maintainers '(("stardiviner" . "numbchild@gmail.com")))
