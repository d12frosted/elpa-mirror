(define-package "corfu" "20240326.253" "COmpletion in Region FUnction"
  '((emacs "27.1")
    (compat "29.1.4.4"))
  :commit "0fb64f960b9d8b292a91202239e52ab6eed0b12e" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("abbrev" "convenience" "matching" "completion" "text")
  :url "https://github.com/minad/corfu")
;; Local Variables:
;; no-byte-compile: t
;; End:
