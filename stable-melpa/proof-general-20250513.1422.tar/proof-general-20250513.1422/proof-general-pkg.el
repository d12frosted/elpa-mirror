;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20250513.1422"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "2b1fe31698fcf56c3f7b2b1e34090d9dbc55b2b1"
  :revdesc "2b1fe31698fc"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
