(define-package "marginalia" "20210409.2305" "Enrich existing commands with completion annotations"
  '((emacs "26.1"))
  :commit "668265af921285c726b2239dae32459bd1064d03" :authors
  '(("Omar Antolín Camarena, Daniel Mendler"))
  :maintainer
  '("Omar Antolín Camarena, Daniel Mendler")
  :url "https://github.com/minad/marginalia")
;; Local Variables:
;; no-byte-compile: t
;; End:
