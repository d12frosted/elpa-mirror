(define-package "sideline-flycheck" "20240311.238" "Show flycheck errors with sideline"
  '((emacs "27.1")
    (sideline "0.1.1")
    (flycheck "0.14")
    (ht "2.4"))
  :commit "595fcc719e669ddf994bc75e4195f366fbf963bc" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :keywords
  '("convenience" "flycheck")
  :url "https://github.com/emacs-sideline/sideline-flycheck")
;; Local Variables:
;; no-byte-compile: t
;; End:
