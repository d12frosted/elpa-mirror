;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "royal-hemlock-theme" "20260110.903"
  "Soothing royal-blue light-theme."
  '((emacs "24"))
  :url "https://github.com/vs-123/royal-hemlock-theme"
  :commit "50c01627b7132feb6549e9498a41e12a8d53add7"
  :revdesc "50c01627b713"
  :keywords '("color" "theme" "faces"))
