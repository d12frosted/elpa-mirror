;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ext" "20261114.1717"
  "VHDL Extensions."
  '((emacs        "29.1")
    (vhdl-ts-mode "0.4.0")
    (lsp-mode     "8.0.0")
    (rg           "2.3.0")
    (hydra        "0.15.0")
    (flycheck     "32")
    (async        "1.9.7"))
  :url "https://github.com/gmlarumbe/vhdl-ext"
  :commit "99a0b5dbf6bbf07db6f729ba8a64e5cb930a579c"
  :revdesc "99a0b5dbf6bb"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
