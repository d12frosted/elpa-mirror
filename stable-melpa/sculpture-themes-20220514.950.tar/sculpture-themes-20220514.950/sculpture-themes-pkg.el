(define-package "sculpture-themes" "20220514.950" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "339023228c00d66ac9a72b85c2059356736c74ae" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
