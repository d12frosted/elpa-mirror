(define-package "llama-cpp" "20231201.844" "A client for llama-cpp server"
  '((emacs "27.1")
    (dash "2.19.1"))
  :commit "172a91d34128c556460ca033a2325cfa0858ac30" :authors
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainers
  '(("Evgeny Kurnevsky" . "kurnevsky@gmail.com"))
  :maintainer
  '("Evgeny Kurnevsky" . "kurnevsky@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/kurnevsky/llama.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
