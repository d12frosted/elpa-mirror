(define-package "consult" "20211110.2020" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "57dc1adfdc0feafc71c6f418ff7aa1adbe47a5fd" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
