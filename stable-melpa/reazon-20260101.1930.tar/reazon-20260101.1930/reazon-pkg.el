;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reazon" "20260101.1930"
  "MiniKanren for Emacs."
  '((emacs "26"))
  :url "https://github.com/nickdrozd/reazon"
  :commit "377e879202943eba10b812f372d6cb00aa344fe9"
  :revdesc "377e87920294"
  :keywords '("languages" "extensions" "lisp")
  :authors '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainers '(("Nick Drozd" . "nicholasdrozd@gmail.com")))
