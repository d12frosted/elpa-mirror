;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tab-bar-lost-commands" "20211013.1945"
  "The \"lost commands\" of the tab bar."
  '((emacs "27.1"))
  :url "https://github.com/fritzgrabo/tab-bar-lost-commands"
  :commit "989e03dc3d1057264b21b9a5d241fcba86cd297a"
  :revdesc "989e03dc3d10"
  :keywords '("convenience")
  :authors '(("Fritz Grabo" . "hello@fritzgrabo.com"))
  :maintainers '(("Fritz Grabo" . "hello@fritzgrabo.com")))
