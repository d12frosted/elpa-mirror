(define-package "consult" "20230206.2007" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.3.2"))
  :commit "977794acd3baa601e5bfa40e344dd9656455814e" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
