;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "swift-mode" "20260726.751"
  "Major-mode for Apple's Swift programming language."
  '((emacs "25.2"))
  :url "https://github.com/swift-emacs/swift-mode"
  :commit "875fa67d36b196703e1106c35f29095f06b8371e"
  :revdesc "875fa67d36b1"
  :keywords '("languages" "swift")
  :authors '(("taku0" . "mxxouy6x3m_github@tatapa.org")
             ("Chris Barrett" . "chris.d.barrett@me.com")
             ("Bozhidar Batsov" . "bozhidar@batsov.com")
             ("Arthur Evstifeev" . "lod@pisem.net"))
  :maintainers '(("taku0" . "mxxouy6x3m_github@tatapa.org")))
