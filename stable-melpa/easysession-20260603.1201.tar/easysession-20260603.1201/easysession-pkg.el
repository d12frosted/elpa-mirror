;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260603.1201"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "03e4b6a019b7a4c180a9700f08d98451c34611b6"
  :revdesc "03e4b6a019b7"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
