(define-package "firrtl-mode" "20230815.1312" "mode for working with FIRRTL files"
  '((emacs "24.3"))
  :commit "45ec466d2945c2893ca4d6b24ff3816fceb8f1b2" :authors
  '(("Schuyler Eldridge" . "schuyler.eldridge@ibm.com"))
  :maintainers
  '(("Schuyler Eldridge" . "schuyler.eldridge@ibm.com"))
  :maintainer
  '("Schuyler Eldridge" . "schuyler.eldridge@ibm.com")
  :keywords
  '("languages" "firrtl")
  :url "https://github.com/ibm/firrtl-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
