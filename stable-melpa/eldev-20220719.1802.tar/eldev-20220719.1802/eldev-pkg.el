(define-package "eldev" "20220719.1802" "Elisp development tool"
  '((emacs "24.4"))
  :commit "3703fbcae613cf4451b4cc72cf74105c3a30d20a" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
