(define-package "consult" "20210602.1920" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "4c8f7f048198f9e3dd282262ed44b311be36d581" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
