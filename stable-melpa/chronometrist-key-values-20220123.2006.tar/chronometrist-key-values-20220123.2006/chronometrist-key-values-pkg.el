(define-package "chronometrist-key-values" "20220123.2006" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "2b57dc480786f13347af5ece607272f40a7532a8" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
