(define-package "chronometrist-key-values" "20220123.2006" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "5629b06f33ba0bebb69fa208ae0d07ee32c5da6d" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
