;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20250602.1355"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.1")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "338ef1a98b54d5c84e9f7202b1ffb66bb18e9e95"
  :revdesc "338ef1a98b54"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
