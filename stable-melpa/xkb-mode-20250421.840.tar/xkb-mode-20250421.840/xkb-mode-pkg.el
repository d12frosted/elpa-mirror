;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "xkb-mode" "20250421.840"
  "Major mode for editing X Keyboard Extension (XKB) files."
  '((emacs "25.1"))
  :url "https://github.com/captainflasmr/xkb-mode"
  :commit "0e317a08dd665bfa8d1bbfbe23c7ca3ae0975519"
  :revdesc "0e317a08dd66"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
