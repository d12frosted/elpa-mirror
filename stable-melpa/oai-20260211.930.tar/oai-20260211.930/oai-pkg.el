;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260211.930"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "2316482fd52ed9ea040c30a5715375a1da41c2a6"
  :revdesc "2316482fd52e"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
