;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgit-file" "20251222.1309"
  "Support for links to files in Git repositories."
  '((emacs  "29.1")
    (compat "30.1")
    (magit  "4.3")
    (org    "9.7")
    (orgit  "2.0"))
  :url "https://github.com/gggion/orgit-file"
  :commit "08f7a16f3cc3d6a85ad4cad89d4c31b3b1c9346d"
  :revdesc "08f7a16f3cc3"
  :keywords '("hypermedia" "vc"))
