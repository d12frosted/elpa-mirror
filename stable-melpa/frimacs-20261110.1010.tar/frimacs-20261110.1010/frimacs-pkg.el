;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "frimacs" "20261110.1010"
  "An environment for the FriCAS computer algebra system."
  '((emacs "26.1"))
  :url "https://github.com/pdo/frimacs"
  :commit "f2b0db7b1276b6c563c4908a3e0393b6152e6b95"
  :revdesc "f2b0db7b1276"
  :keywords '("fricas" "computer algebra" "extensions" "tools")
  :authors '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainers '(("Paul Onions" . "paul.onions@acm.org")))
