(define-package "modus-themes" "20220223.541" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "57165f269f044f5148014cf35be54334bc7e4fbc" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
