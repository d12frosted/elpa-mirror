(define-package "jinx" "20240926.926" "Enchanted Spell Checker"
  '((emacs "28.1")
    (compat "30"))
  :commit "1bced63771de9f00ffe43377955cf2cefad48b50" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("convenience" "text")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
