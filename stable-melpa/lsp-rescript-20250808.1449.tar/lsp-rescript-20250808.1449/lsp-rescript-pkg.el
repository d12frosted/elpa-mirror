;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-rescript" "20250808.1449"
  "LSP client configuration for lsp-mode and rescript-vscode."
  '((lsp-mode      "7.0.1")
    (emacs         "25.1")
    (rescript-mode "0.1"))
  :url "https://github.com/jjlee/lsp-rescript"
  :commit "3c13e3ffe2ece7b08f49c72e8a6e6156041f4c8b"
  :revdesc "3c13e3ffe2ec"
  :keywords '("languages"))
