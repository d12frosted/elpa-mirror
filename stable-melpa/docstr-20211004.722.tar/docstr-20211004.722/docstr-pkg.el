(define-package "docstr" "20211004.722" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "aa2e30dc6b1d3fa6fb1da309fb87df683eab1e62" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
