;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260207.657"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "a41347757ff52fcc20356cfc8077f08522793fb3"
  :revdesc "a41347757ff5"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
