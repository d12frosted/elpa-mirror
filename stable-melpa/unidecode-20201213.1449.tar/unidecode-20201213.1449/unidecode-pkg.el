(define-package "unidecode" "20201213.1449" "Transliterate Unicode to ASCII" 'nil :commit "525b51b38f5b0435642005957740fe22ecb2a53c" :authors
  (("sindikat <sindikat at mail36 dot net>"))
  :maintainer
  ("John Mastro" . "john.b.mastro@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
