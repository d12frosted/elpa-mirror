(define-package "caser" "20230828.402" "Change text casing from camelCase to dash-case to snake_case"
  '((emacs "29.1"))
  :commit "3d55de4dd2e4be5f2641a4c2388e8ea84c9d5b14" :url "https://hg.sr.ht/~zck/caser.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
