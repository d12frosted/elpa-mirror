(define-package "test-cockpit" "20231027.1842" "A command center to run tests of a software project"
  '((emacs "28.1")
    (projectile "2.7")
    (toml "20230411.1449"))
  :commit "911e42d1b71e844b9821a4561154734adaa0f1e0" :authors
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainer
  '("Johannes Mueller" . "github@johannes-mueller.org")
  :url "https://github.com/johannes-mueller/test-cockpit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
