;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251231.450"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "4b1f03e79c09f2e669cd0f7a2fd4d88022ebc8f2"
  :revdesc "4b1f03e79c09"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
