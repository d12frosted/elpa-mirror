(define-package "dirvish" "20220310.1206" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "9a2849471bba98a56791f070d797d853efb36644" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
