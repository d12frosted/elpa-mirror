;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "forge" "20250115.1118"
  "Access Git forges from Magit."
  '((emacs         "29.1")
    (compat        "30.0.1.0")
    (closql        "2.1.0")
    (dash          "2.19.1")
    (emacsql       "4.1.0")
    (ghub          "4.2.1-git")
    (let-alist     "1.0.6")
    (magit         "4.2.1-git")
    (markdown-mode "2.6")
    (seq           "2.24")
    (transient     "0.8.2")
    (yaml          "0.5.5"))
  :url "https://github.com/magit/forge"
  :commit "5fbe818e4ab9b7f086f0680cb707dff6ef564b0a"
  :revdesc "5fbe818e4ab9"
  :keywords '("git" "tools" "vc")
  :authors '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.forge@jonas.bernoulli.dev")))
