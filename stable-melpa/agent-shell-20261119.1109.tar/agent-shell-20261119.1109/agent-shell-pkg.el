;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261119.1109"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.3")
    (acp         "0.19.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "64d9dde314f9baf88d025ba7792d5873c88f3209"
  :revdesc "64d9dde314f9")
