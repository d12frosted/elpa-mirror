;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260114.454"
  "Spaced Repetition System."
  '((emacs      "27.2")
    (emacsql    "4.1.0")
    (compat     "29.1.4.2")
    (transient  "0.7.2")
    (org-gnosis "0.0.9"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "6bd8f4e5a84387b51df961db9703e9801f3610f7"
  :revdesc "6bd8f4e5a843"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
