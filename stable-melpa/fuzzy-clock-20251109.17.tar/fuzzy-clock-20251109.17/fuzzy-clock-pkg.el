;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fuzzy-clock" "20251109.17"
  "Display time in a human-friendly, approximate way."
  '((emacs "26.1"))
  :url "https://github.com/trevoke/fuzzy-clock.el"
  :commit "6b1a33296d856aeee0b29cdf65a9e614054ef94a"
  :revdesc "6b1a33296d85"
  :keywords '("calendar" "time"))
