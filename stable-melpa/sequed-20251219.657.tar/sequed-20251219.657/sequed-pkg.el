;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sequed" "20251219.657"
  "Major mode for FASTA format DNA alignments."
  '((emacs "25.2"))
  :url "https://github.com/brannala/sequed"
  :commit "3a8692268967b55a8c1f712f58ce988914a9375d"
  :revdesc "3a8692268967"
  :authors '(("Bruce Rannala" . "brannala@ucdavis.edu"))
  :maintainers '(("Bruce Rannala" . "brannala@ucdavis.edu")))
