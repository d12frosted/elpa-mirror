(define-package "chee" "20171123.2233" "Interface to chee using dired and image-dired"
  '((dash "2.12.1")
    (s "1.10.0")
    (f "0.18.2"))
  :commit "669ff9ee429f24c3c2d03b83d9cb9aec5f86bb8b" :url "https://github.com/eikek/chee/tree/release/0.3.0/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
