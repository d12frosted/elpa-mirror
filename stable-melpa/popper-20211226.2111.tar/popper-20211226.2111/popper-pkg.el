(define-package "popper" "20211226.2111" "Summon and dismiss buffers as popups"
  '((emacs "26.1"))
  :commit "8af5e6b3bb08a71abbafba2491e3ab001a13a067" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/popper")
;; Local Variables:
;; no-byte-compile: t
;; End:
