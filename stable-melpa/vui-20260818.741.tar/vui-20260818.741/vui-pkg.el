;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20260818.741"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "19f2959c0be9ef76d17bf5d6e2b86ccee4be62bf"
  :revdesc "19f2959c0be9"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
