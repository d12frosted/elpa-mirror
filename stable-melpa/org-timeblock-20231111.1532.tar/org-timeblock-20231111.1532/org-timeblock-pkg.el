(define-package "org-timeblock" "20231111.1532" "Interactive SVG calendar for orgmode tasks"
  '((emacs "28.1")
    (compat "29.1")
    (org-ql "0.7")
    (org "9.0")
    (svg "1.1")
    (persist "0.5"))
  :commit "f840da6c6722cecc16e8d24a0c500be89f830fd4" :authors
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainers
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainer
  '("Ilya Chernyshov" . "ichernyshovvv@gmail.com")
  :keywords
  '("org" "calendar" "timeblocking" "agenda")
  :url "https://github.com/ichernyshovvv/org-timeblock")
;; Local Variables:
;; no-byte-compile: t
;; End:
