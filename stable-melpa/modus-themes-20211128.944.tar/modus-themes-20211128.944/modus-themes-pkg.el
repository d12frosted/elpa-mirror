(define-package "modus-themes" "20211128.944" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "0e31ed4945981bca50a4b39ff271d13a0ea4f789" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
