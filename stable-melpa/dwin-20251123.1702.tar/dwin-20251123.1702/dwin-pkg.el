;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwin" "20251123.1702"
  "Navigate and arrange desktop windows."
  '((emacs "30.2"))
  :url "https://github.com/lsth/dwin"
  :commit "90e9a6c14eee33782c389596d2b940981e2a714f"
  :revdesc "90e9a6c14eee"
  :keywords '("frames" "processes" "convenience")
  :authors '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de"))
  :maintainers '(("Lars Schmidt-Thieme" . "schmidt-thieme@ismll.de")))
