;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg-agent" "20260707.412"
  "Agent tools for ekg."
  '((ekg   "20260305")
    (futur "1.2"))
  :url "https://github.com/ahyatt/ekg"
  :commit "f1401f4189143dcfce5cd7d68231462d7a8873ec"
  :revdesc "f1401f418914"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
