(define-package "multi-web-mode" "20100110.2208" "multiple major mode support for web editing" 'nil :commit "0517b9e2b3052533ac0cb71eba7073ed309fce06" :authors
  '(("Fabián Ezequiel Gallina" . "fabian@gnu.org.ar"))
  :maintainer
  '("Fabián Ezequiel Gallina" . "fabian@gnu.org.ar")
  :keywords
  '("convenience" "languages" "wp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
