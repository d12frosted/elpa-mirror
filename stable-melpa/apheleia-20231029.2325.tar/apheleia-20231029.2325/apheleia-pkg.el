(define-package "apheleia" "20231029.2325" "Reformat buffer stably"
  '((emacs "27"))
  :commit "4178439d438c923f1baccebb63e1edfb00a257a1" :authors
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainers
  '(("Radian LLC" . "contact+apheleia@radian.codes"))
  :maintainer
  '("Radian LLC" . "contact+apheleia@radian.codes")
  :keywords
  '("tools")
  :url "https://github.com/radian-software/apheleia")
;; Local Variables:
;; no-byte-compile: t
;; End:
