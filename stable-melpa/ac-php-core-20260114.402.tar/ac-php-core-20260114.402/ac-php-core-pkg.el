;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ac-php-core" "20260114.402"
  "The core library of the ac-php."
  '((emacs    "24.4")
    (dash     "1")
    (php-mode "1")
    (s        "1")
    (f        "0.17.0")
    (popup    "0.5.0")
    (xcscope  "1.0"))
  :url "https://github.com/xcwen/ac-php"
  :commit "e138e48318f0a39352ee76e0568fcd8786ce68a2"
  :revdesc "e138e48318f0"
  :keywords '("completion" "convenience" "intellisense")
  :authors '(("jim" . "xcwenn@qq.com")
             ("Serghei Iakovlev" . "sadhooklay@gmail.com")))
