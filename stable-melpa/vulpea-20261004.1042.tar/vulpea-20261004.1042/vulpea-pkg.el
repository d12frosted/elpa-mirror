;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261004.1042"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "5907f46de3b1c07e3008370000060c87c42c5c86"
  :revdesc "5907f46de3b1"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
