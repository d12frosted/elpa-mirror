;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260716.2230"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "86fc67b66ad65b3e534e898cb14a34675dc34386"
  :revdesc "86fc67b66ad6"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
