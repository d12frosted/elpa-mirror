(define-package "binky" "20231023.2145" "Jump between points like a rabbit"
  '((emacs "26.3"))
  :commit "bf9bd87c44cd5ca5ede0f080fa510240d948a644" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/liuyinz/binky-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
