(define-package "spdx" "20221215.116" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "39f095a731ba5552ce4593112294642f64f2a7ec" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
