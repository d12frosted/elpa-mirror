(define-package "asm-blox" "20220921.28" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.5.1"))
  :commit "b9008a3b2df97501d9a5aedcc5666bd292fbc5d6" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
