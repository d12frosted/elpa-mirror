;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "once" "20260217.2157"
  "Add-hook and eval-after-load, but only once."
  '((emacs "26.1"))
  :url "https://github.com/meedstrom/once"
  :commit "ca7a4ffb70108ae86c2f0d8585299c2b8f58b1de"
  :revdesc "ca7a4ffb7010"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
