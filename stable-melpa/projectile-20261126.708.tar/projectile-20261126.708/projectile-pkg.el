;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20261126.708"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "bd728f32948f428471626f44b680ac1c6a0e0381"
  :revdesc "bd728f32948f"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
