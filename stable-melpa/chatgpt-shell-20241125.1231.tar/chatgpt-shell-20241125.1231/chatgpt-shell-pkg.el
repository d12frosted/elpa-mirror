;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241125.1231"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.70.2"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "54e59be17494c7228e0f3b166fff13e3220833c7"
  :revdesc "54e59be17494")
