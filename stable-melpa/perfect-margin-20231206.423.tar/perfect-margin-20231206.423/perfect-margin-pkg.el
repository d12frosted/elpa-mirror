(define-package "perfect-margin" "20231206.423" "Auto center windows, works with line numbers"
  '((emacs "24.3"))
  :commit "5a26d898e25a22bdcdc84e877045afcde199ac19" :authors
  '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainers
  '(("Randall Wang" . "randall.wjz@gmail.com"))
  :maintainer
  '("Randall Wang" . "randall.wjz@gmail.com")
  :keywords
  '("convenience" "frames")
  :url "https://github.com/mpwang/perfect-margin")
;; Local Variables:
;; no-byte-compile: t
;; End:
