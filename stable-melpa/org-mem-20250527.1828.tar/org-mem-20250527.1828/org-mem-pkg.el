;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250527.1828"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "75a0f97bfb78db659e9b90eb602a43d2c59cb5e7"
  :revdesc "75a0f97bfb78"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
