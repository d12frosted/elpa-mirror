(define-package "cnfonts" "20211109.740" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "20e6686c69a32dfcb1a53a936f283a8c1967c9b3" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
