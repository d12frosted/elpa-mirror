;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260221.2049"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "3db68b3081740c29e38eb32fcf2d44919d236753"
  :revdesc "3db68b308174"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
