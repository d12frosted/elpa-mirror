;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20261019.855"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.15.1"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "bacdd7737a17c9cb6cc1e61ab52246667a42b1d4"
  :revdesc "bacdd7737a17"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
