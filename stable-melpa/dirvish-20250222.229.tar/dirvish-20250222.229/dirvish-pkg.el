;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dirvish" "20250222.229"
  "A modern file manager based on dired mode."
  '((emacs "28.1"))
  :url "https://github.com/alexluigit/dirvish"
  :commit "b74f0d337da4077d9b9fdd4d189a78948ea08d52"
  :revdesc "b74f0d337da4"
  :keywords '("files" "convenience")
  :authors '(("Alex Lu" . "https://github.com/alexluigit"))
  :maintainers '(("Alex Lu" . "https://github.com/alexluigit")))
