(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c0d4270b789f17032e5f4849f63f1d13df89f17a")
;; Local Variables:
;; no-byte-compile: t
;; End:
