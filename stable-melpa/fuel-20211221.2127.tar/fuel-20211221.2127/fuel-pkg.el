(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "42399d9551a6b4599876ee021c031b7dafc06e9c")
;; Local Variables:
;; no-byte-compile: t
;; End:
