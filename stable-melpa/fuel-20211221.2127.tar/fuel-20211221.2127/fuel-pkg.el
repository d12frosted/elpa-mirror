(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "16a62262272cdf420c27e3febe9bfb0bc3fbc932")
;; Local Variables:
;; no-byte-compile: t
;; End:
