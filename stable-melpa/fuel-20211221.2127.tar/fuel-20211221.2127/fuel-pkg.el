(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d6114e824fe0cf4e0c9ce435de3cfc1119c60229")
;; Local Variables:
;; no-byte-compile: t
;; End:
