(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "0d57b1b43bcfbd6498745ec78be836c45233c6a0")
;; Local Variables:
;; no-byte-compile: t
;; End:
