(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a46b0230d6842fa81ddfb63a2cae219c4ccb5c4b")
;; Local Variables:
;; no-byte-compile: t
;; End:
