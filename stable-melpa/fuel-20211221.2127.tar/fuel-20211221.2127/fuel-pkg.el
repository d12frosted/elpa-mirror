(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a3b7332a1ba118ab913ac117ab06fde5fed2ab97")
;; Local Variables:
;; no-byte-compile: t
;; End:
