(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b0badd157101d4b6b184f06726b456a00171b801")
;; Local Variables:
;; no-byte-compile: t
;; End:
