(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "92d78b897d976b4f70e019050e24b5c1ea0f9384")
;; Local Variables:
;; no-byte-compile: t
;; End:
