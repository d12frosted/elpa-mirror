(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3b8e0baa0f570485eda2b150ff0bb2f2c1a9ade2")
;; Local Variables:
;; no-byte-compile: t
;; End:
