(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f93602c02915dc97014f77ffbdef778376002996")
;; Local Variables:
;; no-byte-compile: t
;; End:
