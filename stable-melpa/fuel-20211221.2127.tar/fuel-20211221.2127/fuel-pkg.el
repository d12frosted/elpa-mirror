(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f30adb4a76188f46accf8adc082c99cc2654f3c8")
;; Local Variables:
;; no-byte-compile: t
;; End:
