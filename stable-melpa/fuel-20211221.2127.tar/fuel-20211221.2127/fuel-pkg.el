(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "96a9d806838b4676488cd926924abbcc00fd0870")
;; Local Variables:
;; no-byte-compile: t
;; End:
