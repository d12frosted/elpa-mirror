(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5716fde9dd0aa8531894938a9930b07ce96dfa66")
;; Local Variables:
;; no-byte-compile: t
;; End:
