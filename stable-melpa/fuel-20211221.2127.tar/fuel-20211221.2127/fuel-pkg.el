(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a7b3eec47a3276f5b9081e47d9ba5fa443f14037")
;; Local Variables:
;; no-byte-compile: t
;; End:
