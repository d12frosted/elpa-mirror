(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "efb078d3b14a0ba8cc911c4f227ea8c946d297a8")
;; Local Variables:
;; no-byte-compile: t
;; End:
