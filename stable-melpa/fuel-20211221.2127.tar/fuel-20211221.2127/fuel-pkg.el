(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4ae756ca3c3ca7a928c18f828cb4dbff16e361e0")
;; Local Variables:
;; no-byte-compile: t
;; End:
