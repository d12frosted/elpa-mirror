(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "eb3d24973a5d9d5f88812f540fb8a3697889fe83")
;; Local Variables:
;; no-byte-compile: t
;; End:
