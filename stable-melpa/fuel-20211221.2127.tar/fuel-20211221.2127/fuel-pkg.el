(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "fb5a0b8559758dc402fd9e843f695876c898c211")
;; Local Variables:
;; no-byte-compile: t
;; End:
