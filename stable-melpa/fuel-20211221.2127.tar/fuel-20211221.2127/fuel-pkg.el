(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a43fe81d3fbe2ebb78f1ba0639a23665f297701b")
;; Local Variables:
;; no-byte-compile: t
;; End:
