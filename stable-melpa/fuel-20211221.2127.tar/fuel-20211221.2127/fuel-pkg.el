(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "760947bd331693e90dabd75f8e7b995210fb961b")
;; Local Variables:
;; no-byte-compile: t
;; End:
