(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "bac5f95f367631bb14e3fd530c9a53045095f625")
;; Local Variables:
;; no-byte-compile: t
;; End:
