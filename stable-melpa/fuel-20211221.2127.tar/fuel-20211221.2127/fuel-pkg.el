(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "41e6cd2f35379805e6f3a8b85926db74d75bb3c6")
;; Local Variables:
;; no-byte-compile: t
;; End:
