(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "0712454c140b5a98eb4ebc4bf21a29fb2157c3b5")
;; Local Variables:
;; no-byte-compile: t
;; End:
