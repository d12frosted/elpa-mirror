(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5eb57c5e08f31278dc07e2f98d25c69afbe0c653")
;; Local Variables:
;; no-byte-compile: t
;; End:
