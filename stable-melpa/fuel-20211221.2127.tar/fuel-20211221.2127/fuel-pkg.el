(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "10da22ab30080f7136d18ec2f526588b753ad035")
;; Local Variables:
;; no-byte-compile: t
;; End:
