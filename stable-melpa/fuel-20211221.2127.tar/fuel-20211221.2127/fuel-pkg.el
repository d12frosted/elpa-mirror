(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "0d878f6a0817e3a5a8ebcc6b98a58a8c3baafc47")
;; Local Variables:
;; no-byte-compile: t
;; End:
