(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d7382e5bae71ed29998da9af9418f18d31e581ed")
;; Local Variables:
;; no-byte-compile: t
;; End:
