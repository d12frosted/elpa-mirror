(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "db7911c017c95e3aa8e2d967d3f86eda803db23c")
;; Local Variables:
;; no-byte-compile: t
;; End:
