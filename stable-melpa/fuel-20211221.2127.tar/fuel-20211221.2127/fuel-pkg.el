(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "7899e1e2906c00fe86da3f5f823608ecf3b25fd3")
;; Local Variables:
;; no-byte-compile: t
;; End:
