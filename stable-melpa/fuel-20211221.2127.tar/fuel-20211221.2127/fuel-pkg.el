(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ba2f27902f8eed848bac927d471915efc4e3e013")
;; Local Variables:
;; no-byte-compile: t
;; End:
