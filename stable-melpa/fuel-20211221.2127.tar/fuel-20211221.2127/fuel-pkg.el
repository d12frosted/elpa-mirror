(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "60005b6cfda0ae7d5c21e5a59f6edc90bd9707cc")
;; Local Variables:
;; no-byte-compile: t
;; End:
