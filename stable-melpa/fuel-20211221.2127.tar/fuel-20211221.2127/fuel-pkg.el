(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f8dd0a982eb634af8564b7691c77ba63f1a1d846")
;; Local Variables:
;; no-byte-compile: t
;; End:
