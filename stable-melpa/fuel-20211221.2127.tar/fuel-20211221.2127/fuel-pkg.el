(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "85a3beddd29c8f752d0b5dbbf2bec3b0afb51a10")
;; Local Variables:
;; no-byte-compile: t
;; End:
