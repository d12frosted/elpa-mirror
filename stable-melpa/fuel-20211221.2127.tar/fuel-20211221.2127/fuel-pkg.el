(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "0388586f2f22c40f6efb19d17f37382b02e4e8e7")
;; Local Variables:
;; no-byte-compile: t
;; End:
