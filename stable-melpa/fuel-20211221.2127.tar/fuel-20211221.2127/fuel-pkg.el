(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "df96aba69203125821f1212f49e9e20c7af498ba")
;; Local Variables:
;; no-byte-compile: t
;; End:
