(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "0ba4855913ea0143f3c94528ce8663f404745c4a")
;; Local Variables:
;; no-byte-compile: t
;; End:
