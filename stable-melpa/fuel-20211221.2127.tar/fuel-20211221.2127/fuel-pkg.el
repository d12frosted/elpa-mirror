(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "084795312f1bbeebb8a054fcd15faf5fbacc1fa0")
;; Local Variables:
;; no-byte-compile: t
;; End:
