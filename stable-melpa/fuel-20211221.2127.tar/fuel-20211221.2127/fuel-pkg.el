(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "789a049a92bb85ba60ccb92e45ad9d5f8a17d44b")
;; Local Variables:
;; no-byte-compile: t
;; End:
