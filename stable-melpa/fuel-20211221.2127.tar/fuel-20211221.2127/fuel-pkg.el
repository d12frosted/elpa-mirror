(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "cd4acad53fb730af0722345ef3a02236ccbf80f4")
;; Local Variables:
;; no-byte-compile: t
;; End:
