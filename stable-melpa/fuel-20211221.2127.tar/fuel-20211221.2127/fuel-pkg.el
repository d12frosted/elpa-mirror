(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "d023a4b7e24fe44741b8509f0c83ac9ed59b877d")
;; Local Variables:
;; no-byte-compile: t
;; End:
