(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "e54a39412baabbae4ead588a392edbe8d5bf7359")
;; Local Variables:
;; no-byte-compile: t
;; End:
