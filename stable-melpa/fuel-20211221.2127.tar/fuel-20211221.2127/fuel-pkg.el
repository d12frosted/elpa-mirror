(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "cc8bf9627c2f0506a4fb449556c14ccf34684692")
;; Local Variables:
;; no-byte-compile: t
;; End:
