(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4899a375aec36b49c2ba2f45a80fb5d2386c58bc")
;; Local Variables:
;; no-byte-compile: t
;; End:
