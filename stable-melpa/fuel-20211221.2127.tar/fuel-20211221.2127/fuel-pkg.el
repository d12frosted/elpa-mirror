(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c83ae69a702ae503fe6663b6333a55d1598bbf08")
;; Local Variables:
;; no-byte-compile: t
;; End:
