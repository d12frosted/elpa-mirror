(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5da49e06f38a8266d4b636114bde5f23e95144f4")
;; Local Variables:
;; no-byte-compile: t
;; End:
