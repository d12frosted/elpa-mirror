(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "96743eeca46176ece358e59b329a593bc718525e")
;; Local Variables:
;; no-byte-compile: t
;; End:
