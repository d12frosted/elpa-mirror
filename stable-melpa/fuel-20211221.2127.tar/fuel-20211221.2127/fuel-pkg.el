(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "b5c6d2febe7fd278595c0d49965f244a191a9421")
;; Local Variables:
;; no-byte-compile: t
;; End:
