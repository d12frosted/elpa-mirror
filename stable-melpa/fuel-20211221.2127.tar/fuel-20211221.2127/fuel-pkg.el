(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "cda1e5f9ad1d6b55077b7a88f18e89e882e8ffef")
;; Local Variables:
;; no-byte-compile: t
;; End:
