(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f6aa9632def8281cd7ec874ad7372d4e01456432")
;; Local Variables:
;; no-byte-compile: t
;; End:
