(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3ceb6f10519491dbfc1d44177010b1bc18afc159")
;; Local Variables:
;; no-byte-compile: t
;; End:
