(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "cbf80d7c48cb5d4f528b2aca2ce71dd9a3de1b12")
;; Local Variables:
;; no-byte-compile: t
;; End:
