(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a159b56c765842f3064b9c409e2d8155ba09638a")
;; Local Variables:
;; no-byte-compile: t
;; End:
