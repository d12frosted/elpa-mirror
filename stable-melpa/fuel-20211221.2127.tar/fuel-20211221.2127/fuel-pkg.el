(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "7fb44f5702726b843ae82b1c7507306ef60667f9")
;; Local Variables:
;; no-byte-compile: t
;; End:
