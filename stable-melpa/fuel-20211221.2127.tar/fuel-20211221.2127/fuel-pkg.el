(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "7af857659fff7cdb98ffa94d012cf39014a57433")
;; Local Variables:
;; no-byte-compile: t
;; End:
