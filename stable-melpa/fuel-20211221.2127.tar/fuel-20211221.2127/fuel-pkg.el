(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "bf478a2bd37616b582b39d4e11c18269b91e753c")
;; Local Variables:
;; no-byte-compile: t
;; End:
