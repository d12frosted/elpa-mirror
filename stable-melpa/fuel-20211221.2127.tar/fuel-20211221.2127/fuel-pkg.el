(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "47349716241792b8e4f2965b9896d5284a879de3")
;; Local Variables:
;; no-byte-compile: t
;; End:
