(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "e1f7c71f636bec5b899a0e7712afde9291b9e587")
;; Local Variables:
;; no-byte-compile: t
;; End:
