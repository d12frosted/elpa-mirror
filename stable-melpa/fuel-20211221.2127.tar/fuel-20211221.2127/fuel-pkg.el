(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "287587048730ab0e33c8682d381967e785fff74d")
;; Local Variables:
;; no-byte-compile: t
;; End:
