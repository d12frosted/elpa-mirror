(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f9bec769243203e0226fc2a5fefb734e977c3f00")
;; Local Variables:
;; no-byte-compile: t
;; End:
