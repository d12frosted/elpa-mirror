(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1ffe99dc574b9ff389dce59e825b02f020a72da1")
;; Local Variables:
;; no-byte-compile: t
;; End:
