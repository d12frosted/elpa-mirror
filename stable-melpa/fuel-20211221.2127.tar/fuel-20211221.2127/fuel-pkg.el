(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "31ce1f5ab2cf9d91a9963107f82654ccedf83193")
;; Local Variables:
;; no-byte-compile: t
;; End:
