(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "6900d1eab9750001e8525f3990ed6fa4a73a8c44")
;; Local Variables:
;; no-byte-compile: t
;; End:
