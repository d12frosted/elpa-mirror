(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9b2d1f965abdbbb422d8407e60586866bdd9f743")
;; Local Variables:
;; no-byte-compile: t
;; End:
