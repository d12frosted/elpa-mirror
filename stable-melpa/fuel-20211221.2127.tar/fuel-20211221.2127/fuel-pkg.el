(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "744a1b550faf804d69b2b8d3ac3c448532082f2c")
;; Local Variables:
;; no-byte-compile: t
;; End:
