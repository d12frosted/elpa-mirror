(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "5f41d794fbd66744bb6779bb5b1bbcd3799e298f")
;; Local Variables:
;; no-byte-compile: t
;; End:
