(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9113d1dd41c77719183f148d6c3898042a2d18ec")
;; Local Variables:
;; no-byte-compile: t
;; End:
