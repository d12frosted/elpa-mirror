(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c626199cd8cae10ce4f5d0bd184d56b4f9b90ecb")
;; Local Variables:
;; no-byte-compile: t
;; End:
