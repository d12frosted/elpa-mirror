(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2f59f72ed58809c266ad1d2a777be7285d246a06")
;; Local Variables:
;; no-byte-compile: t
;; End:
