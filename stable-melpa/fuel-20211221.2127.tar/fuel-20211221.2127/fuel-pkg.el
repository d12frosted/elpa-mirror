(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3fb0924a159cd31a741479c52d85fd402c20d25a")
;; Local Variables:
;; no-byte-compile: t
;; End:
