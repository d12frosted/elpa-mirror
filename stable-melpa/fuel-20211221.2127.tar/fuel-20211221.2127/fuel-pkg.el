(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "32aee51c6f67a1e8550bb4c4eaa978cd5c49ae62")
;; Local Variables:
;; no-byte-compile: t
;; End:
