(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "51f3efab06fca2197440667ad789bb53e5e5398c")
;; Local Variables:
;; no-byte-compile: t
;; End:
