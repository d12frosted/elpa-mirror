(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "baa7f3b31f3686dd30a70a3a32566c3097068e5d")
;; Local Variables:
;; no-byte-compile: t
;; End:
