(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "844060a7d003ae6921f113aceadae67209275455")
;; Local Variables:
;; no-byte-compile: t
;; End:
