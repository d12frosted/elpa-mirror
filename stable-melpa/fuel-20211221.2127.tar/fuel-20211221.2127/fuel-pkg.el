(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a827b197c5896fab1bf8101e68e1e741cb7a410d")
;; Local Variables:
;; no-byte-compile: t
;; End:
