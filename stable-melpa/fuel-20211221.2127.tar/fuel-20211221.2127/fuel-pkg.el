(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "0d0e32ffea19edc685b5b71f8f58166e91dda8e9")
;; Local Variables:
;; no-byte-compile: t
;; End:
