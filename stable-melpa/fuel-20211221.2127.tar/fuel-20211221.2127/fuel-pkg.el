(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "458848d43c085d649c58f0fbb399c4b6608f892f")
;; Local Variables:
;; no-byte-compile: t
;; End:
