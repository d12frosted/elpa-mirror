(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f38848dbd6dc9505ee60ecdecb50d4f6933572d9")
;; Local Variables:
;; no-byte-compile: t
;; End:
