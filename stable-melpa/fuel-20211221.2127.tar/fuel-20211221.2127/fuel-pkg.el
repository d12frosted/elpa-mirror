(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "f88622fab7dd04c17233ddf390e05e3fc8a0ae81")
;; Local Variables:
;; no-byte-compile: t
;; End:
