(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c03f79c73718c20ee2ab995bf67a51867a80ceb3")
;; Local Variables:
;; no-byte-compile: t
;; End:
