(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "305e141650f73ae9c4583aeead8f1b370493e9ad")
;; Local Variables:
;; no-byte-compile: t
;; End:
