(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "54b8eefe97a54cd2e8d85e8c0a275c06d577ee67")
;; Local Variables:
;; no-byte-compile: t
;; End:
