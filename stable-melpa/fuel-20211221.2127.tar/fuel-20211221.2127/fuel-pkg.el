(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "ea50ea61d5bb383e8e446e6526ad0af50a4a0b7b")
;; Local Variables:
;; no-byte-compile: t
;; End:
