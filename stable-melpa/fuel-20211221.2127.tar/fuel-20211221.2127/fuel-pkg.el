(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "06187d8fb97868657693b5121d3faf7f2f200aba")
;; Local Variables:
;; no-byte-compile: t
;; End:
