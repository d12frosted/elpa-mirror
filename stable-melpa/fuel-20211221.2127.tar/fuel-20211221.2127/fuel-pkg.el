(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "7395a8aaa8944138310b8f00f23a7f390e33c2b4")
;; Local Variables:
;; no-byte-compile: t
;; End:
