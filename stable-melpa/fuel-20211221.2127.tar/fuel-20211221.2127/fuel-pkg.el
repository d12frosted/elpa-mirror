(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "a2fa8f124a6f124bc4cbdb49c9dae3657b0424c8")
;; Local Variables:
;; no-byte-compile: t
;; End:
