(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9315bf383d79c37094e414f72cf51fbcf9e9e6b8")
;; Local Variables:
;; no-byte-compile: t
;; End:
