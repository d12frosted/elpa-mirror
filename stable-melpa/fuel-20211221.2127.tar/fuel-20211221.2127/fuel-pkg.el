(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "3032408bd3b521d761eea9f0e4e89640d5485129")
;; Local Variables:
;; no-byte-compile: t
;; End:
