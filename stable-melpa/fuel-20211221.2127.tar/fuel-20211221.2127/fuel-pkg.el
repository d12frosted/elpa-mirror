(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "8ac952134e273854594feb4c6166156ef55ca706")
;; Local Variables:
;; no-byte-compile: t
;; End:
