(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "9dc8dd9bcc3a1ffd0ab7a6ebba0b4ae7f5605eae")
;; Local Variables:
;; no-byte-compile: t
;; End:
