(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "10bbbc11672dbf88b1ece0e1aedc9c1128e4ae00")
;; Local Variables:
;; no-byte-compile: t
;; End:
