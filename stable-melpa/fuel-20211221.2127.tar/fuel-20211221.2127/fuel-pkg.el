(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "37e1f91f463c6ab8f03d09361760c466f8a35ccb")
;; Local Variables:
;; no-byte-compile: t
;; End:
