(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2bad1209bf6be50992a46b5ab1822b3020716692")
;; Local Variables:
;; no-byte-compile: t
;; End:
