(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "c4fa4ec04a2f9c6759531d284981f347e1fbc0de")
;; Local Variables:
;; no-byte-compile: t
;; End:
