(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "dfe2e4f2e0fb2691ed026e8cf1b980b76d55b2c0")
;; Local Variables:
;; no-byte-compile: t
;; End:
