(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "1945b8f54cd62c7d6dd811586ee21bf43d6794a6")
;; Local Variables:
;; no-byte-compile: t
;; End:
