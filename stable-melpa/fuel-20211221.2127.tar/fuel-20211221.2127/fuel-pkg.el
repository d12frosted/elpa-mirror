(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "2a098486b2b5fa0ab978ef9bf2a7dcd3f68e3853")
;; Local Variables:
;; no-byte-compile: t
;; End:
