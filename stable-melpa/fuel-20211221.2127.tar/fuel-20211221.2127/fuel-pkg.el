(define-package "fuel" "20211221.2127" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "07d2b0364b3301eab16a1ccfb050f5b3edddbd91")
;; Local Variables:
;; no-byte-compile: t
;; End:
