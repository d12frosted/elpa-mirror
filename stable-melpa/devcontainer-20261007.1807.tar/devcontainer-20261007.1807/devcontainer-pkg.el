;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "devcontainer" "20261007.1807"
  "Support for devcontainer."
  '((emacs "29.1"))
  :url "https://github.com/johannes-mueller/devcontainer.el"
  :commit "a064e67dee64c87c34fe31f835e455ad0f4dc0cc"
  :revdesc "a064e67dee64"
  :authors '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers '(("Johannes Mueller" . "github@johannes-mueller.org")))
