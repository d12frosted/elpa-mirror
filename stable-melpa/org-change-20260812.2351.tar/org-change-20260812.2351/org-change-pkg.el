;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "20260812.2351"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "567858fdf8f8966811bf9737ca5927c2597c1332"
  :revdesc "567858fdf8f8"
  :keywords '("wp" "convenience"))
