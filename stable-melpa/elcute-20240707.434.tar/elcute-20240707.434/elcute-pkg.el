(define-package "elcute" "20240707.434" "Commands for marking and killing lines electrically"
  '((emacs "29.1"))
  :commit "b511b7705e48167e6544b4daa2d74b2460fc541c" :keywords
  '("convenience")
  :url "https://codeberg.org/vilij/slurpbarf-elcute")
;; Local Variables:
;; no-byte-compile: t
;; End:
