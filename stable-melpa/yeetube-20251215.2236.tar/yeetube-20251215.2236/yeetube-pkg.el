;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20251215.2236"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs  "27.2")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "7a5cccd56d1737cc295c55c7f0564c513c8c8f02"
  :revdesc "7a5cccd56d17"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
