;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-beamer-lecture" "20250918.358"
  "Beamer Lecture Back-End for Org Export Engine."
  '((emacs "29.1"))
  :url "https://github.com/fjesser/ox-beamer-lecture"
  :commit "d9cb630ab5d9e5ef58f68216a4b9e472d67eb46e"
  :revdesc "d9cb630ab5d9"
  :keywords '("org" "text" "tex")
  :authors '(("Felix J. Esser" . "code-esser@mailbox.org"))
  :maintainers '(("Felix J. Esser" . "code-esser@mailbox.org")))
