(define-package "consult" "20220111.1112" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "cf959526708a02bee61854ae8898009f3b1b7da5" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
