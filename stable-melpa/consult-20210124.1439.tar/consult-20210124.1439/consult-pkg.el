(define-package "consult" "20210124.1439" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "dc4499a7e80e1e4e60b81cf70e54fe6a87fb11ac" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
