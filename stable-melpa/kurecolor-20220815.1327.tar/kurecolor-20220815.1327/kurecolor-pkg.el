(define-package "kurecolor" "20220815.1327" "color editing goodies"
  '((emacs "28.1")
    (s "1.12"))
  :commit "922eeabdbe91698fd59e2198474008b2b9e960d3" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/kurecolor.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
