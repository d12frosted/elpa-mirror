;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tuareg" "20260617.1454"
  "OCaml mode."
  '((emacs "26.3")
    (caml  "4.8"))
  :url "https://github.com/ocaml/tuareg"
  :commit "7d4dd535e3f4bed2013bad545629302d07ba991e"
  :revdesc "7d4dd535e3f4"
  :keywords '("ocaml" "languages")
  :authors '(("Albert Cohen" . "Albert.Cohen@inria.fr")
             ("Sam Steingold" . "sds@gnu.org")
             ("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
             ("Till Varoquaux" . "till@pps.jussieu.fr")
             ("Sean McLaughlin" . "seanmcl@gmail.com")
             ("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainers '(("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
                 ("Stefan Monnier" . "monnier@iro.umontreal.ca")))
