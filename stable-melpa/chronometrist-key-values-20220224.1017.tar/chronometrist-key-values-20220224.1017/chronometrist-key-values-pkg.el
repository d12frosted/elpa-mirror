(define-package "chronometrist-key-values" "20220224.1017" "add key-values to Chronometrist data"
  '((chronometrist "0.7.0"))
  :commit "9ef3337c5a68caf73866a6949bb5783d7e246979" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
