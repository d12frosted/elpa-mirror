(define-package "pdf-tools" "20220723.32" "Support library for PDF documents"
  '((emacs "24.3")
    (nadvice "0.3")
    (tablist "1.0")
    (let-alist "1.0.4"))
  :commit "efd4ceee1a00df80a6e5815148e300ef50ec5d41" :authors
  '(("Andreas Politz" . "mail@andreas-politz.de"))
  :maintainer
  '("Vedang Manerikar" . "vedang.manerikar@gmail.com")
  :keywords
  '("files" "multimedia")
  :url "http://github.com/vedang/pdf-tools/")
;; Local Variables:
;; no-byte-compile: t
;; End:
