;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260423.1949"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "cd2e9c074576e44469d84b5827933a035cf493c5"
  :revdesc "cd2e9c074576"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
