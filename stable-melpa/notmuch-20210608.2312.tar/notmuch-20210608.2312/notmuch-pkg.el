(define-package "notmuch" "20210608.2312" "run notmuch within emacs" 'nil :commit "af56f3bcdc8a644564a1182f58bd311907193a4a" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
