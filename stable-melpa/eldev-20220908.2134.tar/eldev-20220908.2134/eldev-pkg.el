(define-package "eldev" "20220908.2134" "Elisp development tool"
  '((emacs "24.4"))
  :commit "cd9ecdb4783ca0ff4487e49cd079f390d56281e7" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
