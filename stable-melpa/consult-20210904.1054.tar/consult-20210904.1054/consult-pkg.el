(define-package "consult" "20210904.1054" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7a3ccdc84d0255093317508b44c507155178c21c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
