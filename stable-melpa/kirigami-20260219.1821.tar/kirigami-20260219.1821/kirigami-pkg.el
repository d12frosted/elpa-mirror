;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260219.1821"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "fa7a52aa87592b86ace66869099d4b34129136db"
  :revdesc "fa7a52aa8759"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
