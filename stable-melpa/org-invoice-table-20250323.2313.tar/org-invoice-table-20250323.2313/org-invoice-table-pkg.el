;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-invoice-table" "20250323.2313"
  "Invoicing table formatter for org-mode."
  '((emacs "26.1"))
  :url "https://codeberg.org/trevdev/org-invoice-table"
  :commit "32340ccad5ba20486b80acddeb7f5455e86cf006"
  :revdesc "32340ccad5ba"
  :authors '(("Trevor Richards" . "trev@trevdev.ca"))
  :maintainers '(("Trevor Richards" . "trev@trevdev.ca")))
