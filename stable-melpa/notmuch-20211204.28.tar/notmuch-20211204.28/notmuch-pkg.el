(define-package "notmuch" "20211204.28" "run notmuch within emacs" 'nil :commit "20b2ae12183a5be79d2f3d8da7943bc358e8202c" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
