;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-beautify-theme" "20250730.2044"
  "A sub-theme to make org-mode more beautiful."
  '((emacs "24.1"))
  :url "https://github.com/jonnay/org-beautify-theme"
  :commit "5301f8cfab127f4219aad83e52787898f0710d4f"
  :revdesc "5301f8cfab12"
  :keywords '("faces" "org" "theme")
  :authors '(("Jonathan Arkell" . "jonnay@jonnay.net"))
  :maintainers '(("Jonathan Arkell" . "jonnay@jonnay.net")))
