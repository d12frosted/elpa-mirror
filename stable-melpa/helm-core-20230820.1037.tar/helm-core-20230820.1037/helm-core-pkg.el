(define-package "helm-core" "20230820.1037" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "f55243cf7c8e60064304fbbfde88635f811c385c" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
