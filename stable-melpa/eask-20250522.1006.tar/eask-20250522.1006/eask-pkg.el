;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20250522.1006"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "5bbbfa787132a172326c9e7312fb0f7a6e00ba41"
  :revdesc "5bbbfa787132"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
