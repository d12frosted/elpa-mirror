(define-package "fanyi" "20211005.811" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "3546fa894d0bfbc29ebceed31a5cfd2f9405da20" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
