;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-codesearch" "20180508.1522"
  "Integration of codesearch into projectile."
  '((codesearch "20171122.431")
    (projectile "20150405.126"))
  :url "https://github.com/abingham/emacs-codesearch"
  :commit "e40efc62e9333db0593bd81b5c78d08b19bfb193"
  :revdesc "e40efc62e933"
  :keywords '("tools" "development" "search")
  :authors '(("Austin Bingham" . "austin.bingham@gmail.com"))
  :maintainers '(("Austin Bingham" . "austin.bingham@gmail.com")))
