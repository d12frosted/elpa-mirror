(define-package "php-mode" "20221103.1056" "Major mode for editing PHP code"
  '((emacs "25.2"))
  :commit "3321d490991ec26e32dac6e10b09ae6c1dfe799b" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
