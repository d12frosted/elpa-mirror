(define-package "mistty" "20230930.1918" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "bd83639a0f6cb5de837dd58d4c4b0b78200161ad" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
