(define-package "sops" "20240621.1513" "SOPS encrypt and decrypt without leaving the editor"
  '((emacs "28.1")
    (s "1.13.0"))
  :commit "c89342d60a191bb1382b89252b4153d1c39331ba" :authors
  '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainers
  '(("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com"))
  :maintainer
  '("Jonathan Carroll Otsuka" . "pitas.axioms0c@icloud.com")
  :keywords
  '("convenience" "programming")
  :url "http://github.com/djgoku/sops")
;; Local Variables:
;; no-byte-compile: t
;; End:
