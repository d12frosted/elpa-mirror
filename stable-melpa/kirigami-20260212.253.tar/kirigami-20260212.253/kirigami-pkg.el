;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20260212.253"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "5bf71664012a9ba2bcbafc0b2dda0a6c713dbfdc"
  :revdesc "5bf71664012a"
  :keywords '("convenience"))
