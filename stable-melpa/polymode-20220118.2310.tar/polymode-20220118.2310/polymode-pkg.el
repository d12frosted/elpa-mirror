(define-package "polymode" "20220118.2310" "Extensible framework for multiple major modes"
  '((emacs "25"))
  :commit "0ea23b89ec18377bacb7d91bc02feb55e49b5a65" :authors
  '(("Vitalie Spinu"))
  :maintainer
  '("Vitalie Spinu")
  :keywords
  '("languages" "multi-modes" "processes")
  :url "https://github.com/polymode/polymode")
;; Local Variables:
;; no-byte-compile: t
;; End:
