;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot-chat" "20241125.852"
  "Copilot chat interface."
  '((request       "0.3.2")
    (markdown-mode "2.6")
    (emacs         "27.1")
    (chatgpt-shell "1.6.1")
    (magit         "4.0.0"))
  :url "https://github.com/chep/copilot-chat.el"
  :commit "74c078e1c9a3a455ba8c7c1ab8d1e2a6f8a3b9b6"
  :revdesc "74c078e1c9a3"
  :keywords '("convenience" "tools")
  :authors '(("cedric.chepied" . "cedric.chepied@gmail.com"))
  :maintainers '(("cedric.chepied" . "cedric.chepied@gmail.com")))
