(define-package "embark" "20210724.26" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "471c6a87e5d3f839f47938ea08dcc952d583a5d9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
