(define-package "cframe" "20201222.1930" "Customize a frame and fast switch size and positions"
  '((emacs "26")
    (buffer-manage "0.11")
    (dash "2.17.0"))
  :commit "38544521e82befc06e397123a118dd96dda2c6b6" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("frames")
  :url "https://github.com/plandes/cframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
