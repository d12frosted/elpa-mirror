;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260220.247"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "8af4e68a25623dbe5134053cdadb0c5b06beec9f"
  :revdesc "8af4e68a2562"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
