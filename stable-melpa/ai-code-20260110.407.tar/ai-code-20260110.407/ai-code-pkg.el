;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260110.407"
  "Unified interface for AI coding CLI tool such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "26.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "3c27ae633b32cddce7e917e152cb57a37ebfc201"
  :revdesc "3c27ae633b32"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
