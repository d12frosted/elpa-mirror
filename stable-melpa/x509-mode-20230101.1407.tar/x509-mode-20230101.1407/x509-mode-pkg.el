(define-package "x509-mode" "20230101.1407" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "0f22a0888a8fefc84647a5bcf513afff016fe354" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
