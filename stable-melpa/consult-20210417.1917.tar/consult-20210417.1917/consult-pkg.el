(define-package "consult" "20210417.1917" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "7cfe3bac6dccd44427f0d4276e7ec815f57b797a" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
