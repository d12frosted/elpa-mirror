(define-package "proof-general" "20220704.1103" "A generic Emacs interface for proof assistants"
  '((emacs "25.1"))
  :commit "dcc590b26859a734a6f520991c84a173a6825b6c" :url "https://proofgeneral.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
