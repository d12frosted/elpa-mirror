(define-package "dpkg-dev-el" "20240405.56" "startup file for the elpa-dpkg-dev-el package" 'nil :commit "5c5fe98c479285ec0e288832609ebaa0881d4701" :authors
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainers
  '(("Peter S Galbraith" . "psg@debian.org"))
  :maintainer
  '("Peter S Galbraith" . "psg@debian.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
