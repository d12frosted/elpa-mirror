(define-package "ox-tufte" "20230802.2339" "Tufte HTML org-mode export backend"
  '((org "9.5")
    (emacs "27.1"))
  :commit "352d5ff5d5cd5edcb0d50ce50a5b2aaa8ae6862a" :authors
  '(("M. Lee Hinman"))
  :maintainers
  '(("The Bayesians Inc."))
  :maintainer
  '("The Bayesians Inc.")
  :keywords
  '("org" "tufte" "html" "outlines" "hypermedia" "calendar" "wp")
  :url "https://github.com/ox-tufte/ox-tufte")
;; Local Variables:
;; no-byte-compile: t
;; End:
