(define-package "dashboard" "20220307.1807" "A startup screen extracted from Spacemacs"
  '((emacs "26.1"))
  :commit "d40ceaff2d26f7213eb21f6a39e58c72642ad737" :authors
  '(("Rakan Al-Hneiti" . "rakan.alhneiti@gmail.com"))
  :maintainer
  '("Jesús Martínez" . "jesusmartinez93@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
