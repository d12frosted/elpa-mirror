;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "package-build" "20260101.1127"
  "Tools for assembling a package archive."
  '((emacs  "26.1")
    (compat "30.1"))
  :url "https://github.com/melpa/package-build"
  :commit "96fb2eff9daa3b4e535298ee2f6cd0ed0d9f0190"
  :revdesc "96fb2eff9daa"
  :keywords '("maint" "tools")
  :authors '(("Donald Ephraim Curtis" . "dcurtis@milkbox.net")
             ("Steve Purcell" . "steve@sanityinc.com")
             ("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")
             ("Phil Hagelberg" . "technomancy@gmail.com"))
  :maintainers '(("Jonas Bernoulli" . "emacs.package-build@jonas.bernoulli.dev")))
