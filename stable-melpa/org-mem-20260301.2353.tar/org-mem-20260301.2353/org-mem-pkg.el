;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260301.2353"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "fbe19417cacc7aab48d74bf99d4be6b40570bd1a"
  :revdesc "fbe19417cacc"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
