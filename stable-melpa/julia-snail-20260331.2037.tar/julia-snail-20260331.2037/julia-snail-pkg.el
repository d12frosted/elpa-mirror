;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-snail" "20260331.2037"
  "Julia Snail."
  '((emacs      "26.2")
    (dash       "2.16.0")
    (julia-mode "0.3")
    (s          "1.12.0")
    (spinner    "1.7.3")
    (popup      "0.5.9"))
  :url "https://github.com/gcv/julia-snail"
  :commit "95905e9d6bbf5657b16a307b120d9efb10ac692b"
  :revdesc "95905e9d6bbf")
