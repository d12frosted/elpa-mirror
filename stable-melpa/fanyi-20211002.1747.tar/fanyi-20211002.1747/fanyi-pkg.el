(define-package "fanyi" "20211002.1747" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "48336ff6e9448a340c831867f14fd400ce6b1863" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
