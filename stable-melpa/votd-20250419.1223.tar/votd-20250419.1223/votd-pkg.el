;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "votd" "20250419.1223"
  "Bible Verse Of The Day."
  '((emacs "29.1"))
  :url "https://github.com/kristjoc/votd"
  :commit "d310f51818e62e683027c67da92f56742607e1ba"
  :revdesc "d310f51818e6"
  :keywords '("convenience" "comm" "hypermedia"))
