(define-package "maxima" "20220531.1751" "Major mode for Maxima"
  '((emacs "25.1")
    (s "1.11.0")
    (test-simple "1.3.0"))
  :commit "1913ee496bb09430e85f76dfadf8ba4d4f95420f" :authors
  '(("William F. Schelter")
    ("Jay Belanger")
    ("Fermin Munoz"))
  :maintainer
  '("Fermin Munoz" . "fmfs@posteo.net")
  :keywords
  '("maxima" "tools" "math")
  :url "https://gitlab.com/sasanidas/maxima")
;; Local Variables:
;; no-byte-compile: t
;; End:
