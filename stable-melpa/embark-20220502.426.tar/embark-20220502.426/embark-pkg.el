(define-package "embark" "20220502.426" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "7a2487f5bb8a6ea5a9b5048386d6dcbbc1b6cc85" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
