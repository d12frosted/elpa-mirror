;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-pop" "20260510.1616"
  "Easily toggle a shell window with a single keystroke."
  '((emacs "26.1"))
  :url "https://github.com/kyagi/shell-pop-el"
  :commit "408dc1b710a273011cd902a94dd21f11fa83a362"
  :revdesc "408dc1b710a2"
  :keywords '("shell" "terminal" "tools")
  :authors '(("Kazuo YAGI" . "kazuo.yagi@gmail.com"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
