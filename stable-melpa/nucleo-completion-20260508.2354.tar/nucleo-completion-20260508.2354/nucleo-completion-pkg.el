;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nucleo-completion" "20260508.2354"
  "Nucleo-backed completion style."
  '((emacs "27.1"))
  :url "https://github.com/kn66/nucleo-completion.el"
  :commit "414197bfa69f4f94c07a15d2ca6fc70841a4228e"
  :revdesc "414197bfa69f"
  :keywords '("matching" "convenience")
  :authors '(("Nobu" . "https://github.com/kn66"))
  :maintainers '(("Nobu" . "https://github.com/kn66")))
