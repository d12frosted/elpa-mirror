(define-package "helm-core" "20230306.1500" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "128e162fd3a16609fb618ff74d21d1470cdf1439" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
