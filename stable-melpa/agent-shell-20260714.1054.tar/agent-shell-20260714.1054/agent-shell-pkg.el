;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260714.1054"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "10b668816d62c8debfe6e7fad36f85f211771edf"
  :revdesc "10b668816d62")
