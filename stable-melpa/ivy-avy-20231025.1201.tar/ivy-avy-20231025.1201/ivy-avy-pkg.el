(define-package "ivy-avy" "20231025.1201" "Avy integration for Ivy"
  '((emacs "24.5")
    (ivy "0.14.1")
    (avy "0.5.0"))
  :commit "c843e05525c9dc9b07402b9b89329f5177521e74" :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
