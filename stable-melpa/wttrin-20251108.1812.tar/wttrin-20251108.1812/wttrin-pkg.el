;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "wttrin" "20251108.1812"
  "Emacs Frontend for Service wttr.in."
  '((emacs       "24.4")
    (xterm-color "1.0"))
  :url "https://github.com/cjennings/emacs-wttrin"
  :commit "04b11059b831c94b4e5ba901b735fcc888cbbe1a"
  :revdesc "04b11059b831"
  :keywords '("weather" "wttrin" "games")
  :maintainers '(("Craig Jennings" . "c@cjennings.net")))
