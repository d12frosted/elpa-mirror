;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260203.33"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "871f1006318bb5808a385d2850c3c75debb07fb8"
  :revdesc "871f1006318b")
