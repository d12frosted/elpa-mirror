(define-package "digistar-mode" "20240430.1417" "major mode for Digistar scripts" 'nil :commit "7c74c10fe71872d0cd9a665671fe1b899e205843" :authors
  '(("John Foerch" . "jjfoerch@gmail.com"))
  :maintainers
  '(("John Foerch" . "jjfoerch@gmail.com"))
  :maintainer
  '("John Foerch" . "jjfoerch@gmail.com")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
