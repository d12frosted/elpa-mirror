;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "daselt" "20260512.626"
  "Module for the Daselt configuration scheme."
  '((emacs "30.1"))
  :url "https://gitlab.com/nameiwillforget/d-emacs/"
  :commit "3b3a4fd4c773b6372621fe35f7183f4b59b65e4a"
  :revdesc "3b3a4fd4c773"
  :keywords '("tools")
  :authors '(("Alexander Prähauser" . "ahprae@protonmail.com"))
  :maintainers '(("Alexander Prähauser" . "ahprae@protonmail.com")))
