;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260515.1543"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "c2e688a42b8d13d0a9d800bdaa68b3d7a0a29eaa"
  :revdesc "c2e688a42b8d"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
