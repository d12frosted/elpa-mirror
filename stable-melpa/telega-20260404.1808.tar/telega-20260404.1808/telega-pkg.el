;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260404.1808"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "895a141ad34a027400f3da4be3821807cb829e41"
  :revdesc "895a141ad34a"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
