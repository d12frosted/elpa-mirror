(define-package "tree-edit" "20220121.1603" "A library for structural refactoring and editing"
  '((emacs "27.1")
    (tree-sitter "0.15.0")
    (tsc "0.15.0")
    (tree-sitter-langs "0.10.0")
    (dash "2.19")
    (reazon "0.4.0")
    (s "0.0.0"))
  :commit "9c5e91199c7de7e271fcd4ef91ffd115e830e669" :authors
  '(("Ethan Leba" . "ethanleba5@gmail.com"))
  :maintainer
  '("Ethan Leba" . "ethanleba5@gmail.com")
  :url "https://github.com/ethan-leba/tree-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
