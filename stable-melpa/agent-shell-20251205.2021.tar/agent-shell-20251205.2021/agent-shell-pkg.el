;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251205.2021"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "581dc765f8ddbff0460f93bea88c95fd20847057"
  :revdesc "581dc765f8dd")
