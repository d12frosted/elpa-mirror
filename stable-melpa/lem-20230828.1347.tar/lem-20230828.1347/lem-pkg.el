(define-package "lem" "20230828.1347" "A basic lemmy client"
  '((emacs "28.1")
    (fedi "0.1")
    (markdown-mode "2.5"))
  :commit "3165695121e4d0ab89d0b1f719ac1c2d8002e499" :authors
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainers
  '(("martian hiatus <martianhiatus [a t] riseup [d o t] net>"))
  :maintainer
  '("martian hiatus <martianhiatus [a t] riseup [d o t] net>")
  :keywords
  '("multimedia" "comm" "web" "fediverse")
  :url "https://codeberg.org/martianh/lem.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
