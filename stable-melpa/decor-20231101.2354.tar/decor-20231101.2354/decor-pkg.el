(define-package "decor" "20231101.2354" "Modify visual decorations (X11)"
  '((emacs "24.1"))
  :commit "aad4fa9f4e0d4140e2707f4cc678b1dc3c0672fa" :authors
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainers
  '(("Peter Badida" . "keyweeusr@gmail.com"))
  :maintainer
  '("Peter Badida" . "keyweeusr@gmail.com")
  :keywords
  '("convenience" "window" "decoration" "distraction" "x11" "xprop")
  :url "https://github.com/KeyWeeUsr/decor")
;; Local Variables:
;; no-byte-compile: t
;; End:
