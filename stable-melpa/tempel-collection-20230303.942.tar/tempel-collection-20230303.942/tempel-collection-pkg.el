(define-package "tempel-collection" "20230303.942" "Collection of templates for Tempel"
  '((tempel "0.5")
    (emacs "27.1"))
  :commit "4d0ae7b9355b45aa24dfa5e072ff50baf63f752a" :authors
  '(("Vitalii Drevenchuk" . "cradlemann@gmail.com")
    ("Max Penet" . "mpenetr@s-exp.com")
    ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Vitalii Drevenchuk" . "cradlemann@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/Crandel/tempel-collection")
;; Local Variables:
;; no-byte-compile: t
;; End:
