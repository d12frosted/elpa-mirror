(define-package "alect-themes" "20181220.1915" "Configurable light, dark and black themes for Emacs 24 or later"
  '((emacs "24.0"))
  :commit "a24065dc780738e914140d617bfe119c889d9c78" :authors
  '(("Alex Kost" . "alezost@gmail.com"))
  :maintainer
  '("Alex Kost" . "alezost@gmail.com")
  :keywords
  '("color" "theme")
  :url "https://github.com/alezost/alect-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
