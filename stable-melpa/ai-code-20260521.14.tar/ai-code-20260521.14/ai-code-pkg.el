;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260521.14"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "25aebcc3e60e6b39835a00d260c7cc4930a3c9f0"
  :revdesc "25aebcc3e60e"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
