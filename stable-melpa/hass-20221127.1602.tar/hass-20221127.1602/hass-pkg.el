(define-package "hass" "20221127.1602" "Interact with Home Assistant"
  '((emacs "25.1")
    (request "0.3.3"))
  :commit "13676aef2d360cce7a50754b8efc854363280d70" :authors
  '(("Ben Whitley"))
  :maintainer
  '("Ben Whitley")
  :url "https://github.com/purplg/hass")
;; Local Variables:
;; no-byte-compile: t
;; End:
