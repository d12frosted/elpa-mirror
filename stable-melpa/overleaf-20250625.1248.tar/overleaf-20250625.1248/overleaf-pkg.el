;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250625.1248"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "07e45836adad45c18804b5e303b54d819a9beff8"
  :revdesc "07e45836adad"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
