;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macos-notifications" "20261111.1656"
  "Native macOS notifications with click callbacks."
  '((emacs "28.1"))
  :url "https://github.com/dakra/macos-notifications"
  :commit "9174abbc7ac2afcd99f931c6fdef2066951d047b"
  :revdesc "9174abbc7ac2"
  :keywords '("notifications" "tools")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
