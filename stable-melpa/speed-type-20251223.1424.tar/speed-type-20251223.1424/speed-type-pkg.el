;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251223.1424"
  "Practice touch and speed typing."
  '((emacs  "27.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "2f60595cd9556ab702a81053fa5ae26f2e054d96"
  :revdesc "2f60595cd955"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
