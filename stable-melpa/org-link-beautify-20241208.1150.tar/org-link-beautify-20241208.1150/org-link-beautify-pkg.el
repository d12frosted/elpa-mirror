;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20241208.1150"
  "Beautify Org Links."
  '((emacs      "29.1")
    (org        "9.7.14")
    (nerd-icons "0.0.1"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "5456afd4f3a6e5a351cf5360769b668e6f6e2a9c"
  :revdesc "5456afd4f3a6"
  :keywords '("hypermedia"))
