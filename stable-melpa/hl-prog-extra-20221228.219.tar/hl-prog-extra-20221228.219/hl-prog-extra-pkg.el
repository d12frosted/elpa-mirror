(define-package "hl-prog-extra" "20221228.219" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "5488297ce0bfd3e59d3cbf9db8a9060ca1e6736e" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
