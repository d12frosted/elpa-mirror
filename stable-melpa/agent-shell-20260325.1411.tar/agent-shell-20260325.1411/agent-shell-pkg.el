;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260325.1411"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e6074160a2d108696537f56a02287f03dc147234"
  :revdesc "e6074160a2d1")
