;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-pkg-config" "20230119.1721"
  "Configure flycheck using pkg-config."
  '((dash     "2.8.0")
    (s        "1.9.0")
    (flycheck "29"))
  :url "https://github.com/Wilfred/flycheck-pkg-config"
  :commit "c4e4028f6621187365b7362566ac2786206765a1"
  :revdesc "c4e4028f6621"
  :keywords '("flycheck")
  :authors '(("Wilfred Hughes" . "me@wilfred.me.uk"))
  :maintainers '(("Wilfred Hughes" . "me@wilfred.me.uk")))
