;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260722.1259"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "e1d8da613ca274d0d13a10b23ec83fadeff6fdd1"
  :revdesc "e1d8da613ca2"
  :keywords '("data" "extensions"))
