;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "composable" "20220608.1148"
  "Composable editing."
  '((emacs "25.1"))
  :url "https://github.com/paldepind/composable.el"
  :commit "205a69c64ea95ef67070423c31ed70ec44ec980c"
  :revdesc "205a69c64ea9"
  :keywords '("lisp")
  :authors '(("Simon Friis Vindum" . "simon@vindum.io"))
  :maintainers '(("Simon Friis Vindum" . "simon@vindum.io")))
