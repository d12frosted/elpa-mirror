;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260424.2341"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "7beeb794069770fce64f4003d5f6862763bc3654"
  :revdesc "7beeb7940697"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
