(define-package "naga-theme" "20231203.809" "Dark color theme with green foreground color"
  '((emacs "24.1"))
  :commit "1cec03b52e123d6be71ce146a3fc0365561e4f0c" :authors
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainers
  '(("Johannes Maier" . "johannes.maier@mailbox.org"))
  :maintainer
  '("Johannes Maier" . "johannes.maier@mailbox.org")
  :keywords
  '("faces" "themes")
  :url "https://github.com/kenranunderscore/emacs-naga-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
