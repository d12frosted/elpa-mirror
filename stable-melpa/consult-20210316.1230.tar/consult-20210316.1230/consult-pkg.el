(define-package "consult" "20210316.1230" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "3d1595e1565b0fa591655f6d1a0a9dd25cd8c984" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
