;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flow-js2-mode" "20191213.1004"
  "Support for flow annotations in js2-mode."
  '((flow-minor-mode "0")
    (js2-mode        "0")
    (emacs           "25.1"))
  :url "https://github.com/Fuco1/flow-js2-mode"
  :commit "7520bdda70287e8d57b3f41033b1e0ca59a3be95"
  :revdesc "7520bdda7028"
  :keywords '("languages" "extensions")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
