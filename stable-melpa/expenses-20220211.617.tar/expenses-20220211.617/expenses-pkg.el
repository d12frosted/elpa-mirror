(define-package "expenses" "20220211.617" "Record and view expenses"
  '((emacs "26.1")
    (dash "2.19.1")
    (ht "2.3"))
  :commit "1d9149a1ec18f392ee70b25bac41bbb6bfdbfbd6" :authors
  '(("Md Arif Shaikh" . "arifshaikh.astro@gmail.com"))
  :maintainer
  '("Md Arif Shaikh" . "arifshaikh.astro@gmail.com")
  :keywords
  '("expense tracking" "convenience")
  :url "https://github.com/md-arif-shaikh/expenses")
;; Local Variables:
;; no-byte-compile: t
;; End:
