;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pi-coding-agent" "20260304.58"
  "Emacs frontend for pi coding agent."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/dnouri/pi-coding-agent"
  :commit "3d4510b802e1ce19995bd134c860b775d47297d9"
  :revdesc "3d4510b802e1"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
