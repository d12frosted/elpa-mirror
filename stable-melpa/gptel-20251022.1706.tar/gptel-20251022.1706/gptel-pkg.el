;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251022.1706"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "d14d8c12f33829ea1615ac5316d7534d4175fe23"
  :revdesc "d14d8c12f338"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
