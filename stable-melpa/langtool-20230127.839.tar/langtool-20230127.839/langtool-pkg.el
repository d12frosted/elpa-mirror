(define-package "langtool" "20230127.839" "Grammar check utility using LanguageTool"
  '((cl-lib "0.3"))
  :commit "69dc4f71dd06fe36f8335deb6d5caf980cda2d45" :authors
  '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainer
  '("Masahiro Hayashi" . "mhayashi1120@gmail.com")
  :keywords
  '("docs")
  :url "https://github.com/mhayashi1120/Emacs-langtool")
;; Local Variables:
;; no-byte-compile: t
;; End:
