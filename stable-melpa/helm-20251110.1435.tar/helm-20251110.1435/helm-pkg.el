;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20251110.1435"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.6")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "9a4b82ec06f131e7ba795ff60c6f70c1d547d52f"
  :revdesc "9a4b82ec06f1"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
