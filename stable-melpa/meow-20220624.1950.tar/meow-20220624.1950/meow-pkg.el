(define-package "meow" "20220624.1950" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "70c27de889260b809a4f1010b3ce9c21bac5f87b" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
