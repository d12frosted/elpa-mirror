;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bazel" "20260413.1918"
  "Bazel support for Emacs."
  '((emacs "29.1"))
  :url "https://github.com/bazelbuild/emacs-bazel-mode"
  :commit "6d33dac0e0f04a6ad33eaf4462e0bcfde511e43a"
  :revdesc "6d33dac0e0f0"
  :keywords '("build tools" "languages"))
