;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20260317.719"
  "Ollama LLM AI Assistant ChatGPT Claude Gemini Grok Codestral DeepSeek OpenRouter Support."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "c207b2312691cd5e9493e4d1c02a9ab91369a4b2"
  :revdesc "c207b2312691"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
