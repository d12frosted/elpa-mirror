;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260624.344"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "cc2761444e652722a65e5d31db663315abc4df2f"
  :revdesc "cc2761444e65"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
