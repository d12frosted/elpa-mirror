;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20261002.621"
  "Note management library for Org mode."
  '((emacs   "29.1")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "9fc0ca3c7c75c2529ce2d7d85a2a94014f1e5f71"
  :revdesc "9fc0ca3c7c75"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
