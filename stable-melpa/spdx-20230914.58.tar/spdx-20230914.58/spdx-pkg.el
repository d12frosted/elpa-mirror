(define-package "spdx" "20230914.58" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "36f52acd2bb2d9df967d2830ee64252ee52d22e6" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
