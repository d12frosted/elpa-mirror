(define-package "oer-reveal" "20220321.1632" "OER with reveal.js, plugins, and org-re-reveal"
  '((emacs "24.4")
    (org-re-reveal "3.1.0"))
  :commit "8ac1829bbe3458a100ef7de1195a9714b59db98b" :authors
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "oer")
  :url "https://gitlab.com/oer/oer-reveal")
;; Local Variables:
;; no-byte-compile: t
;; End:
