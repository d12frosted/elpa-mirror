;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "embark" "20260330.2221"
  "Conveniently act on minibuffer completions."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/oantolin/embark"
  :commit "66429937eb46a45064f17b74b8fa94eecd8a9227"
  :revdesc "66429937eb46"
  :keywords '("convenience")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")))
