;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "roc-ts-mode" "20260205.1810"
  "Roc programming language mode."
  '((emacs "29.1"))
  :url "https://gitlab.com/tad-lispy/roc-ts-mode"
  :commit "ae755ecf52e1b3fc68440d8870b37cfe61a381d6"
  :revdesc "ae755ecf52e1"
  :keywords '("languages")
  :authors '(("Tad Lispy" . "tadeusz@lazurski.pl")
             ("Ajai Khatri Nelson" . "emacs@ajai.dev"))
  :maintainers '(("Tad Lispy" . "tadeusz@lazurski.pl")
                 ("Ajai Khatri Nelson" . "emacs@ajai.dev")))
