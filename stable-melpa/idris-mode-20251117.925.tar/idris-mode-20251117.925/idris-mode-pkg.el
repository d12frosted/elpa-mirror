;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idris-mode" "20251117.925"
  "Major mode for editing Idris code."
  '((emacs     "24")
    (prop-menu "0.1")
    (cl-lib    "0.5"))
  :url "https://github.com/idris-hackers/idris-mode"
  :commit "49c6f3861f72c692aa8cda4793725caa31c836c7"
  :revdesc "49c6f3861f72"
  :keywords '("languages"))
