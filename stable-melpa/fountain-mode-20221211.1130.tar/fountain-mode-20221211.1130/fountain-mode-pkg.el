(define-package "fountain-mode" "20221211.1130" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "82ed82490bce971c7e2b8b28be5801a8e6fe7569" :authors
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainer
  '("Paul W. Rankin" . "hello@paulwrankin.com")
  :keywords
  '("wp" "text")
  :url "https://github.com/rnkn/fountain-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
