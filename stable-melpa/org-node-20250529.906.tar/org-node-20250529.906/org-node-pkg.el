;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250529.906"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.13.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "7df7a1624b15a5de4f151748bb4678c5452398f8"
  :revdesc "7df7a1624b15"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
