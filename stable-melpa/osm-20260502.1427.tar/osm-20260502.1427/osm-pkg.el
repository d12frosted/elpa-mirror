;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "osm" "20260502.1427"
  "OpenStreetMap viewer."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/osm"
  :commit "81b012bb154537e4e93a5702d001f9c9d4197689"
  :revdesc "81b012bb1545"
  :keywords '("network" "multimedia" "hypermedia" "mouse")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
