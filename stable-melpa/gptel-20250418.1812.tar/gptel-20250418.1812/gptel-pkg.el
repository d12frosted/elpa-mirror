;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250418.1812"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "b44bad8800edb8e70b5a6bee53e5849b814d8ede"
  :revdesc "b44bad8800ed"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
