;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mybigword" "20230809.904"
  "Vocabulary builder using Zipf to extract English big words."
  '((emacs "26.1")
    (avy   "0.5.0"))
  :url "https://github.com/redguardtoo/mybigword"
  :commit "13574e2c47a670df4b776b88bd633b2e8a82b2b2"
  :revdesc "13574e2c47a6"
  :keywords '("convenience")
  :authors '(("Chen Bin" . "chenbinDOTshATgmail.com"))
  :maintainers '(("Chen Bin" . "chenbinDOTshATgmail.com")))
