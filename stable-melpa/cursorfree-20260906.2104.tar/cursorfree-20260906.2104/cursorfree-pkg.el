;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cursorfree" "20260906.2104"
  "Complex editing through voice."
  '((emacs "29.1")
    (phony "1.0.1"))
  :url "https://github.com/ErikPrantare/cursorfree.el"
  :commit "63d853f941e57142c3462f752063fceb778dda8d"
  :revdesc "63d853f941e5"
  :keywords '("convenience")
  :authors '(("Erik Präntare" . "erik@prantare.xyz"))
  :maintainers '(("Erik Präntare" . "erik@prantare.xyz")))
