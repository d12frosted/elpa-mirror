;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sumibi" "20251231.1200"
  "Japanese input method powered by ChatGPT API."
  '((emacs          "29.0")
    (popup          "0.5.9")
    (unicode-escape "1.1")
    (deferred       "0.5.1"))
  :url "https://github.com/kiyoka/Sumibi"
  :commit "ac3ea6c6cd816cf3c83474e881ab2bdab1ee1935"
  :revdesc "ac3ea6c6cd81"
  :keywords '("lisp" "ime" "japanese")
  :authors '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org"))
  :maintainers '(("Kiyoka Nishiyama" . "kiyoka@sumibi.org")))
