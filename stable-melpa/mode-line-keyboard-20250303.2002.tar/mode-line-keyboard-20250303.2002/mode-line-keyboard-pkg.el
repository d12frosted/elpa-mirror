;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mode-line-keyboard" "20250303.2002"
  "Keyboard in mode line for touch screens."
  '((emacs "26.0"))
  :url "https://github.com/Lindydancer/mode-line-keyboard"
  :commit "e5613ccd81bd58161efb53ebeaee7bd4dea197ee"
  :revdesc "e5613ccd81bd"
  :keywords '("convenience"))
