;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20251123.2032"
  "A unified method to fold and unfold text."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "aaaa67dd4b164bd6fe97a67e508440847f847ddd"
  :revdesc "aaaa67dd4b16"
  :keywords '("convenience"))
