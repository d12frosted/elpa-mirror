;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-change" "20260801.1701"
  "Annotate changes in text files."
  '((emacs "29.1"))
  :url "https://github.com/drghirlanda/org-change"
  :commit "992f4ffe07f07b31a619a6bfacfbf6fe2d95db0a"
  :revdesc "992f4ffe07f0"
  :keywords '("wp" "convenience"))
