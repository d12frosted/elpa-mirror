(define-package "modus-themes" "20210726.910" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "644b6c286aabf639fc4931abe92264fa84a22d67" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
