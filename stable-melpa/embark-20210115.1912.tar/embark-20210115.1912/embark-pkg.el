(define-package "embark" "20210115.1912" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "47daded610b245caf01a97d74c940aff91fe14e2" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
