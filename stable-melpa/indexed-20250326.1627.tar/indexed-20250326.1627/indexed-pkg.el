;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250326.1627"
  "Cache metadata on all Org files."
  '((emacs   "29.1")
    (el-job  "2.4.1")
    (emacsql "4.2.0")
    (llama   "0.5.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "5446b88445c3695a9e81e53f08d56b92e403d3f2"
  :revdesc "5446b88445c3"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
