(define-package "litex-mode" "20220301.529" "Minor mode for converting lisp to LaTeX"
  '((cl-lib "0.5")
    (emacs "24.1"))
  :commit "324081d31a75bae26c56a84276cb1a074e97e005" :authors
  '(("Gaurav Atreya" . "allmanpride@gmail.com"))
  :maintainer
  '("Gaurav Atreya" . "allmanpride@gmail.com")
  :keywords
  '("calculator" "lisp" "latex")
  :url "https://github.com/Atreyagaurav/litex-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
