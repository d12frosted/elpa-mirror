;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fancy-urls-menu" "20241216.2300"
  "Interface for viewing and opening URLs in current buffer."
  '((emacs "29.1"))
  :url "https://codeberg.org/kakafarm/emacs-fancy-urls-menu/"
  :commit "88135b9964edd47f849830308e9be17813598432"
  :revdesc "88135b9964ed"
  :keywords '("convenience")
  :maintainers '((nil . "yuval.langer@gmail.com")))
