(define-package "pg" "20230907.1549" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "26.1"))
  :commit "a848042aa3c3f87c3e0101bf2f059cd7b9e7aa0f" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
