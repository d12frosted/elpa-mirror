(define-package "init-dir" "20231126.457" "Init directory instead of just a single file"
  '((emacs "27.1"))
  :commit "f8c05a011279edfe904522fec8614702aad5ef78" :authors
  '(("Jared Finder" . "jared@finder.org"))
  :maintainers
  '(("Jared Finder" . "jared@finder.org"))
  :maintainer
  '("Jared Finder" . "jared@finder.org")
  :keywords
  '("extensions" "internal")
  :url "http://github.com/chaosemer/init-dir")
;; Local Variables:
;; no-byte-compile: t
;; End:
