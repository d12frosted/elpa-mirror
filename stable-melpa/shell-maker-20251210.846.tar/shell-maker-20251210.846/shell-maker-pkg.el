;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20251210.846"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "fa1393a28dc661b7b2b31c7731d7c9b0ca48d026"
  :revdesc "fa1393a28dc6")
