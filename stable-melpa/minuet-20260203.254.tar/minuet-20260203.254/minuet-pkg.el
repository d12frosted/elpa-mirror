;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20260203.254"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "dd8301f05dce2c5c536947a6b9bd262a81018e69"
  :revdesc "dd8301f05dce"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
