(define-package "notmuch" "20210713.1255" "run notmuch within emacs" 'nil :commit "d8a5fba4fe1efd7d0d652ead6d55371bc4078a9d" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
