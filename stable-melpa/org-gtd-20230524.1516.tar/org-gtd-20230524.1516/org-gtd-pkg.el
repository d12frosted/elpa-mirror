(define-package "org-gtd" "20230524.1516" "An implementation of GTD."
  '((emacs "27.2")
    (org-edna "1.1.2")
    (f "0.20.0")
    (org "9.6")
    (org-agenda-property "1.3.1")
    (transient "0.3.7"))
  :commit "d6fe323fe03a226f91ba4646afd8908253a8456a" :authors
  '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainer
  '("Aldric Giacomoni" . "trevoke@gmail.com")
  :url "https://github.com/Trevoke/org-gtd.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
