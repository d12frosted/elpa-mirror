;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260205.1250"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "8cc46315ed653097af15a9c2dd7c3d50f7e2090c"
  :revdesc "8cc46315ed65"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
