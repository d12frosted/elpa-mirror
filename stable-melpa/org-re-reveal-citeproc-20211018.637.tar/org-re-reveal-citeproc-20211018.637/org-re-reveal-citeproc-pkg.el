(define-package "org-re-reveal-citeproc" "20211018.637" "Citations and bibliography for org-re-reveal"
  '((emacs "25.1")
    (org "9.5")
    (citeproc "0.9")
    (org-re-reveal "3.0.0"))
  :commit "bfa2d8828153920fef650d8f1b82d2a534d6c063" :authors
  '(("Jens Lechtenbörger"))
  :maintainer
  '("Jens Lechtenbörger")
  :keywords
  '("hypermedia" "tools" "slideshow" "presentation" "bibliography")
  :url "https://gitlab.com/oer/org-re-reveal-citeproc")
;; Local Variables:
;; no-byte-compile: t
;; End:
