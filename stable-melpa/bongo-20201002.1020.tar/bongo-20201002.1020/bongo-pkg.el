;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bongo" "20201002.1020"
  "Play music with Emacs."
  '((cl-lib "0.5")
    (emacs  "24.1"))
  :url "https://github.com/dbrock/bongo"
  :commit "9e9629090262bba6d0003dabe5a375e47a4477f1"
  :revdesc "9e9629090262")
