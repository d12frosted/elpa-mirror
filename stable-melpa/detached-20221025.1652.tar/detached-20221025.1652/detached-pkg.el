(define-package "detached" "20221025.1652" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "7796d2e6f241819703843d24a57597afef2f9757" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
