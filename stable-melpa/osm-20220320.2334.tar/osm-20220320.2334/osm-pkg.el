(define-package "osm" "20220320.2334" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "4124183d15bb5ad84ac93664895bf93557572b6c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
