;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260106.558"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "56e6671f4b2b87ec943c168916fdd59ba1eb3fd5"
  :revdesc "56e6671f4b2b"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
