(define-package "racket-mode" "20211015.1650" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "46bb0bf29f6b2fb571374e1aaf4252bf5f54281f" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
