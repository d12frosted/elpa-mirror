;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "format-all" "20260510.842"
  "Auto-format C, C++, JS, Python, Ruby and 50 other languages."
  '((emacs       "24.4")
    (inheritenv  "0.1")
    (language-id "0.20"))
  :url "https://github.com/lassik/emacs-format-all-the-code"
  :commit "5ea26dda9477285aae2640d79ad501a420ee52bd"
  :revdesc "5ea26dda9477"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
