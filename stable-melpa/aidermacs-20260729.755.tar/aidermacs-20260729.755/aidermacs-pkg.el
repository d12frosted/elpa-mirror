;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260729.755"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "04c31616481fe55b4362859af01241041b755a6a"
  :revdesc "04c31616481f"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
