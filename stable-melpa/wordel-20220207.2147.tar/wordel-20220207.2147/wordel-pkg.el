(define-package "wordel" "20220207.2147" "An Elisp implementation of \"Wordle\" (aka \"Lingo\")"
  '((emacs "27.1"))
  :commit "9f38ff96ccf7176e8a199a57260d79f32ea37953" :authors
  '(("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com"))
  :maintainer
  '("Nicholas Vollmer" . "iarchivedmywholelife@gmail.com")
  :keywords
  '("games")
  :url "https://github.com/progfolio/wordel")
;; Local Variables:
;; no-byte-compile: t
;; End:
