;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260323.2157"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "e877296588c24f2423af446fdada271850262582"
  :revdesc "e877296588c2"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
