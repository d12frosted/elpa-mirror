;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gemtext-mode" "20241129.820"
  "Major mode for Gemtext-formatted text."
  '((emacs "29.1"))
  :url "https://sr.ht/~arjca/gemtext-mode.el/"
  :commit "9e6a7373759afbb8b05e322a3c7b52fc9255c16c"
  :revdesc "9e6a7373759a"
  :keywords '("languages" "gemtext" "gemini")
  :authors '(("Antoine Aubé" . "courriel@arjca.fr"))
  :maintainers '(("Antoine Aubé" . "courriel@arjca.fr")))
