(define-package "geiser-gauche" "20220503.1700" "Gauche scheme support for Geiser"
  '((emacs "26.1")
    (geiser "0.11.2"))
  :commit "8ff743f6416f00751e24aef8b9791501a40f5421" :authors
  '(("András Simonyi" . "andras.simonyi@gmail.com"))
  :maintainer
  '("András Simonyi" . "andras.simonyi@gmail.com")
  :keywords
  '("languages" "gauche" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/gauche")
;; Local Variables:
;; no-byte-compile: t
;; End:
