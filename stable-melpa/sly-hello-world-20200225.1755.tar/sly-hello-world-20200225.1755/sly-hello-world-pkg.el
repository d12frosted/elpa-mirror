(define-package "sly-hello-world" "20200225.1755" "A template SLY contrib"
  '((sly "1.0.0beta2"))
  :commit "d25acc1220a3ce066bd9908251c2f0f88b1781e9" :keywords
  ("languages" "lisp" "sly")
  :authors
  (("João Távora" . "joaotavora@gmail.com"))
  :maintainer
  ("João Távora" . "joaotavora@gmail.com")
  :url "https://github.com/capitaomorte/sly-hello-world")
;; Local Variables:
;; no-byte-compile: t
;; End:
