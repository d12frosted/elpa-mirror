(define-package "eldev" "20230117.2135" "Elisp development tool"
  '((emacs "24.4"))
  :commit "f6895d8768314b7a4691c984468c2ec6a0e08b32" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
