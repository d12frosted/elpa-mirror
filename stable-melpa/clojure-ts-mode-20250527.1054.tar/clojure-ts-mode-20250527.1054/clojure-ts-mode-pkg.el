;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20250527.1054"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "http://github.com/clojure-emacs/clojure-ts-mode"
  :commit "c7c7550f04d2191ec3371d90f1549e43dae1db2e"
  :revdesc "c7c7550f04d2"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
