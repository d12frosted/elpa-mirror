;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-athena" "20250709.12"
  "Run AWS Athena queries from Org Babel."
  '((emacs "26.1"))
  :url "https://github.com/will-abb/aws-athena-babel"
  :commit "9ae4c947f070f0c6ad3ae28e7c78c306b39154cb"
  :revdesc "9ae4c947f070"
  :keywords '("aws" "athena" "org" "babel" "sql" "tools")
  :authors '(("Williams Bosch-Bello" . "williamsbosch@gmail.com"))
  :maintainers '(("Williams Bosch-Bello" . "williamsbosch@gmail.com")))
