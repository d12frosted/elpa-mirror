;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thread-dump" "20170816.1850"
  "Java thread dump viewer."
  ()
  :url "https://github.com/nd/thread-dump.el"
  :commit "204c9600242756d4b514bb5ff6293e052bf4b49d"
  :revdesc "204c96002427")
