(define-package "jinx" "20230327.1318" "Enchanted Just-in-time Spell Checker"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "b4fc5ef01ef85f37b785a57fe0bf0cd57869c964" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/jinx")
;; Local Variables:
;; no-byte-compile: t
;; End:
