;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260215.1554"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "7063a08e38815c756c588e04aa8c129b43214962"
  :revdesc "7063a08e3881"
  :keywords '("convenience"))
