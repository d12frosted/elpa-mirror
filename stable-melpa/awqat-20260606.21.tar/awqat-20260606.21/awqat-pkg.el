;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "awqat" "20260606.21"
  "Islamic prayer times."
  '((emacs "28.1")
    (alert "1.2"))
  :url "https://github.com/zkry/awqat"
  :commit "36b311d5d408be7f3d8758431012565457527614"
  :revdesc "36b311d5d408"
  :authors '(("Zachary Romero" . "zacromero@posteo.net"))
  :maintainers '(("Zachary Romero" . "zacromero@posteo.net")))
