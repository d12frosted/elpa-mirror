(define-package "srcery-theme" "20230827.809" "Dark color theme"
  '((emacs "24"))
  :commit "99455933e4797287c605db0b6b643d7c5fbee04e" :authors
  '(("Daniel Berg"))
  :maintainers
  '(("Daniel Berg"))
  :maintainer
  '("Daniel Berg")
  :keywords
  '("faces")
  :url "https://github.com/srcery-colors/srcery-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
