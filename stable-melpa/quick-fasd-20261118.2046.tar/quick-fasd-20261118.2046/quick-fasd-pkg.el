;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "quick-fasd" "20261118.2046"
  "Integration for the command-line tool `fasd'."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/quick-fasd.el"
  :commit "092ae42ac385ff611bf79437b8e2d430e855d4f5"
  :revdesc "092ae42ac385"
  :keywords '("convenience" "files" "tools"))
