;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rpn-calc" "20210306.426"
  "Quick RPN calculator for hackers."
  '((popup "0.4"))
  :url "https://github.com/zk-phi/rpn-calc"
  :commit "320123ede874a8fc6cde542baa0d106950318071"
  :revdesc "320123ede874")
