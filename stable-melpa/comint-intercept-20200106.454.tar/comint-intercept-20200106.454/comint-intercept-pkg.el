(define-package "comint-intercept" "20200106.454" "Intercept input in comint-mode"
  '((emacs "24.3"))
  :commit "3c9a6125e450435b79ab5e6466f830e57c5e0a30" :authors
  '(("\"Huang, Ying\"" . "huang.ying.caritas@gmail.com"))
  :maintainers
  '(("\"Huang, Ying\"" . "huang.ying.caritas@gmail.com"))
  :maintainer
  '("\"Huang, Ying\"" . "huang.ying.caritas@gmail.com")
  :keywords
  '("processes" "terminals")
  :url "https://github.com/hying-caritas/comint-intercept")
;; Local Variables:
;; no-byte-compile: t
;; End:
