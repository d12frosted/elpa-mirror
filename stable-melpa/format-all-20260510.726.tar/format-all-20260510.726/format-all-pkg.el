;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "format-all" "20260510.726"
  "Auto-format C, C++, JS, Python, Ruby and 50 other languages."
  '((emacs       "24.4")
    (inheritenv  "0.1")
    (language-id "0.20"))
  :url "https://github.com/lassik/emacs-format-all-the-code"
  :commit "07432b4ee1dc22e67ef3a23e73b142b80cb3ee1c"
  :revdesc "07432b4ee1dc"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
