(define-package "fanyi" "20211007.1630" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "b686b82677103de0e8aa81d0b40af991e161a6c6" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
