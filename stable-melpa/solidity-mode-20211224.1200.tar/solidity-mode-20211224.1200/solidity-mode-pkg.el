(define-package "solidity-mode" "20211224.1200" "Major mode for ethereum's solidity language" 'nil :commit "7f239128a15b2baf47be0f8c88f1f533f3114071" :authors
  '(("Lefteris Karapetsas " . "lefteris@refu.co"))
  :maintainer
  '("Lefteris Karapetsas " . "lefteris@refu.co")
  :keywords
  '("languages" "solidity"))
;; Local Variables:
;; no-byte-compile: t
;; End:
