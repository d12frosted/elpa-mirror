(define-package "embark" "20210915.1947" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "63f4128eaca0d7fae9c6c5499e9e36fd29725f53" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
