;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260128.1618"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "4310dc9d736c48b09d59d4041628bcffd09322f5"
  :revdesc "4310dc9d736c"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
