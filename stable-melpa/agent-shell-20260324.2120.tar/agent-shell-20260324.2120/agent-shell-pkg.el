;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260324.2120"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.90.1")
    (acp         "0.11.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "82a7fff89094f509c22f89889401dce5134d459a"
  :revdesc "82a7fff89094")
