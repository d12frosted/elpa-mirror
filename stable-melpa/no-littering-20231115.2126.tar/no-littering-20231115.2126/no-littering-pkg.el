(define-package "no-littering" "20231115.2126" "Help keeping ~/.config/emacs clean"
  '((emacs "25.1")
    (compat "29.1.4.2"))
  :commit "722c44210a5f2697f449bd6cb2cdcff638b8c0bd" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("convenience")
  :url "https://github.com/emacscollective/no-littering")
;; Local Variables:
;; no-byte-compile: t
;; End:
