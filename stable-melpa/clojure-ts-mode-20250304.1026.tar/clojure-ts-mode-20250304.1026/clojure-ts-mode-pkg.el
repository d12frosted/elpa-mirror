;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20250304.1026"
  "Major mode for Clojure code."
  '((emacs "29.1"))
  :url "http://github.com/clojure-emacs/clojure-ts-mode"
  :commit "bec7871c123e379e561c822852847b25cddcd40b"
  :revdesc "bec7871c123e"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Danny Freeman" . "danny@dfreeman.email")))
