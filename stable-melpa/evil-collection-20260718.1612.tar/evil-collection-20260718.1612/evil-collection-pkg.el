;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260718.1612"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "29acaa81d2992d9c89a4b15ead917abb3af05228"
  :revdesc "29acaa81d299"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
