;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260520.1813"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "f16c781ef3ef371519d574e725bfba3da99817c3"
  :revdesc "f16c781ef3ef"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
