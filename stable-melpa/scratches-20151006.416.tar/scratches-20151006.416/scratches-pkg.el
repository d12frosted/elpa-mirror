;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scratches" "20151006.416"
  "Multiple scratches in any language."
  '((dash "2.11.0")
    (f    "0.17.0"))
  :url "https://github.com/victorteokw/scratches"
  :commit "9441afe6396ca38f08029123fab5d87429cbf315"
  :revdesc "9441afe6396c"
  :keywords '("scratch")
  :authors '(("Zhang Kai Yu" . "yeannylam@gmail.com"))
  :maintainers '(("Zhang Kai Yu" . "yeannylam@gmail.com")))
