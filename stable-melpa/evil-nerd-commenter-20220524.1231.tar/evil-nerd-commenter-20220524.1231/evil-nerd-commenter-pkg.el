(define-package "evil-nerd-commenter" "20220524.1231" "Comment/uncomment lines efficiently. Like Nerd Commenter in Vim"
  '((emacs "25.1"))
  :commit "3ca33ee87a4930ff141ff9ea934aab66ca1a811c" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("convenience" "evil")
  :url "http://github.com/redguardtoo/evil-nerd-commenter")
;; Local Variables:
;; no-byte-compile: t
;; End:
