(define-package "evil-nerd-commenter" "20220524.1231" "Comment/uncomment lines efficiently. Like Nerd Commenter in Vim"
  '((emacs "25.1"))
  :commit "73b230073e4535391c6c6be499d2dc45a39f91c2" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("convenience" "evil")
  :url "http://github.com/redguardtoo/evil-nerd-commenter")
;; Local Variables:
;; no-byte-compile: t
;; End:
