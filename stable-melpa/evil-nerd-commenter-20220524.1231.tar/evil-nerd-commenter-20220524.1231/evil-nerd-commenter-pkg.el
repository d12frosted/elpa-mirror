(define-package "evil-nerd-commenter" "20220524.1231" "Comment/uncomment lines efficiently. Like Nerd Commenter in Vim"
  '((emacs "25.1"))
  :commit "5773a95a57862267aca055fdba5bb21f05bd5ea1" :authors
  '(("Chen Bin" . "chenbin.sh@gmail.com"))
  :maintainer
  '("Chen Bin" . "chenbin.sh@gmail.com")
  :keywords
  '("convenience" "evil")
  :url "http://github.com/redguardtoo/evil-nerd-commenter")
;; Local Variables:
;; no-byte-compile: t
;; End:
