;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile" "20260704.449"
  "Manage and navigate projects in Emacs easily."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/bbatsov/projectile"
  :commit "62247042d38223b1420de5302dc0ff0f9282ab75"
  :revdesc "62247042d382"
  :keywords '("project" "convenience")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
