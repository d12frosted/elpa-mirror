(define-package "live-py-mode" "20220404.0" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "342a4ec24c20539dc617511f4daf4abb04f17dc3" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
