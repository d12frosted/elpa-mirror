(define-package "live-py-mode" "20220404.0" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "09ae89505a7b411ab659bba83dd1a2a26a584a2e" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
