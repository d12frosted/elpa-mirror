(define-package "exwm-x" "20210417.653" "A derivative wm based on EXWM (emacs x window manager)"
  '((cl-lib "0.5")
    (async "1.6")
    (exwm "0.22"))
  :commit "8fd00a0ca586e1c80d08209919f1414b448bc228" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("window-manager" "exwm")
  :url "https://github.com/tumashu/exwm-x")
;; Local Variables:
;; no-byte-compile: t
;; End:
