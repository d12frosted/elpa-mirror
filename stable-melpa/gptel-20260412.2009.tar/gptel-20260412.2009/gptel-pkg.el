;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260412.2009"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "a964753863d1fdbaf05e21e1e90ad81addcd0d2a"
  :revdesc "a964753863d1"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
