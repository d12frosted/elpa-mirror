(define-package "vulpea" "20240712.1552" "A collection of org-roam note-taking functions"
  '((emacs "27.2")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12")
    (dash "2.19"))
  :commit "985187c44c21ff00e9da01879c89d01dc37d1eee" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
