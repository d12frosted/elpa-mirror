;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pcomplete-extension" "20190928.519"
  "Additional completion for pcomplete."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/thierryvolpiatto/pcomplete-extension"
  :commit "bc5eb204fee659e0980056009409b44bc7655716"
  :revdesc "bc5eb204fee6"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
