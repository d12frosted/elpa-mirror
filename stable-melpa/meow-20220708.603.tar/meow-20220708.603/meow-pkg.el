(define-package "meow" "20220708.603" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "10cae35366758cf018c1f3cb6cb0c81087da079e" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
