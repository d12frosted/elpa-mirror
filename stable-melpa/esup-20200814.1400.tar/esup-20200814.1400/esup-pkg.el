(define-package "esup" "20200814.1400" "The Emacs StartUp Profiler (ESUP)"
  '((cl-lib "0.5")
    (s "1.2")
    (emacs "25.1"))
  :commit "0ef8b536253c11da44a6788cc2c6e4d0ba7bbd6e" :keywords
  ("convenience" "processes")
  :authors
  (("Joe Schafer" . "joe@jschaf.com"))
  :maintainer
  ("Serghei Iakovlev" . "egrep@protonmail.ch")
  :url "https://github.com/jschaf/esup")
;; Local Variables:
;; no-byte-compile: t
;; End:
