(define-package "memento-mori" "20231128.1725" "Reminder of mortality"
  '((emacs "24.3"))
  :commit "a6b20d54eba11c72872d02930f290dbbb5de17b9" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("help")
  :url "https://github.com/lassik/emacs-memento-mori")
;; Local Variables:
;; no-byte-compile: t
;; End:
