;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magik-mode" "20250318.1157"
  "Emacs major mode for Smallworld Magik files."
  '((emacs     "24.4")
    (compat    "28.1")
    (yasnippet "0.14.0"))
  :url "https://github.com/roadrunner1776/magik"
  :commit "4265c18b88af10ae120e76f817f4eaa56f5bcaeb"
  :revdesc "4265c18b88af"
  :keywords '("languages"))
