;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241126.1727"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.71.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "ec08e66d905af60fa38e4c711f608e8ee2f8a948"
  :revdesc "ec08e66d905a")
