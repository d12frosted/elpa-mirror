;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "srfi" "20261029.2200"
  "Scheme Requests for Implementation browser."
  '((emacs "25.1"))
  :url "https://github.com/srfi-explorations/emacs-srfi"
  :commit "f08f9c52bae3edd0e05d328d8a3a1ee6755c0076"
  :revdesc "f08f9c52bae3"
  :keywords '("languages" "util")
  :authors '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers '(("Lassi Kortela" . "lassi@lassi.io")))
