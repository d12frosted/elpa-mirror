(define-package "stimmung-themes" "20220210.1829" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "ce7c9805c9030fe28c4f29720bfe413ee4674c2d" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
