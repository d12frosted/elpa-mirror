(define-package "hl-indent-scope" "20220913.1050" "Highlight indentation by scope"
  '((emacs "26.1"))
  :commit "d7e660860623818ab86c58e8f725a0e6f622bcc7" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-hl-indent-scope")
;; Local Variables:
;; no-byte-compile: t
;; End:
