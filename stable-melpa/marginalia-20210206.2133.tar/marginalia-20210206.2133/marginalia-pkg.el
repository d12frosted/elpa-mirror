(define-package "marginalia" "20210206.2133" "Enrich existing commands with completion annotations"
  '((emacs "26.1"))
  :commit "86c0461271d407f5676a8af3776e73832458364f" :authors
  '(("Omar Antolín Camarena, Daniel Mendler"))
  :maintainer
  '("Omar Antolín Camarena, Daniel Mendler")
  :url "https://github.com/minad/marginalia")
;; Local Variables:
;; no-byte-compile: t
;; End:
