(define-package "ergoemacs-mode" "20161013.427" "Emacs mode based on common modern interface and ergonomics."
  '((emacs "24.1")
    (undo-tree "0.6.5")
    (cl-lib "0.5"))
  :commit "ac70b2563fb6e3d69ea382fddc87b5721c20c292" :authors
  '(("Xah Lee" . "xah@xahlee.org")
    ("David Capello" . "davidcapello@gmail.com")
    ("Matthew L. Fidler" . "matthew.fidler@gmail.com"))
  :maintainer
  '("Matthew L. Fidler" . "matthew.fidler@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/ergoemacs/ergoemacs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
