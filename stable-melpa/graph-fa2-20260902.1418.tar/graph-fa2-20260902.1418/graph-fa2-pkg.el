;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "graph-fa2" "20260902.1418"
  "ForceAtlas2 pure-elisp background-cached engine."
  '((emacs "27.1"))
  :url "https://github.com/elij/graph-fa2"
  :commit "09e207210094a297949eaa1729dd1a995cc3d6e7"
  :revdesc "09e207210094"
  :keywords '("multimedia" "graphs" "visualization")
  :authors '(("Elijah Charles" . "https://github.com/elij"))
  :maintainers '(("Elijah Charles" . "https://github.com/elij")))
