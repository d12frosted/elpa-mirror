(define-package "consult" "20220807.1302" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "61f13b9d40d2e18d6a08e1d035c2673a5b727ee3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
