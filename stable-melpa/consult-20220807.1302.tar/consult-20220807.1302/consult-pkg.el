(define-package "consult" "20220807.1302" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "90536f39db3bd9085971998308ee42176613d68f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
