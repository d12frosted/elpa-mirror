;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "calle24" "20250315.334"
  "Emacs Toolbar Support for SF Symbols."
  '((emacs "29.1"))
  :url "https://github.com/kickingvegas/calle24"
  :commit "073f12bb5324e1b4a68f71a0dd7f488c52dbaca9"
  :revdesc "073f12bb5324"
  :keywords '("tools")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
