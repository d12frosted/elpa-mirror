;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "projectile-rails" "20261001.756"
  "Minor mode for Rails projects based on projectile-mode."
  '((emacs       "28.1")
    (projectile  "0.12.0")
    (inflections "1.1")
    (inf-ruby    "2.2.6")
    (f           "0.13.0")
    (rake        "0.3.2")
    (dash        "2.18.1"))
  :url "https://github.com/asok/projectile-rails"
  :commit "8760b6fe348524d6fbd854e347204f297ad50a82"
  :revdesc "8760b6fe3485"
  :keywords '("rails" "tools" "projectile")
  :authors '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com"))
  :maintainers '(("Adam Sokolnicki" . "adam.sokolnicki@gmail.com")))
