;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260208.1919"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "6db6fb1aeb4bd499eead03e63763784334f1db7d"
  :revdesc "6db6fb1aeb4b")
