;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "magnus" "20260227.413"
  "Manage multiple Claude Code instances."
  '((emacs     "28.1")
    (vterm     "0.0.2")
    (transient "0.4.0"))
  :url "https://github.com/hrishikeshs/magnus"
  :commit "3e1c4af42c73bc3a9e3d700d190ac9d7f4853b78"
  :revdesc "3e1c4af42c73"
  :keywords '("tools" "processes" "convenience")
  :authors '(("Hrishikesh S" . "hrish2006@gmail.com"))
  :maintainers '(("Hrishikesh S" . "hrish2006@gmail.com")))
