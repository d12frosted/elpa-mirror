(define-package "geiser-gambit" "20210405.1925" "Gambit's implementation of the geiser protocols"
  '((emacs "26.1")
    (geiser "0.12"))
  :commit "0ee4156640988497779345452c3aa0417356e606" :authors
  '(("Daniel Leslie"))
  :maintainer
  '("Daniel Leslie, Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "gambit" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/gambit")
;; Local Variables:
;; no-byte-compile: t
;; End:
