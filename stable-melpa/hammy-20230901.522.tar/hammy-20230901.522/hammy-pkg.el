(define-package "hammy" "20230901.522" "Programmable, interactive interval timers"
  '((emacs "28.1")
    (svg-lib "0.2.5")
    (ts "0.2.2"))
  :commit "1ee56a6b274533328ee6fc456cc2a9f7ea69cc80" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("convenience")
  :url "https://github.com/alphapapa/hammy.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
