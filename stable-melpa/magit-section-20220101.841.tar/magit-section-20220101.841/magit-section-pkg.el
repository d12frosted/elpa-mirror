(define-package "magit-section" "20220101.841" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "4e29d5827cb77a7fbcff57033a099e23b8edd424" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
