;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260908.752"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "0fb77593d449d15722847a650c99516b14f81c43"
  :revdesc "0fb77593d449"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
