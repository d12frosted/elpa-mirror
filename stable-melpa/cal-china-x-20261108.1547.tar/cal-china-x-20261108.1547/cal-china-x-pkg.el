;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cal-china-x" "20261108.1547"
  "Chinese localization, lunar/horoscope/zodiac info and more..."
  '((emacs  "24.4")
    (cl-lib "0.5"))
  :url "https://github.com/xwl/cal-china-x"
  :commit "416aa925cbad8beea6473fc5e61ef1a5380f3036"
  :revdesc "416aa925cbad"
  :authors '(("William Xu" . "william.xwl@gmail.com"))
  :maintainers '(("William Xu" . "william.xwl@gmail.com")))
