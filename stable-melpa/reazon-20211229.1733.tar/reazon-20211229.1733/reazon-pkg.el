(define-package "reazon" "20211229.1733" "miniKanren for Emacs"
  '((emacs "26"))
  :commit "da3c4a8acf236eddb73348056e08bea330e868c0" :authors
  '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainer
  '("Nick Drozd" . "nicholasdrozd@gmail.com")
  :keywords
  '("languages" "extensions" "lisp")
  :url "https://github.com/nickdrozd/reazon")
;; Local Variables:
;; no-byte-compile: t
;; End:
