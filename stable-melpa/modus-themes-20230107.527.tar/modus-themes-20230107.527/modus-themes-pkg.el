(define-package "modus-themes" "20230107.527" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "4455e93bc52f5cd5231152a9be4cf50a14fa22b7" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
