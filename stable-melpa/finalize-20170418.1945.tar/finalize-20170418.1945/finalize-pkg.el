(define-package "finalize" "20170418.1945" "finalizers for Emacs Lisp"
  '((emacs "24.1")
    (cl-generic "0.3")
    (cl-lib "0.3")
    (eieio "1.4"))
  :commit "0f7d47c4d50f1c76fc3b43bfc2d4886dd3e8ca27" :authors
  '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainer
  '("Christopher Wellons" . "wellons@nullprogram.com")
  :url "https://github.com/skeeto/elisp-finalize")
;; Local Variables:
;; no-byte-compile: t
;; End:
