(define-package "zotra" "20231012.2322" "Import bibliographic data from (almost) everywhere"
  '((emacs "27.1"))
  :commit "035e2c1a4299ea36a40f75ca6a585b1b979bc343" :authors
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainers
  '(("Mohammad Pedramfar <https://github.com/mpedramfar>"))
  :maintainer
  '("Mohammad Pedramfar <https://github.com/mpedramfar>")
  :url "https://github.com/mpedramfar/zotra")
;; Local Variables:
;; no-byte-compile: t
;; End:
