;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "face-explorer" "20250117.932"
  "Tools for faces and text properties."
  ()
  :url "https://github.com/Lindydancer/face-explorer"
  :commit "4dc83bffbaf41c22795556fed63f8dc938efd9b8"
  :revdesc "4dc83bffbaf4"
  :keywords '("faces"))
