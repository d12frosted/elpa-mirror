(define-package "sculpture-themes" "20220515.1006" "Themes with vivid colors"
  '((emacs "26.1"))
  :commit "d779c5f5f58409c5e4394c881e86bc11399b8f5c" :authors
  '(("t-e-r-m" . "newenewen@tutanota.com"))
  :maintainer
  '("t-e-r-m" . "newenewen@tutanota.com")
  :url "https://github.com/t-e-r-m/sculpture-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
