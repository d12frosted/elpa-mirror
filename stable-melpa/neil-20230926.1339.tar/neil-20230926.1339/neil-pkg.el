(define-package "neil" "20230926.1339" "companion for Babashka Neil"
  '((emacs "27.1"))
  :commit "1e717dd897d2d3a4a8cdc4f64da06e1b13cfb6cc" :authors
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers
  '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainer
  '("Ag Ibragimov" . "agzam.ibragimov@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/babashka/neil")
;; Local Variables:
;; no-byte-compile: t
;; End:
