;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20260126.1253"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "90b14a20bf863c4b6df0cc79c8b5f776f87a4687"
  :revdesc "90b14a20bf86"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
