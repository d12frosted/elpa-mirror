;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "alectryon" "20260406.2342"
  "Toggle between Code and markup."
  '((flycheck "31")
    (emacs    "25.1"))
  :url "https://github.com/cpitclaudel/alectryon"
  :commit "86bac4eae28c2d6f27859a4ca8821a374e8b1c4f"
  :revdesc "86bac4eae28c"
  :keywords '("convenience" "languages" "tools")
  :authors '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com"))
  :maintainers '(("Clément Pit-Claudel" . "clement.pitclaudel@live.com")))
