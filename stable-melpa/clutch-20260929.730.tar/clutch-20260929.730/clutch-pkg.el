;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260929.730"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "1cf619cc08b1cfb9800ce1f0d00bbd40be774c0c"
  :revdesc "1cf619cc08b1"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
