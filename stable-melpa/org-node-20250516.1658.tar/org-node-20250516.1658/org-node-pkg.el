;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250516.1658"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.8.2")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "219b0f93d7442df865cc4cf5cb64c21c78e106c7"
  :revdesc "219b0f93d744"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
