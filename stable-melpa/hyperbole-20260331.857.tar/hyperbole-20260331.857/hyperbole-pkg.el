;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260331.857"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "9f451d2cd57d74b5875a004d344bec947951cc69"
  :revdesc "9f451d2cd57d"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
