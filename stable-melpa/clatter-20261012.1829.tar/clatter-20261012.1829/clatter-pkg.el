;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20261012.1829"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "d8ef0fe2f5dcbaa8e143e0d149260c736267881d"
  :revdesc "d8ef0fe2f5dc"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
