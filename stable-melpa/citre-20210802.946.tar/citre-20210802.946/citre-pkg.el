(define-package "citre" "20210802.946" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "b74147e2a166e27c7c6074ffeaa5f273d4f938bf" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
