;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260125.1207"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "8d9a1646fb4014a5d34f3f19b7c894310f06a1e8"
  :revdesc "8d9a1646fb40"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
