(define-package "company-spell" "20230813.1514" "Autocompleting spelling for Company"
  '((emacs "24.4")
    (company "0.9.13"))
  :commit "67eb760210b3463202933a15e83bf8ac0e6f913e" :keywords
  '("wp")
  :url "https://github.com/enzuru/company-spell")
;; Local Variables:
;; no-byte-compile: t
;; End:
