(define-package "fsharp-mode" "20210124.1403" "Support for the F# programming language"
  '((emacs "25")
    (s "1.3.1"))
  :commit "5ff172316534f57ed02657d7dc0508e11ff89d3f" :authors
  '(("1993-1997 Xavier Leroy, Jacques Garrigue and Ian T Zimmerman")
    ("2010-2011 Laurent Le Brun" . "laurent@le-brun.eu")
    ("2012-2014 Robin Neatherway" . "robin.neatherway@gmail.com")
    ("2017-2021 Jürgen Hötzel"))
  :maintainer
  '("Jürgen Hötzel")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
