(define-package "citre" "20210908.1527" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "b9bca2d86f58d59e7e170f7224c78753c18e58a8" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
