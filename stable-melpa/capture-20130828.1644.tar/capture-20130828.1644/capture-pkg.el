;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "capture" "20130828.1644"
  "Screencasting with \"avconv\" or \"ffmpeg\"."
  ()
  :url "https://github.com/pashinin/capture.el"
  :commit "9140c207b48b3520a2f06674b3e1bee2fc92b80c"
  :revdesc "9140c207b48b"
  :authors '(("Sergey Pashinin" . "sergeyatpashinindotcom"))
  :maintainers '(("Sergey Pashinin" . "sergeyatpashinindotcom")))
