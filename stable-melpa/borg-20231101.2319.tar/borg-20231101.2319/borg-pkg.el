(define-package "borg" "20231101.2319" "Assimilate Emacs packages as Git submodules"
  '((emacs "27.1")
    (epkg "3.3.3")
    (magit "3.3.0"))
  :commit "d8aecb09193448de12d5a19ac7bf242f3c39e767" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/borg")
;; Local Variables:
;; no-byte-compile: t
;; End:
