(define-package "adwaita-dark-theme" "20231128.1635" "A dark color scheme inspired by Adwaita"
  '((emacs "27.1"))
  :commit "a7c9b66e27761448604cf32037014a4d312bb6e8" :authors
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainers
  '(("Jessie Hildebrandt <jessieh.net>"))
  :maintainer
  '("Jessie Hildebrandt <jessieh.net>")
  :keywords
  '("mode-line" "faces")
  :url "https://gitlab.com/jessieh/adwaita-dark-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
