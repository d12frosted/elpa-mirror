(define-package "vhdl-ext" "20230911.1633" "VHDL Extensions"
  '((emacs "29.1")
    (vhdl-ts-mode "0.0.0")
    (eglot "1.9")
    (lsp-mode "8.0.0")
    (ag "0.48")
    (ripgrep "0.4.0")
    (hydra "0.15.0")
    (flycheck "32")
    (company "0.9.13")
    (outshine "3.0.1")
    (async "1.9.7"))
  :commit "aaf7b7e70b366cb70a36af6d9520d498eb179f0d" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("vhdl" "ide" "tools")
  :url "https://github.com/gmlarumbe/vhdl-ext")
;; Local Variables:
;; no-byte-compile: t
;; End:
