(define-package "org-gtd" "20230519.1524" "An implementation of GTD."
  '((emacs "27.2")
    (org-edna "1.1.2")
    (f "0.20.0")
    (org "9.6")
    (org-agenda-property "1.3.1")
    (transient "0.3.7"))
  :commit "be1c5136cde09b3c799722189651e5ef51ef2ba8" :authors
  '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainer
  '("Aldric Giacomoni" . "trevoke@gmail.com")
  :url "https://github.com/Trevoke/org-gtd.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
