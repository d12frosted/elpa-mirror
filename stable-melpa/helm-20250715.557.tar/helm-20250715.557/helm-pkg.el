;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250715.557"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0.4")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "e6dce5a8fcb254da7a2be744c361fd3ff3fe6d3d"
  :revdesc "e6dce5a8fcb2"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
