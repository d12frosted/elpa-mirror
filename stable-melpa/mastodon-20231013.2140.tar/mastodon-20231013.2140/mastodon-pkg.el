(define-package "mastodon" "20231013.2140" "Client for fediverse services using the Mastodon API"
  '((emacs "27.1")
    (request "0.3.0")
    (persist "0.4"))
  :commit "2cb0a5012af337dd99663d0a3cbbebd332009633" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com")
    ("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainers
  '(("Marty Hiatt" . "martianhiatus@riseup.net"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
