;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "immersive-translate" "20231001.1557"
  "Translate the current buffer immersively."
  '((emacs "28.2"))
  :url "https://github.com/Elilif/emacs-immersive-translate"
  :commit "1d00d558363985fa988fc40cd5093bfc6926d83e"
  :revdesc "1d00d5583639"
  :keywords '("convenience" "help" "translate")
  :authors '(("Eli Qian" . "eli.q.qian@gmail.com"))
  :maintainers '(("Eli Qian" . "eli.q.qian@gmail.com")))
