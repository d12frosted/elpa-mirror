(define-package "ptemplate-templates" "20201116.1656" "Official templates"
  '((emacs "25.1")
    (ptemplate "2.0.0"))
  :commit "84474713f4772ef0962bb9eb01c00be85fbb258b" :authors
  (("Nikita Bloshchanevich" . "nikblos@outlook.com"))
  :maintainer
  ("Nikita Bloshchanevich" . "nikblos@outlook.com")
  :url "https://github.com/nbfalcon/ptemplate-templates")
;; Local Variables:
;; no-byte-compile: t
;; End:
