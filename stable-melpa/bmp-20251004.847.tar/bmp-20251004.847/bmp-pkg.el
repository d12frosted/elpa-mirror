;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bmp" "20251004.847"
  "Version bumper for git projects."
  '((emacs "29"))
  :url "https://git.sr.ht/~lepisma/bmp"
  :commit "63aeacf69a12aa8b47ae4d9e2d859e5d1c954012"
  :revdesc "63aeacf69a12"
  :authors '(("Abhinav Tushar" . "lepisma@fastmail.com"))
  :maintainers '(("Abhinav Tushar" . "lepisma@fastmail.com")))
