;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-mouse" "20251120.1523"
  "Display documentation for mouse hover."
  '((emacs    "30.1")
    (posframe "1.4.0")
    (eglot    "1.8"))
  :url "https://github.com/huangfeiyu/eldoc-mouse"
  :commit "a827f16c6145f6b42a450b72cb068371c5bdbd5d"
  :revdesc "a827f16c6145"
  :keywords '("tools" "languages" "convenience" "emacs" "mouse" "hover")
  :authors '((nil . "HuangFeiyusibadake1@163.com"))
  :maintainers '((nil . "HuangFeiyusibadake1@163.com")))
