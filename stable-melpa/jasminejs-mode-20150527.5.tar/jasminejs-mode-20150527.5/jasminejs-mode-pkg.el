;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jasminejs-mode" "20150527.5"
  "A minor mode for manipulating jasmine test files."
  ()
  :url "https://github.com/stoltene2/jasminejs-mode"
  :commit "23637d6718423d376eebbdaa4d6d914c7cab26ed"
  :revdesc "23637d671842"
  :keywords '("javascript" "jasmine")
  :authors '(("Eric Stolten" . "stoltene2@gmail.com"))
  :maintainers '(("Eric Stolten" . "stoltene2@gmail.com")))
