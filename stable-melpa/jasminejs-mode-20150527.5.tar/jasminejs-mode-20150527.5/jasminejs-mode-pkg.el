(define-package "jasminejs-mode" "20150527.5" "A minor mode for manipulating jasmine test files" 'nil :commit "9f8044bf81ab5b4841a30b0bd099916e1b7ff54a" :keywords
  ("javascript" "jasmine")
  :authors
  (("Eric Stolten" . "stoltene2@gmail.com"))
  :maintainer
  ("Eric Stolten" . "stoltene2@gmail.com")
  :url "https://github.com/stoltene2/jasminejs-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
