(define-package "embark" "20210520.1753" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "a21e510bc63c8ddc98b2bb3e6fff38e9d7f41ca9" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
