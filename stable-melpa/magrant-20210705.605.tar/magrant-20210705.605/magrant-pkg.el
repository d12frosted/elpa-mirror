(define-package "magrant" "20210705.605" "Transient Interface to Vagrant"
  '((emacs "25.1")
    (dash "2.17.0")
    (s "1.12.0")
    (tablist "0.70")
    (transient "0.2.0")
    (friendly-shell-command "0.2.3"))
  :commit "2e14d3e46736a830f207adad58894347efa5cd4d" :keywords
  '("processes" "terminals")
  :url "https://github.com/p3r7/magrant")
;; Local Variables:
;; no-byte-compile: t
;; End:
