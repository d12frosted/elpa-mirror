;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260521.1427"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Kilo, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5bd2d976aaf29206854715512a9de50f4a9cafc3"
  :revdesc "5bd2d976aaf2"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
