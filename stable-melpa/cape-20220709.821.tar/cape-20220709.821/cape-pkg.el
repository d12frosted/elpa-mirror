(define-package "cape" "20220709.821" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "7042b048c8820223551d75c643b958befe7411d2" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
