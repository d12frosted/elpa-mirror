;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chruby" "20180114.1652"
  "Emacs integration for chruby."
  '((cl-lib "0.5"))
  :url "https://github.com/plexus/chruby.el"
  :commit "42bc6d521f832eca8e2ba210f30d03ad5529788f"
  :revdesc "42bc6d521f83"
  :keywords '("languages")
  :authors '(("Arne Brasseur" . "arne@arnebrasseur.net"))
  :maintainers '(("Arne Brasseur" . "arne@arnebrasseur.net")))
