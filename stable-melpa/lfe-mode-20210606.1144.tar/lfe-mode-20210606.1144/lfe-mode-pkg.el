(define-package "lfe-mode" "20210606.1144" "Lisp Flavoured Erlang mode" 'nil :commit "c09b9aebaa659f5c2d0c152d8401fd6924144ce9")
;; Local Variables:
;; no-byte-compile: t
;; End:
