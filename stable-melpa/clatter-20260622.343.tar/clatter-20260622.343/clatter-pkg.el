;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260622.343"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "8b1ae9949717da2491d4a0d869592a2c4d6ba2bf"
  :revdesc "8b1ae9949717"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
