;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260410.332"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "2e70c8411be374ce6e29d06da7103e51982191e8"
  :revdesc "2e70c8411be3"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
