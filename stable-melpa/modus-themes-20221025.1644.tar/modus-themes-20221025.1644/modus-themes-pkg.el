(define-package "modus-themes" "20221025.1644" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "638e92c4811ece5753ed8d7dccc1ce23983ba70c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
