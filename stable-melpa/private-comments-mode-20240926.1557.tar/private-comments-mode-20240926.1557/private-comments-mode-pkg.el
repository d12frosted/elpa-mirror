;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "private-comments-mode" "20240926.1557"
  "Minor mode for masukomi/private_comments."
  '((emacs "27.1"))
  :url "https://github.com/masukomi/private-comments-mode"
  :commit "616d63eccc5a21f1785801baf0fa3667ddfeb80f"
  :revdesc "616d63eccc5a"
  :keywords '("tools")
  :authors '(("Richard Chiang" . "richard@commandlinesystems.com")
             ("Kay Rhodes" . "masukomi@masukomi.org"))
  :maintainers '(("Richard Chiang" . "richard@commandlinesystems.com")
                 ("Kay Rhodes" . "masukomi@masukomi.org")))
