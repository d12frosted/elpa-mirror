;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nimbus-theme" "20260906.2223"
  "Nimbus dark theme."
  '((emacs "27.1"))
  :url "https://github.com/mrcnski/nimbus-theme"
  :commit "92b267a9a41506d4793b333c4a7f1b1b3c17625e"
  :revdesc "92b267a9a415"
  :keywords '("faces")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
