(define-package "org-ai" "20230905.1738" "Use ChatGPT and other LLMs in org-mode and beyond"
  '((emacs "27.1")
    (websocket "1.15"))
  :commit "5b187ba1225ec2790976289fd04b8b19804f2155" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
