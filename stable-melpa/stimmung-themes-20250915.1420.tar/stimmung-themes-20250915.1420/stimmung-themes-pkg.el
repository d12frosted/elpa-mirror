;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "stimmung-themes" "20250915.1420"
  "Themes tuned to inner harmonies."
  '((emacs "25"))
  :url "https://github.com/motform/stimmung-themes"
  :commit "bb3410593bb7ecf3c4094396f488e5c64efdb051"
  :revdesc "bb3410593bb7"
  :keywords '("faces"))
