;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "speed-type" "20251123.810"
  "Practice touch and speed typing."
  '((emacs  "26.1")
    (compat "29.1.3"))
  :url "https://github.com/dakra/speed-type"
  :commit "fb134c158cb00637a3d6d250f19044352a1065a5"
  :revdesc "fb134c158cb0"
  :keywords '("games")
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
