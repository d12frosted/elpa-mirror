;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kkp" "20261105.1240"
  "Enable support for the Kitty Keyboard Protocol."
  '((emacs  "27.1")
    (compat "29.1.3.4"))
  :url "https://github.com/benotn/kkp"
  :commit "f6e9f8166995591a3ac1f62c79deebe93865ac49"
  :revdesc "f6e9f8166995"
  :keywords '("terminals")
  :authors '(("Benjamin Orthen" . "contact@orthen.net"))
  :maintainers '(("Benjamin Orthen" . "contact@orthen.net")))
