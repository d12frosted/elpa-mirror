(define-package "gofmt-tag" "20231008.2315" "Format and align go struct tags"
  '((emacs "27"))
  :commit "45295db2106140cde6099b15847de79076468405" :authors
  '(("ybenel <http://github/m1ndo>"))
  :maintainers
  '(("ybenel" . "root@ybenel.cf"))
  :maintainer
  '("ybenel" . "root@ybenel.cf")
  :keywords
  '("tools" "wp" "matching")
  :url "https://github.com/m1ndo/gofmt-tag")
;; Local Variables:
;; no-byte-compile: t
;; End:
