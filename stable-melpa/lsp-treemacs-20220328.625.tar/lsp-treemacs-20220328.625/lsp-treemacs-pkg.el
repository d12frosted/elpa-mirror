(define-package "lsp-treemacs" "20220328.625" "LSP treemacs"
  '((emacs "26.1")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.0")
    (treemacs "2.5")
    (lsp-mode "6.0"))
  :commit "b330241cdba9826a82c0b9a00ebf74e2e4d21e93" :authors
  '(("Ivan Yonchovski"))
  :maintainer
  '("Ivan Yonchovski")
  :keywords
  '("languages")
  :url "https://github.com/emacs-lsp/lsp-treemacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
