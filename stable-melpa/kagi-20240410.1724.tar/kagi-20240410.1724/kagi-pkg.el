(define-package "kagi" "20240410.1724" "Kagi API integration"
  '((emacs "29.1")
    (shell-maker "0.46.1"))
  :commit "ddbc23ce635eca689e29e27ed1491c441d68fdf3" :authors
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainers
  '(("Bram Schoenmakers" . "me@bramschoenmakers.nl"))
  :maintainer
  '("Bram Schoenmakers" . "me@bramschoenmakers.nl")
  :keywords
  '("terminals" "wp")
  :url "https://codeberg.org/bram85/kagi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
