(define-package "helm" "20240909.1610" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "4.0")
    (wfnames "1.2"))
  :commit "df53496c442615e2d3ae5281a7dacbb5f2362310" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
