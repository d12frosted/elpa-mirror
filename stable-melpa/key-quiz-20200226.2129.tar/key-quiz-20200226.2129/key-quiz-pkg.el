;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "key-quiz" "20200226.2129"
  "Emacs Keys Quiz."
  '((emacs "26"))
  :url "https://github.com/federicotdn/key-quiz"
  :commit "1ee67f3f8977d95785e021f7896685de1979137e"
  :revdesc "1ee67f3f8977"
  :keywords '("games")
  :authors '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers '(("Federico Tedin" . "federicotedin@gmail.com")))
