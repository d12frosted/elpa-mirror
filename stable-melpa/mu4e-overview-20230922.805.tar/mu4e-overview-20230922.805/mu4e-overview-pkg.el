(define-package "mu4e-overview" "20230922.805" "Show overview of maildir"
  '((emacs "26"))
  :commit "36869cf2f880595f1d6781a1aa8c9b513b055e04" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("mail" "tools")
  :url "https://github.com/mkcms/mu4e-overview")
;; Local Variables:
;; no-byte-compile: t
;; End:
