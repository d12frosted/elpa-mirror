;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260527.1159"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "5c4d693d54a420cf505b516d0a3912faed4b8c0c"
  :revdesc "5c4d693d54a4"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
