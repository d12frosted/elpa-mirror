(define-package "consult" "20210116.19" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "d11cdb239008903158bf4531c19be5d568d6a86d" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
