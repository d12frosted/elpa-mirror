;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm" "20250104.1759"
  "Helm is an Emacs incremental and narrowing framework."
  '((helm-core "4.0")
    (wfnames   "1.2"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "3372d13b928ffc3977516eb5a397ab3a555559ce"
  :revdesc "3372d13b928f"
  :keywords '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
