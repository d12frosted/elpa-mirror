(define-package "epkg" "20220423.1552" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "28.1.1.0")
    (closql "20210927"))
  :commit "5dd40e242f305859a26ebbd6249e7cbf7361e005" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
