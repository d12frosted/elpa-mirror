;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20251216.2222"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "96774809486ad32a79f7883e8fbc4a44a8708d96"
  :revdesc "96774809486a"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
