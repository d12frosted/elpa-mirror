;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260503.1601"
  "A set of keybindings for Evil mode."
  '((emacs    "26.3")
    (evil     "1.2.13")
    (annalist "1.0"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "468653805b5a9c44275dfc6add70ed84fcd7e740"
  :revdesc "468653805b5a"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
