;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251112.1229"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "0cd0b3cc7b413cdd233fb65503abd51dbbae8dbb"
  :revdesc "0cd0b3cc7b41"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
