(define-package "meow" "20220425.1626" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "2144ef179bce8338b45f91a1d538c33e2f53771e" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
