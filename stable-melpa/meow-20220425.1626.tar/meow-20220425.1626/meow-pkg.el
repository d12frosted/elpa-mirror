(define-package "meow" "20220425.1626" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "8cfc0b0ecc03f0a017cf2ec96530c1e5c291394c" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
