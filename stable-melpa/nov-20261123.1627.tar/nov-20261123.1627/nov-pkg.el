;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nov" "20261123.1627"
  "Featureful EPUB reader mode."
  '((esxml "0.3.6")
    (emacs "25.1"))
  :url "https://depp.brause.cc/nov.el"
  :commit "ac62554d90a24939b980a3a43564c2bc093fcf2b"
  :revdesc "ac62554d90a2"
  :keywords '("hypermedia" "multimedia" "epub")
  :authors '(("Vasilij Schneidermann" . "mail@vasilij.de"))
  :maintainers '(("Vasilij Schneidermann" . "mail@vasilij.de")))
