;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260222.442"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "48831f36bf7262d33cec19fa6bcafad6b7edfb59"
  :revdesc "48831f36bf72"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
