(define-package "helm-apt" "20231004.1029" "Helm interface for Debian/Ubuntu packages (apt-*)"
  '((helm "3.9.5")
    (emacs "25.1"))
  :commit "ebe71ec064f97b28419c07718e7205aeed533312" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://github.com/emacs-helm/helm-apt")
;; Local Variables:
;; no-byte-compile: t
;; End:
