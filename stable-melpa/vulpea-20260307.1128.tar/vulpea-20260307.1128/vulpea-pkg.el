;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260307.1128"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "62d0ccbded0bd84bf2e6d688ac5a4f97c66e077e"
  :revdesc "62d0ccbded0b"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
