(define-package "run-command-recipes" "20220129.805" "This is collection of recipes to `run-command'"
  '((emacs "25.1")
    (dash "2.18.0")
    (s "1.12.0")
    (f "0.20.0")
    (run-command "0.1.0"))
  :commit "9a91c0334e5d522abd7c40af9547eba03afff244" :authors
  '(("semenInRussia" . "hrams205@gmail.com"))
  :maintainer
  '("semenInRussia" . "hrams205@gmail.com")
  :keywords
  '("extensions" "run-command")
  :url "https://github.com/semenInRussia/emacs-run-command-recipes")
;; Local Variables:
;; no-byte-compile: t
;; End:
