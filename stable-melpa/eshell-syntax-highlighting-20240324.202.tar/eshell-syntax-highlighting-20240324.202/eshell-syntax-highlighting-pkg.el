(define-package "eshell-syntax-highlighting" "20240324.202" "Highlight eshell commands"
  '((emacs "25.1"))
  :commit "1ed10514959dc6f2a1b2d844d01f852ab3a81861" :authors
  '(("Alex Kreisher" . "akreisher18@gmail.com"))
  :maintainers
  '(("Alex Kreisher" . "akreisher18@gmail.com"))
  :maintainer
  '("Alex Kreisher" . "akreisher18@gmail.com")
  :keywords
  '("convenience")
  :url "https://github.com/akreisher/eshell-syntax-highlighting")
;; Local Variables:
;; no-byte-compile: t
;; End:
