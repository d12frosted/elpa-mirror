(define-package "modus-themes" "20220223.1441" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "a0ab3decab5c9e1dc7af32673b977701b7a68d0b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
