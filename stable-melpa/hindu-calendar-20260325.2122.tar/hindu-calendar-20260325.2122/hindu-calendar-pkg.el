;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hindu-calendar" "20260325.2122"
  "Astronomical traditional Hindu calendar (panchanga)."
  '((emacs "24.3"))
  :url "https://github.com/bdsatish/hindu-calendar"
  :commit "bd2cbd6475f718c1a172d25aa249e615a3b41125"
  :revdesc "bd2cbd6475f7"
  :keywords '("calendar" "panchanga" "hindu" "indian")
  :authors '(("B.D.Satish" . "bdsatish@gmail.com"))
  :maintainers '(("B.D.Satish" . "bdsatish@gmail.com")))
