(define-package "embark" "20210801.608" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "99b627382bbb55b1aa3df67f637127d9aabec69a" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
