;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dired-list" "20240318.845"
  "Create dired listings from sources."
  '((dash              "2.10.0")
    (emacs             "24.3")
    (dired-hacks-utils "0.0.1"))
  :url "https://github.com/Fuco1/dired-hacks"
  :commit "475be5486bc2d593283ba6e8c8c43053d4cbdd7f"
  :revdesc "475be5486bc2"
  :keywords '("files")
  :authors '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matúš Goljer" . "matus.goljer@gmail.com")))
