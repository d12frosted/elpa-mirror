;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "run-command" "20230317.2004"
  "Run an external command from a context-dependent list."
  '((emacs "27.1"))
  :url "https://github.com/bard/emacs-run-command"
  :commit "477c42acce9e36ec59d18deaa73992f94faf7b99"
  :revdesc "477c42acce9e"
  :keywords '("processes")
  :authors '(("Massimiliano Mirra" . "hyperstruct@gmail.com"))
  :maintainers '(("Massimiliano Mirra" . "hyperstruct@gmail.com")))
