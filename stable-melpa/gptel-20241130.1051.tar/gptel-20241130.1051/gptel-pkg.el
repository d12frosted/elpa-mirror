;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241130.1051"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "7cf8e3b19b81c82b2c4c6e3732db9fd449c67de9"
  :revdesc "7cf8e3b19b81"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
