;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20260607.1501"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "9079ae4da04d5f824c094e424946a9545a99db17"
  :revdesc "9079ae4da04d"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
