(define-package "gnus-notes" "20201214.1319" "Keep handy notes of read Gnus articles with helm and org"
  '((emacs "27.1")
    (bbdb "3.1")
    (helm "3.1")
    (hydra "0.13.0")
    (org "8.3")
    (s "0.0")
    (lv "0.0")
    (async "1.9.1"))
  :commit "0ebccc49962b3780b1e882a9a3abcc6441a12d9a" :keywords
  ("convenience" "mail" "bbdb" "gnus" "helm" "org" "hydra")
  :authors
  (("Deus Max" . "deusmax@gmx.com"))
  :maintainer
  ("Deus Max" . "deusmax@gmx.com")
  :url "https://github.com/deusmax/gnus-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
