(define-package "assess" "20220719.1904" "Test support functions"
  '((emacs "24.4")
    (m-buffer "0.15"))
  :commit "44083d94feb45d3636f7ee6c55e0ef6bbb32b938" :authors
  '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainers
  '(("Phillip Lord" . "phillip.lord@russet.org.uk"))
  :maintainer
  '("Phillip Lord" . "phillip.lord@russet.org.uk"))
;; Local Variables:
;; no-byte-compile: t
;; End:
