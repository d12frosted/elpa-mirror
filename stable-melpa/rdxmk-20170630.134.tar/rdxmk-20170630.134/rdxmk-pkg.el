(define-package "rdxmk" "20170630.134" "A small set of tools for redox developments" 'nil :commit "e78749fb29738365ffa4d863ffabeb969ebb0bcf" :authors
  (("Jacob Salzberg" . "jsalzbergedu@yahoo.com"))
  :maintainer
  ("Jacob Salzberg" . "jsalzbergedu@yahoo.com")
  :keywords
  ("redox" "convenience" "tools")
  :url "https://github.com/jsalzbergedu/rdxmk")
;; Local Variables:
;; no-byte-compile: t
;; End:
