(define-package "modus-themes" "20210517.659" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "400e1666e3bcb437692f3277084170f41c8141fa" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
