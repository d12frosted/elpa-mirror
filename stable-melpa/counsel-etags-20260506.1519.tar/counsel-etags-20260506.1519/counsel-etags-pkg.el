;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-etags" "20260506.1519"
  "Fast and complete Ctags solution using ivy."
  '((emacs   "29.1")
    (counsel "0.15.1"))
  :url "https://github.com/redguardtoo/counsel-etags"
  :commit "51f45e6c15727a8954c88a7fdab4294402510d82"
  :revdesc "51f45e6c1572"
  :keywords '("tools" "convenience"))
