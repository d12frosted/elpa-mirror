(define-package "pyinspect" "20211102.1415" "Python object inspector"
  '((emacs "27.1"))
  :commit "02976a259b8592b695c830ad04d4d62acdf54bb0" :authors
  '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainer
  '("Maor Kadosh" . "git@avocadosh.xyz")
  :keywords
  '("tools")
  :url "https://github.com/it-is-wednesday/pyinspect.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
