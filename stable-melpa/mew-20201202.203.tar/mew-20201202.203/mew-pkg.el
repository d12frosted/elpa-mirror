(define-package "mew" "20201202.203" "Messaging in the Emacs World" 'nil :commit "b5ca49f83f0b178fab4683b8443083515caaa4c2" :authors
  '(("Kazu Yamamoto" . "Kazu@Mew.org"))
  :maintainer
  '("Kazu Yamamoto" . "Kazu@Mew.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
