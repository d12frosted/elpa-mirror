;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260902.1211"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "aeb903b63f7f1544229b71bbe7ca19d4bd8fa92e"
  :revdesc "aeb903b63f7f"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
