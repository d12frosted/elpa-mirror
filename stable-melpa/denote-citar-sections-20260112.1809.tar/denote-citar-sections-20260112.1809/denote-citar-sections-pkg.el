;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "denote-citar-sections" "20260112.1809"
  "Universal Sidecar sections for citar-denote."
  '((emacs             "26.1")
    (denote            "2.2.4")
    (universal-sidecar "1.5.0")
    (citar-denote      "2.2.2")
    (citar             "1.4"))
  :url "https://git.sr.ht/~swflint/denote-sections"
  :commit "ea81318cf1c7d7281047a6b3a2ac8fb76c8535d7"
  :revdesc "ea81318cf1c7"
  :keywords '("convenience" "files" "hypermedia" "notes")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
