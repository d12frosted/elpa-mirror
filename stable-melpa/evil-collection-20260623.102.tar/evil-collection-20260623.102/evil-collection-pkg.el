;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-collection" "20260623.102"
  "A set of keybindings for Evil mode."
  '((emacs "29.1")
    (evil  "1.2.13"))
  :url "https://github.com/emacs-evil/evil-collection"
  :commit "fe7283e71ab90a882bc103ef76fb3ece3efd75f7"
  :revdesc "fe7283e71ab9"
  :keywords '("evil" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
