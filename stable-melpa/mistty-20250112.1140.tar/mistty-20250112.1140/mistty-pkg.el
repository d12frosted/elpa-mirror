;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20250112.1140"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "http://github.com/szermatt/mistty"
  :commit "7054927e6a95dc5c4362e7cb05dc5f9ade8cccea"
  :revdesc "7054927e6a95"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
