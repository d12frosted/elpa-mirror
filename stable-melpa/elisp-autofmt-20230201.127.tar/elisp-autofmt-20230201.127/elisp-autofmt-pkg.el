(define-package "elisp-autofmt" "20230201.127" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "8b42fb0ace761f7f39d475201001b10d730197d3" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
