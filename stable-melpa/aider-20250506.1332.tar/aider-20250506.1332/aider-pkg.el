;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250506.1332"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "62a6100c54f8d44d1e73b845c769e8056f39427d"
  :revdesc "62a6100c54f8"
  :keywords '("agent" "ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
