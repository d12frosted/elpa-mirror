(define-package "live-py-mode" "20220130.237" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "f2b639bc6528ac87d17303bc555b7262f3610046" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
