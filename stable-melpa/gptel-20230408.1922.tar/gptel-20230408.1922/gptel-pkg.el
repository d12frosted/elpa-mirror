(define-package "gptel" "20230408.1922" "A simple ChatGPT client"
  '((emacs "27.1")
    (transient "0.3.7"))
  :commit "36051b15d5ccb1ad7940a0449cace3edaefd09e2" :authors
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
