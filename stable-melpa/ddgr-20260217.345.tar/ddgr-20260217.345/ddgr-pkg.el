;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ddgr" "20260217.345"
  "DuckDuckGo search."
  '((emacs "27.1"))
  :url "https://github.com/necaris/ddgr.el"
  :commit "55cba194c477f435221094d31798a588df4137e7"
  :revdesc "55cba194c477"
  :keywords '("comm" "duckduckgo" "search" "web")
  :authors '(("Rami Chowdhury" . "rami.chowdhury@gmail.com"))
  :maintainers '(("Rami Chowdhury" . "rami.chowdhury@gmail.com")))
