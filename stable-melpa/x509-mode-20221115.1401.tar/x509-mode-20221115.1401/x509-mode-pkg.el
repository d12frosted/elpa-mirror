(define-package "x509-mode" "20221115.1401" "View certificates, CRLs and keys using OpenSSL"
  '((emacs "25.1"))
  :commit "814114b3dfe44ac477831c8ca5da0050a9d0fdf1" :authors
  '(("Fredrik Axelsson" . "f.axelsson@gmail.com"))
  :maintainer
  '("Fredrik Axelsson" . "f.axelsson@gmail.com")
  :url "https://github.com/jobbflykt/x509-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
