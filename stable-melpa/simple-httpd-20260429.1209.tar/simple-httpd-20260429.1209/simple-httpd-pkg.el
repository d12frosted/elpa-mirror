;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260429.1209"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "a9d7049ed7b4d7ed615b328a6a2237542a2140d6"
  :revdesc "a9d7049ed7b4"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
