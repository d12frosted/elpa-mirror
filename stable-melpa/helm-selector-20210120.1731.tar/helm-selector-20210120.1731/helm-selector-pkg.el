(define-package "helm-selector" "20210120.1731" "Helm buffer selector"
  '((emacs "26.1")
    (helm "3"))
  :commit "0609ba36531676b68736e191e70ded20ee016f31" :authors
  '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainer
  '("Pierre Neidhardt" . "mail@ambrevar.xyz")
  :url "https://github.com/emacs-helm/helm-selector")
;; Local Variables:
;; no-byte-compile: t
;; End:
