;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260121.903"
  "AI-LLM blocks for org-mode."
  '((emacs "29.1"))
  :url "https://github.com/Anoncheg1/emacs-oai"
  :commit "bd09b6b1bae26e2dc946093fc7e66013ac327e5b"
  :revdesc "bd09b6b1bae2"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
