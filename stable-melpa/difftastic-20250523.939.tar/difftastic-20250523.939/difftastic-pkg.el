;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "difftastic" "20250523.939"
  "Wrapper for difftastic."
  '((emacs     "28.1")
    (compat    "29.1.4.2")
    (magit     "4.0.0")
    (transient "0.4.0"))
  :url "https://github.com/pkryger/difftastic.el"
  :commit "f2a54bc9fdc855507a459eb690a660afdf0fa901"
  :revdesc "f2a54bc9fdc8"
  :keywords '("tools" "diff")
  :authors '(("Przemyslaw Kryger" . "pkryger@gmail.com"))
  :maintainers '(("Przemyslaw Kryger" . "pkryger@gmail.com")))
