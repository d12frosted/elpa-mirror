;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rectangle-utils" "20260105.501"
  "Some useful rectangle functions."
  '((emacs  "24")
    (cl-lib "0.5"))
  :url "https://github.com/thierryvolpiatto/rectangle-utils"
  :commit "309034e06fcab69eff094709ba98af9d607dbcbc"
  :revdesc "309034e06fca"
  :authors '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com"))
  :maintainers '(("Thierry Volpiatto" . "thierry.volpiatto@gmail.com")))
