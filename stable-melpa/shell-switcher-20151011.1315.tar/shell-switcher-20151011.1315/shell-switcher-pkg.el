(define-package "shell-switcher" "20151011.1315" "Provide fast switching between shell buffers." 'nil :commit "2c5575ae859a82041a4bacd1793b844bfc24c34f" :authors
  '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainer
  '("Damien Cassou" . "damien.cassou@gmail.com")
  :keywords
  '("emacs" "package" "elisp" "shell" "eshell" "term" "switcher")
  :url "https://github.com/DamienCassou/shell-switcher")
;; Local Variables:
;; no-byte-compile: t
;; End:
