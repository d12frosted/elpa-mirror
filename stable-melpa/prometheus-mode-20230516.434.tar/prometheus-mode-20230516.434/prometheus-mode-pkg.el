(define-package "prometheus-mode" "20230516.434" "Major modes for Prometheus files"
  '((emacs "26.1"))
  :commit "61e4c89db5ad50cc3ff0887dcd4b4bb4b14b4031" :authors
  '(("Peter Hoeg" . "peter@hoeg.com"))
  :maintainers
  '(("Peter Hoeg" . "peter@hoeg.com"))
  :maintainer
  '("Peter Hoeg" . "peter@hoeg.com")
  :keywords
  '("languages")
  :url "https://hoeg.com")
;; Local Variables:
;; no-byte-compile: t
;; End:
