(define-package "autocrypt" "20210709.1230" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "32786dc552569c7cc9970628f580b0b7b8e0b03d" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "philipk@posteo.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
