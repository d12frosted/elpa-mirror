;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "py-import-check" "20130802.1111"
  "Finds the unused python imports using importchecker."
  ()
  :url "https://github.com/psibi/emacs-py-import-check"
  :commit "38ad91e67047bd37231497d11d409d064d510f98"
  :revdesc "38ad91e67047"
  :keywords '("python" "import" "check")
  :authors '(("Sibi" . "sibi@psibi.in"))
  :maintainers '(("Sibi" . "sibi@psibi.in")))
