;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260724.953"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "fb4d521a3f85f839100d52a8495bc2ec69aff784"
  :revdesc "fb4d521a3f85"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
