;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "import-js" "20220215.1948"
  "Import Javascript dependencies."
  '((grizzl "0.1.0")
    (emacs  "24"))
  :url "https://github.com/Galooshi/emacs-import-js/"
  :commit "d2bbb53f96395415f9f01de4fa88d82c1f59ba63"
  :revdesc "d2bbb53f9639"
  :keywords '("javascript")
  :authors '(("Kevin Kehl" . "kevin.kehl@gmail.com"))
  :maintainers '(("Kevin Kehl" . "kevin.kehl@gmail.com")))
