(define-package "kmacro-x" "20230305.1619" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "82d10aae9e4ef1bd445667511f6fb6e1ec1a6e3a" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
