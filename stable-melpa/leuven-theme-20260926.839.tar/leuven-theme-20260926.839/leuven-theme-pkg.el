;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "leuven-theme" "20260926.839"
  "Elegant Emacs color theme for a white background."
  ()
  :url "https://github.com/fniessen/emacs-leuven-theme"
  :commit "bc61caaf7ad0c7afa053f7056ce835ea9231fe27"
  :revdesc "bc61caaf7ad0"
  :keywords '("color" "theme")
  :authors '(("Fabrice Niessen" . ""))
  :maintainers '(("Fabrice Niessen" . "")))
