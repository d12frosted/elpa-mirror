(define-package "org-working-set" "20220414.1402" "Manage and visit a small set of org-nodes."
  '((org "9.3")
    (dash "2.12")
    (s "1.12")
    (emacs "26.3"))
  :commit "6af54ed3a5d9bf90629223157803c42f5d3b152c" :authors
  '(("Marc Ihm" . "1@2484.de"))
  :maintainers
  '(("Marc Ihm" . "1@2484.de"))
  :maintainer
  '("Marc Ihm" . "1@2484.de")
  :url "https://github.com/marcIhm/org-working-set")
;; Local Variables:
;; no-byte-compile: t
;; End:
