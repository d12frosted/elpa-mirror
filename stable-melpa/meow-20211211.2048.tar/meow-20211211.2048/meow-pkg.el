(define-package "meow" "20211211.2048" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "8f3cc859ae5b8cc0bf3bc235301c0b3ec5e7811d" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
