;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "django-mode" "20170522.714"
  "Major mode for Django web framework."
  '((projectile "0")
    (s          "0")
    (helm-make  "0"))
  :url "https://github.com/unrelentingtech/django-mode"
  :commit "a71b8dd984e7f724b8321246e5c353a4ae5c986e"
  :revdesc "a71b8dd984e7"
  :keywords '("languages")
  :authors '(("Greg V" . "floatboth@me.com"))
  :maintainers '(("Greg V" . "floatboth@me.com")))
