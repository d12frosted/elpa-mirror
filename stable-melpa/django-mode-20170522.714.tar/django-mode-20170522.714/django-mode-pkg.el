(define-package "django-mode" "20170522.714" "Major mode for Django web framework."
  '((projectile "0")
    (s "0")
    (helm-make "0"))
  :commit "a71b8dd984e7f724b8321246e5c353a4ae5c986e" :keywords
  ("languages")
  :authors
  (("Greg V" . "floatboth@me.com"))
  :maintainer
  ("Greg V" . "floatboth@me.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
