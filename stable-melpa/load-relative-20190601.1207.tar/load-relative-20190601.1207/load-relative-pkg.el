(define-package "load-relative" "20190601.1207" "Relative file load (within a multi-file Emacs package)" 'nil :commit "5055bfd80644e306aef4e7a7e3e9e5d765b691a4" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :keywords
  '("internal")
  :url "http://github.com/rocky/emacs-load-relative")
;; Local Variables:
;; no-byte-compile: t
;; End:
