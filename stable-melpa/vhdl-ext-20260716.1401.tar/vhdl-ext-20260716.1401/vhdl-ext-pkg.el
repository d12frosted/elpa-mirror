;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vhdl-ext" "20260716.1401"
  "VHDL Extensions."
  '((emacs        "29.1")
    (vhdl-ts-mode "0.3.3")
    (lsp-mode     "8.0.0")
    (rg           "2.3.0")
    (hydra        "0.15.0")
    (flycheck     "32")
    (async        "1.9.7"))
  :url "https://github.com/gmlarumbe/vhdl-ext"
  :commit "fd400c09de24d3c7da9aed5884b6f114f595373c"
  :revdesc "fd400c09de24"
  :keywords '("vhdl" "ide" "tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
