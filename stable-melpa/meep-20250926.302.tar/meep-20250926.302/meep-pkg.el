;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250926.302"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "419d6c73a40f0344193083c21c60c9959f032c1e"
  :revdesc "419d6c73a40f"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
