(define-package "tuareg" "20220629.1711" "OCaml mode"
  '((emacs "24.4")
    (caml "4.8"))
  :commit "b93890a87700ec6bbf73e6afa1c6a3213be14a00" :authors
  '(("Albert Cohen" . "Albert.Cohen@inria.fr")
    ("Sam Steingold" . "sds@gnu.org")
    ("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
    ("Till Varoquaux" . "till@pps.jussieu.fr")
    ("Sean McLaughlin" . "seanmcl@gmail.com")
    ("Stefan Monnier" . "monnier@iro.umontreal.ca"))
  :maintainer
  '("Christophe Troestler" . "Christophe.Troestler@umons.ac.be")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/tuareg")
;; Local Variables:
;; no-byte-compile: t
;; End:
