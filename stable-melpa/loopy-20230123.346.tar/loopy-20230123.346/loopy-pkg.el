(define-package "loopy" "20230123.346" "A looping macro"
  '((emacs "27.1")
    (map "3.0")
    (seq "2.22"))
  :commit "d07baee1aaa89a3786b0b7202e5d12dda77618f9" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
