;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-grammarly" "20251231.1727"
  "Flymake support for Grammarly."
  '((emacs     "26.1")
    (grammarly "0.3.0")
    (s         "1.12.0"))
  :url "https://github.com/emacs-grammarly/flymake-grammarly"
  :commit "45ed9ff6ce87298271903aad5a839c34e940a296"
  :revdesc "45ed9ff6ce87"
  :keywords '("convenience" "grammar" "check")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
