(define-package "suomalainen-kalenteri" "20200830.1107" "Finnish national and Christian holidays for calendar" 'nil :commit "99fd77d25fc12c0a9f1fc75f0b83b31774d493bd" :authors
  '(("Teemu Likonen" . "tlikonen@iki.fi"))
  :maintainer
  '("Teemu Likonen" . "tlikonen@iki.fi")
  :keywords
  '("calendar" "holidays" "finnish")
  :url "https://github.com/tlikonen/suomalainen-kalenteri")
;; Local Variables:
;; no-byte-compile: t
;; End:
