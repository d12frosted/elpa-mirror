;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260212.1449"
  "Unified interface for AI coding CLI such as Claude Code, Codex CLI, Gemini CLI, Copilot CLI, Opencode, Grok CLI, Aider CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "e8a451407273d605582a6f72859423dba529cd13"
  :revdesc "e8a451407273"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
