(define-package "srfi" "20210113.2052" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "1fe8720e2e1e8884eac512d28257d655306a9686" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
