(define-package "magik-mode" "20230623.1236" "mode for editing Magik + some utils." 'nil :commit "d59e9212e44f62b40c4323ca8bbe53ea09cd00d0" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
