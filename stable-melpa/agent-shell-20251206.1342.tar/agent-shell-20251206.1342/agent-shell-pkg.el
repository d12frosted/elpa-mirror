;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251206.1342"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "e59cd30a8c29f911a9078615602f26891c857420"
  :revdesc "e59cd30a8c29")
