(define-package "sly" "20201208.1836" "Sylvester the Cat's Common Lisp IDE"
  '((emacs "24.3"))
  :commit "41b1cc8087a435ea646e0b45feaaea1da14f5e29" :keywords
  ("languages" "lisp" "sly")
  :url "https://github.com/joaotavora/sly")
;; Local Variables:
;; no-byte-compile: t
;; End:
