;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aider" "20250506.1333"
  "AI assisted programming in Emacs with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (magit         "2.1.0")
    (markdown-mode "2.5"))
  :url "https://github.com/tninja/aider.el"
  :commit "0f3e7b0d6ea70f02bcc0356eda3e80ac6acb084c"
  :revdesc "0f3e7b0d6ea7"
  :keywords '("agent" "ai" "gpt" "sonnet" "llm" "aider" "gemini-pro" "deepseek" "ai-assisted-coding")
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
