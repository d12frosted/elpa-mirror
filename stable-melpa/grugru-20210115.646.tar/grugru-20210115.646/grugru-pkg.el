(define-package "grugru" "20210115.646" "Rotate text at point"
  '((emacs "24.4"))
  :commit "7a3437feb777996dcb8f484b79e898cfdb714bfe" :authors
  '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainer
  '("ROCKTAKEY" . "rocktakey@gmail.com")
  :keywords
  '("convenience" "abbrev" "tools")
  :url "https://github.com/ROCKTAKEY/grugru")
;; Local Variables:
;; no-byte-compile: t
;; End:
