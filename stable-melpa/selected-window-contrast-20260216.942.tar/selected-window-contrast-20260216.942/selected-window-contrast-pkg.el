;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-contrast" "20260216.942"
  "Highlight by brightness of text and background."
  '((emacs "29.4"))
  :url "https://codeberg.org/Anoncheg/selected-window-contrast"
  :commit "7c70ccb714e8c1e53786d48c512d4e349c3687c8"
  :revdesc "7c70ccb714e8"
  :keywords '("color" "windows" "faces" "buffer" "background")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
