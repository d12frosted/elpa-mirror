;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ido-occasional" "20150214.1248"
  "Use ido where you choose."
  '((emacs "24.1"))
  :url "https://github.com/abo-abo/ido-occasional"
  :commit "d405f1795e1e0c63be411ee2825184738d29c33a"
  :revdesc "d405f1795e1e"
  :keywords '("completion")
  :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainers '(("Oleh Krehel" . "ohwoeowho@gmail.com")))
