(define-package "related-files" "20230324.934" "Easily find files related to the current one"
  '((emacs "28.2"))
  :commit "f3f841f625a51b964b88cfe08378311124cc5240" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("tools")
  :url "https://www.gnu.org/software/emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
