;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260130.1941"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.8.3"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b593b2f572fb00d1ad42d7c4214f4a94a01d687c"
  :revdesc "b593b2f572fb")
