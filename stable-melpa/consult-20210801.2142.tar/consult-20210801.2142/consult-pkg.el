(define-package "consult" "20210801.2142" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "cf9b877095d1b5524de8efc3b467dd4341ab97e8" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
