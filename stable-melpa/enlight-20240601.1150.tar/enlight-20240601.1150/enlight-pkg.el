(define-package "enlight" "20240601.1150" "Highly customizable startup screen"
  '((emacs "27.1")
    (compat "29.1.4.1"))
  :commit "76753736da1777c8f9ebbeb08beec15b330a5878" :authors
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainers
  '(("Ilya Chernyshov" . "ichernyshovvv@gmail.com"))
  :maintainer
  '("Ilya Chernyshov" . "ichernyshovvv@gmail.com")
  :keywords
  '("startup" "screen" "tools" "dashboard")
  :url "https://github.com/ichernyshovvv/enlight")
;; Local Variables:
;; no-byte-compile: t
;; End:
