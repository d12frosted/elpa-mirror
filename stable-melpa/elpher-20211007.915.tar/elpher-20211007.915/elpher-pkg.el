(define-package "elpher" "20211007.915" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "02fade7fc9a6b642359552694cc7bed95132cf18" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
