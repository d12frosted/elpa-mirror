(define-package "modus-themes" "20210417.1604" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "1903cf653055482714c0f4cfa79e53c82fba047c" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
