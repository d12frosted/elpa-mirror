;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "winring" "20260826.7"
  "Window configuration rings."
  ()
  :url "https://gitlab.com/warsaw/winring"
  :commit "e1ffacae7b4f2642d67898e643a5a47571bcfa25"
  :revdesc "e1ffacae7b4f"
  :keywords '("frames" "tools"))
