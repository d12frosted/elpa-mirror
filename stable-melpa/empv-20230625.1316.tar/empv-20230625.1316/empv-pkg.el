(define-package "empv" "20230625.1316" "A multimedia player/manager, YouTube interface"
  '((emacs "28.1")
    (s "1.13.0"))
  :commit "f71bce1ea481b0578e62394d620ad7982c088dea" :authors
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers
  '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainer
  '("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")
  :url "https://github.com/isamert/empv.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
