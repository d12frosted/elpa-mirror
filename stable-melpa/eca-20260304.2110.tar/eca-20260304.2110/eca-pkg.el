;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260304.2110"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "185ef140ccd08bdae0e113a7005e0dca895caf9a"
  :revdesc "185ef140ccd0"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
