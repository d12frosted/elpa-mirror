(define-package "kele" "20230128.1329" "Spritzy Kubernetes cluster management"
  '((emacs "28.1")
    (async "1.9.7")
    (dash "2.19.1")
    (f "0.20.0")
    (ht "2.3")
    (plz "0.3")
    (s "1.13.0")
    (yaml "0.5.1"))
  :commit "87d0e879445d4ba334220363b3ce30cd65fc33dc" :authors
  '(("Jonathan Jin" . "me@jonathanj.in"))
  :maintainer
  '("Jonathan Jin" . "me@jonathanj.in")
  :keywords
  '("kubernetes" "tools")
  :url "https://github.com/jinnovation/kele.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
