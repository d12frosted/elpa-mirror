;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hnreader" "20261109.27"
  "A hackernews reader."
  '((emacs   "25.1")
    (promise "1.1")
    (request "0.3.0")
    (org     "9.2"))
  :url "https://github.com/thanhvg/emacs-hnreader/"
  :commit "79c29e6b5a46c9cfb899f80ebc272f7e552adbc5"
  :revdesc "79c29e6b5a46"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
