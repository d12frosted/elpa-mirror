(define-package "speechd-el" "20211231.758" "Client to speech synthesizers and Braille displays." 'nil :commit "a4be22b5b62a6be1e749df6f64b06e16a6b09790" :authors
  '(("Milan Zamazal" . "pdm@zamazal.org"))
  :maintainer
  '("Milan Zamazal" . "pdm@zamazal.org"))
;; Local Variables:
;; no-byte-compile: t
;; End:
