;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250425.130"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "e0e4a34d0ecda174b7543c109a09f037370c1e39"
  :revdesc "e0e4a34d0ecd"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
