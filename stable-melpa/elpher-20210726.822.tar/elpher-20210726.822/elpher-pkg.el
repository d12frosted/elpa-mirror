(define-package "elpher" "20210726.822" "A friendly gopher and gemini client"
  '((emacs "27.1"))
  :commit "ce5cd208ce378fd4fd286f5c701e206d3208d9f3" :authors
  '(("Tim Vaughan" . "plugd@thelambdalab.xyz"))
  :maintainer
  '("Tim Vaughan" . "plugd@thelambdalab.xyz")
  :keywords
  '("comm" "gopher")
  :url "https://thelambdalab.xyz/elpher")
;; Local Variables:
;; no-byte-compile: t
;; End:
