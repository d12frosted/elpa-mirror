(define-package "eide" "20220531.452" "IDE interface" 'nil :commit "a32b9266414d9173dfa92fa44b17064ebb39522f" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://forge.chalec.org/hjuvi/eide")
;; Local Variables:
;; no-byte-compile: t
;; End:
