;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260202.1539"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "da9e4d109376b23c3d183d0c66efac540bdc59a8"
  :revdesc "da9e4d109376"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
