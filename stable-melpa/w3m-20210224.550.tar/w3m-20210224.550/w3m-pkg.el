(define-package "w3m" "20210224.550" "an Emacs interface to w3m" 'nil :commit "af044d7596e8c2260b6899fd84c48e9671567333" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
