(define-package "consult" "20220524.625" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "3dbb14797583cb14e40966529021ee723287d200" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
