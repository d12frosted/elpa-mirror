;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evm-mode" "20220911.1647"
  "Major mode for editing Ethereum EVM bytecode."
  ()
  :url "https://github.com/taquangtrung/emacs-evm-mode"
  :commit "422b65cfd04854072bf6b9238c49e3d40577ef98"
  :revdesc "422b65cfd048"
  :keywords '("languages"))
