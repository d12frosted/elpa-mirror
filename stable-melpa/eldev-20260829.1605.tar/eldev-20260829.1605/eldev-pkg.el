;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "20260829.1605"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "129d26489b1749839b203ac40ae3cc609c737036"
  :revdesc "129d26489b17"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
