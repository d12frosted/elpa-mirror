(define-package "elsa" "20230306.2246" "Emacs Lisp Static Analyser"
  '((emacs "25.1")
    (trinary "0")
    (f "0")
    (dash "2.14")
    (cl-lib "0.3")
    (lsp-mode "0"))
  :commit "71e8b3f2e79878b2df9990ecabd7eb3b740f23b4" :authors
  '(("Matúš Goljer" . "matus.goljer@gmail.com"))
  :maintainer
  '("Matúš Goljer" . "matus.goljer@gmail.com")
  :keywords
  '("languages" "lisp")
  :url "https://github.com/emacs-elsa/Elsa")
;; Local Variables:
;; no-byte-compile: t
;; End:
