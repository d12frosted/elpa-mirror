(define-package "cl-format" "20210824.2016" "CL format routine." 'nil :commit "a391d7696bea972ad9a968426e712feddc284ef4" :authors
  '(("Andreas Politz" . "politza@fh-trier.de"))
  :maintainer
  '("Andreas Politz" . "politza@fh-trier.de")
  :keywords
  '("extensions"))
;; Local Variables:
;; no-byte-compile: t
;; End:
