;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20260615.1224"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "6f8bcb4f96cd551f3d5c746b6164e5a735754c5e"
  :revdesc "6f8bcb4f96cd"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
