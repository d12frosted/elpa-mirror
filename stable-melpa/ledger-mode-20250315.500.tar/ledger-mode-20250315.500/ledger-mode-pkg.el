;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ledger-mode" "20250315.500"
  "Helper code for use with the \"ledger\" command-line tool."
  '((emacs "25.1"))
  :url "https://github.com/ledger/ledger-mode"
  :commit "dcad2d467d995b1adf0424d61ac3307e1cc25c5c"
  :revdesc "dcad2d467d99")
