(define-package "cape" "20230121.858" "Completion At Point Extensions"
  '((emacs "27.1")
    (compat "29.1.1.0"))
  :commit "6e3fa266e024e4514e7dc6b2eaab6841b3f7948c" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
