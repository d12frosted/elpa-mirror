(define-package "klondike" "20240105.2237" "Klondike"
  '((emacs "28.1"))
  :commit "7614c3d12c64bb99fc0f5dc16cf36487ce8a5e23" :authors
  '(("Wamm K. D." . "jaft.r@outlook.com"))
  :maintainers
  '(("Wamm K. D." . "jaft.r@outlook.com"))
  :maintainer
  '("Wamm K. D." . "jaft.r@outlook.com")
  :keywords
  '("games" "cards" "solitaire" "klondike")
  :url "https://codeberg.org/WammKD/Emacs-Klondike")
;; Local Variables:
;; no-byte-compile: t
;; End:
