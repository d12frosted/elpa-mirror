;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "media-thumbnail" "20260712.1958"
  "Utility package to provide media icons."
  '((emacs "28.1"))
  :url "https://github.com/jojojames/media-thumbnail"
  :commit "bd0be6d09ced3afb5db1cf2f7e898e26d9934076"
  :revdesc "bd0be6d09ced"
  :keywords '("files" "tools")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
