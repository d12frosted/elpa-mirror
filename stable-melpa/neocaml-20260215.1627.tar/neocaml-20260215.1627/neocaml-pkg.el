;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260215.1627"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "http://github.com/bbatsov/neocaml"
  :commit "5f4553ffeb76f99598b64ef2adf19184cdf11e48"
  :revdesc "5f4553ffeb76"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
