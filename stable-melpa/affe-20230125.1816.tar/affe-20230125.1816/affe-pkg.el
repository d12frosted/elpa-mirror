(define-package "affe" "20230125.1816" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.20"))
  :commit "62d58fdd87a90217ce5bdb61376252c854ee6f79" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
