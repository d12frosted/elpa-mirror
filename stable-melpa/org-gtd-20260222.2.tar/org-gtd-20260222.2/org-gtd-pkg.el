;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-gtd" "20260222.2"
  "An implementation of GTD."
  '((emacs     "28.1")
    (compat    "30.0.0.0")
    (org-edna  "1.1.2")
    (f         "0.20.0")
    (org       "9.6")
    (transient "0.11.0")
    (dag-draw  "1.0.4"))
  :url "https://github.com/Trevoke/org-gtd.el"
  :commit "79ee241426a4266814743f0bcfe934fcb496b1fa"
  :revdesc "79ee241426a4"
  :authors '(("Aldric Giacomoni" . "trevoke@gmail.com"))
  :maintainers '(("Aldric Giacomoni" . "trevoke@gmail.com")))
