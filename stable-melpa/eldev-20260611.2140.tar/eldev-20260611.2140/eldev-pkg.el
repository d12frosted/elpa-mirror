;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "20260611.2140"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "9174eb2d410a519d561f6df204dd04c47eb339c6"
  :revdesc "9174eb2d410a"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
