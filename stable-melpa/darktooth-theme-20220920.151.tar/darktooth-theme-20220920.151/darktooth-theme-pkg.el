(define-package "darktooth-theme" "20220920.151" "From the darkness... it watches"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "4be48efc09f4dd5e61bfec835a08e89d891440ef" :url "http://github.com/emacsfodder/emacs-theme-darktooth")
;; Local Variables:
;; no-byte-compile: t
;; End:
