;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "symon" "20260218.1909"
  "Tiny graphical system monitor."
  ()
  :url "http://hins11.yu-yake.com/"
  :commit "d663045c290f80b77136d6a49f2be0226f01b565"
  :revdesc "d663045c290f")
