;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260326.432"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "95f1695fc8c01eadd1784b1d452e1052596a2149"
  :revdesc "95f1695fc8c0"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
