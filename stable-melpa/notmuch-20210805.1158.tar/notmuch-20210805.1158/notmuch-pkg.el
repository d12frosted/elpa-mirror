(define-package "notmuch" "20210805.1158" "run notmuch within emacs" 'nil :commit "4f84c01b3ab2002812293a0951c4f69acb9ddea2" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
