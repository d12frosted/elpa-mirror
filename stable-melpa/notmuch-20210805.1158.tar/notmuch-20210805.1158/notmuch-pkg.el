(define-package "notmuch" "20210805.1158" "run notmuch within emacs" 'nil :commit "be6edee49660308131cbc7a6eb51e38c642cc098" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
