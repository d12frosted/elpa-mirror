(define-package "notmuch" "20210805.1158" "run notmuch within emacs" 'nil :commit "6fec5d771ede7998ff395abd636d391c21163409" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
