(define-package "modus-themes" "20230320.449" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "2c34f81b831e646fa31840be8102ecaf4df6b6bf" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
