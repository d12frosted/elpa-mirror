;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260409.1646"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "03af83c44d698074bcd36bdb6c092eb5c38d9a39"
  :revdesc "03af83c44d69"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
