(define-package "howm" "20230216.1125" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "304479afd13bbb0b4d23283a28be95877528cc65" :authors
  '(("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
