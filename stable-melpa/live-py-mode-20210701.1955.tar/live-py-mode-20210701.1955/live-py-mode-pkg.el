(define-package "live-py-mode" "20210701.1955" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "033c5c888f8ec9f9739848ead6381b891d4c9c00" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
