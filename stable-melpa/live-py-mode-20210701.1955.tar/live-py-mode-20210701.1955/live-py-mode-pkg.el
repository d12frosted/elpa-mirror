(define-package "live-py-mode" "20210701.1955" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "58b8af6075059633bac1afd166a2a248f25a8515" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
