(define-package "live-py-mode" "20210701.1955" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "db1f98cc470972f92d72f40b78db4baff5768edd" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
