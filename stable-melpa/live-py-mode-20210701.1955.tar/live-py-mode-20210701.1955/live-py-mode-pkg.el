(define-package "live-py-mode" "20210701.1955" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "95e8e7d353674f1a97caebb74be7860ccb0e0fe6" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
