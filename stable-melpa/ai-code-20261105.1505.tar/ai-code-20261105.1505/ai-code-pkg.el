;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20261105.1505"
  "Unified interface for AI coding backends such as Codex CLI, Pi, Antigravity CLI, Claude Code, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "cdf63817b17d9529c1210a4350564cc6023f8b34"
  :revdesc "cdf63817b17d"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
