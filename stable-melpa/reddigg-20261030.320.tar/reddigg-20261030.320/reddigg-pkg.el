;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "20261030.320"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2")
    (json    "1.4"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "81bf4269d66a57e3f69b59ca301352030c8e6882"
  :revdesc "81bf4269d66a"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
