(define-package "citre" "20210715.1057" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "4fd99e80592e21813dbbb2f6c041ecf5bedfbd8f" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
