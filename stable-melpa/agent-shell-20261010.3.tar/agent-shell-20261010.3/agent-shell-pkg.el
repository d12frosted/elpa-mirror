;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261010.3"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.5")
    (acp         "0.16.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "718b8b7f62aa5269a5984eef27c8108986aea9b4"
  :revdesc "718b8b7f62aa")
