(define-package "org-node-fakeroam" "20240920.1733" "Stand-ins for org-roam-autosync-mode"
  '((emacs "28.1")
    (compat "30")
    (org-node "0.10")
    (org-roam "2.2.2")
    (emacsql "4.0.3")
    (persist "0.6.1"))
  :commit "105356a3290c7d48305955ebd4529337ae5314f5" :authors
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers
  '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainer
  '("Martin Edström" . "meedstrom91@gmail.com")
  :keywords
  '("org" "hypermedia")
  :url "https://github.com/meedstrom/org-node-fakeroam")
;; Local Variables:
;; no-byte-compile: t
;; End:
