;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-safari" "20160404.324"
  "Browse your Safari bookmarks and history."
  '((helm  "1.9.1")
    (emacs "24"))
  :url "https://github.com/xuchunyang/helm-safari"
  :commit "664c7f4488829228eed7e90cd53002e14bec555b"
  :revdesc "664c7f448882"
  :keywords '("tools")
  :authors '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers '(("Chunyang Xu" . "xuchunyang56@gmail.com")))
