;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "palimpsest" "20200805.1048"
  "Various deletion strategies when editing."
  ()
  :url "https://github.com/danielsz/Palimpsest"
  :commit "f474b3ad706373d9953abdc401d683a2a023d28e"
  :revdesc "f474b3ad7063"
  :authors '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com"))
  :maintainers '(("Daniel Szmulewicz" . "daniel.szmulewicz@gmail.com")))
