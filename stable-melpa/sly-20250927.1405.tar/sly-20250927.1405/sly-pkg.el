;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "sly" "20250927.1405"
  "Sylvester the Cat's Common Lisp IDE."
  '((emacs "24.3"))
  :url "https://github.com/joaotavora/sly"
  :commit "577c548ee2b2921b45bf22e3ddd5b026ef372ada"
  :revdesc "577c548ee2b2"
  :keywords '("languages" "lisp" "sly"))
