(define-package "base16-theme" "20210406.1956" "Collection of themes built on combinations of 16 base colors" 'nil :commit "b35d21ae0d46856416b64851ccbb5e44ee9498d0" :authors
  '(("Kaleb Elwert" . "belak@coded.io")
    ("Neil Bhakta"))
  :maintainer
  '("Kaleb Elwert" . "belak@coded.io")
  :url "https://github.com/belak/base16-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
