(define-package "chronometrist" "20211127.1923" "A time tracker with a nice interface"
  '((emacs "25.1")
    (dash "2.16.0")
    (seq "2.20")
    (ts "0.2"))
  :commit "8b82d68822485f75829d5a258eb54f296c3db7b9" :authors
  '(("contrapunctus" . "xmpp:contrapunctus@jabjab.de"))
  :maintainer
  '("contrapunctus" . "xmpp:contrapunctus@jabjab.de")
  :keywords
  '("calendar")
  :url "https://tildegit.org/contrapunctus/chronometrist")
;; Local Variables:
;; no-byte-compile: t
;; End:
