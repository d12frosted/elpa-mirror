;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260312.630"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "ba016ad8197869f473e67a62ca4812909d723a9b"
  :revdesc "ba016ad81978"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
