;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzfa" "20260905.242"
  "Async fuzzy completion via `fzf-native'."
  '((emacs      "29.1")
    (fzf-native "2.7"))
  :url "https://github.com/jojojames/fzfa"
  :commit "2fa276ee1de0809ec31eb780b4544aed28331da5"
  :revdesc "2fa276ee1de0"
  :keywords '("matching" "completion" "fzf" "fuzzy" "fussy")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
