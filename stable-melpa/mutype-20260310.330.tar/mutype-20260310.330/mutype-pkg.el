;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mutype" "20260310.330"
  "Type into stillness."
  '((emacs "25.1"))
  :url "https://github.com/suxiaogang223/mutype"
  :commit "731c4ce4c72850ac18e35f8739b229343fb15582"
  :revdesc "731c4ce4c728"
  :keywords '("convenience" "typing")
  :authors '(("Xiaogang Su" . "https://github.com/suxiaogang223"))
  :maintainers '(("Xiaogang Su" . "https://github.com/suxiaogang223")))
