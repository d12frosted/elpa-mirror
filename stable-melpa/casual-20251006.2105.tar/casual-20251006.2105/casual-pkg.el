;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20251006.2105"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0"))
  :url "https://github.com/kickingvegas/casual"
  :commit "f0ec7e600db38e9e7c0b46de48eac032dbf9845d"
  :revdesc "f0ec7e600db3"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
