;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mistty" "20241015.1131"
  "Shell/Comint alternative based on term.el."
  '((emacs "29.1"))
  :url "https://github.com/szermatt/mistty"
  :commit "0213f6c8f2668461956c73bc8634a7bd1256e585"
  :revdesc "0213f6c8f266"
  :keywords '("convenience" "unix")
  :authors '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmx.net")))
