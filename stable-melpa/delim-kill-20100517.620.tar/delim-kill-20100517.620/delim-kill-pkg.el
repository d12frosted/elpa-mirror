;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "delim-kill" "20100517.620"
  "Kill text between delimiters."
  ()
  :url "https://github.com/thomas11/delim-kill/tree/master"
  :commit "1dbe47344f2d2cbc8c54beedf0cf0bf10fd203c1"
  :revdesc "1dbe47344f2d"
  :keywords '("convenience" "languages")
  :authors '(("Thomas Kappler" . "tkappler@gmail.com"))
  :maintainers '(("Thomas Kappler" . "tkappler@gmail.com")))
