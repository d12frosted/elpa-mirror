;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20241112.618"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "6295362eab6913cf79cd9d7e6a8bb969cd20b5ce"
  :revdesc "6295362eab69"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
