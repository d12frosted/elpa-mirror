(define-package "yeetube" "20230929.620" "YouTube Front End"
  '((emacs "27.2"))
  :commit "adf3eb2bb2a23494bc42fe4e0d6e7e8784900536" :authors
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainers
  '(("Thanos Apollo" . "public@thanosapollo.com"))
  :maintainer
  '("Thanos Apollo" . "public@thanosapollo.com")
  :keywords
  '("extensions" "youtube" "videos")
  :url "https://git.thanosapollo.com/yeetube")
;; Local Variables:
;; no-byte-compile: t
;; End:
