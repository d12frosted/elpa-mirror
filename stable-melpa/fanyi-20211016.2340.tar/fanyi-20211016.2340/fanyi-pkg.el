(define-package "fanyi" "20211016.2340" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "70f7a9b89db058d4eee771c49c1fd3a3b00db2ed" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
