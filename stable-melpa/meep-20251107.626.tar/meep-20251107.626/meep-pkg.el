;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251107.626"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "7ef5cdb4e8fc09048ba13814d3c3fd8171ba955c"
  :revdesc "7ef5cdb4e8fc"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
