(define-package "embark" "20210408.2208" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "9172e7b3b4d1cab35d492f943e64d155af69040c" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
