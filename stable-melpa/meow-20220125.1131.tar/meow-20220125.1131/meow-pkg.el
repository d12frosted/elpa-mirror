(define-package "meow" "20220125.1131" "Yet Another modal editing"
  '((emacs "27.2"))
  :commit "cccf8afdbb1ffc4621515d817a4ffb89d592f815" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
