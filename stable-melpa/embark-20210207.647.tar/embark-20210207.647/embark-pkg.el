(define-package "embark" "20210207.647" "Conveniently act on minibuffer completions"
  '((emacs "25.1"))
  :commit "0521c70ff4f22a69c7817328427c849d59088a53" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
