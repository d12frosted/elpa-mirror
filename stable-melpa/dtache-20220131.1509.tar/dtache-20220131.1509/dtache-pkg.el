(define-package "dtache" "20220131.1509" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "10a11312b8590f88de9c7d4feb91ae869ddbe162" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
