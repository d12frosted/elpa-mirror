(define-package "dtache" "20220131.1509" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "f1447b56550ff580d92f2e60cb838b4c6ca49db3" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
