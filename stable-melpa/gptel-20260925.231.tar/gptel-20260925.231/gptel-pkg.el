;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260925.231"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "6c2ff661c14e17ddc35e85d542dc470be6a90dff"
  :revdesc "6c2ff661c14e"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
