(define-package "evil-textobj-tree-sitter" "20231026.1357" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1"))
  :commit "b98c1c6d0b08317c9094bb222739ee037afbe7cd" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
