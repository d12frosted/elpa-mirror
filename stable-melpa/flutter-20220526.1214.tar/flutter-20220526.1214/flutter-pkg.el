(define-package "flutter" "20220526.1214" "Tools for working with Flutter SDK"
  '((emacs "25.1"))
  :commit "b4148db1e6e6822a6a0da1eda3c58affe562d1dc" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("languages")
  :url "https://github.com/amake/flutter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
