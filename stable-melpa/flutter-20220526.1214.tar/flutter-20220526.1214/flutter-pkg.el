(define-package "flutter" "20220526.1214" "Tools for working with Flutter SDK"
  '((emacs "25.1"))
  :commit "2fd54925a00c222b80d4ab43718b199a4c2a6d27" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("languages")
  :url "https://github.com/amake/flutter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
