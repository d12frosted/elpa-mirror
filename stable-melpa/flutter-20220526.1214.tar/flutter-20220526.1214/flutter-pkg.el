(define-package "flutter" "20220526.1214" "Tools for working with Flutter SDK"
  '((emacs "25.1"))
  :commit "49506681cd2d80713af5a04a2d33b8e6d89e3b96" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("languages")
  :url "https://github.com/amake/flutter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
