;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel-agent" "20260109.812"
  "Agentic LLM use for gptel."
  '((emacs     "29.1")
    (compat    "30.1.0.0")
    (gptel     "0.9.9")
    (yaml      "1.2.0")
    (orderless "1.1"))
  :url "https://github.com/karthink/gptel-agent"
  :commit "960bb5db030d21c2d2263028c382cb88393ce04b"
  :revdesc "960bb5db030d"
  :keywords '("comm"))
