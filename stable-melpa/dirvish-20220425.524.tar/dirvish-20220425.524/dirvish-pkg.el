(define-package "dirvish" "20220425.524" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "92a9d7197c54441b56d1865c75c1f192023444a7" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
