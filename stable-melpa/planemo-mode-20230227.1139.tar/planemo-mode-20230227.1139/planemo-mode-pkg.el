;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "planemo-mode" "20230227.1139"
  "Minor mode for editing Galaxy XML files."
  '((emacs "27.1")
    (dash  "2.17.0"))
  :url "https://gitlab.com/mtekman/planemo-mode.el"
  :commit "537ebe40688ca8f3786aa1e9842265e6f34584d2"
  :revdesc "537ebe40688c"
  :keywords '("outlines"))
