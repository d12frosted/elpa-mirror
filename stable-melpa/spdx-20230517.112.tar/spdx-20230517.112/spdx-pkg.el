(define-package "spdx" "20230517.112" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "0515acb3c27131a863e02504540fc0fcfe2789cc" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
