(define-package "parinfer-rust-mode" "20210308.2025" "An interface for the parinfer-rust library"
  '((emacs "26.1"))
  :commit "c19374a3cf9ce57a356a044731063040c552df32" :authors
  '(("Justin Barclay" . "justinbarclay@gmail.com"))
  :maintainer
  '("Justin Barclay" . "justinbarclay@gmail.com")
  :keywords
  '("lisp" "tools")
  :url "https://github.com/justinbarclay/parinfer-rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
