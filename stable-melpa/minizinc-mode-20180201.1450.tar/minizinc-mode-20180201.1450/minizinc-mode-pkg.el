;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minizinc-mode" "20180201.1450"
  "Major mode for MiniZinc code."
  '((emacs "24.1"))
  :url "https://github.com/m00nlight/minizinc-mode"
  :commit "2512521ba7f8e263a06db88df663fc6b3cca7e16"
  :revdesc "2512521ba7f8"
  :keywords '("languages" "minizinc")
  :authors '(("Yushi Wang" . "dot_wangyushi@yeah.net"))
  :maintainers '(("Yushi Wang" . "dot_wangyushi@yeah.net")))
