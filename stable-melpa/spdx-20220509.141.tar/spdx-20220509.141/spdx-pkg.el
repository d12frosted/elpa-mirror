(define-package "spdx" "20220509.141" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "9c054f6c86797ece9079e46662ea16b7ac6af790" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
