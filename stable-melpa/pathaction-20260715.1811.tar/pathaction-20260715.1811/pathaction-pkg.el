;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260715.1811"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "5d80485e7f006a827fcd9b55f40481785abf31ee"
  :revdesc "5d80485e7f00"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
