(define-package "titlecase" "20220728.2253" "Title-case phrases"
  '((emacs "25.1"))
  :commit "1fc48a505a0bf7d0e8b1bb25425993212576a3ef" :authors
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainers
  '(("Case Duckworth" . "acdw@acdw.net"))
  :maintainer
  '("Case Duckworth" . "acdw@acdw.net")
  :url "https://codeberg.org/acdw/titlecase.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
