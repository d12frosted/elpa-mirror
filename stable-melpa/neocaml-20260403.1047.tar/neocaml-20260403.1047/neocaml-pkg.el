;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260403.1047"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "bea8bb2348ed1b73dcb87c9f9d0ff070b7b9f429"
  :revdesc "bea8bb2348ed"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
