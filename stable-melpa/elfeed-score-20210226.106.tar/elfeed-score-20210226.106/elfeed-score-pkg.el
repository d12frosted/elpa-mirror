(define-package "elfeed-score" "20210226.106" "Gnus-style scoring for Elfeed"
  '((emacs "26.1")
    (elfeed "3.3.0"))
  :commit "6f99f4b9338c1a4e64885a799ac01c5b9e1d3a0a" :authors
  '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainer
  '("Michael Herstine" . "sp1ff@pobox.com")
  :keywords
  '("news")
  :url "https://github.com/sp1ff/elfeed-score")
;; Local Variables:
;; no-byte-compile: t
;; End:
