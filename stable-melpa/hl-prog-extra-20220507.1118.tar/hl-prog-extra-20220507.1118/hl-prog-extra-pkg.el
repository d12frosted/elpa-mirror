(define-package "hl-prog-extra" "20220507.1118" "Customizable highlighting for source-code"
  '((emacs "26.2"))
  :commit "a8e2ee5d43ce70c59e57d2ab90b39a6cf9e7b851" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.com/ideasman42/emacs-hl-prog-extra")
;; Local Variables:
;; no-byte-compile: t
;; End:
