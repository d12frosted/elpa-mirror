(define-package "ede-php-autoload" "20170401.1300" "Simple EDE PHP Project" 'nil :commit "28a989232c276ee7fc5112c9050b1c29f628be9f" :authors
  '(("Steven Rémot" . "steven.remot@gmail.com")
    ("original code for C++ by Eric M. Ludlam" . "eric@siege-engine.com"))
  :maintainer
  '("Steven Rémot" . "steven.remot@gmail.com")
  :keywords
  '("php" "project" "ede")
  :url "https://github.com/stevenremot/ede-php-autoload")
;; Local Variables:
;; no-byte-compile: t
;; End:
