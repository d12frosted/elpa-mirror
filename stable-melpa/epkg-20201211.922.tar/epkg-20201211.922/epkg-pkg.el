(define-package "epkg" "20201211.922" "browse the Emacsmirror package database"
  '((closql "1.0.1")
    (emacs "25.1"))
  :commit "a4780c7393f7b1e641c446a9258d6533e7570562" :keywords
  ("tools")
  :authors
  (("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  ("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
