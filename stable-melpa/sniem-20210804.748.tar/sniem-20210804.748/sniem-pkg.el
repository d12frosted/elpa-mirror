(define-package "sniem" "20210804.748" "Simple united editing method"
  '((emacs "26.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "db136f4e55aacd5df8b8f9291c4e1a6d937328eb" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
