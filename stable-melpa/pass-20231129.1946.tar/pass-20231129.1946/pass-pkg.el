(define-package "pass" "20231129.1946" "Major mode for password-store.el"
  '((emacs "25")
    (password-store "2.1.0")
    (password-store-otp "0.1.5")
    (f "0.17"))
  :commit "b1198478cd62e1f21d5072d0275e2c446b88b15b" :authors
  '(("Nicolas Petton" . "petton.nicolas@gmail.com")
    ("Damien Cassou" . "damien@cassou.me"))
  :maintainers
  '(("Nicolas Petton" . "petton.nicolas@gmail.com"))
  :maintainer
  '("Nicolas Petton" . "petton.nicolas@gmail.com")
  :keywords
  '("password-store" "password" "keychain"))
;; Local Variables:
;; no-byte-compile: t
;; End:
