(define-package "kmacro-x" "20230303.633" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "c668be3d7971f412850c11ff25c95012230db4ff" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
