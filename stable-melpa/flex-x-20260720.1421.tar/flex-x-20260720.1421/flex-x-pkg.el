;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "20260720.1421"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "13e2e010c1643551688c5826b1e5fb9929d0d703"
  :revdesc "13e2e010c164"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
