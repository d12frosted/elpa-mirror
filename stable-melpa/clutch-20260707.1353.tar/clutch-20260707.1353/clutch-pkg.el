;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260707.1353"
  "Interactive database client."
  '((emacs     "29.1")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "680ea5ed6d6319d7faa50e1c0aa9d6a5474031aa"
  :revdesc "680ea5ed6d63"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
