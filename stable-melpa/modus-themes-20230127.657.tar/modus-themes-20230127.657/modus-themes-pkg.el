(define-package "modus-themes" "20230127.657" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "4a2449a2e87c0612afdb90d3219f68c1d22bfe94" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
