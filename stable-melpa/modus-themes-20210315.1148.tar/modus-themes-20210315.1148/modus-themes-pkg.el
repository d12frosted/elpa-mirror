(define-package "modus-themes" "20210315.1148" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "405aade2e37ef56cbbc54d810cdd0fac400220dc" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
