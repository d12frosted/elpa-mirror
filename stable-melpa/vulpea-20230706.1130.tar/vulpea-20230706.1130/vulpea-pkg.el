(define-package "vulpea" "20230706.1130" "A collection of org-roam note-taking functions"
  '((emacs "27.2")
    (org "9.4.4")
    (org-roam "2.0.0")
    (s "1.12")
    (dash "2.19"))
  :commit "de199a16e294056e2368a2e031b19008cf9f9e52" :authors
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers
  '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainer
  '("Boris Buliga" . "boris@d12frosted.io")
  :url "https://github.com/d12frosted/vulpea")
;; Local Variables:
;; no-byte-compile: t
;; End:
