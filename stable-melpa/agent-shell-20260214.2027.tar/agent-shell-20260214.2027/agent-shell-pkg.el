;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260214.2027"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.85.1")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "c617076cae65468de645abdef4c8d07d7cf26c49"
  :revdesc "c617076cae65")
