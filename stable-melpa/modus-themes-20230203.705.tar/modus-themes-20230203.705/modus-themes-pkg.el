(define-package "modus-themes" "20230203.705" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "2404de30c29ff0afca68a3b9d8badc483863b08f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
