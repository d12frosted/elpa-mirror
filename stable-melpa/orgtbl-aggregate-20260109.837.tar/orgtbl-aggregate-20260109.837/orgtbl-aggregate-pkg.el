;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "orgtbl-aggregate" "20260109.837"
  "Aggregate an Org Mode table | + | + | into another table."
  '((emacs "26.1"))
  :url "https://github.com/tbanel/orgaggregate/blob/master/README.org"
  :commit "ec32afaf3942ff30d9284fbcc594511ca9269393"
  :revdesc "ec32afaf3942"
  :keywords '("data" "extensions"))
