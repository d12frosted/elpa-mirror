;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dynamic-fonts" "20140731.1226"
  "Set faces based on available fonts."
  '((font-utils      "0.7.0")
    (persistent-soft "0.8.8")
    (pcache          "0.2.3"))
  :url "https://github.com/rolandwalker/dynamic-fonts"
  :commit "004ee6014dc7dbff8f14d26015c91d9229f6eac0"
  :revdesc "004ee6014dc7"
  :keywords '("faces" "frames")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
