;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260917.56"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "8abd249fbdf5e9e8401069f48ae9729b7cec1261"
  :revdesc "8abd249fbdf5"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
