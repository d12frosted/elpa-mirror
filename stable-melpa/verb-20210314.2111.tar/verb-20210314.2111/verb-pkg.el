(define-package "verb" "20210314.2111" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "119514532f12301d7593a0dbe4eee778cc8dcf98" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
