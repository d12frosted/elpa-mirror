(define-package "org-projectile-helm" "20230816.1231" "helm functions for org-projectile"
  '((org-projectile "1.0.0")
    (helm "2.3.1")
    (emacs "25"))
  :commit "418ec0311ff3dde2578930d834cdb507158797e7" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org" "projectile" "todo" "helm" "outlines")
  :url "https://github.com/IvanMalison/org-projectile")
;; Local Variables:
;; no-byte-compile: t
;; End:
