;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-frontend" "20260926.1553"
  "Preview LaTeX math in markup buffers as SVG."
  '((emacs                "29.1")
    (latex-to-svg-backend "0.10.0"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "323d0ea84b6bcb83cabbfebee84debf2abbb6427"
  :revdesc "323d0ea84b6b"
  :keywords '("tex" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
