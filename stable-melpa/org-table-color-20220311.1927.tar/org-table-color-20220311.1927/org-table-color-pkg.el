;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-table-color" "20220311.1927"
  "Add color to your org-mode table cells."
  '((emacs "26.1"))
  :url "https://github.com/fosskers/org-table-color"
  :commit "2022f301ef323953c3a0e087a1b601da85e06da1"
  :revdesc "2022f301ef32"
  :keywords '("data" "faces" "lisp")
  :authors '(("Colin Woodbury" . "colin@fosskers.ca"))
  :maintainers '(("Colin Woodbury" . "colin@fosskers.ca")))
