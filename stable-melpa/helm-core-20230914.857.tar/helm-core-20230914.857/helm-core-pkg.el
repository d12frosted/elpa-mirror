(define-package "helm-core" "20230914.857" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.7"))
  :commit "cbad7919e9598bda9e04cdf81265c2cdf625b645" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
