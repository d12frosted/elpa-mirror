(define-package "mistty" "20230925.940" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "73825e48bf2af06f0393626d3873fefc52de77a5" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
