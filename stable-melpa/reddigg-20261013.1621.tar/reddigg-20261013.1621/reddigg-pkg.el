;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "reddigg" "20261013.1621"
  "A reader for redditt."
  '((emacs   "26.3")
    (promise "1.1")
    (ht      "2.3")
    (org     "9.2")
    (json    "1.4"))
  :url "https://github.com/thanhvg/emacs-reddigg"
  :commit "ee5dafec5450fb22407e4c3cf947d0533569808d"
  :revdesc "ee5dafec5450"
  :authors '(("Thanh Vuong" . "thanhvg@gmail.com"))
  :maintainers '(("Thanh Vuong" . "thanhvg@gmail.com")))
