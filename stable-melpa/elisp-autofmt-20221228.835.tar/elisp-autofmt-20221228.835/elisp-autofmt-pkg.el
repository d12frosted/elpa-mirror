(define-package "elisp-autofmt" "20221228.835" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "560c8297e2b6b5a59ae11b184ddaed6b0043d54b" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
