(define-package "ecukes" "20220802.1502" "Cucumber for Emacs."
  '((commander "0.6.1")
    (espuds "0.2.2")
    (ansi "0.3.0")
    (dash "2.2.0")
    (s "1.8.0")
    (f "0.11.0"))
  :commit "90e4c1d11b69e937f057864080f6dcc3f6acd2f4")
;; Local Variables:
;; no-byte-compile: t
;; End:
