(define-package "pyinspect" "20220805.918" "Python object inspector"
  '((emacs "27.1"))
  :commit "df5959e699157d757c16ce11efdf3045a5b58d23" :authors
  '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainer
  '("Maor Kadosh" . "git@avocadosh.xyz")
  :keywords
  '("tools")
  :url "https://github.com/it-is-wednesday/pyinspect.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
