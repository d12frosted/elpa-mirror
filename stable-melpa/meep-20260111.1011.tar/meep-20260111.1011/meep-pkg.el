;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260111.1011"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "c00540392761048b8609c7d7842772628f98914c"
  :revdesc "c00540392761"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
