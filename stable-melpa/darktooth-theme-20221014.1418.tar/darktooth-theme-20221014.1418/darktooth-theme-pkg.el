(define-package "darktooth-theme" "20221014.1418" "From the darkness... it watches"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "fd3df73a4d937fa9e12f0b18acb009a9d40f245e" :url "http://github.com/emacsfodder/emacs-theme-darktooth")
;; Local Variables:
;; no-byte-compile: t
;; End:
