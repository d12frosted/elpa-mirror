(define-package "kotlin-ts-mode" "20231129.1314" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "97fb77d36169179f0b6326abac148df501870718" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
