;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dwim-shell-command" "20260708.1641"
  "Shell commands with DWIM behaviour."
  '((emacs "28.1"))
  :url "https://github.com/xenodium/dwim-shell-command"
  :commit "3566651e24ca05fe818897f2cf31718d2bcd1c99"
  :revdesc "3566651e24ca")
