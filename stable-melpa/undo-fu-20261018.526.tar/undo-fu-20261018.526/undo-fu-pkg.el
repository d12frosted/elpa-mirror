;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "undo-fu" "20261018.526"
  "Undo helper with redo."
  '((emacs "25.1"))
  :url "https://codeberg.org/ideasman42/emacs-undo-fu"
  :commit "332bc7e89ded3b52cdc53ee0da3f84311278677c"
  :revdesc "332bc7e89ded"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
