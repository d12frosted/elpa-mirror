;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260112.1450"
  "Unified interface for AI coding CLI such as Codex, Copilot CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.8.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "5383c31c0b181f68abb7d6e49bf4de8ef8273576"
  :revdesc "5383c31c0b18"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
