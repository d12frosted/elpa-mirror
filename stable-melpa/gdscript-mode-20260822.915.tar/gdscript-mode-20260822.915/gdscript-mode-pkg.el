;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gdscript-mode" "20260822.915"
  "Major mode for Godot's GDScript language."
  '((emacs "29.1"))
  :url "https://github.com/godotengine/emacs-gdscript-mode/"
  :commit "2ecb74363851e551ed8176376e5b72725fe3e910"
  :revdesc "2ecb74363851"
  :keywords '("languages")
  :authors '(("Nathan Lovato" . "nathan@gdquest.com")
             ("Fabián E. Gallina" . "fgallina@gnu.org"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
