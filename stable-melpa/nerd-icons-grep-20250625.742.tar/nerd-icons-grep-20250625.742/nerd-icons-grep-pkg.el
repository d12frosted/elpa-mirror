;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nerd-icons-grep" "20250625.742"
  "Add nerd-icons to grep-mode."
  '((emacs      "30.1")
    (nerd-icons "0.0.1"))
  :url "https://github.com/hron/nerd-icons-grep"
  :commit "a0a16e9f36919e691d2e79dd319fa68200701852"
  :revdesc "a0a16e9f3691"
  :keywords '("tools" "grep" "icons")
  :authors '(("Aleksei Gusev" . "aleksei.gusev@gmail.com"))
  :maintainers '(("Aleksei Gusev" . "aleksei.gusev@gmail.com")))
