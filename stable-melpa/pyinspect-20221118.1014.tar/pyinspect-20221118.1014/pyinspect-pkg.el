(define-package "pyinspect" "20221118.1014" "Python object inspector"
  '((emacs "27.1"))
  :commit "a6f9a47327b2465dde106307e5dd8e84cb3321d9" :authors
  '(("Maor Kadosh" . "git@avocadosh.xyz"))
  :maintainer
  '("Maor Kadosh" . "git@avocadosh.xyz")
  :keywords
  '("tools")
  :url "https://github.com/it-is-wednesday/pyinspect.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
