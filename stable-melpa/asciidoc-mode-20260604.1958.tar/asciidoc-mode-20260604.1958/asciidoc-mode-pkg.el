;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "asciidoc-mode" "20260604.1958"
  "Major mode for AsciiDoc markup."
  '((emacs "30.1"))
  :url "https://github.com/bbatsov/asciidoc-mode"
  :commit "3da2bb193970fe68d0afe71a2a8d6a81797b4471"
  :revdesc "3da2bb193970"
  :keywords '("text" "asciidoc" "languages" "tree-sitter")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
