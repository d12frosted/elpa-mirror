;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "imbot" "20260521.1439"
  "Emacs input method."
  '((emacs "29.1"))
  :url "https://github.com/QiangF/imbot"
  :commit "e6e23364f441afa82881223c270a8f74923ec10c"
  :revdesc "e6e23364f441"
  :keywords '("convenience" "input method" "dbus"))
