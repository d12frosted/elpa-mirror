;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bts" "20151109.1333"
  "A unified UI for various bug tracking systems."
  '((widget-mvc "0.0.2")
    (log4e      "0.3.0")
    (yaxception "0.3.3")
    (dash       "2.9.0")
    (s          "1.9.0")
    (pos-tip    "0.4.5"))
  :url "https://github.com/aki2o/emacs-bts"
  :commit "df42d58a36447697f93b56e69f5e700b2baef1f9"
  :revdesc "df42d58a3644"
  :keywords '("convenience")
  :authors '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com"))
  :maintainers '(("Hiroaki Otsu" . "ootsuhiroaki@gmail.com")))
