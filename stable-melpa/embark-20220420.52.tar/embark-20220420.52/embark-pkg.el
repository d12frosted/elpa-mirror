(define-package "embark" "20220420.52" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "a1c3c3d52b924286a2c2034786da9e60d8134c94" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
