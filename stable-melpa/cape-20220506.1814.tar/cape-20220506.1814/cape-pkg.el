(define-package "cape" "20220506.1814" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "e72edf2d6357beb64798ef1894cc807190f80901" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
