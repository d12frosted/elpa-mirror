;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "idris-mode" "20250422.1159"
  "Major mode for editing Idris code."
  '((emacs     "24")
    (prop-menu "0.1")
    (cl-lib    "0.5"))
  :url "https://github.com/idris-hackers/idris-mode"
  :commit "b264cbf643bd6c45275b583557d5eeedf941b058"
  :revdesc "b264cbf643bd"
  :keywords '("languages"))
