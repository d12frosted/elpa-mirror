(define-package "asm-blox" "20220726.2211" "Programming game involving WAT"
  '((emacs "26.1")
    (yaml "0.3.4"))
  :commit "62e5149b350af3b448663a5db20c91834b37b75a" :authors
  '(("Zachary Romero"))
  :maintainer
  '("Zachary Romero")
  :keywords
  '("games")
  :url "https://github.com/zkry/asm-blox")
;; Local Variables:
;; no-byte-compile: t
;; End:
