(define-package "modus-themes" "20211205.1523" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "0ab66df6783fd1b9e2937f7bdddf62cc5c586d8f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
