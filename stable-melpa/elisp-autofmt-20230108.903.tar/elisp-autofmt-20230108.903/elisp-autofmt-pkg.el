(define-package "elisp-autofmt" "20230108.903" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "5620ff8ffe23fe9ab4aad32016a47ac9ba283cf0" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
