;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-maker" "20260109.1137"
  "Interaction mode for making comint shells."
  '((emacs "27.1"))
  :url "https://github.com/xenodium/shell-maker"
  :commit "e260a8e472e22b9c4a8a5b4892996dc2c47c7c7e"
  :revdesc "e260a8e472e2")
