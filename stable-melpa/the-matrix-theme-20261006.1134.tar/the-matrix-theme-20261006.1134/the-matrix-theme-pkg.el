;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "the-matrix-theme" "20261006.1134"
  "Green-on-black dark theme inspired by \"The Matrix\" movie."
  '((emacs "26.1"))
  :url "https://github.com/monkeyjunglejuice/matrix-emacs-theme"
  :commit "5dae3ee8210c320d99cb0da8e2a4292a20c94f24"
  :revdesc "5dae3ee8210c"
  :keywords '("faces" "theme")
  :authors '(("Dan Dee" . "monkeyjunglejuice@pm.me"))
  :maintainers '(("Dan Dee" . "monkeyjunglejuice@pm.me")))
