(define-package "kmacro-x" "20230313.1051" "Keyboard macro helpers and extensions"
  '((emacs "27.2"))
  :commit "da76f841776c26f59e31ab17bc942a0b34a18292" :authors
  '(("Wojciech Siewierski"))
  :maintainer
  '("Wojciech Siewierski")
  :keywords
  '("convenience")
  :url "https://github.com/vifon/kmacro-x.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
