;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kerl" "20150424.2005"
  "Emacs integration for kerl."
  ()
  :url "https://github.com/correl/kerl.el/"
  :commit "1732ee26213f021bf040919c45ad276aafcaae14"
  :revdesc "1732ee26213f"
  :keywords '("tools")
  :authors '(("Correl Roush" . "correl@gmail.com"))
  :maintainers '(("Correl Roush" . "correl@gmail.com")))
