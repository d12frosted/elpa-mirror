;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250605.1830"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "5d02bcd37f0b5beec1d86cee4ecd4a94bc208055"
  :revdesc "5d02bcd37f0b"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
