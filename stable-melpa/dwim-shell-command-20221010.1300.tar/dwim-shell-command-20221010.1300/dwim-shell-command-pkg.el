(define-package "dwim-shell-command" "20221010.1300" "Shell commands with DWIM behaviour"
  '((emacs "27.1"))
  :commit "a949445cc23f50c4fc6f13f5094946f8d7673d86" :authors
  '(("Alvaro Ramirez"))
  :maintainer
  '("Alvaro Ramirez")
  :url "https://github.com/xenodium/dwim-shell-command")
;; Local Variables:
;; no-byte-compile: t
;; End:
