(define-package "searchq" "20150829.1211" "Framework of queued search tasks using GREP, ACK, AG and more."
  '((emacs "24.3"))
  :commit "dd510d55ad66a82c6ef022cfe7c4a73ad5365f82" :authors
  '(("boyw165"))
  :maintainer
  '("boyw165"))
;; Local Variables:
;; no-byte-compile: t
;; End:
