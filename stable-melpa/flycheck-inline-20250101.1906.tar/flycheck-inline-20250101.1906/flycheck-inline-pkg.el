;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-inline" "20250101.1906"
  "Display Flycheck errors inline."
  '((emacs    "25.1")
    (flycheck "32"))
  :url "https://github.com/flycheck/flycheck-inline"
  :commit "247058cce68b788814a40c1761e6b699a4bf45d3"
  :revdesc "247058cce68b"
  :keywords '("tools" "convenience"))
