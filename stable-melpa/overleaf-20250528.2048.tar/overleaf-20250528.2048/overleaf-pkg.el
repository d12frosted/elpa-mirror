;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "overleaf" "20250528.2048"
  "Sync and track changes live with overleaf."
  '((emacs     "29.4")
    (plz       "0.9")
    (websocket "1.15")
    (webdriver "0.1")
    (posframe  "1.4.4"))
  :url "https://github.com/vale981/overleaf.el"
  :commit "c401fb10fcea710e607d65c20e0e6820daa747d3"
  :revdesc "c401fb10fcea"
  :keywords '("hypermedia" "tex" "comm")
  :maintainers '(("Valentin Boettcher" . "overleafatprotagon.space")))
