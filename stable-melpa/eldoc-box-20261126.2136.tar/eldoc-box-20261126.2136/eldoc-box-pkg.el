;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldoc-box" "20261126.2136"
  "Display documentation in childframe."
  '((emacs "27.1"))
  :url "https://github.com/casouri/eldoc-box"
  :commit "67dba0862dd1fc3effe8230e13fc0c407876bf6d"
  :revdesc "67dba0862dd1"
  :authors '(("Yuan Fu" . "casouri@gmail.com"))
  :maintainers '(("Yuan Fu" . "casouri@gmail.com")))
