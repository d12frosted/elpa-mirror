;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "scihub" "20260131.420"
  "Sci-Hub integration."
  '((emacs "27.1"))
  :url "https://github.com/emacs-pe/scihub.el"
  :commit "9bbc142be1dceff6705120017b75eeac3671cb36"
  :revdesc "9bbc142be1dc"
  :keywords '("convenience")
  :authors '(("Mario Rodas" . "marsam@users.noreply.github.com"))
  :maintainers '(("Mario Rodas" . "marsam@users.noreply.github.com")))
