;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260823.311"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "28b6907cb5c94ca2314adcbed5e3b34e61494484"
  :revdesc "28b6907cb5c9"
  :keywords '("languages"))
