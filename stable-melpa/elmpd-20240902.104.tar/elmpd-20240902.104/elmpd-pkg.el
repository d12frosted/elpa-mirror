(define-package "elmpd" "20240902.104" "A tight, ergonomic, async client library for mpd"
  '((emacs "25.1"))
  :commit "766ab97e4184c0707840dcd3f2c59f4254e8fc40" :authors
  '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainers
  '(("Michael Herstine" . "sp1ff@pobox.com"))
  :maintainer
  '("Michael Herstine" . "sp1ff@pobox.com")
  :keywords
  '("comm")
  :url "https://github.com/sp1ff/elmpd")
;; Local Variables:
;; no-byte-compile: t
;; End:
