(define-package "verb" "20240626.1743" "Organize and send HTTP requests"
  '((emacs "26.3"))
  :commit "b8f2ba14b56f17049dc7644b13e3cd03f674ea4a" :authors
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainers
  '(("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  '("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
