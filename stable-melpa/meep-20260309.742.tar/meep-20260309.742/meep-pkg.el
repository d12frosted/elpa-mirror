;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260309.742"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "3ea2f94a1b4a86b33e29191a57a35358fa0fc3f8"
  :revdesc "3ea2f94a1b4a"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
