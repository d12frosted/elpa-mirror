;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea" "20260612.821"
  "Note management library for Org mode."
  '((emacs   "27.2")
    (org     "9.4.4")
    (emacsql "4.3.0")
    (s       "1.12")
    (dash    "2.19"))
  :url "https://github.com/d12frosted/vulpea"
  :commit "ec042701ed572fae9cd0aeaeeea20bd9d7472d08"
  :revdesc "ec042701ed57"
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
