(define-package "no-littering" "20231214.2011" "Help keeping ~/.config/emacs clean"
  '((emacs "25.1")
    (compat "29.1.4.2"))
  :commit "48f3ac02d616c1357d06fd4284f6b01f31a3243d" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("convenience")
  :url "https://github.com/emacscollective/no-littering")
;; Local Variables:
;; no-byte-compile: t
;; End:
