(define-package "hledger-mode" "20191012.1046" "A mode for writing journal entries for hledger."
  '((emacs "24.4")
    (popup "0.5.3")
    (async "1.9")
    (htmlize "1.47"))
  :commit "8206f3c5d8e5b9b084733879191ec3724b60494d" :keywords
  ("data")
  :authors
  (("Narendra Joshi" . "narendraj9@gmail.com"))
  :maintainer
  ("Narendra Joshi" . "narendraj9@gmail.com")
  :url "https://github.com/narendraj9/hledger-mode.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
