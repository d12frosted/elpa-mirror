(define-package "fpga" "20230826.1703" "FPGA & ASIC Utils"
  '((emacs "28.1")
    (ggtags "0.9.0")
    (company "0.9.13"))
  :commit "2c2998631e83489abeac5f4fc915c9590bc88142" :authors
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers
  '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainer
  '("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/gmlarumbe/fpga")
;; Local Variables:
;; no-byte-compile: t
;; End:
