;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251220.1305"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "5d083b7be7e6497b02148bdaa6ec4559b5a3f59d"
  :revdesc "5d083b7be7e6"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
