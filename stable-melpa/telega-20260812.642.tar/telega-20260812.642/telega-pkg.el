;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260812.642"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.9.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "38084ca7f0c03097fe0cf0f5a49b5af14f90895a"
  :revdesc "38084ca7f0c0"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
