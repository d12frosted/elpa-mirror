;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-backup" "20180911.614"
  "Backup each file change using git."
  '((helm   "1.5.5")
    (s      "1.8.0")
    (cl-lib "0"))
  :url "https://github.com/antham/helm-backup"
  :commit "691fe542f38fc7c8cca409997f6a0ff5d76ad6c2"
  :revdesc "691fe542f38f"
  :keywords '("backup" "convenience" "files" "tools" "vc")
  :authors '(("Anthony HAMON" . "hamon.anth@gmail.com"))
  :maintainers '(("Anthony HAMON" . "hamon.anth@gmail.com")))
