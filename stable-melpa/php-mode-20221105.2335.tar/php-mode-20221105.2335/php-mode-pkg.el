(define-package "php-mode" "20221105.2335" "Major mode for editing PHP code"
  '((emacs "25.2"))
  :commit "2bc4db007c4e6ccbc2d2e6e74fb54a1af0ead054" :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :keywords
  '("languages" "php")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
