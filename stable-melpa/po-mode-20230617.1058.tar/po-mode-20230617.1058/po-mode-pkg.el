(define-package "po-mode" "20230617.1058" "major mode for GNU gettext PO files" 'nil :commit "d68aa1da2b95a17d7fe400afd414ce3ede09db86" :keywords
  '("i18n" "gettext"))
;; Local Variables:
;; no-byte-compile: t
;; End:
