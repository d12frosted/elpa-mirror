;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "create-link" "20220621.1440"
  "Smart format link generator."
  '((emacs "25.1"))
  :url "https://github.com/kijimaD/create-link"
  :commit "276fafcc6fb568ede256c8d459c3beb408ad9b46"
  :revdesc "276fafcc6fb5"
  :keywords '("link" "format" "browser" "convenience")
  :authors '(("Kijima Daigo" . "norimaking777@gmail.com"))
  :maintainers '(("Kijima Daigo" . "norimaking777@gmail.com")))
