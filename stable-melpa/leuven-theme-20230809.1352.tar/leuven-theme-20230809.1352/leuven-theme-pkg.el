(define-package "leuven-theme" "20230809.1352" "Elegant Emacs color theme for a white background" 'nil :commit "215afd1a0945b4dcf5a908d4f7b0097b0cc6c546" :authors
  '(("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>"))
  :maintainers
  '(("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>"))
  :maintainer
  '("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>")
  :keywords
  '("color" "theme")
  :url "https://github.com/fniessen/emacs-leuven-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
