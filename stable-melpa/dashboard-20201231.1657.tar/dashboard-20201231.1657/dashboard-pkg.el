(define-package "dashboard" "20201231.1657" "A startup screen extracted from Spacemacs"
  '((emacs "25.3")
    (page-break-lines "0.11"))
  :commit "b602d35bb0446a1c926737db2ccd48e577eccacb" :authors
  (("Rakan Al-Hneiti"))
  :maintainer
  ("Rakan Al-Hneiti")
  :keywords
  ("startup" "screen" "tools" "dashboard")
  :url "https://github.com/emacs-dashboard/emacs-dashboard")
;; Local Variables:
;; no-byte-compile: t
;; End:
