;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-qmd" "20260514.1442"
  "Qiita Markdown Back-End for Org Export Engine."
  '((emacs     "27.2")
    (request   "0.3.3")
    (mimetypes "1.0"))
  :url "https://github.com/0x60df/ox-qmd"
  :commit "7a1a4f2679a38e216130d749dfbb38e2d63b713f"
  :revdesc "7a1a4f2679a3"
  :keywords '("wp")
  :authors '(("0x60DF" . "0x60DF@gmail.com"))
  :maintainers '(("0x60DF" . "0x60DF@gmail.com")))
