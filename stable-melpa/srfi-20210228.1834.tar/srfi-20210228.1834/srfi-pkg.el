(define-package "srfi" "20210228.1834" "Scheme Requests for Implementation browser"
  '((emacs "25.1"))
  :commit "12eec5df609b16f16b520eceb0681b74d9ae8aa6" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/srfi-explorations/emacs-srfi")
;; Local Variables:
;; no-byte-compile: t
;; End:
