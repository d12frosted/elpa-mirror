;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20250405.2201"
  "COmpletion in Region FUnction."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "bb2aba7ffde4686d5875be27289fac89201018d2"
  :revdesc "bb2aba7ffde4"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
