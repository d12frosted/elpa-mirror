(define-package "ipp" "20230303.1138" "Implementation of the Internet Printing Protocol"
  '((cl-lib "0.5")
    (emacs "24.1"))
  :commit "8011ef4f550ebfbeefcacc1196a103580c730cfe" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("printing" "hardware")
  :url "https://github.com/emarsden/ipp-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
