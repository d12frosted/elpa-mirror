;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260204.952"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.84.9")
    (acp         "0.9.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "df9384bb3a8a7978dc0b8ee7b8bb12665ff0296e"
  :revdesc "df9384bb3a8a")
