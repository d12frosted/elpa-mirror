;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241229.1933"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "2a253229a00f8276098d02e6751dccbbf2a006d8"
  :revdesc "2a253229a00f"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
