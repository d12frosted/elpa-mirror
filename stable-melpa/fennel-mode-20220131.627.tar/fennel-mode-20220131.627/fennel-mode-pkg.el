(define-package "fennel-mode" "20220131.627" "A major-mode for editing Fennel code"
  '((emacs "26.1"))
  :commit "824d330c32637d8e0ef349ffaa8e002aca56991a" :authors
  '(("Phil Hagelberg"))
  :maintainer
  '("Phil Hagelberg")
  :keywords
  '("languages" "tools")
  :url "https://gitlab.com/technomancy/fennel-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
