;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-links" "20260315.1944"
  "Better manage line numbers in links of Org mode."
  '((emacs "27.2"))
  :url "https://github.com/Anoncheg1/emacs-org-links"
  :commit "cf6362ef5bc63e04d630b2732887bddade4b5bc6"
  :revdesc "cf6362ef5bc6"
  :keywords '("org" "text" "hypermedia" "url")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
