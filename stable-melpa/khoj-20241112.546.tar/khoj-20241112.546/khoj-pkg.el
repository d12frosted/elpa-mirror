;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "khoj" "20241112.546"
  "Your Second Brain."
  '((emacs     "27.1")
    (transient "0.3.0")
    (dash      "2.19.1"))
  :url "https://github.com/khoj-ai/khoj"
  :commit "f05e64cf8c9d761177b34e855f52c1a19a6107a0"
  :revdesc "f05e64cf8c9d"
  :keywords '("search" "chat" "ai" "org-mode" "outlines" "markdown" "pdf" "image")
  :authors '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
             ("Saba Imran" . "saba@khoj.dev"))
  :maintainers '(("Debanjum Singh Solanky" . "debanjum@khoj.dev")
                 ("Saba Imran" . "saba@khoj.dev")))
