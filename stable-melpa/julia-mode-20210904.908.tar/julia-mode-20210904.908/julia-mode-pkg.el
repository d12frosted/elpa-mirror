(define-package "julia-mode" "20210904.908" "Major mode for editing Julia source code"
  '((emacs "24.3"))
  :commit "725b55cadcb6ae44f455edf4e39643fdd5c5ca63" :keywords
  '("languages")
  :url "https://github.com/JuliaEditorSupport/julia-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
