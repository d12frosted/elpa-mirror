;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mediawiki" "20261101.2127"
  "Mediawiki frontend."
  '((emacs "28.1"))
  :url "https://github.com/hexmode/mediawiki-el"
  :commit "b958503a356ba90ebae0afbb38d37fcaa697e5c4"
  :revdesc "b958503a356b"
  :keywords '("mediawiki" "wikipedia" "network" "wiki")
  :authors '(("Mark A. Hershberger" . "mah@everybody.org"))
  :maintainers '(("Mark A. Hershberger" . "mah@everybody.org")))
