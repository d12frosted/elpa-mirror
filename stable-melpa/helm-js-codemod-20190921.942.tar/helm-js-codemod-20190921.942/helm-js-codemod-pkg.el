;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-js-codemod" "20190921.942"
  "A helm interface for running js-codemods."
  '((emacs      "24.4")
    (helm-core  "1.9.8")
    (js-codemod "1.0.0"))
  :url "https://github.com/torgeir/helm-js-codemod.el"
  :commit "1df8583fafadf8c8c5ceb2aecaa815a2a4152686"
  :revdesc "1df8583fafad"
  :keywords '("helm" "js" "codemod" "region")
  :authors '(("Torgeir Thoresen" . "@torgeir"))
  :maintainers '(("Torgeir Thoresen" . "@torgeir")))
