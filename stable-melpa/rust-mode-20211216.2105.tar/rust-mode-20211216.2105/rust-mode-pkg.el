(define-package "rust-mode" "20211216.2105" "A major-mode for editing Rust source code"
  '((emacs "25.1"))
  :commit "9b8d218d74269429c77b5f646ba2c2a2c66ff050" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages")
  :url "https://github.com/rust-lang/rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
