;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indexed" "20250319.1424"
  "Cache metadata on all Org files."
  '((emacs  "29.1")
    (llama  "0.5.0")
    (el-job "2.2.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "685fc996a221a2e31c999fd9a6a6ad2e6c51065d"
  :revdesc "685fc996a221"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
