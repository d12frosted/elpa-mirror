;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minuet" "20250217.237"
  "Code completion using LLM."
  '((emacs "29")
    (plz   "0.9")
    (dash  "2.19.1"))
  :url "https://github.com/milanglacier/minuet-ai.el"
  :commit "419484692277c0151157e70a8956fc5e3c489d67"
  :revdesc "419484692277"
  :authors '(("Milan Glacier" . "dev@milanglacier.com"))
  :maintainers '(("Milan Glacier" . "dev@milanglacier.com")))
