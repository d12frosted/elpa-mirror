(define-package "geiser" "20221022.2255" "GNU Emacs and Scheme talk to each other"
  '((emacs "25.1")
    (project "0.8.1"))
  :commit "fd58d38118e2c409db524ccc8ff213e8d98a43bf" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
