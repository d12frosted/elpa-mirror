(define-package "embark" "20211020.58" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "9a8bb2915aa57ed2151daf31b90c9c135c2f4989" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
