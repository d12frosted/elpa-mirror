;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "creole-mode" "20130722.50"
  "A markup mode for creole."
  ()
  :url "https://github.com/nicferrier/creole-mode"
  :commit "b5e79b2ec5f19fb5aacf689b5febc3e0b61515c4"
  :revdesc "b5e79b2ec5f1"
  :keywords '("hypermedia" "wp")
  :authors '(("Nic Ferrier" . "nferrier@ferrier.me.uk"))
  :maintainers '(("Nic Ferrier" . "nferrier@ferrier.me.uk")))
