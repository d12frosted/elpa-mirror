(define-package "magit-section" "20220223.2013" "Sections for read-only buffers"
  '((emacs "25.1")
    (dash "20210826"))
  :commit "0ab892a3b45f5ad7e7f335348c8276f8f8c525e1" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/magit/magit")
;; Local Variables:
;; no-byte-compile: t
;; End:
