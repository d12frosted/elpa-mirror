(define-package "blackjack" "20230619.5" "The game of Blackjack"
  '((emacs "26.2"))
  :commit "0d0e8fd54ab2ceec428dc9228403ff4686b7bacc" :authors
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainers
  '(("Greg Donald" . "gdonald@gmail.com"))
  :maintainer
  '("Greg Donald" . "gdonald@gmail.com")
  :keywords
  '("card" "game" "games" "blackjack" "21")
  :url "https://github.com/gdonald/blackjack-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
