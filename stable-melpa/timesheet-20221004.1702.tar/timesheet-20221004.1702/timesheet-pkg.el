(define-package "timesheet" "20221004.1702" "Timesheet management add-on for org-mode"
  '((s "1")
    (org "9"))
  :commit "511751b239c84d7619ec1c61d7f108b732b64442" :authors
  '(("Tom Marble"))
  :maintainer
  '("Tom Marble")
  :keywords
  '("org" "timesheet")
  :url "https://github.com/tmarble/timesheet.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
