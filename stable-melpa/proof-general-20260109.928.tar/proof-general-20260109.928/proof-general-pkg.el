;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "proof-general" "20260109.928"
  "A generic Emacs interface for proof assistants."
  '((emacs "25.2"))
  :url "https://proofgeneral.github.io/"
  :commit "649f8f0f1df614c96802e022b0ce0fbaeba6e4bf"
  :revdesc "649f8f0f1df6"
  :maintainers '((nil . "proof-general-maintainers@groupes.renater.fr")))
