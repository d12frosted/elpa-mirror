;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260202.1924"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "920112797c2a46c3fd31eceed91a244fbc07eb0e"
  :revdesc "920112797c2a"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
