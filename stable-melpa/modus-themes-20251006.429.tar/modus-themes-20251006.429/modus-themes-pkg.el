;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251006.429"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "933a92624745b0ef8d07847e1eaecacfd05158da"
  :revdesc "933a92624745"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
