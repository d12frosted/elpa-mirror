(define-package "awk-ts-mode" "20231022.437" "Major mode for awk using tree-sitter"
  '((emacs "29.1"))
  :commit "56eed1a18a4df76fcc98d62e18bfca688a574b9a" :authors
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainers
  '(("Noah Peart" . "noah.v.peart@gmail.com"))
  :maintainer
  '("Noah Peart" . "noah.v.peart@gmail.com")
  :keywords
  '("awk" "languages" "tree-sitter")
  :url "https://github.com/nverno/awk-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
