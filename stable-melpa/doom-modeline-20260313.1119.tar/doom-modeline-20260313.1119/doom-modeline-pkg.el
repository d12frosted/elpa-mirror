;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20260313.1119"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "fb0a15e950fc3e2ea5b078b4fab1ed92d319dadf"
  :revdesc "fb0a15e950fc"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
