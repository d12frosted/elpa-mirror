;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keycoach" "20260721.1501"
  "Learn keybindings."
  '((emacs "25.1"))
  :url "https://github.com/mrcnski/keycoach"
  :commit "fbd7bc410b2101f56b93e8bc3cc9afee76018ef2"
  :revdesc "fbd7bc410b21"
  :keywords '("help")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
