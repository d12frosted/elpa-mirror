;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ox-bibtex-chinese" "20170723.309"
  "Let ox-bibtex work well for Chinese users."
  '((emacs "24.4"))
  :url "https://github.com/tumashu/ox-bibtex-chinese.git"
  :commit "2ad2364399229144110db7ef6365ad0461d6a38c"
  :revdesc "2ad236439922"
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
