;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-msg" "20260211.901"
  "Org mode to send and reply to email in HTML."
  '((emacs   "24.4")
    (htmlize "1.54"))
  :url "https://github.com/jeremy-compostella/org-msg"
  :commit "aa608b399586fb771ad37045a837f8286a0b6124"
  :revdesc "aa608b399586"
  :keywords '("extensions" "mail")
  :authors '(("Jérémy Compostella" . "jeremy.compostella@gmail.com"))
  :maintainers '(("Jérémy Compostella" . "jeremy.compostella@gmail.com")))
