(define-package "modaled" "20240330.1645" "Build your own minor modes for modal editing"
  '((emacs "25.1"))
  :commit "5d67d0f81aa4ea693c7a4a3f2b874100b197d03f" :authors
  '(("DCsunset"))
  :maintainers
  '(("DCsunset"))
  :maintainer
  '("DCsunset")
  :keywords
  '("convenience" "modal-editing")
  :url "https://github.com/DCsunset/modaled")
;; Local Variables:
;; no-byte-compile: t
;; End:
