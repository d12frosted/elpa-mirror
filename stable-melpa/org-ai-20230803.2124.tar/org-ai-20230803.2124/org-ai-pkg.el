(define-package "org-ai" "20230803.2124" "Your AI assistant with ChatGPT, DALL-E, Whisper, Stable Diffusion"
  '((emacs "27"))
  :commit "be19a2cefca360629eeb61e3cea0dc60e55cf897" :authors
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainers
  '(("Robert Krahn" . "robert@kra.hn"))
  :maintainer
  '("Robert Krahn" . "robert@kra.hn")
  :url "https://github.com/rksm/org-ai")
;; Local Variables:
;; no-byte-compile: t
;; End:
