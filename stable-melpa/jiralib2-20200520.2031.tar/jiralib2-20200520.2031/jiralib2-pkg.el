;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jiralib2" "20200520.2031"
  "JIRA REST API bindings to Elisp."
  '((emacs   "25")
    (request "0.3")
    (dash    "2.14.1"))
  :url "https://github.com/nyyManni/jiralib2"
  :commit "c21c4e759eff549dbda11099f2f680b78d7f5a01"
  :revdesc "c21c4e759eff"
  :keywords '("comm" "jira" "rest" "api")
  :authors '(("Henrik Nyman" . "h@nyymanni.com"))
  :maintainers '(("Henrik Nyman" . "h@nyymanni.com")))
