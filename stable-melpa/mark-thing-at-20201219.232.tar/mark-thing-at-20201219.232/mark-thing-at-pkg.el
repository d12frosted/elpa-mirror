(define-package "mark-thing-at" "20201219.232" "Mark a pattern at the current point"
  '((emacs "26")
    (choice-program "0.13"))
  :commit "a622d128afc8d2d67de897666a1e2eccba8d7818" :authors
  '(("Paul Landes"))
  :maintainers
  '(("Paul Landes"))
  :maintainer
  '("Paul Landes")
  :keywords
  '("mark" "point" "lisp")
  :url "https://github.com/plandes/mark-thing-at")
;; Local Variables:
;; no-byte-compile: t
;; End:
