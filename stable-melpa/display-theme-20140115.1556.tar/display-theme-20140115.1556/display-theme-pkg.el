;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "display-theme" "20140115.1556"
  "Display current theme(s) at mode-line."
  '((emacs "24"))
  :url "https://github.com/kawabata/emacs-display-theme/"
  :commit "b180b3be7a74ae4799a14e7e4bc2fe10e3ff7a15"
  :revdesc "b180b3be7a74"
  :keywords '("tools")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
