;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indigo" "20260506.1617"
  "Emacs interface to the Indigo cheminformatics library."
  '((emacs "25.1"))
  :url "https://github.com/gicrisf/emacs-indigo"
  :commit "86433c884f5ef591ff8250b3322e5e9abd8a502d"
  :revdesc "86433c884f5e"
  :keywords '("data" "tools" "extensions")
  :authors '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com"))
  :maintainers '(("Giovanni Crisalfi" . "giovanni.crisalfi@protonmail.com")))
