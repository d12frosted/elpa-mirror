(define-package "bqn-mode" "20230423.1816" "Emacs mode for BQN"
  '((emacs "26.1"))
  :commit "b459f30498bf33efb73d095e1ff0ae98423c0e47" :authors
  '(("Marshall Lochbaum" . "mwlochbaum@gmail.com"))
  :maintainer
  '("Marshall Lochbaum" . "mwlochbaum@gmail.com")
  :url "https://github.com/museoa/bqn-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
