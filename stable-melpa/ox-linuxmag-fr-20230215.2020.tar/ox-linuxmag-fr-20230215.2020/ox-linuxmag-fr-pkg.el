(define-package "ox-linuxmag-fr" "20230215.2020" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "2c06d5441e9e67c3ce419bc84b1d4612f64ff40b" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
