;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241031.1204"
  "ChatGPT shell + buffer insert commands."
  '((emacs       "28.1")
    (shell-maker "0.58.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "a24c003c79a720eafffc79bc3885070735f667f6"
  :revdesc "a24c003c79a7")
