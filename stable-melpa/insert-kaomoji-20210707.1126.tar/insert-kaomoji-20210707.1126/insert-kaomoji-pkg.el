(define-package "insert-kaomoji" "20210707.1126" "Easily insert kaomojis"
  '((emacs "24.4"))
  :commit "e818845a99d418e04c1685f06fe25116916f6168" :authors
  '(("Philip K." . "philip@warpmail.net"))
  :maintainer
  '("Philip K." . "philip@warpmail.net")
  :keywords
  '("wp")
  :url "https://git.sr.ht/~pkal/insert-kaomoji")
;; Local Variables:
;; no-byte-compile: t
;; End:
