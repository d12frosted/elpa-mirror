(define-package "company" "20210328.2135" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "5c6c4942b4ff11b195edf0ee313205fa7fbf8bdd" :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
