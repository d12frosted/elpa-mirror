;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mssql" "20260507.1743"
  "MSSQL LSP bindings."
  '((emacs        "29.1")
    (lsp-mode     "6.2")
    (dash         "2.14.1")
    (f            "0.20.0")
    (ht           "2.0")
    (lsp-treemacs "0.1"))
  :url "https://github.com/emacs-lsp/lsp-mssql"
  :commit "02e50306c92af1c98473840169a477b22f72af2d"
  :revdesc "02e50306c92a"
  :keywords '("data" "languages")
  :authors '(("Ivan Yonchovski" . "yyoncho@gmail.com"))
  :maintainers '(("Ivan Yonchovski" . "yyoncho@gmail.com")))
