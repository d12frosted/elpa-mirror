(define-package "racket-mode" "20231129.1307" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "3f11c6c7644e518e3185da2577012e2a7c95c565" :authors
  '(("Greg Hendershott" . "racket-mode-author@greghendershott.com"))
  :maintainers
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
