;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bicycle" "20260820.2024"
  "Cycle outline and code visibility."
  '((emacs  "28.1")
    (compat "30.1"))
  :url "https://github.com/tarsius/bicycle"
  :commit "4b0efa33a9da40a327deb40fbf229e64b01dd650"
  :revdesc "4b0efa33a9da"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev")))
