;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cerbere" "20181113.1641"
  "Unit testing in Emacs for several programming languages."
  '((pkg-info "0.5"))
  :url "https://github.com/nlamirault/cerbere"
  :commit "bb18d932b16541105d41a668dbf6fc4e833a6dc2"
  :revdesc "bb18d932b165"
  :keywords '("python" "go" "php" "phpunit" "elisp" "ert" "tests" "tdd")
  :authors '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com"))
  :maintainers '(("Nicolas Lamirault" . "nicolas.lamirault@gmail.com")))
