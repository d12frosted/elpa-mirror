(define-package "sqlite3" "20220327.521" "Direct access to the core SQLite3 API"
  '((emacs "25.1"))
  :commit "7cb4b660fe30deb8a4229f3abb18bd99ca9c971c" :authors
  '(("Y. N. Lo" . "gordonynlo@yahoo.com"))
  :maintainer
  '("Y. N. Lo" . "gordonynlo@yahoo.com")
  :keywords
  '("comm" "data" "sql")
  :url "https://github.com/pekingduck/emacs-sqlite3-api")
;; Local Variables:
;; no-byte-compile: t
;; End:
