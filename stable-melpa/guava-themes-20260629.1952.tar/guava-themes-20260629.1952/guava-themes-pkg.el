;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260629.1952"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "aca2eef28526f323a761b9156348a38873310143"
  :revdesc "aca2eef28526"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
