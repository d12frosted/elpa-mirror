;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pycoverage" "20200513.2047"
  "Support for coverage stats on Python 2.X and 3."
  '((emacs "24.3"))
  :url "https://github.com/mattharrison/pycoverage.el"
  :commit "3c69ed312121368f1b24cc04d54a29ce4ed4f743"
  :revdesc "3c69ed312121"
  :keywords '("project" "convenience"))
