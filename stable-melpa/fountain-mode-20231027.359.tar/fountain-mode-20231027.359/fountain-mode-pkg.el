(define-package "fountain-mode" "20231027.359" "Major mode for screenwriting in Fountain markup"
  '((emacs "24.4")
    (seq "2.20"))
  :commit "a9c521590e720ab151ed601baf924928bce40bd7" :authors
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainers
  '(("Paul W. Rankin" . "hello@paulwrankin.com"))
  :maintainer
  '("Paul W. Rankin" . "hello@paulwrankin.com")
  :keywords
  '("wp" "text")
  :url "https://www.fountain-mode.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
