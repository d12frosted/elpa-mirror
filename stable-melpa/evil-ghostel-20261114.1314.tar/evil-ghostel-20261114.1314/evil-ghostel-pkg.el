;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-ghostel" "20261114.1314"
  "Evil-mode integration for ghostel."
  '((emacs   "28.1")
    (evil    "1.0")
    (ghostel "0.64.0"))
  :url "https://github.com/dakra/ghostel"
  :commit "9fd6310a71d1eb8a863767452e2fac30f76801fb"
  :revdesc "9fd6310a71d1"
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
