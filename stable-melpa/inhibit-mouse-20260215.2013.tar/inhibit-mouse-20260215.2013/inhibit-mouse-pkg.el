;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inhibit-mouse" "20260215.2013"
  "Deactivate mouse input (alternative to disable-mouse)."
  '((emacs "24.1"))
  :url "https://github.com/jamescherti/inhibit-mouse.el"
  :commit "cffda3c6fe4f662e1438a347259d914db410f2dd"
  :revdesc "cffda3c6fe4f"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
