;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "detour" "20181122.2138"
  "Take a quick detour and return."
  '((emacs "24.4"))
  :url "https://github.com/ska2342/detour/"
  :commit "f41f17cf1cf4f3db41563ff011786b6567596fb4"
  :revdesc "f41f17cf1cf4"
  :keywords '("convenience" "abbrev")
  :authors '(("Stefan Kamphausen" . "www.skamphausen.de"))
  :maintainers '(("Stefan Kamphausen" . "www.skamphausen.de")))
