;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260402.1201"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "c7fdecae07793253f99b27494744c1c8a0d62ebc"
  :revdesc "c7fdecae0779"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
