(define-package "moom" "20210213.721" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "2d7ca0b0ad76da4d11f8925e72904f03fd1c869e" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
