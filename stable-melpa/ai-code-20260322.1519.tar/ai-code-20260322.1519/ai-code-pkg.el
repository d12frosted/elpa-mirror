;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260322.1519"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "28.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "38d8f8c6a204c3958eec3903170664716e67e9b5"
  :revdesc "38d8f8c6a204"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
