;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "chatgpt-shell" "20241120.1812"
  "A multi-llm Emacs shell (ChatGPT, Claude, Gemini) + editing integrations."
  '((emacs       "28.1")
    (shell-maker "0.68.1"))
  :url "https://github.com/xenodium/chatgpt-shell"
  :commit "b9a9c71385d1d08a5474b5b2f14396439d1cbb99"
  :revdesc "b9a9c71385d1")
