(define-package "citre" "20210703.1556" "Ctags IDE on the True Editor"
  '((emacs "26.1"))
  :commit "64fe30edfaa5ac8a9f8b0113c10a53d09d88a0cc" :authors
  '(("Hao Wang" . "amaikinono@gmail.com"))
  :maintainer
  '("Hao Wang" . "amaikinono@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/universal-ctags/citre")
;; Local Variables:
;; no-byte-compile: t
;; End:
