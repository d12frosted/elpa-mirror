(define-package "autocrypt" "20220201.2102" "Autocrypt implementation"
  '((emacs "24.3"))
  :commit "8965ce57c7d206e5d28167a37c11b9713576b009" :authors
  '(("Philip Kaludercic" . "philipk@posteo.net"))
  :maintainer
  '("Philip Kaludercic" . "philipk@posteo.net")
  :keywords
  '("comm")
  :url "https://git.sr.ht/~pkal/autocrypt")
;; Local Variables:
;; no-byte-compile: t
;; End:
