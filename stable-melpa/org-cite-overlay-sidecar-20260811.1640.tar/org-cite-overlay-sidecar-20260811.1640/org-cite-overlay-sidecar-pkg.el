;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-cite-overlay-sidecar" "20260811.1640"
  "Show Sidecar for overlaid org-cite citations."
  '((emacs                      "28.1")
    (citeproc                   "0.9.4")
    (org-cite-overlay           "0.1.0")
    (universal-sidecar          "1.5.0")
    (universal-sidecar-citeproc "1.0.0"))
  :url "https://git.sr.ht/~swflint/org-cite-overlay"
  :commit "a5b8953f7f6788f025cd6e6f6ce5a9f32ad5408d"
  :revdesc "a5b8953f7f67"
  :keywords '("bib")
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
