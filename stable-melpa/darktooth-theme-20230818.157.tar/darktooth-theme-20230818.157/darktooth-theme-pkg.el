(define-package "darktooth-theme" "20230818.157" "From the darkness... it watches"
  '((emacs "27.1")
    (autothemer "0.2"))
  :commit "6910ebd3ec2441487a730ef98df591d6b1e0c671" :url "http://github.com/emacsfodder/emacs-theme-darktooth")
;; Local Variables:
;; no-byte-compile: t
;; End:
