;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exercism" "20241019.1120"
  "Unofficial https://exercism.org integration."
  '((emacs       "27.1")
    (dash        "2.19.1")
    (a           "1.0.0")
    (s           "1.13.1")
    (request     "0.3.2")
    (async       "1.9.6")
    (async-await "1.1")
    (persist     "0.5")
    (transient   "0.3.7"))
  :url "https://github.com/anonimitoraf/exercism.el"
  :commit "62c008b0e845c26f2e855969e9f87b405011a3ec"
  :revdesc "62c008b0e845"
  :keywords '("exercism" "convenience")
  :authors '(("Rafael Nicdao" . "https://github.com/anonimito"))
  :maintainers '(("Rafael Nicdao" . "nicdaoraf@gmail.com")))
