;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "conda-project" "20250415.1442"
  "Work with conda-project environments."
  '((emacs     "28.1")
    (s         "1.13.0")
    (yaml      "0.1.1")
    (pythonic  "0.2.0")
    (transient "0.8.6"))
  :url "https://github.com/gilbertwong96/conda-project.el"
  :commit "21becf078e21cc98a5890dff9049928c4712c235"
  :revdesc "21becf078e21"
  :keywords '("python" "conda-project" "tools")
  :authors '(("Gilbert" . "gilbertwong96@icloud.com"))
  :maintainers '(("Gilbert" . "gilbertwong96@icloud.com")))
