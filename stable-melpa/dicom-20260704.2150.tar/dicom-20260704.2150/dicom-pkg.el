;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20260704.2150"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "31"))
  :url "https://github.com/minad/dicom"
  :commit "50bfab3a34e502d6bac8ab12854cb33c8aff343c"
  :revdesc "50bfab3a34e5"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
