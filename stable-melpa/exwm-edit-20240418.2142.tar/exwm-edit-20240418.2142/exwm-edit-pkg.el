;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "exwm-edit" "20240418.2142"
  "Edit mode for EXWM."
  '((emacs "27.1"))
  :url "https://github.com/agzam/exwm-edit"
  :commit "046b8c11f71bfd6c798df770c6b7708af2c187a2"
  :revdesc "046b8c11f71b"
  :keywords '("convenience"))
