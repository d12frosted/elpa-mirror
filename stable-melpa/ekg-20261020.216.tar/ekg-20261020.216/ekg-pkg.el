;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261020.216"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "29.1")
    (llm     "0.30.0")
    (vui     "20261017.1157"))
  :url "https://github.com/ahyatt/ekg"
  :commit "3828b27cd9ea41e4f83463a5cc8ca3779d079fd7"
  :revdesc "3828b27cd9ea"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
