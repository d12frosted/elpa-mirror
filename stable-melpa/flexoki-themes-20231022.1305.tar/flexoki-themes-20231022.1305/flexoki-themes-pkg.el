(define-package "flexoki-themes" "20231022.1305" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "76b421243ca6352ac1742315abadc1b00b72e992" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
