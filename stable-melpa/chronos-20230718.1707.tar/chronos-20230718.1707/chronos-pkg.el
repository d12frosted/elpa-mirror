(define-package "chronos" "20230718.1707" "Multiple simultaneous countdown / countup timers"
  '((emacs "27.1")
    (consult "0.16"))
  :commit "9ca0d59cca7af98b44924646ae83fe0deb253c3b" :authors
  '(("David Knight" . "dxknight@opmbx.org"))
  :maintainers
  '(("David Knight" . "dxknight@opmbx.org"))
  :maintainer
  '("David Knight" . "dxknight@opmbx.org")
  :keywords
  '("calendar")
  :url "http://github.com/DarkBuffalo/chronos")
;; Local Variables:
;; no-byte-compile: t
;; End:
