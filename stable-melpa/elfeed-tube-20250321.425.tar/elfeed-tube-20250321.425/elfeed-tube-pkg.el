;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elfeed-tube" "20250321.425"
  "YouTube integration for Elfeed."
  '((emacs  "27.1")
    (elfeed "3.4.1")
    (aio    "1.0"))
  :url "https://github.com/karthink/elfeed-tube"
  :commit "5571ba48b83306d5ae21f0925d2a6b53480c715e"
  :revdesc "5571ba48b833"
  :keywords '("news" "hypermedia" "convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
