(define-package "fanyi" "20211013.1344" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "3515ee7e119835306e2a505d4a6fb190986945e4" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
