;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "minibuffer-modifier-keys" "20210823.713"
  "Use spacebar as a modifier key in the minibuffer."
  '((emacs "24.3"))
  :url "https://github.com/SpringHan/minibuffer-modifier-keys.git"
  :commit "944cdc01049f7e4b563675495f4d27cb018ca2f0"
  :revdesc "944cdc01049f"
  :keywords '("tools"))
