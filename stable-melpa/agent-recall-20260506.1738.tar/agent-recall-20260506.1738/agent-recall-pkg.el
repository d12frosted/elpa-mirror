;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-recall" "20260506.1738"
  "Search and browse agent-shell conversation transcripts."
  '((emacs       "29.1")
    (agent-shell "0.1.0"))
  :url "https://github.com/Marx-A00/agent-recall"
  :commit "f750a7022499bf885b838e4061b94098b0266fec"
  :revdesc "f750a7022499"
  :keywords '("tools" "convenience" "ai")
  :authors '(("Marcos Andrade" . "https://github.com/Marx-A00"))
  :maintainers '(("Marcos Andrade" . "https://github.com/Marx-A00")))
