(define-package "shampoo" "20121020.749" "Shampoo, a remote Smalltalk developemnt" 'nil :commit "9bf488ad4025beef6eef63d2d5b72bc1c9b9e142")
;; Local Variables:
;; no-byte-compile: t
;; End:
