;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250610.145"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "45cfb7ed31177aaaf78be9706d9864e22a3c9a20"
  :revdesc "45cfb7ed3117"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
