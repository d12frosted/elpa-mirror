;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fpga" "20260715.1713"
  "FPGA & ASIC Utils."
  '((emacs "29.1"))
  :url "https://github.com/gmlarumbe/fpga"
  :commit "cbf972cf8700291d904f8b922f5d919295d69a67"
  :revdesc "cbf972cf8700"
  :keywords '("tools")
  :authors '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com"))
  :maintainers '(("Gonzalo Larumbe" . "gonzalomlarumbe@gmail.com")))
