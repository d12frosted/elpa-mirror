;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-eglot" "20260214.2202"
  "Flycheck support for eglot."
  '((emacs    "28.1")
    (eglot    "1.9")
    (flycheck "32"))
  :url "https://github.com/flycheck/flycheck-eglot"
  :commit "f1b209297f739856723ea2dcaddbd9cd601fb05a"
  :revdesc "f1b209297f73"
  :keywords '("convenience" "language" "tools")
  :authors '(("Sergey Firsov" . "intramurz@gmail.com"))
  :maintainers '(("Sergey Firsov" . "intramurz@gmail.com")))
