;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250321.2350"
  "AI pair programming with Aider."
  '((emacs     "26.1")
    (transient "0.3.0")
    (compat    "30.0.2.0"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "b43bed23a45ad7a3577c1ac9d00b342eb4309c05"
  :revdesc "b43bed23a45a"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
