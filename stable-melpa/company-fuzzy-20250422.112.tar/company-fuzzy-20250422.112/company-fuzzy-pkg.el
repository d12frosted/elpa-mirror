;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company-fuzzy" "20250422.112"
  "Fuzzy matching for `company-mode'."
  '((emacs   "26.1")
    (company "0.8.12")
    (s       "1.12.0")
    (ht      "2.0"))
  :url "https://github.com/jcs-elpa/company-fuzzy"
  :commit "9c7019e500caaa3cb35ca27661f1d07714fb00c0"
  :revdesc "9c7019e500ca"
  :keywords '("matching" "auto-complete" "complete" "fuzzy")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
