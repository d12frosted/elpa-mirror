;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "base16-theme" "20260419.235"
  "Collection of themes built on combinations of 16 base colors."
  ()
  :url "https://github.com/tinted-theming/base16-emacs"
  :commit "8461432c62353f302b79bf0b2db2f99b83183dbe"
  :revdesc "8461432c6235"
  :authors '(("Kaleb Elwert" . "belak@coded.io"))
  :maintainers '(("Kaleb Elwert" . "belak@coded.io")))
