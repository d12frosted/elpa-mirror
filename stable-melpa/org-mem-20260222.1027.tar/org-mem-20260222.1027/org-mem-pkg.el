;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260222.1027"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.3")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "5e40d04461039863138d50f3fd2782cc654c3600"
  :revdesc "5e40d0446103"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
