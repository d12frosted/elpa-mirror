(define-package "osm" "20220326.1929" "OpenStreetMap viewer"
  '((emacs "27.1"))
  :commit "95f11d19446084801706f5fe3fc95c88586bb81d" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/osm")
;; Local Variables:
;; no-byte-compile: t
;; End:
