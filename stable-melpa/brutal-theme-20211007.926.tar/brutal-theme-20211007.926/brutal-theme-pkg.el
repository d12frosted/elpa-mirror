(define-package "brutal-theme" "20211007.926" "Brutalist theme"
  '((emacs "24.1"))
  :commit "0d7d3133b80a2f37abcc67daf608c418e6372543" :authors
  '(("Topi Kettunen" . "topi@kettunen.io"))
  :maintainer
  '("Topi Kettunen" . "topi@kettunen.io")
  :url "https://github.com/topikettunen/brutal-emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
