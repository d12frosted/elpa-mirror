(define-package "zk-index" "20230709.1112" "Index for zk"
  '((emacs "27.1")
    (zk "0.3"))
  :commit "91f1d4a3ad29e06d97d9a5fa3a4d1e6705ca828c" :authors
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainers
  '(("Grant Rosson <https://github.com/localauthor>"))
  :maintainer
  '("Grant Rosson <https://github.com/localauthor>")
  :url "https://github.com/localauthor/zk")
;; Local Variables:
;; no-byte-compile: t
;; End:
