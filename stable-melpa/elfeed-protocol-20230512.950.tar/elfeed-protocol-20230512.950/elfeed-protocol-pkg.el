(define-package "elfeed-protocol" "20230512.950" "Provide fever/newsblur/owncloud/ttrss protocols for elfeed"
  '((emacs "24.4")
    (elfeed "2.1.1")
    (cl-lib "0.5"))
  :commit "51983fba76f2287d4f6cbbf3705d1c8fa13ac747" :authors
  '(("Xu Fasheng <fasheng[AT]fasheng.info>"))
  :maintainers
  '(("Xu Fasheng <fasheng[AT]fasheng.info>"))
  :maintainer
  '("Xu Fasheng <fasheng[AT]fasheng.info>")
  :keywords
  '("news")
  :url "https://github.com/fasheng/elfeed-protocol")
;; Local Variables:
;; no-byte-compile: t
;; End:
