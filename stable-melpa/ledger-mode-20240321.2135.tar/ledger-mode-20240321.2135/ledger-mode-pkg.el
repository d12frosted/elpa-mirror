(define-package "ledger-mode" "20240321.2135" "Helper code for use with the \"ledger\" command-line tool"
  '((emacs "25.1"))
  :commit "6a09acd93dade8e15867b051c4524e312f7147b9")
;; Local Variables:
;; no-byte-compile: t
;; End:
