;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "the-matrix-theme" "20251031.320"
  "Green-on-black dark theme inspired by \"The Matrix\" movie."
  '((emacs "26.1"))
  :url "https://github.com/monkeyjunglejuice/matrix-emacs-theme"
  :commit "dc7b1c9b53343f2762c6ad1c2fb36b77f588bb9b"
  :revdesc "dc7b1c9b5334"
  :keywords '("faces" "theme")
  :authors '(("Dan Dee" . "monkeyjunglejuice@pm.me"))
  :maintainers '(("Dan Dee" . "monkeyjunglejuice@pm.me")))
