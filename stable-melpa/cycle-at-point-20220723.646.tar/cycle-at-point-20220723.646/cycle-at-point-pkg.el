(define-package "cycle-at-point" "20220723.646" "Cycle (rotate) the thing under the cursor"
  '((emacs "28.1")
    (recomplete "0.2"))
  :commit "d12be2e91337096f4fbf36029de57d4119a00e1d" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :keywords
  '("convenience")
  :url "https://codeberg.org/ideasman42/emacs-cycle-at-point")
;; Local Variables:
;; no-byte-compile: t
;; End:
