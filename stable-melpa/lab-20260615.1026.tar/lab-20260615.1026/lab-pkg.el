;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lab" "20260615.1026"
  "An interface for GitLab."
  '((emacs       "27.1")
    (request     "0.3.2")
    (s           "1.10.0")
    (f           "0.20.0")
    (compat      "29.1.4.4")
    (promise     "1.1")
    (async-await "1.1"))
  :url "https://github.com/isamert/lab.el"
  :commit "2d4035352432227b73a96987082a6caff9143e78"
  :revdesc "2d4035352432"
  :authors '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com"))
  :maintainers '(("Isa Mert Gurbuz" . "isamertgurbuz@gmail.com")))
