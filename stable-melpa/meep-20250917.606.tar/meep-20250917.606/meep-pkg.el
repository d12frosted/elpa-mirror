;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250917.606"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a458dc54aff93beb2d51a0693d2d7e6561fc934f"
  :revdesc "a458dc54aff9"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
