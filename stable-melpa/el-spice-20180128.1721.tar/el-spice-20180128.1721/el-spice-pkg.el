(define-package "el-spice" "20180128.1721" "Extra spice for emacs lisp programming" 'nil :commit "972dace20ec61cd27b9322432d0c7a688c6f061a" :authors
  '(("Vedang Manerikar" . "vedang.manerikar@gmail.com"))
  :maintainer
  '("Vedang Manerikar" . "vedang.manerikar@gmail.com")
  :keywords
  '("languages" "extensions")
  :url "https://github.com/vedang/el-spice")
;; Local Variables:
;; no-byte-compile: t
;; End:
