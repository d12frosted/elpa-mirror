;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260814.334"
  "Unified interface for AI coding backends such as Codex CLI, Antigravity CLI, Claude Code, Opencode, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "9d046a302c2902fa819d988309078361a6aef9fe"
  :revdesc "9d046a302c29"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
