(define-package "racket-mode" "20220321.1400" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "03ade92008941ed908e81a02127cd337dc96d9bc" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
