;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20241016.959"
  "Draw UNICODE lines, boxes & arrows with the keyboard."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "6ecebc38aba267abcc6d8c1cbf7994b2674e0a41"
  :revdesc "6ecebc38aba2"
  :keywords '("convenience" "text"))
