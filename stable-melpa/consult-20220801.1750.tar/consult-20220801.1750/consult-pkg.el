(define-package "consult" "20220801.1750" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "bd6fc14dac3943a0ea2b7d02d5abb0a841d29698" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
