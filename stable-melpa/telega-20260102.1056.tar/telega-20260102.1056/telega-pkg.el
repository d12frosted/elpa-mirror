;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "telega" "20260102.1056"
  "Telegram client (unofficial)."
  '((emacs              "27.1")
    (visual-fill-column "1.9")
    (transient          "0.3.0"))
  :url "https://github.com/zevlg/telega.el"
  :commit "933fe3f32f5093253613e648e75a40505b3889df"
  :revdesc "933fe3f32f50"
  :keywords '("comm")
  :authors '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainers '(("Zajcev Evgeny" . "zevlg@yandex.ru")))
