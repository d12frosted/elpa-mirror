;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251101.2239"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "242804bb963daffc09243621b0883af624836eb0"
  :revdesc "242804bb963d"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
