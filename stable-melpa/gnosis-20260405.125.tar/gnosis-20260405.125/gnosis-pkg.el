;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnosis" "20260405.125"
  "Knowledge System."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/gnosis"
  :commit "4f2b92dbdd26ce82bf82f3765db3505230e0cd95"
  :revdesc "4f2b92dbdd26"
  :keywords '("extensions")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
