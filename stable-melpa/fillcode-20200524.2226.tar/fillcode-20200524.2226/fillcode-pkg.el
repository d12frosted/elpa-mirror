;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fillcode" "20200524.2226"
  "Fill (wrap) function calls and expressions in source code."
  ()
  :url "https://snarfed.org/fillcode"
  :commit "4d206982b6aaa493d709c84aea206cabb8b4038c"
  :revdesc "4d206982b6aa"
  :authors '(("Ryan Barrett" . "fillcode@ryanb.org"))
  :maintainers '(("Ryan Barrett" . "fillcode@ryanb.org")))
