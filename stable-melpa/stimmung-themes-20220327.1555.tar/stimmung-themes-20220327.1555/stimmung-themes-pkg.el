(define-package "stimmung-themes" "20220327.1555" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "e8b574e370528e281f0465852a4a3964090c903a" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
