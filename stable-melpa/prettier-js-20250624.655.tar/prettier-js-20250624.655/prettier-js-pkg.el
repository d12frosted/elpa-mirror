;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "prettier-js" "20250624.655"
  "Minor mode to format JS code on file save."
  ()
  :url "https://github.com/prettier/prettier-emacs"
  :commit "589877598a612978121df0516cc60dc7bf8c06c3"
  :revdesc "589877598a61"
  :keywords '("convenience" "wp" "edit" "js"))
