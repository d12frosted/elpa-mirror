;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260501.1438"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ed31e2f8cd15d2abdae659be58d8682ea8e07c77"
  :revdesc "ed31e2f8cd15"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
