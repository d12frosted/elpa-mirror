;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "livescript-mode" "20221015.1316"
  "Major mode for editing LiveScript files."
  '((emacs "24.3"))
  :url "https://github.com/yhisamatsu/livescript-mode"
  :commit "e71a82a400e9d451c966c397bb8fa7887d35637b"
  :revdesc "e71a82a400e9"
  :keywords '("languages" "livescript")
  :authors '(("Hisamatsu Yasuyuki" . "yas@null.net"))
  :maintainers '(("Hisamatsu Yasuyuki" . "yas@null.net")))
