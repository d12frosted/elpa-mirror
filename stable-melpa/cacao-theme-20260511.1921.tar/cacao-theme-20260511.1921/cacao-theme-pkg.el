;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cacao-theme" "20260511.1921"
  "Based on a image reversal."
  '((emacs "24.1"))
  :url "https://github.com/Michael-Garibaldi/cacao-theme"
  :commit "24aae4373e5127a779a2b3041967e59944d24f6b"
  :revdesc "24aae4373e51")
