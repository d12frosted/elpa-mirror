;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "codespaces" "20260211.2124"
  "Connect to GitHub Codespaces via TRAMP."
  '((emacs "28.1"))
  :url "https://github.com/F4ban/codespaces.el"
  :commit "7fbbe2a1e4cacea542b81317bc493ab0c69f9555"
  :revdesc "7fbbe2a1e4ca"
  :keywords '("comm")
  :authors '(("Patrick Thomson" . "patrickt@github.com"))
  :maintainers '(("Patrick Thomson" . "patrickt@github.com")))
