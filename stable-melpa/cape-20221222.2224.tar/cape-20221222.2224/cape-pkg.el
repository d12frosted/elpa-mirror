(define-package "cape" "20221222.2224" "Completion At Point Extensions"
  '((emacs "27.1"))
  :commit "80d051389e3cc49367435f7b5d292d45c529ab49" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/cape")
;; Local Variables:
;; no-byte-compile: t
;; End:
