(define-package "epkg" "20230810.1304" "Browse the Emacsmirror package database"
  '((emacs "25.1")
    (compat "29.1.4.1")
    (closql "20230407")
    (emacsql "20230409")
    (llama "0.2.0"))
  :commit "b22da65653418290dc93f7c8b167e8600cdaedb0" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("tools")
  :url "https://github.com/emacscollective/epkg")
;; Local Variables:
;; no-byte-compile: t
;; End:
