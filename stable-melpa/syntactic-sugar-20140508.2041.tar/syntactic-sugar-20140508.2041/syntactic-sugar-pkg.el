;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "syntactic-sugar" "20140508.2041"
  "Effect-free forms such as if/then/else."
  ()
  :url "https://github.com/rolandwalker/syntactic-sugar"
  :commit "b6a49df4b6056e2619eea9ca554c105ae67e115f"
  :revdesc "b6a49df4b605"
  :keywords '("extensions")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
