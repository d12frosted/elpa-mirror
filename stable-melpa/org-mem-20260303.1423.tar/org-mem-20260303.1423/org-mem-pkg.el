;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260303.1423"
  "Fast info from a large number of Org file contents."
  '((emacs          "29.1")
    (el-job         "2.7.3")
    (llama          "1.0")
    (truename-cache "0.3.2"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "a37b885c46b086611b43841e666a5a9f57190b2f"
  :revdesc "a37b885c46b0"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
