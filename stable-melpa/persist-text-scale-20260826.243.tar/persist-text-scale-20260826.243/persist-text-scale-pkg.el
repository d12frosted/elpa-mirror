;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "persist-text-scale" "20260826.243"
  "Persist and restore text scale."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/persist-text-scale.el"
  :commit "dfedeeee6ef14d1d369b81fd25864dd85726af34"
  :revdesc "dfedeeee6ef1"
  :keywords '("convenience" "faces")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
