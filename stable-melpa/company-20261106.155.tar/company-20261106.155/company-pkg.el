;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "company" "20261106.155"
  "Modular text completion framework."
  '((emacs    "26.1")
    (posframe "1.5.1"))
  :url "http://company-mode.github.io/"
  :commit "ba9c346c43bbe3c904cec60364100f521c43faea"
  :revdesc "ba9c346c43bb"
  :keywords '("abbrev" "convenience" "matching")
  :maintainers '(("Dmitry Gutov" . "dmitry@gutov.dev")))
