(define-package "cask" "20210330.1656" "Cask: Project management for package development"
  '((emacs "24.1")
    (s "1.8.0")
    (f "0.16.0")
    (epl "0.5")
    (shut-up "0.1.0")
    (cl-lib "0.3")
    (package-build "1.2")
    (ansi "0.4.1"))
  :commit "663a2dfe4b202835b02dca009da15d27cbb7506b" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("speed" "convenience")
  :url "http://github.com/cask/cask")
;; Local Variables:
;; no-byte-compile: t
;; End:
