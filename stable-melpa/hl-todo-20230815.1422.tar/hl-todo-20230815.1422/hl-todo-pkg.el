(define-package "hl-todo" "20230815.1422" "Highlight TODO and similar keywords"
  '((emacs "25.1")
    (compat "29.1.4.2"))
  :commit "baba5efa49c2d10bebe259c779ac91de5212703a" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainers
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("convenience")
  :url "https://github.com/tarsius/hl-todo")
;; Local Variables:
;; no-byte-compile: t
;; End:
