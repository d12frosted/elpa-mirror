;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "rimel" "20260510.505"
  "A lightweight Rime input method."
  '((emacs    "29.4")
    (liberime "0.0.7"))
  :url "https://github.com/jixiuf/rimel"
  :commit "51907b5851b156fb062a25fdf8dbefa6ae36de3b"
  :revdesc "51907b5851b1"
  :keywords '("convenience" "chinese" "input-method" "rime"))
