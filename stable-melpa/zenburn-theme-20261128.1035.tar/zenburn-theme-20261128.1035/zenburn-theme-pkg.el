;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "zenburn-theme" "20261128.1035"
  "A low contrast color theme."
  ()
  :url "https://github.com/bbatsov/zenburn-emacs"
  :commit "6b9162dae7198259b505d7497b553c3f40a6bf3c"
  :revdesc "6b9162dae719"
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.com"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.com")))
