;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20261104.1817"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "29f3188319c5881f1bf9c34ea46bfc13a46578d9"
  :revdesc "29f3188319c5"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
