(define-package "wildcharm-theme" "20230813.1305" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "a8cd0ce9c812003613da07c62cdaefc0db943bab" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
