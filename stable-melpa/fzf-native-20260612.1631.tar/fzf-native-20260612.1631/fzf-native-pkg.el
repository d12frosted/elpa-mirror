;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fzf-native" "20260612.1631"
  "Fuzzy completion style."
  '((emacs "29.1"))
  :url "https://github.com/dangduc/fzf-native"
  :commit "2b1f678df935d175813f24b4062c0d074e0792b4"
  :revdesc "2b1f678df935"
  :keywords '("matching")
  :authors '(("Duc Dang" . "me@dangduc.com"))
  :maintainers '(("Duc Dang" . "me@dangduc.com")))
