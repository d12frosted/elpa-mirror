(define-package "consult-notes" "20220822.158" "Manage notes with consult"
  '((emacs "27.1")
    (consult "0.17")
    (s "1.12.0")
    (dash "2.19"))
  :commit "fd4091dd3655fdbbbb3fa15cfa96babe17c8b8b5" :authors
  '(("Colin McLear" . "mclear@fastmail.com"))
  :maintainer
  '("Colin McLear")
  :keywords
  '("convenience")
  :url "https://github.com/mclear-tools/consult-notes")
;; Local Variables:
;; no-byte-compile: t
;; End:
