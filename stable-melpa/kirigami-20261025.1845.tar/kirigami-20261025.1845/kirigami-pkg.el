;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kirigami" "20261025.1845"
  "A unified method to fold and unfold text."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/kirigami.el"
  :commit "a435a8f41c33e5824fe3aaf65ad01d0bba5f58e1"
  :revdesc "a435a8f41c33"
  :keywords '("outlines" "convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
