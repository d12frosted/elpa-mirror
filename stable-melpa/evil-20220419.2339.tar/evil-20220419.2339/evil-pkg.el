(define-package "evil" "20220419.2339" "Extensible Vi layer for Emacs."
  '((emacs "24.1")
    (goto-chg "1.6")
    (cl-lib "0.5"))
  :commit "2a5360eccc9bcb784e61c3b58ebe4690f2c7ea49" :maintainer
  '("Tom Dalziel" . "tom.dalziel@gmail.com")
  :keywords
  '("emulation" "vim")
  :url "https://github.com/emacs-evil/evil")
;; Local Variables:
;; no-byte-compile: t
;; End:
