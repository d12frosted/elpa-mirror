(define-package "org-projectile" "20230802.2300" "Repository todo management for org-mode"
  '((projectile "0.11.0")
    (dash "2.10.0")
    (emacs "24")
    (s "1.9.0")
    (org-category-capture "0.0.0"))
  :commit "b2a6ab28acef4a70d0305c29df41f682c4144533" :authors
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers
  '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainer
  '("Ivan Malison" . "IvanMalison@gmail.com")
  :keywords
  '("org-mode" "projectile" "todo" "tools" "outlines")
  :url "https://github.com/IvanMalison/org-projectile")
;; Local Variables:
;; no-byte-compile: t
;; End:
