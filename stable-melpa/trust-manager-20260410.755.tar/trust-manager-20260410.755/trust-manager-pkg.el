;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "trust-manager" "20260410.755"
  "Convenient trust management."
  '((emacs "30.1"))
  :url "https://git.sr.ht/~eshel/trust-manager"
  :commit "91b4149fdda86ac60771f2c131bf2a4741fe79b7"
  :revdesc "91b4149fdda8"
  :keywords '("security" "trust" "files")
  :authors '(("Eshel Yaron" . "me@eshelyaron.com"))
  :maintainers '(("Eshel Yaron" . "me@eshelyaron.com")))
