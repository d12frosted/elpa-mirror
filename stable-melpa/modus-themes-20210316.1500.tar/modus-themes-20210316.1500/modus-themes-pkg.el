(define-package "modus-themes" "20210316.1500" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "96f9c7452c6c2c2663cb7365a07ae0376c1a0cae" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
