(define-package "forth-mode" "20231201.1218" "Programming language mode for Forth"
  '((cl-lib "0.2"))
  :commit "1c66075bbced1e274da37c3cb6ced3e327391550" :authors
  '(("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainers
  '(("Lars Brinkhoff" . "lars@nocrew.org"))
  :maintainer
  '("Lars Brinkhoff" . "lars@nocrew.org")
  :keywords
  '("languages" "forth")
  :url "http://github.com/larsbrinkhoff/forth-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
