;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260212.2003"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "262cf10e51c0ffb26fab9edb228e6ed51650fcbe"
  :revdesc "262cf10e51c0"
  :keywords '("convenience"))
