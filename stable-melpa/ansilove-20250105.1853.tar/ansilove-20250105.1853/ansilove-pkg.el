;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ansilove" "20250105.1853"
  "Display buffers as PNG images using ansilove."
  '((emacs "26.1"))
  :url "https://gitlab.com/xgqt/emacs-ansilove/"
  :commit "a75eb6c89a1d96e1b4fa028ecca9be8b13c95230"
  :revdesc "a75eb6c89a1d"
  :keywords '("multimedia")
  :authors '(("Maciej Barć" . "xgqt@xgqt.org"))
  :maintainers '(("Maciej Barć" . "xgqt@xgqt.org")))
