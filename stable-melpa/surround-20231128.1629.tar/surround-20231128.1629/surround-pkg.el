(define-package "surround" "20231128.1629" "Easily add/delete/change parens, quotes, and more"
  '((emacs "24.3"))
  :commit "1346e7aae59d39db9b9e7c48d06821757964cfec" :authors
  '(("Michael Kleehammer" . "michael@kleehammer.com"))
  :maintainers
  '(("Michael Kleehammer" . "michael@kleehammer.com"))
  :maintainer
  '("Michael Kleehammer" . "michael@kleehammer.com")
  :url "https://github.com/mkleehammer/surround")
;; Local Variables:
;; no-byte-compile: t
;; End:
