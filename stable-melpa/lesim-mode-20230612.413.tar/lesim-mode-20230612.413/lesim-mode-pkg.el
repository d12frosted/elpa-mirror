(define-package "lesim-mode" "20230612.413" "Major mode for Learning Simulator scripts"
  '((emacs "28.1"))
  :commit "8c46f8b95ce09d88b2eda4cb24bd991a800d03ef" :authors
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainer
  '("Stefano Ghirlanda" . "drghirlanda@gmail.com")
  :keywords
  '("languages" "faces")
  :url "https://github.com/drghirlanda/lesim-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
