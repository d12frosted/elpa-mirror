(define-package "mentor" "20181029.2007" "Frontend for the rTorrent bittorrent client"
  '((xml-rpc "1.6.9")
    (seq "1.11")
    (cl-lib "0.5")
    (async "1.9.3"))
  :commit "9415472470ff23ee9600d94123c51c455d63018d" :authors
  '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainer
  '("Stefan Kangas" . "stefankangas@gmail.com")
  :keywords
  '("comm" "processes" "bittorrent"))
;; Local Variables:
;; no-byte-compile: t
;; End:
