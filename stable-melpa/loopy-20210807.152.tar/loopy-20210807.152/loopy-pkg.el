(define-package "loopy" "20210807.152" "A looping macro" 'nil :commit "0432fb250e7bd65f8c4a3852ebac499f173453e4" :authors
  '(("Earl Hyatt"))
  :maintainer
  '("Earl Hyatt")
  :keywords
  '("extensions")
  :url "https://github.com/okamsn/loopy")
;; Local Variables:
;; no-byte-compile: t
;; End:
