;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20250511.1700"
  "VERTical Interactive COmpletion."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "95d0d4c9aa0d13e4333cec0fdfdf19487e282a28"
  :revdesc "95d0d4c9aa0d"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
