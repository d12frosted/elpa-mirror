;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20241008.514"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "27.2"))
  :url "https://git.savannah.gnu.org/git/hyperbole.git"
  :commit "a8d5eaae30162e61dc854c904f831a83fcd4da8a"
  :revdesc "a8d5eaae3016"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
