(define-package "liberime" "20200502.7" "Rime elisp binding"
  '((emacs "24.1"))
  :commit "f13a98ddd7be658e742b0f42988b02db9d779e85" :authors
  '(("A.I."))
  :maintainer
  '("A.I.")
  :keywords
  '("input method" "rime"))
;; Local Variables:
;; no-byte-compile: t
;; End:
