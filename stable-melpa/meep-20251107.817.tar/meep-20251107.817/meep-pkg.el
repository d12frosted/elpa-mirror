;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251107.817"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "53cfadab78645675574bed2864f8fc9ae99e22d6"
  :revdesc "53cfadab7864"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
