(define-package "debian-el" "20231003.1834" "Emacs helpers specific to Debian users" 'nil :commit "c70e9e57d70a7a3449789a5f281af50ec8f4cb5b")
;; Local Variables:
;; no-byte-compile: t
;; End:
