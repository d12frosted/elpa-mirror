(define-package "wildcharm-theme" "20230803.801" "Port of vim-wildcharm colorscheme"
  '((emacs "24.1"))
  :commit "365c43a2a507e18c7c1d3be9cce0b1b7bb3a8c60" :authors
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainers
  '(("Maxim Kim" . "habamax@gmail.com"))
  :maintainer
  '("Maxim Kim" . "habamax@gmail.com")
  :url "https://github.com/habamax/wildcharm-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
