;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pair-tree" "20211219.1816"
  "Visualize a list."
  '((emacs "27.1")
    (dash  "2.17.0"))
  :url "https://github.com/zainab-ali/pair-tree"
  :commit "00bdaf9df933aaacbed66b5d666e2abc29870103"
  :revdesc "00bdaf9df933"
  :keywords '("lisp" "tools")
  :authors '(("Zainab Ali" . "zainab@kebab-ca.se"))
  :maintainers '(("Zainab Ali" . "zainab@kebab-ca.se")))
