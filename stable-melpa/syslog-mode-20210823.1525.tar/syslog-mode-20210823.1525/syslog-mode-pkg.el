(define-package "syslog-mode" "20210823.1525" "Major-mode for viewing log files & strace output"
  '((hide-lines "20130623")
    (ov "20150311"))
  :commit "156955b519177f4557d459564725ab4fe50b955e" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
