(define-package "helm-core" "20220802.631" "Development files for Helm"
  '((emacs "25.1")
    (async "1.9.4"))
  :commit "8c079ea56e1699ce3aa3afa87023e963e6a0e5c3" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
