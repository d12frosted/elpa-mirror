;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260626.718"
  "An Emacs plugin for GitHub Copilot."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "65015f0db9ba74a9e8e9b7a22e236f80d9b7dd94"
  :revdesc "65015f0db9ba"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
