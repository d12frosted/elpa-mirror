(define-package "humanoid-themes" "20201127.2125" "Color themes with a dark and light variant"
  '((emacs "24.3"))
  :commit "fbf23ea03a41f5b599b6c6b9dffdecb992eee830" :keywords
  ("faces" "color" "theme")
  :authors
  (("Thomas Friese"))
  :maintainer
  ("Thomas Friese")
  :url "https://github.com/humanoid-colors/emacs-humanoid-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
