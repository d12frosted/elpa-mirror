(define-package "consult-compile-multi" "20230620.1848" "Consulting read support for `compile-multi'"
  '((emacs "28.0")
    (compile-multi "0.3")
    (consult "0.34"))
  :commit "111db49b4debe3f56b643a5917e14da3d0e36988" :authors
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainers
  '(("mohsin kaleem" . "mohkale@kisara.moe"))
  :maintainer
  '("mohsin kaleem" . "mohkale@kisara.moe")
  :keywords
  '("tools" "compile" "build")
  :url "https://github.com/mohkale/compile-multi")
;; Local Variables:
;; no-byte-compile: t
;; End:
