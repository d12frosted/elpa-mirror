;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumber-jump" "20260722.550"
  "Jump to definition for 50+ languages without configuration."
  '((emacs "28.1")
    (s     "1.11.0")
    (dash  "2.9.0"))
  :url "https://github.com/zenspider/dumber-jump"
  :commit "6e74815e853c68834fd563d16f187f5dd73e4fa8"
  :revdesc "6e74815e853c"
  :keywords '("tools"))
