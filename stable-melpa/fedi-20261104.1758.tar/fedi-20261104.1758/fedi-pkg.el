;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fedi" "20261104.1758"
  "Helper functions for fediverse clients."
  '((emacs         "28.1")
    (markdown-mode "2.5"))
  :url "https://codeberg.org/martianh/fedi.el"
  :commit "1609066aa4c3ea6b6e780eb0a688b6ebdbac6357"
  :revdesc "1609066aa4c3"
  :authors '(("Marty Hiatt" . "martianh@disroot.org"))
  :maintainers '(("Marty Hiatt" . "martianh@disroot.org")))
