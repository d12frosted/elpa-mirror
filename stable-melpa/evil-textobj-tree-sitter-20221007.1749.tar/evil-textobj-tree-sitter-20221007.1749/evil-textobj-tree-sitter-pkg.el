(define-package "evil-textobj-tree-sitter" "20221007.1749" "Provides evil textobjects using tree-sitter"
  '((emacs "25.1")
    (evil "1.0.0")
    (tree-sitter "0.15.0"))
  :commit "3c9a444a14b5f000e909b9b24458332e2916c9fc" :keywords
  '("evil" "tree-sitter" "text-object" "convenience")
  :url "https://github.com/meain/evil-textobj-tree-sitter")
;; Local Variables:
;; no-byte-compile: t
;; End:
