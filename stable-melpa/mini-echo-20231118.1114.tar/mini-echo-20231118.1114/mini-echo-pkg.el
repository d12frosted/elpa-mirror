(define-package "mini-echo" "20231118.1114" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "17e4815bf3204df45b795cdd478c4400389d0202" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
