;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dialog-mode" "20260425.1901"
  "Major mode for editing Dialog files."
  '((emacs "28.1"))
  :url "https://git.sr.ht/~mew/dialog-mode"
  :commit "be5a4a24369c53dbb2efe7bbd3395aae386023fc"
  :revdesc "be5a4a24369c"
  :keywords '("languages")
  :authors '(("Morgan Willcock" . "morgan@ice9.digital"))
  :maintainers '(("Morgan Willcock" . "morgan@ice9.digital")))
