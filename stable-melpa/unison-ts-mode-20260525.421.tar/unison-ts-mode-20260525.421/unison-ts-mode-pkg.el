;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "unison-ts-mode" "20260525.421"
  "Tree-sitter support for Unison."
  '((emacs "29.1"))
  :url "https://github.com/fmguerreiro/unison-ts-mode"
  :commit "7949c0cd08a6b8b3ebc6dc6bc8ef96779aa5cb85"
  :revdesc "7949c0cd08a6"
  :keywords '("languages" "unison" "tree-sitter")
  :authors '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com"))
  :maintainers '(("Filipe Guerreiro" . "filipe.m.guerreiro@gmail.com")))
