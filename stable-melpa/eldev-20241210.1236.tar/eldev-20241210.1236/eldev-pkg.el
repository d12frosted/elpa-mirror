;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eldev" "20241210.1236"
  "Elisp development tool."
  '((emacs "24.4"))
  :url "https://github.com/emacs-eldev/eldev"
  :commit "dd2a4bf9a569fbfa30052f7ee13ce7dc2d9b4091"
  :revdesc "dd2a4bf9a569"
  :keywords '("maint" "tools")
  :authors '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers '(("Paul Pogonyshev" . "pogonyshev@gmail.com")))
