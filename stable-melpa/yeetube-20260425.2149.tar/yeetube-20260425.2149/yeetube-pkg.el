;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "yeetube" "20260425.2149"
  "Scrape YouTube, Play with mpv & Download with yt-dlp."
  '((emacs  "29.1")
    (compat "29.1.4.2"))
  :url "https://thanosapollo.org/projects/yeetube/"
  :commit "0a4495ef3a6a354d20ba1c980841f6bc79c6bc22"
  :revdesc "0a4495ef3a6a"
  :keywords '("extensions" "youtube" "videos")
  :authors '(("Thanos Apollo" . "public@thanosapollo.org"))
  :maintainers '(("Thanos Apollo" . "public@thanosapollo.org")))
