(define-package "nordic-night-theme" "20230727.1928" "A darker, more colorful version of the lovely Nord theme"
  '((emacs "24.1"))
  :commit "ae953b9c4046901e269dedcb62276c035efc2098" :authors
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainers
  '(("Ashton Wiersdorf" . "mail@wiersdorf.dev"))
  :maintainer
  '("Ashton Wiersdorf" . "mail@wiersdorf.dev")
  :url "https://sr.ht/~ashton314/nordic-night/")
;; Local Variables:
;; no-byte-compile: t
;; End:
