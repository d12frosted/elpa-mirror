;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250314.444"
  "AI pair programming with Aider."
  '((emacs "29.1"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "eb22b290675466bf06de5ff53f453cf5f9a67c24"
  :revdesc "eb22b2906754"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
