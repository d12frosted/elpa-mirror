(define-package "parse-it" "20210128.1345" "Basic Parser in Emacs Lisp"
  '((emacs "25.1")
    (s "1.12.0"))
  :commit "27a7b6ac6e92644160358958602aeae596ba8bad" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/parse-it")
;; Local Variables:
;; no-byte-compile: t
;; End:
