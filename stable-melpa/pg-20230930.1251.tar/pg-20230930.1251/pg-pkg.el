(define-package "pg" "20230930.1251" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "26.1"))
  :commit "761c22fe5dc742b31e8cdfb8ec4bca659d1de6fa" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
