;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20251122.1448"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "a472f546459a80f3c95255118831d35a6dcbddf0"
  :revdesc "a472f546459a"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
