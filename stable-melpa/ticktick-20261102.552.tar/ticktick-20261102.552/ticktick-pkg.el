;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ticktick" "20261102.552"
  "Sync Org Mode tasks with TickTick."
  '((emacs        "27.1")
    (request      "0.3.0")
    (simple-httpd "1.5.0"))
  :url "https://github.com/polhuang/ticktick.el"
  :commit "2a9b289c49fd980250bff8c5ee7fe13c7fa00d46"
  :revdesc "2a9b289c49fd"
  :keywords '("tools" "ticktick" "org" "tasks" "todo"))
