;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "julia-vterm" "20251229.137"
  "A mode for Julia REPL using vterm."
  '((emacs "25.1")
    (vterm "0.0.1"))
  :url "https://github.com/shg/julia-vterm.el"
  :commit "7f3321e338955e36019147ff5d2b5eeb43471259"
  :revdesc "7f3321e33895"
  :keywords '("languages" "julia"))
