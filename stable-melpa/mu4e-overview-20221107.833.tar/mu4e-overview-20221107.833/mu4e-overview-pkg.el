(define-package "mu4e-overview" "20221107.833" "Show overview of maildir"
  '((emacs "26"))
  :commit "21d4fbf44f67b786a61072afd20065a56b3952a1" :authors
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainers
  '(("Michał Krzywkowski" . "k.michal@zoho.com"))
  :maintainer
  '("Michał Krzywkowski" . "k.michal@zoho.com")
  :keywords
  '("mail" "tools")
  :url "https://github.com/mkcms/mu4e-overview")
;; Local Variables:
;; no-byte-compile: t
;; End:
