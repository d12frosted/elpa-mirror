(define-package "verb" "20201127.2022" "Organize and send HTTP requests"
  '((emacs "25.1"))
  :commit "ea6be4ad2bf9fdd2907df51b1cf51dd5bd356c40" :authors
  (("Federico Tedin" . "federicotedin@gmail.com"))
  :maintainer
  ("Federico Tedin" . "federicotedin@gmail.com")
  :keywords
  ("tools")
  :url "https://github.com/federicotdn/verb")
;; Local Variables:
;; no-byte-compile: t
;; End:
