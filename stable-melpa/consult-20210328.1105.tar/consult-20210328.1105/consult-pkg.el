(define-package "consult" "20210328.1105" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "3b032d17e5a9355821222ed5b732d956b3c65d81" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
