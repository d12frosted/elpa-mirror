;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "latex-to-svg-for-org" "20261018.1141"
  "Preview Org LaTeX math as SVG."
  '((emacs                 "29.1")
    (latex-to-svg-frontend "0.22.2"))
  :url "https://github.com/alberti42/latex-to-svg"
  :commit "8344784ee0e2086f24c84c1f6fe541535f17129f"
  :revdesc "8344784ee0e2"
  :keywords '("tex" "org" "math" "images")
  :authors '(("Andrea Alberti" . "a.alberti82@gmail.com"))
  :maintainers '(("Andrea Alberti" . "a.alberti82@gmail.com")))
