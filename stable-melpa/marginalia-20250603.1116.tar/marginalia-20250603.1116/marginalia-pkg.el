;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "marginalia" "20250603.1116"
  "Enrich existing commands with completion annotations."
  '((emacs  "28.1")
    (compat "30"))
  :url "https://github.com/minad/marginalia"
  :commit "d01144417ff5bbce906cffe06d1eb5828a38995c"
  :revdesc "d01144417ff5"
  :keywords '("docs" "help" "matching" "completion")
  :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
             ("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Omar Antolín Camarena" . "omar@matem.unam.mx")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
