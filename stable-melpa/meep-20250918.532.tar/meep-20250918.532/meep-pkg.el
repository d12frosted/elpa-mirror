;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20250918.532"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "48faf0b65df3701672c22163298a3363eaf642e1"
  :revdesc "48faf0b65df3"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
