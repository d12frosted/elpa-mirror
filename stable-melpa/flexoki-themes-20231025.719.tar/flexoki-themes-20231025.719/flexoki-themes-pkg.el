(define-package "flexoki-themes" "20231025.719" "An inky color scheme for prose and code"
  '((emacs "27.1"))
  :commit "edc28e2b8d9d2c8f820d996a74ccc4a7ba68cb6a" :authors
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainers
  '(("Andrew Jose" . "arnav.jose@gmail.com"))
  :maintainer
  '("Andrew Jose" . "arnav.jose@gmail.com")
  :keywords
  '("faces" "theme")
  :url "https://github.com/crmsnbleyd/flexoki-emacs-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
