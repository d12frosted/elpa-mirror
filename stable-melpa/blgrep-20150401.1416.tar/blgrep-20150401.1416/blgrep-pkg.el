;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blgrep" "20150401.1416"
  "Block grep."
  '((clmemo "20140321.715"))
  :url "https://github.com/ataka/blgrep"
  :commit "605beda210610a5829750a987f5fcebea97af546"
  :revdesc "605beda21061"
  :keywords '("tools" "convenience")
  :authors '(("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainers '(("Masayuki Ataka" . "masayuki.ataka@gmail.com")))
