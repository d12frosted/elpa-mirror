(define-package "blgrep" "20150401.1416" "Block grep"
  '((clmemo "20140321.715"))
  :commit "605beda210610a5829750a987f5fcebea97af546" :keywords
  ("tools" "convenience")
  :authors
  (("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
  :maintainer
  ("Masayuki Ataka" . "masayuki.ataka@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
