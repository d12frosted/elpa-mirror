(define-package "company" "20240729.6" "Modular text completion framework"
  '((emacs "25.1"))
  :commit "a45b6be404d55a29ab5b98bdb0a4aaf7fbae28b8" :maintainers
  '(("Dmitry Gutov" . "dmitry@gutov.dev"))
  :maintainer
  '("Dmitry Gutov" . "dmitry@gutov.dev")
  :keywords
  '("abbrev" "convenience" "matching")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
