;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lsp-mode" "20251217.631"
  "LSP mode."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (f             "0.21.0")
    (ht            "2.3")
    (spinner       "1.7.3")
    (markdown-mode "2.3")
    (lv            "0")
    (eldoc         "1.11"))
  :url "https://github.com/emacs-lsp/lsp-mode"
  :commit "33606723f8d95b4da780a2f73c5c283398d6022c"
  :revdesc "33606723f8d9"
  :keywords '("languages"))
