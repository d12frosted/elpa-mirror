;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claude-code" "20250918.1025"
  "Run Claude Code sessions."
  '((emacs         "28.1")
    (projectile    "2.5.0")
    (vterm         "0.0.2")
    (transient     "0.4.0")
    (markdown-mode "2.5"))
  :url "https://github.com/yuya373/claude-code-emacs"
  :commit "b221b8adfd498a63abbfd5acd90f1115e2c0dd58"
  :revdesc "b221b8adfd49"
  :keywords '("tools" "convenience"))
