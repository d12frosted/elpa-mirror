(define-package "inf-ruby" "20230929.114" "Run a Ruby process in a buffer"
  '((emacs "26.1"))
  :commit "deb2dc0837ab998a2b7d9aa9b6d474e0659fa5d1" :authors
  '(("Yukihiro Matsumoto")
    ("Nobuyoshi Nakada")
    ("Cornelius Mika" . "cornelius.mika@gmail.com")
    ("Dmitry Gutov" . "dgutov@yandex.ru")
    ("Kyle Hargraves" . "pd@krh.me"))
  :maintainers
  '(("Dmitry Gutov" . "dgutov@yandex.ru"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :keywords
  '("languages" "ruby")
  :url "http://github.com/nonsequitur/inf-ruby")
;; Local Variables:
;; no-byte-compile: t
;; End:
