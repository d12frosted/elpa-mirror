(define-package "helm" "20240926.1220" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "4.0")
    (wfnames "1.2"))
  :commit "a8ef7a391e64c261c9b8ce758abc0e92a51fcfeb" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("helm" "convenience" "files" "buffers" "grep" "completion" "lisp" "matching" "tools" "help")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
