;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tbindent" "20251124.1348"
  "Tab Based Indentation Converter."
  '((emacs "24.3"))
  :url "https://github.com/pierre-rouleau/tab-based-indent"
  :commit "ac9fc2f17e460c95985792d7bf51b33627ea6b1d"
  :revdesc "ac9fc2f17e46"
  :keywords '("convenience" "languages")
  :authors '(("Pierre Rouleau" . "prouleau001@gmail.com"))
  :maintainers '(("Pierre Rouleau" . "prouleau001@gmail.com")))
