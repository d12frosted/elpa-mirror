(define-package "stimmung-themes" "20230420.832" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "968af8491f619a71334875b760fb6ddab63aefae" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
