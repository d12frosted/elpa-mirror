(define-package "vterm" "20210206.1603" "Fully-featured terminal emulator"
  '((emacs "25.1"))
  :commit "bfdb0c9deef2cdeb2c6c7e17f89e39165f8ec7b5" :authors
  '(("Lukas Fürmetz" . "fuermetz@mailbox.org"))
  :maintainer
  '("Lukas Fürmetz" . "fuermetz@mailbox.org")
  :keywords
  '("terminals")
  :url "https://github.com/akermu/emacs-libvterm")
;; Local Variables:
;; no-byte-compile: t
;; End:
