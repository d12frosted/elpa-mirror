(define-package "lsp-mode" "20231101.1732" "LSP mode"
  '((emacs "27.1")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.3")
    (spinner "1.7.3")
    (markdown-mode "2.3")
    (lv "0")
    (eldoc "1.11"))
  :commit "7e1942ed6bfae784429233707444271c3ceb270e" :authors
  '(("Vibhav Pant, Fangrui Song, Ivan Yonchovski"))
  :maintainers
  '(("Vibhav Pant, Fangrui Song, Ivan Yonchovski"))
  :maintainer
  '("Vibhav Pant, Fangrui Song, Ivan Yonchovski")
  :keywords
  '("languages")
  :url "https://github.com/emacs-lsp/lsp-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
