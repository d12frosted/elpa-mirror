;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260324.452"
  "Unified interface for AI coding backends such as Codex CLI, Copilot CLI, Claude Code, Gemini CLI, Opencode, Grok CLI, etc."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "4e260e54e0bea9b03eb7e7e7b9c7d90961bc89c9"
  :revdesc "4e260e54e0be"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
