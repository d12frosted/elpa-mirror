(define-package "dired-gitignore" "20230909.1019" "A minor mode to hide gitignored files in a dired buffer"
  '((emacs "27.1"))
  :commit "eb30f09d3e33d654e3263c791241c1aad6d09233" :authors
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainer
  '("Johannes Mueller" . "github@johannes-mueller.org")
  :keywords
  '("dired" "convenience" "git")
  :url "https://github.com/johannes-mueller/dired-gitignore.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
