;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260729.1838"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "0a51a93f8b76ca1dd05568b298090a76852d197f"
  :revdesc "0a51a93f8b76"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
