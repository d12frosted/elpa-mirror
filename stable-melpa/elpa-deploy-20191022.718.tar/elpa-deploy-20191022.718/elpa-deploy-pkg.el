;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elpa-deploy" "20191022.718"
  "ELPA deployment library."
  '((emacs "24.4")
    (f     "0.0"))
  :url "https://github.com/oitofelix/elpa-deploy"
  :commit "f5126a2da1e0e52981fad9c12028814be80328c2"
  :revdesc "f5126a2da1e0"
  :keywords '("tools")
  :authors '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org"))
  :maintainers '(("Bruno Félix Rezende Ribeiro" . "oitofelix@gnu.org")))
