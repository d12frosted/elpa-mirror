(define-package "magik-mode" "20230803.1333" "mode for editing Magik + some utils."
  '((emacs "24.4")
    (compat "28.1"))
  :commit "628e827e086b1a0fbb3d373e3fab8857d3742348" :keywords
  '("languages")
  :url "http://github.com/roadrunner1776/magik")
;; Local Variables:
;; no-byte-compile: t
;; End:
