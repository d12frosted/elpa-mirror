;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flyspell-lazy" "20210308.1253"
  "Improve flyspell responsiveness using idle timers."
  ()
  :url "https://github.com/rolandwalker/flyspell-lazy"
  :commit "0fc5996bcee20b46cbd227ae948d343c3bef7339"
  :revdesc "0fc5996bcee2"
  :keywords '("spelling")
  :authors '(("Roland Walker" . "walker@pobox.com"))
  :maintainers '(("Roland Walker" . "walker@pobox.com")))
