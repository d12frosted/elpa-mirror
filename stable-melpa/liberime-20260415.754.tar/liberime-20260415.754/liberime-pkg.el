;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "liberime" "20260415.754"
  "Rime elisp binding."
  '((emacs "25.1"))
  :url "https://github.com/merrickluo/liberime"
  :commit "6e8cc1cbadaafae5f99524d1d4dc8fcf115685be"
  :revdesc "6e8cc1cbadaa"
  :keywords '("convenience" "chinese" "input-method" "rime"))
