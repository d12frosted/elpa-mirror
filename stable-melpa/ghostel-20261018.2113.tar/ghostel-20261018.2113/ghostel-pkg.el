;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20261018.2113"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "ccc1e5085d66e3468eca64bdc1560f7c042554ad"
  :revdesc "ccc1e5085d66"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
