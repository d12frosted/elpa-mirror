(define-package "gcode-mode" "20221205.116" "Simple G-Code major mode"
  '((emacs "24.4"))
  :commit "3b17b5ba85e5a05dac79b15b5231ad41f0a0fce5" :authors
  '(("Yuri D'Elia" . "wavexx@thregr.org"))
  :maintainer
  '("Yuri D'Elia" . "wavexx@thregr.org")
  :keywords
  '("gcode" "languages" "highlight" "syntax")
  :url "https://gitlab.com/wavexx/gcode-mode.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
