;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "loopy" "20251008.156"
  "A looping macro."
  '((emacs  "27.1")
    (map    "3.3.1")
    (seq    "2.22")
    (compat "29.1.3")
    (stream "2.4.0"))
  :url "https://github.com/okamsn/loopy"
  :commit "218c241c5ef0742de89cc63258545dca84facf8e"
  :revdesc "218c241c5ef0"
  :keywords '("extensions"))
