;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20260826.1614"
  "AI pair programming with Aider."
  '((emacs         "26.1")
    (transient     "0.3.0")
    (compat        "30.0.2.0")
    (markdown-mode "2.7"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "d6f0489efba1ecbf70f2db9ae7ee0c64eb7d98df"
  :revdesc "d6f0489efba1"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
