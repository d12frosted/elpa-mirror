(define-package "helm-org-ql" "20230310.1225" "Helm support for org-ql"
  '((emacs "26.1")
    (dash "2.18.1")
    (s "1.12.0")
    (helm-org "1.0")
    (org-ql "0.6pre"))
  :commit "aadddc4d84a72fa80d3bf909c9a3a4cbce53cd93" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :url "https://github.com/alphapapa/org-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
