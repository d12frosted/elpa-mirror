(define-package "helm" "20240820.859" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.9")
    (wfnames "1.2"))
  :commit "ce2fe592a03f418ab82c60054376b28a1373637a" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :keywords
  '("helm" "convenience" "files" "completion" "lisp" "matching" "tools" "help")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
