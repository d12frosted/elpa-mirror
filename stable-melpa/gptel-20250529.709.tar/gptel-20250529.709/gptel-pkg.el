;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250529.709"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "a5424aea257f5a522f08bd24979cabb311cd436f"
  :revdesc "a5424aea257f"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
