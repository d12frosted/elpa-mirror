(define-package "cask" "20210313.1606" "Cask: Project management for package development"
  '((emacs "24.1")
    (s "1.8.0")
    (f "0.16.0")
    (epl "0.5")
    (shut-up "0.1.0")
    (cl-lib "0.3")
    (package-build "1.2")
    (ansi "0.4.1"))
  :commit "6fe0a7230ced9c6e91c94a91bc6359f5e4b60545" :authors
  '(("Johan Andersson" . "johan.rejeep@gmail.com"))
  :maintainer
  '("Johan Andersson" . "johan.rejeep@gmail.com")
  :keywords
  '("speed" "convenience")
  :url "http://github.com/cask/cask")
;; Local Variables:
;; no-byte-compile: t
;; End:
