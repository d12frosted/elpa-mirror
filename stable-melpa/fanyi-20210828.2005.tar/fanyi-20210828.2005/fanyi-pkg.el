(define-package "fanyi" "20210828.2005" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "329dc03d0a3bfe46df31333db5be8aab79e430ea" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
