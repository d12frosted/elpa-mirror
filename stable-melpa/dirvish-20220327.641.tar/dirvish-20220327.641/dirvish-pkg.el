(define-package "dirvish" "20220327.641" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "c675984a5a84c359f69780eb42e5bf6c9c30db9d" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
