(define-package "modus-themes" "20211225.1234" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "2180adb0feb5da2ad4fbc6cd87750d13cc04c731" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
