;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "klondike" "20250301.2336"
  "Klondike."
  '((emacs "28.1"))
  :url "https://codeberg.org/tomenzgg/Emacs-Klondike"
  :commit "891cc54c1d9411f7848a4bba34811370ae19960e"
  :revdesc "891cc54c1d94"
  :keywords '("games" "cards" "solitaire" "klondike")
  :authors '(("Jean Libète" . "tomenzgg@mail.mayfirst.org"))
  :maintainers '(("Jean Libète" . "tomenzgg@mail.mayfirst.org")))
