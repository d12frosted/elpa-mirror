;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ert-gwt" "20261123.1259"
  "GWT-style BDD testing for ERT."
  '((emacs "29.4"))
  :url "https://github.com/OverbearingPearl/ert-gwt"
  :commit "0cec8ab97d2ac0f4ad9931eea094d33539d465f1"
  :revdesc "0cec8ab97d2a"
  :keywords '("lisp" "tools")
  :authors '(("OverbearingPearl" . "OverbearingPearl@outlook.com"))
  :maintainers '(("OverbearingPearl" . "OverbearingPearl@outlook.com")))
