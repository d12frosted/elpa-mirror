(define-package "lyrics-fetcher" "20210828.813" "Fetch song lyrics and album covers"
  '((emacs "27")
    (emms "7.5")
    (f "0.20.0")
    (request "0.3.2"))
  :commit "4545f5c5609166198b5f6f2e12de7309d294b629" :authors
  '(("Korytov Pavel" . "thexcloud@gmail.com"))
  :maintainer
  '("Korytov Pavel" . "thexcloud@gmail.com")
  :url "https://github.com/SqrtMinusOne/lyrics-fetcher.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
