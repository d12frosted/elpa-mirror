;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260314.8"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "d2628b9572842b9411ae276430374c9f72e21fef"
  :revdesc "d2628b957284"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
