;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vertico" "20260209.703"
  "VERTical Interactive COmpletion."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/vertico"
  :commit "8bb6751709c4d84eb539b1eea6413a81439ce29e"
  :revdesc "8bb6751709c4"
  :keywords '("convenience" "files" "matching" "completion")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
