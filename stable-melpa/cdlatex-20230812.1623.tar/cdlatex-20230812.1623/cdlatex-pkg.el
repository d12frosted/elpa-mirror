(define-package "cdlatex" "20230812.1623" "Fast input methods for LaTeX environments and math" 'nil :commit "c13f089e960c5596a769cb445955eacf020f61b0" :authors
  '(("Carsten Dominik" . "carsten.dominik@gmail.com"))
  :maintainers
  '(("Carsten Dominik" . "carsten.dominik@gmail.com"))
  :maintainer
  '("Carsten Dominik" . "carsten.dominik@gmail.com")
  :keywords
  '("tex"))
;; Local Variables:
;; no-byte-compile: t
;; End:
