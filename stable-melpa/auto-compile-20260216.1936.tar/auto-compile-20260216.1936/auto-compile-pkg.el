;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "auto-compile" "20260216.1936"
  "Automatically compile Emacs Lisp libraries."
  '((emacs "27.1"))
  :url "https://github.com/emacscollective/auto-compile"
  :commit "dd04f51af45ebac3a1fdb887d90948186a76ddb7"
  :revdesc "dd04f51af45e"
  :keywords '("compile" "convenience" "lisp")
  :authors '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.auto-compile@jonas.bernoulli.dev")))
