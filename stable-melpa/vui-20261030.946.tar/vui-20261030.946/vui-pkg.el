;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vui" "20261030.946"
  "Declarative, component-based UI library."
  '((emacs "29.1"))
  :url "https://github.com/d12frosted/vui.el"
  :commit "772808047e03eac8f6bb38dc7100a784ce302806"
  :revdesc "772808047e03"
  :keywords '("ui" "widgets" "tools")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
