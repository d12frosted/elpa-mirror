(define-package "igist" "20230809.756" "List, create, update and delete GitHub gists"
  '((emacs "27.1")
    (ghub "3.5.6")
    (transient "0.3.7"))
  :commit "99d429d8ebe3cbe709d163bb3746b2a3fa0f4a82" :authors
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainers
  '(("Karim Aziiev" . "karim.aziiev@gmail.com"))
  :maintainer
  '("Karim Aziiev" . "karim.aziiev@gmail.com")
  :keywords
  '("tools")
  :url "https://github.com/KarimAziev/igist")
;; Local Variables:
;; no-byte-compile: t
;; End:
