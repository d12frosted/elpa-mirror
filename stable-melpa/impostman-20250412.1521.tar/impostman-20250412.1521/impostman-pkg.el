;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "impostman" "20250412.1521"
  "Import Postman collections."
  '((emacs "27.1"))
  :url "https://github.com/flashcode/impostman"
  :commit "c1e764b16d32930d157e5bf2d2e6ac4dc3a23b8c"
  :revdesc "c1e764b16d32"
  :keywords '("tools")
  :authors '(("Sébastien Helleu" . "flashcode@flashtux.org"))
  :maintainers '(("Sébastien Helleu" . "flashcode@flashtux.org")))
