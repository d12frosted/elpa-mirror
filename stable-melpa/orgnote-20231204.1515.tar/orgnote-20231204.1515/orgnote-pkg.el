(define-package "orgnote" "20231204.1515" "Sync org roam notes with OrgNote app"
  '((emacs "27.1"))
  :commit "3ea51324172a80ce0e50f18209a1c1a628debcc4" :authors
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainers
  '(("Artur Yaroshenko" . "artawower@protonmail.com"))
  :maintainer
  '("Artur Yaroshenko" . "artawower@protonmail.com")
  :url "https://github.com/Artawower/orgnote.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
