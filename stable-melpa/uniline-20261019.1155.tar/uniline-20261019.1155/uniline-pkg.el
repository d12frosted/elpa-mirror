;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "uniline" "20261019.1155"
  "Add▶ ■─UNICODE based diagrams─■ to▶ ■─text files─■."
  '((emacs "29.1")
    (hydra "0.15.0"))
  :url "https://github.com/tbanel/uniline"
  :commit "67c0632e30799ff39e54d4b9b7c192ac7014d190"
  :revdesc "67c0632e3079"
  :keywords '("convenience" "text"))
