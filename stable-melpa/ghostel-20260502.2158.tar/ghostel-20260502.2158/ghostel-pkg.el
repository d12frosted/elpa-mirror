;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260502.2158"
  "Terminal emulator powered by libghostty."
  '((emacs "28.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b99761f8808d4812d62ee95015c9ce8e97ac6db5"
  :revdesc "b99761f8808d"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
