;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "commify" "20240131.1455"
  "Toggle grouping commas in numbers."
  '((s "1.9.0"))
  :url "https://github.com/ddoherty03/commify"
  :commit "1245bfe420e92b4274bce3421ee59ea201e72aaa"
  :revdesc "1245bfe420e9"
  :keywords '("convenience" "editing" "numbers" "grouping" "commas")
  :authors '(("Daniel E. Doherty" . "ded-commify@ddoherty.net"))
  :maintainers '(("Daniel E. Doherty" . "ded-commify@ddoherty.net")))
