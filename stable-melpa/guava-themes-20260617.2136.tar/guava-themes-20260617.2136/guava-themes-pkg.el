;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260617.2136"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "6b1329c7e28c414dce3feaaf15b3007409da61a3"
  :revdesc "6b1329c7e28c"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
