(define-package "mallard-mode" "20131204.425" "Major mode for editing Mallard files" 'nil :commit "c48170c1ace4959abcc5fb1df0d4cb149cff44c1" :keywords
  ("xml" "mallard")
  :authors
  (("Jaromir Hradilek" . "jhradilek@gmail.com"))
  :maintainer
  ("Jaromir Hradilek" . "jhradilek@gmail.com")
  :url "https://github.com/jhradilek/emacs-mallard-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
