(define-package "mallard-mode" "20131204.425" "Major mode for editing Mallard files" 'nil :commit "0a4cfede57bc31134495804ce513cc106de8de3c" :authors
  '(("Jaromir Hradilek" . "jhradilek@gmail.com"))
  :maintainer
  '("Jaromir Hradilek" . "jhradilek@gmail.com")
  :keywords
  '("xml" "mallard")
  :url "https://github.com/jhradilek/emacs-mallard-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
