;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pig-snippets" "20130913.624"
  "Snippets for pig-mode."
  '((yasnippet "0.8.0"))
  :url "https://github.com/motus/pig-mode"
  :commit "69ca24cb756dd516828e284e33274145eba21183"
  :revdesc "69ca24cb756d"
  :keywords '("snippets")
  :authors '(("Peter Vasil" . "mail@petervasil.net"))
  :maintainers '(("Peter Vasil" . "mail@petervasil.net")))
