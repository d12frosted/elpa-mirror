;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20241020.804"
  "Elegant, highly legible and customizable themes."
  '((emacs "27.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "107df813fb913b1f965320b4a4d4bc6542a763eb"
  :revdesc "107df813fb91"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
