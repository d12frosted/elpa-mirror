(define-package "consult" "20211214.1713" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "39366355f4897dfae73d14d93dbe6ca97f7fc713" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
