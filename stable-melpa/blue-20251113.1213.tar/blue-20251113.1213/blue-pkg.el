;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20251113.1213"
  "BLUE build system interface."
  '((emacs         "30.1")
    (magit-section "4.3.8"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "62f401d19e80754a3df7f135a8fa77e78049bafa"
  :revdesc "62f401d19e80"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
