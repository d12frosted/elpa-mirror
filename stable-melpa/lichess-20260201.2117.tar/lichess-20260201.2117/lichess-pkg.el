;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "20260201.2117"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "537fb54ff4eaf0f932a78d951695e20d696d59f3"
  :revdesc "537fb54ff4ea"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
