;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250323.1147"
  "Ollama Buddy: Your Friendly AI Assistant."
  '((emacs "28.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "43e6b1fb5d50f9a313b15712968ffcbc49f7ddf0"
  :revdesc "43e6b1fb5d50"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
