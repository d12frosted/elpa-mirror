(define-package "affe" "20230120.2009" "Asynchronous Fuzzy Finder for Emacs"
  '((emacs "27.1")
    (consult "0.20"))
  :commit "17c99c8297c71580de23e6066134ec6a31f954b7" :authors
  '(("Daniel Mendler"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/affe")
;; Local Variables:
;; no-byte-compile: t
;; End:
