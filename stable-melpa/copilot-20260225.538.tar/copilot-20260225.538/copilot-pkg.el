;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260225.538"
  "An unofficial Copilot plugin."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "0e1c017162f50dbceb32cd00d4d6d41ddde71b2b"
  :revdesc "0e1c017162f5"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Rakotomandimby Mihamina" . "mihamina.rakotomandimby@rktmb.org")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
