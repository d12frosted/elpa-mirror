(define-package "elfeed-protocol" "20230917.1738" "Provide fever/newsblur/owncloud/ttrss protocols for elfeed"
  '((emacs "24.4")
    (elfeed "2.1.1")
    (cl-lib "0.5"))
  :commit "9d4c18aefef75fd23f8c3568fb842dc92870f3df" :authors
  '(("Xu Fasheng <fasheng[AT]fasheng.info>"))
  :maintainers
  '(("Xu Fasheng <fasheng[AT]fasheng.info>"))
  :maintainer
  '("Xu Fasheng <fasheng[AT]fasheng.info>")
  :keywords
  '("news")
  :url "https://github.com/fasheng/elfeed-protocol")
;; Local Variables:
;; no-byte-compile: t
;; End:
