;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-people" "20260316.1806"
  "Work with a contact-list in org-mode files."
  '((emacs "29.1")
    (org   "9.0"))
  :url "https://github.com/skx/org-people"
  :commit "017f2c1746ed5a07bf0012dffd09964c67442fe4"
  :revdesc "017f2c1746ed"
  :keywords '("outlines" "contacts" "people")
  :authors '(("Steve Kemp" . "steve@steve.fi"))
  :maintainers '(("Steve Kemp" . "steve@steve.fi")))
