;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20260129.2350"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.24.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "http://github.com/s-kostyaev/ellama"
  :commit "f0f4589c72fa2ff01e6bde3bf3c93408a3af9d3f"
  :revdesc "f0f4589c72fa"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
