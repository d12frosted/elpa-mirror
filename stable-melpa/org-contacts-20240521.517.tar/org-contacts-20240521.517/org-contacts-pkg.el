(define-package "org-contacts" "20240521.517" "Contacts management system for Org mode"
  '((emacs "27.1")
    (org "9.3.4"))
  :commit "9fdcb5e968ad8118de02618967370f1cd40b0e14" :authors
  '(("Julien Danjou" . "julien@danjou.info"))
  :maintainers
  '(("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  '("stardiviner" . "numbchild@gmail.com")
  :keywords
  '("contacts" "org-mode" "outlines" "hypermedia" "calendar")
  :url "https://repo.or.cz/org-contacts.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
