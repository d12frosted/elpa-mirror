;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ink-mode" "20260131.2326"
  "Major mode for writing interactive fiction in Ink."
  '((emacs "29.1"))
  :url "https://github.com/Kungsgeten/ink-mode"
  :commit "c33c1409b9a4dd8e86611912cab64ee4b01a70fb"
  :revdesc "c33c1409b9a4"
  :keywords '("languages" "wp" "hypermedia"))
