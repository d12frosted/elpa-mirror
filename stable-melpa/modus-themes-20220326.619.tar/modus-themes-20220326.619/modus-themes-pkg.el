(define-package "modus-themes" "20220326.619" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "283819834b1e710b02bd1c2feec1f4d0f00629de" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
