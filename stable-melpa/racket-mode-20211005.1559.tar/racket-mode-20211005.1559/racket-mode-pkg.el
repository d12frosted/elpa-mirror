(define-package "racket-mode" "20211005.1559" "Racket editing, REPL, and more"
  '((emacs "25.1"))
  :commit "46df4d9ecbaa7da1f48e55e5769d05e4ffdbd8b1" :authors
  '(("Greg Hendershott"))
  :maintainer
  '("Greg Hendershott")
  :url "https://www.racket-mode.com/")
;; Local Variables:
;; no-byte-compile: t
;; End:
