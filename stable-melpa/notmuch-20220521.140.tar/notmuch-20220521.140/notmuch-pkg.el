(define-package "notmuch" "20220521.140" "run notmuch within emacs" 'nil :commit "eab665c573155237001f42ca3bcefc0f7b9281a5" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
