;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fussy" "20260508.7"
  "Fuzzy completion style using `flx' and/or `fzf-native'."
  '((emacs  "29.1")
    (flx    "0.5")
    (compat "30.0.0.0"))
  :url "https://github.com/jojojames/fussy"
  :commit "358f7d0220f313c7d0fdc6033504edd7593f88ba"
  :revdesc "358f7d0220f3"
  :keywords '("matching")
  :authors '(("James Nguyen" . "james@jojojames.com"))
  :maintainers '(("James Nguyen" . "james@jojojames.com")))
