;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "epkg" "20260504.1719"
  "Browse the Emacsmirror package database."
  '((emacs   "28.1")
    (compat  "31.0")
    (closql  "2.4")
    (emacsql "4.3")
    (llama   "1.0"))
  :url "https://github.com/emacscollective/epkg"
  :commit "15e546f48fbbbcf64da56af9db38189f19b61034"
  :revdesc "15e546f48fbb"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.epkg@jonas.bernoulli.dev")))
