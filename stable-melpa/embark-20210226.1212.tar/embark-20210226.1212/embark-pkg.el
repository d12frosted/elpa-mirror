(define-package "embark" "20210226.1212" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "9a6bc65a30c379aaa8f6584509d37e0aeda6dada" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
