(define-package "fanyi" "20210910.724" "Not only English-Chinese translator"
  '((emacs "27.1")
    (s "1.12.0"))
  :commit "88b244e79062d9169051188d90ac68d6c758e9aa" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("convenience" "tools")
  :url "https://github.com/condy0919/fanyi.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
