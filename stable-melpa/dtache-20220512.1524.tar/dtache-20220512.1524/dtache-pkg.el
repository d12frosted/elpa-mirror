(define-package "dtache" "20220512.1524" "Run and interact with detached shell commands"
  '((emacs "27.1"))
  :commit "5a39733299cae60da2aab0e0b9f559bcc022369f" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://www.gitlab.com/niklaseklund/dtache.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
