(define-package "ox-linuxmag-fr" "20221030.716" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "32e0bd1f19b4e6b80b88272f7ec00dc34e52c544" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
