(define-package "cnfonts" "20211128.249" "A simple Chinese fonts config tool"
  '((emacs "24"))
  :commit "f52ed15c867266f37783240024c3cd3fdcd71c0f" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "font")
  :url "https://github.com/tumashu/cnfonts")
;; Local Variables:
;; no-byte-compile: t
;; End:
