;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260316.2135"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "15fdd57bf7999de871cb707a72fe5b1a37979602"
  :revdesc "15fdd57bf799"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
