;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ahg" "20241113.748"
  "Alberto's Emacs interface for Mercurial (Hg)."
  ()
  :url "https://bitbucket.org/agriggio/ahg"
  :commit "d57b91d52e5c2c501cb7112af53c6549397ea1b5"
  :revdesc "d57b91d52e5c"
  :authors '(("Alberto Griggio" . "agriggio@users.sourceforge.net"))
  :maintainers '(("Alberto Griggio" . "agriggio@users.sourceforge.net")))
