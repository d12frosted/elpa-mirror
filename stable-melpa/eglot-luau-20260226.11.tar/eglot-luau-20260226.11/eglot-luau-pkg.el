;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-luau" "20260226.11"
  "Luau language server integration for eglot."
  '((emacs "29.1")
    (eglot "1.17"))
  :url "https://github.com/kennethloeffler/eglot-luau"
  :commit "cf024fb654e0a38d1de2e3fbd1d7a9cde9936f1e"
  :revdesc "cf024fb654e0"
  :keywords '("roblox" "luau" "tools")
  :authors '(("Kenneth Loeffler" . "kenloef@gmail.com"))
  :maintainers '(("Kenneth Loeffler" . "kenloef@gmail.com")))
