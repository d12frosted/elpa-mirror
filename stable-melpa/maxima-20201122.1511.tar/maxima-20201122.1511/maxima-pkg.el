(define-package "maxima" "20201122.1511" "Major mode for Maxima"
  '((emacs "25.1")
    (s "1.11.0")
    (test-simple "1.3.0"))
  :commit "0945290e048939b6fefb50c6dae51c5b6ddcb723" :keywords
  ("maxima" "tools" "math")
  :authors
  (("William F. Schelter")
   ("Jay Belanger")
   ("Fermin Munoz"))
  :maintainer
  ("Fermin Munoz" . "fmfs@posteo.net")
  :url "https://gitlab.com/sasanidas/maxima")
;; Local Variables:
;; no-byte-compile: t
;; End:
