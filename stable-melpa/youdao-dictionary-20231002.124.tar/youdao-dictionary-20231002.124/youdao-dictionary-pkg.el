(define-package "youdao-dictionary" "20231002.124" "Youdao Dictionary interface for Emacs"
  '((popup "0.5.0")
    (pos-tip "0.4.6")
    (chinese-word-at-point "0.2")
    (names "0.5")
    (emacs "24"))
  :commit "b4b15ae9516be476cba1beab1ee45974f076671c" :authors
  '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainers
  '(("Chunyang Xu" . "xuchunyang56@gmail.com"))
  :maintainer
  '("Chunyang Xu" . "xuchunyang56@gmail.com")
  :keywords
  '("convenience" "chinese" "dictionary")
  :url "https://github.com/xuchunyang/youdao-dictionary.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
