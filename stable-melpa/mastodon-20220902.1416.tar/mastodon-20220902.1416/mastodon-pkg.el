(define-package "mastodon" "20220902.1416" "Client for Mastodon"
  '((emacs "27.1")
    (request "0.3.0"))
  :commit "2504bdf1e623439a55f6f56f1f5d89b6d9acbf4b" :authors
  '(("Johnson Denen" . "johnson.denen@gmail.com"))
  :maintainer
  '("Marty Hiatt" . "martianhiatus@riseup.net")
  :url "https://codeberg.org/martianh/mastodon.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
