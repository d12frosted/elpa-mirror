(define-package "elisp-autofmt" "20221230.217" "Emacs lisp auto-format"
  '((emacs "28.1"))
  :commit "5cb91d3469f30b99e77bb01e0e6bdbce4cf2dac4" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-elisp-autofmt")
;; Local Variables:
;; no-byte-compile: t
;; End:
