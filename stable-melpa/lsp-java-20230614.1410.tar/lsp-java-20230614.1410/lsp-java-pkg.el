(define-package "lsp-java" "20230614.1410" "Java support for lsp-mode"
  '((emacs "25.1")
    (lsp-mode "6.0")
    (markdown-mode "2.3")
    (dash "2.18.0")
    (f "0.20.0")
    (ht "2.0")
    (request "0.3.0")
    (treemacs "2.5")
    (dap-mode "0.5"))
  :commit "e78199d13695cfa63db8b9711a8f3ce0fafe80fe" :keywords
  '("languague" "tools")
  :url "https://github.com/emacs-lsp/lsp-java")
;; Local Variables:
;; no-byte-compile: t
;; End:
