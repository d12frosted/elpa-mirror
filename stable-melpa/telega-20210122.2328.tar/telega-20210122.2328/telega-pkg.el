(define-package "telega" "20210122.2328" "Telegram client (unofficial)"
  '((emacs "26.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "88cede54b9565092cf86254c2fa486f1d818c402" :authors
  '(("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  '("Zajcev Evgeny" . "zevlg@yandex.ru")
  :keywords
  '("comm")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
