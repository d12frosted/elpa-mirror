(define-package "xcode-project" "20200810.2010" "A package for reading Xcode project files."
  '((emacs "25"))
  :commit "90aef198df5b51dfdb9ad205aa5b412c471fd418" :authors
  '(("John Buckley" . "john@olivetoast.com"))
  :maintainer
  '("John Buckley" . "john@olivetoast.com")
  :keywords
  '("languages" "tools")
  :url "https://github.com/nhojb/xcode-project.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
