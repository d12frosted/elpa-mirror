;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flycheck-hledger" "20241029.1710"
  "Flycheck module to check hledger journals."
  '((emacs    "27.1")
    (flycheck "31"))
  :url "https://github.com/DamienCassou/flycheck-hledger/"
  :commit "66e12fce7d4875327bce06b2fc33043924c710ed"
  :revdesc "66e12fce7d48"
  :authors '(("Damien Cassou" . "damien@cassou.me"))
  :maintainers '(("Damien Cassou" . "damien@cassou.me")))
