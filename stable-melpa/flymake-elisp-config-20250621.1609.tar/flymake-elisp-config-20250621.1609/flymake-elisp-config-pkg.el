;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-elisp-config" "20250621.1609"
  "Setup load-path for flymake on Emacs Lisp mode."
  '((emacs "28.1"))
  :url "https://github.com/ROCKTAKEY/flymake-elisp-config"
  :commit "1f9100e855aff8877c1af111fcdde6968038b4d2"
  :revdesc "1f9100e855af"
  :keywords '("lisp")
  :authors '(("ROCKTAKEY" . "rocktakey@gmail.com"))
  :maintainers '(("ROCKTAKEY" . "rocktakey@gmail.com")))
