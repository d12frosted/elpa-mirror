(define-package "org-roam-bibtex" "20210602.2113" "Org Roam meets BibTeX"
  '((emacs "27.2")
    (org-roam "1.2.2")
    (bibtex-completion "2.0.0")
    (org-ref "1.1.1"))
  :commit "c9865196efe7cfdfcced0d47ea3e5b39bdddd162" :authors
  '(("Mykhailo Shevchuk" . "mail@mshevchuk.com")
    ("Leo Vivier" . "leo.vivier+dev@gmail.com"))
  :maintainer
  '("Mykhailo Shevchuk" . "mail@mshevchuk.com")
  :keywords
  '("bib" "hypermedia" "outlines" "wp")
  :url "https://github.com/org-roam/org-roam-bibtex")
;; Local Variables:
;; no-byte-compile: t
;; End:
