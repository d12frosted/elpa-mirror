(define-package "dap-mode" "20220218.2028" "Debug Adapter Protocol mode"
  '((emacs "26.1")
    (dash "2.18.0")
    (lsp-mode "6.0")
    (bui "1.1.0")
    (f "0.20.0")
    (s "1.12.0")
    (lsp-treemacs "0.1")
    (posframe "0.7.0")
    (ht "2.3"))
  :commit "ec0c707f0051a172eb87d6d04d40b8aaa69a575e" :authors
  '(("Ivan Yonchovski" . "yyoncho@gmail.com"))
  :maintainer
  '("Ivan Yonchovski" . "yyoncho@gmail.com")
  :keywords
  '("languages" "debug")
  :url "https://github.com/emacs-lsp/dap-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
