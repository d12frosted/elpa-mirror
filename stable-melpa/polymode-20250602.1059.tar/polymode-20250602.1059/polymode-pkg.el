;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "polymode" "20250602.1059"
  "Extensible framework for multiple major modes."
  '((emacs "25"))
  :url "https://github.com/polymode/polymode"
  :commit "b384eec4ce3fd989302b25c4b9c94cbebdc993b7"
  :revdesc "b384eec4ce3f"
  :keywords '("languages" "multi-modes" "processes")
  :maintainers '(("Vitalie Spinu" . "spinuvit@gmail.com")))
