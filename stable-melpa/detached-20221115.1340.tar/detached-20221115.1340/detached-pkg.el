(define-package "detached" "20221115.1340" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "52140bc17f0e0cc5edc4c05d096d847f9537b3d9" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
