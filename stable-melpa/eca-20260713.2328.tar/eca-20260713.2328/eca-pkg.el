;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260713.2328"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "f88b4b2a83be8c8024a9780d6b2290ef3ac0b22f"
  :revdesc "f88b4b2a83be"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
