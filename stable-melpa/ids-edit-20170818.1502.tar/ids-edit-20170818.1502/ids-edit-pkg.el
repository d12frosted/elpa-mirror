(define-package "ids-edit" "20170818.1502" "IDS (Ideographic Description Sequence) editing tool"
  '((emacs "24.3"))
  :commit "8562a6cbfb3f2d44bc6f62ab15081a80f8fee502" :authors
  '(("KAWABATA, Taichi <kawabata.taichi_at_gmail.com>"))
  :maintainer
  '("KAWABATA, Taichi <kawabata.taichi_at_gmail.com>")
  :keywords
  '("i18n" "wp")
  :url "http://github.com/kawabata/ids-edit")
;; Local Variables:
;; no-byte-compile: t
;; End:
