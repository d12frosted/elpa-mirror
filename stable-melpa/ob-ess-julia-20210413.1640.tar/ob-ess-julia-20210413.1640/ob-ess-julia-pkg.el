(define-package "ob-ess-julia" "20210413.1640" "Org babel support for Julia language"
  '((ess "20201004.1522")
    (julia-mode "0.4"))
  :commit "429097c51e3db7f9e4d59e5ec675a1871cb6f376" :authors
  '(("Frédéric Santos"))
  :maintainer
  '("Frédéric Santos")
  :keywords
  '("languages")
  :url "https://github.com/frederic-santos/ob-ess-julia")
;; Local Variables:
;; no-byte-compile: t
;; End:
