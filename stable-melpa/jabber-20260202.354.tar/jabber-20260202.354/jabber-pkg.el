;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jabber" "20260202.354"
  "A minimal Jabber client."
  '((emacs "27.1")
    (fsm   "0.2.0")
    (srv   "0.2"))
  :url "https://codeberg.org/emacs-jabber/emacs-jabber"
  :commit "a4a7a27f484363bb024d62f3f942fddcff0b095c"
  :revdesc "a4a7a27f4843"
  :keywords '("comm")
  :authors '(("Magnus Henoch" . "mange@freemail.hu"))
  :maintainers '(("wgreenhouse" . "wgreenhouse@tilde.club")))
