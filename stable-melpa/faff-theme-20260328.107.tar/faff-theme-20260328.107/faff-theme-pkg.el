;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "faff-theme" "20260328.107"
  "Light Emacs color theme on cornsilk3 background."
  ()
  :url "https://github.com/WJCFerguson/emacs-faff-theme"
  :commit "a9f3c21092ee6455b03adbbe64ee696268c293f6"
  :revdesc "a9f3c21092ee"
  :keywords '("color" "theme")
  :authors '(("James Ferguson" . ""))
  :maintainers '(("James Ferguson" . "")))
