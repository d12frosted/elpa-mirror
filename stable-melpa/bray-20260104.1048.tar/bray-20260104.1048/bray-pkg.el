;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bray" "20260104.1048"
  "Lightweight modal editing."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-bray"
  :commit "ff193c20d8dca061cf683eb3074579b9e0724807"
  :revdesc "ff193c20d8dc"
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
