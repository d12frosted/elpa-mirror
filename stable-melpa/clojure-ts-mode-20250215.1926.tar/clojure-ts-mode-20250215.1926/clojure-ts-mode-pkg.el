;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20250215.1926"
  "Major mode for Clojure code."
  '((emacs "29.1"))
  :url "http://github.com/clojure-emacs/clojure-ts-mode"
  :commit "ee8baed6437452c76e9ce778038e2a28219c76e5"
  :revdesc "ee8baed64374"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :maintainers '(("Danny Freeman" . "danny@dfreeman.email")))
