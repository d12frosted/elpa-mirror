;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "noxml-fold" "20170823.1357"
  "Fold away XML things."
  ()
  :url "https://github.com/paddymcall/noxml-fold"
  :commit "46c7f6a008672213238a9f8d7a416ce80916aa62"
  :revdesc "46c7f6a00867"
  :keywords '("xml" "folding")
  :authors '(("Patrick McAllister" . "pma@rdorte.org"))
  :maintainers '(("Patrick McAllister" . "pma@rdorte.org")))
