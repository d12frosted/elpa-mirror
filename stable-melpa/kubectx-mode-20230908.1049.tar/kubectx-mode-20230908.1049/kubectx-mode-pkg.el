(define-package "kubectx-mode" "20230908.1049" "Change kubectl context/namespace and show in mode line"
  '((emacs "24"))
  :commit "342bba8b34d73f99adf143f1281a2767d698f0b0" :authors
  '(("Terje Sannum" . "terje@offpiste.org"))
  :maintainers
  '(("Terje Sannum" . "terje@offpiste.org"))
  :maintainer
  '("Terje Sannum" . "terje@offpiste.org")
  :keywords
  '("tools" "kubernetes")
  :url "https://github.com/terjesannum/emacs-kubectx-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
