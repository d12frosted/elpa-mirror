;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-flycheck" "20260101.1341"
  "Provides the command `consult-flycheck'."
  '((emacs    "29.1")
    (consult  "2.8")
    (flycheck "35"))
  :url "https://github.com/minad/consult-flycheck"
  :commit "3dc1fcc422e3f0ed4d55e5f9bd11d6c99d38e041"
  :revdesc "3dc1fcc422e3"
  :keywords '("languages" "tools" "completion")
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
