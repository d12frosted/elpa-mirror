(define-package "gptel" "20231113.211" "A simple multi-LLM client"
  '((emacs "27.1")
    (transient "0.4.0"))
  :commit "17a58d38e7299f254d02c29bbcc9211146394758" :authors
  '(("Karthik Chikmagalur"))
  :maintainers
  '(("Karthik Chikmagalur"))
  :maintainer
  '("Karthik Chikmagalur")
  :keywords
  '("convenience")
  :url "https://github.com/karthink/gptel")
;; Local Variables:
;; no-byte-compile: t
;; End:
