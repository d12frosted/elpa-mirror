;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "grpclient" "20260724.434"
  "Grpcurl interactive builder."
  '((emacs "29.1"))
  :url "https://github.com/Prikaz98/grpclient.el"
  :commit "f372e008afee46552f69022d87d976d3fbd8fd4a"
  :revdesc "f372e008afee"
  :keywords '("grpc" "grpcurl" "tools")
  :authors '(("Ivan Prikaznov" . "prikaznov555@gmail.com")
             ("Miloš Tepić" . "tepcmils@gmail.com"))
  :maintainers '(("Ivan Prikaznov" . "prikaznov555@gmail.com")
                 ("Miloš Tepić" . "tepcmils@gmail.com")))
