;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "kakapo-mode" "20171004.451"
  "TABS (hard or soft) for indentation (leading whitespace), and SPACES for alignment."
  '((cl-lib "0.5"))
  :url "https://github.com/listx/kakapo-mode"
  :commit "67d516138172fd60782df94454b3d0bd247e84f3"
  :revdesc "67d516138172"
  :keywords '("indentation"))
