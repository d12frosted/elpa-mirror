(define-package "whois" "20240226.1711" "Syntax highlighted domain name queries using system whois"
  '((emacs "24"))
  :commit "855f7d672bcb3dde61a9fd957a6de7145eca7a0f" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("network" "comm")
  :url "https://github.com/lassik/emacs-whois")
;; Local Variables:
;; no-byte-compile: t
;; End:
