;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clojure-ts-mode" "20261010.550"
  "Major mode for Clojure code."
  '((emacs "30.1"))
  :url "https://github.com/clojure-emacs/clojure-ts-mode"
  :commit "aaeb7a6eef242def4b1136f81b4cb992a1c0c24f"
  :revdesc "aaeb7a6eef24"
  :keywords '("languages" "clojure" "clojurescript" "lisp")
  :authors '(("Danny Freeman" . "danny@dfreeman.email")
             ("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
