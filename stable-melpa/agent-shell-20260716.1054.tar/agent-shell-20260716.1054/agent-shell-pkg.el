;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260716.1054"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.93.5")
    (acp         "0.12.2"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "44879403b42255bee61cba488c10e8042238fc18"
  :revdesc "44879403b422")
