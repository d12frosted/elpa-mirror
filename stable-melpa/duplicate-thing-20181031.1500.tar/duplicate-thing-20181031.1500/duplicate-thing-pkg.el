;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "duplicate-thing" "20181031.1500"
  "Duplicate current line & selection."
  ()
  :url "https://github.com/ongaeshi/duplicate-thing"
  :commit "9d8fd05e3e5caa35d3f2a0c0032c92f0c0908e21"
  :revdesc "9d8fd05e3e5c"
  :keywords '("convenience" "command" "duplicate" "line" "selection"))
