(define-package "weblorg" "20210906.1254" "Static Site Generator for org-mode"
  '((templatel "0.1.6")
    (emacs "26.1"))
  :commit "e49a901223b9f5db390adf01e3928f134aa66f25" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
