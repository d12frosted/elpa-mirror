;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thrift" "20260413.1435"
  "Major mode for fbthrift and Apache Thrift files."
  '((emacs "24"))
  :url "https://github.com/facebook/fbthrift"
  :commit "51f81f060bf315d86b3519302cdfb5c806f2d28d"
  :revdesc "51f81f060bf3"
  :keywords '("languages"))
