(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "cdbfabe733c78acaa4088e9ba871ae74d7a2b690" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
