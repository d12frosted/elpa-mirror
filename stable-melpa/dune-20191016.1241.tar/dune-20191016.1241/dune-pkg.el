(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "3eefbed4aac1d5866c22d893e8af9edd6d1ca388" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
