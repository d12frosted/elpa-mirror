(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "78707ffa288bc45dc61de05af481e7ec935f586b" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
