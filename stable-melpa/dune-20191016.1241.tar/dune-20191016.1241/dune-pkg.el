(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "2c0b6c1ef14606dbafd38aca4444c88bc76a08d0" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
