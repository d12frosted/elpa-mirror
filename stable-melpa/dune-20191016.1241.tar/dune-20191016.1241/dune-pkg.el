(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "1710cbeb9fd33c4b45a83b5d1c4a4cd991f111ca" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
