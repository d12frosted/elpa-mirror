(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "a1fbb8d40ee8073d3ac466c52dc7c6609f48d010" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
