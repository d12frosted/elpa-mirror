(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "e5424037cb8d5e32ac02a7979e8d8e99bedd6016" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
