(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "78dc0f870092c46e32a5b935d31edf86293acde5" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
