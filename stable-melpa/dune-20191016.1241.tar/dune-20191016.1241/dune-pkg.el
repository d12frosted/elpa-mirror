(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "f918dfbf6d7d9881e6df028936ea4fe408614714" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
