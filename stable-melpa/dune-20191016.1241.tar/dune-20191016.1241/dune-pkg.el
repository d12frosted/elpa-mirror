(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "bbbbc67925e3aa8b9dcd05515c6eff34eac164bc" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
