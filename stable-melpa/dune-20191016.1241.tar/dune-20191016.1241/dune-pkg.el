(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "29b6b9f9e6ed9a7be596ba2ef565412a064cc8e2" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
