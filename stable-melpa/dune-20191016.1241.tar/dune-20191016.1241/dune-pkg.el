(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "517356667cdc74dcdeda4db28215aded7584d402" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
