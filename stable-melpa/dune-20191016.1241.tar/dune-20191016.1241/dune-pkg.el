(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "f82f9f172258c39f6fbf8a691f64a03e2f969319" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
