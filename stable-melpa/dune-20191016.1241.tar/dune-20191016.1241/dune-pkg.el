(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "caef668f680501426a0f7741caab983e45699078" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
