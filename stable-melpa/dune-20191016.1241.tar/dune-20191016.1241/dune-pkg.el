(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "31285ad2b6ed6f91087124ff034d68a2363c03cd" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
