(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "133a6fedc217d9b66329cc8fce45ab0edddef538" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
