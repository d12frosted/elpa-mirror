(define-package "dune" "20191016.1241" "Integration with the dune build system" 'nil :commit "83d08b6146d2673c151ba5ded3e8460e15eeb265" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
