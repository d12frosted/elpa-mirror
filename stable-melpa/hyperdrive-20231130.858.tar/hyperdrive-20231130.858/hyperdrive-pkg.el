(define-package "hyperdrive" "20231130.858" "P2P filesystem"
  '((emacs "28.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5")
    (taxy-magit-section "0.12.1")
    (transient "0.5.0"))
  :commit "36fe1c951921eaded9353c75c6585fc1225e87b0" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
