(define-package "google-maps" "20130412.930" "Access Google Maps from Emacs" 'nil :commit "90151ab59e693243ca8da660ce7b9ce361ea5126" :authors
  '(("Julien Danjou" . "julien@danjou.info"))
  :maintainer
  '("Julien Danjou" . "julien@danjou.info")
  :keywords
  '("comm"))
;; Local Variables:
;; no-byte-compile: t
;; End:
