(define-package "julia-snail" "20220506.519" "Julia Snail"
  '((emacs "26.2")
    (dash "2.16.0")
    (julia-mode "0.3")
    (s "1.12.0")
    (spinner "1.7.3")
    (vterm "0.0.1")
    (popup "0.5.9"))
  :commit "603c752d67e02ce078084d8ad98031530b952cc1" :url "https://github.com/gcv/julia-snail")
;; Local Variables:
;; no-byte-compile: t
;; End:
