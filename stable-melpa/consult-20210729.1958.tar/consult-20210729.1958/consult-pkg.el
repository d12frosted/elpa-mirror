(define-package "consult" "20210729.1958" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "5564008dfc3d4b7a7ba2454e70c570a569290f0c" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
