;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "casual" "20260320.2158"
  "Transient user interfaces for various modes."
  '((emacs     "29.1")
    (transient "0.9.0")
    (csv-mode  "1.27"))
  :url "https://github.com/kickingvegas/casual"
  :commit "c8d6ec4165220d2de9fca742f3be254deec312c1"
  :revdesc "c8d6ec416522"
  :keywords '("tools" "wp")
  :authors '(("Charles Choi" . "kickingvegas@gmail.com"))
  :maintainers '(("Charles Choi" . "kickingvegas@gmail.com")))
