;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20260211.117"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.7.1")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "3f9c030396844c976bd5d80f08d0a3aa42962486"
  :revdesc "3f9c03039684"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
