(define-package "mini-echo" "20231030.955" "Echo buffer status in minibuffer window"
  '((emacs "28.1"))
  :commit "1a4622322bf3832bdb721d2c707dff1ff1906712" :authors
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainers
  '(("liuyinz" . "liuyinz95@gmail.com"))
  :maintainer
  '("liuyinz" . "liuyinz95@gmail.com")
  :keywords
  '("frames")
  :url "https://github.com/liuyinz/mini-echo.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
