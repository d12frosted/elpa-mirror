;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "emc" "20250921.1247"
  "Invoking a C/C++ (et al.) build toolchain from ELisp."
  '((delight "1.7")
    (emacs   "29.1"))
  :url "https://github.com/marcoxa/emc"
  :commit "1b9d657c7f46e0f289bba0e1696a1d012a8f1368"
  :revdesc "1b9d657c7f46"
  :keywords '("extensions" "c" "lisp" "building tools" "development" "deployment.")
  :authors '(("Marco Antoniotti" . "marcoxa[at]gmail.com"))
  :maintainers '(("Marco Antoniotti" . "marcoxa[at]gmail.com")))
