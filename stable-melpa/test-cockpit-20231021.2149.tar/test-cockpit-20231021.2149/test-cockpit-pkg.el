(define-package "test-cockpit" "20231021.2149" "A command center to run tests of a software project"
  '((emacs "28.1")
    (projectile "2.7")
    (toml "20230411.1449"))
  :commit "98a15ab65d45e2053c587b2f2fde37d16fd45a21" :authors
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainers
  '(("Johannes Mueller" . "github@johannes-mueller.org"))
  :maintainer
  '("Johannes Mueller" . "github@johannes-mueller.org")
  :url "https://github.com/johannes-mueller/test-cockpit.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
