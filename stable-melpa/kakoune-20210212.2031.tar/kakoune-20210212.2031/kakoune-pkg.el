(define-package "kakoune" "20210212.2031" "A simulation, but not emulation, of kakoune"
  '((ryo-modal "0.45")
    (multiple-cursors "1.4")
    (expand-region "0.11.0")
    (emacs "25.1"))
  :commit "34af1bc1225b044d9a15d8c276b7e33b12cb8720" :authors
  '(("Joseph Morag" . "jm4157@columbia.edu"))
  :maintainer
  '("Joseph Morag" . "jm4157@columbia.edu")
  :url "https://github.com/jmorag/kakoune.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
