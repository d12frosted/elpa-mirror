(define-package "selectrum" "20210108.1356" "Easily select item from list"
  '((emacs "25.1"))
  :commit "783c4517e4ca347efa7571b137b4ed29429a026c" :authors
  '(("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  '("Radon Rosborough" . "radon.neon@gmail.com")
  :keywords
  '("extensions")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
