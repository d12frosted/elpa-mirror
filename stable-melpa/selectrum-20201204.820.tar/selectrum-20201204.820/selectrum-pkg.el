(define-package "selectrum" "20201204.820" "Easily select item from list"
  '((emacs "25.1"))
  :commit "5c8d2ad458781a018d430b477f15b0a649d818aa" :keywords
  ("extensions")
  :authors
  (("Radon Rosborough" . "radon.neon@gmail.com"))
  :maintainer
  ("Radon Rosborough" . "radon.neon@gmail.com")
  :url "https://github.com/raxod502/selectrum")
;; Local Variables:
;; no-byte-compile: t
;; End:
