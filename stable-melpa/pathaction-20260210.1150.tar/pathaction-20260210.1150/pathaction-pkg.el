;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pathaction" "20260210.1150"
  "Execute the pathaction.yaml rules from your editor."
  '((emacs "24.4"))
  :url "https://github.com/jamescherti/pathaction.el"
  :commit "4fa63b7868e068bb1b06209af18722cb1c8983ab"
  :revdesc "4fa63b7868e0"
  :keywords '("convenience"))
