;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "occult" "20260405.1822"
  "Collapse and reveal buffer regions."
  '((emacs "29.1"))
  :url "https://github.com/agzam/occult.el"
  :commit "599d4db83c892753664be3c4024b7a616e45f40b"
  :revdesc "599d4db83c89"
  :keywords '("convenience")
  :authors '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com"))
  :maintainers '(("Ag Ibragimov" . "agzam.ibragimov@gmail.com")))
