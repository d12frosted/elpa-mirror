(define-package "consult" "20220711.1452" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "1680f26f1c692743d3c9a38cfd33fcd5d943550f" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
