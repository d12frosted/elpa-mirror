(define-package "haskell-emacs-base" "20150714.1559" "Haskell functions from Prelude"
  '((haskell-emacs "2.4.0"))
  :commit "7f91f65254902b8ff04fdb679bc569b2f6a51637" :authors
  '(("Florian Knupfer"))
  :maintainer
  '("Florian Knupfer")
  :keywords
  '("haskell" "emacs" "ffi")
  :url "https://github.com/knupfer/haskell-emacs/modules/base")
;; Local Variables:
;; no-byte-compile: t
;; End:
