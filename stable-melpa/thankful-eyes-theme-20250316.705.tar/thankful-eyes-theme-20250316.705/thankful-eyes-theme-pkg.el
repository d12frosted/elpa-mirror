;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "thankful-eyes-theme" "20250316.705"
  "Theme for color blindness and visual impairments."
  '((emacs "24.1"))
  :url "https://github.com/tanrax/thankful-eyes-theme.el"
  :commit "246eb8b0aa76dcb752e70c3c006432ce7bd9288b"
  :revdesc "246eb8b0aa76"
  :keywords '("faces")
  :authors '(("Andros Fenollosa" . "hi@andros.dev"))
  :maintainers '(("Andros Fenollosa" . "hi@andros.dev")))
