(define-package "hyperdrive" "20231208.2258" "P2P filesystem"
  '((emacs "28.1")
    (map "3.0")
    (compat "29.1.4.0")
    (plz "0.7")
    (persist "0.5")
    (taxy-magit-section "0.12.1")
    (transient "0.5.2"))
  :commit "b096ed34ede79cab82252bf63448c579c26a8129" :authors
  '(("Joseph Turner" . "joseph@ushin.org"))
  :maintainers
  '(("Joseph Turner" . "~ushin/ushin@lists.sr.ht"))
  :maintainer
  '("Joseph Turner" . "~ushin/ushin@lists.sr.ht")
  :url "https://git.sr.ht/~ushin/hyperdrive.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
