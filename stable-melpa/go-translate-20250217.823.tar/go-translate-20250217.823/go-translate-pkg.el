;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250217.823"
  "Translation framework, configurable and scalable."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/go-translate"
  :commit "3340ce542fbe612a5e04eb8b33d8994d94060c7b"
  :revdesc "3340ce542fbe"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
