(define-package "moom" "20220724.808" "Commands to control frame position and size"
  '((emacs "25.1"))
  :commit "808952a934d0459829422b3417ca23926c1ceabf" :authors
  '(("Takaaki ISHIKAWA <takaxp at ieee dot org>"))
  :maintainer
  '("Takaaki ISHIKAWA <takaxp at ieee dot org>")
  :keywords
  '("frames" "faces" "convenience")
  :url "https://github.com/takaxp/Moom")
;; Local Variables:
;; no-byte-compile: t
;; End:
