;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "indent-info" "20210111.745"
  "Show indentation information in status bar."
  '((emacs "24.3"))
  :url "https://github.com/terlar/indent-info.el"
  :commit "05a787afeb9946714d8b0c724868195a678db49e"
  :revdesc "05a787afeb99"
  :keywords '("convenience" "tools")
  :authors '(("Terje Larsen" . "terlar@gmail.com"))
  :maintainers '(("Terje Larsen" . "terlar@gmail.com")))
