(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "88adcb8071d30e5f211748ce1d011989e501cccb")
;; Local Variables:
;; no-byte-compile: t
;; End:
