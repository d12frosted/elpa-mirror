(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "89a14a76a31bcaaac657e6d8d9b92c8ed7402967")
;; Local Variables:
;; no-byte-compile: t
;; End:
