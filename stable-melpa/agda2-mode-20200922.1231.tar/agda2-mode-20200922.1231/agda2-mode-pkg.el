(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "be0040f10498aab7f71fe7ecafbc272bc0024c7f")
;; Local Variables:
;; no-byte-compile: t
;; End:
