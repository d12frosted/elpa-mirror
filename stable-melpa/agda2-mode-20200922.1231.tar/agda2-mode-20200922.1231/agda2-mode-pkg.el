(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "834b75908632e1633c0fe9b0ab1cd39195b51aa3")
;; Local Variables:
;; no-byte-compile: t
;; End:
