(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "4717912820a72a63b1b3af532c9f1571c5afebf8")
;; Local Variables:
;; no-byte-compile: t
;; End:
