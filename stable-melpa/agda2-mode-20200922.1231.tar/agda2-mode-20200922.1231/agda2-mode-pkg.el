(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "a2553b73c88a81c41f63694df2bf1ac28bdfb23c")
;; Local Variables:
;; no-byte-compile: t
;; End:
