(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "332d6a1b0dbea20d089b06a95e30556869a92bff")
;; Local Variables:
;; no-byte-compile: t
;; End:
