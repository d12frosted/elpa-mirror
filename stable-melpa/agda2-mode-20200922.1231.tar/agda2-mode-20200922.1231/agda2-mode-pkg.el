(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "e564b701e81037875907b172ff4db19fec2f658a")
;; Local Variables:
;; no-byte-compile: t
;; End:
