(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "e5b80904c43079462c1271566d850a949e13498b")
;; Local Variables:
;; no-byte-compile: t
;; End:
