(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "d20295b678fe0600630cd50ac5b51ab567e5462d")
;; Local Variables:
;; no-byte-compile: t
;; End:
