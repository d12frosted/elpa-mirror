(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "5d4e9cf46a96889f14cd095c1f5757b59bc2c46e")
;; Local Variables:
;; no-byte-compile: t
;; End:
