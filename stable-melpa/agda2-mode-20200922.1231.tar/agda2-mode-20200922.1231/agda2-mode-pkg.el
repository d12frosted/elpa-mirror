(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "f3370a42f36f880da78acffeb0dd8cc55c1c7f9f")
;; Local Variables:
;; no-byte-compile: t
;; End:
