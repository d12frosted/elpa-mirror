(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "3e18dd39c83f1b4d4b36c00e2e7a35f6c7bfa0dc")
;; Local Variables:
;; no-byte-compile: t
;; End:
