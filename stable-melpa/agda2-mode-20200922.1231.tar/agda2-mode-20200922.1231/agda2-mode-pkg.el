(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "f27893d8f068bd8bb79a9947511e6b761e568d4b")
;; Local Variables:
;; no-byte-compile: t
;; End:
