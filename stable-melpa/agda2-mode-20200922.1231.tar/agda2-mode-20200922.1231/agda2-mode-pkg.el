(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "88222ed563e399dafffcd552b38c1adaaa3888ae")
;; Local Variables:
;; no-byte-compile: t
;; End:
