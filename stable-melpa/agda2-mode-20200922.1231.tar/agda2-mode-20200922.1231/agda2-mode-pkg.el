(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "6b8f697433448050da81de7f5f262a79e602a03d")
;; Local Variables:
;; no-byte-compile: t
;; End:
