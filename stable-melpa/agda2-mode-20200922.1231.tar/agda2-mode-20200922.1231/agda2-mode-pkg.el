(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "55ab6e656ea794c718c4af2eec6825696c4b12fc")
;; Local Variables:
;; no-byte-compile: t
;; End:
