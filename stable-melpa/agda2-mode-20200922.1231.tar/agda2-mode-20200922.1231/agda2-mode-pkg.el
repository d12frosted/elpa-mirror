(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "68ec2312961776e415c99d2839e41a92ffe464db")
;; Local Variables:
;; no-byte-compile: t
;; End:
