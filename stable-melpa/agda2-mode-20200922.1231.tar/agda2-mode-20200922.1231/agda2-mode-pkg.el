(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "4a570ebed31e95082f0d68fdce542d2110495bd7")
;; Local Variables:
;; no-byte-compile: t
;; End:
