(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "d1f688c584acd945a9f2fa398f3b06f67370abda")
;; Local Variables:
;; no-byte-compile: t
;; End:
