(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "c45dc6b2729a53653df2874b6ea8b3500793da78")
;; Local Variables:
;; no-byte-compile: t
;; End:
