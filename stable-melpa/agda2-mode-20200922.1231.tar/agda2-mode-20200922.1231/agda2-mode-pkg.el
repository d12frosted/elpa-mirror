(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "b0cf67f0b1308b60f02c5a2eae6ad647eadc60c3")
;; Local Variables:
;; no-byte-compile: t
;; End:
