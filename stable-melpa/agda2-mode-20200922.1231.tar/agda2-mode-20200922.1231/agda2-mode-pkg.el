(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "a4c07e640eade54f7f18710556568d87b4452c2d")
;; Local Variables:
;; no-byte-compile: t
;; End:
