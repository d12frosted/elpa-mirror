(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "0d6ff44f9cb5c5caea5fe05da4fd6ded7cc0b513")
;; Local Variables:
;; no-byte-compile: t
;; End:
