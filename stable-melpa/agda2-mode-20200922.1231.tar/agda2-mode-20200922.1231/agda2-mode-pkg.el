(define-package "agda2-mode" "20200922.1231" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "63e351bc746e637af3792637159a28b57791debe")
;; Local Variables:
;; no-byte-compile: t
;; End:
