;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20250608.1803"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "dd80517f418a166e40b2b306d54f46f95641cce0"
  :revdesc "dd80517f418a"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
