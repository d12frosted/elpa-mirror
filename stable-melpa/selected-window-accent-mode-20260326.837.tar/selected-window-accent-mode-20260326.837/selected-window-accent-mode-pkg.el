;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "selected-window-accent-mode" "20260326.837"
  "Accent Selected Window."
  '((emacs "29.1"))
  :url "https://github.com/captainflasmr/selected-window-accent-mode"
  :commit "1ab6e720ee2c34035b5d0ab855c32d471f7ca849"
  :revdesc "1ab6e720ee2c"
  :keywords '("convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
