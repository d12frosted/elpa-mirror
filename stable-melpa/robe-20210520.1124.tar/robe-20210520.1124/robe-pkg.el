(define-package "robe" "20210520.1124" "Code navigation, documentation lookup and completion for Ruby"
  '((inf-ruby "2.5.1")
    (emacs "24.4"))
  :commit "c9cb1abcc4caca7aa89aa61e648d323117d49d88" :authors
  '(("Dmitry Gutov"))
  :maintainer
  '("Dmitry Gutov")
  :keywords
  '("ruby" "convenience" "rails")
  :url "https://github.com/dgutov/robe")
;; Local Variables:
;; no-byte-compile: t
;; End:
