;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultra-scroll" "20260501.1434"
  "Fast and smooth scrolling."
  '((emacs "29.1"))
  :url "https://github.com/jdtsmith/ultra-scroll"
  :commit "c6decf7754edda0aa7c5a775b7d6147490a8f464"
  :revdesc "c6decf7754ed"
  :keywords '("convenience"))
