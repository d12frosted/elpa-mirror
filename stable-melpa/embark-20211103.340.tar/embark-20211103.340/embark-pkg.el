(define-package "embark" "20211103.340" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "d09fff2da7506cfd9171d37e92b437c46d142d50" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
