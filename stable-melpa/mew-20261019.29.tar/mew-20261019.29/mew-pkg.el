;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261019.29"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "d6ea75942ef989d0399b59da6e9b94dd63697135"
  :revdesc "d6ea75942ef9")
