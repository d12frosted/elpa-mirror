;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "jira" "20260210.1939"
  "Emacs Interface to Jira."
  '((emacs         "29.1")
    (request       "0.3.0")
    (tablist       "1.0")
    (transient     "0.8.3")
    (magit-section "4.2.0"))
  :url "https://github.com/unmonoqueteclea/jira.el"
  :commit "0dab542ec0ccd56438aab8dc8c9ce0b2775a48e7"
  :revdesc "0dab542ec0cc"
  :authors '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com"))
  :maintainers '(("Pablo González Carrizo" . "unmonoqueteclea@gmail.com")))
