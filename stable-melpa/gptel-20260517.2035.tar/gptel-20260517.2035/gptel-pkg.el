;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20260517.2035"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.8")
    (compat    "30.1.0.0"))
  :url "https://github.com/karthink/gptel"
  :commit "b0c319347f843f5e04e4db6ec83640d3c94955b0"
  :revdesc "b0c319347f84"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
