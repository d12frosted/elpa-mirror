;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evil-dvorak" "20160416.1841"
  "Evil keybindings for that work with dvorak mode."
  '((evil "1.0.8"))
  :url "https://github.com/jbranso/evil-dvorak"
  :commit "e7b80077d6f332452049eb3d7ea51f6c8fbf5947"
  :revdesc "e7b80077d6f3"
  :keywords '("dvorak" "evil" "vim"))
