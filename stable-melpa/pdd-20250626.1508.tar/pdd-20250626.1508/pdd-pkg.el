;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250626.1508"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "1c860f59212c2a3a4df4eb4e33a5c6d6927fb07b"
  :revdesc "1c860f59212c"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
