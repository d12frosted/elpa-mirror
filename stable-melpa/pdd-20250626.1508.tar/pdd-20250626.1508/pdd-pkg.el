;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250626.1508"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "5fd711976c53a56a1bf7db6f96670e73333e19bd"
  :revdesc "5fd711976c53"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
