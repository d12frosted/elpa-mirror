;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250626.1508"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "455def1b8ea54a1a3386505e562d9c829afd29f0"
  :revdesc "455def1b8ea5"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
