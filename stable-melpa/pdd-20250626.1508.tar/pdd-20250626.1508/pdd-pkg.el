;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pdd" "20250626.1508"
  "HTTP library & Async Toolkit."
  '((emacs "28.1"))
  :url "https://github.com/lorniu/pdd.el"
  :commit "8878457684f306a569072327c239e76512001e3b"
  :revdesc "8878457684f3"
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
