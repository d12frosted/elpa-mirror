;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260730.1216"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "a2d821a0765d5f076ed777d22cecd914ad9106d8"
  :revdesc "a2d821a0765d"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
