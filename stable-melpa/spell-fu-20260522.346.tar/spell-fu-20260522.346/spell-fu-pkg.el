;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spell-fu" "20260522.346"
  "Fast & light spelling highlighter."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-spell-fu"
  :commit "2aad2f633d89e5f617ba6bb563837c342f363310"
  :revdesc "2aad2f633d89"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
