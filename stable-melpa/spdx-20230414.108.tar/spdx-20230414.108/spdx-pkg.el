(define-package "spdx" "20230414.108" "Insert SPDX license and copyright headers"
  '((emacs "24.4"))
  :commit "cbf947171bf2a67cd06f8a49003ff9b7fd6607ab" :authors
  '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainer
  '("Zhiwei Chen" . "condy0919@gmail.com")
  :keywords
  '("license" "tools")
  :url "https://github.com/condy0919/spdx.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
