;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ietf-docs" "20190420.851"
  "Fetch, Cache and Load IETF documents."
  ()
  :url "https://github.com/choppsv1/ietf-docs"
  :commit "ae157549eae5ec78dcbf215c2f48cb662b73abd0"
  :revdesc "ae157549eae5"
  :keywords '("ietf" "rfc")
  :authors '(("Christian E. Hopps" . "chopps@gmail.com"))
  :maintainers '(("Christian E. Hopps" . "chopps@gmail.com")))
