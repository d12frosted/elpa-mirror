(define-package "chatgpt-shell" "20231103.1529" "ChatGPT shell + buffer insert commands"
  '((emacs "27.1")
    (shell-maker "0.42.1"))
  :commit "096b603e9360b7a5ac3ebdeff084906e98790809" :authors
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainers
  '(("Alvaro Ramirez https://xenodium.com"))
  :maintainer
  '("Alvaro Ramirez https://xenodium.com")
  :url "https://github.com/xenodium/chatgpt-shell")
;; Local Variables:
;; no-byte-compile: t
;; End:
