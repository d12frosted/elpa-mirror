(define-package "detached" "20220920.1327" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "81ed6fc4b41000c2728ddccd351455979d6ec818" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("detached.el Development" . "~niklaseklund/detached.el@lists.sr.ht")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
