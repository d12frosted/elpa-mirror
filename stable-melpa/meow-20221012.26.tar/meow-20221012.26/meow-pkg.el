(define-package "meow" "20221012.26" "Yet Another modal editing"
  '((emacs "27.1"))
  :commit "d180d47c56ec06d054fb101bc843340d93c26d41" :authors
  '(("Shi Tianshu"))
  :maintainer
  '("Shi Tianshu")
  :keywords
  '("convenience" "modal-editing")
  :url "https://www.github.com/DogLooksGood/meow")
;; Local Variables:
;; no-byte-compile: t
;; End:
