;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "evedel" "20250222.1654"
  "Instructed LLM programmer/assistant."
  '((emacs "29.1")
    (gptel "0.9.0"))
  :url "https://github.com/daedsidog/evedel"
  :commit "35370626b8429f06c31095e4787bafc9e5da7e42"
  :revdesc "35370626b842"
  :keywords '("convenience" "tools")
  :authors '(("daedsidog" . "contact@daedsidog.com"))
  :maintainers '(("daedsidog" . "contact@daedsidog.com")))
