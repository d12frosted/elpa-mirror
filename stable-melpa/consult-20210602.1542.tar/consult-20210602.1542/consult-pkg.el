(define-package "consult" "20210602.1542" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "d211022b071ee8f96153cdcc86eda6ce82be07cf" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
