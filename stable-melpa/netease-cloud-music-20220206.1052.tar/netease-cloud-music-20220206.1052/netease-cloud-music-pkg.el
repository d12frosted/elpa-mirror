(define-package "netease-cloud-music" "20220206.1052" "Netease Cloud Music client"
  '((emacs "27.1")
    (request "0.3.3"))
  :commit "c94ab2fc0beb80f4cb378dceba566b9314095152" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("multimedia")
  :url "https://github.com/SpringHan/netease-cloud-music.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
