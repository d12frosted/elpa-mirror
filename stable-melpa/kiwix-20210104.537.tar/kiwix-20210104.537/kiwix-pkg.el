(define-package "kiwix" "20210104.537" "Searching offline Wikipedia through Kiwix."
  '((emacs "24.4")
    (request "0.3.0"))
  :commit "4f987d49ec6e7c6191275514d5165ef013b1a0fc" :authors
  (("stardiviner" . "numbchild@gmail.com"))
  :maintainer
  ("stardiviner" . "numbchild@gmail.com")
  :keywords
  ("kiwix" "wikipedia")
  :url "https://github.com/stardiviner/kiwix.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
