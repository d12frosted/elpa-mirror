;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "claudia" "20250824.1704"
  "Claude AI integration."
  '((emacs         "29.1")
    (uuidgen       "0.3")
    (markdown-mode "2.3"))
  :url "https://github.com/mzacho/claudia"
  :commit "f5a3398d588a83372169a277d3dd3ed467ff799b"
  :revdesc "f5a3398d588a"
  :keywords '("ai" "tools" "productivity" "codegen")
  :authors '(("Martin Zacho" . "hi@martinzacho.net"))
  :maintainers '(("Martin Zacho" . "hi@martinzacho.net")))
