(define-package "zenscript-mode" "20201109.1110" "Major mode for ZenScript"
  '((emacs "25.1"))
  :commit "1d262868c30d978bfb62fd4ddd306f988651df05" :url "https://github.com/eutropius225/zenscript-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
