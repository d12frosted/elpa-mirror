;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ultisnips-mode" "20260124.2258"
  "Major mode for editing Ultisnips snippets."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/ultisnips-mode.el"
  :commit "035cacccebe1629eca5ce24fd6f597a4e5453d23"
  :revdesc "035cacccebe1"
  :keywords '("languages"))
