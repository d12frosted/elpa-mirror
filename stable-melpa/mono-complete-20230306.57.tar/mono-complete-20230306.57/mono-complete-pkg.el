(define-package "mono-complete" "20230306.57" "Completion suggestions with multiple back-ends"
  '((emacs "28.1"))
  :commit "eda613656bdf64760a593c73d36c706f6bfa7939" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mono-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
