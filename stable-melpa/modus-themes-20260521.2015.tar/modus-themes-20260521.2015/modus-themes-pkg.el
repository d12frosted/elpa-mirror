;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260521.2015"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "87d5764eccca2f130afe3dd00143ed8d93a802a6"
  :revdesc "87d5764eccca"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos" . "info@protesilaos.com")))
