;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260811.1508"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.1")
    (acp         "0.13.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b6eb936a10be8ed3340f62e23be983dc5de2289f"
  :revdesc "b6eb936a10be")
