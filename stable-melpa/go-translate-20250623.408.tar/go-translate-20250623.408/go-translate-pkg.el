;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-translate" "20250623.408"
  "Translation framework, configurable and scalable."
  '((emacs "28.1")
    (pdd   "0.21"))
  :url "https://github.com/lorniu/go-translate"
  :commit "ae10ad855a9e59c92b3ceecba6e9957a69bfb1c4"
  :revdesc "ae10ad855a9e"
  :keywords '("convenience")
  :authors '(("lorniu" . "lorniu@gmail.com"))
  :maintainers '(("lorniu" . "lorniu@gmail.com")))
