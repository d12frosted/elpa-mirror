;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eask" "20250404.106"
  "Core Eask APIs, for Eask CLI development."
  '((emacs "26.1"))
  :url "https://github.com/emacs-eask/eask"
  :commit "257b127379734b11c7865d5cc619cbbba9282023"
  :revdesc "257b12737973"
  :keywords '("lisp" "eask" "api")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
