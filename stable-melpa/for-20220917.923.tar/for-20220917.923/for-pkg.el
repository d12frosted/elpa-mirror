(define-package "for" "20220917.923" "Iteration and sequence"
  '((emacs "28.1"))
  :commit "d30f38f8880a17201efb58892cda9e44965cb359" :authors
  '(("Wing Hei Chan" . "whmunkchan@outlook.com"))
  :maintainer
  '("Wing Hei Chan" . "whmunkchan@outlook.com")
  :keywords
  '("extensions")
  :url "https://github.com/usaoc/elisp-for")
;; Local Variables:
;; no-byte-compile: t
;; End:
