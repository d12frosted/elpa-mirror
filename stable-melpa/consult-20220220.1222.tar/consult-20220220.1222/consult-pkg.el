(define-package "consult" "20220220.1222" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "f24b363f04644c7602af24d3fadb89f321499442" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
