(define-package "modus-themes" "20210521.819" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "d426fd28e9e4998b016297fcd1f39e2b36aa4356" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
