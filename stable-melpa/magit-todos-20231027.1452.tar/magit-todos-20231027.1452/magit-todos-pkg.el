(define-package "magit-todos" "20231027.1452" "Show source file TODOs in Magit"
  '((emacs "26.1")
    (async "1.9.2")
    (dash "2.13.0")
    (f "0.17.2")
    (hl-todo "1.9.0")
    (magit "2.13.0")
    (pcre2el "1.8")
    (s "1.12.0")
    (transient "0.2.0"))
  :commit "a197a04da1620ee7d41f3aa4f846a479760e2273" :authors
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainers
  '(("Adam Porter" . "adam@alphapapa.net"))
  :maintainer
  '("Adam Porter" . "adam@alphapapa.net")
  :keywords
  '("magit" "vc")
  :url "http://github.com/alphapapa/magit-todos")
;; Local Variables:
;; no-byte-compile: t
;; End:
