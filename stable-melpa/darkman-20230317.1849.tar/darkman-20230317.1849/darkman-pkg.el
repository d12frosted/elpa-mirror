(define-package "darkman" "20230317.1849" "Seamless integration with Darkman"
  '((emacs "28.1"))
  :commit "6c300374ce9c28adda43462795a13b7741b15299" :authors
  '(("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn"))
  :maintainer
  '("Aziz Ben Ali" . "tahaaziz.benali@esprit.tn")
  :keywords
  '("convenience")
  :url "https://grtcdr.tn/darkman.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
