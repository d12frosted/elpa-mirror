(define-package "dracula-theme" "20220116.920" "Dracula Theme"
  '((emacs "24.3"))
  :commit "9571f3cac4b9f0a72a12d05706f71f3c8df283e6" :authors
  '(("film42"))
  :maintainer
  '("Étienne Deparis" . "etienne@depar.is")
  :url "https://github.com/dracula/emacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
