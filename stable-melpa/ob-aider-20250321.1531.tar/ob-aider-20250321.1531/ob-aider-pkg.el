;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-aider" "20250321.1531"
  "Org Babel functions for Aider.el integration."
  '((emacs "27.1")
    (org   "9.4"))
  :url "https://github.com/localredhead/ob-aider.el"
  :commit "68470148973ca26c581045de3d8bdc3b4da57c43"
  :revdesc "68470148973c"
  :keywords '("tools" "convenience" "languages" "org" "processes")
  :authors '(("Levi Strope" . "levi.strope@gmail.com"))
  :maintainers '(("Levi Strope" . "levi.strope@gmail.com")))
