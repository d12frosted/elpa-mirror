;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "copilot" "20260215.918"
  "An unofficial Copilot plugin."
  '((emacs         "27.2")
    (editorconfig  "0.8.2")
    (jsonrpc       "1.0.14")
    (compat        "30")
    (track-changes "1.4"))
  :url "https://github.com/copilot-emacs/copilot.el"
  :commit "189f0b4a5163c438faaa5aca729f525225317c48"
  :revdesc "189f0b4a5163"
  :keywords '("convenience" "copilot")
  :authors '(("zerol" . "z@zerol.me"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")
                 ("Rakotomandimby Mihamina" . "mihamina.rakotomandimby@rktmb.org")
                 ("Bozhidar Batsov" . "bozhidar@batsov.dev")))
