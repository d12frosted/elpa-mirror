(define-package "elfeed-tube" "20220818.502" "YouTube integration for Elfeed"
  '((emacs "27.1")
    (elfeed "3.4.1")
    (aio "1.0"))
  :commit "395d8add1b090bae075b0f918add0078a2ca9759" :authors
  '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainer
  '("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")
  :keywords
  '("news" "hypermedia" "convenience")
  :url "https://github.com/karthink/elfeed-tube")
;; Local Variables:
;; no-byte-compile: t
;; End:
