;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "git-modeline" "20260914.629"
  "Show the git status of the current file in the modeline."
  '((emacs "26.1"))
  :url "https://github.com/djangoliv/git-modeline"
  :commit "c0ee693ff96d2ac9819c50e70f3fd73521dc72f6"
  :revdesc "c0ee693ff96d"
  :keywords '("vc" "tools" "convenience")
  :authors '(("djangoliv" . "olivier.giorgis@quantstack.net"))
  :maintainers '(("djangoliv" . "olivier.giorgis@quantstack.net")))
