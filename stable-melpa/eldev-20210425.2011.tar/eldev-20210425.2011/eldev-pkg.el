(define-package "eldev" "20210425.2011" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "7256b1b953fd8bf09acc840354e3a28e63fd1ba6" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
