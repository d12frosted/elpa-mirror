;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20241218.934"
  "Transient commands."
  '((emacs  "26.1")
    (compat "30.0.0.0")
    (seq    "2.24"))
  :url "https://github.com/magit/transient"
  :commit "88031d689108714b1a41618c3f0fd7e2d60d0b5f"
  :revdesc "88031d689108"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
