(define-package "live-py-mode" "20211204.2255" "Live Coding in Python"
  '((emacs "24.3"))
  :commit "82a34879d4a607fe9f09376d20222ff3c77ef809" :authors
  '(("Don Kirkby http://donkirkby.github.io"))
  :maintainer
  '("Don Kirkby http://donkirkby.github.io")
  :keywords
  '("live" "coding")
  :url "http://donkirkby.github.io/live-py-plugin/")
;; Local Variables:
;; no-byte-compile: t
;; End:
