(define-package "telega" "20201125.555" "Telegram client (unofficial)"
  '((emacs "26.1")
    (visual-fill-column "1.9")
    (rainbow-identifiers "0.2.2"))
  :commit "b1708a49d0d9317352f79b431da552af950cd638" :keywords
  ("comm")
  :authors
  (("Zajcev Evgeny" . "zevlg@yandex.ru"))
  :maintainer
  ("Zajcev Evgeny" . "zevlg@yandex.ru")
  :url "https://github.com/zevlg/telega.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
