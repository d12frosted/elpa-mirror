(define-package "soothe-theme" "20220826.1628" "A dark colorful theme"
  '((emacs "24.3")
    (autothemer "0.2"))
  :commit "fcb4cf648d4bf45d9e5dd3a2fb7f59f8faf99d19" :authors
  '(("Jason Milkins" . "jasonm23@gmail.com"))
  :maintainer
  '("Jason Milkins" . "jasonm23@gmail.com")
  :url "https://github.com/emacsfodder/emacs-soothe-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
