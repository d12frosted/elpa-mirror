(define-package "org-roam-ql-ql" "20230820.1942" "Intgrating org-roam and org-ql"
  '((emacs "28")
    (org-roam-ql "0.1")
    (org-ql "0.7")
    (org-roam "2.2.0")
    (s "1.12.0")
    (transient "0.4"))
  :commit "e5ee7db483c220f11b1517d1de92905fcc8e5879" :authors
  '(("Shariff AM Faleel"))
  :maintainers
  '(("Shariff AM Faleel"))
  :maintainer
  '("Shariff AM Faleel")
  :url "https://github.com/ahmed-shariff/org-roam-ql")
;; Local Variables:
;; no-byte-compile: t
;; End:
