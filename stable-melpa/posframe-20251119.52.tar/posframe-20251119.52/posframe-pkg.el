;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "posframe" "20251119.52"
  "Pop a posframe (just a frame) at point."
  '((emacs "26.1"))
  :url "https://github.com/tumashu/posframe"
  :commit "ec5901e75af20bf7ddb383b318b7db4d63dbaa3b"
  :revdesc "ec5901e75af2"
  :keywords '("convenience" "tooltip")
  :authors '(("Feng Shu" . "tumashu@163.com"))
  :maintainers '(("Feng Shu" . "tumashu@163.com")))
