;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "easysession" "20260205.1756"
  "Persist and restore your sessions (desktop.el alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/easysession.el"
  :commit "a534e36235349c2da651b19421a910ddd778a15e"
  :revdesc "a534e3623534"
  :keywords '("convenience"))
