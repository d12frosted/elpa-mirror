(define-package "org-change" "20231023.2156" "Annotate changes in org-mode files"
  '((emacs "26.1")
    (org "9.3"))
  :commit "4f59429e539ef978cdd3ffba1a0840fe35f654f4" :keywords
  '("wp" "convenience")
  :url "https://github.com/drghirlanda/org-change")
;; Local Variables:
;; no-byte-compile: t
;; End:
