(define-package "eldev" "20230805.1640" "Elisp development tool"
  '((emacs "24.4"))
  :commit "5ac5f26869cf4bcd96adc00edd254a845197e77a" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainers
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/emacs-eldev/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
