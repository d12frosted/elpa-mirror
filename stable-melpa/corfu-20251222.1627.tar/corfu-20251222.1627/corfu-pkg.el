;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251222.1627"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "fd127b8f4361fb143f487e84217321f89c4e3fb8"
  :revdesc "fd127b8f4361"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
