;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250530.1111"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "e54c3d7feb5763c2267cd17cbb3304b88462c92e"
  :revdesc "e54c3d7feb57"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
