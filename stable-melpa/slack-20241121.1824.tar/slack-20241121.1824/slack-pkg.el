;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "slack" "20241121.1824"
  "Slack client for Emacs."
  '((websocket "1.8")
    (request   "0.2.0")
    (oauth2    "0.10")
    (circe     "2.2")
    (alert     "1.2")
    (emojify   "0.2")
    (emacs     "25.1")
    (dash      "2.19.1")
    (s         "1.13.1")
    (ts        "0.3"))
  :url "https://github.com/emacs-slack/emacs-slack"
  :commit "b2b6d36d41c897bbbf57fbe1c559332e655ad340"
  :revdesc "b2b6d36d41c8"
  :keywords '("tools")
  :authors '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local"))
  :maintainers '(("yuya.minami" . "yuya.minami@yuyaminami-no-MacBook-Pro.local")))
