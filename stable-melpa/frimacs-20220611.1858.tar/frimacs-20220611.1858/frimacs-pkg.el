(define-package "frimacs" "20220611.1858" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "7813f151b4e59c3c175c7117228f0dd70dcc10d7" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
