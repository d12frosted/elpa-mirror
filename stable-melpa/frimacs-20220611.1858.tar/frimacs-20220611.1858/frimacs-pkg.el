(define-package "frimacs" "20220611.1858" "An environment for the FriCAS computer algebra system"
  '((emacs "26.1"))
  :commit "742268f6f05f418993dc366bbca9ccc931125748" :authors
  '(("Paul Onions" . "paul.onions@acm.org"))
  :maintainer
  '("Paul Onions" . "paul.onions@acm.org")
  :keywords
  '("fricas" "computer algebra" "extensions" "tools")
  :url "https://github.com/pdo/frimacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
