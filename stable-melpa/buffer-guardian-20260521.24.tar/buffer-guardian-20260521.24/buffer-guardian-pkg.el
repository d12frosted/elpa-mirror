;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-guardian" "20260521.24"
  "Automatically Save Buffers Without Manual Intervention."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/jc-dev"
  :commit "c16b9ba1bb279defab811466c274aa41f0dc2e7a"
  :revdesc "c16b9ba1bb27"
  :keywords '("maint")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
