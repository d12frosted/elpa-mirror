(define-package "ein" "20220604.1147" "Emacs IPython Notebook"
  '((emacs "25")
    (websocket "1.12")
    (anaphora "1.0.4")
    (request "0.3.3")
    (deferred "0.5")
    (polymode "0.2.2")
    (dash "2.13.0")
    (with-editor "0pre"))
  :commit "5d031ae6f1159780d13da1bc56602fe261574ac8" :keywords
  '("jupyter" "literate programming" "reproducible research")
  :url "https://github.com/dickmao/emacs-ipython-notebook")
;; Local Variables:
;; no-byte-compile: t
;; End:
