;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clatter" "20260714.845"
  "An IRCv3-compliant IRC client."
  '((emacs "30.1"))
  :url "https://github.com/parenworks/clatter.el"
  :commit "00782c42a8c122811fa81066e63fce0dd000929b"
  :revdesc "00782c42a8c1"
  :keywords '("comm" "irc")
  :authors '(("Glenn Thompson" . "glenn@paren.works"))
  :maintainers '(("Glenn Thompson" . "glenn@paren.works")))
