;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "envrc" "20260921.1016"
  "Support for `direnv' that operates buffer-locally."
  '((emacs      "28.1")
    (inheritenv "0.1"))
  :url "https://github.com/purcell/envrc"
  :commit "1ecb82e01745d700578754eb35d6c1758290b869"
  :revdesc "1ecb82e01745"
  :keywords '("processes" "tools")
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
