;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pyfun-mode" "20261017.1859"
  "Major mode for the Pyfun language."
  '((emacs "29.1"))
  :url "https://github.com/simontreanor/Pyfun"
  :commit "f7acdaf9452dcb4d0fcdadaec811c70ede1675d2"
  :revdesc "f7acdaf9452d"
  :keywords '("languages")
  :authors '(("Simon Treanor" . "https://github.com/simontreanor"))
  :maintainers '(("Simon Treanor" . "https://github.com/simontreanor")))
