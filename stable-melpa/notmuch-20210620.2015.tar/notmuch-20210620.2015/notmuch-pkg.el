(define-package "notmuch" "20210620.2015" "run notmuch within emacs" 'nil :commit "8dbd5deb8d3bbfda9554163c8d4cb2474c505c87" :url "https://notmuchmail.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
