;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "aidermacs" "20250310.704"
  "AI pair programming with Aider."
  '((emacs "28.1"))
  :url "https://github.com/MatthewZMD/aidermacs"
  :commit "4af8c4283dd1180a3f833138db168471ec7054dc"
  :revdesc "4af8c4283dd1"
  :keywords '("ai" "emacs" "llm" "aider" "ai-pair-programming" "tools")
  :authors '(("Mingde Zeng" . "matthewzmd@posteo.net"))
  :maintainers '(("Mingde Zeng" . "matthewzmd@posteo.net")))
