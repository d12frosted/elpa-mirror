(define-package "lice" "20220312.828" "License And Header Template" 'nil :commit "9daa798da9faf13ed3652b3e7103136078a9da4f" :authors
  '(("Taiki Sugawara" . "buzz.taiki@gmail.com"))
  :maintainer
  '("Taiki Sugawara" . "buzz.taiki@gmail.com")
  :keywords
  '("template" "license" "tools")
  :url "https://github.com/buzztaiki/lice-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
