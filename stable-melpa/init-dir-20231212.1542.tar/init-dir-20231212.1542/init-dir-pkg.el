(define-package "init-dir" "20231212.1542" "Init directory instead of just a single file"
  '((emacs "27.1"))
  :commit "fa7ada3a52e203c2aeb1546a61a71416fdf2f65d" :authors
  '(("Jared Finder" . "jared@finder.org"))
  :maintainers
  '(("Jared Finder" . "jared@finder.org"))
  :maintainer
  '("Jared Finder" . "jared@finder.org")
  :keywords
  '("extensions" "internal")
  :url "http://github.com/chaosemer/init-dir")
;; Local Variables:
;; no-byte-compile: t
;; End:
