;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bicycle" "20261001.1535"
  "Cycle outline and code visibility."
  '((emacs  "28.1")
    (compat "31.1"))
  :url "https://github.com/tarsius/bicycle"
  :commit "b638dcc3945950d05400466c7166d0c941f18694"
  :revdesc "b638dcc39459"
  :keywords '("outlines")
  :authors '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.bicycle@jonas.bernoulli.dev")))
