;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-node" "20250605.502"
  "Fast org-roam replacement."
  '((emacs         "29.1")
    (llama         "0.5.0")
    (org-mem       "0.14.1")
    (magit-section "4.3.0"))
  :url "https://github.com/meedstrom/org-node"
  :commit "19dca9f0ca1f3bd958757b356dad100e4bb255c6"
  :revdesc "19dca9f0ca1f"
  :keywords '("org" "hypermedia")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
