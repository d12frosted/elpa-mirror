;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250102.255"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.4.0")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "dc417a5483b73096934afc442e2f1d4969559c9f"
  :revdesc "dc417a5483b7"
  :keywords '("convenience")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
