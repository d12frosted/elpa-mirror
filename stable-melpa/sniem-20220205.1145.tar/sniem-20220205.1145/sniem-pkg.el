(define-package "sniem" "20220205.1145" "Hands-eased united editing method"
  '((emacs "27.1")
    (s "2.12.0")
    (dash "1.12.0"))
  :commit "72acb51ad48ea56fb4fb270f93aebd73c96bb38f" :authors
  '(("SpringHan"))
  :maintainer
  '("SpringHan")
  :keywords
  '("convenience" "united-editing-method")
  :url "https://github.com/SpringHan/sniem.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
