(define-package "avy-migemo" "20160321.1011" "avy with migemo"
  '((emacs "24.4")
    (avy "0.4.0")
    (migemo "1.9"))
  :commit "ce87777bea76c45be5f185e9fe356a8efe5c2d16" :authors
  '(("momomo5717"))
  :maintainer
  '("momomo5717")
  :keywords
  '("avy" "migemo")
  :url "https://github.com/momomo5717/avy-migemo")
;; Local Variables:
;; no-byte-compile: t
;; End:
