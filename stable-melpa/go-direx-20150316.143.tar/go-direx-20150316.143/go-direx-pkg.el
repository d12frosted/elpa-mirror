;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "go-direx" "20150316.143"
  "Tree style source code viewer for Go language."
  '((direx  "1.0.0")
    (cl-lib "0.5"))
  :url "https://github.com/syohex/emacs-go-direx"
  :commit "aecb9fef4d56d04d230d37c75c260c8392b5ad9f"
  :revdesc "aecb9fef4d56"
  :authors '(("Syohei YOSHIDA" . "syohex@gmail.com"))
  :maintainers '(("Syohei YOSHIDA" . "syohex@gmail.com")))
