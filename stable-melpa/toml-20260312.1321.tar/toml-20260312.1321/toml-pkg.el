;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "toml" "20260312.1321"
  "TOML (Tom's Obvious, Minimal Language) parser."
  ()
  :url "https://github.com/gongo/emacs-toml"
  :commit "b280ae65d73bee0050d1c6c63adeca3ba4419778"
  :revdesc "b280ae65d73b"
  :keywords '("toml" "parser")
  :authors '(("Wataru MIYAGUNI" . "gonngo@gmail.com"))
  :maintainers '(("Wataru MIYAGUNI" . "gonngo@gmail.com")))
