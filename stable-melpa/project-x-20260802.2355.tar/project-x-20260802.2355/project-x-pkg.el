;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "project-x" "20260802.2355"
  "Extra convenience features for project.el."
  '((emacs "28.1"))
  :url "https://github.com/vmargb/project-x"
  :commit "6f95c7e722db3e1c9fcee43e00873883630b5eed"
  :revdesc "6f95c7e722db"
  :keywords '("project" "convenience" "session" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("vmargb" . "https://github.com/vmargb")))
