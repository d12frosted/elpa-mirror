(define-package "dirvish" "20220125.706" "A modern file manager based on dired mode"
  '((emacs "27.1"))
  :commit "48822adf69284d953fbda7ecd6a4356ae44d2c74" :authors
  '(("Alex Lu <https://github.com/alexluigit>"))
  :maintainer
  '("Alex Lu <https://github.com/alexluigit>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/alexluigit/dirvish")
;; Local Variables:
;; no-byte-compile: t
;; End:
