(define-package "modus-themes" "20211225.554" "Highly accessible themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "c435114b9733be1b6c7ea61b07bc94683812d970" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
