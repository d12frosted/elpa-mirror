;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20251207.1213"
  "A single native shell experience to interact with agentic providers (Claude Code, Cursor, Gemini CLI, Goose, Codex, OpenCode, Qwen, etc.)."
  '((emacs       "29.1")
    (shell-maker "0.84.1")
    (acp         "0.8.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "b81830ded7bdfd4ef02b498bea77982a060d1b2b"
  :revdesc "b81830ded7bd")
