(define-package "w3m" "20210802.114" "an Emacs interface to w3m" 'nil :commit "bd712267d5fd42a5f6f10795cbc75475199e1ab9" :keywords
  '("w3m" "www" "hypermedia"))
;; Local Variables:
;; no-byte-compile: t
;; End:
