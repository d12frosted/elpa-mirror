(define-package "detached" "20220524.1604" "A package to launch, and manage, detached processes"
  '((emacs "27.1"))
  :commit "cf229d6d6be3f7fd6454a7db9a9f6397b6a8ffed" :authors
  '(("Niklas Eklund" . "niklas.eklund@posteo.net"))
  :maintainer
  '("Niklas Eklund" . "niklas.eklund@posteo.net")
  :keywords
  '("convenience" "processes")
  :url "https://sr.ht/~niklaseklund/detached.el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
