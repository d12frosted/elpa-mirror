;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-sage" "20160514.745"
  "A helm extension for sage-shell-mode."
  '((cl-lib          "0.5")
    (helm            "1.5.6")
    (sage-shell-mode "0.1.0"))
  :url "https://github.com/stakemori/helm-sage"
  :commit "f14e9281d8f2162df7d8f9c2ad9ad1248a24803b"
  :revdesc "f14e9281d8f2"
  :keywords '("sage" "math" "helm")
  :authors '(("Sho Takemori" . "stakemorii@gmail.com"))
  :maintainers '(("Sho Takemori" . "stakemorii@gmail.com")))
