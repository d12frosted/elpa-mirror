;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cfn-mode" "20250420.805"
  "AWS cloudformation mode."
  '((emacs     "27.0")
    (f         "0.20.0")
    (s         "1.12.0")
    (yaml-mode "0.0.13"))
  :url "https://gitlab.com/worr/cfn-mode"
  :commit "dfc0550e3b22f28adfeaa78d77f36315e0b9a15b"
  :revdesc "dfc0550e3b22"
  :keywords '("convenience" "languages" "tools")
  :authors '(("William Orr" . "will@worrbase.com"))
  :maintainers '(("William Orr" . "will@worrbase.com")))
