;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tree-sitter-langs" "20251224.1317"
  "Grammar bundle for tree-sitter."
  '((emacs       "26.1")
    (tree-sitter "0.15.0"))
  :url "https://github.com/emacs-tree-sitter/tree-sitter-langs"
  :commit "2e2578dce48d3a2121cd10bf778611504358bbcf"
  :revdesc "2e2578dce48d"
  :keywords '("languages" "tools" "parsers" "tree-sitter")
  :authors '(("Tuấn-Anh Nguyễn" . "ubolonton@gmail.com"))
  :maintainers '(("Jen-Chieh Shen" . "jcs090218@gmail.com")))
