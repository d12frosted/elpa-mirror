(define-package "ede-php-autoload" "20180901.1255" "Simple EDE PHP Project" 'nil :commit "8a4eeeaa93b8d87b65a107c4ebcbeb14528d9449" :keywords
  ("php" "project" "ede")
  :authors
  (("Steven Rémot" . "steven.remot@gmail.com")
   ("original code for C++ by Eric M. Ludlam" . "eric@siege-engine.com"))
  :maintainer
  ("Steven Rémot" . "steven.remot@gmail.com")
  :url "https://github.com/emacs-php/ede-php-autoload")
;; Local Variables:
;; no-byte-compile: t
;; End:
