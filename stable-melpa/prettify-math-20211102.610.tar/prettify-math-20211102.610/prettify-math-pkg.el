(define-package "prettify-math" "20211102.610" "Prettify math formula"
  '((emacs "27.1")
    (dash "2.19.0")
    (s "1.12.0")
    (jsonrpc "1.0.9"))
  :commit "491bdd6764afeaf3211dd0199e19a06b7bbb7e0a" :authors
  '(("Shaq Xu" . "shaqxu@163.com"))
  :maintainer
  '("Shaq Xu" . "shaqxu@163.com")
  :keywords
  '("math" "asciimath" "tex" "latex" "prettify" "mathjax")
  :url "https://gitee.com/shaqxu/prettify-math")
;; Local Variables:
;; no-byte-compile: t
;; End:
