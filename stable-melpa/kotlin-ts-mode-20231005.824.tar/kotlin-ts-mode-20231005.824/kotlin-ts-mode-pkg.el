(define-package "kotlin-ts-mode" "20231005.824" "A mode for editing Kotlin files based on tree-sitter"
  '((emacs "29.1"))
  :commit "8d98d2ecf15ce1a378c13a46e462e47ee39d4198" :authors
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainers
  '(("Alex Figl-Brick" . "alex@alexbrick.me"))
  :maintainer
  '("Alex Figl-Brick" . "alex@alexbrick.me")
  :url "https://gitlab.com/bricka/emacs-kotlin-ts-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
