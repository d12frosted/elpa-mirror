;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gptel" "20250311.706"
  "Interact with ChatGPT or other LLMs."
  '((emacs     "27.1")
    (transient "0.7.4")
    (compat    "29.1.4.1"))
  :url "https://github.com/karthink/gptel"
  :commit "8889e27c5b53478248b05a660778ae744848c1cd"
  :revdesc "8889e27c5b53"
  :keywords '("convenience" "tools")
  :authors '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com"))
  :maintainers '(("Karthik Chikmagalur" . "karthik.chikmagalur@gmail.com")))
