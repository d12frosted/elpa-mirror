;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20260830.1306"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "1b5ff3ee4ee2cb7a639d214451c266b0d3c2aa1d"
  :revdesc "1b5ff3ee4ee2"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")
                 ("Mats Lidell" . "matsl@gnu.org")))
