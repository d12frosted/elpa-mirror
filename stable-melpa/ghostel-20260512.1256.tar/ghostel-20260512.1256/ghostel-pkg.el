;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260512.1256"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "b83fd7ea5a21ea0661f875f541786bfff744cac1"
  :revdesc "b83fd7ea5a21"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
