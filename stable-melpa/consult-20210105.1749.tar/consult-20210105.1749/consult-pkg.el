(define-package "consult" "20210105.1749" "Consulting completing-read"
  '((emacs "26.1"))
  :commit "b62b22786c13d5c9a2403123095bb251ebaf4218" :authors
  '(("Daniel Mendler, Consult and Selectrum contributors"))
  :maintainer
  '("Daniel Mendler")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
