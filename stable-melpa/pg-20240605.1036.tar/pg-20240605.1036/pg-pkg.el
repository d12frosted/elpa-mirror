(define-package "pg" "20240605.1036" "Emacs Lisp socket-level interface to the PostgreSQL RDBMS"
  '((emacs "28.1")
    (peg "1.0"))
  :commit "10229db41ce8b9417b2bda0c2836cec0ed3dae95" :authors
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainers
  '(("Eric Marsden" . "eric.marsden@risk-engineering.org"))
  :maintainer
  '("Eric Marsden" . "eric.marsden@risk-engineering.org")
  :keywords
  '("data" "comm" "database" "postgresql")
  :url "https://github.com/emarsden/pg-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
