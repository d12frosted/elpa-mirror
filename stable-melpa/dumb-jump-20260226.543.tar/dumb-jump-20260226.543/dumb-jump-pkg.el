;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dumb-jump" "20260226.543"
  "Jump to definition for 60+ languages without configuration."
  '((emacs "24.4")
    (dash  "2.9.0"))
  :url "https://github.com/jacktasia/dumb-jump"
  :commit "ea15cbbeb134634c09c359337bfb58cd6c09476d"
  :revdesc "ea15cbbeb134"
  :keywords '("programming"))
