;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-core" "20251206.1353"
  "Development files for Helm."
  '((emacs "25.1")
    (async "1.9.9"))
  :url "https://emacs-helm.github.io/helm/"
  :commit "61c2efe9f5b03eac04a36ca86be163dae1574301"
  :revdesc "61c2efe9f5b0"
  :authors '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers '(("Thierry Volpiatto" . "thievol@posteo.net")))
