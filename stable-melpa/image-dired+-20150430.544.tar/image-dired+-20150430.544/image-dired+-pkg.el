;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "image-dired+" "20150430.544"
  "Image-dired extensions."
  '((cl-lib "0.3"))
  :url "https://github.com/mhayashi1120/Emacs-image-diredx"
  :commit "b68094625d963056ad64e0e44af0e2266b2eadc7"
  :revdesc "b68094625d96"
  :keywords '("extensions" "multimedia")
  :authors '(("Masahiro Hayashi" . "mhayashi1120@gmail.com"))
  :maintainers '(("Masahiro Hayashi" . "mhayashi1120@gmail.com")))
