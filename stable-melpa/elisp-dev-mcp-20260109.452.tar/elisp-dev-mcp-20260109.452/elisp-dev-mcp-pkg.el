;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "elisp-dev-mcp" "20260109.452"
  "MCP server for agentic Elisp development."
  '((emacs          "27.1")
    (mcp-server-lib "0.2.0"))
  :url "https://github.com/laurynas-biveinis/elisp-dev-mcp"
  :commit "aed89eacc49ad53f64da882d32e17c289e888443"
  :revdesc "aed89eacc49a"
  :keywords '("tools" "development"))
