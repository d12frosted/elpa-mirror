(define-package "memento-mori" "20231202.17" "Reminder of mortality"
  '((emacs "24.3"))
  :commit "dca8eae1f76fccd39b7c084dacae56bf6e2a913e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainers
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("help")
  :url "https://github.com/lassik/emacs-memento-mori")
;; Local Variables:
;; no-byte-compile: t
;; End:
