;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "shell-command-x" "20231214.1"
  "Extensions for shell commands."
  '((emacs "28.1"))
  :url "https://github.com/elizagamedev/shell-command-x.el"
  :commit "d2fe4d08be306d6570f3c316ea06b0e6931ea5d5"
  :revdesc "d2fe4d08be30"
  :keywords '("convenience" "processes" "unix"))
