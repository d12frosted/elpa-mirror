;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "helm-system-packages" "20251122.709"
  "Helm UI wrapper for system package managers."
  '((emacs "24.4")
    (helm  "2.8.7")
    (seq   "1.8"))
  :url "https://github.com/emacs-helm/helm-system-packages"
  :commit "d4a2432791cb481e0dc4c54831df6e92eaf6eed8"
  :revdesc "d4a2432791cb"
  :keywords '("helm" "packages")
  :authors '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainers '(("Pierre Neidhardt" . "mail@ambrevar.xyz")))
