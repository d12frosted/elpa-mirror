(define-package "orgtbl-show-header" "20141031.1547" "Show the header of the current column in the minibuffer" 'nil :commit "f0f48ccc0f96d4aa2a676ff609d9dddd71748e6f" :authors
  '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainers
  '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainer
  '("Damien Cassou" . "damien.cassou@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
