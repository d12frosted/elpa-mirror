(define-package "json-par" "20230401.901" "Minor mode for structural editing of JSON"
  '((emacs "24.4")
    (json-mode "1.7.0"))
  :commit "9d4503d595c41c5e501f6ce9067b487f8933cd4b" :authors
  '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainers
  '(("taku0" . "mxxouy6x3m_github@tatapa.org"))
  :maintainer
  '("taku0" . "mxxouy6x3m_github@tatapa.org")
  :keywords
  '("abbrev" "convenience" "files")
  :url "https://github.com/taku0/json-par")
;; Local Variables:
;; no-byte-compile: t
;; End:
