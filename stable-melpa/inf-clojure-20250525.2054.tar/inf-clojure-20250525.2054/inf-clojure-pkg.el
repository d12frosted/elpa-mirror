;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "inf-clojure" "20250525.2054"
  "Basic interaction with a Clojure REPL."
  '((emacs        "28.1")
    (clojure-mode "5.11"))
  :url "https://github.com/clojure-emacs/inf-clojure"
  :commit "bdef6110a3d051c08179503207eadc43b1dd4d09"
  :revdesc "bdef6110a3d0"
  :keywords '("processes" "comint" "clojure")
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
