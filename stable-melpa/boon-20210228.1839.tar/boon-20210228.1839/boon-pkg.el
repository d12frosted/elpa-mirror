(define-package "boon" "20210228.1839" "Ergonomic Command Mode for Emacs."
  '((emacs "25.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0")
    (pcre2el "1.8"))
  :commit "58107055dadb735941537c90457753dbc1ea7005")
;; Local Variables:
;; no-byte-compile: t
;; End:
