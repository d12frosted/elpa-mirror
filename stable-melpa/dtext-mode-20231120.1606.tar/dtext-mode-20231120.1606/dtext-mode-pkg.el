;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dtext-mode" "20231120.1606"
  "Major mode for Danbooru DText."
  '((emacs "24.4"))
  :url "https://github.com/JohnDevlopment/dtext-mode.el"
  :commit "5c68d1c05c4606f68384569d9baaef4f6e72fc73"
  :revdesc "5c68d1c05c46"
  :keywords '("languages")
  :authors '(("John Russell" . "johndevlopment7@gmail.com"))
  :maintainers '(("John Russell" . "johndevlopment7@gmail.com")))
