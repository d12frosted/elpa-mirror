;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20260629.934"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.4.0")
    (vui    "1.0"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "bed846c0f08a8b7500c63d19772d926d01e938ca"
  :revdesc "bed846c0f08a"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
