;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "python-mode" "20251107.736"
  "Python major mode."
  ()
  :url "https://gitlab.com/groups/python-mode-devs"
  :commit "10478fbaebde53a4d8450d825789cae10d4edcdc"
  :revdesc "10478fbaebde"
  :keywords '("python" "languages" "oop")
  :maintainers '((nil . "python-mode@python.org")))
