;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260823.1350"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "447cacd64370e5fc3ee3fa71719d7d6e3da7a624"
  :revdesc "447cacd64370"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
