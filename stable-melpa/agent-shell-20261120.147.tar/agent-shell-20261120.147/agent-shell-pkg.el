;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20261120.147"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.98.3")
    (acp         "0.20.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "7473e5eb2f3a7da01e1762ac20ac3a4c577b1cb8"
  :revdesc "7473e5eb2f3a")
