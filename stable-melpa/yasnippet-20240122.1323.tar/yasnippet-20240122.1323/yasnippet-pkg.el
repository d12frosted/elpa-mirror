(define-package "yasnippet" "20240122.1323" "Yet another snippet extension for Emacs"
  '((cl-lib "0.5")
    (emacs "24.4"))
  :commit "5af84cdb94fb2f45933c13b5aed378425b487564" :maintainers
  '(("Noam Postavsky" . "npostavs@gmail.com"))
  :maintainer
  '("Noam Postavsky" . "npostavs@gmail.com")
  :keywords
  '("convenience" "emulation")
  :url "http://github.com/joaotavora/yasnippet")
;; Local Variables:
;; no-byte-compile: t
;; End:
