;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "consult-notes" "20251114.1555"
  "Manage notes with consult."
  '((emacs   "27.1")
    (consult "0.17")
    (s       "1.12.0")
    (dash    "2.19"))
  :url "https://github.com/mclear-tools/consult-notes"
  :commit "26297ff8756f7fccec6532ad4d2a8edc8c7e8a27"
  :revdesc "26297ff8756f"
  :keywords '("convenience")
  :authors '(("Colin McLear" . "mclear@fastmail.com")))
