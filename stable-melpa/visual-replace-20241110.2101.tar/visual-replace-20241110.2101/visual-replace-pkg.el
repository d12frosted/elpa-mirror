;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "visual-replace" "20241110.2101"
  "A prompt for replace-string and query-replace."
  '((emacs "26.1"))
  :url "https://github.com/szermatt/visual-replace"
  :commit "6fbda3d3749391ecf7b906fb0681713032f13a7e"
  :revdesc "6fbda3d37493"
  :keywords '("convenience" "matching" "replace")
  :authors '(("Stephane Zermatten" . "szermatt@gmail.com"))
  :maintainers '(("Stephane Zermatten" . "szermatt@gmail.com")))
