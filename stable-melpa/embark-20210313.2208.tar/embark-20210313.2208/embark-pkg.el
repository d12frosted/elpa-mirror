(define-package "embark" "20210313.2208" "Conveniently act on minibuffer completions"
  '((emacs "26.1"))
  :commit "1edbb1af2a6ff2f25a34d9c769baf6fc175a7ef7" :authors
  '(("Omar Antolín Camarena" . "omar@matem.unam.mx"))
  :maintainer
  '("Omar Antolín Camarena" . "omar@matem.unam.mx")
  :keywords
  '("convenience")
  :url "https://github.com/oantolin/embark")
;; Local Variables:
;; no-byte-compile: t
;; End:
