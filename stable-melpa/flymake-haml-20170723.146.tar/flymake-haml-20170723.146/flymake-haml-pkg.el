;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flymake-haml" "20170723.146"
  "A flymake handler for haml files."
  '((flymake-easy "0.1"))
  :url "https://github.com/purcell/flymake-haml"
  :commit "22a81e8484734552d461e7ae7305664dc244447e"
  :revdesc "22a81e848473"
  :authors '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainers '(("Steve Purcell" . "steve@sanityinc.com")))
