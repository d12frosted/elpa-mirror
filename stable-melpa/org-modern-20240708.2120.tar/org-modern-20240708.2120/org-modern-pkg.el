(define-package "org-modern" "20240708.2120" "Modern looks for Org"
  '((emacs "27.1")
    (compat "30"))
  :commit "4afaa86c51b1f0b41c2a6ea8199befeb7c55eeb2" :authors
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers
  '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :keywords
  '("outlines" "hypermedia" "text")
  :url "https://github.com/minad/org-modern")
;; Local Variables:
;; no-byte-compile: t
;; End:
