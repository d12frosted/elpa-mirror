(define-package "consult" "20230311.1859" "Consulting completing-read"
  '((emacs "27.1")
    (compat "29.1.4.0"))
  :commit "fd00979d2fbfad66960c621e9fc140eb8c6a06f3" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
