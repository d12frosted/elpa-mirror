;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ellama" "20261124.1539"
  "Tool for interacting with LLMs."
  '((emacs     "28.1")
    (llm       "0.33.0")
    (plz       "0.8")
    (transient "0.7")
    (compat    "29.1")
    (yaml      "1.2.3"))
  :url "https://github.com/s-kostyaev/ellama"
  :commit "c05729669c5c80c9353870689cc2a7597c661006"
  :revdesc "c05729669c5c"
  :keywords '("help" "local" "tools")
  :authors '(("Sergey Kostyaev" . "sskostyaev@gmail.com"))
  :maintainers '(("Sergey Kostyaev" . "sskostyaev@gmail.com")))
