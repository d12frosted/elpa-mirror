;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-window-habit" "20260808.2040"
  "Time window based habits."
  '((emacs "29.1")
    (dash  "2.10.0"))
  :url "https://github.com/colonelpanic8/org-window-habit"
  :commit "0f3e9101fed8e51680bfecb4c90849df87d48da8"
  :revdesc "0f3e9101fed8"
  :keywords '("calendar" "org-mode" "habit" "interval" "window")
  :authors '(("Ivan Malison" . "IvanMalison@gmail.com"))
  :maintainers '(("Ivan Malison" . "IvanMalison@gmail.com")))
