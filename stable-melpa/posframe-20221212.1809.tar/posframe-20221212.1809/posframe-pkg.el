(define-package "posframe" "20221212.1809" "Pop a posframe (just a frame) at point"
  '((emacs "26.1"))
  :commit "94719253d6a943ab5b42c62d6c8db6d3bc15e808" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
