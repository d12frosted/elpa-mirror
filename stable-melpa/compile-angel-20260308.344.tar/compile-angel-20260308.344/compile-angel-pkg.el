;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260308.344"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "f09b581864ee9950f0ae4e6181bb46431a88f1d3"
  :revdesc "f09b581864ee"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
