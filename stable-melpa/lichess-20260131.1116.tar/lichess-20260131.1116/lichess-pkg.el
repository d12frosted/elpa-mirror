;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "lichess" "20260131.1116"
  "Client for Lichess.org."
  '((emacs "27.1"))
  :url "https://github.com/tmythicator/Lichess.el"
  :commit "b714bf72d7acc1baf59e929b6d3f2a13243754ac"
  :revdesc "b714bf72d7ac"
  :keywords '("games" "chess" "lichess" "api")
  :authors '(("Alexandr Timchenko" . "atimchenko92@gmail.com"))
  :maintainers '(("Alexandr Timchenko" . "atimchenko92@gmail.com")))
