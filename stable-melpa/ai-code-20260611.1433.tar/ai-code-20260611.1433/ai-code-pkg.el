;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ai-code" "20260611.1433"
  "Unified interface for AI coding backends."
  '((emacs     "29.1")
    (transient "0.9.0")
    (magit     "2.1.0"))
  :url "https://github.com/tninja/ai-code-interface.el"
  :commit "306b18df197a4d3f115af041f806c089dc8277ee"
  :revdesc "306b18df197a"
  :authors '(("Kang Tu" . "tninja@gmail.com"))
  :maintainers '(("Kang Tu" . "tninja@gmail.com")))
