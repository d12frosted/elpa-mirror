;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260110.557"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "192b2f612e44303750c3d7515d39030fa8cf1c4b"
  :revdesc "192b2f612e44"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
