;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivariants" "20170823.224"
  "Ideographic variants editor and browser."
  '((emacs    "24.3")
    (ivs-edit "1.0"))
  :url "https://github.com/kawabata/ivariants"
  :commit "ca0b74d32b5d2d77a45cc6ad6edc00be0ee85284"
  :revdesc "ca0b74d32b5d"
  :keywords '("i18n" "languages")
  :authors '(("Taichi" . "kawabata.taichi_at_gmail.com"))
  :maintainers '(("Taichi" . "kawabata.taichi_at_gmail.com")))
