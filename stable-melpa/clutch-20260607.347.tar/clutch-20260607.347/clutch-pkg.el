;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "clutch" "20260607.347"
  "Interactive database client."
  '((emacs     "29.1")
    (mysql     "0.2.2")
    (pg        "0.40")
    (transient "0.3.7"))
  :url "https://github.com/LuciusChen/clutch"
  :commit "198dec69653739907a510e206f5367cd5e2c73f0"
  :revdesc "198dec696537"
  :keywords '("comm" "data" "tools")
  :authors '(("Lucius Chen" . "chenyh572@gmail.com"))
  :maintainers '(("Lucius Chen" . "chenyh572@gmail.com")))
