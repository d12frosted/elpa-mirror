(define-package "thrift" "20231210.1733" "major mode for fbthrift and Apache Thrift files"
  '((emacs "24"))
  :commit "1678fba0715b526ff7f15571695f179be89eec71" :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
