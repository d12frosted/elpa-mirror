;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "outline-indent" "20260204.1644"
  "Folding text based on indentation (origami alternative)."
  '((emacs "26.1"))
  :url "https://github.com/jamescherti/outline-indent.el"
  :commit "b0d2a0a28e2f5c252db7d69e3474e5ffae34d7da"
  :revdesc "b0d2a0a28e2f"
  :keywords '("outlines"))
