;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260924.1210"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.3")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "19e9d0175a5392af9999447f6be99f65e43f37bb"
  :revdesc "19e9d0175a53")
