;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eca" "20260711.1928"
  "AI pair programming via ECA (Editor Code Assistant)."
  '((emacs         "28.1")
    (dash          "2.18.0")
    (s             "1.12.0")
    (f             "0.20.0")
    (markdown-mode "2.3")
    (compat        "30.1"))
  :url "https://github.com/editor-code-assistant/eca-emacs"
  :commit "acc2b0647f4dd0988ba15c2d0f9b5aef5d3ea96f"
  :revdesc "acc2b0647f4d"
  :keywords '("tools")
  :authors '(("Eric Dallo" . "ercdll1337@gmail.com"))
  :maintainers '(("Eric Dallo" . "ercdll1337@gmail.com")))
