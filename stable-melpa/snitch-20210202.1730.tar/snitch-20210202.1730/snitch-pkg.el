(define-package "snitch" "20210202.1730" "An Emacs firewall"
  '((emacs "27.1"))
  :commit "14e91336fb04c23d7b23836642eef3f2edef03bf" :authors
  '(("Trevor Bentley" . "snitch.el@x.mrmekon.com"))
  :maintainer
  '("Trevor Bentley" . "snitch.el@x.mrmekon.com")
  :keywords
  '("processes" "comm")
  :url "https://github.com/mrmekon/snitch-el")
;; Local Variables:
;; no-byte-compile: t
;; End:
