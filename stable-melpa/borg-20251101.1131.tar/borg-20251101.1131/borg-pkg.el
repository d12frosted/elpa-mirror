;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "borg" "20251101.1131"
  "Assimilate Emacs packages as Git submodules."
  '((emacs "27.1")
    (epkg  "4.1")
    (magit "4.4"))
  :url "https://github.com/emacscollective/borg"
  :commit "bb63f8231f04d33df1c4dd9339c7cd10c7254fb9"
  :revdesc "bb63f8231f04"
  :keywords '("tools")
  :authors '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.borg@jonas.bernoulli.dev")))
