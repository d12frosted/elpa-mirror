;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "simple-httpd" "20260428.1833"
  "Pure Elisp HTTP server."
  '((emacs  "27.1")
    (compat "30"))
  :url "https://github.com/skeeto/emacs-http-server"
  :commit "0dfed044a8b4e4adf63bd862da5e63a822aff61f"
  :revdesc "0dfed044a8b4"
  :keywords '("network" "comm")
  :authors '(("Christopher Wellons" . "wellons@nullprogram.com"))
  :maintainers '(("Philip Kaludercic" . "philipk@posteo.net")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
