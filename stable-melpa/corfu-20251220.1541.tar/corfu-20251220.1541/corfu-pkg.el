;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "corfu" "20251220.1541"
  "COmpletion in Region FUnction."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/corfu"
  :commit "439f37ef69161a97fbf8d9389e1b10ca92f8a48b"
  :revdesc "439f37ef6916"
  :keywords '("abbrev" "convenience" "matching" "completion" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
