;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "tempel" "20260120.1246"
  "Tempo templates/snippets with in-buffer field editing."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/tempel"
  :commit "b5cecf7b3b4efea35cd8552b6add3e2142f657a3"
  :revdesc "b5cecf7b3b4e"
  :keywords '("abbrev" "languages" "tools" "text")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
