;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20260707.2341"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "880d4af5cadadfa3b0348c340f187aa45c0a870c"
  :revdesc "880d4af5cada")
