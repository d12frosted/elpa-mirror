;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "eglot-typescript-preset" "20260617.128"
  "Eglot preset for TypeScript."
  '((emacs "30.2")
    (eglot "1.17"))
  :url "https://github.com/mwolson/eglot-typescript-preset"
  :commit "cc780650223cf08f2268bca3de16509c61ef885d"
  :revdesc "cc780650223c"
  :keywords '("typescript" "javascript" "convenience" "languages" "tools")
  :authors '(("Michael Olson" . "mwolson@gnu.org"))
  :maintainers '(("Michael Olson" . "mwolson@gnu.org")))
