(define-package "lfe-mode" "20220709.1956" "Lisp Flavoured Erlang mode" 'nil :commit "d10af0a774d6d9c41ea78fe0185fdd0065a05d66")
;; Local Variables:
;; no-byte-compile: t
;; End:
