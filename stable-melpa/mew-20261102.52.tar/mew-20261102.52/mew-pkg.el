;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "mew" "20261102.52"
  "Messaging in the Emacs World."
  ()
  :url "https://github.com/kazu-yamamoto/Mew"
  :commit "3654285bd47c2030f4c6c4e92f46388b064c049d"
  :revdesc "3654285bd47c")
