;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250523.2301"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "f95e15619edc1f70d37592e66adcf1c25f0dd383"
  :revdesc "f95e15619edc"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
