;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "dicom" "20260117.1648"
  "DICOM viewer - Digital Imaging & Communications in Medicine."
  '((emacs  "29.1")
    (compat "30"))
  :url "https://github.com/minad/dicom"
  :commit "03a12498905ef80d67ff53d138d415d828ceb12f"
  :revdesc "03a12498905e"
  :keywords '("multimedia" "hypermedia" "files")
  :authors '(("Daniel Mendler" . "mail@daniel-mendler.de"))
  :maintainers '(("Daniel Mendler" . "mail@daniel-mendler.de")))
