;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "truename-cache" "20260223.2304"
  "Efficiently de-dup file-names."
  '((emacs  "27.1")
    (compat "30.1"))
  :url "https://github.com/meedstrom/truename-cache"
  :commit "db697cbc4a6a22c9762e387d1d362749bc4f32fd"
  :revdesc "db697cbc4a6a"
  :keywords '("lisp")
  :authors '(("Martin Edström" . "meedstrom91@gmail.com"))
  :maintainers '(("Martin Edström" . "meedstrom91@gmail.com")))
