;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flames-of-freedom" "20191202.1637"
  "The flames of freedom."
  '((emacs "25.1"))
  :url "https://github.com/wiz21b/FlamesOfFreedom"
  :commit "5e47ff27cfa2f7c06081be2ffefe91a731efd012"
  :revdesc "5e47ff27cfa2"
  :keywords '("multimedia")
  :authors '(("Stéphane Champailler" . "schampailler@skynet.be"))
  :maintainers '(("Stéphane Champailler" . "schampailler@skynet.be")))
