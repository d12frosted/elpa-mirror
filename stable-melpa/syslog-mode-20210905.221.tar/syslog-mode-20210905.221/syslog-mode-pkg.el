(define-package "syslog-mode" "20210905.221" "Major-mode for viewing log files & strace output"
  '((hide-lines "20130623")
    (ov "20150311")
    (hsluv "20181127"))
  :commit "7735c455eb6aa5a60a3dcd14705a7a923214b363" :authors
  '(("Harley Gorrell" . "harley@panix.com"))
  :maintainer
  '("Joe Bloggs" . "vapniks@yahoo.com")
  :keywords
  '("unix")
  :url "https://github.com/vapniks/syslog-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
