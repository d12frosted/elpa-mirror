(define-package "mono-complete" "20230403.7" "Completion suggestions with multiple back-ends"
  '((emacs "28.1"))
  :commit "9c437a43ca13536cf455d3d9ab43629c841e346b" :authors
  '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainer
  '("Campbell Barton" . "ideasman42@gmail.com")
  :url "https://codeberg.org/ideasman42/emacs-mono-complete")
;; Local Variables:
;; no-byte-compile: t
;; End:
