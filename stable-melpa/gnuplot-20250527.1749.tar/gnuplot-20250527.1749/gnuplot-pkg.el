;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "gnuplot" "20250527.1749"
  "Major-mode and interactive frontend for gnuplot."
  '((emacs "25.1"))
  :url "https://github.com/emacs-gnuplot/gnuplot"
  :commit "897c029b9855fe85a35e288179db2a4e41c557ae"
  :revdesc "897c029b9855"
  :keywords '("data" "gnuplot" "plotting")
  :maintainers '(("Maxime Tréca" . "maxime@gmail.com")
                 ("Daniel Mendler" . "mail@daniel-mendler.de")))
