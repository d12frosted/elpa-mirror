(define-package "mistty" "20231009.1257" "Shell/Comint alternative based on term.el"
  '((emacs "29.1"))
  :commit "4deadf61857ad01fd1cf1021fc9b01b3edd478a3" :authors
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainers
  '(("Stephane Zermatten" . "szermatt@gmx.net"))
  :maintainer
  '("Stephane Zermatten" . "szermatt@gmx.net")
  :keywords
  '("convenience" "unix")
  :url "http://github.com/szermatt/mistty")
;; Local Variables:
;; no-byte-compile: t
;; End:
