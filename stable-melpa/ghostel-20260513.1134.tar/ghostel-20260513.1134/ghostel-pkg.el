;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ghostel" "20260513.1134"
  "Terminal emulator powered by libghostty."
  '((emacs  "28.1")
    (compat "30.1.0.1"))
  :url "https://github.com/dakra/ghostel"
  :commit "69610433ca60ac1637fd92aa8297cec86cd429e4"
  :revdesc "69610433ca60"
  :keywords '("terminals")
  :authors '(("Daniel Kraus" . "daniel@kraus.my"))
  :maintainers '(("Daniel Kraus" . "daniel@kraus.my")))
