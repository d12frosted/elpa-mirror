(define-package "posframe" "20210616.1142" "Pop a posframe (just a frame) at point"
  '((emacs "26"))
  :commit "74f06b77deeb770cd0a96977b1e6bdedb682487a" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "tooltip")
  :url "https://github.com/tumashu/posframe")
;; Local Variables:
;; no-byte-compile: t
;; End:
