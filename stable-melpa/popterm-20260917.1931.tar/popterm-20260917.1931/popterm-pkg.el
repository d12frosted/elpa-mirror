;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "popterm" "20260917.1931"
  "Posframe terminal toggler with smart backends."
  '((emacs    "29.1")
    (posframe "1.4.0"))
  :url "https://github.com/ChetanKoneru/popterm.el"
  :commit "d086833f7762d7f9a96954451328ee9a57378b93"
  :revdesc "d086833f7762"
  :keywords '("terminals" "convenience" "tools")
  :authors '(("Chetan Koneru" . "kchetan.hadoop@gmail.com"))
  :maintainers '(("Chetan Koneru" . "kchetan.hadoop@gmail.com")))
