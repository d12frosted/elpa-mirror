;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "modus-themes" "20260314.857"
  "Elegant, highly legible and customizable themes."
  '((emacs "28.1"))
  :url "https://github.com/protesilaos/modus-themes"
  :commit "a4264088b7782e135d2a6210c932eb11cc5fbecd"
  :revdesc "a4264088b778"
  :keywords '("faces" "theme" "accessibility")
  :authors '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainers '(("Protesilaos Stavrou" . "info@protesilaos.com")))
