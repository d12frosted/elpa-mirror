(define-package "arxiv-mode" "20220128.920" "Read and search for articles on arXiv.org"
  '((emacs "27.1")
    (hydra "0"))
  :commit "f550583d2da8bd9600bd26bb4028fe22a9744da2" :authors
  '(("Alex Chen (fizban007)" . "fizban007@gmail.com")
    ("Simon Lin (Simon-Lin)" . "n.sibetz@gmail.com"))
  :maintainer
  '("Alex Chen (fizban007)" . "fizban007@gmail.com")
  :keywords
  '("bib" "convenience" "hypermedia")
  :url "https://github.com/fizban007/arxiv-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
