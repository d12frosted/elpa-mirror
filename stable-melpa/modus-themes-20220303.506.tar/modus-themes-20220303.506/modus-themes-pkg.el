(define-package "modus-themes" "20220303.506" "Highly accessible and customizable themes (WCAG AAA)"
  '((emacs "27.1"))
  :commit "f067d2ef39c22174b95584f2cba7942aaf03bcca" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
