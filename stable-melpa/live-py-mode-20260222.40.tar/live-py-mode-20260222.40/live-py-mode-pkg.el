;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "live-py-mode" "20260222.40"
  "Live Coding in Python."
  '((emacs "24.3"))
  :url "http://donkirkby.github.io/live-py-plugin/"
  :commit "e3d1436a7c279084587b40534f96cfd33aff25b4"
  :revdesc "e3d1436a7c27"
  :keywords '("live" "coding"))
