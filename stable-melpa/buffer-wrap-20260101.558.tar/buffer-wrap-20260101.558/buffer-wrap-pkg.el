;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-wrap" "20260101.558"
  "Wrap the beginning and the end of buffer."
  '((emacs "24.4"))
  :url "https://github.com/jcs-elpa/buffer-wrap"
  :commit "53a098384c17ae5140e525aeeeece3b14d35e12f"
  :revdesc "53a098384c17"
  :keywords '("convenience" "buffer" "tool" "wrap")
  :authors '(("Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainers '(("Jen-Chieh" . "jcs090218@gmail.com")))
