;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "oai" "20260430.229"
  "AI-LLM chat blocks for org-mode."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-oai"
  :commit "421189ec34293652ebe4a1e0f18441c84f79d0d3"
  :revdesc "421189ec3429"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
