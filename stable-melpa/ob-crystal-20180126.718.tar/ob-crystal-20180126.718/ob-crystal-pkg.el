;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ob-crystal" "20180126.718"
  "Org-babel functions for Crystal evaluation."
  '((emacs "24.3"))
  :url "https://github.com/brantou/ob-crystal"
  :commit "b3bb27a21a4cefef3f5aeef52718b694bd51245b"
  :revdesc "b3bb27a21a4c"
  :keywords '("crystal" "literate programming" "reproducible research")
  :authors '(("Brantou" . "brantou89@gmail.com"))
  :maintainers '(("Brantou" . "brantou89@gmail.com")))
