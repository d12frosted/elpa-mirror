(define-package "elgrep" "20230810.645" "Searching files for regular expressions"
  '((emacs "26.2")
    (async "1.5"))
  :commit "c006e2395ec38bbe5fa3e59613d21883a68ceaf1" :authors
  '(("Tobias Zawada" . "i@tn-home.de"))
  :maintainers
  '(("Tobias Zawada" . "i@tn-home.de"))
  :maintainer
  '("Tobias Zawada" . "i@tn-home.de")
  :keywords
  '("tools" "matching" "files" "unix")
  :url "https://github.com/TobiasZawada/elgrep")
;; Local Variables:
;; no-byte-compile: t
;; End:
