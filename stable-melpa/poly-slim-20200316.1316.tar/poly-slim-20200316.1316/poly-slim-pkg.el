;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "poly-slim" "20200316.1316"
  "Polymodes for slim."
  '((emacs     "25")
    (polymode  "0.2.2")
    (slim-mode "1.1"))
  :url "https://github.com/polymode/poly-slim"
  :commit "9e9b5164c68955974fd5f5d220aec5af9b5ba3ae"
  :revdesc "9e9b5164c689"
  :keywords '("emacs"))
