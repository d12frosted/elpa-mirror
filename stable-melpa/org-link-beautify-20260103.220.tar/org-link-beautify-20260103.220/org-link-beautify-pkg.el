;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-link-beautify" "20260103.220"
  "Beautify Org Links."
  '((emacs      "29.1")
    (nerd-icons "0.0.1")
    (qrencode   "1.3"))
  :url "https://repo.or.cz/org-link-beautify.git"
  :commit "0730668c8c559ced60693d1554597743c7afde68"
  :revdesc "0730668c8c55"
  :keywords '("hypermedia"))
