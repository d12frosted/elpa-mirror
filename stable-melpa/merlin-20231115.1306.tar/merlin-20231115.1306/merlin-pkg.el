(define-package "merlin" "20231115.1306" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "53eaad5df01bbdabc9e655dbadebc302d0475f31" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainers
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
