(define-package "osx-location" "20150613.917" "Watch and respond to changes in geographical location on OS X" 'nil :commit "110aee945b53ea550e4debe69bf3c077d940ec8c" :authors
  '(("Steve Purcell" . "steve@sanityinc.com"))
  :maintainer
  '("Steve Purcell" . "steve@sanityinc.com")
  :keywords
  '("convenience" "calendar")
  :url "https://github.com/purcell/osx-location")
;; Local Variables:
;; no-byte-compile: t
;; End:
