;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "moonbit-ts-mode" "20260907.325"
  "MoonBit tree-sitter major mode."
  '((emacs "31.1"))
  :url "https://github.com/moonbit-community/moonbit-ts-mode"
  :commit "15ab3f9f139fc370492ce8fc1b6d4658d61fc496"
  :revdesc "15ab3f9f139f"
  :keywords '("languages" "tree-sitter"))
