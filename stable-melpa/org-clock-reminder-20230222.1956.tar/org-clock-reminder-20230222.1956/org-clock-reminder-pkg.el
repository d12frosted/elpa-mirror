(define-package "org-clock-reminder" "20230222.1956" "Notifications that remind you about clocked-in tasks"
  '((emacs "26.1"))
  :commit "d3bf97113fd519aa08198e2283ba9c236a6df168" :authors
  '(("Nikolay Brovko" . "i@nickey.ru"))
  :maintainer
  '("Nikolay Brovko" . "i@nickey.ru")
  :keywords
  '("calendar" "convenience")
  :url "https://github.com/inickey/org-clock-reminder")
;; Local Variables:
;; no-byte-compile: t
;; End:
