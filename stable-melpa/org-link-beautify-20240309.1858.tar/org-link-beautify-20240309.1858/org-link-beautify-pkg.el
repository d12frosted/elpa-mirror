(define-package "org-link-beautify" "20240309.1858" "Beautify Org Links"
  '((emacs "28.1")
    (nerd-icons "0.0.1")
    (fb2-reader "0.1.1"))
  :commit "e3375927a9c6bad0d0801ed905a7bacc89839dee" :keywords
  '("hypermedia")
  :url "https://repo.or.cz/org-link-beautify.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
