;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ekg" "20261015.1310"
  "A system for recording and linking information."
  '((triples "0.6.1")
    (emacs   "28.1")
    (llm     "0.30.0")
    (vui     "1.0.0"))
  :url "https://github.com/ahyatt/ekg"
  :commit "7549000bc8733b8973d0accddb63cc4c79cc6297"
  :revdesc "7549000bc873"
  :keywords '("outlines" "hypermedia")
  :authors '(("Andrew Hyatt" . "ahyatt@gmail.com"))
  :maintainers '(("Andrew Hyatt" . "ahyatt@gmail.com")))
