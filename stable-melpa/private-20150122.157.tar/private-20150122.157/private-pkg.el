;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "private" "20150122.157"
  "Take care of your private configuration files."
  '((aes "0.6"))
  :url "https://github.com/cheunghy/private"
  :commit "f57f1c2f6bfe900bd40b252688df4c6ed6a5f44b"
  :revdesc "f57f1c2f6bfe"
  :keywords '("private" "configuration" "backup" "recover")
  :authors '(("Cheung Mou Wai" . "yeannylam@gmail.com"))
  :maintainers '(("Cheung Mou Wai" . "yeannylam@gmail.com")))
