(define-package "consult" "20221201.2210" "Consulting completing-read"
  '((emacs "27.1")
    (compat "28.1"))
  :commit "d948041c160bf30703c2e09cc9db415495b2206a" :authors
  '(("Daniel Mendler and Consult contributors"))
  :maintainer
  '("Daniel Mendler" . "mail@daniel-mendler.de")
  :url "https://github.com/minad/consult")
;; Local Variables:
;; no-byte-compile: t
;; End:
