(define-package "lister" "20220802.2128" "Yet another list printer"
  '((emacs "26.1"))
  :commit "f3e9748b3417184c36e301a381ec20ef4a88e511" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
