;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "doom-modeline" "20261117.623"
  "A minimal and modern mode-line."
  '((emacs       "25.1")
    (compat      "30.1.0.0")
    (nerd-icons  "0.1.0")
    (shrink-path "0.3.1"))
  :url "https://github.com/seagle0128/doom-modeline"
  :commit "3186c42e2942814efce5354eb9190f5801167637"
  :revdesc "3186c42e2942"
  :keywords '("faces" "mode-line")
  :authors '(("Vincent Zhang" . "seagle0128@gmail.com"))
  :maintainers '(("Vincent Zhang" . "seagle0128@gmail.com")))
