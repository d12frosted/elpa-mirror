;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "repeat-fu" "20260106.250"
  "Minor mode to repeat typing or commands."
  '((emacs "29.1"))
  :url "https://codeberg.org/ideasman42/emacs-repeat-fu"
  :commit "e5357f318eaeacbdd9cf57c2d8ac253f9ceeb6dd"
  :revdesc "e5357f318eae"
  :keywords '("convenience")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
