;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "promptu" "20260927.2015"
  "Compose LLM prompts from building blocks."
  '((emacs     "28.1")
    (transient "0.5.0"))
  :url "https://github.com/mrcnski/promptu.el"
  :commit "acc904a4b74bd4f28111757fc0bb7c9f54dde994"
  :revdesc "acc904a4b74b"
  :keywords '("convenience" "tools")
  :authors '(("Marcin Swieczkowski" . "marcin@realemail.net"))
  :maintainers '(("Marcin Swieczkowski" . "marcin@realemail.net")))
