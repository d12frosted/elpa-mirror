(define-package "k8s-mode" "20210413.1505" "Major mode for Kubernetes configuration file"
  '((emacs "24.3")
    (yaml-mode "0.0.10"))
  :commit "fa3181cbaef044e11c652a595c8528720db0fca6" :authors
  '(("Giap Tran" . "txgvnn@gmail.com"))
  :maintainer
  '("Giap Tran" . "txgvnn@gmail.com")
  :url "https://github.com/TxGVNN/emacs-k8s-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
