;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20260312.1353"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "d7825dcea9b7282675e27da8ad35ce07496961d1"
  :revdesc "d7825dcea9b7"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
