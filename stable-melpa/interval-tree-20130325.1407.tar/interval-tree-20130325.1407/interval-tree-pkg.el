;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "interval-tree" "20130325.1407"
  "Interval tree data structure for 1D range queries."
  '((dash "1.1.0"))
  :url "https://github.com/Fuco1/interval-tree"
  :commit "301302f480617091cf3ab6989caac385d52543dc"
  :revdesc "301302f48061"
  :keywords '("extensions" "data structure")
  :authors '(("Matus Goljer" . "matus.goljer@gmail.com"))
  :maintainers '(("Matus Goljer" . "matus.goljer@gmail.com")))
