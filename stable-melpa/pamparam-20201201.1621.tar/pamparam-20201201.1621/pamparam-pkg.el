(define-package "pamparam" "20201201.1621" "Simple and fast flashcards."
  '((emacs "24.3")
    (lispy "0.26.0")
    (worf "0.1.0")
    (hydra "0.13.4"))
  :commit "aab22e32fcdc8e83fecbe248bb35f4583739f955" :keywords
  ("outlines" "hypermedia" "flashcards" "memory")
  :authors
  (("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  ("Oleh Krehel" . "ohwoeowho@gmail.com")
  :url "https://github.com/abo-abo/pamparam")
;; Local Variables:
;; no-byte-compile: t
;; End:
