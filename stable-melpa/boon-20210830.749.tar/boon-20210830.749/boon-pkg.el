(define-package "boon" "20210830.749" "Ergonomic Command Mode for Emacs."
  '((emacs "26.1")
    (dash "2.12.0")
    (expand-region "0.10.0")
    (multiple-cursors "1.3.0"))
  :commit "d31550b3336d706b57df0e43bedf3e95a615ce0d")
;; Local Variables:
;; no-byte-compile: t
;; End:
