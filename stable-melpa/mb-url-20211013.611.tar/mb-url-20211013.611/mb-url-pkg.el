(define-package "mb-url" "20211013.611" "Multiple Backends for Emacs URL package"
  '((emacs "24.4"))
  :commit "f6b608db585231eee231d5473edcf4183bb678fe" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com")
  :keywords
  '("comm" "data" "processes" "hypermedia")
  :url "https://github.com/dochang/mb-url")
;; Local Variables:
;; no-byte-compile: t
;; End:
