(define-package "buttercup" "20220321.1903" "Behavior-Driven Emacs Lisp Testing"
  '((emacs "24.3"))
  :commit "c365dae776f823aa7489bcf0f750ca748fefdb28" :authors
  '(("Jorgen Schaefer" . "contact@jorgenschaefer.de"))
  :maintainer
  '("Ola Nilsson" . "ola.nilsson@gmail.com")
  :url "https://github.com/jorgenschaefer/emacs-buttercup")
;; Local Variables:
;; no-byte-compile: t
;; End:
