;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "keychain-environment" "20260728.1811"
  "Load keychain environment variables."
  ()
  :url "https://github.com/tarsius/keychain-environment"
  :commit "199f407f28f8f473790126a1149abba38e4b3164"
  :revdesc "199f407f28f8"
  :keywords '("gnupg" "pgp" "ssh")
  :authors '(("Paul Tipper" . "bluefooatgooglemaildotcom"))
  :maintainers '(("Jonas Bernoulli" . "jonas@bernoul.li")))
