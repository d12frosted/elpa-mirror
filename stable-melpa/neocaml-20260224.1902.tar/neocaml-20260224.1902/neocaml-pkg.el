;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260224.1902"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "410db808ad69516fd4314ea7ec6779eb9b6c6894"
  :revdesc "410db808ad69"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
