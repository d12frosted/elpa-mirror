;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "bookmarks-menu" "20250508.2114"
  "Add a Bookmarks menu to the menu bar."
  '((emacs "29.1"))
  :url "https://github.com/ajrosen/bookmarks-menu"
  :commit "e279bd3c27773e72b23eb698e9b1eed3f7d764c9"
  :revdesc "e279bd3c2777"
  :keywords '("matching" "convenience" "bookmark")
  :authors '(("Andy Rosen" . "ajr@corp.mlfs.org"))
  :maintainers '(("Andy Rosen" . "ajr@corp.mlfs.org")))
