;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "macher" "20260621.1"
  "LLM implementation toolset."
  '((emacs "30.1")
    (gptel "0.9.9.6"))
  :url "https://github.com/kmontag/macher"
  :commit "a4291dc930d2264878f2f73ccff3354964e5eed3"
  :revdesc "a4291dc930d2"
  :keywords '("convenience" "gptel" "llm"))
