;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "meep" "20251008.1123"
  "Lightweight modal editing."
  '((emacs "30.1"))
  :url "https://codeberg.org/ideasman42/emacs-meep"
  :commit "d455ee7b2466054b1249e951b733f0fd14820bb8"
  :revdesc "d455ee7b2466"
  :keywords '("convenience" "modal-editing")
  :authors '(("Campbell Barton" . "ideasman42@gmail.com"))
  :maintainers '(("Campbell Barton" . "ideasman42@gmail.com")))
