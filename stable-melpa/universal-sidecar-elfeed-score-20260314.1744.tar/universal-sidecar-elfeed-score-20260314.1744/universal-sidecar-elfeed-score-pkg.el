;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "universal-sidecar-elfeed-score" "20260314.1744"
  "Show Elfeed Score information in sidecar."
  '((emacs             "25.1")
    (universal-sidecar "1.0.0")
    (elfeed            "3.4.1")
    (elfeed-score      "1.2.6"))
  :url "https://git.sr.ht/~swflint/emacs-universal-sidecar"
  :commit "3b6bd928f7adb840e62a63dd5bf1236ece912b13"
  :revdesc "3b6bd928f7ad"
  :authors '(("Samuel W. Flint" . "me@samuelwflint.com"))
  :maintainers '(("Samuel W. Flint" . "me@samuelwflint.com")))
