(define-package "eide" "20211023.2001" "IDE interface" 'nil :commit "83ed534e78f5b9f4b32c0c8b3d636174afbdd5dd" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://eide.hjuvi.fr.eu.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
