(define-package "geiser-chicken" "20210405.1931" "Chicken's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.12"))
  :commit "47be5b43b35d3bf35b0f668b4c08715ea41fb97d" :authors
  '(("Daniel Leslie"))
  :maintainer
  '("Daniel Leslie")
  :keywords
  '("languages" "chicken" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/chicken")
;; Local Variables:
;; no-byte-compile: t
;; End:
