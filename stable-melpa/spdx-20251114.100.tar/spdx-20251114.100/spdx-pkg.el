;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "spdx" "20251114.100"
  "Insert SPDX license and copyright headers."
  '((emacs "24.4"))
  :url "https://github.com/condy0919/spdx.el"
  :commit "54fc564742911c8c1d1de684c5da3b85e07ea332"
  :revdesc "54fc56474291"
  :keywords '("license" "tools")
  :authors '(("Zhiwei Chen" . "condy0919@gmail.com"))
  :maintainers '(("Zhiwei Chen" . "condy0919@gmail.com")))
