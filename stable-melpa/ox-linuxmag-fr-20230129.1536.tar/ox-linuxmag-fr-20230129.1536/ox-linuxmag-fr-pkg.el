(define-package "ox-linuxmag-fr" "20230129.1536" "Org-mode exporter for the French GNU/Linux Magazine"
  '((emacs "28.1"))
  :commit "b879b80dd5b4d8b17e796e1e12cca5cca945d66b" :url "https://github.com/DamienCassou/ox-linuxmag-fr")
;; Local Variables:
;; no-byte-compile: t
;; End:
