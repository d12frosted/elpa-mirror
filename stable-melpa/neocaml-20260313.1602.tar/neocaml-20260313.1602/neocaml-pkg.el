;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "neocaml" "20260313.1602"
  "Major mode for OCaml code."
  '((emacs "29.1"))
  :url "https://github.com/bbatsov/neocaml"
  :commit "59814846c9c22759f7b2a2281f1d277f4cf42a9b"
  :revdesc "59814846c9c2"
  :keywords '("languages" "ocaml" "ml")
  :authors '(("Bozhidar Batsov" . "bozhidar@batsov.dev"))
  :maintainers '(("Bozhidar Batsov" . "bozhidar@batsov.dev")))
