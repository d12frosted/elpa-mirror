;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "cui" "20261025.1111"
  "Chat blocks in org-mode for LLM and agents."
  '((emacs "29.1"))
  :url "https://codeberg.org/Anoncheg/emacs-cui"
  :commit "d3d7711547b59b4c59731852850fb374960b3a22"
  :revdesc "d3d7711547b5"
  :keywords '("org" "comm" "url" "link")
  :authors '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg"))
  :maintainers '((nil . "github.com/Anoncheg1,codeberg.org/Anoncheg")))
