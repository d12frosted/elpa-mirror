(define-package "helm" "20240121.617" "Helm is an Emacs incremental and narrowing framework"
  '((helm-core "3.9.7")
    (wfnames "1.1")
    (popup "0.5.3"))
  :commit "1437c6d7ad0342881112a7d7dd88e76e3a68ec0e" :authors
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainers
  '(("Thierry Volpiatto" . "thievol@posteo.net"))
  :maintainer
  '("Thierry Volpiatto" . "thievol@posteo.net")
  :url "https://emacs-helm.github.io/helm/")
;; Local Variables:
;; no-byte-compile: t
;; End:
