(define-package "lister" "20210921.1947" "Yet another list printer"
  '((emacs "26.1"))
  :commit "4f84574f7ffd29f424e1c92754d61e71678cb9aa" :authors
  '((nil . "<joerg@joergvolbers.de>"))
  :maintainer
  '(nil . "<joerg@joergvolbers.de>")
  :keywords
  '("lisp")
  :url "https://github.com/publicimageltd/lister")
;; Local Variables:
;; no-byte-compile: t
;; End:
