(define-package "merlin" "20210401.1417" "Mode for Merlin, an assistant for OCaml." 'nil :commit "65debffc6ee30d18245c09a079303014c8128c34" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
