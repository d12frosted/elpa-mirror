;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ivy-hoogle" "20240102.908"
  "Search Hoogle using ivy."
  '((emacs "28.1")
    (async "1.9")
    (ivy   "0.13.2"))
  :url "https://github.com/aartamonau/ivy-hoogle"
  :commit "4b080018175b5770fd3571265bc846a4a845cdca"
  :revdesc "4b080018175b"
  :keywords '("matching" "haskell" "hoogle")
  :authors '(("Aliaksei Artamonau" . "aliaksiej.artamonau@gmail.com"))
  :maintainers '(("Aliaksei Artamonau" . "aliaksiej.artamonau@gmail.com")))
