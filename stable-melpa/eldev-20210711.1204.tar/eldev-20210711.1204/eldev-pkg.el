(define-package "eldev" "20210711.1204" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "f9d034ff330d657fa3cbbb1df3a582cd417da78a" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
