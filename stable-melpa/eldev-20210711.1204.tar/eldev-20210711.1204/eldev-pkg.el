(define-package "eldev" "20210711.1204" "Elisp Development Tool"
  '((emacs "24.4"))
  :commit "b7b5c6d7a9cf9f3fcbe57d4c2f91471b1139cc9f" :authors
  '(("Paul Pogonyshev" . "pogonyshev@gmail.com"))
  :maintainer
  '("Paul Pogonyshev" . "pogonyshev@gmail.com")
  :keywords
  '("maint" "tools")
  :url "https://github.com/doublep/eldev")
;; Local Variables:
;; no-byte-compile: t
;; End:
