(define-package "merlin" "20220328.1348" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "ebd07f4a039a62dcf673d02d20b294bb63fb48b6" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
