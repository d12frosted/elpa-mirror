(define-package "merlin" "20220328.1348" "Mode for Merlin, an assistant for OCaml"
  '((emacs "25.1"))
  :commit "68b75e0df2979a6fc0979b1acbbbf99d1687eb41" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
