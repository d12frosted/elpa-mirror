(define-package "good-scroll" "20210521.742" "Good pixel line scrolling"
  '((emacs "27.1"))
  :commit "5792cd778b37c714e3a418bc1dfc420bd0e7e731" :authors
  '(("Benjamin Levy" . "blevy@protonmail.com"))
  :maintainer
  '("Benjamin Levy" . "blevy@protonmail.com")
  :url "https://github.com/io12/good-scroll.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
