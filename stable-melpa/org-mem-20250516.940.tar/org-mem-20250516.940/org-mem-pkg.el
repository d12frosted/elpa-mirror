;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "org-mem" "20250516.940"
  "Fast info from a large number of Org file contents."
  '((emacs  "29.1")
    (el-job "2.4.2")
    (llama  "0.5.0"))
  :url "https://github.com/meedstrom/org-mem"
  :commit "deb07f53a1cefa486b65399551bcd97e9f4cd577"
  :revdesc "deb07f53a1ce"
  :keywords '("text")
  :authors '(("Martin Edström" . "meedstrom@runbox.eu"))
  :maintainers '(("Martin Edström" . "meedstrom@runbox.eu")))
