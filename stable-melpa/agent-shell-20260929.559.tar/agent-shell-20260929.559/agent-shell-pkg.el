;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "agent-shell" "20260929.559"
  "Native agentic integrations for Claude Code, Gemini CLI, etc."
  '((emacs       "29.1")
    (shell-maker "0.97.4")
    (acp         "0.15.1"))
  :url "https://github.com/xenodium/agent-shell"
  :commit "fc19d4ef2099e9684e7a08c851706586aef805a0"
  :revdesc "fc19d4ef2099")
