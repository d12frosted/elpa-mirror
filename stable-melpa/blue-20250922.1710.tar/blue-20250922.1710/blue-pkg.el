;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "blue" "20250922.1710"
  "BLUE build system interface."
  '((emacs "30.1"))
  :url "https://codeberg.org/lapislazuli/blue.el"
  :commit "48495be94b6db7c85207493a80e0b9113fcc5fd3"
  :revdesc "48495be94b6d"
  :keywords '("blue" "tools")
  :authors '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com"))
  :maintainers '(("Sergio Pastor Pérez" . "sergio.pastorperez@gmail.com")))
