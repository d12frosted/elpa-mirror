;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "youtube-music" "20260923.1109"
  "YouTube Music client."
  '((emacs "29.1"))
  :url "https://github.com/cyberkm/emacs-youtube-music"
  :commit "d13cf01d58f6c399a7217f708c84d741f8cd4f63"
  :revdesc "d13cf01d58f6"
  :keywords '("multimedia" "youtube" "music")
  :authors '(("Pavel Bibergal" . "pavel@keewano.com"))
  :maintainers '(("Pavel Bibergal" . "pavel@keewano.com")))
