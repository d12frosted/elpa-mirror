(define-package "media-progress" "20230701.911" "Display position where media player stopped"
  '((emacs "28.1"))
  :commit "a9137d64bb6a786d6a50523237b9d9cc53ffed57" :authors
  '(("Dmitriy Pshonko <http://github.com/jumper047>"))
  :maintainers
  '(("Dmitriy Pshonko <http://github.com/jumper047>"))
  :maintainer
  '("Dmitriy Pshonko <http://github.com/jumper047>")
  :keywords
  '("files" "convenience")
  :url "https://github.com/jumper047/media-progress")
;; Local Variables:
;; no-byte-compile: t
;; End:
