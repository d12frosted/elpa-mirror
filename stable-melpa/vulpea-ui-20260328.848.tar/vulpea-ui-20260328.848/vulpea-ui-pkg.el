;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "vulpea-ui" "20260328.848"
  "Sidebar infrastructure and widget framework for vulpea notes."
  '((emacs  "29.1")
    (vulpea "2.0.0")
    (vui    "0.1"))
  :url "https://github.com/d12frosted/vulpea-ui"
  :commit "cb06e5b4bfa6d420d7608fa70f6fa12d705ddbfa"
  :revdesc "cb06e5b4bfa6"
  :keywords '("outlines" "hypermedia")
  :authors '(("Boris Buliga" . "boris@d12frosted.io"))
  :maintainers '(("Boris Buliga" . "boris@d12frosted.io")))
