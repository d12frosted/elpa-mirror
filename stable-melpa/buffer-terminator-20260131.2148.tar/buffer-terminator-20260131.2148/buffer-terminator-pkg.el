;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "buffer-terminator" "20260131.2148"
  "Safely Terminate/Kill Buffers Automatically."
  '((emacs "25.1"))
  :url "https://github.com/jamescherti/buffer-terminator.el"
  :commit "5771d1c31529d7845ad03e03aef84c98a241596b"
  :revdesc "5771d1c31529"
  :keywords '("convenience"))
