;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "transient" "20260924.935"
  "Transient commands."
  '((emacs    "28.1")
    (compat   "31.0")
    (cond-let "1.1")
    (llama    "1.0")
    (seq      "2.24"))
  :url "https://github.com/magit/transient"
  :commit "d1ab36958ddfd6c85aab00dbc130cd3e1a97615f"
  :revdesc "d1ab36958ddf"
  :keywords '("extensions")
  :authors '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev"))
  :maintainers '(("Jonas Bernoulli" . "emacs.transient@jonas.bernoulli.dev")))
