(define-package "lesim-mode" "20230604.1826" "Major mode for Learning Simulator scripts"
  '((emacs "28.1"))
  :commit "236c7d2ee726fc1ddb61ee0dd136d9a3c879a785" :authors
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainers
  '(("Stefano Ghirlanda" . "drghirlanda@gmail.com"))
  :maintainer
  '("Stefano Ghirlanda" . "drghirlanda@gmail.com")
  :keywords
  '("languages" "faces")
  :url "https://github.com/drghirlanda/lesim-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
