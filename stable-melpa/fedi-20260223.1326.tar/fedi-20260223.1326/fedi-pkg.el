;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "fedi" "20260223.1326"
  "Helper functions for fediverse clients."
  '((emacs         "28.1")
    (markdown-mode "2.5"))
  :url "https://codeberg.org/martianh/fedi.el"
  :commit "74fab520f1d008f5a389a673616a617c03c74600"
  :revdesc "74fab520f1d0"
  :authors '(("Marty Hiatt" . "mousebot@disroot.org"))
  :maintainers '(("Marty Hiatt" . "mousebot@disroot.org")))
