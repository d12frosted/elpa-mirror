(define-package "rust-mode" "20240228.205" "A major-mode for editing Rust source code"
  '((emacs "25.1"))
  :commit "73e6e4ef891affba87d08021cbc25cdc084ce290" :authors
  '(("Mozilla"))
  :maintainers
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages")
  :url "https://github.com/rust-lang/rust-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
