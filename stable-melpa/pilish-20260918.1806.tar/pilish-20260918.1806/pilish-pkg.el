;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pilish" "20260918.1806"
  "Emacs frontend for pi coding agent."
  '((emacs               "29.1")
    (transient           "0.9.0")
    (magit-section       "4.0.0")
    (md-ts-mode          "0.4.0")
    (markdown-table-wrap "0.2.0"))
  :url "https://github.com/dnouri/pilish"
  :commit "0540bf2e05043350e6f2d9b6e5dd70c2b287c4dd"
  :revdesc "0540bf2e0504"
  :keywords '("ai" "llm" "ai-pair-programming" "tools")
  :authors '(("Daniel Nouri" . "daniel.nouri@gmail.com"))
  :maintainers '(("Daniel Nouri" . "daniel.nouri@gmail.com")))
