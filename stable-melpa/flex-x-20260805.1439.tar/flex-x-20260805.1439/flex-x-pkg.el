;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "flex-x" "20260805.1439"
  "Extended flex completion style."
  '((emacs "30.1"))
  :url "https://github.com/kn66/flex-x"
  :commit "dc8e7949663cc5892a8f3736a98a5f96d0f89e5c"
  :revdesc "dc8e7949663c"
  :keywords '("convenience" "matching")
  :authors '(("kn66" . "https://github.com/kn66"))
  :maintainers '(("kn66" . "https://github.com/kn66")))
