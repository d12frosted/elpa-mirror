;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "ollama-buddy" "20250310.1110"
  "Ollama Buddy: Your Friendly AI Assistant."
  '((emacs "26.1"))
  :url "https://github.com/captainflasmr/ollama-buddy"
  :commit "20489d2a356f27910e5da8732bbd03a3b0204190"
  :revdesc "20489d2a356f"
  :keywords '("applications" "tools" "convenience")
  :authors '(("James Dyer" . "captainflasmr@gmail.com"))
  :maintainers '(("James Dyer" . "captainflasmr@gmail.com")))
