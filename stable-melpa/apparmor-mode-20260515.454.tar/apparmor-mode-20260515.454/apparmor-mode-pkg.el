;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "apparmor-mode" "20260515.454"
  "Major mode for editing AppArmor policy files."
  '((emacs "26.1"))
  :url "https://gitlab.com/apparmor/apparmor-mode"
  :commit "b0e4bbcd30aafd71f484c74164351af40ef885bf"
  :revdesc "b0e4bbcd30aa"
  :authors '(("Alex Murray" . "murray.alex@gmail.com"))
  :maintainers '(("Alex Murray" . "murray.alex@gmail.com")))
