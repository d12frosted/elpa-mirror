(define-package "llama" "20230831.2227" "Compact syntax for short lambda"
  '((seq "2.23"))
  :commit "a938ac0ae7890cfaf3281beb13f5c2fa75b337fa" :keywords
  '("extensions")
  :url "https://git.sr.ht/~tarsius/llama")
;; Local Variables:
;; no-byte-compile: t
;; End:
