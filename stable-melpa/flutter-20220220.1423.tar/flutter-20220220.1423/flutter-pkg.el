(define-package "flutter" "20220220.1423" "Tools for working with Flutter SDK"
  '((emacs "24.4"))
  :commit "08138f8c95488aaf315a1f5d52c33deb8d28672b" :authors
  '(("Aaron Madlon-Kay"))
  :maintainer
  '("Aaron Madlon-Kay")
  :keywords
  '("languages")
  :url "https://github.com/amake/flutter.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
