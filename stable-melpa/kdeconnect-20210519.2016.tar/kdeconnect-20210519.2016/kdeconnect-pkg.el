(define-package "kdeconnect" "20210519.2016" "An interface for KDE Connect" 'nil :commit "4977af8cb5fdc21da770f3ee43ad7823f2937da3" :authors
  '(("Carl Lieberman" . "dev@carl.ac"))
  :maintainers
  '(("Carl Lieberman" . "dev@carl.ac"))
  :maintainer
  '("Carl Lieberman" . "dev@carl.ac")
  :keywords
  '("kdeconnect" "android"))
;; Local Variables:
;; no-byte-compile: t
;; End:
