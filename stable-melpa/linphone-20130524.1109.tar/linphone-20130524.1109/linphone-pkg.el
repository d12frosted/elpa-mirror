;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "linphone" "20130524.1109"
  "Emacs interface to Linphone."
  ()
  :url "https://github.com/zabbal/emacs-linphone"
  :commit "99af3db941b7f4e5272bb48bff96c1ce4ceac302"
  :revdesc "99af3db941b7"
  :keywords '("comm")
  :authors '(("Yoni Rabkin" . "yonirabkin@member.fsf.org"))
  :maintainers '(("Yoni Rabkin" . "yonirabkin@member.fsf.org")))
