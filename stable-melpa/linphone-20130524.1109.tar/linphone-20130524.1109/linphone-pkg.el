(define-package "linphone" "20130524.1109" "Emacs interface to Linphone" 'nil :commit "99af3db941b7f4e5272bb48bff96c1ce4ceac302" :keywords
  ("comm")
  :authors
  (("Yoni Rabkin" . "yonirabkin@member.fsf.org"))
  :maintainer
  ("Yoni Rabkin" . "yonirabkin@member.fsf.org")
  :url "https://github.com/zabbal/emacs-linphone")
;; Local Variables:
;; no-byte-compile: t
;; End:
