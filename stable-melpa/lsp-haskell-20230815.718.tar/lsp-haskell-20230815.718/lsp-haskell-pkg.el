(define-package "lsp-haskell" "20230815.718" "Haskell support for lsp-mode"
  '((emacs "27.1")
    (lsp-mode "3.0")
    (haskell-mode "16.1"))
  :commit "70ed6529ddfbf6e650f7c297090d60fc91d28c63" :keywords
  '("haskell")
  :url "https://github.com/emacs-lsp/lsp-haskell")
;; Local Variables:
;; no-byte-compile: t
;; End:
