(define-package "modus-themes" "20221229.1247" "Elegant, highly legible and customizable themes"
  '((emacs "27.1"))
  :commit "93401ca2c88d1199ac61c74c35d8e2243f6ae18f" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Modus-Themes Development" . "~protesilaos/modus-themes@lists.sr.ht")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://git.sr.ht/~protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
