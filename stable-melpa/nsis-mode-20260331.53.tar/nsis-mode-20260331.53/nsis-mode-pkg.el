;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "nsis-mode" "20260331.53"
  "NSIS-mode."
  ()
  :url "https://github.com/mlf176f2/nsis-mode"
  :commit "0e1ec26a3943865f33e5590e26f5bc31684ad67e"
  :revdesc "0e1ec26a3943"
  :keywords '("nsis"))
