;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "compile-angel" "20260224.27"
  "Automatically Compile Elisp files (auto-compile alternative)."
  '((emacs "26.3"))
  :url "https://github.com/jamescherti/compile-angel.el"
  :commit "4d9d1db237189720eb72aff24c05ba18ebe06423"
  :revdesc "4d9d1db23718"
  :keywords '("convenience")
  :authors '(("James Cherti" . "https://www.jamescherti.com/contact/"))
  :maintainers '(("James Cherti" . "https://www.jamescherti.com/contact/")))
