;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260503.2328"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "eb0bff6637b2ecd82dde8f6fad6c91308a826947"
  :revdesc "eb0bff6637b2"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "eternalmangocean@gmail.com"))
  :maintainers '(("Geralld Borbón" . "eternalmangocean@gmail.com")))
