;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "guava-themes" "20260616.1531"
  "A pack of plant-inspired themes."
  '((emacs "24.1"))
  :url "https://github.com/bormoge/guava-themes"
  :commit "41ff3477fce70a4a3bc41d592afb04445c9d0903"
  :revdesc "41ff3477fce7"
  :keywords '("themes" "faces" "color")
  :authors '(("Geralld Borbón" . "geralldborbon@gmail.com"))
  :maintainers '(("Geralld Borbón" . "geralldborbon@gmail.com")))
