;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "hyperbole" "20250607.700"
  "GNU Hyperbole: The Everyday Hypertextual Information Manager."
  '((emacs "28"))
  :url "http://www.gnu.org/software/hyperbole"
  :commit "db9f64b3489543b7d16ec930f69c9db34e5b70ae"
  :revdesc "db9f64b34895"
  :keywords '("comm" "convenience" "files" "frames" "hypermedia" "languages" "mail" "matching" "mouse" "multimedia" "outlines" "tools" "wp")
  :authors '(("Robert Weiner" . "rsw@gnu.org"))
  :maintainers '(("Robert Weiner" . "rsw@gnu.org")))
