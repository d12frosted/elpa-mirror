;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "pinyin-isearch" "20260221.1837"
  "Pinyin mode for isearch."
  '((emacs "28.1"))
  :url "https://github.com/Anoncheg1/pinyin-isearch"
  :commit "5dc9114d4f1844005f83a4895808318dd5114e9d"
  :revdesc "5dc9114d4f18"
  :keywords '("chinese" "pinyin" "matching" "convenience"))
