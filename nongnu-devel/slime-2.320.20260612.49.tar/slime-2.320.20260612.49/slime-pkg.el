;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.320.20260612.49" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "b38be925a128dc3d6524121692988cb900fbcbf8" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
