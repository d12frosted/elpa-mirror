;; Generated package description from web-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "web-mode" "17.3.25.0.20260831.3" "major mode for editing web templates" '((emacs "24.3.1")) :commit "ce24723eb900c455b488d224910519bd36af580a" :maintainer '("François-Xavier Bois" . "fxbois@gmail.com") :keywords '("languages") :url "https://web-mode.org")
