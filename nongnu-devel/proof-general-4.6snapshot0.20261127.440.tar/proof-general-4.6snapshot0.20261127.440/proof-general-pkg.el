;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261127.440" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "f15e4bf82c596268949f0da16530f031edcefa0e" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
