;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.16.1.0.20261127.20" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "abcc79836e1389708ee2772f18d38b1a60d0a122" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy")
