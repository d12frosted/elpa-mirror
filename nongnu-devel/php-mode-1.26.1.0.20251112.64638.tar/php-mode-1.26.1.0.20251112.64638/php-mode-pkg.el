;; Generated package description from php-mode.el  -*- no-byte-compile: t -*-
(define-package "php-mode" "1.26.1.0.20251112.64638" "Major mode for editing PHP code" '((emacs "27.1")) :commit "d9858333e42f42c1486a84bc5277e9d8e37e40cc" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
