;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.1.0.20260618.1" "A major mode for editing subtitles" '((emacs "25.1")) :commit "e5df568e5979d51b43cc86e478bb8b32a4c0d717" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
