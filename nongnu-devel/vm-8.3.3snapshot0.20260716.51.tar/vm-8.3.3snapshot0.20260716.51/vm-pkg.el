;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "8.3.3snapshot0.20260716.51" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "4de80ac0a1687f0db29a65a049f5bcd702a19109" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
