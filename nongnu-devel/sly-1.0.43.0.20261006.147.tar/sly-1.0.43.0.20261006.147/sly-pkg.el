;; Generated package description from sly.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sly" "1.0.43.0.20261006.147" "Sylvester the Cat's Common Lisp IDE" '((emacs "24.5")) :commit "191fe38eaa83e4e7556a940aa4b234666215cced" :keywords '("languages" "lisp" "sly") :url "https://github.com/joaotavora/sly")
