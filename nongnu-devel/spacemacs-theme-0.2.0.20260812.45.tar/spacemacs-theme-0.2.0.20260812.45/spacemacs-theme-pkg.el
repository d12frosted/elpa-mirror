;; Generated package description from spacemacs-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "spacemacs-theme" "0.2.0.20260812.45" "Color theme with a dark and light versions." '((emacs "24")) :commit "c1617a86bc18ae611b0c0cf1d51e5906a2676c6b" :keywords '("color" "theme") :url "https://github.com/nashamri/spacemacs-theme")
