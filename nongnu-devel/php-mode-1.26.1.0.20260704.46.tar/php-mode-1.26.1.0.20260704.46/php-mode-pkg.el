;; Generated package description from php-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.26.1.0.20260704.46" "Major mode for editing PHP code" '((emacs "27.1")) :commit "e175393855bba23865d81c4a4d380b54c4506196" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
