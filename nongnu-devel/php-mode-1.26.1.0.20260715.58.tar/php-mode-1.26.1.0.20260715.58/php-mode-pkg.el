;; Generated package description from php-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.26.1.0.20260715.58" "Major mode for editing PHP code" '((emacs "27.1")) :commit "101b3b5cad0d783a91ffc58e0e43115d06d11034" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
