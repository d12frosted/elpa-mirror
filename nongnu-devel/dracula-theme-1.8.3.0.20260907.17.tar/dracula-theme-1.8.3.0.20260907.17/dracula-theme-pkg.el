;; Generated package description from dracula-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "dracula-theme" "1.8.3.0.20260907.17" "Dracula Theme" '((emacs "24.3")) :commit "538b8d20c667ac4b0c43ed1a5ef50760fb4ad754" :maintainer '("tienne Deparis" . "etienne@depar.is") :url "https://github.com/dracula/emacs")
