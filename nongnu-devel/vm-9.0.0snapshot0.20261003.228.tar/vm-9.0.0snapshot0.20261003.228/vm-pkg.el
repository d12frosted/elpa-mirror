;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.0snapshot0.20261003.228" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "6e67a14aee0070561f99b2ecbcb306ed8b5b866f" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
