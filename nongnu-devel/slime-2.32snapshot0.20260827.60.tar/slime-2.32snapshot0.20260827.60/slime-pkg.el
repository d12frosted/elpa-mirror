;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260827.60" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "d93a570f57600611d534893fa381d0cf10b85e23" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
