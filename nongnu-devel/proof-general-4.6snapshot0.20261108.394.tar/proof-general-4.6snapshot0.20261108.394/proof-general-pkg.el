;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261108.394" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "20de568be368eef29e97635a31f383eeadcc4c31" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
