;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261106.389" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "7922429acd7b46e237873f26533a20f67490ad3f" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
