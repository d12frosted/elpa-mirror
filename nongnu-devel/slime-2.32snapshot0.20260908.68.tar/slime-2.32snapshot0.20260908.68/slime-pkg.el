;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260908.68" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "1a1e0e3a5e5600138d9205291e2d9befdb269bea" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
