;; Generated package description from php-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.26.1.0.20260709.53" "Major mode for editing PHP code" '((emacs "27.1")) :commit "86e788eeeab57e0576fad9ec9ea1fab0c236efb7" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
