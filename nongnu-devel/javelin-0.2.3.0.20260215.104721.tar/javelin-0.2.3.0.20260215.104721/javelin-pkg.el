;; Generated package description from javelin.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "javelin" "0.2.3.0.20260215.104721" "Implementation of harpoon: bookmarks on steroids" '((emacs "28.1")) :commit "e2f1ccad5a7ad0dd38f62773723353081d57bae8" :keywords '("tools" "languages") :url "https://github.com/DamianB-BitFlipper/javelin.el")
