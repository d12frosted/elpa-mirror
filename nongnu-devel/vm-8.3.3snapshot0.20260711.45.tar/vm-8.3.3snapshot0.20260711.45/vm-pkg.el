;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "8.3.3snapshot0.20260711.45" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "64bdc613196565776a47e181f89e88533132b023" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
