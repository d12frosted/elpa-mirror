;; Generated package description from haskell-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "haskell-mode" "17.5.0.20260619.67" "A Haskell editing mode" '((emacs "25.1")) :commit "781e4669a0e0917fa8c532371cbfb1eb5b03b645" :keywords '("haskell" "cabal" "ghc" "repl" "languages") :url "https://github.com/haskell/haskell-mode")
