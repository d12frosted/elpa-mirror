;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261105.48" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "82673f4684c1321995b20432dab818fd70dd7754" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
