;; Generated package description from meow.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "meow" "1.5.0.0.20260714.67" "Yet Another modal editing" '((emacs "27.1")) :commit "aa8aec19e70369b547176e625f5b95c4a8565e8e" :keywords '("convenience" "modal-editing") :url "https://www.github.com/DogLooksGood/meow")
