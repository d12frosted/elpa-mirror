;; Generated package description from haskell-tng-mode.el  -*- no-byte-compile: t -*-
(define-package "haskell-tng-mode" "0.0.1.0.20230522.221126" "Major mode for editing Haskell" '((emacs "27.1") (popup "0.5.3")) :commit "9f63505d5c27312157e362404f5b922d0211be18" :keywords '("languages") :url "https://gitlab.com/tseenshe/haskell-tng-mode")
