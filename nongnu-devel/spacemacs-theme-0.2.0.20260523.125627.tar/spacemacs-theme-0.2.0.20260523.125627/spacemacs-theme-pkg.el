;; Generated package description from spacemacs-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "spacemacs-theme" "0.2.0.20260523.125627" "Color theme with a dark and light versions." '((emacs "24")) :commit "cbd290dfde96f53a7b41730c7840850a8a7b8a02" :keywords '("color" "theme") :url "https://github.com/nashamri/spacemacs-theme")
