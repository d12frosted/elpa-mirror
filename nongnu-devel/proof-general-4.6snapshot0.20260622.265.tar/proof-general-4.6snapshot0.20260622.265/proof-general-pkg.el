;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20260622.265" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "38e3f59d4b650fbfb9649c84f24adbc9056ffa30" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
