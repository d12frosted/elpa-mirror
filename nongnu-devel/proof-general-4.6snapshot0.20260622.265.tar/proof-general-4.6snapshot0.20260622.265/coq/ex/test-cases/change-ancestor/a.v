
Definition a := 0.

