;; Generated package description from org-journal.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "org-journal" "2.2.0.0.20260413.140147" "a simple org-mode based journaling mode" '((emacs "26.1") (org "9.1")) :commit "6460f6f2b0835b4b8aa87d5fdf40cac7deb319f5" :url "http://github.com/bastibe/org-journal")
