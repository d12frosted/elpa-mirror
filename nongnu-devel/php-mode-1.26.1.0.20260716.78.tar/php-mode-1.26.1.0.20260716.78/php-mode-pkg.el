;; Generated package description from php-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.26.1.0.20260716.78" "Major mode for editing PHP code" '((emacs "27.1")) :commit "5c4ebd83871fcff28f9019d5e4309f61241e19e7" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
