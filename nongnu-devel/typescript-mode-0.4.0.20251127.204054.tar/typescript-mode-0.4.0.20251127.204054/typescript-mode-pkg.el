;; Generated package description from typescript-mode.el  -*- no-byte-compile: t -*-
(define-package "typescript-mode" "0.4.0.20251127.204054" "Major mode for editing typescript" '((emacs "24.3")) :commit "2535780bdb318d86761b9bd21b0347ca6a89628f" :keywords '("typescript" "languages") :url "http://github.com/ananthakumaran/typescript.el")
