;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261014.77" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "579d609ecb3e4df695f2c45c9ab47229bab13a2e" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
