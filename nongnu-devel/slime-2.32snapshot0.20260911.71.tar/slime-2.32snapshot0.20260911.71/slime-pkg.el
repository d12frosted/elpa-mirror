;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260911.71" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "b7c25d3cf9d29f9babd0431de00e44ad744a81fd" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
