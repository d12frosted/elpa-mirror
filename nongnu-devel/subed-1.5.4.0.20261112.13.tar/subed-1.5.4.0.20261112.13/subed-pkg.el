;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.4.0.20261112.13" "A major mode for editing subtitles" '((emacs "25.1")) :commit "6752329239d01ccf6ad62546f8bddc6884eb5208" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
