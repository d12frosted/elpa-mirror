;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260719.53" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "055c1c98c2b7791162b0e8c994051a7d72208dc1" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
