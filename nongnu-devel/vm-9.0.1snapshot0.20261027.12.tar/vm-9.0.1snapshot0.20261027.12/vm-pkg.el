;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261027.12" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "a594a7f25d09e55718280a492f439733ba587804" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
