;; Generated package description from pacmacs.el  -*- no-byte-compile: t -*-
(define-package "pacmacs" "0.1.1.0.20220411.143014" "Pacman for Emacs" '((emacs "24.4") (dash "2.18.0")) :commit "071d008ebd734f469b87597cbdd34139a92e5308" :authors '(("Codingteam" . "codingteam@conference.jabber.ru")) :maintainer '("Alexey Kutepov" . "reximkut@gmail.com") :url "http://github.com/codingteam/pacmacs.el")
