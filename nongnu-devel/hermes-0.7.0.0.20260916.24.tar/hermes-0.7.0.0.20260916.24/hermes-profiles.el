;;; hermes-profiles.el --- Profile browser for Hermes  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Thanos Apollo

;; Author: Thanos Apollo <public@thanosapollo.org>
;; Assisted-by: Hermes:MoA
;; Keywords: tools, convenience

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; A `tabulated-list' browser over the dashboard REST `/api/profiles':
;; every profile with its configured model and provider.  Profiles can be
;; created, renamed, and deleted through the dashboard REST API; the built-in
;; default profile is protected.  `m' picks a new model from the shared
;; `model.options' catalog and persists it into that profile's own config.yaml
;; via `PUT /api/profiles/{name}/model'.  The Reasoning column is display-only
;; for now: the dashboard exposes no
;; per-profile reasoning read or write route yet; wire it up when
;; hermes-agent grows `GET/PUT /api/profiles/{name}/reasoning'.

;;; Code:

(require 'hermes-buffer)
(require 'seq)
(require 'tabulated-list)
(require 'url-util)
(require 'markdown-mode)
(require 'hermes-transport)
(require 'hermes-promise)
(require 'hermes-dashboard-transport)
(require 'hermes-dashboard-rpc)
(require 'hermes-browser)
(require 'hermes-chat)

(defun hermes-profiles--field (profile key)
  "Return PROFILE's KEY as a string, or nil."
  (hermes-transport--scalar-string (hermes-transport--get profile key)))

(defun hermes-profiles--row (profile)
  "Return one `tabulated-list' entry for PROFILE."
  (let ((name (or (hermes-profiles--field profile 'name) "")))
    (list name
          (vector (hermes-browser--face-cell name 'hermes-browser-profile)
                  (hermes-browser--face-cell
                   (if (eq (hermes-transport--get profile 'is_default) t)
                       "*"
                     "")
                   'hermes-browser-default)
                  (hermes-browser--face-cell
                   (or (hermes-profiles--field profile 'model) "")
                   'hermes-browser-model)
                  (hermes-browser--face-cell
                   (or (hermes-profiles--field profile 'provider) "")
                   'hermes-browser-provider)
                  ;; No per-profile reasoning surface in the dashboard yet.
                  (hermes-browser--face-cell "—" 'hermes-browser-reasoning)
                  (hermes-browser--face-cell
                   (or (hermes-profiles--field profile 'description) "")
                   'hermes-browser-description)))))

(defun hermes-profiles--rows (result)
  "Return `tabulated-list' entries for an `/api/profiles' RESULT."
  (mapcar #'hermes-profiles--row
          (hermes-transport--get result 'profiles)))

(defun hermes-profiles--read-model-candidate (catalog)
  "Prompt for a provider-qualified model from `model.options' CATALOG.
Only candidates that carry a provider slug are offered: the profile model
route requires both fields."
  (let* ((candidates (seq-filter
                      (lambda (candidate)
                        (hermes-transport--non-empty-string
                         (plist-get (cdr candidate) :provider)))
                      (hermes-chat--model-candidates catalog)))
         (choice (completing-read "Profile model: "
                                  (mapcar #'car candidates) nil t)))
    (or (cdr (assoc choice candidates))
        (user-error "No model selected"))))

(defun hermes-profiles--put-model (client name candidate &optional current-p)
  "Set profile NAME's model to CANDIDATE via CLIENT under CURRENT-P."
  (hermes-dashboard-transport-api-request-async
   "PUT" (format "/api/profiles/%s/model" (url-hexify-string name))
   :body `((provider . ,(plist-get candidate :provider))
           (model . ,(plist-get candidate :model)))
   :client client :current-p current-p))

(defun hermes-profiles--api (client method path &optional body)
  "Return a profile REST METHOD PATH promise through CLIENT with BODY."
  (hermes-dashboard-transport-api-request-async
   method (concat "/api/profiles" path) :body body :client client))

(defun hermes-profiles--refresh-after-mutation (origin message)
  "Refresh live profile ORIGIN after reporting MESSAGE."
  (message "Hermes: %s" message)
  (when (hermes-browser--buffer-mode-p origin 'hermes-profiles-mode)
    (with-current-buffer origin (hermes-profiles--revert))))

(defun hermes-profiles--ensure-non-default (name action)
  "Refuse ACTION when profile NAME denotes the built-in default profile."
  (when (string-equal-ignore-case name "default")
    (user-error "Cannot %s the default profile" action)))

(defun hermes-profiles--read-create-arguments ()
  "Read a new profile name and optional clone source."
  (let* ((profiles (mapcar #'car tabulated-list-entries))
         (name (read-string "New profile name: "))
         (clone-from (completing-read "Clone profile (empty for none): "
                                      profiles nil nil)))
    (list name (unless (string-empty-p clone-from) clone-from))))

(defun hermes-profiles-create (name &optional clone-from)
  "Create profile NAME, optionally cloning identity from CLONE-FROM."
  (interactive
   (hermes-browser--read-owned-arguments #'hermes-profiles--read-create-arguments))
  (let ((name (string-trim name))
        (clone-from (and clone-from (string-trim clone-from)))
        (origin (current-buffer)))
    (when (string-empty-p name) (user-error "Profile name is required"))
    (hermes-profiles--ensure-non-default name "create")
    (hermes-browser--run-owned
     (lambda (client _guard)
       (hermes-profiles--api
        client "POST" ""
        (append `((name . ,name))
                (and (hermes-transport--non-empty-string clone-from)
                     `((clone_from . ,clone-from))))))
     (hermes-browser--mutation-context)
     (lambda (_result)
       (hermes-profiles--refresh-after-mutation origin
                                                (format "created profile %s" name)))
     #'hermes-browser--read-error)))

(defvar-local hermes-profiles-soul-profile nil
  "Profile owned by the current SOUL editor buffer.")

(defvar-local hermes-profiles--soul-save-pending nil
  "Request token of the pending SOUL save, or nil.
Reject another save until settlement rather than race remote writes.")

(defvar-keymap hermes-profiles-soul-mode-map
  :parent markdown-mode-map
  "C-c C-c" #'hermes-profiles-soul-save
  "C-c C-k" #'quit-window)

(define-derived-mode hermes-profiles-soul-mode markdown-mode "Hermes SOUL"
  "Edit one Hermes profile's SOUL.md through the dashboard API."
  :interactive nil
  (setq-local header-line-format
              '(:eval (hermes-profiles--soul-header-line))))

(defun hermes-profiles--soul-header-line ()
  "Return the SOUL editor header for its profile and instance."
  (concat (or (hermes-browser--instance-header-line) "")
          (format " Profile: %s  |  C-c C-c save  C-c C-k quit "
                  hermes-profiles-soul-profile)))

(defun hermes-profiles--soul-buffer-name (profile instance)
  "Return the SOUL editor buffer name for PROFILE on INSTANCE."
  (if (hermes-instance-multiple-p)
      (format "*Hermes Profile SOUL@%s: %s*"
              (hermes-instance-name instance) profile)
    (format "*Hermes Profile SOUL: %s*" profile)))

(defun hermes-profiles--soul-path (profile)
  "Return the SOUL API path for PROFILE."
  (format "/%s/soul" (url-hexify-string profile)))

(defun hermes-profiles--soul-buffer (profile instance)
  "Return the editor owned by PROFILE and INSTANCE, creating one if needed."
  (or (seq-find
       (lambda (buffer)
         (with-current-buffer buffer
           (and (hermes-buffer--owned-p 'hermes-profiles-soul-mode)
                (equal hermes-profiles-soul-profile profile)
                (equal hermes-instance instance))))
       (buffer-list))
      (let ((buffer (generate-new-buffer
                     (hermes-profiles--soul-buffer-name profile instance))))
        (with-current-buffer buffer
          (hermes-profiles-soul-mode)
          (hermes-buffer--claim 'hermes-profiles-soul-mode)
          (setq hermes-instance (copy-tree instance t)
                hermes-profiles-soul-profile (copy-sequence profile)))
        buffer)))

(defun hermes-profiles--soul-current-p (buffer generation profile instance)
  "Return non-nil when BUFFER still owns GENERATION, PROFILE and INSTANCE."
  (and (hermes-browser--request-current-mode-p
        buffer generation 'hermes-profiles-soul-mode)
       (with-current-buffer buffer
         (and (equal hermes-profiles-soul-profile profile)
              (equal hermes-instance instance)))))

(defun hermes-profiles-edit-soul ()
  "Open the selected non-default profile's SOUL.md for editing."
  (interactive)
  (let ((instance (hermes-instance-resolve))
        (profile (tabulated-list-get-id)))
    (unless profile (user-error "No profile on this line"))
    (hermes-profiles--ensure-non-default profile "edit SOUL for")
    (let ((target (hermes-profiles--soul-buffer profile instance)))
      (pop-to-buffer target)
      (unless (with-current-buffer target (buffer-modified-p))
        (let ((generation
               (with-current-buffer target
                 (hermes-browser--next-request-generation))))
          (hermes-browser--run-on-client
           (lambda (client)
             (hermes-profiles--api
              client "GET" (hermes-profiles--soul-path profile)))
           (lambda (result)
             (when (hermes-profiles--soul-current-p
                    target generation profile instance)
               (with-current-buffer target
                 (unless (buffer-modified-p)
                   (let ((inhibit-read-only t))
                     (erase-buffer)
                     (insert (or (hermes-profiles--field result 'content) ""))
                     (set-buffer-modified-p nil))))))))))))

(defun hermes-profiles-soul-save ()
  "Save the current profile SOUL editor through the dashboard API.
Reject unavailable owners and overlapping saves without discarding the draft.
Keep edits made during a save modified."
  (interactive)
  (unless (derived-mode-p 'hermes-profiles-soul-mode)
    (user-error "Not in a Hermes profile SOUL buffer"))
  (when hermes-profiles--soul-save-pending
    (user-error "SOUL save in progress; draft retained, save again after completion"))
  (let* ((profile hermes-profiles-soul-profile)
         (target (current-buffer))
         (instance hermes-instance)
         (tick (buffer-chars-modified-tick))
         (content (buffer-substring-no-properties (point-min) (point-max))))
    (unless (and (hermes-instance--valid-p instance)
                 (member instance (hermes-instance-configured)))
      (user-error "SOUL instance unavailable; draft retained"))
    (unless (hermes-transport--non-empty-string profile)
      (user-error "This SOUL buffer has no profile"))
    (hermes-profiles--ensure-non-default profile "edit SOUL for")
    (let* ((generation (hermes-browser--next-request-generation))
           (current-p
            (lambda ()
              (and (hermes-profiles--soul-current-p
                    target generation profile instance)
                   (with-current-buffer target
                     (eq hermes-profiles--soul-save-pending generation)))))
           (release
            (lambda ()
              (when (buffer-live-p target)
                (with-current-buffer target
                  (when (eq hermes-profiles--soul-save-pending generation)
                    (setq hermes-profiles--soul-save-pending nil))))))
           dispatched)
      (setq hermes-profiles--soul-save-pending generation)
      (unwind-protect
          (prog1
              (hermes--promise-finally
               (hermes-browser--run-on-client
                (lambda (client)
                  (hermes-profiles--api
                   client "PUT" (hermes-profiles--soul-path profile)
                   `((content . ,content))))
                (lambda (_result)
                  (when (funcall current-p)
                    (with-current-buffer target
                      (when (= tick (buffer-chars-modified-tick))
                        (set-buffer-modified-p nil)))
                    (message "Hermes: saved SOUL for profile %s" profile)))
                (lambda (reason)
                  (when (funcall current-p)
                    (message "Hermes: %s" reason))))
               release)
            (setq dispatched t))
        ;; Client acquisition can signal before it returns a promise.
        (unless dispatched (funcall release))))))

(defun hermes-profiles-rename (new-name)
  "Rename the profile at point to NEW-NAME."
  (interactive
   (hermes-browser--read-owned-arguments
    (lambda () (list (read-string "Rename profile to: ")))
    #'tabulated-list-get-id))
  (let ((name (tabulated-list-get-id))
        (new-name (string-trim new-name))
        (origin (current-buffer)))
    (unless name (user-error "No profile on this line"))
    (when (string-empty-p new-name) (user-error "Profile name is required"))
    (hermes-profiles--ensure-non-default name "rename")
    (hermes-profiles--ensure-non-default new-name "rename to")
    (hermes-browser--run-owned
     (lambda (client _guard)
       (hermes-profiles--api
        client "PATCH" (concat "/" (url-hexify-string name))
        `((new_name . ,new-name))))
     (hermes-browser--mutation-context #'tabulated-list-get-id)
     (lambda (_result)
       (hermes-profiles--refresh-after-mutation
        origin (format "renamed profile %s to %s" name new-name)))
     #'hermes-browser--read-error)))

(defun hermes-profiles-delete ()
  "Delete the profile at point after confirmation."
  (interactive)
  (let* ((name (tabulated-list-get-id))
         (origin (current-buffer)))
    (unless name (user-error "No profile on this line"))
    (hermes-profiles--ensure-non-default name "delete")
    (let ((current (hermes-browser--mutation-context #'tabulated-list-get-id)))
      (when (and (yes-or-no-p (format "Delete profile %s? " name))
                 (funcall current))
        (with-current-buffer origin
          (hermes-browser--run-owned
           (lambda (client _guard)
             (hermes-profiles--api
              client "DELETE" (concat "/" (url-hexify-string name))))
           current
           (lambda (_result)
             (hermes-profiles--refresh-after-mutation
              origin (format "deleted profile %s" name)))
           #'hermes-browser--read-error))))))

(defun hermes-profiles-set-model ()
  "Set the model of the profile at point, persisted in its configuration."
  (interactive)
  (let ((name (tabulated-list-get-id))
        (origin (current-buffer)))
    (unless name (user-error "No profile on this line"))
    (hermes-browser--run-owned
     (lambda (client guard)
       (hermes--promise-then
        (hermes--promise-then
         (hermes-dashboard-transport-call-fn
          #'hermes-dashboard-transport-model-options-cached client)
         (lambda (catalog)
           (when (funcall guard)
             (with-current-buffer origin
               (let ((candidate (hermes-profiles--read-model-candidate catalog)))
                 (when (funcall guard)
                   (hermes-profiles--put-model client name candidate guard)))))))
        (lambda (_receipt)
          (hermes--promise-map
           (hermes-dashboard-transport-api-request-async
            "GET" "/api/profiles" :client client :current-p guard)
           (lambda (result)
             (when (funcall guard)
               (hermes-dashboard-transport--store-profile-cache
                result (hermes-dashboard-transport--cache-base-url client)))
             result)))))
     (hermes-browser--mutation-context #'tabulated-list-get-id)
     (lambda (result)
       (hermes-profiles--render result)
       (setq hermes-browser--status "Ready")
       (message "Hermes: read back model for profile %s" name))
     #'hermes-browser--read-error)))

;;;###autoload (autoload 'hermes-list-profiles "hermes-profiles" nil t)
(hermes-define-list-browser profiles
  :title "Hermes Profiles"
  :buffer "*Hermes Profiles*"
  :command hermes-list-profiles
  :doc "Major mode listing Hermes profiles with their configured runtime."
  :command-doc "Browse Hermes profiles and manage their lifecycle and model."
  :columns [("Profile" 16 t) ("Default" 7 t) ("Model" 28 t)
            ("Provider" 14 t) ("Reasoning" 9 t) ("Description" 40 nil)]
  :fetch (lambda (client)
           (hermes-dashboard-transport-profile-list-async client))
  :rows #'hermes-profiles--rows
  :help (:group "Settings"
         hermes-profiles-set-model "Set default model"
         hermes-profiles-edit-soul "Edit SOUL"
         :group "Profile"
         hermes-profiles-create "Create"
         hermes-profiles-rename "Rename"
         hermes-profiles-delete "Delete")
  :keys ("m" #'hermes-profiles-set-model
         "RET" #'hermes-profiles-set-model
         "s" #'hermes-profiles-edit-soul
         "c" #'hermes-profiles-create
         "r" #'hermes-profiles-rename
         "D" #'hermes-profiles-delete))

(provide 'hermes-profiles)
;;; hermes-profiles.el ends here
