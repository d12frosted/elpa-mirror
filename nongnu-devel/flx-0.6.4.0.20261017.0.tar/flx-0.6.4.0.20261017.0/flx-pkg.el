;; Generated package description from flx.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "flx" "0.6.4.0.20261017.0" "Fuzzy matching with good sorting" '((emacs "24.3")) :commit "be738f439fa779c5a5def44569202d2d7c6b0547" :url "https://github.com/lewang/flx")
