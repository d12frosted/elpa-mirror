;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261108.69" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "589ee12538bd844cbfb1ca659ff6f5ef92c5b91d" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
