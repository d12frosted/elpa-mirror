;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.16.1.0.20260718.10" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "265d45b3f2d01a6e6262d01c8d48058f56de6351" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy")
