;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.0snapshot0.20261009.247" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "cd6324a0ccd99f9c55799d82937d9b7a3b722ac9" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
