;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261015.78" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "73699f4b39b4718eaeeb11677c051e6334cd0d50" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
