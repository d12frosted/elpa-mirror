;;; evil-collection-hg-histedit.el --- Bindings for `hg-histedit' -*- lexical-binding: t -*-

;; Copyright (C) 2019 James Nguyen

;; Author: James Nguyen <james@jojojames.com>
;; Maintainer: James Nguyen <james@jojojames.com>
;; Pierre Neidhardt <mail@ambrevar.xyz>
;; URL: https://github.com/emacs-evil/evil-collection
;; Version: 0.0.1
;; Package-Requires: ((emacs "29.1"))
;; Keywords: emacs, tools

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:
;;; Bindings for `hg-histedit'.

;;; Code:
(require 'evil-collection)
(require 'hg-histedit nil t)

(defconst evil-collection-hg-histedit-maps '(hg-histedit-mode-map))

;;;###autoload
(defun evil-collection-hg-histedit-setup ()
  "Set up `evil' bindings for `hg-histedit'."
  (evil-collection-bind 'hg-histedit-mode-map 'edit 'hg-histedit-modify-commit-with-edit)
  (evil-collection-define-key 'normal 'hg-histedit-mode-map
    "m" 'hg-histedit-modify-commit-with-mess
    "p" 'hg-histedit-modify-commit-with-pick
    "b" 'hg-histedit-modify-commit-with-base
    "d" 'hg-histedit-modify-commit-with-drop
    "f" 'hg-histedit-modify-commit-with-fold
    "r" 'hg-histedit-modify-commit-with-roll
    "u" 'hg-histedit-undo))

(provide 'evil-collection-hg-histedit)
;;; evil-collection-hg-histedit.el ends here
