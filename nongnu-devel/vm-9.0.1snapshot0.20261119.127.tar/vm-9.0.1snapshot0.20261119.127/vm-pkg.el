;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261119.127" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "f8f5fad8cef2801989bf61d972d350ee242a9edc" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
