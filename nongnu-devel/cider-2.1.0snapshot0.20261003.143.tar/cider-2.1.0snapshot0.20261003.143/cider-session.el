;;; cider-session.el --- Session and REPL lookup for CIDER -*- lexical-binding: t -*-
;;
;; Copyright © 2019-2026 Artur Malabarba, Bozhidar Batsov, Vitalie Spinu and CIDER contributors
;;
;; Author: Artur Malabarba <bruce.connor.am@gmail.com>
;;         Bozhidar Batsov <bozhidar@batsov.dev>
;;         Vitalie Spinu <spinuvit@gmail.com>
;;
;; Keywords: languages, clojure, cider
;;
;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.
;;
;; This file is not part of GNU Emacs.
;;
;;
;;; Commentary:
;;
;; Lightweight session tracking, REPL discovery and runtime detection for CIDER.
;; This module intentionally has minimal dependencies so that any CIDER module
;; can require it without pulling in heavyweight initialization code.
;;
;;; Code:

(require 'nrepl-client)
(require 'cl-lib)
(require 'format-spec)
(require 'sesman)
(require 'sesman-browser)
(require 'cider-common)
(require 'cider-util)

;; Defined in cider-popup.el, set at runtime; declared here for the byte-compiler.
(defvar cider-ancillary-buffers)

;; Override nrepl-client's default REPL buffer name.
(setq nrepl-repl-buffer-name-template "*cider-repl %s(%r:%S)*")

(defcustom cider-session-name-template "%J:%h:%p"
  "Format string to use for session names.
See `cider-format-connection-params' for available format characters."
  :type 'string
  :group 'cider
  :package-version '(cider . "0.18.0"))

(defcustom cider-auto-mode t
  "When non-nil, automatically enable and disable CIDER in all Clojure buffers.

After an initial connection, `cider-mode' is added to `clojure-mode-hook' and
automatically enabled on all existing Clojure buffers.  After the last
connection has been closed, `cider-mode' is disabled in all Clojure buffers, and
has to be manually re-enabled via \\[cider-mode].

Useful for switching between alternative minor modes like `inf-clojure-mode'."
  :type 'boolean
  :group 'cider
  :safe #'booleanp
  :package-version '(cider . "0.9.0"))

(defcustom cider-merge-sessions nil
  "Controls session combination behavior.

Symbol `host' combines all sessions of a project associated with the same host.
Symbol `project' combines all sessions of a project.

All other values do not combine any sessions."
  :type '(choice (const :tag "Combine all sessions with the same host" host)
                 (const :tag "Combine all sessions from the same project" project)
                 (other :tag "Do not combine any sessions"))
  :group 'cider
  :safe #'symbolp
  :package-version '(cider . "1.5"))

(defvar cider-default-session nil
  "When non-nil, bypass sesman and use this session for all REPL lookups.
Set interactively with `cider-set-default-session'.")

(defun cider--default-session ()
  "Return the session named by `cider-default-session', or nil.
Nil when no default session is set, or when the named one no longer exists
\(e.g. it was quit) - callers then fall back to normal sesman resolution.
This is the single source of truth for the `cider-default-session' override,
shared by `cider-repls', `cider-ensure-session' and
`cider--sesman-friendly-session-p'."
  (when cider-default-session
    (sesman-session 'CIDER cider-default-session)))

(defcustom cider-clojurec-eval-destination 'multi
  "The REPL type to be chosen in .cljc buffers."
  :type '(choice (const :tag "Clojure" clj)
                 (const :tag "ClojureScript" cljs)
                 (const :tag "Multi (evaluate in Clojure and ClojureScript simultaneously)" multi))
  :group 'cider
  :package-version '(cider . "1.8"))


;;; Session Tracking

(defun cider-sessions ()
  "Return a list of all active CIDER sessions."
  (sesman-sessions 'CIDER))

(defun cider-connected-p ()
  "Return t if CIDER is currently connected, nil otherwise."
  (process-live-p (get-buffer-process (cider-current-repl))))

(defvar-local cider--pinned-repl-buffer nil
  "The REPL buffer the current buffer is pinned to, or nil.
Pinning ties a buffer to a specific REPL so that CIDER commands invoked
there target that session regardless of sesman and `default-directory'.
It is set on ancillary buffers that originate from a session and must never
switch away from it (e.g. *cider-inspector*, *cider-error*, popups), and on
source buffers visited outside the project directory (e.g. a dependency's
source jumped to via `cider-find-var'), pinning them to the session they
were navigated from.  Consult it through `cider--pinned-repl' and
`cider--pinned-session' rather than directly.")

(defun cider--pinned-repl ()
  "Return the REPL the current buffer is pinned to, or nil.
The pin lives in `cider--pinned-repl-buffer'; a dead pin yields nil."
  (and (buffer-live-p cider--pinned-repl-buffer)
       cider--pinned-repl-buffer))

(defun cider--pinned-session ()
  "Return the sesman session of the REPL the current buffer is pinned to.
Return nil when the buffer isn't pinned or the pin is stale - its REPL is
dead or its session has been quit."
  (when-let* ((repl (cider--pinned-repl)))
    (sesman-session-for-object 'CIDER repl 'no-error)))

(defun cider--current-session-name ()
  "Return the name of the session the current buffer resolves to, or nil.
Follow the same precedence as REPL resolution - pinned session, then
`cider-default-session', then sesman's current session - so error messages
name the session evaluation would actually target, even in a buffer that is
only pinned (e.g. a dependency's source) and thus has no linked sesman
session of its own."
  (car (or (cider--pinned-session)
           (cider--default-session)
           (sesman-current-session 'CIDER))))

(defun cider-ensure-session ()
  "Signal a `user-error' unless CIDER has a session available here.
The CIDER-level nREPL senders (e.g. `cider-nrepl-send-request',
`cider-nrepl-sync-request') already ensure a connection - they resolve the
REPL with `cider-current-repl' ENSURE - so commands don't need this for
correctness.  Use it only to fail fast, before doing interactive or
side-effecting work, rather than at the point of the first request.

Mirror the resolution precedence of `cider-current-repl' and `cider-repls':
honor a buffer pinned to a REPL (via `cider--pinned-session') and a
`cider-default-session' before falling back to sesman's linked sessions.
Otherwise this guard would reject buffers where evaluation actually works,
such as a dependency's source jumped to via `cider-find-var' (which lives
outside the project and so has no linked session, only a pin - see
https://github.com/clojure-emacs/cider/issues/4120)."
  (or (cider--pinned-session)
      (cider--default-session)
      (sesman-ensure-session 'CIDER)))

(define-obsolete-function-alias 'cider-ensure-connected #'cider-ensure-session "2.0.0")


;;; Connection Parameters

(defun cider--session-server (session)
  "Return server buffer for SESSION or nil if there is no server."
  (seq-some (lambda (r)
              (buffer-local-value 'nrepl-server-buffer r))
            (cdr session)))

(defun cider--gather-connect-params (&optional params proc-buffer)
  "Gather all relevant connection parameters into PARAMS plist.
PROC-BUFFER is either server or client buffer, defaults to current buffer."
  (let ((proc-buffer (or proc-buffer (current-buffer))))
    (with-current-buffer proc-buffer
      (unless nrepl-endpoint
        (error "This is not a REPL or SERVER buffer; is there an active REPL?"))
      (let ((server-buf (if (nrepl-server-p proc-buffer)
                            proc-buffer
                          nrepl-server-buffer)))
        (cl-loop for l on nrepl-endpoint by #'cddr
                 do (setq params (plist-put params (car l) (cadr l))))
        (setq params (thread-first params
                                   (plist-put :project-dir nrepl-project-dir)))
        (when (buffer-live-p server-buf)
          (setq params (thread-first params
                                     (plist-put :server (get-buffer-process server-buf))
                                     (plist-put :server-command nrepl-server-command))))
        ;; repl-specific parameters (do not pollute server params!)
        (unless (nrepl-server-p proc-buffer)
          (setq params (thread-first params
                                     (plist-put :session-name cider-session-name)
                                     (plist-put :repl-type cider-repl-type)
                                     (plist-put :cljs-repl-type cider-cljs-repl-type)
                                     (plist-put :repl-init-function cider-repl-init-function))))
        params))))

(defun cider--gather-session-params (session)
  "Gather all params for a SESSION."
  (let (params)
    (dolist (repl (cdr session))
      (setq params (cider--gather-connect-params params repl)))
    (when-let* ((server (cider--session-server session)))
      (setq params (cider--gather-connect-params params server)))
    params))


;;; Connection Info

(defun cider--java-version ()
  "Retrieve the underlying connection's Java version."
  (with-current-buffer (cider-current-repl)
    (when nrepl-versions
      (thread-first nrepl-versions
                    (nrepl-dict-get "java")
                    (nrepl-dict-get "version-string")))))

(defun cider--clojure-version ()
  "Retrieve the underlying connection's Clojure version."
  (with-current-buffer (cider-current-repl)
    (when nrepl-versions
      (thread-first nrepl-versions
                    (nrepl-dict-get "clojure")
                    (nrepl-dict-get "version-string")))))

(defun cider--nrepl-version ()
  "Retrieve the underlying connection's nREPL version."
  (with-current-buffer (cider-current-repl)
    (when nrepl-versions
      (thread-first nrepl-versions
                    (nrepl-dict-get "nrepl")
                    (nrepl-dict-get "version-string")))))

(defun cider--babashka-version ()
  "Retrieve the underlying connection's Babashka version."
  (with-current-buffer (cider-current-repl)
    (when nrepl-versions
      (nrepl-dict-get nrepl-versions "babashka"))))

(defun cider--babashka-nrepl-version ()
  "Retrieve the underlying connection's babashka.nrepl version."
  (with-current-buffer (cider-current-repl)
    (when nrepl-versions
      (nrepl-dict-get nrepl-versions "babashka.nrepl"))))

(defun cider--nbb-nrepl-version ()
  "Retrieve the underlying connection's nbb version.

Note that this is currently not a real version number.
But helps us know if this is a nbb repl, or not."
  (with-current-buffer (cider-current-repl)
    (when nrepl-versions
      (nrepl-dict-get nrepl-versions "nbb-nrepl"))))

(defun cider--scittle-nrepl-version ()
  "Retrieve the underlying connection's scittle version."
  (with-current-buffer (cider-current-repl)
    (when nrepl-versions
      (nrepl-dict-get nrepl-versions "scittle-nrepl"))))

(defun cider--let-go-version ()
  "Retrieve the underlying connection's let-go version.
Formatted as \"MAJOR.MINOR\" since let-go's nREPL `describe` response
splits the version into separate fields rather than a `version-string`."
  (with-current-buffer (cider-current-repl)
    (when-let* ((versions nrepl-versions)
                (lg (nrepl-dict-get versions "let-go")))
      (format "%s.%s"
              (or (nrepl-dict-get lg "major") "?")
              (or (nrepl-dict-get lg "minor") "?")))))

(defun cider-runtime ()
  "Return the runtime of the nREPL server."
  (cond
   ((cider--clojure-version) 'clojure)
   ((cider--babashka-version) 'babashka)
   ((cider--nbb-nrepl-version) 'nbb)
   ((cider--scittle-nrepl-version) 'scittle)
   ((cider--let-go-version) 'let-go)
   (t 'generic)))

(defun cider-runtime-clojure-p ()
  "Check if the current runtime is Clojure."
  (eq (cider-runtime) 'clojure))


;;; Connection Capabilities

(defvar-local cider-connection-capabilities '()
  "A list of some of the capabilities of this connection buffer.
In other words - what assumptions we make about the runtime.
This is more general than
`cider-nrepl-op-supported-p' and `cider-library-present-p'.
But does not need to replace them.")

(defun cider-connection-has-capability-p (capability &optional conn-buf)
  "Return non nil when the cider connection has CAPABILITY for CONN-BUF.
By default it assumes the connection buffer is current."
  (with-current-buffer (or conn-buf (current-buffer))
    (member capability cider-connection-capabilities)))


;;; REPL Buffer Init

(defvar-local cider-cljs-repl-type nil
  "The type of the ClojureScript runtime (`browser', `node', `figwheel', etc.).")

(defvar-local cider-repl-type nil
  "The type of this REPL buffer, usually either clj or cljs.")

(defvar-local cider-repl-cljs-upgrade-pending nil
  "Is the cljs repl currently pending?")

(defvar-local cider-session-name nil)
(defvar-local cider-repl-init-function nil)
(defvar-local cider-launch-params nil)

(defun cider-repl-type (repl-buffer)
  "Get REPL-BUFFER's type."
  (buffer-local-value 'cider-repl-type repl-buffer))

(defun cider-cljs-pending-p (repl-buffer)
  "Return non-nil when REPL-BUFFER is currently a pending cljs repl."
  (buffer-local-value 'cider-repl-cljs-upgrade-pending repl-buffer))

(defvar-local cider-repl-type-override nil
  "When non-nil, the REPL type (clj, cljs or multi) used for this buffer.
Overrides the major-mode-based inference in `cider-repl-type-for-buffer'.
Buffers with no inherent file type - e.g. `*cider-scratch*' - set this to
control where their evaluations are dispatched.")

(defun cider-repl-type-for-buffer (&optional buffer)
  "Return the matching REPL type (clj or cljs) for BUFFER.
BUFFER defaults to the `current-buffer'.  In cljc buffers return
multi.  This function infers the REPL type based on the major mode,
unless `cider-repl-type-override' is set.
To get a REPL buffer's own type use the function `cider-repl-type'."
  (with-current-buffer (or buffer (current-buffer))
    (cond
     (cider-repl-type-override cider-repl-type-override)
     ((cider-clojurescript-major-mode-p) 'cljs)
     ((cider-clojurec-major-mode-p) cider-clojurec-eval-destination)
     ((cider-clojure-major-mode-p) 'clj)
     (cider-repl-type))))

(defconst cider-eval-destinations '(clj cljs multi auto)
  "The eval dispatch types `cider-cycle-eval-destination' cycles through.
The `auto' entry clears `cider-repl-type-override', reverting to the
major-mode-based inference of `cider-repl-type-for-buffer'.")

(defun cider--reflect-eval-destination-in-mode-line ()
  "Show the buffer's `cider-repl-type-override' in the mode line, if any."
  (setq-local mode-line-process
              (when cider-repl-type-override
                (format " [%s]" cider-repl-type-override)))
  (force-mode-line-update))

(defun cider-set-eval-destination (type)
  "Set the current buffer's eval dispatch (REPL type) to TYPE.
TYPE is one of `clj', `cljs', `multi', or `auto'.  All but `auto' set
`cider-repl-type-override' for this buffer, overriding the major-mode-based
inference of `cider-repl-type-for-buffer' so that evaluations target the
chosen REPL of the buffer's session; `auto' clears the override.  The choice
is reflected in the mode line.

This is handy in buffers with no inherent file type to dispatch on (e.g. the
scratch buffer) and in `.cljc' buffers where you want to pin evaluations to a
specific REPL."
  (interactive (list (intern (completing-read
                              "Eval destination: "
                              (mapcar #'symbol-name cider-eval-destinations)
                              nil t))))
  (setq-local cider-repl-type-override (unless (eq type 'auto) type))
  (cider--reflect-eval-destination-in-mode-line)
  (message "Buffer eval destination set to `%s'" type))

(defun cider-cycle-eval-destination ()
  "Cycle the current buffer's eval dispatch through `cider-eval-destinations'.
See `cider-set-eval-destination'."
  (interactive)
  (let* ((current (or cider-repl-type-override 'auto))
         (tail (cdr (memq current cider-eval-destinations)))
         (next (or (car tail) (car cider-eval-destinations))))
    (cider-set-eval-destination next)))

(defun cider-set-repl-type (&optional type)
  "Set REPL TYPE to clj or cljs.
Assume that the current buffer is a REPL."
  (interactive)
  (let ((type (cider-maybe-intern (or type (completing-read
                                            (format "Set REPL type (currently `%s') to: "
                                                    cider-repl-type)
                                            '(clj cljs))))))
    (when (or (not (equal cider-repl-type type))
              (null mode-name))
      (setq cider-repl-type type)
      (setq mode-name (format "REPL[%s]" type))
      (let ((params (cider--gather-connect-params)))
        ;; We need to set current name to something else temporarily to avoid
        ;; false name duplication in `nrepl-repl-buffer-name`.
        (rename-buffer (generate-new-buffer-name "*dummy-cider-repl-buffer*"))
        (rename-buffer (nrepl-repl-buffer-name params))
        (when (and nrepl-log-messages nrepl-messages-buffer)
          (with-current-buffer nrepl-messages-buffer
            (rename-buffer (nrepl-messages-buffer-name params))))))))


;;; Connection Name Formatting

(defun cider--ensure-spec-is-not-invokable (spec)
  "Ensure SPEC cannot be invoked as a function.

Invokeable specs are an Emacs 29 feature
that we don't intend to use in this context."
  (let ((spec-char (car spec))
        (spec-value (cdr spec)))
    `(,spec-char
      .
      ,(if (symbolp spec-value)
           (prin1-to-string spec-value)
         spec-value))))

(defun cider-format-connection-params (template params)
  "Format PARAMS with TEMPLATE string.
The following formats can be used in TEMPLATE string:

  %h - host
  %H - remote host, empty for local hosts
  %p - port
  %j - short project name, or directory name if no project
  %J - long project name including parent dir name
  %r - REPL type (clj or cljs)
  %S - type of the ClojureScript runtime (Browser, Node, Figwheel etc.)
  %s - session name as defined by `cider-session-name-template'.

In case some values are empty, extra separators (: and -) are automatically
removed."
  (let* ((dir (directory-file-name
               (abbreviate-file-name
                (or (plist-get params :project-dir)
                    (cider-project-dir (cider-current-dir))
                    default-directory))))
         (short-proj (file-name-nondirectory (directory-file-name dir)))
         (parent-dir (ignore-errors
                       (thread-first dir
                                     file-name-directory
                                     directory-file-name file-name-nondirectory
                                     file-name-as-directory)))
         (long-proj (format "%s%s" (or parent-dir "") short-proj))
         ;; use `dir` if it is shorter than `long-proj` or `short-proj`
         (short-proj (if (>= (length short-proj) (length dir))
                         dir
                       short-proj))
         (long-proj (if (>= (length long-proj) (length dir))
                        dir
                      long-proj))
         (port (or (plist-get params :port) ""))
         (host (or (plist-get params :host) "localhost"))
         (remote-host (if (member host '("localhost" "127.0.0.1"))
                          ""
                        host))
         (repl-type (or (plist-get params :repl-type) "unknown"))
         (cljs-repl-type (or (and (eq repl-type 'cljs)
                                  (plist-get params :cljs-repl-type))
                             ""))
         (specs `((?h . ,host)
                  (?H . ,remote-host)
                  (?p . ,port)
                  (?j . ,short-proj)
                  (?J . ,long-proj)
                  (?r . ,repl-type)
                  (?S . ,cljs-repl-type)))
         (ses-name (or (plist-get params :session-name)
                       (format-spec cider-session-name-template specs)))
         (specs (append `((?s . ,ses-name)) specs))
         (specs (mapcar #'cider--ensure-spec-is-not-invokable specs)))
    (thread-last (format-spec template specs)
                 ;; remove extraneous separators
                 (replace-regexp-in-string "\\([:-]\\)[:-]+" "\\1")
                 (replace-regexp-in-string "\\(^[:-]\\)\\|\\([:-]$\\)" "")
                 (replace-regexp-in-string "[:-]\\([])*]\\)" "\\1"))))

(defun cider-make-session-name (params)
  "Create new session name given plist of connection PARAMS.
Session name can be customized with `cider-session-name-template'."
  (let* ((root-name (cider-format-connection-params cider-session-name-template params))
         (other-names (mapcar #'car (sesman-sessions 'CIDER)))
         (name root-name)
         (i 2))
    (while (member name other-names)
      (setq name (concat root-name "#" (number-to-string i))
            i (+ i 1)))
    name))


;;; Default Session Commands

(defun cider-set-default-session ()
  "Set the default session for all REPL lookups.
When a default session is set, all evaluations use it
regardless of project context."
  (interactive)
  (let* ((sessions (cider-sessions))
         (session-names (mapcar #'car sessions))
         (name (completing-read "Set default CIDER session: " session-names nil t)))
    (setq cider-default-session name)
    (message "Default CIDER session set to '%s'" name)))

(defun cider-clear-default-session ()
  "Clear the default CIDER session.
Reverts to normal project-based session association."
  (interactive)
  (setq cider-default-session nil)
  (message "Default CIDER session cleared"))


;;; Sesman's Session-Wise Management UI

(cl-defmethod sesman-project ((_system (eql CIDER)))
  "Find project directory."
  (cider-project-dir (cider-current-dir)))

(cl-defmethod sesman-more-relevant-p ((_system (eql CIDER)) session1 session2)
  "Figure out if SESSION1 or SESSION2 is more relevant."
  (sesman-more-recent-p (cdr session1) (cdr session2)))

(defun cider--cache-session-project-dir ()
  "Cache the current connection's project directory for session matching.

Called from `cider--connected-handler' once per new connection.  The
project directory is stored on the connection's process under
`:cached-project-dir', resolved via `file-truename' and with a trailing
slash, so that `cider--sesman-friendly-session-p' can match buffers with
a cheap `string-prefix-p' check on the hot redisplay path instead of
resolving symlinks on every call."
  (when-let* ((proc (get-buffer-process (current-buffer)))
              (proj-dir (buffer-local-value 'nrepl-project-dir (current-buffer))))
    (process-put proc :cached-project-dir
                 (file-name-as-directory (file-truename proj-dir)))))

(defun cider--sesman-friendly-session-p (session &optional debug)
  "Check if SESSION is a friendly session, DEBUG optionally.

A session is friendly to the current buffer when the buffer's file lives
under the session's project directory.  The checking is done as follows:

* If `cider-default-session' is set and the named session still
  exists, only that session is considered friendly (it serves every
  buffer, regardless of project context).  When the named session has
  been quit/killed, fall through to the normal matching logic.
* Consider if the buffer belongs to `cider-ancillary-buffers'.
* Consider the buffer's filename, strip any Docker/TRAMP details from it.
* Check whether that filename lives under the connection's project
  directory.

Buffers associated with their originating session explicitly through
`cider--pinned-repl-buffer' (e.g. popups, or a dependency's source
jumped to via `cider-find-var') resolve via that pin and don't rely on
this matcher.

The project directory is cached at connection time by
`cider--cache-session-project-dir', so this function does not block on
any nREPL requests."
  (setcdr session (seq-filter #'buffer-live-p (cdr session)))
  (when-let* ((repl (cadr session)))
    (cond
     ;; If a default session is set and still exists, only that session is
     ;; friendly.  If the named session no longer exists we fall through to
     ;; the normal matching logic, matching `cider-repls' behavior.
     ((cider--default-session)
      (equal (car session) cider-default-session))

     ((member (buffer-name) cider-ancillary-buffers)
      t)

     (t
      (when-let* ((proc (get-buffer-process repl))
                  (file (file-truename (or (buffer-file-name) default-directory))))
        (when-let* ((tp (cider-tramp-prefix (current-buffer))))
          (setq file (string-remove-prefix tp file)))
        (when (process-live-p proc)
          (let ((proj-dir (or (process-get proc :cached-project-dir)
                              (when-let* ((pd (buffer-local-value 'nrepl-project-dir repl)))
                                (file-name-as-directory (file-truename pd))))))
            ;; The project dir is cached as a truename-resolved directory (with
            ;; a trailing slash), so a plain `string-prefix-p' is both a correct
            ;; directory-boundary check and cheap enough for the redisplay hot
            ;; path.  `file' is already resolved via `file-truename' above.
            (or (and proj-dir (string-prefix-p proj-dir file))
                ;; For remote (TRAMP/Docker) sessions the project dir is a remote
                ;; path; translate the local file and match against it.
                (when-let* ((cider-path-translations (cider--all-path-translations))
                            (translated (cider--translate-path file 'to-nrepl :return-all)))
                  (and proj-dir
                       (seq-find (lambda (tp) (string-prefix-p proj-dir (file-truename tp)))
                                 translated)))
                (when debug
                  (list file
                        "was not determined to belong to project-dir:" proj-dir))))))))))

(defun cider-debug-sesman-friendly-session-p ()
  "`message's debugging information relative to friendly sessions.

This is useful for when one sees \"No linked CIDER sessions\"
in an unexpected place."
  (interactive)
  (message (prin1-to-string (mapcar (lambda (session)
                                      (cider--sesman-friendly-session-p session t))
                                    ;; `cider-sessions' wraps the public
                                    ;; `sesman-sessions', which returns the same
                                    ;; set as the private `sesman--all-system-sessions'.
                                    (cider-sessions)))))

(cl-defmethod sesman-friendly-session-p ((_system (eql CIDER)) session)
  "Check if SESSION is a friendly session."
  (cider--sesman-friendly-session-p session))

(declare-function cider-quit "cider-connection")
(declare-function cider-restart "cider-connection")
(declare-function cider-describe-connection "cider-connection")

(defvar cider-sesman-browser-map
  (let ((map (make-sparse-keymap)))
    (define-key map (kbd "j q") #'cider-quit)
    (define-key map (kbd "j k") #'cider-quit)
    (define-key map (kbd "j r") #'cider-restart)
    (define-key map (kbd "j d") #'cider-describe-connection)
    (define-key map (kbd "j i") #'cider-describe-connection)
    (define-key map (kbd "C-c C-q") #'cider-quit)
    (define-key map (kbd "C-c C-r") #'cider-restart)
    (define-key map (kbd "C-c M-r") #'cider-restart)
    (define-key map (kbd "C-c C-d") #'cider-describe-connection)
    (define-key map (kbd "C-c M-d") #'cider-describe-connection)
    map)
  "Map active on REPL objects in sesman browser.")

(cl-defmethod sesman-session-info ((_system (eql CIDER)) session)
  "Obtain info for a CIDER SESSION."
  (list :objects (cdr session)
        :map cider-sesman-browser-map))


;;; Current/other REPLs

(defun cider--no-repls-user-error (type)
  "Throw \"No REPL\" user error customized for TYPE."
  (let ((type (cond
               ((or (eq type 'multi) (eq type 'any))
                "clj or cljs")
               ((listp type)
                (mapconcat #'identity type " or "))
               (type))))
    (user-error "No %s REPLs in current session \"%s\""
                type (cider--current-session-name))))

(defun cider-current-repl (&optional type ensure)
  "Get the most recent REPL of TYPE from the current session.
TYPE is either clj, cljs, multi, infer or any.
When infer or nil, infer the type from the current buffer.
If ENSURE is non-nil, throw an error if either there is
no linked session or there is no REPL of TYPE within the current session."
  (let ((type (cider-maybe-intern type)))
    (if (and (derived-mode-p 'cider-repl-mode)
             (or (null type)
                 (eq 'any type)
                 (eq 'infer type)
                 (eq cider-repl-type type)))
        ;; shortcut when in REPL buffer
        (current-buffer)
      (or (cider--pinned-repl)
          (let* ((type (if (or (null type)
                               (eq 'infer type))
                           (cider-repl-type-for-buffer)
                         type))
                 (repls (cider-repls type ensure))
                 (repl (if (<= (length repls) 1)
                           (car repls)
                         ;; pick the most recent one
                         (seq-find (lambda (b)
                                     (member b repls))
                                   (buffer-list)))))
            (if (and ensure (null repl))
                (cider--no-repls-user-error type)
              repl))))))

(defun cider--match-repl-type (type buffer)
  "Return non-nil if TYPE matches BUFFER's REPL type."
  (let ((buffer-repl-type (cider-repl-type buffer)))
    (cond ((null buffer-repl-type) nil)
          ((or (null type) (eq type 'multi) (eq type 'any)) t)
          ((listp type) (member buffer-repl-type type))
          (t
           (or (string= type buffer-repl-type)
               (let ((capabilities
                      (buffer-local-value 'cider-connection-capabilities buffer)))
                 (member type capabilities)))))))

(defun cider--get-host-from-session (session)
  "Return the host associated with SESSION."
  (plist-get (cider--gather-session-params session)
             :host))

(defun cider--get-sessions-with-same-host (session sessions)
  "Return the subset of SESSIONS that share SESSION's host."
  ;; Resolve SESSION's host once up front rather than on every comparison.
  (let ((host (cider--get-host-from-session session)))
    (seq-filter (lambda (s)
                  (string-equal host (cider--get-host-from-session s)))
                sessions)))

(defun cider--extract-connections (sessions)
  "Return a flattened list of all REPL buffers in SESSIONS."
  (seq-reduce (lambda (x y)
                (append x (cdr y)))
              sessions
              '()))

;; Avoid circular dependency: cider-client.el requires cider-session.el
(declare-function cider-nrepl-op-supported-p "cider-client")
(defun cider-repls (&optional type ensure required-ops)
  "Return cider REPLs of TYPE from the current session.
If TYPE is nil or multi, return all REPLs.  If TYPE is a list of types,
return only REPLs of type contained in the list.  If ENSURE is non-nil,
throw an error if no linked session exists.  If REQUIRED-OPS is non-nil,
filters out all the REPLs that do not support the designated ops.

If the buffer is pinned to a REPL via `cider--pinned-repl-buffer', that
REPL's session is used instead of the current one (taking precedence over
`cider-default-session'); a stale pin falls through to normal resolution."
  (let* ((type (cond
                ((listp type)
                 (mapcar #'cider-maybe-intern type))
                ((cider-maybe-intern type))))
         ;; Gather the candidate REPLs for the current buffer.  Each branch
         ;; produces the raw list without an `ensure' check; the single check
         ;; below reports the absence of any linked session uniformly.
         ;; A buffer explicitly pinned to a REPL (e.g. a popup created from a
         ;; given session) resolves against that REPL's *session*, independent
         ;; of sesman/`default-directory'.  We resolve the session - not just the
         ;; lone REPL - so type filtering and multi (clj+cljs) dispatch keep
         ;; working.  Takes precedence over `cider-default-session', matching
         ;; `cider-current-repl', which checks the pin first.
         (pinned-session (cider--pinned-session))
         (repls (cond
                 (pinned-session (cdr pinned-session))
                 ;; A pinned default session bypasses sesman entirely and serves
                 ;; every buffer.  If it has been quit since being pinned, warn
                 ;; and treat it as having no REPLs, so the `ensure' check below
                 ;; reports the missing session.
                 (cider-default-session
                  (if-let* ((session (cider--default-session)))
                      (cdr session)
                    (message "Default CIDER session '%s' no longer exists, ignoring" cider-default-session)
                    nil))
                 (t
                  (pcase cider-merge-sessions
                    ;; Merge every linked session sharing the current session's
                    ;; host into one pool of REPLs.
                    ('host (cider--extract-connections
                            (cider--get-sessions-with-same-host
                             (sesman-current-session 'CIDER)
                             (sesman-current-sessions 'CIDER))))
                    ;; Merge all sessions linked to the current project.
                    ('project (cider--extract-connections (sesman-current-sessions 'CIDER)))
                    ;; No merging: use only the most relevant linked session.
                    (_ (cdr (sesman-current-session 'CIDER))))))))
    ;; `ensure' has two distinct failure modes: no linked session at all
    ;; (reported here, matching `sesman-ensure-session') and a session that
    ;; has no REPL of the requested TYPE (reported after filtering below).
    (when (and ensure (null repls))
      (user-error "No linked %s sessions" 'CIDER))
    (or (seq-filter (lambda (b)
                      (unless
                          (cider-cljs-pending-p b)
                        (and (cider--match-repl-type type b)
                             (seq-every-p (lambda (op)
                                            (cider-nrepl-op-supported-p op b))
                                          required-ops))))
                    repls)
        (when ensure
          (cider--no-repls-user-error type)))))

(defun cider-map-repls (which function)
  "Call FUNCTION once for each appropriate REPL as indicated by WHICH.
The function is called with one argument, the REPL buffer.  The appropriate
REPLs are found by inspecting the current buffer.  WHICH is either one of
the following keywords or a list starting with one of them followed by names of
operations that the REPL is expected to support:
 :auto - Act on the REPLs whose type matches the current buffer.  In
     `cljc' files, mapping happens over both types of REPLs.
 :clj (:cljs) - Map over clj (cljs)) REPLs only.
 :clj-strict (:cljs-strict) - Map over clj (cljs) REPLs but signal a
      `user-error' in `clojurescript-mode' (`clojure-mode').  Use this for
      commands only supported in Clojure (ClojureScript).
Error is signaled if no REPL buffers of specified type exist in current
session."
  (declare (indent 1))
  (let ((cur-type (cider-repl-type-for-buffer))
        (which-key (or (car-safe which) which))
        (required-ops (cdr-safe which)))
    (pcase which-key
      (:clj-strict (when (eq cur-type 'cljs)
                     (user-error "Clojure-only operation requested in a ClojureScript buffer")))
      (:cljs-strict (when (eq cur-type 'clj)
                      (user-error "ClojureScript-only operation requested in a Clojure buffer"))))
    (let* ((type (pcase which-key
                   ((or :clj :clj-strict) 'clj)
                   ((or :cljs :cljs-strict) 'cljs)
                   (:auto (if (eq cur-type 'multi)
                              '(clj cljs)
                            cur-type))))
           (ensure (pcase which-key
                     (:auto nil)
                     (_ 'ensure)))
           (repls (cider-repls type ensure required-ops)))
      (mapcar function repls))))

;; Legacy aliases from before the connection->REPL terminology change.  They have
;; no remaining users in CIDER itself; keep them working but steer code to the
;; `cider-repl' names.
(defalias 'cider-current-connection #'cider-current-repl)
(defalias 'cider-connections #'cider-repls)
(defalias 'cider-map-connections #'cider-map-repls)
(defalias 'cider-connection-type-for-buffer #'cider-repl-type-for-buffer)
(make-obsolete 'cider-current-connection #'cider-current-repl "2.0.0")
(make-obsolete 'cider-connections #'cider-repls "2.0.0")
(make-obsolete 'cider-map-connections #'cider-map-repls "2.0.0")
(make-obsolete 'cider-connection-type-for-buffer #'cider-repl-type-for-buffer "2.0.0")


(provide 'cider-session)

;;; cider-session.el ends here
