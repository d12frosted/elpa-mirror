;; Generated package description from meow.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "meow" "1.5.0.0.20260619.66" "Yet Another modal editing" '((emacs "27.1")) :commit "96648fa6398222e1376422d01f5249afa2a25680" :keywords '("convenience" "modal-editing") :url "https://www.github.com/DogLooksGood/meow")
