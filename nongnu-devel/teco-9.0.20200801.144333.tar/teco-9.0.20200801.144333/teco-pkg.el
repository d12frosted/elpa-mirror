;; Generated package description from teco.el  -*- no-byte-compile: t -*-
(define-package "teco" "9.0.20200801.144333" "Teco interpreter" 'nil :commit "61caf8f419659a0567a269f290c90427a215d77b" :authors '(("Dale R. Worley" . "worley@alum.mit.edu")) :maintainer '("Mark T. Kennedy" . "mtk@acm.org") :keywords '("convenience" "emulations" "files") :url "https://github.com/mtk/teco.git")
