;; Generated package description from flx-ido.el  -*- no-byte-compile: t -*-
(define-package "flx-ido" "0.6.2.0.20240204.195634" "flx integration for ido" '((flx "0.1") (cl-lib "0.3")) :commit "4b1346eb9a8a76ee9c9dede69738c63ad97ac5b6" :url "https://github.com/lewang/flx")
