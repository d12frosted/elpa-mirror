;; Generated package description from go-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "go-mode" "1.6.0.0.20260529.24" "Major mode for the Go programming language" '((emacs "26.1")) :commit "3a71d28ab47df685e54ca6046a7a3dd3e28b682c" :keywords '("languages" "go") :url "https://github.com/dominikh/go-mode.el")
