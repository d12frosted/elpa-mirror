;; Generated package description from eprolog.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "eprolog" "0.3.2.0.20260308.150317" "Native Prolog engine implementation" '((emacs "27.2")) :commit "6eff9942d3de603109101f3d74e30aac495203f6" :keywords '("languages" "prolog" "logic programming") :url "https://github.com/tani/eprolog")
