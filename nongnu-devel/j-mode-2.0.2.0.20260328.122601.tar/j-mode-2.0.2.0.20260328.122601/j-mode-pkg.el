;; Generated package description from j-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "j-mode" "2.0.2.0.20260328.122601" "Major mode for editing J programs" 'nil :commit "e49ef0692d73b320c281e40d9fa96b2c17073695" :keywords '("j" "languages") :url "http://github.com/zellio/j-mode")
