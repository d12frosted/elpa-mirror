;; Generated package description from ujelly-theme.el  -*- no-byte-compile: t -*-
(define-package "ujelly-theme" "1.3.6.0.20241111.2243" "Ujelly theme for GNU Emacs 24 (deftheme)" 'nil :commit "7345ab821739aafa2ec079a71fa7de350a869f0e" :authors '(("Mark Tran" . "mark.tran@gmail.com")) :maintainer '("Mark Tran" . "mark.tran@gmail.com") :url "http://github.com/marktran/color-theme-ujelly")
