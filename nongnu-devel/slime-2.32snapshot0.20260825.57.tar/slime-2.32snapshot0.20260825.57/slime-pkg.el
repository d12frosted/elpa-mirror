;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260825.57" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "37530f48dfa52871c632b1783029ab7c7e84bd39" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
