;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.5.0.20261126.8" "A major mode for editing subtitles" '((emacs "25.1")) :commit "6f378602fb115d21f8c18f106bd4041ee1a6b7da" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
