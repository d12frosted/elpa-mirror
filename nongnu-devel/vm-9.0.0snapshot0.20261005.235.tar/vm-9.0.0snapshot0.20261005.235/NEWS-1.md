# VM NEWS, releases through 7.19

Kyle Jones's releases, 4.10 in May 1989 through 7.19 in September 2004.  A
frozen record, kept as he wrote it: the wording, the spelling and the
attributions are his.

Later releases are in NEWS-2.md, 8.0.0 through 8.2.0b1, and NEWS-3.md, 8.3.0
onwards.  There is no file called NEWS: the newest entries are always at the
front of the highest-numbered file, and an older file is never renamed.

## VM 7.19 released (29 September 2004)

* New variables:
  + vm-stunnel-program-additional-configuration-file
* added vm-mouse-send-url-to-safari to send URLs to Safari under
  Mac OS X.
* added docstrings for vm-mime-reader-map-* commands.
* normalized prefix key description layout in vm-mode docstring.
* added some missing MIME commands to menu entries.
* undo change in vm-preview-current-message that required
  vm-auto-decode-mime-messages to be non-nil along with
  vm-display-using-mime before creating the presentation
  copy of a message.  It has the unexpected side-effect of
  breaking 'D' when vm-auto-decode-mime-messages is nil.

## VM 7.18 released (2 November 2003)

* New variables:
  + vm-default-new-folder-line-ending-type
* vm-mail-internal: use idle timers to run vm-update-composition-buffer-name
  instead of post command hooks
* vm-decode-mime-layout: always delete a MIME object button after
  doing a type conversion.
* vm-mail-send: bind coding-system-for-write to match the coding
  system of mail-archive-file-name (if set) so that mail-do-fcc
  writes to the file using the correct line endings.
* vm-make-tempfile-name, vm-make-tempfile: accept optional
  second argument 'proposed-filename' which will be used if a
  file with that name do not exist in vm-tempfile-directory.
  If such a file exists, then a number and a dash will be prepended
  to the proposed filename and the number will be incremented until no
  such file exists.
* don't use vm-menu-fsfemacs-image-menu unless vm-use-menus is non-nil.
* vm-preview-current-message: require vm-auto-decode-mime-messages to
  be non-nil along with vm-display-using-mime before creating the
  presentation copy.  This helps prevent selection of the presentation
  buffer when the user likely needs to do M-x recover-file.

## VM 7.17 released (6 July 2003)

* New commands:
  + vm-create-imap-folder
  + vm-delete-imap-folder
  + vm-rename-imap-folder
* vm-edit-message-end: try to positoin the cursor in the message
  window roughly where it was in the edit window.
* vm-read-imap-folder-name: allow vm-imap-make-session to return
  nil without crashing.  Also, bind vm-imap-ok-to-ask non-nil so
  that vm-imap-make-session will interactively prompt for a
  password.
* added menu entry to Folder menu for vm-visit-imap-folder.
* vm-imap-normalize-spec: convert auth method to * instead of the
  IMAP folder name.
* vm-imap-get-message-flags: fixed flag retrieval so that it
  actually works now.
* vm-handle-file-recovery-or-reversion: find an IMAP spec for the
  buffer so that the spec is passed to the 'vm' command instead
  of the buffer-file-name.  This fixes a wrong-type-argument
  error under M-x recover-file when done on a IMAP cache folder.
* tapestry.el: in tapestery-window-edges check for existence of
  face-width and face-height in addition to window-pixel-edges.
* search for BASE64/QP encoder/decoder programs and set the
  encoder/decoder program variable based on what we find.
* vm-mf-default-action: if object is convertible to a displayble
  type mention the conversion that will happen in the action
  string.

## VM 7.16 released (26 May 2003)

* New commands:
  + vm-visit-imap-folder
  + vm-visit-imap-folder-other-window
  + vm-visit-imap-folder-other-frame
  + vm-save-message-to-imap-folder
* New variables:
  + vm-imap-server-list
* vm-primary-inbox can now be a POP or IMAP mailbox specification.
* vm-mime-set-xxx-parameter: use the parameter name passed in
  instead of assuming the name is "charset".  The only calls to
  this function passed in "charset" as the name, so this bug
  wasn't affecting anything.
* vm-decode-mime-encoded-words: do charset conversion if needed.
  Forgot to add this back when vm-mime-charset-converter-alist
  was added.
* vm-send-mail-and-exit -> vm-mail-send-and-exit in vm-user-agent
  definition.
* vm-mail-send-and-exit: dropped first arg requirement since the
  argument isn't used anyway.
* compute POP cache filenames based on the POP mailbox spec with
  the access method as "pop" and the authentication method and
  port as asterisks.  This prevents visiting the wrong file if
  the user starts accessing a POP mailbox through a different
  port or using a different access or authentication method.
  Automatically migrate the old cache files to the new scheme as
  we go.
* fixed convert -page typos.
* vm-set-redistributed-flag: fourth arg of vm-set-xxx-flag
  call corrected to be vm-set-redistributed-flag instead of
  vm-set-forwarded-flag.
* IMAP BYE responses are always untagged; changed code to match.

## VM 7.15 released (3 May 2003)

* Makefile: filter echo's output through tr to avoid CRs
  under Cygwin.
* Makefile: Use '>' instead of '>>' on first write to vm-autoload.el
  to truncate the file otherwise it will grow each time it is updated.
* vm-mime-attach-message: arrange for forwarded flag of each
  attached message to be set when the composition is sent.
* when cropping images call 'convert' with -page to avoid having
  some kind of margin tacked on to the image.  The strange
  margin seems to be applied to GIFs but not JPGs.  No idea why.
* fixed some defcustom variable declarations.
* vm-mime-reader-map-save-file: return the file name to which the object
  was saved.
* vm-mime-burst-digest: remove blank lines at the beginning of
  message/rfc822 bodies in a multipart/digest object, since they
  most likely indicate an improperly packed digest rather than a
  message with no headers.
* vm-make-tempfile: use vm-octal to clarify file mode setting.
* vm-make-image-strips: when building the script for incremental
  display, don't quote the filenames.  DJGPP cmdproxy.exe doesn't
  interpret single quotes and using double quotes is pointless.
  VM's arguments to 'convert' don't need quoting anyway.
* use vm-pop-check-connection to check POP connections before
  trying to read data from them.  The checker will signal an
  error if the connection is closed or the process associated
  with the connection has exited.
* use vm-imap-check-connection to check IMAP connections before
  trying to read data from them, The checker will signal an error
  if the connection is closed or the process associated with the
  connection has exited.

## VM 7.14 released (27 March 2003)

* moved (provide ...) to bottom of .el files.
* Made the vm-undo command undo everything the last command did.
  E.g. vm-undo after vm-kill-subject undoes all of the related
  deletes instead of just one of them.  vm-undo-boundary is only
  called from vm-add-undo-boundaries now.  vm-add-undo-boundaries
  is called from post-command-hook.

## VM 7.13 released (19 March 2003)

* '(vm-marker -> (vm-marker in vm-mime-parse-entity.

## VM 7.12 released (14 March 2003)

* vm-pop-make-session: use new stunnel configuration code
  introduced in VM 7.11.  This was only installed in
  vm-imap-make-session previously.
* create MIME layout from plist instead of using a raw vector.
  The layout struct is still a vector.
* save original layout when doing a layout conversion so that if
  the object needs to be deleted we still ahve the correct object
  endpoint in the folder buffer.  In the old code the endpoints in
  the converted object buffer would be used in the folder buffer
  with disastrous results.

## VM 7.11 released (5 March 2003)

* fixed check for usability of uncompface's -X flag, needed
  symbol to be unquoted.
* fixed check for stunnel 4, check for non-zero exit code instead
  of string, moved check to the time when stunnel is first run.
* vm-stunnel-configuration-args: fixed reversed v3/v4 logic.
* vm-stunnel-configuration-file: reuse the stunnel configuration
  tempfile.
* vm-parse: fourth arg limits the number of matches before
  returning.
* vm-parse: after we quit matching add everything after the last
  match to the list that is returned, but do this ONLY if the
  fourth arg 'matches' was specified.
* compute POP cache filenames based on the POP mailbox spec with
  the password as an asterisk.  This prevents visiting the wrong
  file if the user has the password in the spec and later changes
  their password.  Automatically migrate the old password-based cache
  files to the new scheme as we go.
* vm-pop-make-session: parse POP mailbox spec in a way that
  permits colons in the user's password.
* install .el files before .elc files to avoid "source file newer
  than compiled file" problems.
* added ] to char class exclusion in mailto spec in vm-url-regexp
  to help with MS EXchange's [mailto:foo] syntax.

## VM 7.10 released (5 March 2003)

* vm-menu-url-browser-menu: add third element to clipboard and
  Konqueror entries--- VM's menu code under GNU Emacs requires it.
* treat device-type `gtk' like `x' under XEmacs so that
  VM running on GTK-XEmacs will use window system features.
* vm-imap-move-mail: set use-body-peek after retrieving the
  CAPABILITY results. (oops)
* Makeflie: default install target now installs the .el files.
* added support for version 4 of stunnel.

## VM 7.09 released (3 March 2003)

* New variables:
  + vm-mime-forward-local-external-bodies
* vm-mime-fsfemacs-encode-composition: if object is in a buffer,
  write the buffer out to disk and insert the file contents instead
  of copuying buffer to buffer.  This avoids the trademark \201
  data corruption.
* vm-su-thread-indent: check for vm-summary-show-threads non-nil
  before calling vm-th-thread-indentation.
* vm-summary-compile-format-1: added %(..%) format groups.
* don't forward Content-Length header.
* use results of CAPABILITY command to check for authentication methods
  before trying to use them.
* use results of CAPABILITY command to decide whether to use
  BODY.PEEK vs. RFC822.PEEK.
* vm-mime-attach-object-from-message: move window point to
  beginning of the line after the inserted attachment if the
  compositoin buffer is being displayed in a window.
* vm-mime-parse-entity-safe: set c-t-e to "7bit" if it is nil.
* vm-mime-fetch-url-with-programs: erase the work buffer between
  tries of various URL fetch programs; this handles the case
  where an URL fetcher outputs part of the data and then dies.
* added support for the `fetch' and `curl' URL fetch programs for
  message/external-body.
* vm-mime-fsfemacs-encode-composition: call vm-mime-parse-entity
  twice for already MIME'd objects.
  vm-mime-xemacs-encode-composition similarly modified.
* vm-mime-fsfemacs-encode-composition: don't automatically
  base64-encode non-composite non-text objects that already have
  MIME headers.  Use vm-mime-transfer-encode-layout on them
  instead to produce the correct encoding.
  vm-mime-xemacs-encode-composition similarly modified.
* dropped support for url-w3 retrieval method.  It's interface too
  crusty to continue using given the wide availabity of external
  programs that do the job.
* vm-mime-display-internal-message/external-body: pulled
  retrieval guts out and put into vm-mime-retrieve-external-body.
* added support for simple image manipulations, supported by
  Imagemagick's `convert' program.  Use mouse button 3 on an
  image to see what you can do.
* added Konqueror to vm-menu-url-browser-menu.
* added option to send to the X clipboard to vm-menu-url-browser-menu.

## VM 7.08 released (14 February 2003)

* New variables
  + vm-mime-ignore-missing-multipart-boundary
  + vm-url-browser-switches
* vm-mime-attach-object-from-message: decode object after stuffing it
  into the work buffer.  Two reasons: (1) the composition encoding
  code doesn't expect base64 or QP encoded objects and will encode
  them again, and (2) we shouldn't trust that the original object was
  encoded properly so we should re-encode it since we're sending it.
* vm-mime-display-internal-multipart/alternative: a badly formed
  mesage may cause VM to find no message parts so don't call
  vm-decode-mime-layout unless best-layout is non-nil.
* vm-su-subject: compress \n[ \t]* to a single space.
* README: Added (vm) to the example VM entry in the 'dir' file.
  Apparently the old entry won't work without it anymore.
* vm-mime-parse-entity-safe: error/error MIME layout needs to be
  length 16; added a nil.  Really need to macroize creation
  of the layout object someday.
* vm-recover-file: call recover-file with call-interactively
  instead of apply.
* vm-revert-buffer: call revert-buffer with call-interactively
  instead of apply.
* vm-decode-mime-layout: check if layout has been converted
  and don't try to convert it again if so.
* vm-vs-or, vm-vs-and: check existence of selector function and
  signal error if not found.
* vm-md5-region: accept " -" and " *-" before the md5 checksum
  because md5sum stupidly produces extra output on some systems.
* vm-imap-end-session: trying reading the response to the LOGOUT
  command and see if we start hanging in some environments.
* vm-imap-make-session: don't query for password if the
  authentiation method is "preauth".
* vm-visit-virtual-folder: select the message corresponding to
  the real message the user used as a basis for this folder, if
  there was one.  Only honor the vm-jump-* variables if
  there's no corresponding real message to use.
* vm-compose-mail: run mail-citation-hook or mail-yank-hooks or
  the normal VM default action after yanking the message text.
  Always position point in the body before running the yank
  action.  Don't assume the yank action is smart enough to
  position point correctly before inserting the text.
* vm-recognize-imap-maildrops,vm-recognize-pop-maildrops: changed
  regexp to allow colons in the last field.
* dropped single quotes in const choice values in defcustom for
  vm-mime-alternative-select-method.
* Makefile: use \015 instead of \r with tr due to bug in Solaris
  8's tr which removes r's.
* vm-get-mail-itimer-function: correct use of timer-set-time; set
  new firing time to now + vm-auto-get-new-mail instead of now
  with a delta of vm-auto-get-new-mail, to avoid having
  the timer expire repeatedly in the same second.  Similar change
  in vm-check-mail-itimer-function which support vm-mail-check-interval.
  Similar change in vm-flush-itimer-function which supports vm-flush-interval.
* vm-decode-mime-message: vm-preview-read-messages ->
  vm-preview-lines so that message previewing is turned off for
  the 'raw' and 'all buttons' displays.
* vm-mail-send: bind select-safe-coding-system-function to nil
  during call to mail-send to prevent Emacs from prodding user
  about the FCC coding system.  The coding system used should be
  raw-text and VM sets buffer-file-coding-system to that.
* vm-stuff-attributes: don't clear modflag if stuffing for another
  folder, since the information stuffed in that case is missing
  the deleted flag if that flag was set.
* use defconst to set vm-faked-defcustom so that the checking
  works correctly if vm-vars.el is loaded twice.
* vm-mime-parse-entity: find multipart boundaries, then recurse
  into parts.  This satisfies the new rule in RFC 2046 that outer
  level multipart boundaries be recognized at any level of inner
  nesting.
* vm-mime-send-body-to-file: removed let-binding of variable file
  which was shadowing the function parameter of the same name.
  This should make the function not ask about a filename even
  when one has already been provided.
* define vm-folder-history as a function that returns t so that
  when it is passed as the sixth arg to read-file-name under
  Emacs 21 it does not cause void-function to be signaled when
  completion is attempted.
* vm-mime-send-body-to-folder: force conversion to target folder's
  type since the user doesn't know what type we're using in the
  temp folder.
* vm-save-message: dno't try to honor vm-delete-after-saving if
  the folder is read-only.
* vm-delete-duplicate-messages: compute hash on real folder
  contents rather than virtual copy.  Fixes utterly brokwn
  behavior when run on a virtual folder.

## VM 7.07 released (5 June 2002)

* vm-sort-messages: move first call of
  vm-update-summary-and-mode-line out to callers.  Threading bonks
  if we call it in here.
* vm-assimilate-new-messages: resume calling
  vm-update-summary-and-mode-line to clear the decks before
  thread sorting.
* vm-toggle-threads-display: start calling
  vm-update-summary-and-mode-line to clear the decks before
  thread sorting.

## VM 7.06 released (3 June 2002)

* vm-save-folder,vm-write-file: support vm-default-folder-permission-bits here,
  since a folder might be created when it is saved.
* vm-save-message,vm-save-message-sans-headers: use the target
  folder's line ending coding system for saves.  If the target
  doesn't exist use the local system's default.
* vm-write-string: don't set an explicit coding system for writes,
  use the ambient value.
* vm-sort-messages: call vm-update-summary-and-mode-line to clear
  the decks before sorting.
* vm-mail-internal: UNder FSF Emacs set the coposition buffer
  coding system to 'raw-text' which should stop write-region from
  question the coding system inside mail-do-fcc.

## VM 7.05 released (10 May 2002)

* New variables:
  + vm-default-folder-permission-bits
* Makefile: added install-el target.
* always set mode-popup-menu; it's value should not depend on the
  value of vm-popup-menu-on-mouse-3.
* vm-stuff-folder-attributes: added status messages.
* vm-mime-discard-layout-contents: call vm-set-modflag-of on the
  modified message.
* vm-preview-composition: add a newline at end of the preview
  buffer if the composition lacks one.
* vm-url-decode-buffer: fixed brain-o; bind case-fold-search to t
  instead of nil.
* use new vm-octal function instead of writing out UNIX permission
  bits in decimal.
* defcustom :type fixes.
* added "image" to default value of vm-auto-displayed-mime-content-types.
* vm-mime-should-display-internal: ignore Content-Disposition as
  it has no bearing on whether an object is displayed internally.
* vm-assimilate-new-messages: build threads very early if
  vm-summary-show-threads is non-nil.  Don't run
  vm-update-summary-and-mode-line before sorting threads--- this
  should no longer be necessary thanks to the change to to
  vm-set-numbering-redo-start-point.
* vm-set-numbering-redo-start-point: compare message structs
  instead of list conses.
* vm-unthread-message: only unthread if threads have been built
  in a particular message's buffer.
* vm-thread-list: keep track of the youngest member of a thread.
* vm-sort-compare-thread: sort threads by youngest member instead
  of by oldest member.  Also sort thread siblings by date instead
  of by message-id; sort by messge-id if dates are equal (rare).

## VM 7.04 released (18 April 2002)

* New commands:
  + vm-mime-attach-object-from-message (bound to $ a)
* New variables:
  + vm-mime-ignore-composite-type-opaque-transfer-encoding
* fixed problem with a repeated char being displayed after an
  X-Face when a non-MIME message is reselected.
* Makefile: remove CRs from the output of make-autoloads.  Emacs
  when run under Cygwin apparently emits them.
* vm-session-initialization: create gui-button-face under XEmacs
  if it does not exist.
* vm-mime-display-internal-text/html: don't use W3 if
  vm-mime-use-w3-for-text/html is nil.
* recognize 'mac' as a window system with mouse, image, and
  multi-font support (FSF Emacs only).
* put vm-update-composition-buffer-name on post-command-idle-hook
  instead of post-command-hook if the idle hook is available for
  use.
* vm-menu-vm-menu: added commas to variable refernece so they
  would be evalled in the backquote context.
* changed hook defcustoms to use 'hook instead of '(list function).
* vm-read-index-file: do thread sort if necessary since
  vm-assimilate-new-messages isn't going to do it.
* default vm-thread-obarray and vm-thread-sort-obarray to non-nil
  values so that if they are used as obarrays before
  initialization an error will be signaled.
* vm-mime-pipe-body-to-queried-command: prompt with "Pipe object
  to command:" instead of "Pipe to command:".
* make sure select-message-coding-system is fbound before overriding
  its definition.  Apparently early Emacs 20 versions do not define
  it.
* vm-imap-read-object: move point past closing double quote to
  fix parsing problem that caused VM to hang.
* vm-mime-display-button-xxxx: always insert the button, even we
  have no method for displaying the MIME object.

## VM 7.03 released (4 March 2002)

* fixed defcustom syntax errors.
* minor compiler warning cleanup.

## VM 7.02 released (3 March 2002)

* New variables:
  + vm-uncompface-program
  + vm-icontopbm-program
* display X-Faces under Emacs 21 if necessary support programs
  are available.
* vm-url-decode-buffer: accept lower cased hex digits in escapes
  as per the URL spec RFC.
* map "unknown" charset to iso-8859-1 in
  vm-mime-mule-charset-to-coding-alist.
* dropped use of defmacro in many places in favor of defsubst.
* use backquote macro instead of (list ...) in many places since
  the old objection of differing backquote syntax between Emacs
  versions no longer applies.
* define menu variables using defvar instead of defconst.
* use vm-revert-buffer and vm-recover-file in menus instead of
  revert-buffer and recover-file because the menu-enabled form is
  global for these symbols and VM's form was overriding the one
  in the global Emacs menu.  This problem only occur under FSF
  Emacs.
* use defcustom instead of defvar for most user customization
  variables.

## VM 7.01 released (22 January 2002)

* New variables:
  + vm-mime-use-w3-for-text/html
* new possible values for vm-mime-alternative-select-method:
  (favorite ...) and (favorite-internal ...).
* vm-visit-pop-folder: use value of vm-last-visit-pop-folder if
  interactive user entered an empty string as the folder.
* vm-mail-send: bind sendmail-coding-system to the binary coding
  system and bind mail-send-nonascii to t so that mail-send will
  leave us alone.
* redefine select-message-coding-system if it is fbound and we're
  running FSF Emacs MULE.  It doesn't like no-conversion as a
  coding system, so we get it out of the way.
* define vm-image-too-small properly as an error condition.
* vm-scroll-forward-one-line, vm-scroll-backward-one-line: accept
  a numeric prefix arg.
* vm-setup-ssh-tunnel: use copy-sequence on vm-ssh-program-switches
  to avoid corrupting the list tail with nconc.
* vm-mime-can-convert-0: always return the conversion that
  produces an internally displayable type if there is one.
  Fallback to the externally displayable type if there is none
  that can be displayed internally.
* vm-mime-can-convert-0: don't return a match when the target
  type matches the original type.
* vm-mime-display-internal-image-xemacs-xxxx: wrap image extents
  around spaces instead of newlines.  Adjust newline insertion
  code accordingly.  Create image strips twice the default font
  height to avoid having to match the font ascent value.  Don't
  use vm-monochrome-face except on XBM images.
* vm-display-image-strips-on-extents,
  vm-display-some-image-strips-on-extents: Don't use
  vm-monochrome-face except on XBM images.
* support completion-ignore-case variable.
* block interactive use of vm-expunge-pop-messages in a POP
  folder.  It's meant for folder linked to POP spool files, not
  POP folders.
* use display-planes function to determine if Emacs 21 is running
  on a "colorful" display.
* put image/xpm ahead of image/pbm in vm-mime-image-type-converter-alist.
* vm-parse-date: find year even if it's at the end of line.

## VM 7.00 released (2 December 2001)

* New commands:
  + vm-visit-pop-folder
  + vm-visit-pop-folder-other-window
  + vm-visit-pop-folder-other-frame
* New variables:
  + vm-pop-folder-alist
  + vm-pop-folder-cache-directory
* vm-parse-date: fixed search to allow monthday digits to occur
  at the beginning of a string.
* vm-get-mail-itimer-function: skip buffer if bm-block-new-mail
  is set.  This avoids vm-get-spooled-mail signaling "can't get
  new mail until you save this folder" later.  Also check for
  mail block and folder read-only before doing the expensive file
  stat checks.
* vm-get-image-dimensions: don't search for the filename in
  the 'identify' output.  Apparently 'identify' will sometimes
  substitute a different filename than we expect.  Instead
  just search for a space and then start looking for the image
  dimensions from that point.
* moved setting of vm-folder-type in the POP trace buffer from
  vm-pop-move-mail to vm-pop-make-session so that all callers get
  of vm-pop-make-session get the feature.
* vm-assimilate-new-messages: check for new-messages non-nil
  before attempting some things.  Makes the function a bit more
  efficient if we call it and no new messages are found.
* vm-pop-report-retrieval-status,
  vm-imap-report-retrieval-status: report "post processing" if
  'need' value is nil.
* vm-pop-retrieve-to-crashbox -> vm-pop-retrieve-to-target
* vm-imap-retrieve-to-crashbox: use new "post processing" reporting.
* vm-pop-retrieve-to-target: use new "post processing" reporting.
* vm-expunge-pop-messages: record which messages were expunged by
  stuffing nil into the car of the cell in vm-pop-retrieved-messages.
  At the end strip out all the nils, leaving the data for messages
  that we had problems expunging from the POP server.
* in vm-stuff-* functions check for vm-message-list non-nil
  instead of vm-message-pointer.
* vm-pop-end-session: check whether the process is still open or
  running before attempting to send the QUIT command.  Also check
  whether the process buffer is still alive before killing it.
* vm-get-spooled-mail: gutted, with most of it going into
  vm-get-spooled-mail-normal.  Calls vm-pop-synchronize-folder
  for folders that use the POP access method.
* vm-session-initialization: when deciding whether to create the
  vm-image-placeholder face check for image-type-available-p
  being fbound, not vm-image-type-available-p.
* use <vm-image-face> instead of <face> as the name of the faces
  used to display images under Emacs 19 and 20.
* vm-mime-display-internal-image-xemacs-xxxx: insert a newline
  before the image if point is at the same position as the
  beginning of the text portion of the message.  Otherwise
  there is no visible separation between the image and the
  message headers.
* vm-pop-report-retrieval-status,
  vm-imap-report-retrieval-status: record in the statblob the fact that some
  status was reported.
* vm-pop-stop-status-timer, vm-imap-stop-status-timer: if any
  status was reported, do (message "") to clear the echo area.

## VM 6.99 released (25 November 2001)

* New commands:
  + vm-scroll-forward-one-line
  + vm-scroll-backward-one-line
* New variables:
  + vm-imagemagick-identify-program
  + vm-mime-display-image-strips-incrementally
* vm-do-folders-summary: bind default-directory to the directory
  names when checking for subdirectories amongst its children
  with vm-delete-directory-names.
* vm-get-image-dimensions: use the ImageMagick program 'identify'
  instead of 'convert' to get the image dimensions.
* vm-thread-list: set done to t if we've run out of references
  and we're not threading by subject (vm-thread-using-subject ==
  nil).  Fixes infloop.
* use the vm-monochrome-image face for image glyphs instead of vm-xface
  under XEmacs.
* use a face with a background stipple (vm-image-placeholder)
  on the spaces used to display images in FSF Emacs 19.
* vm-display-image-strips-on-overlay-regions: store modified
  flag value after the process buffer is selected, otherwise
  we're recording the state of the wrong buffer.
* vm-mime-display-internal-image-fsfemacs-21-xxxx: If the image
  strip is the same height as the font the image ascent ratio
  must match font ascent ratio else the image strips will be
  displayed with gaps between them.  There's currently no way to
  get font ascent information under Emacs 21.  Use strips that
  are twice the font height and a 50/50 ascent ratio to avoid
  this problem.
* vm-make-image-strips: remainder math was wrong; fixed.   Use new
  remainder math in the sync branch.  Use vm-make-tempfile
  instead of vm-make-tempfile-name.
* when cutting images into strips give 'convert' an explicit
  target type.  Otherwise it might choose some unknown new type
  that Emacs can't display.
* vm-parse-date: simplified the search for the monthday and the
  year, hopefully reducing the problems with confusing 2-digit
  years and monthdays.
* vm-thread-list: check and set 'oldest-date property on all the
  messages.
* vm-mail-internal: eval the value of mail-signature and insert
  the result if its value is not nil, t or a string.  Also, if
  mail-signature is a string, subject the result to the same
  check for a proper signature separator.

## VM 6.98 released (18 November 2001)

* New variables:
  + vm-mime-use-image-strips
  + vm-imagemagick-convert-program
  + vm-w3m-program
  + vm-mime-charset-converter-alist
* inline image display support for Emacs 19 and Emacs 20.
* vm-md5-region: deal with the " -\n" that md5sum appends to the
  checksum output when summing stdin.
* vm-edit-message: set buffer-offer-save to t so that if user
  types C-x C-c they won't lose their changes in the message edit
  session without warning.
* vm-spool-files: remove any directories from vm-spool-files
  that we slurped from environmental variables.  There was a case
  where a user's MAIL variable was set to /var/mail.  I don't know
  how widespread this practice is.
* when initializing vm-temp-file-directory check for C:\TEMP
  before C:\.
* vm-setup-ssh-tunnel: instead of sleeping for a bit and hoping
  that's long enough to establish a connection, read some output
  from the tunnel before returning so we know that the connection
  is established.  vm-ssh-remote-c0mmand has to provide the output,
  so its default value has been changed to produce output.
* vm-frame-loop: don't reset the starting frame placeholder unless
  the starting frame was really deleted.  Fixes an infloop when
  quitting out of VM and the VM summary is visible in multiple
  frames.
* try to use the ImageMagick 'convert' program (if available) to
  convert image types that Emacs can't display internally into
  images that Emacs can display.
* support the unregistered image/xbm, image/xpm and image/pbm
  types, so that we can autoconvert unsupported image types to
  these types under an Emacs that's compiled with minimal image
  support.
* use w3m to retrieve URLs if specified in vm-url-retrieval-methods.
* make layout cache be the property list of a symbol instead of
  an alist.
* use vm-make-tempfile in more places to produce private tempfiles
  instead of vm-make-tempfile-name.
* vm-preview-composition: mnuge message separators that appear in
  the message body.  Use MMDF for the temp folder type.
* all your base no longer are belong to us.

## VM 6.97 released (28 October 2001)

* New variables:
  + vm-mime-require-mime-version-header
* SSL support for IMAP and POP.
* SSH tunnel support for IMAP and POP.
* uninstall toolbar goop from vm-mode-map under FSF Emacs if we're
  creating a frame and vm-use-toolbar is nil.
* don't use a heuristic background map in the toolbar image spec
  for the MIME icon.
* vm-make-tempfile-name: add a random elemnt to VM's temporary
  file name.
* vm-pop-cleanup-region, vm-imap-cleanup-region: don't emit
  CRLF->LF status messages.  Say something about post-processing
  in the normal status message instead.
* vm-mail-to-mailto-url: do session initialization stuff so that
  the function can be called from gnuclient.  This is apparently
  useful for driving VM from a web browser that allows use of an
  external mailer.
* vm-mime-encode-composition: undo buffer changes if an
  error occurs during encoding.
* rename certain composition buffers on the fly as the recipient
  headers change to reflect the new primary recipient(s).
* vm-submit-bug-report: call vm-session-initialization so the all
  necessary goop is loaded, rather than doing a few 'require'
  calls.  This fixed the bug in the VM XEmacs package where
  calling vm-submit-bug-report immediately after starting XEmacs
  would cause (void-function vm-display) to be signaled.
* vm-th-parent: when extracting the parent message ID from the
  In-Reply-To header, use the longest ID found, instead of the
  first ID found.  Store the result in the references slot in the
  message struct, since that slot must be empty otherwise we
  would be ignoring In-Reply-To.
* vm-thread-list: remove the clock skew loop-recovery-point
  heuristic; seems to cause more breakage than it fixes.
* vm-mime-display-internal-image-fsfemacs-xxxx: use a unibyte buffer
  as a work buffer when unpacking an image file.  Apparently needed
  to avoid the evil \201 corruption under Emacs 21.
* accept 'name' parameter as suggested filename for all MIME
  types.  Old broken software that sends this stuff will never go
  away and complaints about it will never end.
* default vm-use-lucid-highlighting non-nil only if (require
  'highlight-headers) doesn't signal an error.
* vm-md5-region: call the MD5 program directly instead of using
  sh -c.
* vm-pop-md5: call the MD5 program directly instead of using
  sh -c.
* vm-check-for-spooled-mail, vm-get-spooled-mail: bind
  case-fold-search to nil for comparisons against vm-recognize-*.
* vm-preview-current-message: do less work if the user will never
  see the message in the previewed state.
* vm-preview-current-message: just MIME decode the headers rather
  than the whole message if vm-preview-lines == 0.
* vm-mime-convert-undisplayable-layout: check exit status of
  command and if non-zero return nil.  Fixed all callers to deal
  with this new reality.

## VM 6.96 released (5 September 2001)

* print-autoloads: handle fset calls.  There are paths through
  the code that reach functions that are to be defined by fset
  but lack autoload definitions.  print-autoloads now creates
  autoload definitions for them.
* vm-mime-encapsulate-messages: pluralization fix in MIME digest
  preamble.  Don't output "messages" if there's only one message in
  the digest.
* vm-display-startup-message: update copyright date.  Use
  \251 under XEmacs to show the c-in-circle copyright glyph.
  Can't rely on FSF Emacs being setup to display it.
* vm-mime-display-internal-application/octet-stream: honor
  setting of vm-mime-delete-after-saving.
* vm-imap-move-mail: don't emit warning messages if BODY.PEEK
  fails--- no one cares.  Don't retry BODY.PEEK after it fails
  the first time, it will never work.  Use RFC822.PEEK henceforth
  within this IMAP session.
* vm-toolbar-support-possible-p: check whether the variable
  tool-bar-map is bound.  Apparently tool-bar-mode is fboun
  even when there is no toolbar support (e.g. under Windows).
* moved guts of vm-discard-cached-data to vm-discard-cached-data-internal.
* vm-mime-attach-message: corrected prompt in the "attach from
  other folder" case.
* vm-summary-sprintf: decode encoded words in the final string if
  we're not producing a tokenized result and vm-display-using-mime
  is not nil.
* vm-mail-to-mailto-url: support full RFC2368 mailto URL spec.
* vm-pop-send-command: use one process-send-string call instead
  of two, which should saves some packet overhead at the
  expense of more string consing.
* vm-imap-send-command: use one process-send-string call instead
  of three, which should saves some packet overhead at the
  expense of more string consing.
* vm-imap-send-command: allow sending a string without a tag.
  Also allow sending a string with a caller specified tag.
* vm-imap-make-session: don't send a tag with the CRAM-MD5
  challenge response.
* vm-do-summary: reuse the mouse-track overlays if possible,
  instead of generating a new one each time.  The old ones
  apparently are never reclaimed by Emacs until the buffer is
  killed and degrade editing performance in that buffer.
* vm-imap-ask-about-large-message: require simple "OK" response
  after fetching headers instead of "OK FETCH".  The "FETCH" part
  may never come and isn't required.
* vm-save-folder: sweep though virtual folder associated with the
  real folder and set their buffer modified flags to nil if they
  are none of their real folders are modified.
* vm-thread-list: don't allow the first and last element of a multielement
  thread list to be the same message-ID.  This is a thread loop that
  previously was previously undetected.
* vm-thread-list: remember the position in the thread list where
  we first threaded using subject information and reset the
  thread list to that point if we encountered a message ID we've
  seen before.  This is a heuristic to try to trim off
  parents-by-subject that are only parents due to clock skew.

## VM 6.95 released (23 July 2001)

* New variables:
  + vm-mime-attachment-auto-suffix-alist
* vm-guess-digest-type: require a line consisting of 30 dashes in
  addition to the 70 dashes line before guessing RFC 1153.
* vm-md5-region: add third arg that prevents re-search-forward
  from signalling an error if it fails.
* vm-toolbar-update-toolbar: don't use the 'getmail' icon
  as the helper button if 'getmail' is already on the toolbar.
* vm-toolbar-update-toolbar: don't use the 'mime icon
  as the helper button if 'mime' is already on the toolbar.
* vm-mime-attach-message: if invoked on marked messages (C-c C-v
  M N C-c C-m) attach the marked messages in the parent folder as
  a digest.
* vm-mail-mode-remove-tm-hooks: remove global TM/SEMI hooks from
  mail-setup-hook and mail-send-hook if vm-send-using-mime is
  non-nil.  Previously VM tried to remove the hooks locally but
  that doesn't work.
* fixed negative Content-Length computation problem
  - vm-find-leading-message-separator,
    vm-find-trailing-message-separator: new type 'baremessage
    means go to point-max.
  - vm-pop-retrieve-to-crashbox, vm-imap-retrieve-to-crashbox: use
    'baremessage as old type during header conversion.  Narrow to
    region around message during this conversion so that folder
    traversal functions can safely go to point-max without moving
    past the end of the message.
* vm-pop-make-session, vm-imap-make-session: don't sleep for 2
  seconds after reporting a bad password unless the function was
  called synchronously, i.e. not from a timer.
* vm-check-mail-itimer-function, vm-get-mail-itimer-function,
  vm-flush-cached-data: when traversing the buffer list, check
  whether a buffer is still alive before selecting it.  Because
  the loop calls input-pending-p, a timer or process-filter could
  have killed one of the buffers.
* vm-delete-duplicate: remove duplicate addresses case
  insensitively  This is still sort of wrong, in that the only
  the right hand side of the address should be treated this way.
  But doing the right thing is hard.
* vm-mime-display-internal-image-xemacs-xxxx: make the image
  extent be 'start-open' so that it is moved forward when text is
  inserted at its position.  This fixes the image doubling
  problem if a mssage containing only an image is previewed with
  vm-mime-deocde-for-preview set non-nil.
* vm-narrow-for-preview: added kludge to prevent images and button
  art from being displayed at the edge of a preview cutoff during
  MIME decode-for-preview.  Everything beyond the cutoff is shifted
  forward one character during MIME preview.  (XEmacs only for now, but
  might be needed for FSF Emacs 21).
* vm-mime-encapsulate-messages, vm-rfc934-encapsulate-messages,
  vm-rfc1153-encapsulate-messages: do a better job of protecting
  MIME headers.  Sort the MIME headers to the top of the message
  then skip past them before applying the user's header filter
  variables.

## VM 6.94 released (9 July 2001)

* in the defconst of vm-menu-mime-dispose-menu, check whether a
  non-string s-expression is allowed as a menu element name
  before trying to use one.  Versions of XEmacs prior to 21.4
  don't allow expressions as item names.

## VM 6.93 released (23 June 2001)

* New variables:
  + vm-folder-file-precious-flag
* added CRAM-MD5 as an authentication method for IMAP.
* vm-su-do-date: interpret 2-digit years in the RFC-822 matching
  case as 20XX if year starts with 0-6.
* vm-rfc1153-or-rfc934-burst-message: skip spaces in addition to
  newlines that occur after a separator line.  A digest has been
  observed with that kind of deformity.
* treat enable-local-eval as we do enable-local-variables--- always
  bind it to nil.
* vm: don't bind vm-auto-decode-mime-messages non-nil during
  initial message preview if it is nil.
* vm-mime-display-internal-text/html: dropped (sleep-for 2).  No one cares
  enough about the "Need W3 to inline HTML" message to wait 2
  seconds afterward.
* added menu entry to allow MIME objects to be converted to
  another type and displayed.  The new type is determined by
  vm-mime-type-converter-alist.
* added koi8-r to vm-mime-mule-charset-to-coding-alist (XEmacs only).
* vm-pop-read-list-response: check for nil return of
  vm-pop-read-response before using return value. 
* vm-pop-read-stat-response: check for nil return of
  vm-pop-read-response before using return value. 
* vm-encode-coding-region: use unwind-protect to make sure (well
  more likely) that the work buffer always gets killed if it has
  been created.
* vm-decode-coding-region: use unwind-protect to make sure (well
  more likely) that the work buffer always gets killed if it has
  been created.
* vm-mime-convert-undisplayable-layout: put object buffer on
  garbage list sooner to make rarer the situation where the
  buffer never gets deleted.
* Makefile: remove function definition of vm-its-such-a-cruel-world
  after it is run.
* vm-md5-region: if vm-pop-md5-program exits non-zero, signal an
  error.  Also if the work buffer is not at least 32 bytes long,
  signal an error.  This prevents naive callers from assumption all is well
  and using a possibly empty string as an MD5 hash.
* vm-md5-region: check the MD5 digest returned for non-hex-digit
  characters and signal an error if any are found.
* vm-get-file-buffer: use find-buffer-visiting if it is fbound.
* vm-build-threads: fixed loop that removed child messages from a
  parent when better information about a child's parent is found.
  Previously the loop attempted to remove the same message from
  the parent over and over.
* vm-build-threads: gather thread data using References and
  In-Reply-To for all messages before using the Subject header.
  This helps prevent the case where References says A is the
  parent of B but because of clock skew B is older than A, which
  can lead to B being considered the parent of A if A and B have
  the same subject and vm-thread-using-subject is non-nil.

## VM 6.92 released (11 March 2001)

* vm-imap-check-mail: throw to 'end-of-session instead of 'done.
  Fixes problem of vm-spooled-mail-waiting not being set.
* vm-su-do-recipients: If there is no To or Apparently-To header,
  use Newsgroups if available.
* vm-mime-display-external-generic: use a unibyte temp buffer for
  base64 decoding if using FSF Emacs MULE.  Otherwise our old
  friend \201 crashes the party.
* vm-mime-find-leaf-content-id-in-layout-folder: add missing
  layout argument to vm-mime-find-leaf-content-id.
* vm-mime-parse-entity: fixed regexps that match an empty content
  description so that they match descriptions that only contain
  spaces.
* vm-su-do-date: make +/- mandatory in the numeric timezone spec.
  First digit of numeric timezone spec must be 0 or 1.
* vm-fill-paragraphs-containing-long-lines: ignore errors generated
  by fill-paragraph.
* moved the code that catches the font-lock search bound error
  from the XEmacs MIME composition encoder to the FSF Emacs
  encoder.
* vm-mime-charset-internally-displayable-p: allow variable
  vm-mime-default-face-charsets to apply to MULE-enabled Emacs
  and XEmacs.

## VM 6.91 released (1 March 2001)

* vm-mime-can-display-internal: check charset to verify that we
  can display it when checking text/html.
* vm-auto-archive-messages: hide value of last-command when calling
  vm-save-message.
* vm-mime-find-leaf-content-id: removed second arg in call to
  vm-mm-layout-id since it only accepts one argument.
* vm-mime-transfer-encode-region: \\n -> \n in armor-dot check
  regexp string.
* vm-mime-parse-entity-safe: dropped (sleep-for 2).  No one cares
  about syntax errors.
* vm-mime-base64-encode-region: if call to base64-encode-region
  fails with wrong-number-of-arguments error call it with only
  two args and do the B encoding cleanup separately.
* vm-mime-base64-decode-region: don't use the FSF Emacs base64
  decoding function, since it fails completely if it encounters
  characters outside of the BASE64 alphabet.
* vm-mime-attachment-auto-type-alist: added the usual PDF,
  Quicktime and Excel file extensions.
* vm-imap-move-mail: trying using obsolete RFC822.PEEK if
  BODY.PEEK fails.
* vm-imap-retrieve-to-crashbox: support use of obsolete RFC822.PEEK.
* vm-so-sortable-datestring: use vm-timezone-make-date-sortable
  instead of the bare timezone-make-date-sortable, which is less
  capable of parsing badly formed Date headers.
* vm-mime-convert-undisplayable-layout: save the content type
  parameters from the old type and give them to the new type.
* all your base are belong to us

## VM 6.90 released (9 January 2001)

* vm-compose-mail: Use apply instead of funcall to call the yank
  action.  We aren't passing a list of arguments to the function.
* vm-mark-or-unmark-messages-same-author: compare author
  addresses case insensitively.
* vm-emit-eom-blurb: ignore case when matching against
  vm-summary-uninteresting-senders to match what
  vm-su-interesting-from does.
* vm-mime-display-internal-text/html: use 'message' to display
  any errors encountered.
* vm-mime-display-internal-text/enriched: use 'message' to display
  any errors encountered.
* vm-yank-message: call vm-decode-mime-encoded-words in the correct buffer.
* default value of vm-auto-center-summary changed from nil to 0.

## VM 6.89 released (22 December 2000)

* vm-yank-message: MIME decode the headers of the yanked message
  if vm-display-using-mime is non-nil.
* vm-forward-message: if MIME forwarding, switch the buffer
  containing the attached message to be multibyte to avoid the
  appearance of our old friend \201 when the buffer contents are
  inserted into the composition buffer.  (FSF Emacs 20 only).
* vm-do-folders-summary: count messages in folders that lack
  entries in the folders summary database using vm-grep-program.
* vm-do-folders-summary: ignore index files in the folder directories.
* vm-update-folders-summary-highlight: use intern-soft instead of
  intern, since the symbol may not be present in the obarray.
* vm-mark-for-folders-summary-update: check for killed summary
  before selecting folders summary buffer.
* vm-emit-eom-blurb: bind vm-summary-uninteresting-senders-arrow
  to "" around call to vm-summary-sprintf.
* Makefile: Start using $(prefix) to be more GNUish.  Try to
  create the installation directories if they don't exist.
* vm-modify-folder-totals: wrong cells in the list were being
  updated; fixed.
* vm-mime-run-display-function-at-point: return result of calling
  the display function because callers expect it.  This wasn't
  happening in the FSF Emacs part of the conditional.

## VM 6.88 released (11 December 2000)

* New variables:
  + vm-folders-summary-mode-hook
  + vm-grep-program
  + vm-mmosaic-program
  + vm-mmosaic-program-switches
* vm-determine-proper-charset: don't use MULE rules if operating
  in a unibyte buffer.  The non-MULE rules work better in that
  case.  Dropped use of vm-with-multibyte-buffer.
* use BODY.PEEK instead of RFC822.PEEK in IMAP message fetches,
  since RFC822.PEEK has been made obsolete in RFC 2060.
* not decoding for preview if vm-preview-lines == 0 was a
  mistake, as the header might still need decoding, so this
  change was reversed.
* allow 8-bit chars in IMAP atoms.  Microsoft Exchange emits them,
  resistance is futile.
* keep IMAP trace buffer if a protocol error occurs.  Code for
  this was partially done, it's finished now.
* improved folders summary, new folders summary format specifier %s.
* vm-move-to-xxxx-button: fixed code assumption that buttons were
  contiguous.
* qp-encode.c: get rid of non-constant initializers (nextc =
  getchar()) to avoid warnings from Sun's compiler.
* vm-toolbar-fsfemacs-install-toolbar: "mime" now works in
  vm-use-toolbar under FSF Emacs.
* don't display verbose "Waiting for POP QUIT" message unless
  getting mail interactively.
* make vm-thread-loop-obarray a larger hash table.
* use vm-global-block-new-mail to prevent async reentrance into the POP
  and IMAP code.  Use vm-block-new-mail to prevent command-level
  mail retrieval buffer locally.
* vm-check-mail-itimer-function: always check for mail.  Now that
  we're updating the folders summary we need to do the check even
  if we know there is new mail from a previous check, so that the
  summary is kept up to date.
* removed Mule menu from VM's commandeered menubar (FSF Emacs 20 only).
* C-c C-p in composition buffer binding changed from 
  vm-mime-preview-composition to vm-preview-composition.
* vm-sort-messages: fixed paren problem that broke non-thread
  sorting while threading was enabled.
* vm-assimilate-new-messages: don't run vm-arrived-message-hook
  and vm-arrived-messages-hook if being called for the first time
  in this folder.  Old check for this didn't work properly, so
  now first-time status is passed in as a parameter.
* vm-emit-eom-blurb: use vm-summary-sprintf on full name so that
  it is MIME decoded if necessary.
* vm-check-for-spooled-mail: don't skip remaining spool files
  once we know there is mail waiting.  We still need to retrieve
  data for the remaining folders for the folders summary.

## VM 6.87 released (29 November 2000)

* New commands:
  + vm-delete-duplicate-messages
* vm-toolbar-fsfemacs-install-toolbar: fix logic reversal that
  caused Emacs 21 toolbar to never be installed.
* reviewed coding-system-for-{read,write} usage everywhere and
  brought it into line with current theory of how Emacs/MULE
  works.  coding-system-for-write is bound in more places because
  in the Emacs 21.0.91 pretest, write-region, even when called
  non-interactively, will query the user if it doesn't think the
  buffer's coding system can be used to safely write out the
  data.
* vm-mail-to-mailto-url: vm-url-decode -> vm-url-decode-string.
* vm-move-to-xxxx-button: next-etent-change -> next-extent-change.
* vm-move-to-xxxx-button: dropped point movement outside the loop
  as it wasn't needed and actually broke things.
* vm-add-or-delete-message-labels: don't cycle through the
  message list if there are no labels to act upon.
* vm-add-or-delete-message-labels: return a list of labels that were
  rejected because they are not known.  vm-add-existing-message-labels
  expects this and it apparently hasn't been done in a long time.
* call base64-encode-region and base64-decode-region only if they
  are subrs.
* vm-check-for-spooled-mail: save-excursion around the guts
  of the let form that binds vm-block-new-mail to avoid the
  restore-the-wrong-local-variable bug.
* vm-get-spooled-mail: save-excursion around the guts of the let
  form that binds vm-block-new-mail to avoid the
  restore-the-wrong-local-variable bug.
* vm-determine-proper-content-transfer-encoding: changed search
  for non-ASCII chars from [\200-\377] to [^\000-\177] because FSF
  Emacs 20 re-search-forward does not match 0200-0377 unibyte
  chars in multibyte buffers.  They only match in unibyte buffers.
* vm-unbury-buffer: wrapped call to switch-to-buffer in condition-case
  in case it fails (dedicated window, minibuffer window)

## VM 6.86 released (26 November 2000)

* New variables:
  + vm-pop-read-quit-response (default value is t)
* reversed coding system changes introduced in VM 6.85 in
  vm-line-ending-coding-system and vm-binary-coding-system, as
  they were wrong.
* vm-minibuffer-complete-word: use minibuffer-prompt-end
  function to determine where the prompt ends instead of
  previous-property-change.
* vm-toolbar-fsfemacs-install-toolbar: use xbm images if the
  display is not color-capable.
* vm-toolbar-fsfemacs-install-toolbar: don't use "mime-colorful"
  as a basename when looking for an XBM for a non-color display.
* vm-toolbar-make-fsfemacs-toolbar-image-spec: use ":mask
  heuristic" to make the toolbar pixmap/bitmap backgrounds track the
  background of the tool-bar face.
* vm-mime-base64-encode-region: when using base64-encode-region
  wrap it in a condition-case to catch errors and resignal all
  errors with vm-mime-error.
* vm-mime-base64-decode-region: when using base64-decode-region
  wrap it in a condition-case to catch errors and resignal all
  errors with vm-mime-error.
* getmail-xx.xbm was a PBM file.  No one noticed.  Fixed.
* check for vm-fsfemacs-p before using overlay-put, overlay-get,
  etc. in the extent/overlay compatibility functions.  We can't
  use the overlay emulation package's functions because VM needs
  the functions to be able to handle plain extents also.
* vm-mime-fsfemacs-encode-composition: catch the "Invalid search
  bound (wrong side of point)" error that font-lock can throw and
  ignore it.
* vm-set-window-configuration: delete windows that are over
  explicitly named buffers.  This is meant as an aid to BBDB
  users who might want to include a BBDB window in a
  configuration but don't want the window to appear unless the
  displayed buffer is non-empty.
* install the toolbar only once under FSF Emacs, since it will
  appear everywhere vm-mode-map is used thereafter.
* panic buffoon's color changed from rgb:ff/7f/ff to rgb:e1/92/46 (tan).

## VM 6.85 released (23 November 2000)

* New commands:
  + vm-move-to-previous-button
  + vm-move-to-next-button
* vm-end-of-message, vm-beginning-of-message: wrap vm-save-buffer-excursion
  around the part of the function that does window selection since that can
  change the current buffer.  vm-narrow-to-page was noticing the
  buffer change to the summary; vm-message-pointer was suddenly nil.
* made vm-create-virtual-folder, and by effect its callers, honor
  vm-next-command-uses-marks.
* vm-apply-virtual-folder: honor vm-next-command-uses-marks.
* added no-suggested-filename arg to vm-mime-attach-file and
  vm-mime-attach-object.
* vm-preview-current-message: don't decode for preview unless
  vm-preview-lines is non-nil, as this is extra unnecessary work.
* vm-pop-end-session: read POP QUIT response; Microsoft Exchange
  apparently will sometimes not expunge if we close the connection
  without reading the response.
* set reasonable default value for vm-folders-summary-directories.
* vm-preview-current-message: don't block display of any type
  other than message/external-body and externally displayed types
  when supporting vm-mime-decode-for-preview.
* internal image support for v21 Emacs.
* toolbar support for v21 Emacs.
* Makefile: for 'make autoload' compile vm.el into vm.elc instead
  of writing require statements directly into it, otherwise Emacs
  21 bitches.
* vm-binary-coding-system was returning no-conversion under FSF
  Emacs, which is wrong--- it now returns raw-text.
* vm-minibuffer-complete-word: In Emacs 21, during a minibuffer
  read the minibuffer contains the prompt as buffer text and that text
  is read only.  So we can no longer assume that (point-min) is
  where the user-entered text starts so we must compute this
  location.  Calling previous-property-change is a kludge but it
  seems to be the only thing that does the job.
* vm-mime-display-internal-message/external-body: for Emacs 21,
  use a multibyte work buffer, otherwise the evil \201s appear
  in the tempfile and utterly corrupt it.  Also set
  buffer-file-coding-system in the work buffer, since
  write-region may be called in it later.
* dropped use of vm-with-unibyte-buffer.  I don't think it is
  needed any longer.
* vm-assimilate-new-messages: only run vm-arrived-messages-hook
  if a new message has arrived.
* use a normal keymap instead of a sparse keymap for vm-mode-map.

## VM 6.84 released (15 November 2000)

* vm-submit-bug-report: mail-user-agent should be a symbol not a
  list--- fixed.
* vm-keep-some-buffers: kill a buffer even if it is modified
  if it's value of buffer-offer-save is nil.
* vm-pop-make-session: if APOP authentication fails, remove the
  saved password just like we do for PASS authentication.
* new variable and function vm-xemacs-file-coding-p tells whether
  XEmacs was compiled with --with-file-coding=yes, which means
  several things need to be treated the same as if MULE were
  enabled.
* when deciding whether to call set-buffer-file-coding-system
  just check fboundp instead of xemacs-mule-p or fsfemacs-mule-p.
  This should help XEmacs-NT+file-coding.

## VM 6.83 released (14 November 2000)

* New variables:
  + vm-page-continuation-glyph
  + vm-folders-summary-database
  + vm-folders-summary-directories
  + vm-folders-summary-format
  + vm-frame-per-folders-summary
* New commands:
  + vm-folders-summarize
* Makefile: moved vm-version.el to the beginning of the SOURCES
  list so that "make debug" doesn't crash on unbound variables.
* vm-narrow-to-page: move to beginning of line only if we're not
  at end of buffer.  If we're at end of buffer, it usually means
  forward-page failed to find a page delimiter and crashed into
  point-max.
* vm-scroll-forward: after calling vm-narrow-to-page move to
  either the new window start or the start of the text section of
  the message, whichever is the greater buffer position.  This
  fixes the semi-broken backward paging over page delimiters and
  fixed the broken forward scrolling over page delimiters after
  scrolling backward through the same message.
* vm-narrow-to-page: use overlay/extent to display a "...more..."
  type string at the end of a page.
* vm-scroll-forward: do (sit-for 0) to refresh display early so that
  the end of message notice appears when it should when scrolling
  over page delimiters.
* vm-mime-display-internal-text/html: insert placeholder
  character before end marker before calling w3-region to avoid
  end == start marker squashing problem.
* vm-submit-bug-report: reporter-submit-bug-report apparently
  dropped support for the variable reporter-mailer in favor of
  using mail-user-agent instead.  Bind this variable as well the
  old one so bug reporters can send attachments.
* vm: don't decode MIME if recover-file is likely to happen,
  since recover-file does not work in a presentation buffer.
* vm-mail-to-mailto-url: decode URL before handing it to
  vm-mail-internal.
* vm-mime-compile-format-1: removed code to decode and reencode
  MIME encoded words, since these aren't needed in MIME button
  format tags.
* give up on disabling font-lock around attachments.  font-lock
  users will just have to lose, because I don't see a clean way
  to do it.  Removed futile atemptes from code.
* vm-preview-current-message: don't MIME decode for preview if
  vm-preview-lines == 0 since it's pointless in that case.
* vm-select-folder-buffer: make folder buffer selection
  mandatory, generate error otherwise.  New function
  vm-select-folder-buffer-if-possible is to be used for
  situations where buffer selection is not mandatory.
* moved vm-totals computation out of vm-emit-totals-blurb and into a
  separate function.
* vm-expunge-folder: increment vm-modification-counter in the
  real folder buffers to invalidate vm-totals.

## VM 6.82 released (10 November 2000)

* New variables:
  + vm-url-retrieval-methods
  + vm-wget-program
  + vm-lynx-program
* access-type=url support added for message/external-body.
* vm-visit-virtual-folder: call vm-fsfemacs-nonmule-display-8bit-chars.
  This needs to be done for the same reasons as it needs to be done
  in 'vm'.
* provide keymap prompt for # and ## (XEmacs only, unfortunately).
* vm-truncate-string: fixed to once again support a negative width
  argument, even if we're using char-width.
* vm-mime-get-xxx-parameter: don't inadvertently truncate parameter
  value at newline.
* vm-string-width: don't use Emacs 20's string width--- it
  ignores buffer-display-table and thereby hoses the summary.
  Using char-width on each character and summing the reuslt
  gives the answer we want.
* vm-decode-coding-region: compute old region size based on the
  source buffer rather than the work buffer, since they might
  have different unibyte/multibyte status.
* vm-decode-coding-region: reverse order of insert/delete
  sequence at the end to delete then insert.  It fixes the
  parsing of this header
     From: "Cajsa Ottesj=?ISO-8859-1?B?9g==?=" <cajsao@ling.gu.se>
  Apparently if ö is inserted before \366 in a multibyte buffer,
  Emacs believes that the two characters are one character and
  moves point forward past the \366.  This loses because the \366
  needs to be deleted.
* vm-flush-cached-data: stuff last-modified, pop-retrieved and
  imap-retrieved lists.
* vm-pop-move-mail: if we retrieved something, call vm-stuff-pop-retrieved.
* vm-imap-move-mail: if we retrieved something, call vm-stuff-imap-retrieved.
* vm-mime-display-internal-text/html: pass charset name to
  vm-mime-charset-decode-region instead a layout.
* vm-mime-display-internal-text/enriched: pass charset name to
  vm-mime-charset-decode-region instead a layout.
* vm-menu-mime-dispose-menu: convert extent or overlay into a
  layout before using layout functions on it.
* vm-mime-send-body-to-folder: put leading and trailiing message
  separators around the message in the temp folder.
* vm-mime-send-body-to-folder: clear buffer-modified flag before
  entering vm-mode.
* call the mime-reader-map save functions from the dispose menu
  instead of the low-level functions, so that
  vm-mime-delete-after-saving is honored.
* vm-mime-can-display-internal: add 'deep' flag, which indicates
  whether to check the subobject of a message/external-body
  object.
* vm-mime-display-internal-multipart/alternative: use the new 'deep'
  flag of vm-mime-can-display-internal.

## VM 6.81 released (7 November 2000)

* vm-menu-mime-dispose-menu: take car of vm-mm-layout-type to get
  type. (oops)
* vm-mime-display-internal-text/html: set end position after
  inserting the MIME body (oops).
* vm-mime-display-internal-text/html: charset decode the body
  after inserting it.
* vm-mime-display-internal-text/enriched: set end position after
  inserting the MIME body (oops).
* vm-mime-display-internal-text/enriched: charset decode the body
  after inserting it.

## VM 6.80 released (6 November 2000)

* vm-scroll-forward: set window start to point-min if we just
  exposed a hidden message window and we're transitioning frmo
  previewing to showing a message.  This fixes the buggy window start
  marker drift caused by replacing unibyte chars with multibyte
  chars (typically with decode-coding-region).
* vm-fsfemacs-nonmule-display-8bit-chars: dropped use of
  standard-display-european and its attendant disp-table.el
  in favor of directly creation and manipulation of display
  tables.
* vm: call vm-fsfemacs-nonmule-display-8bit-chars to rectify
  8-bit char width conflct between summary and folder buffers and
  to display undeclared 8-bit chars "properly" in the folder buffer.

## VM 6.79 released (5 November 2000)

* vm-make-presentation-copy: force use of multibyte presentation
  buffer.  Otherwise non-ASCII characters won't be displayed
  properly.  (FSF Emacs 20 only).
* vm-summarize: force use of multibyte summary buffer.  (FSF Emacs 20 only).
* vm-truncate-string: use char-width to determine a character's
  display width when truncating a string.
* use vm-truncate-roman-string instead of vm-truncate-string in
  various places that don't encounter non-Roman strings.  (For
  speed.)
* create vm-string-width to compute width of strings that might
  contain glyphs with a column width > 1.  Use this function in
  various summary formatting functions.
* vm-assert: use let to bind debug-on-error to t instead of
  setting it permanently with setq.
* turned on 8bit character character display in summary for
  non-Mule FSF Emacs.
* vm-mime-charset-decode-region: add a face extent or a face text
  property to a charset decoded region so that non-MULE XEmacs
  and FSF Emacs can display non-ISO-8859-1 chars in the summary.

## VM 6.78 released (5 November 2000)

* vm-save-message-sans-headers: if target file looks like a mail
  folder, ask the user if they really want to append to it.
* vm-mime-base64-encode-region: when using Emacs' base64-encode-region
  break long lines unless doing B-encoding.
* vm-mime-base64-encode-region: fixed indentation error that
  moved kill-buffer outside the unwind-protect form, which hosed
  the return value of the function.
* vm-decode-coding-region: mend MULE mangled end marker by an
  explicit set-marker call, since nothing else seems to work.
  Make other functions use this fixed marker as a reference so
  that they don't forget where they are.
* vm-decode-mime-encoded-words: (goto-char end) after calling
  vm-mime-charset-decode-region because decode-coding-region screws
  with point and otherwise we will miss encoded words because of
  this screwage.  Same fix applied to vm-decode-mime-message-headers.
* vm-mime-can-display-internal: indicate that we can handle
  message/external-body internally.
* vm-mime-display-internal-message/external-body: deal with the
  possibility that the specified access method is unsupported---
  cleanup properly and return nil.
* vm-decode-mime-layout: deal with the possible failure of a
  message/external-body object to be retrieved.  It needs to be
  treated differently than a local object.  Offering to save it to
  disk is useless.  Either display a button or prevent the
  existing button from being removed.
* new 'x' specifier for vm-mime-button-format-alist.
* vm-mime-display-internal-message/external-body: fixed reversed
  anon-ftp/ftp logic where the user name would be requested for
  anon-ftp and set to "anonymous" for normal FTP.
* vm-mime-display-internal-message/external-body: check for
  ange-ftp-hook-function and efs-file-handler-function being
  fbound to determine if FTP support is available.
* vm-mime-display-internal-message/external-body: catch
  vm-mime-error signals and store error message in display-error
  slot of layout for later display.
* vm-preview-current-message: don't auto-display
  message/external-body when honoring vm-mime-decode-for-preview.
* vm-mime-display-internal-text/plain: drop fancy calculations to
  rectify the end marker's position; vm-decode-coding-region now
  fixes the end marker's position before returning.
* vm-mime-display-internal-text/html: drop fancy calculations to
  rectify the end marker's position; vm-decode-coding-region now
  fixes the end marker's position before returning.  Hopefully
  w3-region won't scramble the marker position... we'll see.
* vm-mime-display-internal-text/enriched: dropped use of
  vm-with-unibyte-buffer.
* vm-decode-coding-region: use temp buffer for XEmacs also;
  generalize code to work for XEmacs and FSF Emacs.

## VM 6.77 released (2 November 2000)

* changed keybinding of vm-expunge-folder from # to ### so that
  typing it accidentally is less likely.
* '$ w' now does what '$ s' used to do, i.e. saves a MIME object
  to a file.
* '$ s' now saves the MIME object to a mail folder if the object
  is a message, otherwise it behaves like '$ w'.
* added support for MIME type message/external-body.
* fixed duplicated menu titles in Emacs 20.
* use built-in base64 encoding and decoding functions if present
  (FSF Emacs 20 only).
* moved vm-mime-delete-after-saving support out of
  vm-mime-send-body-to-file and into
  vm-mime-reader-map-save-file.
* make-autoloads: recognize defsubst.
* some code changes to make it possible for the mime headers and
  body to be in different buffers.
* vm-mime-find-message/partials: recursively descend composite
  message/* types.
* vm-gobble-crash-box: check if folder buffer is the same as the
  crash box buffer--- if it is, signal an error.
* vm-mime-fsfemacs-encode-composition: turn off font-lock when
  inserting an attached file into the composition buffer.  Ditto
  in vm-mime-xemacs-encode-composition.
* vm-pop-move-mail: ask user about lack of UIDL support, and skip
  folder if the user absolutely wants messages left on server.
* use vm-make-work-buffer to create scratch buffers in many more places.
* save-excursions -> save-excursion
* vm-burst-digest-to-temp-folder: use buffer-disable-undo on the
  temp folder buffer.
* vm-make-work-buffer: always create unibyte buffers.
* vm-mime-Q-encode-region: translate SPC to underscore after
  quoted-printable encoding is done instead of before.
* vm-mime-charset-decode-region: used a wrapped version of
  decode-coding-region (vm-decode-coding-region) if running under FSF Emacs.
  The wrapped version encodes into a unibyte buffer then converts
  the buffer to a multibyte buffer before insert the conrtents
  into the region.  Encoding into a unibyte buffer avoid the \201
  lossage.  Switching to multibyte before inserting into the
  region avoids corrupting some markers.
* vm-mime-display-external-generic: fixed typo that discarded the
  message garbage list and replaced it with the folder garbage
  list.  The result is that MIME messages that invoke multiple
  object viewers will now kill all the viewers when selecting a
  new message.
* vm-preview-current-message: restrict MIME types that are
  auto-displayed when honoring vm-mime-decode-for-preview.  The
  reason for this restriction is to allow a numeric vm-preview-lines
  to remain useful in the face of opaque transfer encodings and
  multipart messages, so we avoid launching external viewers
  until the message is opened completely.
* vm-toolbar-install-toolbar: check for reasonable value of
  vm-toolbar-pixmap-directory before calling vm-toolbar-initialize.
* vm-toolbar-initialize: remove check of
  vm-toolbar-pixmap-directory, which is better done before
  vm-toolbar-initialize is called.

## VM 6.76 released (5 September 2000)

* New variables:
  + vm-movemail-program-switches
* generate a random Message-ID for previewed compositions in case
  the user wants to resend the preview somewhere.
* vm-fix-my-summary!!!: call vm-set-modflag-of on each message
  whose summary we whack so that the summary cache is rewritten
  when the folder is saved.
* vm-sort-messages: if this is not a thread sort and threading is
  enabled, then disable threading and make sure the whole summary
  is regenerated (to recalculate %I everywhere).
* vm-mime-display-internal-image-xxxx: set glyph baseline to 100%
  to add scrolling in XEmacs 21.2.
* vm-generate-index-file-validity-check: set step value to 1 if
  buffer size is smaller than 11 bytes.  Step used to be 0 in
  this case which led to infloop.
* added base64-encode.c, base64-decode.c, qp-encode.c,
  qp-decode.c to the distribution.
* fixed problem in qp-decode.c where lines contain a single
  character followed by newline would have the first character
  dropped.
* vm-display: allow a string as a buffer argument, convert it to
  a buffer internally.
* vm-print-message: don't set the current buffer to be the shell
  output buffer, as this makes vm-set-window-configuration bail
  out early because it wants to be in a VM related buffer.
* vm-pipe-message-to-command: don't set the current buffer to be the
  shell output buffer, as this makes vm-set-window-configuration
  bail out early because it wants to be in a VM related buffer.
* vm-print-message: don't use vm-display to display the shell
  output buffer, use display-buffer instead and only use it if
  the output buffer is not empty.
* vm-pipe-message-to-command: don't use vm-display to display the
  shell output buffer, use display-buffer instead and only use it
  if the output buffer is not empty.
* vm-print-message: use the vm-print-message config instead of
  the vm-pipe-message-to-command config.
* vm-display: don't immediately set current buffer to be the buffer
  to be displayed.  This behavior made vm-set-window-configuration
  bail out early.
* vm-discard-cached-data: call vm-garbage-collect-message before
  flushing message caches.
* look for (fboundp 'w3-about) in addition to (fboundp 'w3-region)
  to determine if text/html can be displayed internally.
* make after-save-hook local in VM folder buffers.
* vm-get-new-mail: make third arg to read-file-name nil, make
  fourth arg t.
* vm-compose-mail: move to point-min before searching for the
  header separator string.
* Removed bad quote in vm-delete-mime-object menu entry.
* vm-match-data: replaced with version that calls match-data to
  figure out the number of valid \(..\) groups.  Emacs 20.4 is
  randomly signaling args-out-of-range if the arg to
  match-beginning exceed the number of internally allocated
  registers in the regexp engine or some such nonsense.
* vm-frame-loop: in the last deletion check, also check the
  delete-me frame with vm-created-this-frame-p before deleting
  it.
* vm-check-index-file-validity: allow for a nil modified time,
  which can occur if the folder is empty.
* generalized vm-keep-mail-buffer into vm-keep-some-buffers and
  made the former call the latter.
* keep POP and IMAP trace buffers if there is trouble making a connection.
* complain to user if APOP authentication is asked for but isn't
  supported.  Previously POP retrieval silently failed.
* vm-reorder-message-headers: For babyl folders, add a newline
  before the EOOH line if header section does not end with two
  newline.
* macroized most uses of coding system constants 'no-conversion
  and 'binary, because 'no-conversion doesn't meant the same thing
  in Emacs and XEmacs.
* vm: if buffer-file-coding-system is nil, set it to 'raw-text.
  (FSF Emacs MULE only).
* removed duplicate (make-variable-buffer-local 'vm-pop-retrieved-messages)
* vm-parse-date: assume 2-digit year specifications < 70 are in
  the 2000's rather than the 1900's.
* vm-mm-encoded-header: bind case-fold-search to t during
  search for encoded words.

## VM 6.75 released (27 August 1999)

* New variables:
  + vm-mail-send-hook
* vm-mime-parse-entity: when checking for a content type of just
  "text" allow for the possibility that there was no content-type 
  header at all.
* use XEmacs built-in MD5 support.
* vm-pop-md5: use shell-file-name instead of "/bin/sh".
* formatting and typo fixes in the manual and docstrings
  from will@fumblers.org.

## VM 6.74 released (2 August 1999)

* New variables:
  + vm-mime-external-content-type-exceptions
* vm-mime-parse-entity: quietly treat "text" as a content type as 
  if it were "text/plain" and US-ASCII.
* vm-mime-discard-layout-contents: set m to be the layout's
  message, not the end of the layout's body.

## VM 6.73 released (27 July 1999)

* New variables:
  + vm-mime-decode-for-preview
  + vm-mime-delete-viewer-processes
* vm-mime-display-external-generic: put MIME temp files on the message
  garbage list instead of the folder's garbage list.
* vm-delete-mime-object: copied check for the top-level MIME
  object from FSF Emacs code to XEmacs code since the former is
  the correct check to use.
* vm-mime-discard-layout-contents: discard cached byte and line
  counts of the edited message.
* vm-sort-compare-thread: in the case where root message IDs are
  different, if the message dates are identical, use string-lessp on
  the message IDs to break the tie.  This avoids having different
  messages compare as equal, which makes the sort unstable.
* vm-mime-discard-layout-contents: recompute Content-Length
  header if needed.
* vm-mime-can-display-internal: consider all text types except
  text/html displayable if the character set is displayable.
  For text/html continue to require W3.

## VM 6.72 released (21 May 1999)

* New commands:
  + vm-delete-mime-object
* New variables
  + vm-mime-delete-after-saving
  + vm-mime-confirm-delete
  + vm-mime-default-face-charset-exceptions
  + vm-paragraph-fill-column
  + vm-imap-session-preauth-hook
* removed old, bogus definition of vm-session-initialization from 
  vm.folder.el
* added w32 as another name for win32 as a window system type.
  (FSF Emacs only).
* changed default value of vm-mime-default-face-charsets to
  include iso-8859-1 if running on a tty under FSF Emacs/Mule.
* vm-mime-parse-entity: move binding of case-fold-search to a
  point after the set-buffer call to avoid having the binding
  overriden by a buffer-local value.
* vm-mime-convert-undisplayable-layout: wrap call to vm-mm-layout 
  message in a call to vm-mime-make-message-symbol; a symbol
  needs to be in the struct slot, not the raw message.
* signal an error if mail-alias-file is set and the user is not
  the superuser.
* broke the message ID creation code out of
  vm-mail-mode-insert-message-id-maybe.
* vm-su-do-date: allow a RFC 822 regexp to match a timezone spec
  that lacks the leading plus or minus.
* bind jka-compr-compression-info-list to nil in various place to 
  avoid unwanted compression or decompression of data.
* vm-mime-send-body-to-file: bind jka-compr-compression-info-list 
  to nil instead of func-binding jka-compr-get-compression-info.
* vm-sort-messages: call vm-build-thread-lists (new function)
  which calls vm-th-thread-list on each message in the folder.
  This generates keys that the thread sort needs before the sort
  happens instead of during it.  Fixes thread sorting bugs.

## VM 6.71 released (8 April 1999)

* vm-mime-display-internal-text/plain: get message struct from
  the MIME layout instead of from vm-message-pointer, since the
  latter is utterly the wrong place to find it in this context.
  Also, don't fill if no-highlighting is non-nil.
* vm-add-or-delete-message-labels: propagate label additions in
  virtual folders to the global lists of the underlying real folders.
* bind format-alist to nil around calls to insert-file-contents
  in MIME composition encoding functions.

## VM 6.70 released (21 March 1999)

* New variables:
  + vm-fill-paragraphs-containing-long-lines
* vm-mime-display-internal-text/html: moved the code that rmeoves 
  read-only text properties into the vm-with-unibyte-buffer form.
* vm-make-presentation-copy: bind inhibit-read-only before tryign 
  to modify an existing presentation buffer.  This is to avoid
  stumbling over read-only text properties.
* vm-mime-insert-button: use 'append' instead of 'nconc' to add a 
  keymap parent.  (FSF Emacs only)  This avoids modifying the
  child keymap and creating a circular keymap structure in a
  subsequent call.

## VM 6.69 released (16 March 1999)

* moved code that sets vm-xemacs-p, vm-fsfemacs-p, etc. to vm-version.el.
  Moved other basic feature checking code to vm-version.el.
* Makefile: make sure vm-version gets loaded first, so the
  version/feature checking code is run very early.  Some of it is 
  needed by other modules at load time.
* added keymap for MIME buttons so you can display, save, pipe,
  print from a tty.
* vm-mime-xemacs-encode-composition: use insert-file-contents
  instead of insert-file-contents-literally and see what breaks.
  This will allow EFS to work.
* default value of vm-mime-default-face-charsets no longer contains
  "iso-8859-1" under FSF Emacs/Mule.  8-bit character display as
  octal codes in a unibyte buffer unless standard-display-europeans
  or equivalent is called, and we don't call this function under
  MULE.
* vm-compose-mail: this function is a VM entry point so call
  vm-session-initialization.

## VM 6.68 released (25 February 1999)

* put user specified Netscape switches before the -remote stuff
  in the arg list to Netscape.
* vm-imap-retrieve-to-crashbox: use char-after instead of
  char-before since Emacs 19.34 doesn't have char-before.
* use vm-coding-system-name instead of coding-system-name.  fset
  vm-coding-system-name to coding-system-name if it exists,
  otherwise use symbol-name.  FSF Emacs doesn't have a
  coding system object, so the name is the same as the coding
  system symbol's name.
* vm-determine-proper-charset: wrap the guts of the function in a 
  vm-with-multibyte-buffer form to ensure we're looking at
  characters instead of the raw encoding data when scanning for
  the character sets that are present.
* vm-decode-mime-layout: support the old 'name' parameter when
  supporting vm-infer-mime-types.
* vm-do-reply: don't match vm-subject-ignored-prefix against the
  subject to determine if we prepend vm-reply-subject-prefix to
  the subject or not.  This reverts a change made in VM 6.47.
* vm-mm-layout: call vm-mime-parse-entity-safe instead of
  vm-mime-parse-entity so that we get always get a layout back.
  This avoids a MIME part completely disappearing if we can't
  parse it.
* vm-mime-parse-entity-safe: use type "error/error" for the
  layout returned if the MIME part can't be parsed.
* vm-mime-qp-encode-region: hex encode _ and ? for Q encoding as
  required by RFC 2047.
* vm-mime-send-body-to-file: Func-bind jka-compr-get-compression-info
  to 'ignore' to avoid double compression of saved MIME bodies that
  are already compressed.
* vm-imap-make-session: quote (using IMAP quoting rules) login
  name and password that are sent as part of the LOGIN command.

## VM 6.67 released (7 February 1999)

* vm-mime-parse-entity-safe: pass message and passing-message-only
  flag to vm-mime-parse-entity.
* vm-mime-parse-entity: wrong number of fields in the last layout
  structure fixed.
* make MIME transfer encoding/decoding work buffers unibyte to
  avoid corruption when characters are copied from them.  (FSF
  Emacs only).
* vm-mime-attach-message: store the message to attach in an
  unibyte buffer instead of a multibyte buffer.
* vm-mime-fsfemacs-encode-composition: encode text regions using
  coding system selected from vm-mime-mule-coding-to-charset-alist
  instead of relying on buffer-file-coding-system to be set properly.
* vm-mime-fsfemacs-encode-composition: when handling the attachment
  of a composite object, add MIME header section (if not already
  provided) before parsing and transfer encoding the object.
  vm-mime-xemacs-encode-composition similarly modified.

## VM 6.66 released (5 February 1999)

* New variables:
  + vm-mime-qp-decoder-program
  + vm-mime-qp-decoder-switches
  + vm-mime-qp-encoder-program
  + vm-mime-qp-encoder-switches
* set-file-coding-system -> set-buffer-file-coding-system.
* vm-edit-message: force edit buffer to be unibyte (FSF Emacs
  only).
* vm: force folder buffer to be unibyte (FSF Emacs only).
* wrap parts of various MIME decoding and display functions in
  vm-with-unibyte-buffer so we can work with unwashed 8-bit data
  directly. (FSF Emacs only).
* force some buffers we create to be unibyte buffers to avoid
  conflabulation of 8-bit data. (FSF Emacs only).
* vm-find-trailing-message-separator: point still not moving backward
  all the times that it should be, so go back to ignoring the return
  value of vm-find-leading-message-separator and always moving backward.
* vm-mail-mode-insert-message-id-maybe: use the hostname variable 
  we so carefullly initialized, instead of just using
  (system-name).
* vm-mime-base64-encode-region: if B encoding, strip newlines from 
  the work buffer instead of the buffer region we're converting.
* vm-mime-base64-encode-region: don't emit status message unless
  the region we're encoding is larger than 200 chars.
* vm-mime-parse-entity: new fourth argument that tells the
  function whether to use the message argument for positional
  information or to just use it to struct in the message slot of
  the MIME layout struct.  Same for vm-mime-parse-entity-safe.
  Use this new argument appropriately in various places so the
  message slot gets filled in more places.

## VM 6.65 released (29 January 1999)

* New commands:
  + vm-mime-attach-buffer
  + vm-mime-attach-message
* New variables:
  + vm-subject-significant-chars
* changed vm-url-regexp to recognize file URLs.
* vm-reencode-mime-encoded-words: fixed infloop problems by updating
  pos value to account for the insertion of the =?charset?B? stuff
  at the beginning of the newly encoded region.
* big pile of typo fixes in the manual courtesy of Greg Shapiro.
* changes for Emacs 20 Mule: recognize coding system names, bind
  coding-system-for-read and process-coding-system-alist to get
  binary I/O.
* insert vm-digest-identifier-header-format header into digest
  message created in temp folders created to view multipart/digest.
  Needed to store link to parent message in MIME layout struct to 
  make this happen.
* vm-mime-attach-object: don't set 'mime-object property twice in 
  the FSF Emacs code.
* vm-so-sortable-subject: collapse consecutive whitespace chars
  to a single space after prefix/suffix processing.

## VM 6.64 released (17 January 1999)

* vm-mail-mode-insert-message-id-maybe: (stringp
  'mail-host-address) -> (stringp mail-host-address).
* vm-imap-retrieve-to-crashbox: for From_-with-Content-Length and
  BellFrom_ folders, add a newline to the end of a message if the
  message lacks one.
* vm-mime-display-internal-text/html: third arg to
  remove-text-properties changed to be a plist as the function
  requires.
* new edition of the user manual.
* updated README, new installation instructions for manual,
  mention Web site
* vm-search18.el gone, vm-search19.el became vm-search.el.
* vm-pop-make-session: switched to the trace buffer earlier in
  the function so that MULE coding system is set in correct
  buffer.  Add connection status messages to trace buffer.
* vm-imap-make-session: switched to the trace buffer earlier in
  the function so that MULE coding system is set in correct
  buffer.  Added connection status messages to trace buffer.
* vm-submit-bug-report: use 'vm-mail instead of 'mail for sending 
  bug reports.  Less confusing, and will work most of the time.

## VM 6.63 released (14 December 1998)

* set selective-display to nil in various places in the code
  where write-region and call-process-region (which calls
  write-region) are called to avoid the CR -> LF translation.
* vm-load-window-configurations: added bind of
  coding-system-for-read.
* vm-store-window-configurations: removed binding of
  coding-system-for-read, moved coding-system-for-write binding
  to be ambient only during the write-region call.
* removed all but one of the bindings of inhibit-read-only in the 
  MIME code.
* vm-mime-display-internal-text/html: Added a remove-text-properties
  call to remove read-only text properties.
* vm-mime-attach-object: Don't allow attachment of object to a
  composition buffer that has already been encoded.
* retain IMAP session trace buffer if a protocol error occurs.
* removed vm-iamp-store-failed error definition since it was
  unused.
* 'w' summary format specifier now gives full weekday name.
* vm-mail-mode-insert-message-id-maybe: ensure RFC 822 compliant
  month and day name by indexing the names from an alist instead
  of relying on format-time-string.  format-time-string's output
  can't be trusted for this because of the dubious `locale' stuff
  in the C library.
* for non-Content-Length based From_ types, don't require a year
  >= A.D. 1000 at the end of the From line--- instead only require a
  single digit.  This change to deal with some evil mailer that
  puts a numeric timezone at the end of the line.
* vm-make-presentation-buffer: remove buffer local foreground and
  background colors set in the default face in the presentation
  buffer.
* dropped the Videodrome joke from vm-submit-bug-report.
* vm-mime-fsfemacs-encode-composition: bind
  file-name-buffer-file-type-alist so that a bit-for-bit binary
  file read is assured.  This matters only to NTEmacs.
* vm-mouse-send-url-to-netscape: Netscape 4.05 apparently doesn't
  like the space after the comma in openURL(..., new-window) and
  doesn't create a new window.  So the space has been removed.
* read per-folder IMAP retrieved list at startup... forgot to add
  code to do this.
* accept lower-case hex digits in quoted-printable encoding.
* vm-mime-composite-type-p: assume message/rfc822 and
  message/news are the only composite "message" types.  New ones
  will have to be manually added.
* vm-misc.el: moved macros to vm-macro.el.
* Makefile: Preload vm-macro.el instead of vm-misc.el.

## VM 6.62 released (9 September 1998)

* vm-mouse-send-url-to-netscape: Change commas to %2C to avoid
  confusing Netscape -remote.
* vm-mime-display-external-generic: when searching for %f, ignore 
  %%f.
* vm-decode-mime-layoout: drop rule that causes unmatched text/*
  and message/* MIME objects to be displayed as text plain.
* vm-mime-can-display-internal: don't load W3 just to see if
  w3-region gets bound.  If the user wants to view inline HTML,
  they'll have to either load W3 explicitly or set up an autoload
  for w3-region.

## VM 6.61 released (17 August 1998)

* vm-find-trailing-message-separator: point wasn't being moved
  backward when it should be.  Change check to use the return
  value of vm-find-leading-message-separator.
* vm-build-message-list: add the starting position of the garbage 
  to the garbage warning.

## VM 6.60 released (17 August 1998)

* don't use gray75 to initialize gui-button-face under Windows
  (FSF Emacs only).  Use only primary colors instead.
* vm-find-trailing-message-separator: for From_ folders, don't
  move point backward one char after finding the leading separator
  unless that char is a newline.
* vm-skip-past-trailing-message-separator: for From_ folders
  don't move point forward one character unless we're not at end
  of buffer.
* vm-submit-bug-report: require vm-vars and vm-version modules.
* vm-visit-folder-other-frame: call vm-session-initialization
  even if the command is not called interactively.

## VM 6.59 released (24 July 1998)

* New variables:
  + vm-default-From_-folder-type
* new folder type: BellFrom_.
* vm-mime-display-internal-multipart/alternative: call
  vm-mime-should-display-internal with two arguments, as
  required, instead of one.
* vm-munge-message-separators: if folder type arg is From_, use
  BellFrom_ as type to produce folders that are less likely to be
  misparsed by other mailers.
* quoted vm variables in docstrings in vm-vars.el with ` and '
  for hyper-apropos.  Change previous other uses of `foo' to
  ``foo''.

## VM 6.58 released (21 July 1998)

* fixed typo in vm-mime-fsfemacs-encode-composition; e -> o.

## VM 6.57 released (21 July 1998)

* added a defvar for timer-list in vm-folder.el.
* added defvars for standard-display-table,
  buffer-display-table and buffer-file-type in vm-mime.el.
* added a defvar for mail-personal-alias-file in vm-reply.el.
* added defvars for lpr-command and lpr-switches.
* rewrote text/html inline display function to not need a temp
  buffer, save-excursion, and save-restriction.  Needed because
  w3-region puts markers into the buffer that can't be copied
  out.
* don't auto-create text body attachments that contain all
  whitespace if the attachment will be at the beginning or end
  of the composition.
* vm-imap-retrieve-to-crashbox: munge folder message separators
  so the retrieved messages will be parsed correctly in the
  target folder.
* vm-do-reply: don't use contents of In-Reply-To in generated
  References header unless no References header is present.
* if vm-mime-alternative-select-method is best-internal, consider 
  a MIME object only if the user wants it displayed internally,
  not just if it can be displayed internally.

## VM 6.56 released (14 July 1998)

* vm-get-spooled-mail: set the non-file maildrop flag on each pass 
  though the loop.
* vm-get-spool-mail: restore expand-file-name call on the
  maildrop so that tildes get expanded.
* store/use the same password for IMAP mailboxes on the same host.
* removed greeting block on Cyrus server.
* Shapiro typo fixes.

## VM 6.55 released (13 July 1998)

* vm-mail-mode-insert-message-id-maybe: check mail-host-address
  with stringp instead of boundp before using its value.
* vm-rfc1153-or-rfc934-burst-message: do digest separator unstuffing
  on a per message basis and before message separator munging, so
  that message separators exposed by the unstuffing get munged.
* registered vm-imap-protocol-error as a known error/exception.  Use it.
* vm-check-for-spooled-mail: check spool filename against the IMAP
  template before checking against the POP template, since the
  POP template will match both.
* vm-imap-check-mail: bail early if message count in mailbox is zero.

## VM 6.54 released (13 July 1998)

* first crack at IMAP support.
* New commands:
  + vm-expunge-imap-messages
* New variables:
  + vm-recognize-imap-maildrops
  + vm-imap-auto-expunge-alist
  + vm-imap-bytes-per-session
  + vm-imap-expunge-after-retrieving
  + vm-imap-max-message-size
  + vm-imap-messages-per-session
* use vm-check-for-killed-folder before calling
  vm-select-folder-buffer in a few functions that don't necessarily
  need to select the folder buffer in order to run.
* vm-goto-message bound to M-g.
* vm-find-leading-message-separator: for From_ type folders
  require that end of the leading separator line match
  " [1-9][0-9][0-9][0-9]".  Revisit in eight thousand years.
* rename vm-sprintf to vm-summary-sprintf.  Use alists to store
  compiled formats instead of using symbol property lists.
* vm-mime-xemacs-encode-composition: discard all but Content-ID
  header in already MIME'd objects to avoid header duplication.
  Same for vm-mime-fsfemacs-encode-composition.
* vm-mime-display-internal-text/html: If error signaled, catch
  it, store the error message and return nil.
* more descriptive buffer name for header buffer used when asking 
  about POP retrievals.
* vm-mail-mode-insert-message-id-maybe: try harder to find a
  hostname that has dots in it for the Message-ID header.
* made vm-pop-retrieved-messages a buffer-local variable, as the
  table isn't meant to be shared among folders.
* vm-expunge-pop-messages: use password-less maildrop specs when
  doing comparisons in skip code.  Changed catch tag from 'skip
  to 'replay to more accurately reflect what's happening.
* vm-pop-end-session: delete the trace buffer.
* vm-pop-make-session: generate a new buffer for each session
  instead of reusing the same one.
* vm-expunge-pop-messages: set buffer-read-only to nil in
  trouble-alert buffer before trying to modify erase it.

## VM 6.53 released (29 June 1998)

* vm-mf-default-action: needed car of vm-mm-layout-type to
  extract type string.
* vm-mime-display-button-xxxx: don't display button unless
  there's a defined method for displaying the object.

## VM 6.52 released (28 June 1998)

* New variables:
  + vm-auto-displayed-mime-content-type-exceptions
  + vm-mime-internal-content-type-exceptions
* vm-find-leading-message-separator: for From_ type folders,
  reinstate requirement that there be two newlines before "From "
  message separators.
* renamed vm-mime-should-display-external to vm-mime-can-display-internal.
* added big5 to vm-mime-mule-charset-to-coding-alist
* default value of vm-send-using-mime to always be t instead of
  looking to see if the TM mime-setup feature is present.
* added a newline to the 'end' line of a uuencoded attachment if 
  there isn't one already; this to cope with the usual crocked PC 
  mail readers (may they reek).
* vm-mime-text-description: further identify a text part if it
  has a standard signature in it.
* remove TM hooks from mail mode buffers if vm-send-using-mime is 
  non-nil.
* vm-mime-send-body-to-file: if user enters a directory name, use
  it unconditionally.
* panic buffoon's color changed from rgb:00/df/ff to rgb:ff/7f/ff.
* use user-mail-address function in Bcc header (XEmacs only).
* use user-mail-address variable, if bound in, Bcc headers.
* replaced definition of vm-load-init-file in vm-startup.el with
  the one from vm-folder.el.
* use vm-mime-default-action-string-alist only if VM knows how to 
  display the MIME object.  Fiddle with the strings in the list.
* support foregroundToolBarColor symbol in the 'small' set of
  toolbar pixmaps (XEmacs only).

## VM 6.51 released (15 June 1998)

* don't call make-face if no face support is compiled into Emacs
  (FSF Emacs only).
* enable inline display of text/html again.
* vm-mime-text-type-p: anchor string matches and add a trailing / 
  to assure matching only the correct types.
* more fiddling with newlines around the Content-Description
  header, hopefully getting it right this time.
* correct "Display as Text" MIME menu item.
* vm-mime-charset-internally-displayable-p: check
  vm-mime-mule-charset-to-coding-alist if vm-fsfemacs-mule-p is
  non-nil.

## VM 6.50 released (10 June 1998)

* vm-rename-current-mail-buffer: changed to recognize new default
  composition buffer name introduced in 6.49.
* vm-mime-display-external-generic: append filename when supporting
  COMMAND-LINE form.  Copy program-list since we may need to modify
  it.
* vm-discard-cached-data: set mime layout and mime encoded header 
  slots to nil in virtual messages.
* vm-session-initialization: initialize gui-button-face if not
  already initialized (FSF Emacs only).
* vm-pop-move-mail: check vm-pop-auto-expunge-alist properly;
  defaulting did not work as you would expect.
* enable image and multiple font support for Windows (XEmacs only).
* provide Content-Description headers for text surrounding
  MIME attachments in compositions.
* vm-forward-message: provide Content-Description header for a
  MIME forwarded message.
* use same filename extension as that of the suggested attachment
  filename when creating a tempfile for use by an external MIME
  viewer.

## VM 6.49 released (4 June 1998)

* New variables:
  + vm-infer-mime-types
* vm-pop-check-mail: return nil if UIDL returns an empty list.
* vm-mail-internal: default composition buffer name to "mail to ?"
  instead of "*VM-mail*".
* added '$' to regexps in default value of
  vm-mime-attachment-auto-type-alist.
* new semantics for vm-mime-external-content-types-alist: %-spec
  expansion, shell command line syntax allowed.
* default value of vm-auto-decode-mime-messages changed from nil
  to t.

## VM 6.48 released (1 June 1998)

* New variables:
  + vm-spooled-mail-waiting-hook
  + vm-mime-uuencode-decoder-program
  + vm-mime-uuencode-decoder-switches
* vm-delete-index-file: don't try to delete the file if
  vm-index-file-suffix is not a string.
* show completions if completion-auto-help is non-nil.  Needed to 
  replace car with caar in one place in vm-minibuffer-complete-word.
* vm-startup-with-summary: handle 0 case specially so that a
  negative number is not passed to nth.
* make vm-mime-preview-composition an alias for
  vm-preview-composition, fixing the typo that aliased
  vm-preview-mime-composition instead.
* vm-auto-archive-messages: don't archive messages to the same
  folder that the user is visiting.
* vm-mime-fsfemacs-encode-composition: encode last MIME part from 
  point to point-max instead of point-min to point-max.  (FSF
  Emacs/MULE only.)
* fixed regexp syntax for backslashes in [..] contexts.  Need
  four backslahses for every one to appear in the regexp.
* vm-discard-cached-data: set the mime-encoded-header-flag to nil.
* vm-mime-burst-message: reverse varref and funcall in `or' expression
  to avoid skipping the rest of the vm-mime-burst-layout calls after
  the first successful one.
* vm-check-pop-mail: use UIDL data to determine if messages in the
  popdrop have been retrieved.
* vm-get-spooled-mail: always set vm-spooled-mail-waiting to nil
  after doing a sweep through the spool files, whether mail was
  retrieved or not.  Not really correct but it is what the user
  expects.

## VM 6.47 released (8 April 1998)

* vm-write-string: bind buffer-read-only to nil before
  attempting to modify the buffer.
* vm-auto-select-folder: Do the eval if the cdr of the alist pair
  is anything other than a string, instead of it it is anything
  other than an atom.
* vm-do-reply: match vm-subject-ignored-prefix against the subject
  and don't prepend vm-reply-subject-prefix if there is a prefix
  match.
* vm-buffer-to-label: map presentation buffers to the 'message
  label.
* vm-scroll-forward: raise and select frame before setting window
  configuration.
* vm-frame-totally-visible-p: Consider frame totally visible if
  return value of frame-visible-p is not equal to nil or 'hidden.
* dropped `sender' synonym virtual selectors.
* If prefix arg is given to vm-visit-virtual-folder-* commands, say
  "read only" in the prompt string.

## VM 6.46 released (30 March 1998)

* don't clear Message-ID and Date headers after sending the message.

## VM 6.45 released (29 March 1998)

* New variables:
  + vm-mail-header-insert-date
  + vm-mail-header-insert-message-id
* insert Message-ID header when message is sent, instead of when
  the composition buffer is initialized.  Remove any existing
  Message-ID header before inserting.
* remove any existing Date header before inserting a new one.
* vm-discard-cached-data: thread sort folders that need it one
  time instead of once for each message that has data discarded.
* vm-vs-not: use vm-with-virtual-selector-variables.
* vm-toolbar-mail-waiting-p: return t if vm-mail-check-interval
  is not a number, since we can't determine if mail is waiting.
* drop extra space before single digit day numbers in Date
  headers that are inserted into compositions.
* vm-edit-message: use set-keymap-parent to allow fallback to the 
  major mode keymap after searching vm-edit-message-map.
* vm-emit-eom-blurb: display information about recipients if
  sender matches vm-summary-uninteresting-senders.
* use define-mail-user-agent to setup vm-user-agent.
* vm-create-virtual-folder-same-subject: match subjects with ^$
  regexp if subject is empty.
* vm-create-virtual-folder-same-author: match authors with ^$
  regexp if author is empty (probably not needed).
* vm-build-virtual-message-list: when updating the virtual message
  list of the real message, copy list of virtual messages from
  real message instead of a virtual and potentially unmirrored
  message.

## VM 6.44 released (24 February 1998)

* vm-resend-bounced-message: insert Resent-To header near the top 
  of the composition instead of near the bottom.
* provide second argument to format-time-string for older
  versions of XEmacs that require it.

## VM 6.43 released (18 February 1998)

* only use char-to-int if defined, use identity function
  otherwise.
* 0 prepended to field width means to pad with zeroes instead of
  spaces in vm-summary-format and vm-mime-button-format-alist.
* recognize %T in MIME button format specs.
* vm-mime-find-format-for-layout: fixed typo in fallback format
* always save the POP password in vm-pop-passwords, even if it is
  listed in vm-spool-files.  This is for the sake of
  vm-expunge-pop-messages which typically deals with
  password-less POP specifications.
* use 'highlight extent property for summary mouse tracking,
  instead of mode-motion-hook.  Seems to display considerably
  faster.  (XEmacs only).
* reuse summary mouse tracking extents/overlays instead of
  constantly making new ones.
* removed autoload cookies from vm-easymenu functions.
* vm-mail-internal: add a Message-ID header.
* vm-mail-send: add a Date header if not already present.

## VM 6.42 released (16 February 1998)

* New variables:
  + vm-pop-expunge-after-retrieving
  + vm-pop-auto-expunge-alist
  + vm-mime-button-format-alist
* vm-save-message: don't set vm-last-save-folder if it is non-nil
  and the user selected folder matches what vm-auto-folder-alist
  would have chosen.  Tried to do this in 6.41, but broke the
  setting of vm-last-save-folder instead.
* vm-expunge-pop-messages: typo prngn -> progn.
* vm-expunge-pop-messages: check whether vm-make-pop-session
  returns nil.
* vm-read-attributes: allow header without a label list.  The
  label part of the data in the header was added later and may
  not be in the header of some older folders.
* dropped use of vm-with-virtual-selector-variables in favor of
  using an alist.

## VM 6.41 released (11 February 1998)

* New variables:
  + vm-index-file-suffix
* New commands:
  + vm-expunge-pop-messages
* default value of vm-circular-folders changed from 0 to nil.
* don't issue DELE commands on POP messages when retrieving
  unless POP server doesn't support UIDL.  If server supports
  UIDL, remember what messages have been retrieved and avoid
  retrieving them later.
* vm-save-message: don't set vm-last-save-folder if it is non-nil and the user
  selected folder matches what vm-auto-folder-alist would have
  chosen.
* vm-show-list: sort list before displaying it.
* vm-show-list: display list ordered top to bottom then left to
  right, instead of left to right and then top to bottom.
* bind print-length to nil in some places to avoid truncation of
  Lisp Objects in folder headers.
* vm-mime-encapsulate-messages: use vm-insert-region-from-buffer
  so we're sure to do buffer switch and unnarrowing necessary to
  retrieve the desired buffer contents.

## VM 6.40 released (30 January 1998)

* New variables:
  + vm-mime-7bit-composition-charset
* don't grey-out "Decode MIME" toolbar button after a message is
  first decoded.  Let user use the button to rotate through
  decoding states like the 'D' key does.  This applies only to
  the separate MIME button, not the one that appears as part of
  the `helper' button.
* vm-mark-or-unmark-messages-with-selector: removed extra count
  argument from `message' call.
* vm-build-virtual-message-list: if dont-finalize is set, don't
  set up the location vector or to obarray used to suppress
  duplicate messages.  In particular the latter causing empty
  message lists to be returned since all the messages were
  considered duplicates.
* support foregroundToolBarColor symbol in toolbar pixmaps
  (XEmacs only).
* vm-rfc1153-or-rfc934-burst-message: Use current buffer as
  folder buffer, instead of the buffer of specified message.
* vm-get-new-mail: signal error if we fail to find a folder
  buffer through the normal means.
* sleep for 2 seconds instead of 1 second after "consider M-x
  revert-buffer" message and after a quit is signaled and caught
  in vm-get-spooled-mail.

## VM 6.39 released (20 January 1998)

* New commands:
  + vm-burst-digest-to-temp-folder
  + vm-add-existing-message-labels
* vm-vs-header-or-text: vm-header-of -> vm-headers-of.
* fixed reversed fset definition of vm-vs-sender.
* don't grey-out "Decode MIME" menu entry after a message is
  first decoded.  Let user use menu entry to rotate through
  decoding states like the 'D' key does.
* vm-check-emacs-version: Disallow running under Emacs 20.
* vm-mime-display-internal-multipart/digest: generate summary if
  vm-startup-with-summary says so.  Did the same for
  vm-mime-display-internal-message/partial and
  vm-mime-display-internal-message/rfc822.
* default vm-temp-directory to (getenv "TMPDIR") if result is
  non-nil.
* vm-undo: signal an error if the current folder is read-only.
* vm-minibuffer-complete-word: set start of word to beginning of
  buffers if not doing a multi-word read.
* vm-minibuffer-complete-word: if doing multi-word completion and
  the word before point exactly matches something in the completion
  list and the word also prefixes something else in the completion
  list and last-command eq vm-minibuffer-complete-word, insert
  a space, thereby letting the user complete the word.
* vm-mime-display-internal-text/enriched: Don't assume (car
  errdata) is a string; it usually isn't.  Format error data
  properly.
* vm-print-message: write out the tempfile for the non-MIME lobe
  of the conditional in the code, since it is needed there also.
* vm-read-virtual-selector: raise the selected frame before
  reading from the minibuffer, so the user is less likely to type 
  into the wrong minibuffer window and hose themselves.
* vm-mime-fsfemacs-encode-composition: set coding-system-for-read 
  when inserting a file-based attachment to avoid MULE munging.
  Protect value of buffer-file-coding-system from possible
  changes by insert-file-contents.

## VM 6.38 released (15 January 1998)

* add vm-virtual-selector-clause property to new selectors.
* vm-read-virtual-selector: removed hard coded list of selectors
  that take an arument.  Instead, read arg only for selectors that 
  have a vm-virtual-selector-arg-type property.
* fixed virtual folder numbering/infloop problem introduced in
  6.37.
* vm-mark-or-unmark-messages-with-virtual-folder: Mark virtual
  messages instead of the underlying real messages when current
  folder is a virtual folder.

## VM 6.37 released (29 December 1997)

* Folders menu code: create directories by default in vm-folder-directory.
* added name parameter to vm-create-virtual-folder for use by
  vm-create-virtual-folder-same-author and
  vm-create-virtual-folder-same-subject to avoid regexp-quote
  goop in the modeline.
* make sure the -should-delete-frame variables in vm-mouse.el are
  initialized before use.
* vm-apply-virtual-folder bound to V X.
* added virtual folder selectors for all the attributes that
  vm-set-message-attributes accepts.  Added un- selectors so that 
  simple negations can be used with V C.  Added header-or-text
  selector.  Added aliases for some selector names.
* New commands:
  + vm-toggle-all-marks (bound to M V).
  + vm-mark-matching-messages-with-virtual-folder (bound to M X).
  + vm-unmark-matching-messages-with-virtual-folder (bound to M x).
* vm-update-summary-and-mode-line: copy value of default-directory
  from folder buffer to the summary and presentation buffers.
* report null results in mark commands as "No message marked"
  instead of "0 messages marked".

## VM 6.36 released (19 December 1997)

* vm-yank-message: commented out text/html code.
* added toolbar initialization status message (XEmacs only).
* allow integers in the vm-use-toolbar toolbar specification,
  which represent blank space in the toolbar. (XEmacs only).
* allow for the possibility that lpr-command and lpr-switches
  are unbound.
* restore binding of C-? ; binding the delete keysym doesn't
  affect the delete key on a dumb terminal when running FSF
  Emacs.
* changed semantics of vm-temp-file-directory.  Its value now
  must end with the directory separator character used by the
  local operating system.
* vm-mime-display-internal-text/enriched: catch errors in
  enriched-decode and store it in the MIME layout struct for
  future display.
* New commands:
    + vm-create-virtual-folder-same-subject (bound to V S)
    + vm-create-virtual-folder-same-author (bound to V A)
* vm-write-file: If write-file renames the folder buffer, rename
  the summary buffer and presentation buffer to match.
* vm-mime-can-display-internal: don't assume enriched.el is
  shipped with Emacs.  Assume text/enriched is internally
  displayable only if enriched-mode is fbound.
* vm-mime-fragment-composition: supply the "total" parameter in
  all message/partial parts instead of just the last one.
* only delete the frame used for completion if VM created it.
* vm-fsfemacs-p: Don't insist on v19.

## VM 6.35 released (24 November 1997)

* typo fixes
* Gregory Neil Shapiro's Emacs 20 MULE patches, which inserted
  bindings for coding-system-for-read/write in various places.
* renamed vm-fsfemacs-19-p to vm-fsfemacs-p.
* Bound (control /) to vm-undo, bound backspace and delete
  keysyms to vm-scroll-backward, dropped binding of "\C-?".
* added ;;;###autoload cookies to all VM entry points.
* vm-session-initialization: require 'vm first to make sure the basic
  things are loaded before we try to do anything.
* dropped inline support for text/html.  Too much pain right now.
  Revisit later.
* recognize po:user type spool file and peaceably hand it off to
  movemail.
* vm-mode-internal: install new fucntion vm-unblock-new-mail on
  after-save-hook to allow retrieval of mail after a save of an
  M-x recover-file'd folder.
* vm-pop-make-session: first argument to buffer-disable-undo is
  required under XEmacs 19.14, so provide it.
* Use locate-data-directory if it exists when setting
  vm-image-directory.
* vm-mail-internal: insert an extra newline before the inserted signature
  so the user doesn't have to type one.  (I give.)
* vm-mime-transfer-encode-layout: don't add a
  Content-Transfer-Encoding header unless the encoding type of
  the layout differs from what we require it to be.
* vm-mime-transfer-encode-region: downcase the return value so
  string comparisons don't have to worry about case.  QP encode
  if armor-dot is set.
* vm-print-message: use a tempfile under Windows 95 or NT.
  Apparently the losing print utils there don't understand stdin or
  can't read from it.
* vm-mime-text-type-p renamed to vm-mime-text-type-layout-p.
  The new version of vm-mime-text-type-p checks the type without a
  layout wrapped around it.
* vm-mime-xemacs-encode-composition: For MULE, use binary coding
  system when inserting an attached file if the type of the
  attachment is not a textual MIME type.

## VM 6.34 released (15 September 1997)

* vm: use other frame if folder is visible there.
* vm-auto-archive-messages: don't silently block archival
  attempts to /dev/null; Emacs no longer complains about
  writes to /dev/null.
* vm-toolbar-initialize: add line for 'getmail' button support
  that got omitted somehow.
* vm-multiple-fonts-possible-p: added win32 as a window system
  that supports multiple fonts.

## VM 6.33 released (19 July 1997)

* vm-undisplay-buffer: don't delete frames unless both
  vm-mutable-windows and pop-up-frames are not non-nil.  Loop
  over the remaining windows that display the target buffer and
  make those windows display some other buffer.
* vm-mime-set-extent-glyph-for-type: use a list of instantiators,
  use 'xpm instead of 'autodetect and fallback to [nothing] if
  instantiation fails.
* vm-display-face: use the [nothing] instantiator on ttys.  XEmcas
  only.
* vm-toolbar-install-toolbar: change toolbar size specifier on
  frame even if VM did not create the frame.  This reverses the
  change made in 6.32.
* vm-isearch: call vm-energize-urls to light up the URLs after a
  search completes.
* vm-set-window-configuration: return the window configuration we
  set.  A change in 6.32 caused this not to be done.  This confused
  vm-display which relied on the return value to determine whether
  vm-display-buffer needed to be called.
* don't recognize <URL:...> as an URL if it contains a newline.
* vm-scroll-backward: make argument optional.

## VM 6.32 released (30 May 1997)

* vm-toolbar-install-toolbar: don't change toolbar size specifier
  on frame unless VM created the frame.
* vm-mail-send: move attribute change before possible deletion of
  the buffer due to vm-keep-sent-messages == nil.
* remove references to vm-record-current-window-configuration
  since it is not being used and will never be used.
* vm-mouse-read-file-name-event-handler: don't delete the completion
  frame before reading keyboard input.  This should avoid making
  the user hunt for the frame that contains the correct minibuffer
  window to type into.
* default value of vm-mutable-frames changed to t, and the
  semantics of this variable have been changed to hopefully be
  more like what users expect it to be.
* use cache slot of MIME layout struct as an alist everywhere
  to avoid having display functions confuse each other with their
  different cache entries.
* vm-mime-display-internal-image-xxxx: use device tag lists to have
  a text tag displayed on ttys and the image itself on image-capable
  devices.
* added optional `to' argument to vm-mail commands.
* mouse support changed so that it is installed whenever mouse
  support may be possible instead of only if it is possible on
  the current device..  Significant only under XEmacs currently.
* use multiple frames on ttys, where available.
* vm-scroll-forward: don't scroll if we're auto decoding MIME and
  the message needed to be decoded.
* vm-mail-internal: support mail-personal-alias-file, fall back
  to ~/.mailrc if it is nil.

## VM 6.31 released (11 May 1997)

* vm-toolbar-support-possible-p: don't check device type, install
  toolbar if the 'toolbar feature is present.
* vm-toolbar-initialize: check for device-on-window-system-p
  before looking at device-bitplanes, in case the selected device
  is a tty.
* use '(win) tag sets on toolbar specifiers to prevent toolbars
  from being attached to non-window system frames.
* vm-multiple-fonts-possible-p: conditionalize checks on
  XEmacs/Emacs to avoid looking at the window-system variable
  under XEmacs where it should not be used.
* set scrollbar height only if (featurep 'scrollbar) and under
  XEmacs.  Previously we checked if set-specifier was fbound.
* vm-mime-preview-composition: copy value of enriched-mode to
  the temp buffer so that the MIME encoding code knows what to do.
* set perms to 600 on MIME tempfiles before writing to them.
  There's still a race window where access can be gained to
  such files, but it should be very small assuming NFS is not
  involved.
* added new 'display-error' slot to the MIME layout struct to
  avoid overloading the cache slot... and fixed a bug thereby, due
  to vm-mime-display-external-generic trying to use the contents
  of the cache slot when there was an error message there.
* vm-mime-display-internal-message/rfc822: bind buffer-read-only
  to nil before trying to insert text into the presentation
  buffer.
* vm-burst-digest will now descend into nested MIME layouts to find
  digests to burst.

## VM 6.30 released (28 April 1997)

* vm-mail-send: rename and/or delete the composition buffer before
  trying to make the replied/forward/etc. attribute change, since
  the user might abort that action.  E.g. "... really edit the buffer?"
* changed code to use XEmacs 20.2 MULE variables and functions
  instead of the 20.0 functions.
* treat inlined message/rfc822 like multipart/mixed except we also
  insert the forwarded headers message and decode any encoded
  words in them.
* support enriched-mode in composition buffers.
* replaced some repeated calls to car with varrefs.
* vm-make-presentation-copy: bind inhibit-read-only to disable
  read-only text properties before calling erase-buffer.
* vm-rfc1153-or-rfc934-burst-message: don't insert a trailing
  message separator if we're bursting the first message.
* rewrote vm-menu-support-possible-p to not factor device type
  into its decision.  For a multi-device XEmacs what is not
  possible now might be possible later, so let the menus be
  instantiated even if they aren't necessarily visible on the
  currently selected device.

## VM 6.29 released (23 April 1997)

* default value of vm-honor-mime-content-disposition now nil.
* disable the setting of stack-trace-on-error for now.
* fixed a few places where MIME layout vectors were created with
  too many slots and one place with too few slots.
* Makefile: doc fixes
* Shapiro typo fixes.  

## VM 6.28 released (22 April 1997)

* added status messages for vm-mark-all-messages and vm-clear-all-marks.
* vm-mime-set-extent-glyph-for-type: don't croak on unknown
  types.
* vm-thread-mark-for-summary-update: when skipping already marked
  messages don't skip the part of the loop that moves the list
  pointer forward. :-P
* rerun vm-menu-install-known-virtual-folders-menu after creating 
  on-the-fly virtual folders because the folder menu gets hosed
  by the let-bound value of vm-virtual-folder-alist.
* added hack to vm-mail-send-and-exit to try and improve window
  configuration behavior under XEmacs when vm-keep-sent-messages 
  is nil.
* vm-mime-composite-type-p: don't consider message/partial and
  message/external-body as a composite types.
* fixed nested MIME encoding to check types recursively all the
  way down to make sure the 7bit/8bit rules are followed.
* vm-forward-message: use message/rfc822 instead of multipart/digest.
* vm-send-digest: fixed preamble insert for MIME digests to
  insert into the composition buffer instead of directly into the
  digest buffer.

## VM 6.27 released (16 April 1997)

* vm-mime-rewrite-failed-button: add newline to displayed error
  string.
* vm-menu-goto-event: use event-closest-point instead of
  event-point so that we get locality of point when a click
  occurs over a glyph (XEmacs only).
* vm-mime-display-button-xxxx: say "attempt to display" instead of
  "display", as the button doesn't know if there is a functional
  display function for the type.
* vm-mime-xemacs-encode-composition: dropped calls to
  encode-coding-region for now.  They were screwing up marker
  positions.
* vm-mime-xemacs-encode-composition: protect value of
  file-coding-system from changes when inserting attachment file
  contents.
* vm-mime-display-internal-text/html: don't call w3-region if it
  isn't bound, just set error string and return nil.
* vm-thread-mark-for-summary-update: don't mark if vm-thread-list-of
  slot is nil; use nil in this slot to mean we've already marked
  this message.

## VM 6.26 released (13 April 1997)

* added missing application/octet-stream button display function.
* Shapiro typo fixes

## VM 6.25 released (13 April 1997)

* copied vm-note-emacs-version to vm-menu.el so that it is
  available at load time for use there.
* converted mona stamps to XPMs as XEmacs can't display the GIF versions.
* vm-mime-transfer-encode-layout: mark encoding in transfer
  encoded leaves, forgot this previously (oops).
* default value of vm-mime-ignore-mime-version now t.
* restored vm-xemacs-p, vm-xemacs-mule-p and vm-fsfemacs-19-p
  functions to avoid breaking third party code that rely on them
  being present (sigh).
* dropped vm-mime-attach-mime-file from the vm-mail-mode keymap and
  menu.
* vm-show-list: binding to button release events in XEmacs didn't
  work.  Should probably use mouse-track hooks instead of binding
  keys but until we do that go back to binding button press events.
* vm-mouse-get-mouse-track-string: check whether we're running
  Emacs/XEmacs rather than whether functions are defined to avoid
  using the wrong overlay/extent interface.
* initialize mail-default-reply-to from REPLYTO environmental
  variable if value is nil (used to be if value is t).
* vm: moved call to vm-preview-current-message after the summary
  generatation/display code.  The summary might completely
  obscure the view of the message buffer, so previewing should
  occur after that so that vm-show-current-message knows whether
  the message was visible and therefore also knows whether to
  mark the message as read.
* vm-keep-mail-buffer: don't kill a buffer if it marked as
  modified, even if the number of `kept' messages would be
  exceeeded by keeping it.  Presumably if a buffer is modified
  the user has resumed composing in it and so we should not delete
  it.
* added vm-mouse-send-url-to-netscape-new-window and
  vm-mouse-send-url-to-mosaic-new-window functions for use as
  values of vm-url-browser.
* dropped use of vm-check-for-killed-folder in menubar and
  toolbar enabled-p functions.  We wrap troublesome calls to
  vm-select-folder-buffer in (condition-case ...) now to avoid a
  "Folder has been killed" error from hosing the toolbar/mnunebar
  and XEmacs permanently.
* don't use application/octet-stream's button function for all
  application subtypes.  Added a separate function to be used for
  subtypes other than octet-stream.
* vm-mime-attach-object: if type is nil, use text/plain as the
  type when calling vm-mime-set-extent-glyph-for-type.
* don't fold content-disposition headers if
  vm-mime-avoid-folding-content-type is non-nil.
* don't add an extra newline after the unfolded content-type of the
  last text subpart.
* vm-mime-preview-composition: remove mail header separator after
  the message is encoded since the encoder won't work without it.

## VM 6.24 released (9 April 1997)

* default value of vm-mime-avoid-folding-content-type now t due
  to pervasive broken Solaris sendmail installations that mangle
  the headers of messages with folded Content- headers.
* vm-mime-make-multipart-boundary: shortened multipart boundaries to
  avoid long header lines when vm-mime-avoid-folding-content-type is
  t.
* include the missing audio_stamp images in the distribution.
* set version variables at startup and refer to them rather than
  calling vm-xemacs-p, etc. repeatedly.
* vm-summary-highlight-region: overlays and extents aren't
  interchangable in this context, so behave based on Emacs/XEmacs
  version to avoid any overlay/extent emulations, and also to
  avoid having make-overlay's sudden appearance give us
  heartburn.
* don't fset vm-extent-property, vm-make-extent, etc. unless they
  are undefined.  This is to avoid changing their definition in
  the middle of an Emacs session and thereby mixing usage the
  overlay/extent interfaces.
* vm-mime-set-extent-glyph-for-layout: fixed reversed colorfulness
  test.
* vm-mime-set-extent-glyph-for-type: mona_stamp is a GIF not an XPM.
* more overlay/extent interface cleanup.
* reenabled internal text/html code.
* vm-yank-message: decode text/html and text/enriched in the
  composition buffer.
* attach image glyphs to attachment tags in composition buffers
  (XEmacs only).
* print a warning and continue if x-vm- header seems corrupted.
  old behavior was to just croak an error and wedge the mailer.
* vm-print-message: default count to 1 if passed no arguments.

## VM 6.23 released (4 April 1997)

* default value of vm-honor-mime-content-disposition now t.
* Makefile: default VM build type is now back to `autoload'.
* vm-rfc1153-or-rfc934-burst-message: use point instead of
  (match-end 0) when deleting the message separator.
* vm-rfc1153-or-rfc934-burst-message: trim excessive newlines
  only after we know that we are looking at a valid message separator.
* vm-su-message-id: discard chaff preceding message ID.
* vm-mime-fragment-composition: 'send -> '8bit to match
  documentation of vm-mime-8bit-text-transfer-encoding.
* vm-mime-fragment-composition: call vm-add-mail-mode-header-separator
  at the end so the buffer could be sent again.
* vm-mime-preview-composition: call vm-remove-mail-mode-header-separator.
* avoid starting new timers if old timers are still active (FSF
  Emacs only).
* vm-mime-encode-composition: split code into FSF Emacs and
  XEmacs functions.  This should avoid mixing usage of the extent
  and overlay interfaces, which loses with Nuspl's overlay.el
  emulation.
* default vm-temp-file-directory to C:\ if /tmp is not a directory
  and C:\ is.
* use insert-file-contents instead of insert-file-contents-literally
  when inserting MIME attachments into compositions when encoding.
  insert-file-contents-literally bypasses CRLF -> LF processing
  under NTEmacs, apparently.
* if vm-auto-displayed-mime-content-types or Content-Disposition
  says to display message/rfc822 or message/news inline and
  immediately display them as text/plain.  If displaying them due
  to button activation, use a folder instead.
* use different menu for mailto: URLs since the old one didn't
  really do what it advertised, i.e. didn't allow mailto URLs to
  be send to other browsers.
* added reduced color MIME art for 8-bit displays that used to only be
  used with displays with 16-bit or better displays.
* cache MIME art image glyphs for reuse to save load time.
* wrap calls to timezone-make-date-sortable in (condition-case ...)
  to avoid crashing on bad dates.
* gave up on using frame-totally-visible-p since it is still
  broken in 19.15.

## VM 6.22 released (22 March 1997)

* vm-mime-encode-composition: insert-file-contents-literally
  doesn't move point. the code assumed it does and corrupted
  attachments as a result.
* vm-gobble-crash-box: remove/rename crash box even if it is
  zero-length.

## VM 6.21 released (21 March 1997)

* vm-save-folder: call clear-visited-file-modtime if folder was
  deleted to avoid "File changed on disk" warnings later.
* vm-mime-qp-encode-region: bounds check (1+ inputpos) before
  using it to avoid referencing outside a clipping region.
* vm-mime-encode-composition: do the insert/delete dance to avoid
  text leaking into overlays in the file insertion case.

## VM 6.20 released (18 March 1997)

* vm-menu-support-possible-p: allow menu code to operate under
  NextStep.  window-system == ns.
* New variables:
  + vm-mosaic-program-switches
  + vm-netscape-program-switches
  + vm-mime-ignore-mime-version
  + vm-presentation-mode-hook (you were right, i was wrong)
* vm-decode-mime-messages: run the highlighting code
* vm-mime-display-internal-multipart/digest: copied folder display
  code from the message/rfc822 handler since they should work the
  same and message/rfc822 works properly with vm-mutable-windows
  == nil.
* make gui-button-face be the unconditional default value for
  vm-mime-button-face.
* vm-virtual-quit: make sure vm-message-pointer is non-nil before
  trying to run vm-message-id-number-of on it.
* vm-howl-if-eom: don't search other frames for the buffer's
  window.  Under XEmacs calling select-window on such a window
  causes its frame to be selected and it stays selected despite
  the call being wrapped in a save-window-excursion.  I don't
  think we really want to report end of message status in a
  window in a non-selected frame anyway.
* removed reference to user-mail-address variable, because it might be
  set to nil.
* vm-show-list: bind command to mouse release events instead of
  mouse press events in XEmacs.
* vm-preview-current-message: set vm-mime-decoded to nil; it is
  not enough to just let vm-make-presentation-copy do this.
* use full contents of References headers to avoid holes in
  threads due to missing parent messages.
* insert an X-Mailer in composition buffers.  Music!  Fun!  Horoscopes!
  And bug tracking.
* removed "Parsing MIME message..." status messages until I come
  up with a better way to write these status message only when
  we're doing something that might take a while.

## VM 6.19 released (8 March 1997)

* New user data functions:
  + vm-user-composition-folder-buffer
  + vm-user-composition-real-folder-buffers
* vm-print-message: make printing of MIME message work more like
  non-MIME messages; print visible headers, print tags for
  non-textual body parts.
* vm-mime-insert-button: don't set keymap parent to be the
  current local map unless that map exists (i.e. is non-nil).
* catch errors when decoding encoded words and substitute an error
  indicator for the string that we could not parse.
* vm-set-xxxx-flag: don't set attribute flag until after the undo
  information is recorded.  The buffer modification might be
  nixed by the user via the clash detection query, so we need to
  be sure we're past that code before committing to the attribute
  change.
* vm-set-labels: same as vm-set-xxxx-flag and for same reason.

## VM 6.18 released (4 March 1997)

* New variables:
  + vm-mime-composition-armor-from-lines
* use Dispose menu as the mode menu in the presentation buffer.
* vm-mime-encode-composition: do insert/delete dance to avoid
  inserting into attachment overlays.
* vm-print-command now decodes the MIME message before printing.
* vm-determine-proper-charset: use assoc instead of
  vm-string-assoc when searching MULE alists since symbosl are
  used tor charsets there.
* added 'print' item to mime dispose menu.
* vm-display: make buffer current buffer running
  vm-undisplay-buffer-hook.
* vm-make-presentation-copy: don't set frame deletion hooks unless
  multiple frames are possible.
* fixed bug where X-Faces were unrecognized if the X-Face header
  name used DiFfErEnT case than XEmacs' autodetect code expected.
* returned to using the day's date as part of the saved crash box
  name used when vm-keep-crash-boxes is set.
* somehow we didn't get scroll-in-place turned off in
  presentation buffers; done now.
* added support for message/news type, which is handled mostly
  like message/rfc822.
* new mime-dispose menu entries.
* don't check again for new mail if we already know some is waiting.
* add extended status reporting during POP message retrieval.
* vm-get-spooled-mail: if we know we've already retrieved some
  mail, catch keyboard-quit from vm-spool-move-mail and
  vm-pop-move-mail, so crash box contents can be processed
  immediately after the quit.

## VM 6.17 released (27 February 1997)

* vm-pop-read-past-dot-sentinel-line: use re-search-forward
  instead of search-forward (oops).
* don't use match-string; it is a macro in XEmacs 19.14 and this
  makes byte compiled code that doesn't know this fact blow up
  under 19.14.
* added content disposition popup menu on attachment tags.
* don't use intangible text property on attachment tags (breaks
  menu code).
* set zone-of message slot to "" if timezone missing from a Date
  header that looks like UNIX-ctime format.
* avoid using the symbol name `obarray'.
* treat consecutive rfc934 message boundaries as one boundary
  when bursting.
* fixed boundary test in rfc934/rfc1153 digest bursting code to
  requires the headers only if not looking at the last boundary.
  should have been doing this already, but the boolean logic was
  wrong.
* skip >From lines when reordering headers.
* added assert statement to vm-mime-encode-composition to try to
  track the disappearing attachment bug.
* vm-preview-current-message: unbury folder or presentation
  buffer depending on which one we use for the current message.
  This is a further effort to improve vm-mutable-windows == nil
  behavior.

## VM 6.16 released (25 February 1997)

* check for vm-xemacs-mule-p before using file-coding-system and
  friends, and also strengthen the checks that vm-xemacs-mule-p
  does.
* vm-mime-fake-attachment-overlays: don't use `pos' twice in a let
  statement.
* still more coding system fiddling; use get-coding-system to
  normalize coding-system values before comparing with eq.
* bind buffer-read-only to nil when encoding/decoding folder for MULE.
* make timers go away if interval vars indicate this should be
  done, or if all vm-mode buffers are gone.
* vm-run-command-on-region: bind binary-process-input for DOS/Windows.
* vm-mime-base64-encode-region: if B encoding, strip out line
  breaks after encoding if using an external encoder.
* vm-resend-bounced-message: use Resent- headers.
* extend mail mode menu.
* put VM mail mode menu on menubar (FSF Emacs).
* display content type information in the MIME button even if
  Content-Description is present.
* retire vm-unsaved-message.
* vm-run-command-on-region: don't visit file to determine how
  large it is.

## VM 6.15 released (20 February 1997)

* move start of attachment tag out of header section.
* vm-mime-preview-composition: don't copy extents under XEmacs.
* use text properties for attachment tags in FSF Emacs.
* vm-mime-attach-file: pass description from interactive spec
  into function.
* better handling of M-x vm-mode w.r.t. coding systems under Mule.
* Shapiro typo fixes.

## VM 6.14 released (19 February 1997)

* New variables:
  + vm-pop-max-message-size
  + vm-mail-check-interval
  + vm-pop-messages-per-session
  + vm-pop-bytes-per-session
  + vm-image-directory
  + vm-mime-default-face-charsets
  + vm-mime-charset-font-alist
* vm-get-spooled-mail: ncons -> nconc.
* vm-mime-parse-entity: allow trailing LWSP-chars on boundary
  lines.
* vm-make-presentation-copy: don't bury folder buffer when
  displaying presentation buffer.
* vm-get-spooled-mail: block signaling of errors if mail has
  already been appended to the folder.  Just display a message
  and continue.
* vm-gobble-crash-box: don't try to rename the crash box unless
  we actually put something into it.
* vm-pop-move-mail: don't use a filter function.  This should
  avoid consing and discarding big strings while downloading a
  maildrop and avoid swamping Emacs' heap with them.
* fixed a couple of attachment tag seepage problems.
* for subpart parse errors cram (car (cdr data)) into the
  description slot rather than the car; braino... the string is
  further down the list.
* vm-delete-duplicates: don't croak if vm-chop-full-name-function
  can't extract an address.
* vm-yank-message: search more than one level deep for textual
  MIME part when yanking a message into a composition buffer.
* added image stamps for MIME types that are displayed with the
  MIME buttons under XEmacs (> 15bit displays only).
* vm-pop-retrieve-to-crashbox: don't search from the beginning of
  message each time new output is added to the POP buffer.
* suppress prompt for POP password unless the user ran a command that 
  caused mail to be retrieved.
* vm-auto-select-folder: pass clump argument to vm-get-header-contents.
* don't let attachment be inserted into the header section of a message.
* should-use-dialog-box -> use-dialog-box
* simplify crashbox renaming to just use "Z" + a random number and
  check for existence of the destination file before renaming.
  This avoids the need for a one second sleep to avoid name
  collisions.
* Makefile: use -insert in rule to build vm.info to support
  XEmacs 19.14's broken command line parsing.
* new `getmail' toolbar button available under XEmacs.
* vm-mime-send-body-to-file: reread file name if user inputs a
  directory name, using the dir plus the default filename as the
  new default filename.
* default value of vm-flush-interval now 90, was `t'.
* require at least one valid header and a From header in messages
  in RFC1153 and RFC934 digests.  If the requirement is not met,
  assume the prior message boundary was not valid unless it was
  the boundary at the end of the digest.
* ignore line lengths when doing "Q" and "B" encoded word encoding.
* reverted to pre-6.05 version of vm-scroll-forward-internal.
  The pos-visible-in-window-p check still doesn't work correctly in the
  face of window size changes.  Only scrolling the buffer is an
  accurate indicator of whether we're on the last page.
* Makefile: default VM build type is now `noautoload'.
* vm-decode-mime-messages: if called interactively and we're
  previewing, call vm-show-current-message so the body will be
  displayed.
* set timer to delete POP processes two seconds after the session
  ends to try to evade a race condition in the TCP protocol that
  causes long delays when closing a socket.
* give up on using mail-extract-address-components.
* use proper file coding systems for reading and writing for
  XEmacs/MULE.
* vm-mime-encode-composition: prefer params attached to the
  extent over parameters in the body of the an already-MIMEd
  object, since the information is guaranteed valid.  It also
  avoids losing the quotes on boundary parameters.
* vm-show-current-message: check value of vm-mime-decoded in
  correct buffer, i.e. the folder buffer not the presentation
  buffer.
* stopped using w3-region.
* put MIME encoded words in the summary cache instead of decoded
  words to avoid losing Kanji and other long coded char types on saves.
* set scroll-in-place to nil in VM folder and presentation buffers.
* keep quoted copy of some structured fields of MIME headers for
  later use.  Useful if we want to inherit the type and
  parameters of a subpart.
* vm-mail-internal: set vm-mail-mode-map-parented for the XEmacs
  case as well as the FSF Emacs case.
* trimmed vm-mail-mode-map of some key bindings that already
  appear in mail-mode-map.
* replace some FSF Emacs menubar command entries in Mail mode.
* vm-kill-subject: type fix vm-move-after-deleting -> vm-move-after-killing

## VM 6.13 released (7 February 1997)

* set file-precious-flag to t in vm-mode buffers.
* vm-mime-qp-encode-region: call vm-insert-char properly when
  inserting linebreaks (sigh).
* vm-menu-toggle-menubar: save-excursion around recursive calls
  to avoid a buffer change.  Symptom of bug was that menubar
  toggling didn't work if the presentation buffer was the
  current buffer.
* don't use 'replicating property on attachment tag extents under
  XEmacs as they tend to make XEmacs crash.
* vm-forward-message: don't use vm-forward-list in temp buffer
  when miming; it has a nil value there instead of the needed
  message list.
* signal an error if the user tries to attach a directory,
  nonexistent file or unreadable file to a MIME composition.
* stuff attributes by reverse physical order.  This should
  decrease the amount of gap motion when stuffing attributes in
  folders that have been sorted by some key other than
  physical-order (thank you Bob Glickstein for this speedup
  idea).
* vm-thread-list: don't remove the head of thread-list when a
  loop is detected.  Symptom was that threading without using the
  Subject header was often broken.  I guess
  vm-thread-using-subject == nil is not a popular setting.
* vm-show-current-message: moved setting of vm-system-state back
  inside the conditional that checks whether the folder or
  presentation buffer is visible.  Having it outside seemed to be
  causing pain for vm-preview-lines == nil users, bane of
  life. :-/
* vm-delete-buffer-frame: removes itself from
  vm-undisplay-buffer-hook, as it did before some recent changes.

## VM 6.12 released (6 February 1997)

* New commands:
  + vm-mime-encode-composition
  + vm-mime-preview-composition
* New variables:
  + vm-mime-avoid-folding-content-type
  + vm-mime-display-function
* Retired variables:
  + vm-summary-subject-no-newlines
* replace newlines with spaces in all subjects and full names
  displayed in the summary.
* vm-guess-digest-type: listp -> vectorp.  The MIME layout struct
  type changed since this code was last looked at.
* don't let subpart parse errors make the parse of the whole MIME
  message fail.  Return a default type upon encountering a
  non-top-level parse error.
* vm-forward-message: like vm-send-digest, use an attachment in
  the composition buffer if vm-send-using-mime is non-nil.
* more status messages for things that take a while to execute.
* set default value of vm-send-using-mime based of featurep
  'mime-setup to try and avoid bad interaction with TM.
* vm-mime-qp-encode-region: don't use insert-string, since it
  does different things in Emacs and XEmacs
* MIME header-decode strings that go into the summary cache that
  are taken from headers that can contain encoded words.
* add "MIME-Version:" and "Content-" to the default list of
  headers (vm-resend-bounced-headers) that are kept when
  resending a bounced message.
* don't treat multiple occurrences of all headers like the
  multiple occurrence of a recipient header.  Old behavior was to
  clump all header instance contents together separated by ", ".
  Now some headers clump, some don't, and some clump with a
  different separator string.
* don't move message pointer if deleting after archiving even if
  vm-move-after-deleting is non-nil.

## VM 6.11 released (3 February 1997)

* vm-mime-encode-composition: don't encode the whole message when
  trying to encode the last text part.
* vm-yank-message: use (car parts) instead of `o' inside the MIME
  part insertion loop.  Symptom, nothing was inserted when
  yanking a multipart message
* changed default value of vm-auto-displayed-mime-content-types
  to ("text" "multipart").

## VM 6.10 released (3 February 1997)

* New variables:
  + vm-honor-mime-content-disposition
  + vm-mime-attachment-save-directory
* vm-mime-display-internal-message/partial: changed incorrect
  reference to layout to (car p-list).  Symptom of the bug was
  the "total" parameter would not be found unless it was present
  in the message that was current when the message/partial button
  was activated.
* vm-check-emacs-version: allow VM to run on v20 Emacs/XEmacs.
* removed bogus default value of vm-frame-parameter-alist.
* vm-yank-message: when yanking a MIME message, don't yank
  non-text parts.
* fixed problem with vm-show-current-message being called twice
  if you put the cursor on a non-current MIME message in the
  summary and hit RET.  The symptom was that you would get the
  `all button' MIME display instead of the `decoded' display.
* discard any directory components from default filename provided
  via a MIME object.
* fixed buggy handling of multipart/alternative to pick the best part
  rather than the last displayable part.
* vm-decode-mime-message: when doing the `buttons' display,
  display buttons for all non-composite objects, i.e. make all
  multipart types transparent.
* treat multipart/parallel exactly like multipart/mixed.
* vm-mail-send: take precautions so that VM doesn't manhandle the
  wrong buffer if the composition buffer is killed inside mail-send.
* vm-mime-qp-decode-region: treat CR after = like a soft local
  line break.  The message is supposed to be written in the local
  newline convention (LF only) by the time VM sees it, but when
  was life ever easy?  Why am I sure that I'll be visiting this
  again?
* run w3-region in its own buffer and wrap it in save-excursion /
  save-window-excursion to prevent it from fiddling with VM's
  window environment, clip region and point.
* make sure the presentation buffer has a license to kill frames if
  vm-frame-per-folder is non-nil.
* put quotes around boundary parameters in multipart messages
  that VM creates, since the random boundary strings might
  contain a /, which requires quoting.

## VM 6.09 released (30 January 1997)

* MIME composition (support for vm-send-using-mime)
* New commands:
  + vm-mime-attach-file
  + vm-mime-attach-mime-file
* New variables:
  + vm-mime-8bit-composition-charset
  + vm-mime-8bit-text-transfer-encoding
  + vm-mime-attachment-auto-type-alist
  + vm-mime-max-message-size
* fixed range check bug in vm-mark-or-unmark-summary-region.
* don't ignore whether the text/plain internal display function
  fails when used as a fallback display function for textual
  types.  Unsupportable charsets might make it fail; should
  default to application/octet-stream in that case.
* fixed MIME parsing in virtual folders.
* don't move window point when decoding MIME messages if the
  presentation buffer's window is the selected window.
* added a third state for vm-decode-mime-messages to show all
  buttons before going back to the raw data.
* fixed frame-iconified-p typos.
* fixed vm-mime-convert-undisplayable-layout to return a layout
  instead of a status message :-P.
* avoid using make-local-variable on kill-buffer-hook in some
  buffers since this is now apparently a no-no.
* check Emacs version and signal an error if the version the user
  is using is too old to run VM.
* fixed really doof bit shift and masking errors in
  vm-mime-qp-encode-region.

## VM 6.08 released (26 January 1997)

* New commands:
  + vm-mark-summary-region
  + vm-unmark-summary-region
* New variables:
  + vm-spool-file-suffixes
  + vm-crash-box-suffix
  + vm-make-spool-file-name
  + vm-make-crash-box-name
* vm-mime-base64-encode-region: fixed typo base64-decoder ->
  base64-encoder.
* save-excursion around switch-to-buffer in 'vm and
  'vm-visit-virtual-folder startup code to avoid possibly
  switching to the summary or presentation buffer.
* don't propagate vm-ml-sort-keys to the presentation buffer.
* make sure buttons start at the beginning of a line after the
  first decoding pass.
* support the native-sound-only-on-console variable under XEmacs.
* added image/tiff support for XEmacs.
* vm-mail-send-and-exit: respect the buffer stack; don't make VM
  buffers rise in the stack after sending a message by forcing
  the display of a VM buffer with vm-display.
* vm-mail-send-and-exit: don't attach VM buffers to the
  unsuspecting frame that we land on after deleting the
  composition frame.
* vm-mail-send: protect the value of this-command in a couple of
  places.
* Under XEmacs, give the vm-summary-overlay extent a `t'
  start-open property to avoid text leaking into that extent from
  summary entries earlier in the buffer when such entries are
  updated.

## VM 6.07 released (23 January 1997)

* New variables:
  + vm-raise-frame-at-startup
  + vm-mouse-track-summary
* vm-goto-new-frame: ditch the sit-for code; it screws with
  window-start.
* vm-display: always raise frame if doing a buffer display,
  unless invoker says not to.
* vm-preview-current-message: run the select-message hooks before
  copying to the presentation buffer.  Maybe this will allow the
  font-lock stuff that users put on these hooks to work.
* fixed bug where application subtypes were ignored.
* mark folder buffer for update after displaying raw MIME data
  with 'D'.  The toolbar wasn't being updated.
* add enabled-p function for Quit and Helper toolbar buttons.
* set default values for vm-toolbar-helper-icon and
  vm-toolbar-delete/undelete-icon so that greyed buttons are
  displayed when a non-VM mode buffer is current.
* vm-inhibit-startup-message variable retired.
* added XEmacs support for audio/basic.
* vm-mime-send-body-to-file: show default filename, if any, in prompt.
* vm-build-virtual-message-list: make virtual folder inherit the
  global label lists of all the associated real folders.
* fixed totally gubbed handling of multipart/parallel.
* use shell-command-switch instead of "-c" when running shell
  command lines.

## VM 6.06 released (21 January 1997)

* New variables:
  + vm-mime-type-converter-alist
  + vm-move-after-killing
* fixed matching of <URL:blah> tags under FSF Emacs to ignore the
  bracketing.
* narrow to the message clip region in both the folder and
  presentation buffers to avoid confusing peripatetic users who
  insist on looking at the wrong buffer.
* bury the folder buffer when using the presentation buffer.
  Again this is to make it harder for users to stumble over it.
* changed "Click" to "Click mouse-2" in the buttons so users won't
  try mouse-1.
* added support for deprecated "name" parameter of
  application/octet-stream to specify a default filename.
* added support for image/png under XEmacs.
* added support for message/partial assembly.
* added support for message/parallel display.
* default charset to us-ascii is some places where it was not
  being done.
* set frame deletions hook in the presentation buffer.
* ignore Content-Description header if it is empty or all whitespace.
* fixed vm-mouse-3-help so that balloon help is displayed; first
  sexp in a function apparently is always considered to be a
  docstring and is not returned.
* be more verbose when doing MIME decoding and display so the
  user knows what's going on.
* evade the awful XEmacs file dialog box.
* vm-mouse-send-url-at-position: call `widen' to avoid
  referencing a positon outside the clip region.
* complain about invalid virtual selectors if the user enters one.
* keep track of the frames that VM creates so that we don't
  delete frames that VM didn't create.
* don't delete frames that VM did not create.
* do a sit-for immediately after creating a frame so that the
  status messages will appear in the new frame.  This is mostly
  for XEmacs.
* vm-make-presentation-copy: don't leave the folder buffered unnarrowed
* filled in some gaps in vm-supported-window-configurations.
* stopped passing vm-Next-message and vm-Previous-message to
  vm-display; we use the official names now.
* set buffer-file-type to t temporarily when writing POP
  transcript buffer contents to crashbox.
* attach toolbar to frame as well as to buffer if VM created the
  frame we're displaying the toolbar on.
* run vm-menu-setup-hook under XEmacs also.
* (require 'disp-table) before calling standard-display-european
  to insure that standard-display-table gets initialized _before_
  lambda-binding it (FSF Emacs only).
* vm-options-file -> vm-preferences-file.
* vm-mouse-button-2: don't call vm-preview-current-message;
  vm-follow-summary-cursor already does this.
* default value of vm-forwarding-digest-type changed to "mime".
* default value of vm-digest-send-type changed to "mime".
* vm-decode-mime-messages: if message is already decoded, then
  display the raw MIME data instead.
* use vm-chop-full-name-function in vm-su-do-recipients instead
  of the home brewed regexps.
* vm-display: don't call raise-frame unless either a) the
  window's frame we want displayed is not visible, i.e. is
  unmapped or iconified, or b) the invoker specifically demands
  that we raise the frame.
* vm-scroll-forward/vm-scroll-backward: demand that the folder
  buffer frame be raised.
* Shapiro typo fixes

## VM 6.05 released (15 January 1997)

* New variables:
  + vm-popup-menu-on-mouse-3
  + vm-frame-per-completion
  + vm-burst-digest-messages-inherit-labels
* fixed bug in vm-set-summary-redo-start-point and
  vm-set-numbering-redo-start-point that caused expunges in
  virtual folders to have screwy numbering and summary entries
  that don't correspond to real messages.
* display MIME messages using non-US-ASCII character sets.  (Only
  ISO-8859-1 for Emacs 19.34 and XEmacs 19.14, many more for
  XEmacs 20.0.
* decode MIME headers, e.g. =?ISO-2022-JP?B?GyRCPGkyLBsoQiAbJEJDTkknGyhC?=
* set buffer-file-type, binary-process-input, and
  binary-process-output correctly for DOS and Windows systems.
  Hopefully this will cure the MIME decoding problems seen there.
* copy current menubar before toggling menubar to the XEmacs
  global menu when running under XEmacs.  This is done to avoid
  discarding menu entries added by minor modes like mailcrypt.
* support mailto: URLs internally.
* support RFC 1738 <URL:blah> style tags.
* changed some virtual folder selector functions to handle being
  passed a virtual message instead of a real message.  This
  allowed virtual messages to be passed to all selectors, which
  is what selectors like vm-vs-marked needed to work properly.
* default value of vm-digest-burst-type changed from "rfc934" to
  "guess".
* vm-set-window-configuration: if current buffer is a mail-mode
  buffer, use it for the `composition' buffer for window
  configuration purposes instead of the one found by
  vm-find-composition-buffer.  Proximity implies affinity, I
  hope.
* typo fix: vm-mm-mime-layout should have been vm-mm-layout in
  vm-guess-digest-type.
* vm-scroll-forward-internal: check for vm-text-end-of visible
  before attempting to scroll, signal end-of-buffer if it is
  visible.
* vm-mime-parse-entity: set buffer to real message's folder buffer
* added extra save-excursion to various functions to protect
  against point motion in the buffer to which the function
  temporarily switches.
* force display of either the folder buffer or the presentation
  buffer after creating the temp folder in the message/rfc822
  internal handler.
* force display of either the folder buffer or the presentation
  buffer after sending a message and undisplaying the composition
  buffer... this before trying for a window configuration that
  is indifferent about displaying any particular buffer.  This
  should allow the vm-mutable-windows == nil crowd to see the
  correct buffer more often after sending a message.
* vm-guess-digest-type: limit search for rfc1153 separator to the
  end of the message being burst.
* fixed brokenness in VM's invocation of the FSF Emacs interval
  timers so that they actually work now.
* vm-reorder-message-headers: don't cons strings to copy
  headers.  Use positions instead and move text around solely
  via buffer to buffer copies.  This should prevent VM from
  consing itself and Emacs into oblivion when faced with hundreds
  of To/Cc headers.
* display text/html internally using w3-region if w3-region is
  bound after (require 'w3).
* consider iso-8859-1 charset messages `plain' for the purposes
  of deciding whether MIME decoding is needed.
* made qp decoder not think the end of the region was an equal
  sign.
* under XEmacs don't default vm-mime-button-face to
  gui-button-face on ttys.  gui-button-face is plain on ttys so
  use bold-italic instead.
* remove references to underline in the sexpr default for
  vm-mime-button-face.
* documentation improvements

## VM 6.04 released (9 January 1997)

* mime-error -> vm-mime-error
* &optioanl to &optional in def of vm-mime-base64-decode-region
* require some diagnostic output before signaling an error when a
  MIME external decoder exits non-zero.
* save-excursion when running quit hook to avoid buffer changes.
* don't call facep if it isn't bound.  FSF Emacs when compiled
  without window system support doesn't have face support either.
* use reasonable toolbar width and height values if glyph-width
  and glyph-height return 0, as they do sometimes at startup.
* typo fixes from Shapiro.

## VM 6.03 released (8 January 1997)

* made vm-show-current-message use vm-mime-plain-message-p to
  decide whether to use the presentation buffer, just as
  vm-preview-current-message does, to avoid calling
  vm-decode-mime-message when there is no prep'd presentation
  buffer.
* fixed calls to vm-run-command-on-region to use apply so that
  last arg could be an arg list.
* fixed parsing bug in vm-mime-plain-message-p; use \(.*\) instead of
  \\(.*\\) inside a regexp string.
* made vm-decode-mime-message refuse to decode plain messages.
* more work on vm-quit and friends to make sure buffers are
  buried or killed when they should be.
* turn off undo record keeping in temp work buffers.
* removed undo button from the fallback VM popup menu under FSF
  Emacs.
* vm-mime-send-body-to-file: fixed reversed logic after asking
  "File exists, overwrite? "
* fixed (wrong-type-argument (number-or-markerp nil)) bug in
  vm-mime-base64-decode-region; botched eob test cause char-after
  to be called at eob and the result was used in a numeric
  comparison.
* rewrote vm-determine-proper-content-transfer-encoding, fix a
  small bug with the line length check.
* fixed parsing of empty MIME bodies
* vm-discard-cached-data: for each affect folder and virtual
  folder if there's an associated presentation buffer, call
  vm-preview-current-message to rectify the contents of the
  presentation buffer with the new reality.
* force inclusion of MIME headers into forwarded and digestified
  messages if the message is not plain.
* do CRLF -> LF conversion for text and message types after
  base64 decoding.
* disallow multipart types to be sent to an external viewer.
* doc improvements

## VM 6.02 released (8 January 1997)

* New variables:
  + vm-mime-base64-decoder-switches
  + vm-mime-base64-encoder-switches
* empty the presentation buffer after expunging if the resultant
  folder is empty.
* fixed bug in vm-edit-message; when computing the cursor offset
  from the start of the message, it was using the value of point
  from the folder buffer when it should have used the value in
  the presentation buffer if the latter buffer existed.
* bury the presentation buffer in those places where the folder
  buffer and summary are also buried.
* fixed bug in vm-mime-base64-decode-region that would corrupt
  the last two bytes in a body if there were two padding bytes of
  the end.
* use process-kill-without-query on external viewer processes.
* made vm-run-command-on-region use it arg-list parameter
* decode base64 or quoted-printable text in message bodies yanked into
  composition buffers.
* remove undo button from vm-menu-vm-menu, which is the popup
  menu that mostly mirrors the main VM menubar.  The button
  doesn't have much value in a popup menu and I think it is
  angering ntemacs.
* ensured case insensitive matching of MIME Content-Type
  parameter names.
* don't display the Decode MIME toolbar button, don't enable the
  Decode MIME menu entry, and don't use the presentation buffer
  if the message is of type text/plain; charset=us-ascii and has
  no opaque transfer encoding.
* don't show autosave and backup file names in the *Files* window.

## VM 6.01 released (7 January 1997)

* fixed bug that caused a message not to be displayed if
  vm-auto-decode-mime-messages is non-nil.
* fixed FSF Emacs specific bug that cause mouse-2 and mouse-3 to
  not work correctly over URLs.
* fixed vm-mime-burst-layout to allow bursting of all subtypes of
  MIME type "message".
* messages of unknown subtypes of MIME type "message" are
  displayed as text/plain, which is more likely to be correct
  than treating them as message/rfc822.
* added popup menus to the MIME buttons.
* typo fixes

## VM 6.00 released (6 January 1997)

* MIME reader support, digest send/burst, resend bounce
* New commands:
  + vm-burst-mime-digest
  + vm-send-mime-digest
  + vm-send-mime-digest-other-frame
  + vm-decode-mime-message
* New variables:
  + vm-display-using-mime
  + vm-mime-alternative-select-method
  + vm-mime-digest-discard-header-regexp
  + vm-mime-digest-headers
  + vm-auto-displayed-mime-content-types
  + vm-auto-decode-mime-messages
  + vm-mime-internal-content-types
  + vm-mime-external-content-types-alist
  + vm-mime-button-face
  + vm-mime-base64-decoder-program
  + vm-mime-base64-encoder-program
  + vm-temp-file-directory
* Use local-map property on URL overlays so that URLs can now be
  activated by pressing RET in FSF Emacs.  This feature was
  already present under XEmacs.
* Check for buffer-file-name non-nil or buffer-offer-save non-nil
  before we warn the user about quitting without saving changes.
  Also use this check before trying to save the folder during a
  quit.
* vm-mode now sets buffer-offer-save to t.
* panic buffoon's color changed from yellow to rgb:00/df/ff
* made use of the [Emacs] and [Undo] menubar button conditional
  on not being under Windows 95 or NT.  Those versions of Emacs
  don't handle menubar buttons.
* use FSF Emacs' interval timer package if not (featurep 'itimer).

## VM 5.97 released (22 December 1996)

* temporarily set print-length to nil while VM is writing out
  Lisp objects.
* changed vm-menu-support-possible-p to accept 'win32 as a
  window-system value that means menu support is possible.
* fixed parse problem in vm-parse-addresses with () and "".  Also
  change code not to put empty strings recipients in the returned
  list.
* made vm-toolbar a user variable.  Experimental.
* documentation fixes

## VM 5.96 released (9 June 1996)

* started shipping a pre-built vm.elc file for those who can't
  build VM.
* changed predictate function that determines whether menu support is
  possible; there can be window system support without menubar
  support.
* changed build procedure to not concatenate .elc files when
  building the autoloadable version of the program.  The
  concatenation broke Emacs' dynamic loading feature, which some
  users wanted to use.
* fixed typo in default setting of vm-default-folder-type; if
  system-configuration was unbound, vm-default-folder-type would
  be set to From instead of From_.
* vm-quit-just-bury: reordered burying and undisplaying actions
  again to try to keep undisplaying from bringing one of the
  buried buffers back to the top of the buffer list.
* vm-follow-summary-cursor: the position at end of buffer now
  belongs to the last message.
* New variables:
  + vm-virtual-mode-hook
* use extent-end-position instead of extent-live-p since XEmacs
  19.11 doesn't have extent-live-p.
* added ( and ) to characters that cannot be part of an URL path.
* changed 'count' local variable in let s-exp to 'undel-count' to
  avoid conflict with prefix arg parameter also called 'count'
* changed vm-help to use (describe-function major-mode) instead
  of (describe-mode) since in Emacs and XEmacs describe-mode
  describes minor modes, too.
* fixed infinite loop bug in vm-frame-loop.  Needed to make sure
  that the frame we start in could never be a minibuffer-only
  frame because the loop will never visit a minibuffer-only frame
  again and thus never terminate.

## VM 5.95 released (18 August 1995)

* vm-find-leading-message-separator: for From_ type folders,
  removed requirement that there be two newlines before "From "
  message separators.
* don't change summary and numbering redo start points once they
  are set to t.  This got screwed up when I fixed other problems
  in vm-expunge-folder.
* vm: always do window configuration setup if doing full startup.
* Shapiro typo fixes
* default value of vm-startup-with-summary now t.
* default value of vm-follow-summary-cursor now t.
* call delete-other-windows before running reporter-submit-bug-report
  so the user has the full screen to work with.
* vm-edit-message-other-frame: lambda-bound vm-frame-per-edit to
  nil when calling vm-edit-message.
* vm-mouse-send-url: fixed calls to vm-unsaved-message that had a
  missing arg.
* vm-keyboard-read-string: make RET do completion and exit the
  minibuffer (non multi-word reads only).
* fixed auto correction in vm-read-string.
* set default-directory before running auto-save-mode in
  vm-mail-internal so the auto-save file name picks up the
  directory change.

## VM 5.94 released (4 August 1995)

* use window instead of frame in set-mouse-position call (XEmacs
  19.12 only).
* vm-warp-mouse-to-frame-maybe: nil coordinates mean that the
  mouse is not really within the frame, so move it. (FSF Emacs
  only).
* use regexp-quote on header contents passed to
  vm-menu-create-*-virtual-folder functions.
* don't set keymap parents for any extent local keymaps because
  this breaks minor-mode-map-alist, which breaks isearch.
* don't actually select frames in vm-frame-loop since this
  affects the buffer stack.
* vm-quit-just-bury: moved vm-bury-buffer calls after the
  vm-display calls; the latter may have been partially undoing
  some of the burying.
* vm-mail-send-and-exit: moved vm-bury-buffer call after the
  vm-display call; the latter may have been partially undoing
  some of the burying.
* expect From_-with-Content-Length folders by default on IBM AIX
  systems.
* added toolbar button help messages.
* added URL balloon help messages
* added electric header balloon help messages
* added status messages for when URLs are sent to browsers.
* added "https" to the URL match regexp.

## VM 5.93 released (25 July 1995)

* fixed null menu problem if vm-use-menus == 1 (FSF Emacs only);
  menu map wasn't being built.
* tollbar -> toolbar typo in vm-toolbar.el.
* vm-find-leading-message-separator: for From_ type added
  requirement that something that looks like a header or
  ">From " be on the line after the From_ line.
* truncate ultralong buffer names generated by
  vm-rename-current-buffer-function.
* vm-auto-archive-messages: don't really save message if the
  destination folder is /dev/null.

## VM 5.92 released (19 July 1995)

* vm-set-summary-pointer: check vm-su-start-of for nil value
  before trying to go to its position.
* reuse vm-summary-overlay instead of deleting and recreating it.
* fixed dup menu entries in FSF Emacs menubar toggled menubar.

## VM 5.91 released (19 July 1995)

* fixed dup menu problem in FSF Emacs.
* vm-expunge-folder: disabled summary updates of expunged messages.
* fixed typo in vm-use-menus default value.
* check for multi-frame support before trying to create a frame
  in vm-edit-message.
* efficiency tweaks in vm-toolbar-can-recover-p and
  vm-update-message-summary; avoid work most of the time
  by testing for the common bailout cases early.

## VM 5.90 released (16 July 1995)

* use vm-set-deleted-flag-of instead of vm-set-deleted-flag in
  vm-expunge-folder.  Should make expunging much faster since
  many wasted summary updates are eliminated.
* use a different symbol name for every menubar binding, as
  opposed to just a different symbol.  (FSF Emacs only.)  FSF
  Emacs seems to match against the names.

## VM 5.89 released (16 July 1995)

* deal with system-configuration not being bound.
* don't call buffer-substring with three args in
  vm-buffer-substring-no-proprerties.  buffer-substring only
  takes two args in FSF Emacs.
* fixed XEmacs toggle menu button.
* added menu toggle button for FSF Emacs.
* changed Undo menu into an Undo button in FSF Emacs.
* don't fset most of the vm-toolbar-*-command variables if they are
  already fbound; lets the user customize them from ~/.vm.
* new semantics for vm-use-toolbar.
* new semantics for vm-use-menus.
* vm-update-message-summary: changed insertion/deletion dance so
  that window point moves to the beginning of the current summary
  entry instead of the beginning of the next summary entry when
  an attribute change occurred and the cursor is in a
  summary entry but not at beginning of line.
* added "Recover" toolbar button that appears in conjunction with
  "Auto save file is newer..."

## VM 5.88 released (13 July 1995)

* New variables:
  + vm-frame-per-summary
  + vm-frame-per-edit
  + vm-rename-current-buffer-function
  + vm-thread-using-subject
* default window configuration for editing-message now full
  screen instead of split with summary.
* moved calls to vm-set-hooks-for-frame-deletion to avoid having
  the hooks attached to the wrong buffer.
* swapped first and second args to mapconcat in vm-print-message.
* check for killed folder buffer in toolbar enabled-p functions
  to avoid the wildebeest-botfly-toolbar-enabled-p-death-spiral
  bug in XEmacs 19.12.  Actually it looks like that bug was fixed
  before 19.12 was released.
* check for killed folder buffer in menubar enabled-p functions
  to avoid the wildebeest-botfly-menubar-enabled-p-death-spiral
  bug in XEmacs 19.12.  Unlike the toolbar counterpart, this is
  bug still exists in 19.12.
* vm-read-file-name: allow old value of file-name-history to be
  used if history is nil.
* panic buffoon's color changed from DarkGreen to yellow.
* call device-type without any args.  device defaults to
  (selected-device) anyway.
* put a save-excursion around the parts of vm-delete-buffer-frame
  that might change Emacs' idea of the `current buffer'.  Lack of
  this save-excursion caused vm-undisplay-buffer-hook for another
  buffer to be modified by remove-hook.
* vm-read-string: don't pop up mouse interface if the completion
  list is empty.  instead just run the keyboard interface.
* don't try to add to menubar if it is nil.  (XEmacs only)
* recognize rmail, rmail-input and rmail-mode as alternate names
  for vm.  for (defalias 'rmail 'vm).
* Shapiro typo fixes.
* match Content-Length header case insensitively.
* hide the 19.29 Help menu; tag moved from help to help-menu.
* don't log uninteresting status messages in *Messages*
  log. (Emacs 19.29 only.)
* use vm-save-restriction instead of save-restriction in
  vm-run-message-hook.
* vm-show-list: fix lossage if list item is wider than the
  window; avoid division by zero by setting a min value of 1 for
  columns.
* vm-easymenu.el: If callback is a symbol use it in the menu
  keymap instead of the uninterned menu-function-XXX symbols.
  This allows Emacs' menu code to set this-command properly
  when launching a command from the menubar.
* default value of vm-convert-folder-types is now t.
* instead of putting buffer objects into the virtual folder spec
  for anonymous virtual folders, use a s-expression that returns
  a buffer object.
* fixed bug where forwarding a zero length message would put the
  forwared message outside the digest separators.
* default values of vm-trust-From_-with-Content-Length and
  vm-default-folder-type now vary depending on the system type.
  Solaris and usg-unix-v users are set to use Content-Length
  folders.
* support mail-archive-file-name and mail-self-blind in
  vm-resend-message.
* xbm bitmaps added for XEmacs 19.13 xbm toolbar support.
* fixed infinite loop bug in vm-window-loop.  Needed to make sure
  that the window we start in could never be a minibuffer window
  because the loop will never visit a minibuffer window and thus
  never terminate.
* obfuscated calls to screen-* in vm-warp-mouse-to-frame-maybe to
  avoid stimulating the Emacs 19.29 byte compiler bug.
* prefer References over In-Reply-To when looking for a message
  parent when threading.
* fixed infinite loop bug in vm-mark-thread-subtree; check for
  messages that we've already seen to avoid child is a parent of
  the child problem that can occur in subject threading.
* strip text properties from all strings to be used in the
  attributes and summary cache.  It should be OK now to use
  font-lock (i.e. text properties) in a VM folder buffer under
  FSF Emacs now.

## VM 5.87 released (16 June 1995)

* New variables:
  + vm-search-other-frames
  + vm-summary-update-hook
* when searching for a window displaying a buffer, always search the
  selected frame first.
* frame-map slot of window configuration set to nil to avoid
  unreadable objects being printed into the window configuration
  file.
* vm-menu-print-message -> vm-print-message
* made the highlight-headers-regexp defvar in vm-vars.el match the
  one in XEmacs' highlight-headers.el so it doesn't matter if VM
  is loaded before highlight-headers.el.
* warp mouse to center of frame instead of left corner.
* only run vm-arrived-message-hook on new messages not messages
  already in the folder at startup.
* fixed bug where a message deletion in one folder caused the
  "undelete" toolbar button to appear in another folder.
* Shapiro typo fixes

## VM 5.86 released (6 June 1995)

* toolbar support (XEmacs 19.12 only)
* New commands:
  + vm-print-message
* New variables:
  + vm-use-toolbar
  + vm-toolbar-orientation
  + vm-print-command
  + vm-print-command-switches
* vm-summary-highlight-face's default value is now 'bold (was nil).
* vm-highlighted-header-face's default value is now 'bold (was 'highlight).
* vm-mail-send-and-exit: always undisplay buffer if it is alive
  after runnning vm-mail-send.  Previously it would undisplay
  only if the current buffer were the same after running vm-mail-send.
* fixed call in vm-bury-buffer to pass the argument to along
  bury-buffer.
* region not narrowed properly for vm-display-xface, so it
  searched the whole message, which in turn could cause selection of
  large messages to take a looong time.  Fixed.
* vm-display-xface: use set-glyph-face instead of
  set-extent-face.
* dropped 'highlight property from the xface extent.
* if non-nil let vm-highlighted-header-regexp override
  highlight-headers-regexp so user can have VM specific highlight
  if desired.  This was done before, but was undone in one of the
  releases.
* rolled (save-window-excursion (switch-to-buffer ...)) into
  vm-unbury-buffer.
* used vm-unbury-buffer in vm-continue-composing-message to avoid
  having the window configuration code pick a different composition
  buffer than vm-continue-composing-message did.
* added netbsd to the system types that get
  vm-berkeley-mail-compatibility turned on by default.
* clickable *Completions*
* mouse triggered commands now use mouse interface to read filenames.
* mouse triggered commands now use mouse interface to do
  completing reads of strings.
* fixed typo in completion list show function tab-stop-list ->
  tab-stops.  This was causing the ragged completions display.
* vm-sort-messages: signal error is no sort keys provided.
* vm: moved visited-folders-menu installation and the running of
  vm-visit-folder-hook so that they are executed even if "auto
  save file is newer ..."
* fixed places where VM was unconditionally warping the mouse.
* added (provide ...) calls for all vm-*.el files.
* added version number to vm-mode help.

## VM 5.85 released (2 June 1995)

* dropped reporter.el and timezone.el from distribution
* merged tree-menu.el into vm-menu.el; renamed functions to avoid
  conflicts with the real tree-menu.el.
* no more SUPPORT_EL and SUPPORT_ELC in Makefile
* New variables:
  + vm-warp-mouse-to-new-frame
  + vm-use-lucid-highlighting
  + vm-display-xfaces
* patched vm-current-time-zone to understand timezone offsets
  that are not an integral number of hours from GMT.
* frame deletion hooks now detach themselves from buffer after one
  execution.
* added menubar buttons to toggle between buffer local and global
  menubars (XEmacs only).
* lambda-bound vm-follow-summary-cursor to t in vm-mouse-button-2
  so mouse-2 selection in the summary will always work.
* make vm-select-frame a no-op in tty-only Emacs
* use set-specifier to turn off horizontal scrollbar instead of
  the variable buffer-scrollbar-height, which is gone
  now. (XEmacs 19.12 only)
* changed vm-url-regexp to not match some common trailing
  punctuation.
* added missing call to vm-move-message-pointer to
  vm-next-message so that it would start at the message after the
  current message when vm-circular-folders is non-nil and a move
  is being retried non-dogmatically.
* fixed args to re-search-forward in the URL search code.  The
  search bound wasn't being set.
* vm-find-trailing-message-separator: if Content-Length header
  doens't point to the start of another message or end of folder,
  search for "^From " starting at the original search point.  We
  used to start at the point Content-Length told us to go, but
  that can make VM clump many messages together if the incorrect
  Content-Length value is very large.
* fixed logic in vm-display so that if the buffer is visible and
  is required to be displayed and the applied window
  configuration undisplays it, notice and display it again.
* region not narrowed properly for vm-energize-headers, so it
  searched the whole message, which in turn could cause selection of
  large messages to take a looong time.  Fixed.
* bury-buffer -> vm-bury-buffer in most places.  vm-bury-buffer
  buries the buffer in all frames (XEmacs only).  No change in
  behavior for FSF Emacs.
* fixed vm-expunge-folder: numbering and summary redo start points may need
  to be recomputed on each iteration of the message loop in the
  case of virtual mirrored expunges.  The code previously assumed
  the first expunged message in a folder would correspond to the correct
  redo start point.  This is only true for unmirrored virtual
  expunges or real expunges.
* dropped duplicate Reply-To from vm-resend-bounced-headers.
* Shapiro typo fixes.

## VM 5.84 released (26 May 1995)

* fixed known-virtual-folders menu to use vm-visit-virtual-folder
  instead of vm-visit-folder.
* vm-continue-composing-message now creates a frame for the
  composition if vm-frame-per-composition is non-nil.
* fixed vm-iconify-frame-xxx so that it gives iconify-screen an
  arg since it churlishly requires one.
* vm-delete-buffer-frame: added condition that the target frame
  must be the selected frame to be unconditionally deleted.  Also
  added call to vm-delete-windows-or-frames-on to clear remaining
  windows and frames that might be displaying a buffer.
* Added Visit tags to the known-virtual-folders and
  visited-folders menus.

## VM 5.83 released (25 May 1995)

* fixed incorrect mode menus selection that was due to mode-popup-menu being
  set before major-mode.
* fixed menubar Dispose menu
* made vm fall back to `folder' if `primary-folder' parameters not
  specified in vm-frame-parameter-alist.
* vm: at startup, reuse summary frame if available when looking
  for a frame displaying the folder buffer.  Supposedly did this
  in 5.82 but I fluffed the change.
* dropped second arg 't' to vm-sort-messages in the menus.  Legacy
  stuff from 5.72.L, bad juju.
* renamed support packages to vm- prefixed names to keep from
  picking up old or non-vm-simpatico versions.
* vm-easymenu.el: renamed a couple of easy-menu- functions to
  further avoid picking up bad versions.
* zapped "File" menu when VM is using the whole menubar.  Should
  have been zapped already but file -> files in 19.29 and I'm
  testing mostly with 19.29.
* moved frame creation before call to vm-preview-current-message
  in vm.  Try to help the BBDB crowd.
* made the options file optional, as it should be.
* added "Mail" item to menubar in mail-mode (XEmacs only).
* Folders menu deep-sixed for FSF Emacs.

## VM 5.82 released (25 May 1995)

* New commands:
  + vm-iconify-frame
* New variables:
  + vm-iconify-frame-hook
  + mode-popup-menu (FSF Emacs only, XEmacs already has this)
* full menubar for FSF Emacs.
* popup menu for vm-mode, vm-summary-mode and vm-virtual-mode is
  now the Dispose menu, rather than the whole VM menu set.
* menu consolidations
* set keymap parent of vm-mail-mode-map to mail-mode-map.
* run URL browsers as background commands so that when you quit Emacs
  you don't have to quit the browser.
* fixed "M A" and "M a" bindings to point to correct commands.
* vm-visit-virtual-folder: moved summary display after folder
  display so the summary is displayed in the correct frame.
* vm: at startup, reuse summary frame if available when looking
  for a frame displaying the folder buffer.
* disable "Make Folders Menu" entry if vm-folder-directory is
  nil.
* popup menus for the Subject and From headers.
* fixed "new directory" menu to allow mkdir in
  vm-folder-directory itself.
* "emacs -f vm" now ignores vm-frame-per-folder.
* added `primary-folder' frame type for vm-frame-parameter-alist.

## VM 5.81 released (22 May 1995)

* backquote use in menu and mouse code removed, due to use of newer backquoting
  features that were unsupported in older Emacses.
* Shapiro typo fixes.

## VM 5.80 released (22 May 1995)

* vm-su-do-author still not quite right, code not falling through
  to chop-full-name phase if Full-Name header existed but was empty.
* fixed reversed sense of Page Up/Down menu items.
* added "physical order" to the sort menu.
* match-fetch-field -> mail-fetch-field in vm-menu-can-send-mail-p.
* use two lines of "---" instead of "===" for compatibility with
  XEmacs 19.11.
* changed how vm-folder-history is updated.  Now VM always
  updates the variable itself, and doesn't let read-file-name
  alter it.  This is so we get a real history of folders visited,
  and not a history of what the user typed, typos and all.
* New variables:
  + vm-url-browser
  + vm-url-search-limit
  + vm-highlight-url-face
  + vm-netscape-program
  + vm-mosaic-program
  + vm-menu-setup-hook
* popup menu in Mail Mode now works if you run vm-mail before
  any other VM command.  An initialization omission broke this
  before.

## VM 5.79 released (19 May 1995)

* New commands:
  + vm-mark-messages-same-author
  + vm-unmark-messages-same-author
* New variable:
  + vm-frame-parameter-alist
* don't update vm-folder-history for XEmacs, it's done
  automatically.  Continue to update vm-folder-history for FSF
  Emacs since it needs it.
* updated various Emacs-typecheck functions to rely on the
  contents of emacs-version first and foremost.
* vm-mouse-set-fsfemacs-mouse-track-highlight changed to use
  overlays instead of text properties.

## VM 5.78 released (18 May 1995)

* needed to pass file history as sixth arg to read-file-name
  instead of fifth arg.
* needed to pass variable name as history instead of its value.
* FSF Emacs' read-file-name doesn't take six args, needed a wrapper
  function to pass it only five args if it balks at six.
* stopped using add-hook for vm-folder-history
* vm-other-frame and vm-visit-folder-other-frame needed wrappers
  to set vm-frame-per-folder to nil so they wouldn't create too many
  frames.

## VM 5.77 released (18 May 1995)

* send APOP command with two args instead of one, as the spec demands.
* vm-display-buffer makes the buffer to be displayed or
  undisplayed the current buffer before searching for display
  hooks.  Useful for having buffer local display hooks.
* start n at 2 in vm-rename-current-mail-buffer.
* indention -> indentation
* integrated Heiko Muenkel's vm-folder-menu.el; required addition
  of tree-menu.el to distribution.
* New file: vm-menu.el, which contains the menus and menu code.
* New variables:
  + vm-frame-per-folder
  + vm-frame-per-composition
  + vm-use-menus
* New commands:
  + vm-quit-just-iconify
* New files:
  + easymenu.el
  + tree-menu.el
  + vm-mouse.el
  + vm-menu.el
* mouse support
* vm-pipe-message-to-command now takes 3 C-u's to mean use the
  visible headers plus the text section.
* changed vm-munge-message-separators to munge messages in
  From_-with-Content-Length folders, too.  Necessary now since
  From_-with-Content-Length parsing falls back to a pseudo type
  From_ if no Content-Length header is found.  This fixes a
  digest bursting bug that occurred if From_ message separators
  appeared in a message that was being burst into a
  From_-with-Content-Length folder.
* strip doublequotes from recipient full names as we do for sender full
  names.
* Changed Makefile to use vm-byteopts.el for the support stuff
  too.
* updated vm-grok-From_-* to reject inappropriate types better.
* made vm-next-command-uses-marks set this-command.  Needed for
  the menubar invocation of the command.
* vm-su-do-author: moved blank full name test before the address
  gets chopped.  Also changes search regexp from "^[ \t]+$" to
  "^[ \t]*$" to catch "".
* added a folder history list which is used by vm-visit-folder*.
* composing-message default configuration changed to "full screen
  composition".  Previously it was "summary on top, composition
  on bottom".

## VM 5.76 released (7 May 1995)

* "\.el$" -> "\\.el$" in make-autoloads.
* moved message separator unstuff call before the header
  conversions in vm-rfc1153-or-rfc934-burst-message.  Unstuff
  must come first or the Content-Length offsets might be
  invalidated by it.
* if full name is just whitespace, use the address instead in summary cache.
* vm-burst-digest now can be invoked on marked messages via
  vm-next-command-uses-marks.
* prefix arg to isearch commands now toggles value of
  vm-search-using-regexps.
* don't delete after saving when archiving if vm-delete-after-saving
  is non-nil and vm-delete-after-archiving is nil.
* fixed bug in vm-physically-move-message that was causing
  vm-headers-of marker corruption.  This bug could have caused
  serious folder corruption in BABYL folders, due to the headers
  that are copied for this folder type.
* turned off dynamic docstrings and lazy loading in
  vm-byteopts.el.  This is a preemptive strike against the new
  features of the byte compiler that will appear in FSF Emacs
  19.29.
* docstring typo fixes.

## VM 5.75 released (30 April 1995)

* reinstated code that turns on auto-save-mode in
  vm-mail-internal.  Thought it was redundant; it ain't.
* fixed bug in vm-set-xxxx-flag.  The same message was being put
  into all the undo record lists, which loses when the folder
  containing that message goes away.
* fixed bug in vm-save-message.  needed to call
  vm-error-if-folder-empty in the (interactive ...) spec before
  relying on the value of vm-message-pointer to have a non-nil
  value.
* fixed bug in vm-convert-folder-type-headers; search for
  trailing message separator was starting in the wrong place---
  needed an extra save-excursion around code that computed
  content-length.
* fixed bug in vm-find-trailing-message-separator.  Needed to
  move backward to start of separator after the fallback "^From "
  search.
* output from movemail is no longer considered fatal.  If
  call-process returns a number, then the error is considered
  fatal only if this number is non-zero.  Otherwise upon
  unexpected output, a warning message is issued and VM carries
  on.
* added status message in vm-pop-move-mail to count out messages
  as they are retrieved.

## VM 5.74 released (24 April 1995)

* added new test data for mail-extract-address-components to
  catch its failure to handle "" in some older versions.
* expand ~/ instead of ~ in vm-mail-internal, so that
  default-directory's value ends in a slash.
* fixed bug in vm-{next,previous}-message-same-subject that left
  vm-message-pointer at the wrong position if the search for a
  message with the same subject failed.
* FSF Emacs 19.28.90 breaks make-autoloads by adding a *Messages*
  buffer with a default-directory different from the directory VM
  started in.  This buffer ends up being selected, which makes
  find-file-noselect not read in the wanted VM source file.
  Fixed this.
* From_-with-Content-Length folder type now less strict.
  (Uncle!)  If the position indicated by Content-Length doesn't
  look like a message separator point, VM searches forward for a
  line beginning with "From ".  A side effect of this is that a
  bug is fixed in the digest bursting code that affected bursting a
  message in a From_-with-Content-Length folder.
* skip >From at the beginning of MMDF messages.  I don't know if
  SCO is at fault or SCO system sysadmins, but I'm tired of these
  bug reports.
* <= should have been >= in tapestry-first-window, oops.
* in vm-discard-cached-data, the header markers needed to be
  discarded before the message was rethreaded, otherwise the
  threader and summary functions would use the invalid markers.
* Shapiro typo fixes

## VM 5.73 released (7 April 1995)

* allow a default non-nil value for vm-folder-read-only to work.
* moved the running of vm-arrived-message-hook into
  vm-assimialte-new-messages.
* expand folders, crash box and primary inbox using vm-folder-directory
  as root if path is relative; this wasn't being done everywhere.
* new reporter.el
* stop padding the monthday
* added reply-to to the default value of vm-resend-bounced-headers
* if mail-default-reply-to == t init with (getenv "REPLYTO") for
  compatibility with FSF Emacs v19.29 change.
* changed vm-pop-send-command to not put the user's password in
  the trace buffer.
* set default-directory to either vm-folder-directory or ~ in
  vm-mail-internal.  This cut down on autosave errors due to
  unwritable directories.
* fixed bug in tapestry.el that caused recreation of tapestries
  with horizontally split windows to be off by one in size.
* made tapestry.el use window-pixel-edges in XEmacs, if
  available.  Apparently the window-edges function is going away.
* fixed bug in tapestry-first-window.  menu-bar-lines frame
  parameter can be non-zero when Lucid menubar is enabled even
  though the menubar doesn't steal lines form the topmost window.
* fixed bug in vm-build-virtual-message-list, the next folder
  after a directory in the virtual folder spec was being skipped.
* vm-thread-indention -> vm-th-thread-indention typo
* fix call to error in vm-help-tale, too many args.
* vm-run-user-summary-function was using the virtual message in
  some contexts; changed to use the real message in all contexts.
* changed vm-set-edited-flag-of to a function, rolled common code
  from several functions that use vm-set-edited-flag-of into it,
  made the buffer modification flag always get set when the
  'edited' flag changes.
* New variable: vm-arrived-messages-hook.
* removed call to auto-save-default in vm-mail-internal as I
  don't see why it would ever be needed.
* changed vm-get-folder-type to accept start and end args;
  vm-pop-retrieve-to-crashbox uses these to specify where to scan
  in the POP trace buffer to determine if there is a folder type.
* %+ -> %& in mode line spec.  %+ got usurped by RMS into
  something else.  %& now does what %+ was supposed to do.
* fixed bug in vm-expunge-folder.  It did not work properly with
  marks because parts of the code assumed that mp always traversed
  vm-message-list, which was not true if marks were being used.
* made the virtual folder spec parser skip auto-save files and
  backup files when globbing the contents of a directory.

## VM 5.72 released (29 May 1994)

* doc fixes
* fixed vm-after-revert-buffer-hook to not attack non-VM buffers.
* changed calls to find-file-name-handler to specify the
  operation; I don't care why.
* run hooks in vm-arrived-message-hook for messages returned by
  the call to vm-assimilate-new-messages.
* call vm-find-leading-message-separator before calling
  vm-skip-past-leading-message-separator in the vm-stuff-
  functions.  This avoids stuffing headers before the leading
  message separator due to vm-skip-past-leading-message-separator
  being confused by newlines at the beginning of folder.

## VM 5.71 released (25 May 1994)

* (fboundp 'mail-signature-file) -> (boundp 'mail-signature-file).
  graaaggg.
* vm-mutable-window non-nil non-t special behavior
  eliminated.
* added `exit-minibuffer' to the list of commands VM will do
  window config setup for.  This is so that recover-file and
  revert-buffer, which read from the minibuffer but do not
  protect the value of this-command, have window configuration
  done for them.
* fixed VM support for revert-buffer for v19.23 Emacs;
  revert-buffer now preserves some marker positions across the
  reversion and this hosed VM's check for reversion since it used
  the marker clumping as an indicator of the reversion.  v19.23
  has a new after-revert-hook that VM uses.
* Shapiro and Foiani typo fixes.

## VM 5.70 released (18 May 1994)

* added missing quote in (fboundp mail-signature-file) in vm-reply.el.

## VM 5.69 released (18 May 1994)

* vm-munge-message-separators needed (goto-char start).
* fixed vm-munge-message-separators to pay attention to
  first arg, folder-type.
* fixing vm-munge-message-separators exposed a bug in
  vm-convert-folder-type; trailing message separators were getting
  munged inappropriately because of a bad search bound due to a
  marker being shifted.
* digest bursting code also needed to be fixed, now that
  vm-munge-message-separators is actually doing the (goto-char start);
  match-data needed to be saved and restored, needed to start
  munging after inserting the leading message separator instead of
  before inserting it.
* moved message order gobbling into vm-assimilate-new-messages;
  needed because thread sorting is done there and message order
  gobbling needed to be done before thread sorting.
* In FSFmacs 19.23, find-file-name-handler takes two args, it
  used to take only one.  The second arg is not optional.  Fixed
  code to deal with the one or two arg versions of this function.
* tink message modflag if we encounter a v4 attributes header in
  vm-read-attributes.  The idea is that if the user saves the
  folder we get rid of those retro headers, so the user gets a
  fast summary thereafter.
* get rid of vm-unhighlight-region, since it adds text properties
  that we definitely don't want to find their way in the summary
  cache headers.
* made signature insertion work more like mail-mode; use
  mail-signature-file for lemacs compatibility, insert the
  mail-signature string itself, instead of using it as a file
  name (oops).
* don't go to point-max if to is null in vm-mail-internal--- keep
  point just after the header/text separator line.
* added the word "encapsulation" to RFC 934 digest start.
* fixed babyl label reading bug; needed to skip past comma after
  attributes.
* use regexp-quote on mail-header-separator before using it as a
  search string; can't count on users not putting plusses and other
  regexp crap in it.
* dropped def of vm-highlight-region.
* dropped the spaces after the commas in the label strings.
  Previous convention seems to be to not display them.
* doc string fixes.

## VM 5.68 released (12 April 1994)

* vm-resend-bounced-message now strips Sender.
* for From_-with-Content-Length in vm-find-leading-message-separator
  use (match-end 1) instead of (match-beginning 0).
* fixed code in vm-find-trailing-message-separator so that it
  allows mutiple bogus newlines at the end of a message at the
  end of a From_-with-Content-Length folder.  Turns out this code
  is really needed, and I found out after I broke it.
* vm-byte-count -> vm-su-byte-count in vm-save-message.
* removed unneeded (setq vm-need-summary-pointer-update t) forms in
  vm-motion.el.
* don't flush in vm-flush-cached-data if vm-message-list is nil.
* header highlighting is now done using overlays
  instead of text properties in FSF 19.  This should cure the
  "text property leaking in to the summary cache" problem.
* summary highlighting is now done using overlays in FSF Emacs and
  extents Lucid Emacs 19.
* header highlight under Lucid Emacs is now done using the
  out of the box header highlighting functionality.
* Shapiro typo fixes.

## VM 5.67 released (6 April 1994)

* used match-end instead of match-beginning in
  vm-find-leading-message-separator for From_-with-Content-Length
  folders. (ack!)
* revised some docstrings.
* added docstrings for many internal functions.
* made vm-find-and-set-text-of to set start of text section to
  (point-max) if \n\n wasn't found.  This is more likely to be
  right than setting it to (point) when the search fails.
* put kludge in make-autoloads to deal with v19 autoload fifth
  arg breakage.
* vm-auto-archive-messages now natters about what it's doing,
  since it's often long running and slow.
* don't stuff labels unless there are messages in the folder.
* fixed a couple of calls to format that had too few args.

## VM 5.66 released (26 March 1994)

* added call to vm-unhighlight-region to turn off highlighing of
  headers gathered from the folder buffer.
* set current buffer to real message's buffer, not virtual
  message's buffer, in vm-save-message-sans-headers.
* use `signal' with folder-read-only instead of calling `error'
  in vm-save-message.
* fixed type mismatch error message in vm-save-message; must use
  (vm-message-type-of m) instead vm-folder-type because current
  buffer is the target folder buffer and not the source buffer
  during buffer->buffer saves.  Went ahead and changed the
  buffer->file code for consistency.
* changed all calls to get-file-buffer to vm-get-file-buffer,
  which makes all file->buffer mapping try truenames as well as
  unchased names.
* allow leading newlines in From_ and From-_with-Content-Length
  type folders.
* allow multiple trailing newlines in From-_with-Content-Length
  type folders.
* moved call to vm-convert-folder-type-headers up a bit in
  vm-convert-folder-type, as content-length header generation
  needs the old folder type's trailing message separator to be
  present.  This makes everything-but-mmdf ->
  From_-with-Content-length crash box conversion work right.
  Apparently no one ever tried this.
* moved call to vm-convert-folder-type-headers up a bit in
  vm-change-folder-type, as content-length header generation
  needs the old folder type's trailing message separator to be
  present.  This makes everything-but-mmdf ->
  From_-with-Content-length folder conversion work right.
  Apparently no one ever tried this.
* fixed marker shift problem in vm-change-folder-type that caused
  inserted trailing message separators to be stripped.
  Conversion from From_-with-Content-Length to other folder types
  triggered this because there's no trailing message separator
  for From_-with-Content-Length folders.
* don't clump messages together if Content-Length is wrong.
  this meant moving the content-length goop from
  vm-find-leading-message-separator to
  vm-find-trailing-message-separator, which is where it should
  have been anyway.
* insert "-- \n" before the signature.  not worth the
  argument or unending bug reports.
* fix code that assumes a non-nil value for buffer-file-name in
  folder buffers.

## VM 5.65 released (17 March 1994)

* fixed reverse link bug in vm-expunge-folder that was causing
  renumbering to bug out.
* "folder buffer has been deleted" for those who could not figure
  this out on their own.
* dot unquote fix in 5.64 wasn't quite right; try again.
* turning off threading now sorts by physical order to avoid the
  misleading modeline display.
* vm-{mark,unmark}-message-same-subject now follows the summary
  cursor.
* fixed logic error in vm-unthread-message; messages without
  parents were not being unthreaded.
* dropped unused ref to unread-command-event.
* same subject mark commands now report the number of messages
  they mark or unmark.
* don't mark buffer modified unless sort actually changed the
  message order.
* dropped vm-preview-current-message call in vm-save-folder;
  we'll see what the effects are.

## VM 5.64 released (9 March 1994)

* dropped call to widen in vm-do-reply, unneeded now that
  vm-yank-message is called instead of doing the yanking
  internal to vm-do-reply.
* always do the stuff in vm-set-buffer-modified-p regardless of
  the real modified flag's value.
* unquote _all_ leading dots in inbound POP messages.
* don't call vm-preview-current-message in an possibly empty
  folder in vm-assimilate-new-messages.
* don't override pre-sort by calling vm-gobble-message-order in vm.

## VM 5.63 released (7 March 1994)

* Shapiro typo fixes
* dropped duplicate buffer suppression in vm-build-virtual-message-list;
  not currently needed and doesn't work anyway.
* avoid globally setting tab-stop-list in vm-minibuffer-show-completions.
* fixed free var ref "form" in vm-read-password.
* dropped some unreferenced vars in tapestry.el
* replaced (get-file-buffer buffer-file-name) with
  (current-buffer) in vm-get-spooled-mail, an obvious
  optimization.
* check inbox against name and truename in vm-get-spooled-mail to
  avoid being tripped by find-file-visit-truename being non-nil
  and get-file-buffer's obliviousness thereof.

## VM 5.62 released (6 March 1994)

* vm-burst-digest was honoring vm-delete-after-bursting in the
  real folder instead of the virtual one; fixed.
* vm-add-message-labels didn't work in a virtual folder because
  vm-label-obarray was uninitialized; fixed.
* onw -> one in vm-visit-folder-other-window
* vm-get-new-mail, and vm-save-folder now map themselves over the
  associated real folders when applied to a virtual folder.
* since vm-save-folder now has a meaning when applied to virtual
  folders, vm-save-and-expunge-folder works for virtual folders.
* moved (intern (buffer-name) vm-buffers-needing-display-update)
  into vm-set-buffer-modified-p and out of vm-save-folder.
* incremented vm-modification-counter in vm-toggle-virtual-mirror.
* incremented vm-modification-counter in vm-build-virtual-message-list.
* fixed vm-su-line-count to use the real message offsets, not
  the virtual message offsets.
* fixed expunge in unmirrored virtual folder to remove virtual
  messages from the virtual message list of the real message.

## VM 5.61 released (3 March 1994)

* moved vm-session-initialization and vm-load-init-file to
  vm-startup.el so as to avoid autoloading vm-folder.el for M-x
  vm-mail.
* removed call to vm-follow-summary-cursor from vm-mail so as to
  avoid autoloading vm-motion.el for M-x vm-mail.
* added L to regexp string in vm-compile-format.
* changed vm-error-if-folder-empty to complain about the folder
  type being unrecognized if that is the reason the folder is
  deemed empty.
* changed modeline to reflect the "unrecognized folder type"
  condition.
* use epoch::selected-window instead screen-selected-window if it
  is fbound.

## VM 5.60 released (1 March 1994)

* vm-set-edited-flag -> vm-set-edited-flag-of
* forgot to fix interactive spec of vm-yank-message; fixed.
* vm-search18.el: signal error if vm-isearch is attempted in a
  virtual folder.

## VM 5.59 released (26 February 1994)

* was calling pos-visible-in-window-p in wrong window in
  vm-scroll-forward; fixed, which takes care of preview/scrolling
  problems introduced in VM 5.58.
* fixed interactive spec of vm-yank-message-other-folder
* call vm-yank-message with only one arg in
  vm-yank-message-other-folder
* made vm-help-tale be a little less rude.
* '?' gives help in vm-read-string
* dropped top level requires in favor of autoloads
* use vm-selected-frame everywhere, instead of error-free-call
* do multi-screens in Lucid Emacs like multi-frames in FSFmacs.

## VM 5.58 released (26 February 1994)

* New variables:
  + vm-included-text-headers
  + vm-included-text-discard-header-regexp
  + vm-summary-highlight-face
* New commands:
  + vm-add-message-labels (la)
  + vm-delete-message-labels (ld)
  + vm-virtual-help (V?)
* new semantics for vm-yank-message
* lookup vm-spool-move-mail and vm-pop-move-mail in
  file-name-handler-alist.
* set stop-point properly if using marks in
  vm-auto-archive-messages.
* in Makefile rm -f vm-search.el to evade a read only copy.
* don't assume the subject thread obarray is setup properly or
  ditto for the message id thread obarray.  User may have
  interrupted the thread build and screwed things up.
* V? gives some help for V commands.
* put ... after mark help.
* Shapiro typo fixes.
* switch to virtual buffer before comparing edited message to
  current message.  also compare the underlying real messages
  instead of the possibly virtual ones.  this makes the current
  message be repreviewed appropriately if it is virtual.
* don't generate a summary in vm if recover-file is likely to happen,
  since recover-file does nothing useful in a summary buffer.
* changed VM to use \040 instead of \020 in babyl attribute parsing code.
  obvious error in babyl spec.
* small change to vm-minibuffer-complete-word to handle label
  reading.  since we don't demand a match for label reads, we
  have to let the user insert a space for multi-word reads.
* undo now says what it is doing.
* undo now moves the message pointer to the message that it is
  affecting.
* fixed vm-scroll-forward to mark message as read _and_ scroll
  when point-max isn't visible on screen.  should help with
  vm-preview-lines == t.

## VM 5.57 released (18 February 1994)

* added missing refs to -other-window and -other-frame commands in
  root commands so that window configurations work.
* shuffled targets in Makefile a bit.
* integerp -> natnump in vm-start-itimers-if-needed
* doc string updates.
* added missing -other-frame to the send-digest commands that
  needed them.  fixes the infinite frames, infinite recursion
  problem.
* don't assume a match when descending a nested auto folder
  alist.
* Shapiro typo fixes.
* New commands:
  + vm-set-message-attributes (bound to `a')
* made vm-auto-select-folder signal errors.
* default value of vm-check-folder-types is now t.
* fix modeline at end of vm-auto-archive-messages;
  vm-save-message whacks it.
* use unwind-protect in vm-auto-archive-messages to make sure
  mode line gets fixed if there's an error.
* deal with type 'unknown' in vm-save-message and vm-gobble-crash-box
* warn user about unparsable filth at end of folder.
* fixed typos of &optional in vm-startup.el
* indicate when threading display is enabled in the summary modeline.
* clear modification flag undos after saving folder.
* always setting vm-system-state to showing is wrong; changed it
  back to the way it was before 5.56.
* display sort keys in summary modeline when they are valid.
* used more care when lambda-binding inhibit/enable-local-variables
  must be careful not to change buffers while inside such a let
  binding as it might screw users who set local values of those
  variables.

## VM 5.56 released (14 February 1994)

* vm-save-folder no longer expunges, this also means that 'q' and
  'S' keys no longer expunge.
* New commands:
  + vm-save-and-expunge-folder
  + vm-quit-just-bury
  + vm-other-frame
  + vm-visit-folder-other-frame
  + vm-visit-virtual-folder-other-frame
  + vm-mail-other-frame
  + vm-reply-other-frame
  + vm-reply-include-text-other-frame
  + vm-followup-other-frame
  + vm-followup-include-text-other-frame
  + vm-send-digest-other-frame
  + vm-send-rfc934-digest-other-frame
  + vm-send-rfc1153-digest-other-frame
  + vm-forward-message-other-frame
  + vm-forward-message-all-headers-other-frame
  + vm-resend-message-other-frame
  + vm-resend-bounced-message-other-frame
  + vm-edit-message-other-frame
  + vm-summarize-other-window
  + vm-other-window
  + vm-visit-folder-other-window
  + vm-visit-virtual-folder-other-window
  + vm-mail-other-window
* New variables:
  + vm-quit-hook
  + vm-digest-identifier-header-format
  + vm-confirm-mail-send
* non-nil non-t vm-delete-empty-folders now means ask first.
* select last message in real folder instead of first at startup
  if no unread messages are present (vm-thoughtfully-select-message).
* in vm-get-spooled-mail expand inbox file name rooted in folder
  directory if path is relative.
* don't do physical order sort unless moving messages physically
  in vm-sort-messages.  avoids markers pointing to nowhere at
  virtual folder startup with the threads display enabled.
* don't call display-buffer in vm-display-buffer unless
  vm-mutable-windows is t.
* always set vm-system-state to showing in vm-show-current-message,
  even if message is not visible.  The message-not-visible case is
  handled in vm-scroll-forward.
* moved window config of vm-quit to the beginning of the command
  instead of the end.
* added new window configuration action class: quitting
* don't assume new and unread flags are mutually exclusive in
  vm-show-current-message, they aren't for babyl folders.
* fixed tapestry-set-window-map to coerce Emacs into giving space
  to the right window in the root window case.  Works for FSF
  v19 Emacs.
* ignore trailing spaces in subject for threading and other "same
  subject" purposes.
* changed call to vm-update-summary-and-mode-line to
  vm-preview-current-message in the new same-subject motion
  commands (oops).
* gave vm-virtual-mode a docstring.
* don't allow vm-auto-archive-messages to recurse if a message
  archives to the same folder that it currently lives in.
* slightly restructured modeline to deal with new and unread flags
  both being set in babyl messages.
* burst digest fixes for From_-with-Content-Length and babyl
  folders.
* make require-final-newline be buffer local in VM buffers.
* don't set vm-block-new-mail in vm-mode-internal; it messes up
  the value set by the file recovery code.
* dropped frame configuration part of VM window configuration
  code.  too restrictive.
* use vm-default-folder-type in vm-save-message for empty folders.
* don't use sets for marking messages for summary updates; just
  consing up a list is much faster and the dups don't matter much
  with the speedy new summary code.
* use an obarray for vm-buffers-needing-display-update
* dropped sets.el from the distribution.
* put cursor in the To header for vm-resend-bounced-message.
* don't do Berkeley Mail compatibility stuff unless the current
  folder type is From_.
* use unwind-protect in vm-stuff-attributes to make sure folder
  modified status is reset properly on non-local exit.
* don't change modflag-of for virtual messages in
  vm-build-virtual-message-list; virtual messages don't use this
  flag anyway.
* added a level of indirection for virtual-messages-of so print
  will work on a message struct.

## VM 5.55 released (9 February 1994)

* vm-set-babyl-frob-flag -> vm-set-babyl-frob-flag-of
* rewrote vm-delete-duplicates again; this one doesn't pitch the
  full names in hack-addresses mode.
* made vm-get-header-contents put grouping ^\(...)  around the
  header name regexp instead of just prepending ^.
* vm-yank commands now in the composing-message action class.
* made use of the bundled reporter.el and timezone.el optional in
  Makefile.
* New commands:
  + vm-next-message-same-subject
  + vm-previous-message-same-subject
* fixed bug in vm-assimilate-new-messages; work was being done to
  a virtual folder even if no new messages were added.
* internal thread tree is now built on demand.
* some mods to vm-sort-messages to deal with calls by threading
  code and values of vm-folder-read-only and vm-move-messages-physically.
* moved scattered autoload defs into vm-startup.el.
* doc string updates.
* errors from call to vm-expunge-folder are no longer ignored in
  vm-save-folder.
* default window configuration now uses the split screen mode for
  everything.
* dropped the skip-newlines-at-top-of-folder code.
* dropped single quotes from around sed command; unneeded since
  we're not calling the shell.
* made vm-change-folder-type work; fixed babyl related problems
  along the way.
* run copy-sequence on new-messages before sorting in
  vm-assimilate-new-messages to keep sorting from scrambling the
  value we need to return.
* fixed bugs in vm-convert-folder-type; have to be careful about
  update order since some code depends on correct separator
  strings being present.
* added special code to the POP mail retriever needed for babyl
  crash boxes.
* block mail new mail retrieval while we're getting new mail;
  timer processes might be fired up while the POP code is running.
* added another missing set-buffer-modified-p in vm-gobble-crash-box.

## VM 5.54 released (4 February 1994)

* made vm-discard-cached-data fill the cache with nils instead of
  allocating a new array.  necessary so that the virtual messages
  get their caches wiped too.
* vm-edit-message now unhightlights the edit buffer.
* moved unthread/rethread stuff from vm-edit-message-end to
  vm-discard-cached-data.
* removed thread data prerefs from vm-edit-message and
  vm-discard-cached-data; I no longer think they are needed.
* changed emacs to $(EMACS) in Makefile for make-autoloads run.

## VM 5.53 released (3 Feburary 1994)

* got rid of reuse of count variable in vm-delete-message; used
  del-count instead.  this was hosing motion after
  vm-delete-message-backward.
* fixed bugs in vm-delete-duplicates; was calling vm-delqual with
  an unfrobbed list of addresses; if 'all' was non-nil was
  resetting list and setcdr'ing prev inappropriately.
* Shapiro typo fixes.
* fixed vm-set-xxxx-flag to not add to the undo record list
  twice; more confusion due to virtual folders.

## VM 5.52 released (3 February 1994)

* BABYL file support.
* fixed noautoload target in Makefile to depend on reporter.elc.
* actually put the reporter.el file in the distribution (oops)
* fixed vm-set-xxxx-flag to notice the real message when a
  virtual message flag is set.
* added loop detection code to vm-thread-list.
* added 'redistributed' message attribute, because BABYL files
  support this.  vm-resend-message makes a message
  'redistributed'.
* %A summary format spec now seven characters wide instead of
  six.
* no longer set vm-message-pointer in composition buffers.  It
  doesn't look like it's used anywhere anymore.
* needed make-local-variable calls in some places in vm-reply.el to
  avoid referencing a global variable.
* don't auto-get-new-mail if vm-folder-read-only is non-nil.
* don't try to startup folder read only for vm-yank-message-other-folder.
* fixed logic error in vm-assimilate-new-messages; if real folder
  was empty; the first new messages that arrived would not be
  offered to virtual folders for assimilation.
* fixed logic error in vm-build-virtual-message-list that causes
  new message list not to be installed into an empty virtual
  folder if vm-build-virtual-message-list was passed a message
  list.
* added some code to vm-save-message and vm-assimilate-new-messages to
  get the message pointer set properly when live folders inherit their
  first message from another folder.
* rewrote vm-delete-duplicates to use an obarray.
* fixed another file name expansion in wrong dir problem in
  vm-save-message.
* fixed bug in vm-pop-move-mail; needed (car (cdr ...)) instead
  of (car ...) to get password from assoc list.
* unhighlight text copied into composition buffers.
* use mail-position-on-field in vm-send-digest.
* anonymous virtual folders now can acquire new messages when
  their real folders do.
* drop error free calls in vm-window-loop in favor of checking
  for only one window before doing a delete-window.  Lucid Emacs
  blows away the containing screen if you delete the last
  ordinary window.
* preserve buffer modified status of virtual folder after
  erase-buffer call in vm-do-needed-mode-line-update.
* replaced timezone-floor with Kanazawa Yuzi's fixed version.
* don't makunbound unless there are no message left with a
  subject; previously it was done when there was one message left
  that was a child of the subject, which was quite wrong.  This
  required keeping track of every message with a particular
  subject, which wasn't being done before.
* reset thread-indention-of cache and thread-list-of in vm-unthread-message
* move vm-keep-mail-buffer further down in vm-mail-send so that
  attribute update code can do its work before the buffer
  potentially goes away.
* fixed logic error in vm-save-message; non-conversion error
  message check was reversed regarding virtual messages.
* made vm-save-message report the number of messages saved,
* made vm-delete-message and vm-undelete-message report the
  number of messages deleted/undeleted if marks are used.
* made vm copy the read-only state of a visited folder--- if the
  file was read-only when vm first visits it, the folder will
  be read-only, too.
* added read-only flag to vm-mode; prefix arg interactively.
* New variables:
  + vm-summary-subject-no-newlines
  + vm-keep-crash-boxes
* New commands:
  + vm-toggle-virtual-mirror
  + vm-change-folder-type
* virtual-messages-of in real message was not being updated for
  non-mirrored virtual folders... wrong wrong wrong.  fixed.
* vm-stuff-virtual-attributes was stuffing the data using the
  header offsets of the virtual message instead of the real
  message's offsets... (woo, woo!) fixed.
* doc string fixes
* preserve summary buffer modified status when doing summary
  buffer updates since it's supposed to reflect the folder
  buffer's status.
* moved vm-summary-redo-hook run to be in the summary buffer.
* made unmirrored virtual message not share a summary with real
  messages (oops).
* moved vm-su-summary preref to fill the cache out of
  vm-mark-for-summary-update and into vm-stuff-attributes.
* changed vm-check-for-killed-summary to be a function, and made
  it reset su-start-of and su-end-of of all messages if the
  summary buffer has been killed.
* changed thread indent calculator to start counting from the
  first ancestor that is in the current folder, instead of always
  counting from the root message.
* set require-final-newline to nil for vm-mode buffers.  needed for
  babyl folders.
* added more test data to detect brokenesses in mail-extr.el.

## VM 5.51 released (29 January 1994)

* docstring fixes.
* fixed logic behind how schedule-reindents is set in
  vm-build-threads; startup with ought to be somewhat faster.
* check for vm-message-pointer == nil in vm-sort-messages to
  avoid problems when sorting by thread at startup.
* added reporter.el to distribution.
* changed %* to %+ in modeline in hopeful anticipation of this
  being added to v19 Emacs.
* made sure summary modflag was updated after folder saves; needed
  to add folder buffer to vm-buffers-needing-display-update.
* changed vm-force-mode-line-update to use force-mode-line-update
  if it is bound.
* made vm-make-virtual-copy restore the modified status of the
  virtual folder buffer after doing the copy.

## VM 5.50 released (28 January 1994)

* found and fixed another bug in the threading code that can
  cause looping; interned a symbol into the wrong obarray.
* made vm-save-message-sans-headers remember that last file
  written to, and not claim that a file was written to when it
  wasn't.
* made vm-save-message not claim that a folder was written to
  when it wasn't, and to not visit files, check folder types and
  so on when the prefix arg given was 0.
* fixed doc for vm-summary-uninteresting-senders; pointer -> arrow.
* made sets-typetag be defvar'd instead of defconst'd.  avoids
  trouble if sets.el is reloaded.
* fixed expunge; it was checking for virtual message after the
  virtual message list of the message had been emptied.
* fixed vm-build-virtual-message-list; when new messages were
  assimilated, the old message list overlapped the new causing
  duplicates in vm-virtual-messages-of.
* dropped the rest of the undocumented stuff for hilit19.

## VM 5.49 released (25 January 1994)

* changed timezone.el not to call abs directly.
* changed vm-mail-send-and-exit to notice if it's no longer in
  the composition buffer after vm-mail-send and not to bury
  whatever buffer it happens to be in.
* changed make-autoloads to use Lisp, create proper interactive
  autoloads and to include the doc strings.
* cached date of oldest message in a thread; thread display now
  sorts threads in chronological order of the oldest message
  known to have been in the thread during this VM session.
* fixed threading by subject bug, that I suspect caused endless
  looping in some folders.
* fixed some of the problems with vm-mutable-windows non-t
  non-nil; most in tapestry.el; one in vm-window.el.
* doc fix in vm-summary-format var doc, h -> H.

## VM 5.48 released (23 January 1994)

* @cp -> cp in Makefile.
* fixed bug in vm-load-window-configurations where
  vm-window-configurations is set to t.
* Shapiro typos fixes.
* added timezone.el to the distribution.

## VM 5.47 released (23 January 1994)

* vm-window-configuration-file now has a default value of
  "~/.vm.windows".
* vm-default-window-configuration is now used if reading a
  configuration failed.  previously it would not be used if the
  file vm-window-configuration-file pointed to did not exist or
  was empty.
* expunge caused highlighted area to move over to some unwanted
  areas of text.  made highlighting function nuke the face
  property of the whole message to try to clean this up before the
  user gets to see it.  user will still see it during searches,
  oh well.  real fix is for Emacs to move the properties when the
  text shifts because of insert/delete, which I think Emacs will
  do in the next release.
* first crack at thread support.
  New variables:
  + vm-summary-show-threads
  + vm-summary-thread-indent-level
  * vm-subject-ignored-prefix
  * vm-subject-ignored-suffix
  New commands:
  + vm-toggle-threads-display (C-t)
  + vm-goto-parent-message (^)
  + vm-mark-thread-subtree (M T)
  + vm-unmark-thread-subtree (M t)
* Variables that went away:
  + vm-summary-show-message-numbers
* summary format specifiers %n and %* are allowed again.
* added slot in message struct for the summary to use for its
  padded copy of the message number.  everything else uses the
  unpadded number.
* fixed vm-expunge-folder; a couple of problems with initiating
  expunges from a virtual folder--- some stuff was being done
  twice, and the physical expunge was occurring in the virtual
  buffer instead of the real buffer.
* gave vm-mark-for-summary-update an optional arg that says
  "don't kill the summary entry cache".  this is used by thread
  and marks commands, which don't change anything that the
  summary entry could cache.
* vm-visit-virtual-folder, vm-get-new-mail and vm-burst-digest
  work harder at keeping the totals blurb on the screen in the
  face of autoload messages, summary status, etc.
* made vm-set-numbering-redo-{start,end}-point update
  vm-buffers-needing-display-update.
* made vm-undisplay-buffer not use save-excursion, which
  apparently does a switch-to-buffer in v18 Emacs.
* made vm-undisplay-buffer not select a dead window, since this
  can crash v18 Emacs.  Rewrote it to use
  vm-delete-windows-or-frames-on which already has the smarts
  about not selecting dead windows.
* don't emit totals blurb in vm unless it's a full startup.
  cured problem of calling (message ...) when totals-blurb is nil.
* changed call to buffer-disable-undo to use fboundp to check
  first, and call buffer-flush-undo if it is not fbound.
* disable undo in the summary buffer.
* updated vm-mode doc with missing variables and keys.
* changed make-autoloads to create proper autoload defs for
  macros and to trim the suffixes from the file names.
* folder is now expanded properly in vm-visit-folder before
  calling vm.
* if call of read-file-name with five args fails (v18 doesn't
  take the INITIAL-INPUT arg) call it with the expansion dir set
  to what would have been the fifth arg.
* Shapiro typo fixes.
* don't signal error in vm-expunge-folder if there are no deleted
  messages.
* fixed summary rebuild problem in vm-expunge-folder related to
  virtual folders.
* changed vm-kill-subject to use vm-so-sortable-subject
* added new action class "marking-message" and put the mark and unmark
  commands in it.
* some of the motion commands now follow the summary cursor.
* dropped a bit of stupidity at the end of
  vm-next-command-uses-marks; why o why was I prereading the next
  input event?
* fixed message assimilation into virtual folders.
* made vm-move-message-forward silently not try to move a message
  physically if it's in a virtual folder.
* updated documentation for vm-get-new-mail.
* dropped the refcard from the distribution.
* if summary format doesn't match the cache summary format, force
  a restuff of the cache of all messages when the folder is saved.

## VM 5.46 released (17 January 1994)

* added header highlighting for FSF Emacs 19.
  + slightly different sematics for vm-highlighted-header-regexp
    to match the new header name matching rules.
  + new variable vm-highlighted-header-face to specify what face
    to use for highlighting.
* fixed make-autoloads to create autoloads pointing to .elc files
  instead of .el files.
* updated laggard copyright notice in startup message.
* chopped out undocumented hook for hilit19 in
  vm-preview-current-message.

## VM 5.45 released (17 January 1994)

* Shapiro typo fixes
* editing a message that already had an edit buffer caused window
  config failure; window config code couldn't find the edit
  buffer, because the current buffer was not the edit buffer.
  fixed by calling set-buffer for this case in vm-edit-message.
* dropped unneeded calls to vm-previous-window in vm-window.el.
  calling (next-window w 'nomini) is sufficient to avoid the
  minibuffer and to avoid drifting into another frame while
  evading the minibuffer.
* make vm-next-message do its own window configuration when
  called by vm-delete-message and others, so auto-motion pops up
  the correct configuration.
* VM now has a default window configuration.
* the unwind form in set-tapestry could select a dead frame; we
  now check with frame-live-p before selecting the saved frame.
* removed the kludge from tapestry-set-frame-map, it didn't work
  reliably anyway.
* changed vm-undisplay-buffer not to delete a frame unless there
  only one window in it.
* VM now autoloads all of its modules on demand.  some functions
  moved to different modules for better locality of related
  functions.  some care given to how display update lists
  were built so as to avoid calling summary update functions on
  messages that actually are part of a folder that does not have a
  summary.  Turned out mostly to be a waste, the summary gets
  loaded almost immediately unless serious contortions are made.
* New files:
  make-autoloads - build the autoload defs
  vm-startup.el - contains all VM entry point functions
  vm-minibuf.el - contains most of VM's minibuffer read functions.
* work harder at vm startup to keep the totals blurb on the
  screen despite all the autoload tripe blasting the
  minibuffer.
* added a documented cardinality function to sets.el.
* made vm-emit-eom-blurb not call vm-su-full-name, which avoids
  dragging in the summary code unnecessarily.
* check for killed folder buffer in vm-mark-replied and
  vm-mark-forwarded to avoid trying to set-buffer to a killed
  buffer.
* moved a ( in a docstring right to avoid it being in column 0.

## VM 5.44 released (16 January 1994)

* fixed free variable reference (length) in vm-edit.el.
* added a few missing commands to the supported window
  configurations list.
* wrapped call to mail-send in save-excursion to protect against
  a buffer change.
* moved call of vm-rename-current-mail-buffer in front of
  vm-keep-mail-buffer so that if vm-keep-sent-messages is nil we
  won't rename some random buffer because the current buffer had
  been killed.
* added doc for vm-submit-bug-report to vm-mode doc.
* added optional first argument to tapestry which allow
  specification of which frames to return info about.
* made vm-save-window-configuration record configuration info
  only about the selected frame if vm-mutable-frames is nil.
* %* format spec no longer allowed in summary format, for the
  same reason the %n spec was disallowed.
* made the "get new mail" call of vm-assimilate-new-messages in
  vm not read message attributes, so we don't inherit X-VM stuff
  from messages sent by others.
* was calling select-frame in set-tapestry, changed to call
  tapestry-select-frame instead.
* made tapestry and set-tapestry no change Emacs' idea of what the
  selected-frame is.
* made vm-set-window-configuration more friendly to errors
  + if the window config requires a summary buffer and none is
    present and the folder buffer isn't displayed either, then
    display the folder buffer where the summary would have been
    displayed if it existed.
  + if the window config requires an edit, composition, or
    summary buffer and it is not present, delete windows and
    frames that would have displayed it.
* moved "hide" check in vm-scroll-forward to be prior to the
  first usage to the window we're checking.
* Shapiro typo fixes, as usual, sigh.
* more virtual folder selectors
* made virtual folder selectors that require dates be more
  flexible and fill in incomplete date specifications.
* removed redundant and incorrect calls to vm-check-count from
  vm-mark-message and vm-unmark-message.
* fixed bug in vm-timezone-make-date-sortable; used car to access
  chace when should have used cdr.
* New commands:
  + vm-mark-matching-messages
  + vm-unmark-matching-messages
  + vm-create-virtual-folder
  + vm-apply-virtual-folder
* default value of vm-virtual-mirror is now t.
* added missing mapping of vm-virtual-mode to `message' in
  vm-set-window-configuration.
* fixed sent-before and sent-after selectors to call
  vm-so-sortable-datestring instead of vm-so-sortable-date.
* modeline indicates folder virtuality by surrounding the buffer
  name with parens, eats less space than "virtual " particularly
  when the folder are nested.
* fixed vm-beginning-of-message and vm-end-of-message so they
  again work when invoked from the summary buffer.
* added vm-beginning-of-message, vm-end-of-message, and
  vm-expose-hidden-headers to the reading-message action class.
* changed vm-expose-hidden-headers to force the displaying of the
  folder buffer.
* changed calls of get-buffer-window to vm-get-buffer-window so
  that searches for buffers in windows fan out to all frames when
  it is appropriate.
* added let-bind of buffer-read-only to nil around call to
  erase-buffer in vm-do-needed-mode-line-update.
* rewrote vm-mark-for-summary-update again, and hopefully got it
  right this time.
* fixed problem in vm-virtual-quit; vm-message-list needed to have
  expunged messages stripped before vm-message-pointer was rehomed
  there. virtual folder can now shrink to 0 messages without errors.
* fixed some bad logic in vm-assimilate-new-messages that caused
  the summary to be rebuilt every time you ran M-x vm.

## VM 5.43 released (14 January 1994)

* changed another reference to window-frame in tapestry.el that I
  missed, sigh.
* added vm-mutable-frames to var list in vm-submit-bug-report
* put vm-edit-message-end and vm-edit-message-abort into the
  reading-message and startup action classes.
* changed vm-set-window-configuration to bail if the current
  buffer isn't a VM related buffer.
* changed vm-set-window-configuration to create some descriptive
  buffers when a configured buffer can't be found, to let users
  when they've flubbed the window configuration setup.
* made vm-convert-folder-header-types a bit more robust
* made vm-find-leading-message-separator go to point-max for
  From_-with-Content-Length folders if no separator is found just
  as it does for the other folder types.
* made vm-edit-message-end properly recompute the Content-Length
  header for the From_-with-Content-Length type.
* made vm-edit-message-end munge message separators that it finds
  in an edited message before the message is reincorporated into
  the folder.
* made vm-convert-folder-types munge message separators of the
  new folder type as part of the conversion process.
* Greg Shapiro's and Andy Scott's typo fixes
* %n spec is gone from the summary format; new summary cache code
  would cause the messaage number to be cached and this caused
  many problems.
* New variables:
  + vm-summary-arrow
  + vm-summary-show-message-numbers
* New command:
  + vm-forward-message-all-headers

## VM 5.42 released (13 January 1994)

* made tapestry-frame-map call tapestry-window-frame instead of
  window-frame directly, which bombs under v18 Emacs.
* made vm-get-mail-itimer-function call
  vm-assimilate-new-messages with a first arg non-nil, so that
  attributes found in newly arrived  messages will be ignored.
* removed some local-set-key calls in vm-do-reply that I forget
  to take out.
* dropped the keymap parent stuff altogether, mimic mail-mode
  bindings in VM's mail mode, use vm-edit-message-map and simply
  override text mode map or whatever, copy the vm-mode-map to
  create the summary mode map.
* drop cat-chow from the variable list in vm-submit-bug-report.
* added a salutation and subject to vm-submit-bug-report
* corrected vm-edit-message-end typo in vm-vars.el
* moved vm-isearch-forward back to M-s, took vm-isearch-backward
  off C-r.
* vm-goto-message now does not follow the summary cursor if a
  prefix argument is given.
* added vm-mail-send-and-exit to the reading-message and startup
  action classes.  ought to keep the *scratch* buffer from popping
  after sending mail when reasonable window configurations are enabled.
* New variables:
  + vm-trust-From_-with-Content-Length
* signature now appears after forwarded messages and digests,
  instead of before them.
* added tapestry autoloads.
* removed more references to vm-ml-attributes-string
* turned off modification flag in crashbox buffer after folder
  conversion to keep kill-buffer silent.
* turn on Emacs 19 compatbility in vm-byteopts.el.

## VM 5.41 released (10 January 1994)

* fixed "~/INBOX" dreg in vm-get-folder-type.
* added more test data to detect for broken
  mail-extract-address-components implementations
* added SHELL = /bin/sh to Makefile.
* added a current folder buffer slot to message struct so that
  (marker-buffer (vm-start-of message)) is no longer necessary.
* VM no longer changes the message pointer on async auto-get-new-mail
  unless the folder was previously empty.
* VM now queries for a POP password if the password is "*" in
  vm-spool-files.
* made vm-visit-virtual-folder honor vm-startup-with-summary.
* older Lucid Emacs versions apparently don't have the improved
  insert-file-contents; changed test in vm-get-folder-type to deal
  with it.
* took vm-yank-message-other-folder off C-c y.
* some fixes for the keymap troubles
  + use keymap parenting when we can
  + vm-mail-mode-map
  + vm-edit-message-map
* added support for the System V Content-Length folder type.
* much work on the display code
  + added vm-display clearinghouse function for display work
  + per command window configuration support added.
  + weird window configuration related scrolling bugs fixed
* New variables:
  + vm-mutable-frames
  + vm-display-buffer-hook
  + vm-undisplay-buffer-hook
  + vm-reply-ignored-reply-tos
  + vm-move-messages-physically
  + vm-tale-is-an-idiot
  + vm-summary-pointer-update-hook
* Variables that went away:
  + vm-retain-message-order (message order is always retained now.)
  + vm-mail-window-percentage (have to use window configs for this now.)
* frame support added to tapestry.el
* file recovery and reversion now deals with virtual folders.
* SPC now invokes completion in vm-read-string, which means
  minibuffer reads of sort keys now have completion on both TAB
  and SPC.
* various minor contortions to quiet the compiler.
  + added some defvars
  + moved error condition puts to vm-misc.el
  + added a compile-time preloaded file vm-byteopts.el
* added documentation for more VM entry points to README.
* strip quotes from ends of full name in vm-su-do-author.
* fixed attribute stuffing code to properly correct the changed
  value of vm-headers-of in all cases.
* made sets.el use prin1-to-string instead of (format "%S" ...)
  since %S doesn't work under v18 Emacs.
* save the correct modeline variables in vm-search18.el;
  vm-ml-attributes-string is gone.
* change vm-su-do-month to avoid using all those symbols
* rewrote vm-search19.el to work and work better.
* vm-isearch-forward moves from M-s to C-s
* vm-isearch-backward command created.
* vm-isearch-backward on C-r
* made the message separator string generator functions look at
  the local variable that they set.  by looking at the wrong
  variable they used the wrong folder type.
* added needed narrow-to-region to vm-pop-retrieve-to-crashbox
  so that folder type could be correctly deduced.
* jwz improvements
  + fixed width hh:mm:ss
  + negative precision in summary spec means truncate from the right
  + vm-delete-duplicates rewritten to be slow (and not reorder elements)
  + vm-delete-duplicates also handles addresses specially if asked
* fixed bug in vm-default-chop-full-name; it should result a
  non-nil value in the 'address' part of the list.
* fixed typo in vm.texinfo
* fixed unnoticeable bug in vm-set-{summary,numbering}-redo-start-point
* fixed vm-expunge-folder to not do redundant sets of the summary
  and numbering start points.
* fixed vm-expunge-folder to be lock out interrupts at
  appropriate places.
* fixed vm-expunge-folder to expunge the real message when a
  mirrored virtual message is expunged.
* changed vm-build-virtual-message-list to allow a list to be
  built from a virtual folder's message list by looking through
  it to the real messages underneath.  This is a prelude to
  on-the-fly virtual folder creation.
* added many new virtual folder selectors, including 'and', 'or'
  and 'not'.
* vm-resend-message now strips the Sender header from the message.
* vm-move-message-forward locks out interrupts in the right place
  to protect message list integrity.
* fixed vm-sort-messages bug that caused it to put the message
  into the wrong physical order.
* added two commands: vm-move-message-forward-physically and
  vm-move-message-backward-physically.
* fixed bug in vm-resend-bounced-message; if it found no header
  separator line it would insert one in the wrong place.
* new semantics for vm-startup-with-summary
* entire summary entries now cached, which means almost now work
  to generate a summary at startup now.
* VM now does summary, numbering and modeline updates even if it
  is quitting.  virtual folder displays will be out of sync otherwise.
* VM now ignores message attributes that arrive attached to new mail.
* last vm-gargle-uucp dreg removed.
* VM no longer sets inbox file permissions to 600.
* added some undocumented hooks for hilit19.el until it starts
  using the proper hook variables.
* added protection for the variable this-command to the
  (interactive) forms that needed it.
* added protection for the variable last-command to the
  (interactive) forms that needed it.

## VM 5.40 released (21 December 1993)

* made vm-edit-message-end preview if edited message is current;
  comparison bug caused it not to.
* removed extra definition of vm-do-needed-mode-line-update
* fixed mail-extract-address-components test code.
* fixed problem with summary mode line not being updated if
  expunge empties the folder.
* fixed Makefile install target to copy vm.info to $(INFODIR)/vm .
* more doc corrections from Greg Shapiro.
* fixed long line Summaries node in Info document.
* fixed bug in vm-default-chop-full-name, should use list instead
  of cons for the return value.

## VM 5.39 released (21 December 1993)

* sanity checked all bindings of case-fold-search.
* sanity checked all searches for reasonable ambient values of
  case-fold-search.
* adopted most of Kevin Rodgers latest round of changes to
  vm-su-do-author, to parse full names and addresses a bit better.
* changed 'file' to 'folder' in vm-save-message to fix an invalid
  variable reference.
* New variables:
  + vm-check-folder-types
  + vm-convert-folder-types
* Variables that have gone away:
  + vm-gargle-uucp
    (wrote this for late eighties melee, things are different now)
* added call to set-window-point in vm-preview-current-message so
  that window-point is set properly in time for a vm-howl-if-eom
  call from a parent function.
* fixed set-xxxx-flag and vm-update-message-summary to create
  correct update lists taking into account virtual folders.  The
  code wasn't quite right.
* fixed vm-update-message-summary not to try to use buffer-name
  to determine if the vm-su-start-of is a live buffer.  Just
  marker-buffer will do, apparently.  Killing the summary should
  safe to do again.
* added a vm-submit-bug-report command based on reporter.el.
* emit totals blurb in various places before selecting a message
  to prevent the non-previewers from altering the new message
  count and confusing themselves.
* checked for existence of vm-arrived-message-hook before running
  the loop.
* put vm-howl-if-eom after the vm-update-summary-and-mode-line
  because the howl contains the message number and the correct
  message number may not be computed in some cases until after the
  update.
* fixed many bugs with virtual folders.
* incremented vm-modification-counter in vm-burst-digest which
  should make the totals blurb be recomputed; previous it wasn't.
* removed a couple of (apparently) unneeded re-search-forward's in the
  message yanking code.
* added X400-Received to a couple of the default header discard
  lists.
* fixed POP retriever to check for servers that DON'T strip
  message separators.
* -hooks vs. -hook; hobgoblins win.
* added some defvars to quiet the v19 compiler (a little)
* made vm-spool-move-mail kill the miserable buffer if nothing
  went wrong.
* added doc string for vm-summary-mode-hook
* added more general date parser
* added 'H' (hh:mm)  summary specifier
* normalized vm-su-year, at least 3 or 4 digits always.
* made vm-auto-archive-messages be applicable to marked messages
  only.
* made MNMU == Mu, i.e. vm-unmark-message is applicable to marked messages.
* made vm-next-message and friends applicable to marked messages.
* incorporated typo and spelling fixes from Gregory Shapiro
* fixed vm-get-folder-type to widen before trying to get to the
  beginning of the buffer.
* updated README
* change mode line update code to not create strings at every
  update.
* changed update code to not rebuild the mode line regardless of
  whether it did or did not change.
* fixed bug in vm-write-string; point was not supposed to be
  restored on exit.
* fixed bug in vm-save-message; said write-region when I meant
  insert-buffer-substring.
* used new insert-file-contents features in v19 Emacses to
  replace running sed.
* called vm-su-from instead of vm-from-of in
  vm-rfc1153-or-rfc934-burst-message; vm-from-of can be return
  nil.
* fixed vm-leading-message-separator and
  vm-trailing-message-separator to use the
  right type variable.
* made nil an allowable value for vm-forwarding-digest-type.
* changed vm-stuff-attributes to use insert-before-markers which
  should keep the attributes headers from leaking into view.
  (window-start is a marker you see and ...)
* changed the RFC 934 digest banners messages, they were scaring
  the tourists.
* changed dashes to spaces in mode line.
* 'make' != 'make all' in Makefile anymore
* Info file created is now named vm.info.

## VM 5.38 released (16 December 1993)

* made vm function check vm-block-new-mail before calling
  vm-get-spooled-mail and thereby avoid having an error signaled
  after M-x recover-file.
* putting a call to vm-howl-if-eom into vm-show-current-message
  was a mistake.  moved to vm-scroll-forward, which is a better
  place for it.
* changed vm-delete-message to really honor vm-circular-folders
  if vm-move-after-deleting is nil.  Also fixed a similar problem
  in vm-undelete-message, plus a typo where delete was used when
  undelete should have been.
* fixed vm-so-sortable-subject, needed case-fold-search set to t.
* changed vm-pop-move-mail to clear the trace buffer before
  trying to open a connection.  This is to prevent confusion
  about old output in the trace buffer.
* fixed endless loop bug in vm-mail-yank-default that occur when
  vm-included-text-prefix is "".
* changed folder parser back to just matching "From " for the From_ type.
* New variables:
  + vm-summary-mode-hook
  + vm-summary-uninteresting-senders-arrow
  + vm-summary-mode-map
* Slightly different semantics for vm-summary-uninteresting-senders.

## VM 5.37 released (15 December 1993)

* fixed "wrong type argument" arrayp nil problem in
  vm-pipe-message-to-command. (m -> (car mlist))
* fixed "intersting" and "vm-message-type" typos in vm-summary.el
* added a clarification about byte-compiler warnings in the
  README file and corrected a typo in an autoload line; one of
  the vm's should be vm-mode.
* fixed vm-delete-window-configuration to actually read a window
  configuration.  Not sure when this was broken or whether it
  actually ever worked!
* fixed unescaped quotes in docstring for
  vm-summary-uninteresting-senders
* made vm-edit-message be a bit more careful about what it sets
  the edit buffers local value of vm-message-pointer to be.
* made the string returned by vm-safe-popdrop-string look a bit
  better.
* added support for mail-default-headers
* added defvars for mail-default-headers and mail-signature for
  v18 Emacs, to avoid referencing symbols with void values.
* fixed bug in vm-resend-message that caused the first to the
  current message to be copied into the composition buffer.
* fixed problem with vm-expunge-folder not updating the display
  after completing its work iff the current message was not
  expunged.
* made vm-show-current-message not mark a message as read unless
  the folder buffer had a window opened on it.
* added (vm-howl-if-eom) to vm-show-current-message now that it
  checks for a window.
* prevent effects of vm-summary-uninteresting-senders from
  leaking into non-summary areas.
* New variable:
  + vm-retrieved-spooled-mail-hook
* added vm-last-save-folder internal variable to track the last
  visited folder and offer it as a default for the next
  vm-visit-folder.

## VM 5.36 released (14 December 1993)

* no more marker sharing between message in real folders.
  Previously the start and end pointers were shared between
  consecutive messages.
* changed vm-clear-all-marks only update messages that actually
  have marks, and only update the summaries of updated messages.
* let* -> let in some places
* dropped one *+ regexp from vm-kill-subject
* vm-move-after-deleting non-nil and non-t means move as if
  vm-circular-folder is nil.
* virtual-folders work now
* vm-preview-lines == t means preview but display a windowful of text
* fixed mark-even-if-inactive type in vm-reply.el; replies under
  transient mark mode should work now under FSF v19.
* doc fixes and changes
* fixed bug in vm-scroll-backward, numeric prefix args other than
  simple strings of C-u's were causing inappropriate forward
  scrolling.
* removed strange no-op in vm-record-and-change-message-pointer
* default value of vm-preview-read-messages is now nil.
* call-process doesn't return a exit status in all Emacs, only
  check exit status of movemail run on those Emacses that return
  it.
* digest code redone, refurbished.
* RFC1153 digest support
* more status messages at startup so user knows Emacs is still
  alive while visiting a large folder.
* protected against letter bombs when vm-visit-when-saving is t.
* grouping code is gone
* New variables:
  + vm-forwarded-headers
  + vm-unforwarded-header-regexp
  + vm-forwarding-digest-type
  + vm-digest-burst-type
  + vm-digest-send-type
  + vm-rfc934-digest-headers
  + vm-rfc934-digest-discard-header-regexp
  + vm-rfc1153-digest-headers
  + vm-rfc1153-digest-discard-header-regexp
  + vm-auto-get-new-mail
  + vm-recognize-pop-maildrops
  + vm-jump-to-new-messages
  + vm-jump-to-unread-messages
  + vm-mail-mode-hook
  + vm-edit-message-hook
  + vm-resend-bounced-headers
  + vm-resend-bounced-discard-header-regexp
  + vm-resend-headers
  + vm-resend-discard-header-regexp
  + vm-init-file
  + vm-summary-uninteresting-senders
  + vm-summary-redo-hook
  + vm-reply-hook
  + vm-mail-hook
  + vm-resend-bounced-message-hook
  + vm-resend-message-hook
  + vm-send-digest-hook
  + vm-select-message-hook
  + vm-select-new-message-hook
  + vm-select-unread-message-hook
  + vm-arrived-message-hook
  + vm-visit-folder-hook
* Variables that have gone away:
  + vm-group-by
  + vm-rfc934-forwarding
  + vm-edit-message-mode-map
* timer based auto-retrieval of new mail implemented
* 'vm' function cleanup and should protect and warn about precious
  auto save files.
* dropped the vm-buffer-modified-p kludge
* new semantics for vm-spool-files
* M-x recover-file works properly in a VM folder buffer now.
* fixed defvar of vm-spool-files so that VM can be dumped with Emacs.
* vm-resend-bounced-message now has header trimming variables
* vm-resend-message now has header trimming variables and works
  like other outbound mail commands.
* regexps are now allowed in the HEADER-NAME field in
  vm-auto-folder-alist
* when reading the folder name, vm-save-message now uses the
  default folder name as initial input if it is a directory.
* VM now always stuffs attributes in vm-save-message; to do otherwise can
  cause the deleted' attribute to be saved sometimes.
* change vm-save functions to update the summary as they work so
  that if an error occurs the display will be up-to-date.
* ditched overlay-keymap
* ditched header highlighting code
* fixed vm-yank-message-other-folder to restore window environ
  before yanking the message.
* fixed vm-pipe-message-to-command to save read its command in
  the right context.
* made vm-save-message convert messages to the target folders
  format if necessary.
* POP support via vm-spool-files
* made how VM matches headers be consistent.  Put a colon at the
  end of header names if you want exact matches, leave it off if
  you just want prefixes.

## VM 5.35 released (25 August 1993)

* fixed vm-fsf-emacs-19-p to not confuse FSF Emacs with Lucid
* changed code to deal with screen.el's rename to tapestry.el
* set enable-local-variables to nil in vm-build-virtual-message-list
* began work on code in vm-virtual.el to get virtual folders to
  work right.  not finished yet.
* expanded and reorganized message structure for virtual folders
* added patch from jwz to use set-keymap parent in
  vm-edit-message under Lucid Emacs.

## VM 5.34 released (15 August 1993)

* used -l texinfmt explicitly in Makefile to get texinfo-format-buffer loaded
  under Emacs 19.18+.
* ditched use of vm-overlay-keymap in FSF 19 Emacs.
* use unread-command-events for FSF v19 in vm-next-command-uses-marks
* moved to using buffer-disable-undo rather than
  buffer-flush-undo; hooked them together for compatibility with
  v18.
* set folder type in more places and allowed empty folders to
  match all types.
* made vm-rename-current-mail-buffer look for Bcc header for
  possible addition to buffer name, before defaulting to the
  anonymous horse.
* fixed vm-edit-message-end bug; needed to widen so
  insert-buffer-substring inserts the whole edit-buf into the
  folder buffer.
* added a bunch of patches from Jamie Zawinski--- some for general
  VM bugs, some to let VM run under Lucid Emacs.
    - support for Lucid Emacs keymaps in vm-overlay-keymap
    - fixed some inadvertent free variable references
    - use % instead of mod to avoid getting clobbered by cl.el macros
    - check return status of movemail
    - support enable-local-variables for FSF19 and Lucid
    - use next-command-event if present for Lucid Emacs
    - bind zmacs-regions so that (mark) behaves like (mark t)
    - add support for mail-citation-hook for FSF19.
    - regexp fix in vm-compile-format that should fix a format
      bug as well at comply with whatever new POSIX regexp rot
      has come down the pike.
* more regexp fixes so that Emacs won't take an eternity to
  start VM
* vm.texinfo fixes
* fixed logic error in dealing with vm-visible-headers and
  vm-invisible-header-regexp.  If header was matched by both
  variables it would be displayed, which is wrong.

## VM 5.33 released (11 April 1993)

* fixed "wrong type argument arrayp, nil" error when primary
  inbox is empty.
* applied Frank Bresz's fix for vm-visit-folder expanding the
  minibuffer read filename in the wrong directory.
* applied Jamie Z's fix for the old, old scrolling problem when
  scrolling from the summary buffer.
* changed default value of vm-flush-interval to t.
* fixed Makefile to say *.el instead of . so compilation will
  occur even if there are no .elc files.

## VM 5.32 released (2 March 1992)

* changed `|' not to send the message separator strings to the command.
* fixed bug in vm-parse-addresses; no longer considers an empty
  string or a string composed only of whitespace to be an address.
* fixed bug in vm-compatible-folder-p; kill-buffer may make Emacs go
  to an random buffer.
* reorganized the sources, moved everything out of vm.el so vm.el
  can be used as a temp file.  VM compiles to one object file now.
* Prefix arg to `c' (vm-continue-composing-message) now allows
  selection of unmodified Mail mode buffers.
* Fixed the problem with the startup message appearing every time
  you invoked VM instead of just the first time.
* Fixed problem with first message displayed at startup not
  having its headers highlighted properly.
* axed the Full-Name header.
* New variable: vm-mail-header-from
* removed addresses from Cc that are already in To in replies.
* window configurations
  - commands
    vm-apply-window-configuration
    vm-save-window-configuration
    vm-delete-window-configuration
    vm-window-help
  - variables
    vm-window-configuration-file
* used $(EMACS) instead of emacs in the Makefile.
* fixed bug in vm-save-message, needed to restuff deleted messages
  to suppress the delete flag.
* New command: vm-mark-help
* moved the license into the texinfo document, and made the
  license display code use the Info subsystem.
* The Info document goes into the file `vm' now; the README and
  Makefile were changed to reflect this.
* vm-visit-folder depended on insert-default-directory being
  non-nil in order to find folders in the folder directory.  vm
  now temp bind default-directory to folder-directory to make
  sure that relative paths resolve in that directory.
* VM now handles the in-reply-to argument to vm-mail-internal (oops).
* Reply-To instead of Reply-to in outbound mail, a concession to
  broken mailers.
* Fixed vm-grok functions to give up only in the case of MMDF folders.
  A nil value of vm-folder-type could confuse it otherwise.  This
  is an interim fix.

## VM 5.31 released (31 March 1991)

* kill-buffer in vm-parse-address may cause a change to a random
  buffer; added save-excursion.
* moved vm-parse-addresses to vm.el, since it's used in the
  summary and in replies.
* fixed problem with retaining correct message order across
  multiple saves and expunges.
* no longer generate an empty In-Reply-To if mailer didn't
  provide message-ID.

## VM 5.30 released (26 March 1991)

* vm-resend-message now inserts a Resent-To header.
* changed default value of vm-visible-headers to show Resent-From
  and Resent-Date.
* fixed bug in vm-thoughtfully-select-message, return value was
  sometimes incorrect.
* fixed bug in vm-save-message, summary and message renumbering
  were being deferred too long in the destination folder when
  saving between visited folders.  fix similar deferral bug in
  vm-burst-digest.
* rfc822-addresses is no longer needed to support
  vm-reply-ignored-addresses.  This should keep addresses
  from being stripped of comments inappropriately.
* VM now reorders before grabbing the bookmark, as it should.
* vm-mail-internal now subsumes the function of mail-setup so as to
  avoid some of the choices made in mail-setup.
* removed the conditionals from around calls to vm-mail-internal
  since it cannot fail; vm-mail-internal no longer returns the
  token value of t.
* centralized the code that removes duplicates from lists of
  addresses, message-ids, etc, and fixed a bug in it.
* used duplicate removal code on address lists
* in replies, if To is empty and Cc isn't then To = Cc, Cc = nil
* used vm-parse-addresses in vm-su-do-recipients, which should do
  better than the simple address parser used there before.
* vm-mail-internal now automatically adds a Full-Name header.
* vm-flush-interval == t now means flush after every change
* vm-save-message now check whether the per message modflag is set
  before stuffing the message attributes.
* (setq file-precious-flag t) is no longer done by vm-mode-internal.
* vm-reply puts together an appropriate Newsgroups header.

## VM 5.29 released (18 March 1991)

* fixed References being inserted after mail-header-separator
* made a couple of VM find-file-hooks not assume that because
  they've been installed vm-message-list has been initialized.
* removed last of \\[...] usage; might as well be consistent
  since these things waste more time than they save.

## VM 5.28 released (16 March 1991)

* fixed buffer renaming error; check for name collisions
* vm-goto-message now tries to follow the summary cursor first;
  if it does, then it doesn't try to move again.
* fixed another bookmark problem; problem really inside
  vm-expunge-folder, some variables needed to be set even if
  quitting.
* removed the expand-file-name loop from vm-save-message, since
  it would loop endlessly if vm-folder-directory was a relative
  path name.
* fixed code in vm-save-message that assumed some VM specific
  local variables would have sane values in a non VM mode buffer.
* VM maintains the References header in replies.

## VM 5.27 released (14 March 1991)

* fixed bug in vm-stuff-message-order; needed (cdr vm-message-list)
  instead of (cdr vm-message-pointer).
* centralized code that VM executes once per Emacs session.
* eliminated the need for immediately loading other libraries
  during the load of the main VM Lisp file, which should fix a
  bug in the Makefile.
* cleaned up the vm function a bit, the code that tries to make
  make sure that the totals blurb in left at the bottom of the
  screen after startup is less grungy now.
* fuzzier grouping, spaces at end of the subject and after re:
  are ignored.
* killing a killed buffer breaks older versions Andy Norman's
  homebrewed kill-buffer function in gnuserv.el.  VM no longer
  stimulates the bug.
* fixed a couple of summary pointer update bugs in the VM
  isearch code.
* better bindings for the mark commands.
* vm-forward-message just calls vm-send-digest when user tries to
  use it with marks, instead of just chiding the user.
* VM feeps even less on motion errors to avoid disturbing
  sensitive souls and sleeping spouses.
* various documentation corrections
* fixed bug bookmark bug; bookmark was being stuffed too soon,
  i.e. before messages were renumbered properly
* when mail is sent the outbound mail buffer is renamed to "sent
  ..." to indicate that the mail has been sent.
* New command: vm-resend-message
* New command: vm-continue-composing-message
* `|' uses marks now

## VM 5.26 released (6 March 1991)

* vm-move-message-forward now sets the proper variables to get
  the message order saved.
* fixed bug in vm-stuff-message-order; message numbers needed to
  be redone sometimes before saving.
* fixed bug in vm-revert-to-physical-order, it was not recording
  the message order change properly either.
* prefix arguments to vm and vm-visit-folder now cause VM to
  visit the folder read-only.
* altered conditional in vm that decides whether to get new mail;
* indiscriminately scrubbing slashes from reply buffer auto save
  file names proved to be a humorous mistake.  I've decided that
  post-modification of the auto save file name is a bad thing, so
  VM doesn't do any of the scrubbing anymore.  I leave it up to
  make-auto-save-file-name to do the right thing, since it's its
  job anyway.
* documentation fixes in vm-reply.el
* 'g' now switches to the primary inbox if you weren't there
  already and there is new mail.

## VM 5.25 released (3 March 1991)

* got rid of vm-local-message-list and vm-local-message-pointer

## VM 5.24 released (2 March 1991)

* New variable: vm-retain-message-order
* New command: vm-move-message-forward
* New command: vm-move-message-backward
* VM finally gets doubly links message lists.  vm-previous-message
  should be much faster on large folders now.
* removed some unnecessary code at the end of the routine that
  reverts the message-list back to physical-ordering.
* added missing function vm-delete-directories to vm-virtual.el
* added `/' to the list of characters that get scrubbed out of
  the auto-save-file-name's of reply buffers.
* added > description to the doc string of vm-mode.
* move-after-deleting and move-after-undeleting now signal error
  only if non-interactive and not executing a keyboard macro.
* New variable: vm-edit-message-mode-map
* C-c C-c now works like C-c ESC when editing a message.
* substitute-command-keys now used in vm-edit-message since it
  should be relatively cheap.
* doc string correction in vm-delete-message.

## VM 5.23 released

* fixed display bug with virtual folders; virtual folder would
  switch real buffers when changing messages but the display
  wouldn't display the buffer containing the new current message.
* changed the vm-group-by algorithm; now uses buckets, should be
  much faster.
* append a newline if necessary after inserting an edit buffer into the
  folder, to keep the message separator from becoming a part of
  the message.
* Made the "No new mail" message go away after a while.
* fixed bug where VM assumed buffer-file-name would always be
  non-nil.
* fixed bug in vm-gobble-deleted-messages that caused
  VM via vm-expunge-folder to bomb on empty folders.
* fixed another bug in vm-gobble-deleted-messages that caused
  it to mark a folder modified if an expunge was attempted on an
  empty folder.
* further centralized summary updates and renumbering activities
* couldn't remember why require-final-newline was set to nil in
  vm-mode and vm-virtual-mode buffers so I got rid of it.
* "No new messages" -> "No messages gathered" in vm-get-new-mail.
* made `g' go ahead and get new mail even if the current folder
  isn't the primary inbox.

## VM 5.22 released (beta-testable in Feb 22, 1991)

* fixed obscure bug in vm-write-file-hook that might have bitten
  someone some day; vm-message-list vs. vm-local-message-list.
* updated startup message and README to say where to send bug reports.
* added support for timer based checkpointing.
* New variable: vm-flush-interval
* VM now gets along with revert-buffer and recover-file.
* VM undo will now delete the auto-save-file when appropriate.
* Folder saves with C-x C-s and C-x C-w don't get the -??-
  uncertainty indicators anymore.  C-x s still does though, alas.
* vm-set-buffer-modified-p changed to make the setting of the
  buffer's modification flag be tried first, so that file locking
  and file supersession threat aborts are handled cleanly.
* added code (that really works) to clear the question from the
  minibuffer after vm-quit gets its answer.
* tiny cleanup in mail buffer name used by vm-send-digest

## VM 5.21 released

* the auto-save file name scrubber was broken.  I also discovered
  that Emacs` aset function is broken.
* vm-keep-sent-messages didn't quite work right; used rassq instead
  of memq...

## VM 5.20 released

* fixed doc string for vm-scroll-forward and vm-scroll-backward
* removed whitespace from auto-save-file-names in VM Mail Mode
  buffers.  trimmed shell metacharacters as well.
* fixed doc error for vm-resend-bounced-message (bound to M-r not C-r)
* the default value of vm-confirm-quit is now 0.
* corrected documentation on vm-confirm-quit.
* variable initialization now in vm-vars.el
* VM scroll commands, page narrowing functions and other
  functions that schlep about in the current message moved to
  vm-page.el.
* New variable: vm-keep-sent-messages
* VM now reports the "right" number of new and unread messages at
  startup, even if previewing is disabled.
* added code to clear the question from the minibuffer after
  vm-quit gets its answer.

## VM 5.19 released

* fixed bug in vm-gobble-deleted-messages that causes the summary
  to be botched if the first message was expunged and the second
  message wasn't.
* call to vm-set-buffer-modified-p made clearer.
* fixed bug in vm-expunge-folder and vm-update-summary-and-mode-line
  that caused a botched summary if all the messages
  in a folder were expunged.
* moved the vm-version variable initialization into
  another separate file.
* vm-save-folder is now more verbose when it does it's work.
* vm-beginning-of-message and vm-end-of-message now push point
  onto the mark ring just like their beginning-of-buffer/end-of-buffer
  counterparts.
* removed incorrect vm-system-state change in vm-beginning-of-message
* vm-save-folder now handles prefix args like save-buffer does.
* vm-mail now works if called before the rest of VM is loaded.

## VM 5.18 released

* VM now ignores garbage (e.g. blank lines) at the beginning of a folder.
* C-x C-s and C-x C-w will now save the folder if invoked from
  the summary buffer.

## VM 5.17 released

* fixed bug in vm-build-=virtual-message-list that kept other
  virtual folder selectors from working.]
* fixed bug in vm-get-new-mail when gathering messages from
  another folder instead of the spool.
* added autoload for vm-visit-virtual-folder to vm.el
* fixed bug in parsing of MAILPATH environmental variable.
* fixed bug in vm-expose-hidden-headers; if message is unread
  body is not inadvertently displayed.

## VM 5.16 released

* message structs are no longer directly self-referential.  A
  symbol must now be dereferenced.  This was done to allow the
  debugger to be used on VM.
* vm-get-spooled-mail no longer assumes that there's always mail
  in an existing spool file.

## VM 5.15 released to the beta-testers

* slight cleanup in vm-assimilate-new-messages
* added some calls to vm-select-folder-buffer to some commands
  that needed it.  Basically this means commands that call
  another command to do most of their work but do not call this
  second command interactively, which result in
  vm-set-folder-variables not always being called when it's
  needed.

## VM 5.14 released

* New variable: `vm-delete-after-archiving'
* New variable: `vm-delete-after-bursting'
* VM now avoids the use of the default *mail* buffer.  Outgoing
  mail buffers are given more descriptive names, and more than
  one can exist concurrently.

## VM 5.13 released

* vm-kill-subject bug fixed; report of number of killed message
  was broken.
* changed vm-message-list to vm-local-message-list in vm-do-summary

## VM 5.12 released

* last couple of changes to the grouping code didn't make it into the
  previous patch.

## VM 5.11 released

* added a check for a killed summary buffer to vm-group-message.
* references to vm-local- variables still weren't right; there
  are now no references at all to their global counterparts.

## VM 5.10 released

* grouping code wasn't setting vm-local- vars... this didn't
  generate an error when I tested it with a virtual folder, but
  better safe than...
* summary code now tries not to do a total rebuild after getting
  new mail or expunging.  This should give a considerable time
  savings on large folders.
* another type of bounced message delimiter added to the searches
  in vm-resend-bounced-message.

## VM 5.09 released 

* New variable: `vm-folder-read-only'
* removed all the "clever" code at the end of vm-quit that tried
  to do nice thing if we landed on a VM buffer.
* vm-kill-subject now reports the number of messages that have
  been deleted.
* fixed bug in implementation of vm-reply-subject-prefix; test
  condition was reversed, and the string-match for the prefix was
  not anchored at the beginning of the header contents as it
  should have been.
* fixed problem where expunging immediately after C-x C-s would not show
  folder as being modified, even if some messages were expunged.
* virtual folders
  - New variables:
    + vm-virtual-folder-alist
    + vm-virtual-mirror
  - New commands:
    + vm-visit-virtual-folder
* vm-proportion-windows now handles vertical windows appropriately.
* vm-expose-hidden-headers now automatically jumps to top of message.
* VM no longer stuffs headers into expunged messages before saving the
  folder (oops).
* fixed bug in handling of negative prefix arguments (broken everywhere).
* fixed bug in the message save functions, last-command was being
  clobbered on interactive calls, which made the commands inapplicable
  to marked messages.
* fixed bug in vm-delete-message-backward; vm-follow-summary-cursor was
  not being called.
* vm-resend-bounced-message moved from C-r to M-r.
* support for Grapevine added to vm-resend-bounced-message.

## VM 5.08 released

* commands that send mail now inherit the default-directory of the
  folder buffer.
* 86ed last paragraph of vm-burst-digest docstring left by an
  overzealous documentation Muse.
* better error handling when getting months and month numbers.
  bogus Date: header shouldn't make VM explode now.
* the code that supported vm-reply-ignored-addresses had a typo:
  "to" where "cc" should have been--- fixed.
* fixed problem with *mail* buffer not being displayed after C-r
  (vm-resend-bounced-message).  I believe this is in fact a bug in
  save-excursion.
* New variable: vm-auto-folder-case-fold-search
* Updated regexp that groks RFC 822 dates to reflect new policy as of
  RFC 1123, i.e. four digit year numbers.
* vm-mail need not be invoked from within VM now.

## VM 5.07 released

* purged the overlay-arrow filth, enough is enough.
* changed incorrect reference to m to (car mp) in vm-write-file-hook.
* removed incorrect call to backup-buffer in vm-gobble-crash-box
* fixed full name parsing botch that left trailing quote on doublequoted names.
* more virtual folders code added

## VM 5.06 released

* vm-save-restriction modified to hide its uninterned vars in a (let ...)
  because the byte-compiler interns them. :-(
* fixed problem with vm-resend-bounced-message; mail-header-separator
  was not being inserted into the message.
* fixed another problem with vm-resend-bounced-message; code needed to
  be inside the save-restriction call instead of outside it.
* some early virtual folder stubs added.

## VM 5.05 released

* Changed vm-thoughtfully-select-message to rely on vm-system-state to
  determine whether to jump to a new message or not.  Made mods to other
  VM function to insure the vm-system-state always has the right value.
* New variable: vm-digest-preamble-format
* New variable: vm-digest-center-preamble
* cleanups in the header stuffing routines
* added a modify flag to each message struct; should save time when
  saving by restuffing only those messages that need it.

## VM 5.04 released

* fixed problem with the summary arrow drifting out of view in the summary
  window.
* fixed problem with visible/invisible variables startup consistency
  checking.
* disabled file locking in places where it is inappropriate; this should
  make startup a bit faster.
* made vm-show-current-message do something sensible if a page-delimiter
  is at the beginning of the text portion of the message, and
  vm-honor-page-delimiters is non-nil.
* made vm-honor-page-delimiters override the value of vm-preview-lines
  if honoring vm-preview-lines would require displaying past a page
  boundary.
* fixed problem where VM wasn't detecting end of message when honoring
  page delimiters.
* fixed problem with editing and already edited message not setting the
  buffer modification flag; also fixed similar problem with unsetting the
  edited flag.
* added a page break indicator via overlay-arrow.  The overlay-arrow
  vars are buffer local, so there shouldn't be any squabbles over their
  use.

## VM 5.03 released

* fixed problem with point and the summary arrow not coinciding at startup.
* MAILPATH again; bash doesn't use `%' as sh does, it uses `?'.
* Changed Makefile.  `make' alone no longer rebuilds the texinfo stuff;
  `make all' does that now.
* Fixed Makefile; vm.info wasn't being saved after formatting (oops).

## VM 5.02 released

* Changed defconst to defvar in the definition of vm-summary-format;
  this is a leftover from debugging.
* Makefile wasn't loading ./vm.elc before forcing compilation of all
  modules.  Depending on the circumstances an old vm.elc could be loaded
  with predictably bad results.
* Added -q to Emacs invocations in Makefile to avoid grot in .emacs files.
* New command: vm-delete-message-backward (C-d), a concession to
  RMAILoids.  Maybe now they'll get off my BACK about this. :-)
* doc corrections and additions
* modified vm-su-do-author to handle double quoted full names better.

## VM 5.01 released

* fixed MAILPATH parsing; forgot about "%message" stuff that could be
  tacked onto the end of the filenames.
* added check to the mail gathering routines to make sure the folder types
  of the source and destination folders are compatible.
* fixed bug involving vm-totals in vm-assimilate-new-messages.
* doc corrections

## VM 5.00 released for alpha testing (sometime in 1990)

* `t' now toggles exposing/hiding normally invisible headers.
* VM now writes much more cached info into its data header resulting in
  much faster startup.
* New variable `vm-invisible-header-regexp'.
* Cached a regular expression that shows how to find the beginning of the
  reordered headers (assuming the user permits such cached data to be
  used, then VM won't reorder message headers every time a folder is
  visited.
* Status and X-VM-... headers are now updated in place instead of always
  putting them at the top of the message.
* vm-delete-header unused, went away.
* Doesn't feep on "No next unread message."
* `written' and `forwarded' attributes added.
* macroized (if vm-mail-buffer (set-buffer vm-mail-buffer)) into
  (vm-select-folder-buffer)
* modularized the header highlighting and folder buffer display functions.
* fixed < and > to behave properly when invoked from the summary buffer.
* vm-last-save-folder now gets the fully expanded version of the folder name.
* vm-visit-folder now defaults to vm-last-save-folder if it is non-nil,
  and the user hits RET at the interactive prompt.
* old vm-mode now vm-mode-internal; new vm-mode now interactively callable.
* vm-get-new-mail now takes a prefix argument to mean gather mail from a
  user specified folder instead of from the usual spool files.
* vm-auto-archive-messages now ask user confirmation before saving each
  message if given a prefix arg.
* Fixed botched interpretation of Berkeley Status headers.
* VM now loads ~/.vm the first time it is executed in an Emacs session.
* New variable `vm-move-after-undeleting'.
* Added a trailing slash to the if-all-else-fails setting of
  vm-spool-directory.
* Fixed problem where the totals blurb would not be redisplayed after
  the copyright info if vm-startup-with-summary is t.
* `vm' now only does (switch-to-buffer mail-buffer) if it was not
  invoked via vm-mode.
* vm-howl-if-eom-visible has forsaken pos-visible-in-window-p in favor
  of just doing a scroll-up and howling if an error occurs.  This
  obviates the need for vm-show-current-message to do a sit-for before
  calling vm-howl-...
* Implemented the standard VM included text code as a call to
  vm-yank-message and a default yank function.  This default yank
  function is not called if the user already has a mail-yank-hook in place.
* If the FOLDER-NAME part of auto-folder-alist evaluates to a list,
  then it is considered to be another auto-folder-alist and is scanned
  like vm-auto-folder-alist.
* New variable `vm-auto-next-message'.
* New variable `vm-auto-center-summary'.
* VM can now survive the death of its summary buffer.
* VM no longer uses overlay-arrow; the summary arrow is now written into
  the summary buffer directly.
* %t and %T now supported to show recipient addresses and full names in
  the summary.
* vm-gargle-uucp extended to cover %t addresses.
* New variable `vm-honor-page-delimiters'.
* New variable `vm-reply-subject-prefix'.
* vm-quit now squawks if invoked from a non-VM buffer.  It used to just
  kill whatever buffer it was invoked from.
* vm-folder-type now automated; is no longer a user variable.
* message marks
* the end of message notification has been removed.
* group by recipient
* New variable: vm-reply-ignored-addresses
* `U' now marks messages unread.
* skip variables value = t now means skip inappropriate messages
  dogmatically, no exceptions.  Non-nil and non-t value now gives old
  behavior.
* attributes are now stuffed before saving a message to a folder.
* bookmarks
* vm-yank-message-other-folder
* support for MAIL and MAILPATH environmental variables
* after getting new mail jump to the first unread message only if the
  last command executed was not a message scan command, e.g.
  vm-scroll-forward, vm-isearch-forward.
* summary mode-line-format format now mirrors that of the folder buffer
* vm-buffer-modified-p returns, folder buffer is now read-only.
* 'L' now loads ~/.vm
* vm-mode is quieter and less obtrusive now, vm now works with crypt.el
  and with vm-mode present in auto-mode-alist.
* you can now save a message in a folder to that same folder, in effect
  duplicating it.
* `M' format spec now gives numeric month.
* message editing
* `j' discards cache data
* C-r (vm-resend-bounced-message).
* New variable: vm-confirm-quit
* New behavior for vm-visit-when-saving if it is non-nil and non-t.
* `A' no longer archives messages marked for deletion.
* prefix arg to vm-burst-digest now makes it copes with non-standard
  digests, at least to a certain extent.
* New format spec %A gives longer attribute summary; less column overloading.
? vm-read-mh-folder

gnu.emacs.vm.info  started Feb 1, 1991

  http://groups.google.com/group/gnu.emacs.vm.info/browse_frm/month/1991-02

## VM 4.11 released May 30, 1989  (posted on comp.emacs)

* VM has learned how to deal with MMDF folders

## VM 4.10 released May 23, 1989  (posted on comp.emacs)

 The first public release of VM
 http://groups.google.com/group/comp.emacs/browse_frm/month/1989-05 

## Kyle Jones's note (written on Apr 27, 1997)

The earliest record I have of anything VM related is April 1989. 
Sometime in the spring of 1989, I wrote the first version of VM 
and gave it to a few friends.  The first net release was 4.10, 
sometime in June of that same year.  All releases up to that 
point were to a small group of people, mostly college friends who 
I knew used Emacs.
 
VM was originally written to run under GNU Emacs 18.52.  I didn't 
seem to get seriously interested in supporting v19 GNU Emacs until 
the summer of 1993.

5.00 was a private alpha release, sometime in 1990 I think. 

I know that Jamie [Zawinski] was shipping VM with XEmacs as early as
v19.9.  But beyond that I have no idea. 
