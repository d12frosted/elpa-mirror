;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.0snapshot0.20261005.235" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "1bc8b945720369f596878d99bcd33155b7c99486" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
