;;; vm-mark.el ---  Commands for handling messages marks  -*- lexical-binding: t; -*-
;;
;; This file is part of VM
;;
;; Copyright (C) 1990, 1993, 1994 Kyle E. Jones
;; Copyright (C) 2003-2006 Robert Widhopf-Fenk
;; Copyright (C) 2024-2026 The VM Developers
;;
;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 2 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License along
;; with this program; if not, write to the Free Software Foundation, Inc.,
;; 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

;;; Code:

(require 'vm-macro)
(require 'vm-misc)
(require 'vm-folder)
(require 'vm-motion)
(require 'vm-thread)
(require 'vm-summary)
(require 'vm-sort)
(require 'vm-virtual)
(require 'vm-window)

;; Say so if this file's compiled form outlives the VM it was built
;; against; see `vm-assert-version' (#791).
(vm-assert-version)

;;;###autoload
(defun vm-clear-all-marks ()
  "Removes all message marks in the current folder."
  (interactive)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-inform 5 "Clearing all marks...")
  (let ((mp vm-message-list))
    (while mp
      (if (vm-mark-of (car mp))
	  (progn
	    (vm-set-mark-of (car mp) nil)
	    (vm-mark-for-summary-update (car mp) t)))
      (setq mp (cdr mp))))
  (vm-display nil nil '(vm-clear-all-marks)
	      '(vm-clear-all-marks marking-message))
  (vm-update-summary-and-mode-line)
  (vm-inform 5 "Clearing all marks... done"))

;;;###autoload
(defun vm-toggle-all-marks ()
  "Toggles all message marks in the current folder.
Messages that are unmarked will become marked and messages that are
marked will become unmarked."
  (interactive)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-inform 5 "Toggling all marks...")
  (let ((mp vm-message-list))
    (while mp
      (vm-set-mark-of (car mp) (not (vm-mark-of (car mp))))
      (vm-mark-for-summary-update (car mp) t)
      (setq mp (cdr mp))))
  (vm-display nil nil '(vm-toggle-all-marks)
	      '(vm-toggle-all-marks marking-message))
  (vm-update-summary-and-mode-line)
  (vm-inform 5 "Toggling all marks... done"))

;;;###autoload
(defun vm-mark-all-messages ()
  "Mark all messages in the current folder."
  (interactive)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-inform 5 "Marking all messages...")
  (let ((mp vm-message-list))
    (while mp
      (vm-set-mark-of (car mp) t)
      (vm-mark-for-summary-update (car mp) t)
      (setq mp (cdr mp))))
  (vm-display nil nil '(vm-mark-all-messages)
	      '(vm-mark-all-messages marking-message))
  (vm-update-summary-and-mode-line)
  (vm-inform 5 "Marking all messages... done"))

;;;###autoload
(defun vm-mark-message (count)
  "Mark the current message.
Numeric prefix argument N means mark the current message and the next
N-1 messages.  A negative N means mark the current message and the
previous N-1 messages."
  (interactive "p")
  (if (vm-interactive-p)
      (vm-follow-summary-cursor))
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((direction (if (< count 0) 'backward 'forward))
	(count (vm-abs count))
	(vm-message-pointer vm-message-pointer))
    (while (not (zerop count))
      (if (not (vm-mark-of (car vm-message-pointer)))
	  (progn
	    (vm-set-mark-of (car vm-message-pointer) t)
	    (vm-mark-for-summary-update (car vm-message-pointer) t)))
      (vm-decrement count)
      (if (not (zerop count))
	  (vm-move-message-pointer direction))))
  (vm-display nil nil '(vm-mark-message)
	      '(vm-mark-message marking-message))
  (vm-update-summary-and-mode-line))

;;;###autoload
(defun vm-unmark-message (count)
  "Remove the mark from the current message.
Numeric prefix argument N means unmark the current message and the next
N-1 messages.  A negative N means unmark the current message and the
previous N-1 messages."
  (interactive "p")
  (if (vm-interactive-p)
      (vm-follow-summary-cursor))
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((mlist (vm-select-operable-messages
		count (vm-interactive-p) "Unmark")))
    (while mlist
      (if (vm-mark-of (car mlist))
	  (progn
	    (vm-set-mark-of (car mlist) nil)
	    (vm-mark-for-summary-update (car mlist) t)))
      (setq mlist (cdr mlist))))
  (vm-display nil nil '(vm-unmark-message)
	      '(vm-unmark-message marking-message))
  (vm-update-summary-and-mode-line))

;;;###autoload
(defun vm-mark-summary-region ()
  "Mark all messages with summary lines contained in the region."
  (interactive)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (if (null vm-summary-buffer)
      (error "No summary."))
  (set-buffer vm-summary-buffer)
  (if (not (mark))
      (error "The region is not active now"))
  (vm-mark-or-unmark-summary-region t)
  (vm-display nil nil '(vm-mark-summary-region)
	      '(vm-mark-summary-region marking-message))
  (vm-update-summary-and-mode-line))

;;;###autoload
(defun vm-unmark-summary-region ()
  "Remove marks from messages with summary lines contained in the region."
  (interactive)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (if (null vm-summary-buffer)
      (error "No summary."))
  (set-buffer vm-summary-buffer)
  (if (not (mark))
      (error "The region is not active now"))
  (vm-mark-or-unmark-summary-region nil)
  (vm-display nil nil '(vm-unmark-summary-region)
	      '(vm-unmark-summary-region marking-message))
  (vm-update-summary-and-mode-line))

(defun vm-mark-or-unmark-summary-region (markit)
  ;; The folder buffers copy of vm-message-list has already been
  ;; propagated to the summary buffer.
  (let ((mp vm-message-list)
	(beg (point))
	(end (mark))
	tmp m)
    (if (> beg end)
	(setq tmp beg 
	      beg end 
	      end tmp))
    (while mp
      (setq m (car mp))
      (if (not (eq (not markit) (not (vm-mark-of m))))
	  (if (or (and (>  (vm-su-end-of m) beg)
		       (<  (vm-su-end-of m) end))
		  (and (>= (vm-su-start-of m) beg)
		       (<  (vm-su-start-of m) end))
		  (and (>= beg (vm-su-start-of m))
		       (<  beg (vm-su-end-of m))))
	      (progn
		(vm-set-mark-of m markit)
		(vm-mark-for-summary-update m t))))
      (setq mp (cdr mp)))))

(defun vm-mark-or-unmark-messages-by-selector (val selector arg)
  (let ((mlist vm-message-list)
	(virtual (eq major-mode 'vm-virtual-mode))
	(arglist (if arg (list arg) nil))
	(count 0))
    (setq selector (intern (concat "vm-vs-" (symbol-name selector))))
    (while mlist
      (if (if virtual
	      (with-current-buffer
		  (vm-buffer-of
		   (vm-real-message-of
		    (car mlist)))
		(apply selector (vm-real-message-of (car mlist)) arglist))
	    (apply selector (car mlist) arglist))
	  (progn
	    (vm-set-mark-of (car mlist) val)
	    (vm-mark-for-summary-update (car mlist) t)
	    (vm-increment count)))
      (setq mlist (cdr mlist)))
    (vm-display nil nil
		'(vm-mark-messages-by-selector vm-unmark-messages-by-selector)
		(list this-command 'marking-message))
    (vm-update-summary-and-mode-line)
    (vm-inform 5 "%s message%s %smarked"
	     (if (> count 0) count "No")
	     (if (= 1 count) "" "s")
	     (if val "" "un"))))

;;;###autoload
(defun vm-mark-messages-by-selector (selector &optional arg)
  "Mark messages matching a virtual selector.
You can use any of the virtual folder selectors, except for the
`and', `or' and `not' selectors.  See the documentation for the
variable `vm-virtual-folder-alist' for more information."
  (interactive
   (let ((last-command last-command)
	 (this-command this-command))
     (save-current-buffer
       (vm-select-folder-buffer)
       (vm-read-virtual-selector "Mark messages: "))))
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-messages-by-selector t selector arg))
;;;###autoload (autoload 'vm-mark-matching-messages "vm-mark" nil t)
(defalias 'vm-mark-matching-messages 'vm-mark-messages-by-selector)

;;;###autoload
(defun vm-unmark-messages-by-selector (selector &optional arg)
  "Unmark messages matching a virtual selector.
You can use any of the virtual folder selectors, except for the
`and', `or' and `not' selectors.  See the documentation for the
variable `vm-virtual-folder-alist' for more information."
  (interactive
   (let ((last-command last-command)
	 (this-command this-command))
     (save-current-buffer
       (vm-select-folder-buffer)
       (vm-read-virtual-selector "Unmark messages: "))))
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-messages-by-selector nil selector arg))
;;;###autoload (autoload 'vm-unmark-matching-messages "vm-mark" nil t)
(defalias 'vm-unmark-matching-messages 'vm-unmark-messages-by-selector)

;;;###autoload
(defun vm-mark-thread-subtree ()
  "Mark all messages in the thread tree rooted at the current message."
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-thread-subtree t))

;;;###autoload
(defun vm-unmark-thread-subtree ()
  "Unmark all messages in the thread tree rooted at the current message."
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-thread-subtree nil))

(defun vm-mark-or-unmark-thread-subtree (mark)
  (vm-build-threads-if-unbuilt)
  (let ((list (vm-thread-subtree 
	       (vm-thread-symbol (car vm-message-pointer)))))
    (while list
      (unless (eq (vm-mark-of (car list)) mark)
	(vm-set-mark-of (car list) mark)
	(vm-mark-for-summary-update (car list)))
      (setq list (cdr list))))
  (vm-display nil nil
	      '(vm-mark-thread-subtree vm-unmark-thread-subtree)
	      (list this-command 'marking-message))
  (vm-update-summary-and-mode-line))

;;;###autoload
(defun vm-mark-messages-same-subject ()
  "Mark all messages with the same subject as the current message."
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-messages-same-subject t))

;;;###autoload
(defun vm-unmark-messages-same-subject ()
  "Unmark all messages with the same subject as the current message."
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-messages-same-subject nil))

(defun vm-mark-or-unmark-messages-same-subject (mark)
  (let ((mp vm-message-list)
	(mark-count 0)
	(subject (vm-so-sortable-subject (car vm-message-pointer))))
    (while mp
      (if (and (not (eq (vm-mark-of (car mp)) mark))
	       (string-equal subject (vm-so-sortable-subject (car mp))))
	  (progn
	    (vm-set-mark-of (car mp) mark)
	    (vm-increment mark-count)
	    (vm-mark-for-summary-update (car mp) t)))
      (setq mp (cdr mp)))
    (vm-display nil nil
		'(vm-mark-messages-same-subject
		  vm-unmark-messages-same-subject)
		(list this-command 'marking-message))
    (vm-update-summary-and-mode-line)
    (if (zerop mark-count)
	(vm-inform 5 "No messages %smarked" (if mark "" "un"))
      (vm-inform 5 "%d message%s %smarked"
	       mark-count
	       (if (= 1 mark-count) "" "s")
	       (if mark "" "un")))))

;;;###autoload
(defun vm-mark-messages-same-author ()
  "Mark all messages with the same author as the current message."
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-messages-same-author t))

;;;###autoload
(defun vm-unmark-messages-same-author ()
  "Unmark all messages with the same author as the current message."
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-messages-same-author nil))

(defun vm-mark-or-unmark-messages-same-author (mark)
  (let ((mp vm-message-list)
	(mark-count 0)
	(author (vm-su-from (car vm-message-pointer))))
    (while mp
      (if (and (not (eq (vm-mark-of (car mp)) mark))
	       (vm-string-equal-ignore-case author (vm-su-from (car mp))))
	  (progn
	    (vm-set-mark-of (car mp) mark)
	    (vm-increment mark-count)
	    (vm-mark-for-summary-update (car mp) t)))
      (setq mp (cdr mp)))
    (vm-display nil nil
		'(vm-mark-messages-same-author
		  vm-unmark-messages-same-author)
		(list this-command 'marking-message))
    (vm-update-summary-and-mode-line)
    (if (zerop mark-count)
	(vm-inform 5 "No messages %smarked" (if mark "" "un"))
      (vm-inform 5 "%d message%s %smarked"
	       mark-count
	       (if (= 1 mark-count) "" "s")
	       (if mark "" "un")))))

(defun vm-mark-or-unmark-messages-with-virtual-folder (val name)
  (let* ((vfolder (assoc name vm-virtual-folder-alist))
	 vm-virtual-folder-definition m mlist clauses
	 (count 0))
    (or vfolder (error "No such virtual folder, %s" name))
    (setq vfolder (vm-copy vfolder))
    (setq clauses (cdr vfolder))
    (while clauses
      (setcar (car clauses) (list (list 'get-buffer (buffer-name))))
      (setq clauses (cdr clauses)))
    (setq vm-virtual-folder-definition vfolder)
    (setq mlist (vm-build-virtual-message-list vm-message-list t))
    (if (null vm-real-buffers)
	(while mlist
	  (setq m (vm-real-message-of (car mlist)))
	  (vm-set-mark-of m val)
	  (vm-mark-for-summary-update m t)
	  (vm-increment count)
	  (setq mlist (cdr mlist)))
      (let ((curbuf (current-buffer)) vmlist)
	(while mlist
	  (setq m (vm-real-message-of (car mlist))
		vmlist (vm-virtual-messages-of m))
	  (while vmlist
	    (cond ((eq curbuf (vm-buffer-of (car vmlist)))
		   (vm-set-mark-of (car vmlist) val)
		   (vm-mark-for-summary-update (car vmlist) t)
		   (vm-increment count)
		   (setq vmlist nil))
		  (t (setq vmlist (cdr vmlist)))))
	  (setq mlist (cdr mlist)))))
    (vm-display nil nil
		'(vm-mark-messages-by-virtual-folder
		  vm-unmark-messages-by-virtual-folder)
		(list this-command 'marking-message))
    (vm-update-summary-and-mode-line)
    (vm-inform 5 "%s message%s %smarked"
	     (if (> count 0) count "No")
	     (if (= 1 count) "" "s")
	     (if val "" "un"))))

;;;###autoload
(defun vm-mark-messages-by-virtual-folder (name)
  "Mark messages that are matched by the selectors of virtual folder NAME."
  (interactive
   (let ((last-command last-command)
	 (this-command this-command))
     (list
      (completing-read
       ;; prompt
       "Mark messages matching this virtual folder's selectors: "
       ;; collection, predicate, require-match
       vm-virtual-folder-alist nil t))))
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-messages-with-virtual-folder t name))
;;;###autoload (autoload 'vm-mark-matching-messages-with-virtual-folder "vm-mark" nil t)
(defalias 'vm-mark-matching-messages-with-virtual-folder 
  'vm-mark-messages-by-virtual-folder)

;;;###autoload
(defun vm-unmark-messages-by-virtual-folder (name)
  "Unmark messages that are matched by the selectors of virtual folder NAME."
  (interactive
   (let ((last-command last-command)
	 (this-command this-command))
     (list
      (completing-read
       ;; prompt
       "Unmark message matching this virtual folder's selectors: "
       ;; collection, predicate, require-match
       vm-virtual-folder-alist nil t))))
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (vm-mark-or-unmark-messages-with-virtual-folder nil name))
;;;###autoload (autoload 'vm-unmark-matching-messages-with-virtual-folder "vm-mark" nil t)
(defalias 'vm-unmark-matching-messages-with-virtual-folder
  'vm-unmark-messages-by-virtual-folder)

;;;###autoload
(defun vm-next-command-uses-marks ()
  "Does nothing except insure that the next VM command will operate only
on the marked messages in the current folder.  This only works for
commands bound to key, menu or button press events.  M-x vm-command will
not work."
  (interactive)
  (setq this-command 'vm-next-command-uses-marks)
  (vm-inform 5 "Next command uses marks...")
  (vm-display nil nil '(vm-next-command-uses-marks)
	      '(vm-next-command-uses-marks)))

;;;###autoload
(defun vm-marked-messages ()
  (let (list (mp vm-message-list))
    (while mp
      (if (vm-mark-of (car mp))
	  (setq list (cons (car mp) list)))
      (setq mp (cdr mp)))
    (nreverse list)))

;;;###autoload
(defun vm-mark-help ()
  "Show the mark commands and their keys in the echo area."
  (interactive)
  (vm-display nil nil '(vm-mark-help) '(vm-mark-help))
  (vm-inform 
   0 
   "MM = mark, MU = unmark, Mm = mark all, Mu = unmark all, MN = use marks, ..."))

(provide 'vm-mark)
;;; vm-mark.el ends here
