;;; vm-minibuf.el --- Minibuffer read functions for VM  -*- lexical-binding: t; -*-
;;
;; This file is part of VM
;;
;; Copyright (C) 1993, 1994 Kyle E. Jones
;; Copyright (C) 2003-2006 Robert Widhopf-Fenk
;; Copyright (C) 2024-2026 The VM Developers
;;
;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 2 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License along
;; with this program; if not, write to the Free Software Foundation, Inc.,
;; 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

;;; Code:

(require 'vm-macro)
(require 'vm-mouse)

;; Say so if this file's compiled form outlives the VM it was built
;; against; see `vm-assert-version' (#791).
(vm-assert-version)

(declare-function vm-folder-buffers "vm" (&optional non-virtual))

(defun vm-minibuffer-complete-word (&optional exiting)
  (interactive)
  (let ((opoint (point))
	;; In Emacs 21, during a minibuffer read the minibuffer
	;; contains the prompt as buffer text and that text is
	;; read only.  So we can no longer assume that (point-min)
	;; is where the user-entered text starts and we must avoid
	;; modifying that prompt text.  The value we want instead
	;; of (point-min) is (minibuffer-prompt-end).
	(point-min (if (fboundp 'minibuffer-prompt-end)
		       (minibuffer-prompt-end)
		     (point-min)))
	(case-fold-search completion-ignore-case)
	trimmed-c-list c-list beg end diff word word-prefix-regexp completion)
    ;; find the beginning and end of the word we're trying to complete
    (if (or (eobp) (memq (following-char) '(?\t ?\n ?\ )))
	(progn
	  (skip-chars-backward " \t\n")
	  (and (not (eobp)) (forward-char))
	  (setq end (point)))
      (skip-chars-forward "^ \t\n")
      (setq end (point)))
    ;; if there can't be multiple words in the input the beginning
    ;; of the word must be at point-min.
    (if (not vm-completion-auto-space)
	(setq beg point-min)
      (skip-chars-backward "^ \t\n")
      (setq beg (point)))
    (goto-char opoint)
    ;; copy the word into a string
    (setq word (buffer-substring beg end))
    ;; trim the completion list down to just likely candidates
    ;; then convert it to an alist.
    (setq word-prefix-regexp (concat "^" (regexp-quote word))
	  trimmed-c-list (vm-delete-non-matching-strings
			  word-prefix-regexp
			  vm-minibuffer-completion-table)
	  trimmed-c-list (sort trimmed-c-list (function string-lessp))
	  trimmed-c-list (mapcar 'list trimmed-c-list)
	  c-list (mapcar 'list vm-minibuffer-completion-table))
    ;; Try the word against the completion list.
    (and trimmed-c-list
	 (setq completion (try-completion word trimmed-c-list)))
    ;; If completion is nil, figure out what prefix of the word would prefix
    ;; something in the completion list... but only if the user is interested.
    (if (and (null completion) vm-completion-auto-correct c-list)
	(let ((i -1))
	  (while (null (setq completion
			     (try-completion (substring word 0 i) c-list)))
	    (vm-decrement i))
	  (setq completion (substring word 0 i))))
    ;; If completion is t, we had a perfect match already.
    (if (eq completion t)
	(cond (vm-completion-auto-space
	       (goto-char end)
	       (insert " "))
	      (t
	       (and (not exiting)
		    (vm-minibuffer-completion-message "[Sole completion]"))))
      ;; Compute the difference in length between the completion and the
      ;; word.  A negative difference means no match and the magnitude
      ;; indicates the number of chars that need to be shaved off the end
      ;; before a match will occur.  A positive difference means a match
      ;; occurred and the magnitude specifies the number of new chars that
      ;; can be appended to the word as a completion.
      ;;
      ;; `completion' can be nil here, but the code works anyway because
      ;; (length nil) still equals 0!
      (setq diff (- (length completion) (length word)))
      (cond
       ;; We have some completion chars.  Insert them.
       ((or (> diff 0) 
	    (and completion (zerop diff) (not (string-equal completion word))))
	(goto-char end)
	(delete-char (- (length word)))
	(insert completion)
	(if (and vm-completion-auto-space
		 (null (cdr trimmed-c-list)))
	    (insert " ")))
       ((null completion)
        (vm-minibuffer-completion-message "[No completion available]"))
       ;; The word prefixed more than one string, but we can't complete
       ;; any further.  Either give help or say "Ambiguous".
       ((zerop diff)
	(and (not exiting)
	     (cond ((> (length (car (car trimmed-c-list))) (length word))
		    (if (null completion-auto-help)
			(vm-minibuffer-completion-message "[Ambiguous]")
		      (vm-minibuffer-show-completions (sort
						       (mapcar 'car
							       trimmed-c-list)
						       'string-lessp))))
		   ((not (eq last-command 'vm-minibuffer-complete-word))
		    (vm-minibuffer-completion-message
		     "[Complete, but not unique]"))
		   (vm-completion-auto-space
		    (insert " ")))))
       ;; The word didn't prefix anything... if vm-completion-auto-correct is
       ;; non-nil strip the offending characters and try again.
       (vm-completion-auto-correct
	(goto-char end)
	(delete-char diff)
	(vm-minibuffer-complete-word exiting))
       ;; if we're not auto-correcting and we're doing
       ;; multi-word, just let the user insert a space.
       (vm-completion-auto-space
	(insert " "))
       ;; completion utterly failed, tell the user so.
       (t
	(and (not exiting)
	     (vm-minibuffer-completion-message "[No match]")))))))
(put 'vm-minibuffer-complete-word 'vm-called-by-vm t)

(defun vm-minibuffer-complete-word-and-exit ()
  "Complete the word before point and leave the minibuffer at once.
`vm-minibuffer-complete-word\' and then `exit-minibuffer\', for a prompt
where one word is the whole answer."
  (interactive)
  (vm-minibuffer-complete-word t)
  (exit-minibuffer))
(put 'vm-minibuffer-complete-word-and-exit 'vm-called-by-vm t)

(defun vm-minibuffer-completion-message (string &optional seconds)
  "Briefly display STRING to the right of the current minibuffer input.
Optional second arg SECONDS specifies how long to keep the message visible;
the default is 2 seconds.

A keypress causes the immediate erasure of the STRING, and return of control
to the calling program."
  (let (omax (inhibit-quit t))
    (save-excursion
      (goto-char (point-max))
      (setq omax (point))
      (insert " " string))
    (sit-for (or seconds 2))
    (delete-region omax (point-max))))

(defun vm-minibuffer-replace-word (word)
  (goto-char (point-max))
  (skip-chars-backward "^ \t\n")
  (delete-region (point) (point-max))
  (insert word))

(defun vm-minibuffer-show-completions (list)
  "Display LIST in a multi-column listing in the \" *Completions*\" buffer.
LIST should be a list of strings."
  (with-current-buffer (get-buffer-create " *Completions*")
    (setq buffer-read-only nil)
    (use-local-map (make-sparse-keymap))
    ;; ignore vm-mutable-* here.  the user shouldn't mind
    ;; because when they exit the minibuffer the windows will be
    ;; set right again.
    (display-buffer (current-buffer))
    (erase-buffer)
    (insert "Possible completions are:\n")
    (setq buffer-read-only t)
    (vm-show-list list 'vm-minibuffer-replace-word
		  (list (current-local-map) minibuffer-local-map))
    (goto-char (point-min))))

(defun vm-show-list (list &optional function keymaps)
  "Display LIST in a multi-column listing in the current buffer at point.
The current buffer must be displayed in some window at the time
this function is called.

LIST should be a list of strings.

Optional second argument FUNCTION will be called if the mouse is
clicked on one of the strings in the current buffer.  The string
clicked upon will be passed to FUNCTION as its sole argument.

Optional third argument KEYMAPS specifies a lists of keymaps
where the FUNCTION should be bound to the mouse clicks.  By
default the local keymap of the current buffer is used."
  (or keymaps (setq keymaps (and (current-local-map)
				 (list (current-local-map)))))
  (save-excursion
    (let ((buffer-read-only nil)
	  (separation 3)
	  tabs longest positions columns list-length q i w start command
	  keymap)
      (cond ((and function keymaps (vm-mouse-support-possible-p))
	     (setq command
		   (list 'lambda '(e) '(interactive "e")
			 (list 'let
			       '((string (vm-mouse-get-mouse-track-string e)))
			       (list 'and 'string (list function 'string)))))
	     (while keymaps
	       (setq keymap (car keymaps))
	       (define-key keymap [down-mouse-1] 'ignore)
	       (define-key keymap [drag-mouse-1] 'ignore)
	       (define-key keymap [mouse-1] command)
	       (define-key keymap [drag-mouse-2] 'ignore)
	       (define-key keymap [down-mouse-2] 'ignore)
	       (define-key keymap [mouse-2] command)
	       (setq keymaps (cdr keymaps)))))
      (setq list (sort (copy-sequence list) (function string-lessp))
	    w (vm-get-buffer-window (current-buffer))
	    q list
	    list-length 0
	    longest 0
	    positions (1- (window-width w)))
      (while q
	(setq longest (max longest (length (car q)))
	      list-length (1+ list-length)
	      q (cdr q)))
      (setq columns (if (< positions (+ longest separation))
			1
		      (/ positions (+ longest separation))))
      (setq tabs (/ list-length columns)
	    tabs (+ tabs
		    (if (zerop (% list-length columns))
			0
		      1)))
      (setq i 0)
      (while (< i tabs)
	(setq q (nthcdr i list))
	(while q
	  (setq start (point))
	  (insert (car q))
	  (when function 
	    (vm-mouse-set-mouse-track-highlight start (point)))
	  (insert-char ?  (+ separation (- longest (length (car q)))))
	  (setq q (nthcdr tabs q)))
	(setq i (1+ i))
	(insert "\n")))))

(defun vm-minibuffer-completion-help ()
  "Show the completions of the word around point.
Unlike ordinary minibuffer completion, which works on the whole of the
input, this completes one word of it -- so a prompt that takes a space
separated list, as the label and attribute prompts do, can complete each
item in turn."
  (interactive)
  (let ((opoint (point))
	c-list beg end word word-prefix-regexp)
    ;; find the beginning and end of the word we're trying to complete
    (if (or (eobp) (memq (following-char) '(?\t ?\n ?\ )))
	(progn
	  (skip-chars-backward " \t\n")
	  (and (not (eobp)) (forward-char))
	  (setq end (point)))
      (skip-chars-forward "^ \t\n")
      (setq end (point)))
    (skip-chars-backward "^ \t\n")
    (setq beg (point))
    (goto-char opoint)
    ;; copy the word into a string
    (setq word (buffer-substring beg end))
    ;; trim the completion list down to just likely candidates
    ;; then convert it to an alist.
    (setq word-prefix-regexp (concat "^" (regexp-quote word))
	  c-list (vm-delete-non-matching-strings
		  word-prefix-regexp
		  vm-minibuffer-completion-table)
	  c-list (sort c-list (function string-lessp)))
    (if c-list
	(vm-minibuffer-show-completions c-list)
      (vm-minibuffer-completion-message " [No match]"))))
(put 'vm-minibuffer-completion-help 'vm-called-by-vm t)

(defun vm-keyboard-read-string (prompt completion-list &optional multi-word)
  (let ((minibuffer-local-map (copy-keymap minibuffer-local-map))
	(vm-completion-auto-space multi-word)
	(vm-minibuffer-completion-table completion-list))
    (define-key minibuffer-local-map "\t" 'vm-minibuffer-complete-word)
    (define-key minibuffer-local-map " " 'vm-minibuffer-complete-word)
    (define-key minibuffer-local-map "?" 'vm-minibuffer-completion-help)
    (if (not multi-word)
	(define-key minibuffer-local-map "\r"
	  'vm-minibuffer-complete-word-and-exit))
    ;; evade the XEmacs dialog box, yeccch.
    (let ((use-dialog-box nil))
      (read-string prompt))))

(defvar last-nonmenu-event)

(defun vm-read-string (prompt completion-list &optional multi-word)
  ;; handle alist
  (if (consp (car completion-list))
      (setq completion-list (nreverse (mapcar 'car completion-list))))
  (if (and completion-list (vm-mouse-support-possible-here-p))
      (if (listp last-nonmenu-event)
	  (vm-mouse-read-string prompt completion-list multi-word)
	(vm-keyboard-read-string prompt completion-list multi-word))
    (vm-keyboard-read-string prompt completion-list multi-word)))

(defun vm-read-number (prompt)
  (let (result)
    (while
	(null
	 (string-match "^[ \t]*-?[0-9]+" (setq result (read-string prompt)))))
    (string-to-number result)))

(defun vm-keyboard-read-file-name (prompt &optional dir default
					  must-match initial history)
  "Like `read-file-name', reading and extending the history in HISTORY.
HISTORY names a variable whose value is a list of file names.  It is
offered in the minibuffer in place of `file-name-history', which is left
alone, and the answer is pushed onto it.

`read-file-name' has no HISTORY argument in GNU Emacs -- its sixth
argument is a completion PREDICATE -- so the list is supplied by binding
`file-name-history' around the call."
  (let ((use-dialog-box nil))		; evade the XEmacs dialog box, yeccch
    (if (null history)
	(read-file-name prompt dir default must-match initial)
      (unless (and (symbolp history) (boundp history))
	(error "HISTORY should name a variable holding a list of file names, not %S"
	       history))
      (let* ((old (symbol-value history))
	     (file (let ((file-name-history old))
		     (read-file-name prompt dir default must-match initial))))
	(set history (cons file (remove file old)))
	file))))

(defun vm-read-file-name (prompt &optional dir default
				 must-match initial history)
  "Like `read-file-name', except a mouse interface is used if a mouse
click mouse triggered the current command."
  (if (vm-mouse-support-possible-here-p)
      (if (listp last-nonmenu-event)
	  (vm-mouse-read-file-name prompt dir default
				   must-match initial history)
	(vm-keyboard-read-file-name prompt dir default
				    must-match initial history))
    (vm-keyboard-read-file-name prompt dir default
				must-match initial history)))

(defun vm-read-folder-name ()
  (completing-read
   ;; prompt
   "VM Folder: "
   ;; collection
   (mapcar (lambda (f) (list f)) (vm-folder-buffers))
   ;; predicate, require-match, initial-input, hist
   nil t nil nil))

(provide 'vm-minibuf)
;;; vm-minibuf.el ends here
