;; Generated package description from scala-mode.el  -*- no-byte-compile: t -*-
(define-package "scala-mode" "1.1.1.0.20260118.94206" "Major mode for editing Scala" '((emacs "25.1")) :commit "50bcafa181baec7054e27f4bca55d5f9277c6350" :keywords '("languages") :url "https://github.com/hvesalai/emacs-scala-mode")
