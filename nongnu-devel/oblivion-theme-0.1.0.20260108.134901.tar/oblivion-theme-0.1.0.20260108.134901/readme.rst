####################
Emacs Oblivion Theme
####################

This theme is a port of the GEdit Oblivion theme.

Available via `melpa <https://melpa.org/#/oblivion-theme>`__.

This theme is quite close to
`GEdit's wonderful Oblivion theme <https://help.gnome.org/users/gedit/stable/>`__.

.. PNG image.

.. figure:: https://codeberg.org/attachments/e478072c-2191-4b85-93d9-954461dd0291
   :scale: 50 %
   :align: center


Notes
=====

Tested to work well with:

Programming Languages:
   - ``c-mode``.
   - ``haskell-mode``.
   - ``java-mode``.
   - ``rust-mode``.

Build Systems:
   - ``cmake-mode``.
   - ``makefile-mode``.

Scripting Languages:
   - ``lua-mode``.
   - ``python-mode``.

Shells:
   - ``bat-mode``.
   - ``shell-mode``.

Markup Languages:
   - ``latex-mode``.
   - ``markdown-mode``.
   - ``org-mode``.
   - ``rst-mode`` (reStructuredText).

Other:
   - ``diff-mode`` with refine colors for emacs 27+.
   - ``ediff-mode``.

Bundled Packages:
   - ``eglot``.
   - ``tab-bar-mode``.
   - ``which-func``.
   - ``whitespace``.
   - ``xref``.

Other Packages:
   - ``idle-highlight-mode``.
   - ``diff-hl``.
   - ``display-line-numbers``.
   - ``fancy-dabbrev``.
   - ``gnus``.
   - ``helm-mode``.
   - ``highlight-indent-guides``.
   - ``highlight-number`` *(needed to match the original theme's number color)*.
   - ``highlight-operators``.
   - ``highlight-symbol``.
   - ``hl-indent-scope``.
   - ``ivy-mode``.
   - ``lsp-mode``.
   - ``magit-commit-mark``.
   - ``neotree``.
   - ``treemacs``.
   - ``visual-indentation-mode``.


Additions, corrections, and improvements are most welcome.
