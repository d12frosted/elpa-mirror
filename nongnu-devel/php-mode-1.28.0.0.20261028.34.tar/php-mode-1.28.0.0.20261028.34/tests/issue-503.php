<?php
function foo () {

}
