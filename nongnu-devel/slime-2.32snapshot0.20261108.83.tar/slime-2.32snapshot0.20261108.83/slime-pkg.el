;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261108.83" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "26cdc8bb6182f4b17b803573721546af705caf0a" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
