;; Generated package description from geiser-chicken.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "geiser-chicken" "0.17.0.20260727.8" "Chicken's implementation of the geiser protocols" '((emacs "24.4") (geiser "0.19")) :commit "80a2aeded0face0822c477d085e62695ab57f639" :keywords '("languages" "chicken" "scheme" "geiser") :url "https://gitlab.com/emacs-geiser/chicken")
