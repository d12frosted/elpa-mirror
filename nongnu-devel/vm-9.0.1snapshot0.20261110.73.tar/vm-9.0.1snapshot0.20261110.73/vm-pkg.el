;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261110.73" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "82483571d6e7f362c7cf5fef7f62622ea18440e8" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
