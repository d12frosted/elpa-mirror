;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260711.51" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "c917f01f1d208ae96683150a35e9bc1d4f56b93b" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
