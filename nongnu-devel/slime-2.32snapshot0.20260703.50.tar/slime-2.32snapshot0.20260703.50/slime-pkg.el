;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260703.50" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "883b19c77ca42f827b5e4631c5428e244c2e063c" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
