;; Generated package description from racket-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "racket-mode" "1.0.20261025.0" "Racket editing, REPL, and more" '((emacs "25.1") (compat "30.0.2.0")) :commit "1ba63e2fa6dd146b71640fefbd0315e0334106e8" :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")) :url "https://www.racket-mode.com/")
