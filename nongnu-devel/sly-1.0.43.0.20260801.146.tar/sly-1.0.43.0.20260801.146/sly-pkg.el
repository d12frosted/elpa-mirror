;; Generated package description from sly.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sly" "1.0.43.0.20260801.146" "Sylvester the Cat's Common Lisp IDE" '((emacs "24.5")) :commit "3ffa216d0818972f7a7fea38a566a6b570349f3b" :keywords '("languages" "lisp" "sly") :url "https://github.com/joaotavora/sly")
