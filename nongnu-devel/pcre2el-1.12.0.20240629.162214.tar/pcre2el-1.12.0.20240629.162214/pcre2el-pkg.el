;; Generated package description from pcre2el.el  -*- no-byte-compile: t -*-
(define-package "pcre2el" "1.12.0.20240629.162214" "regexp syntax converter" '((emacs "25.1")) :commit "b4d846d80dddb313042131cf2b8fbf647567e000" :authors '(("joddie" . "jonxfieldatgmail.com")) :maintainer '("joddie" . "jonxfieldatgmail.com") :url "https://github.com/joddie/pcre2el")
