;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.16.1.0.20260704.4" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "3e5d417d0f9ce63caf1cadd7d2776d590bccf24f" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy")
