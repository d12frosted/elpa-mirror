;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.0snapshot0.20261010.250" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "e1a00b9c9143dad6182cfb3069bc040a6434077e" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
