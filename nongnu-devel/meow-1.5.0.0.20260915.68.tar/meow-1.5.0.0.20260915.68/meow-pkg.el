;; Generated package description from meow.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "meow" "1.5.0.0.20260915.68" "Yet Another modal editing" '((emacs "27.1")) :commit "8aebed9f8cd8d865501b780e63acbeef55da231b" :keywords '("convenience" "modal-editing") :url "https://www.github.com/DogLooksGood/meow")
