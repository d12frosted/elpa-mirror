;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "8.3.3snapshot0.20260802.57" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "b8a1b5f6c108a1e06f6a0f13bbb52ed6847156bd" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
