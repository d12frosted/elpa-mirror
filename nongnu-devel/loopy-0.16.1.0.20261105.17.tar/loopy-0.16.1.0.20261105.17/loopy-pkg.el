;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.16.1.0.20261105.17" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "b75089cdf0a7b004b44ea703d80c47ac821b2635" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy")
