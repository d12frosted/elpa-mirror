;; Generated package description from rubocop.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "rubocop" "0.7.0.20210309.124149" "An Emacs interface for RuboCop" '((emacs "24")) :commit "f5fd18aa810c3d3269188cbbd731ddc09006f8f5" :keywords '("project" "convenience") :url "https://github.com/rubocop/rubocop-emacs")
