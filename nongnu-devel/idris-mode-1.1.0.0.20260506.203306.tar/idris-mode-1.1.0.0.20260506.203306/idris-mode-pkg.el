;; Generated package description from idris-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "idris-mode" "1.1.0.0.20260506.203306" "Major mode for editing Idris code" '((emacs "24") (prop-menu "0.1") (cl-lib "0.5")) :commit "22cc1bf237428b24de5f4f228db747e93a4ae619" :keywords '("languages") :url "https://github.com/idris-hackers/idris-mode")
