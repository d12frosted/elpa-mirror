;; Generated package description from jade-mode.el  -*- no-byte-compile: t -*-
(define-package "jade-mode" "1.0.1.0.20211019.161323" "Major mode for editing .jade files" 'nil :commit "1ad7c51f3c6a6ae64550d9510c5e4e8470014375" :keywords '("languages") :url "https://github.com/brianc/jade-mode")
