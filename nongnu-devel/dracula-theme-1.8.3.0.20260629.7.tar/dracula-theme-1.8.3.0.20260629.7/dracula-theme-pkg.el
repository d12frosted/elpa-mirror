;; Generated package description from dracula-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "dracula-theme" "1.8.3.0.20260629.7" "Dracula Theme" '((emacs "24.3")) :commit "fa562443129993e3408ea300595b230874da33db" :maintainer '("tienne Deparis" . "etienne@depar.is") :url "https://github.com/dracula/emacs")
