;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260909.69" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "a93bb5e00235b72ce086faca13b33955f44b416e" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
