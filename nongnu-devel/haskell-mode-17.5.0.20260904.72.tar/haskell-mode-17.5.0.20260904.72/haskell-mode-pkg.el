;; Generated package description from haskell-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "haskell-mode" "17.5.0.20260904.72" "A Haskell editing mode" '((emacs "25.1")) :commit "4bdd38c22d8a54d3284b517e889863a1d3971998" :keywords '("haskell" "cabal" "ghc" "repl" "languages") :url "https://github.com/haskell/haskell-mode")
