;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261102.82" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "728a05ed0afc12626e3792be1c5bccc01913c269" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
