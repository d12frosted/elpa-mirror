;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261101.35" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "665d76571c7a0748b315760e830639d520ab8f2b" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
