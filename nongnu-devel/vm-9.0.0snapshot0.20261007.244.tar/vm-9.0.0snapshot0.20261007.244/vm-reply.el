;;; vm-reply.el --- Mailing, forwarding, and replying commands  -*- lexical-binding: t; -*-
;;
;; This file is part of VM
;;
;; Copyright (C) 1989-2001 Kyle E. Jones
;; Copyright (C) 2003-2006 Robert Widhopf-Fenk
;; Copyright (C) 2024-2026 The VM Developers
;; Copyright (C) 2024-2026 The VM Developers
;;
;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 2 of the License, or
;; (at your option) any later version.
;;
;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.
;;
;; You should have received a copy of the GNU General Public License along
;; with this program; if not, write to the Free Software Foundation, Inc.,
;; 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

;;; Commentary:

;;; Interface:
;; Interactive commands:
;;
;; vm-yank-message: (message) -> unit
;; vm-yank-message-other-folder: (folder) -> unit
;; vm-mail-send-and-exit: () -> unit
;; vm-mail-send: () -> unit
;; vm-do-fcc-before-mime-encode: () -> unit
;; vm-reply: (count) -> unit
;; vm-reply-other-frame: (count) -> unit
;; vm-reply-include-text: (count) -> unit
;; vm-reply-include-text-other-frame: (count) -> unit
;; vm-followup: (count) -> unit
;; vm-followup-other-frame: (count) -> unit
;; vm-followup-include-text: (count) -> unit
;; vm-followup-include-text-other-frame: (count) -> unit
;; vm-forward-message: (&optional bool message-list) -> unit
;; vm-forward-message-plain: () -> unit
;; vm-forward-message-other-frame: () -> unit
;; vm-forward-message-plain-other-frame: () -> unit
;; vm-forward-message-all-headers: () -> unit
;; vm-forward-message-all-headers-other-frame: () -> unit
;; vm-resend-message: () -> unit
;; vm-resend-message-other-frame: () -> unit
;; vm-resend-bounced-message: () -> unit
;; vm-resend-bounced-message-other-frame: () -> unit
;; vm-send-digest: (&optional preamble-line list) -> unit
;; vm-send-digest-other-frame: (&optional preamble-line list) -> unit
;; vm-send-rfc934-digest: (&optional preamble-line list) -> unit
;; vm-send-rfc934-digest-other-frame: (&optional preamble-line list) -> unit
;; vm-send-rfc1153-digest: (&optional preamble-line list) -> unit
;; vm-send-rfc1153-digest-other-frame: (&optional preamble-line list) -> unit
;; vm-send-mime-digest: (&optional preamble-line list) -> unit
;; vm-send-mime-digest-other-frame: (&optional preamble-line list) -> unit
;; vm-continue-composing-message () -> unit
;; vm-mail-to-mailto-url: (url) -> unit
;; vm-preview-composition: () -> unit
;;
;; vm-mail-mode-show-headers: () -> unit
;; vm-mail-mode-hide-headers: () -> unit

;;; Code:

(require 'vm-macro)
(require 'vm-summary)
(eval-when-compile (require 'cl-lib))

;; Say so if this file's compiled form outlives the VM it was built
;; against; see `vm-assert-version' (#791).
(vm-assert-version)

(declare-function vm-emacs-name-and-version "vm" ())
(declare-function vm-mode "vm" (&optional read-only))
;; The Fcc of a composition may name an IMAP mailbox (emacs-vm/vm#605), so
;; this file calls into vm-imap.el, which requires this one.
(declare-function vm-imap-save-composition "vm-imap" ())
(declare-function vm-imap-parse-spec-to-list "vm-imap" (spec))
(declare-function vm-imap-subst-CRLF-for-LF "vm-imap" (string))
;; A cl-defun taking &key arguments: spelling the arglist out here makes the
;; compiler count a keyword call wrongly, so it is left unsaid.
(declare-function vm-imap-make-session "vm-imap" t)
(declare-function vm-imap-spec-fields "vm-imap" (spec))
(declare-function vm-imap-net-append-text "vm-imap-net"
		  (spec mailbox text &optional flags may-ask))
(declare-function vm-imap-append-message "vm-imap"
		  (process mailbox string &optional flags))
(declare-function vm-imap-end-session "vm-imap"
		  (process &optional imap-buffer keep-buffer))
(declare-function dnd-get-local-file-name "dnd" (uri &optional must-exist))
(declare-function vm-session-initialization "vm" ())
(declare-function vm-version "vm" ())

;; vm-digest.el functions - cyclic dependency
(declare-function vm-no-frills-encapsulate-message "vm-digest"
		  (m keep-list discard-regexp))
(declare-function vm-mime-encapsulate-messages "vm-digest" t)
(declare-function vm-rfc934-encapsulate-messages "vm-digest"
		  (message-list keep-list discard-regexp))
(declare-function vm-rfc1153-encapsulate-messages "vm-digest"
		  (message-list keep-list discard-regexp))

(declare-function mail-strip-quoted-names "ext:mail-utils" (address))
(declare-function mail-fetch-field "ext:mail-utils" 
		  (field-name &optional last all list))
(declare-function mail-send "ext:sendmail" ())
(declare-function mail-do-fcc "ext:sendmail" (header-end))
(declare-function mail-text "ext:sendmail" ())
(declare-function mail-position-on-field "ext:sendmail" 
		  (field &optional soft))
(declare-function mail-mode "ext:sendmail" ())
(declare-function build-mail-aliases "ext:mailalias" (&optional file))
(declare-function sendmail-sync-aliases "ext:sendmail" ())
(declare-function vm-pcrisis-configured-but-off-p "vm" ())
(declare-function mail-insert-from-field "ext:sendmail" ())

(defun vm-add-reply-subject-prefix (message &optional start)
  (when (not start)
    (goto-char (point-min))
    (re-search-forward 
     (concat "^\\(" (regexp-quote mail-header-separator) "\\)$")
     (point-max))
    (forward-char 1)
    (setq start (point)))
  (goto-char start)
  (if (and message vm-included-text-attribution-format)
      (let ((vm-summary-uninteresting-senders nil))
        (insert (vm-summary-sprintf
                 vm-included-text-attribution-format
                 message))))
  (while (re-search-forward "^" (point-max) t)
    (insert vm-included-text-prefix)))

;;;###autoload
(defun vm-fill-long-lines-in-reply ()
  "Fill lines in the message composition in the current buffer,
provided it has lines longer than the line length specified by
`vm-fill-paragraphs-containing-long-lines-in-reply'.  If that variable
is `nil' then it uses the width of the window as the maximum line
length." 
  (interactive)
  (let ((vm-word-wrap-paragraphs vm-word-wrap-paragraphs-in-reply)
					; doesn't work well with fill-prefixes
	(vm-paragraph-fill-column vm-fill-long-lines-in-reply-column))
    (when (or (vm-interactive-p)
	      vm-fill-paragraphs-containing-long-lines-in-reply)
      (vm-fill-paragraphs-containing-long-lines
       (or vm-fill-paragraphs-containing-long-lines-in-reply
	   'window-width)		; use window-width for interactive
       (save-excursion
	 (goto-char (point-min))
	 (re-search-forward 
	  (concat "^\\(" (regexp-quote mail-header-separator) "\\)$")
	  (point-max))
	 (forward-line 1)
	 (point))
       (point-max)))))

;;;###autoload
(defun vm-do-reply (to-all include-text count)
  "Set up a VM composition buffer for sending a reply (and switch the
focus to that buffer?).  The reply is sent to the current message in
the folder buffer or other selected messages.  The dynamically bound
variable `vm-enable-thread-operations' should be bound to nil before
calling this function in order to avoid surprises for the user.

The argument TO-ALL says whether the reply should go to all the
recipients of the original messages.  INCLUDE-TEXT says whether
the body of those messages should be included in the reply.
COUNT is the prefix argument indicating how many consecutive
messages of the folder are involved in this reply."
  (let ((mlist (vm-select-operable-messages
		count (vm-interactive-p) "Reply to"))
        (case-fold-search t)
        to cc subject in-reply-to references
        mp tmp tmp2 newsgroups)
    (vm-retrieve-operable-messages count mlist :fail t)
    (when (and include-text vm-include-text-from-presentation
	       (> (length mlist) 1))
      (error "Including presentation is possible for only a single message"))
    (setq mp mlist)
    (while mp
      (cond ((setq tmp (vm-get-header-contents (car mp) "Reply-To:" ", "))
             (unless (vm-ignored-reply-to tmp)
               (cl-pushnew tmp to :test #'equal)))
            ((setq tmp (vm-get-header-contents (car mp) "From:" ", "))
             (cl-pushnew tmp to :test #'equal))
            ;; bad, but better than nothing for some
            ((setq tmp (vm-grok-From_-author (car mp)))
             (cl-pushnew tmp to :test #'equal))
            (t (error "No From: or Reply-To: header in message")))
      (let ((this-subject (vm-get-header-contents (car mp) "Subject:"))
            (this-reply-to (and vm-in-reply-to-format
                                (let ((vm-summary-uninteresting-senders nil))
                                  (vm-summary-sprintf vm-in-reply-to-format
                                                      (car mp))))))
        (if (and this-subject vm-reply-subject-prefix
                 (not (string-match vm-reply-subject-prefix this-subject)))
            (setq this-subject (concat vm-reply-subject-prefix
                                       this-subject)))
        (unless subject
          (setq subject (concat this-subject
                                (if (cdr mlist)
                                    (format " [and %d more messages]"
                                            (length (cdr mlist)))))))
        (setq in-reply-to (if in-reply-to
                              (concat in-reply-to ",\n\t" this-reply-to)
                            this-reply-to)))
      (when to-all
	(setq tmp (vm-get-header-contents (car mp) "To:" ", "))
	(setq tmp2 (vm-get-header-contents (car mp) "Cc:" ", "))
	(when tmp
	  (if cc
	      (setq cc (concat cc "," tmp))
	    (setq cc tmp)))
	(when tmp2
	  (if cc
	      (setq cc (concat cc "," tmp2))
	    (setq cc tmp2))))
      ;; References header will be made from the last message.  Others
      ;; will be ignored.
      (setq references
            (cons (or (vm-get-header-contents (car mp) "References:" " ")
                      (vm-get-header-contents (car mp) "In-reply-to:" " "))
                  (list (vm-get-header-contents (car mp) "Message-ID:" " "))))
      (setq newsgroups
            (cons (or (and to-all
                           (vm-get-header-contents 
			    (car mp) "Followup-To:" ","))
                      (vm-get-header-contents (car mp) "Newsgroups:" ","))
                  newsgroups))
      (setq mp (cdr mp)))

    (when to
      (setq to (mapconcat #'identity (nreverse to) ", ")))

    (when vm-strip-reply-headers
      (let ((mail-use-rfc822 t))
	(and to (setq to (mail-strip-quoted-names to)))
	(and cc (setq cc (mail-strip-quoted-names cc)))))
    (setq to (vm-parse-addresses to)
          cc (vm-parse-addresses cc))
    (when vm-reply-ignored-addresses
      (setq to (vm-strip-ignored-addresses to)
	    cc (vm-strip-ignored-addresses cc)))
    (setq to (vm-delete-duplicates to nil t))
    (setq cc (vm-delete-duplicates
              (append (vm-delete-duplicates cc nil t)
                      to (copy-sequence to))
              t t))
    (when to (setq to (mapconcat 'identity to ",\n    ")))
    (when cc (setq cc (mapconcat 'identity cc ",\n    ")))
    (when (null to) (setq to cc cc nil))
    (setq references (delq nil references)
          references (mapconcat 'identity references " ")
          references (vm-parse references "[^<]*\\(<[^>]+>\\)")
          references (vm-delete-duplicates references)
          references (if references (mapconcat 'identity references "\n\t")))
    (setq newsgroups (delq nil newsgroups)
          newsgroups (mapconcat 'identity newsgroups ",")
          newsgroups (vm-parse newsgroups "[ \t\f\r\n,]*\\([^ \t\f\r\n,]+\\)")
          newsgroups (vm-delete-duplicates newsgroups)
          newsgroups (if newsgroups (mapconcat 'identity newsgroups ",")))
    (vm-mail-internal
     :buffer-name (format "reply to %s%s" (vm-su-full-name (car mlist))
			  (if (cdr mlist) ", ..." ""))
     :to to :subject subject :in-reply-to in-reply-to :cc cc 
     :references references :newsgroups newsgroups)
    (make-local-variable 'vm-reply-list)
    (setq vm-system-state 'replying
          vm-reply-list mlist)
    (when include-text
      (save-excursion
	(goto-char (point-min))
	(let ((case-fold-search nil))
	  (re-search-forward
	   (concat "^" (regexp-quote mail-header-separator) "$") nil 0))
	(forward-char 1)
	(while mlist
	  (save-restriction
	    (narrow-to-region (point) (point))
	    (vm-yank-message (car mlist))
	    (goto-char (point-max)))
	  (setq mlist (cdr mlist))))
      ;; Set window-start to the top because the yanks processed by
      ;; emacs-w3m are somehow clobbering the buffer in Emacs 24
      (set-window-start nil (point-min)))
    (when vm-fill-paragraphs-containing-long-lines-in-reply
      (vm-fill-long-lines-in-reply))
    (run-hooks 'vm-reply-hook)
    (vm-mail-mode-apply-options)
    (run-hooks 'vm-mail-mode-hook)))

(defun vm-strip-ignored-addresses (addresses)
  (setq addresses (copy-sequence addresses))
  (let (re-list addr-list) ;; list
    (setq re-list vm-reply-ignored-addresses)
    (while re-list
      (setq addr-list addresses)
      (while addr-list
	(when (string-match (car re-list) (car addr-list))
	  (setq addresses (delq (car addr-list) addresses)))
	(setq addr-list (cdr addr-list)))
      (setq re-list (cdr re-list))))
  addresses )

(defun vm-ignored-reply-to (reply-to)
  (if (and reply-to (not (string= reply-to "")))
      (let (re-list result)
	(setq re-list vm-reply-ignored-reply-tos)
	(while re-list
	  (if (string-match (car re-list) reply-to)
	      (setq result t re-list nil)
	    (setq re-list (cdr re-list))))
	result)))

(defvar zmacs-regions) ;; XEmacs.

(defun vm-mail-yank-default (&optional message)
  "The default message yank handler when `mail-citation-hook' is set to nil."
  (save-excursion
    (vm-reorder-message-headers 
     nil :keep-list vm-included-text-headers
     :discard-regexp vm-included-text-discard-header-regexp)
    ;; if all the headers are gone, delete the trailing blank line, too.
    (when (eq (following-char) ?\n)
      (delete-char 1))
    (when (and message vm-included-text-attribution-format)
      (let ((vm-summary-uninteresting-senders nil))
	(insert (vm-summary-sprintf vm-included-text-attribution-format
				    message))))
    ;; turn off zmacs-regions for Lucid Emacs 19
    ;; and get around transient-mark-mode in FSF Emacs 19
    ;; all this so that (mark) does what it did in v18, sheesh.
    (let* ((zmacs-regions nil)
	   (mark-even-if-inactive t)
	   (end (mark-marker)))
      (while (< (point) end)
	(insert vm-included-text-prefix)
	(forward-line 1)))))

;;;###autoload
(defun vm-yank-message-other-folder (folder)
  "Like vm-yank-message except the message is yanked from a folder other
than the one that spawned the current Mail mode buffer.  The name of the
folder is read from the minibuffer.

Don't call this function from a program."
  (interactive
   (list
    (let ((dir (if vm-folder-directory
		    (expand-file-name vm-folder-directory)
		  default-directory))
	  (last-command last-command)
	  (this-command this-command))
      (read-file-name "Yank from folder: " dir nil t))))
  (let ((b (current-buffer)) newbuf sumbuf default result prompt mp)
    (set-buffer (or (vm-get-file-buffer folder) (find-file-noselect folder)))
    (setq newbuf (current-buffer))
    (unless (eq major-mode 'vm-mode)
      (vm-mode))
    (when vm-presentation-buffer-handle
      (vm-bury-buffer vm-presentation-buffer-handle))
    (when (null vm-message-pointer)
      (error "No messages in folder %s" folder))
    (setq default (vm-number-of (car vm-message-pointer)))
    (save-excursion
      (save-window-excursion
	(save-window-excursion
	  (vm-summarize))
	(vm-display vm-summary-buffer t '(vm-yank-message-other-folder)
		    '(vm-yank-message-other-folder composing-message))
	(setq sumbuf (current-buffer))
	(setq prompt (format "Yank message number: (default %s) " default)
	      result 0)
	(while (zerop result)
	  (setq result (read-string prompt))
	  (and (string= result "") default (setq result default))
	  (setq result (string-to-number result)))
	(when (null (setq mp (nthcdr (1- result) vm-message-list)))
	  (error "No such message."))))
    (set-buffer b)
    (unwind-protect
	(let ((vm-mail-buffer newbuf))
	  (vm-yank-message (car mp)))
      (vm-bury-buffer newbuf)
      (vm-bury-buffer sumbuf))))

;;;###autoload
(defun vm-yank-message (message)
  "Yank message number N into the current buffer at point.
When called interactively N is always read from the minibuffer.  When
called non-interactively the first argument is expected to be a
message struct.

This command is meant to be used in VM created Mail mode buffers; the
yanked message comes from the mail buffer containing the message you
are replying to, forwarding, or invoked VM's mail command from.

The whole message is inserted, headers and all, with point left
before it and the mark after it, which is where a function on
`mail-citation-hook' looks for what it is to cite.  Anything on
that hook is then run.

With nothing on the hook VM cites the message itself: the yanked
headers are trimmed as specified by `vm-included-text-headers' and
`vm-included-text-discard-header-regexp', which between them keep
none by default, and the value of `vm-included-text-prefix' is
prepended to every line that is left."
  (interactive
   (list
    ;; What we really want for the first argument is a message struct,
    ;; but if called interactively, we let the user type in a message
    ;; number instead.
    (let (mp default
             (result 0)
             prompt
             (last-command last-command)
             (this-command this-command))
      (save-current-buffer
	(vm-select-folder-buffer)
	(setq default (and vm-message-pointer
			   (vm-number-of (car vm-message-pointer)))
	      prompt (if default
			 (format "Yank message number: (default %s) "
				 default)
		       "Yank message number: "))
	(while (zerop result)
	  (setq result (read-string prompt))
	  (and (string= result "") default (setq result default))
	  (setq result (string-to-number result)))
	(when (null (setq mp (nthcdr (1- result) vm-message-list)))
	  (error "No such message.")))
      (car mp))))
  (unless (bufferp vm-mail-buffer)
    (error "This is not a VM Mail mode buffer."))
  (unless (buffer-name vm-mail-buffer)
    (error "The folder buffer containing message %d has been killed."
	   (vm-number-of message)))
  (vm-display nil nil '(vm-yank-message) '(vm-yank-message composing-message))
  (vm-retrieve-operable-messages 1 (list message) :fail t)
  (setq message (vm-real-message-of message))
  (let ((layout (vm-mm-layout message))
	(start (point))
        (end (point-marker)))
     (save-excursion
       ;; yank the message body as per settings
       (cond ((and vm-include-text-from-presentation
		   (not (vm-mime-plain-message-p message))
		   (or (eq message (car vm-message-pointer))
		       (progn
			 (message 
			  (concat "Can yank presentation for only the "
				  "current message.  Using default yank."))
			 (sit-for 2)
			 nil)))
	      (vm-yank-message-presentation)
	      (setq end (point-marker)))
	     (vm-include-text-basic
	      (vm-yank-message-text message layout)
	      (setq end (point-marker)))
	     (t
	      (vm-yank-message-mime message layout)
	      (setq end (point-marker)))
	     )
       ;; decode MIME encoded words so supercite and other
       ;; mail-citation-hook denizens won't have to eat 'em.
       (when vm-display-using-mime
	 (save-restriction
	   (narrow-to-region start end)
	   (vm-decode-mime-encoded-words))))
    ;; get rid of read-only text properties on the text, as
    ;; they will only cause trouble.
    (let ((inhibit-read-only t))
      (remove-text-properties (point-min) (point-max)
                              '(read-only nil invisible nil)
                              (current-buffer)))
    (push-mark end)
    (save-excursion
      ;; Move point above the headers which should be at the top of
      ;; the buffer by this point, and given the push-mark above, mark
      ;; should now be after the message text. This is the invariant
      ;; needed by the hook functions called by mail-citation-hook
      ;; whose doc string states "Each hook function can find the
      ;; citation between (point) and (mark t)." The upshot of that is
      ;; that if point equals mark at the end of the buffer, some
      ;; citation functions will fail with messages similar to
      ;; "doesn't conform to RFC 822." -- Brent Goodrick, 2009-01-24
      ;; But this yanks wrongly!  The following line reverted by Uday
      ;; Reddy, 2009-12-07 
      (cond (mail-citation-hook (run-hooks 'mail-citation-hook))
	    ;; mail-yank-hooks is obsolete now
	    ;; `mail-yank-hooks' is not consulted: it was obsoleted by
	    ;; `mail-citation-hook' above.
	    (t (vm-mail-yank-default message))))))

(defun vm-yank-message-presentation ()
  ;; This function is the same as Rob's vm-insert-presentation.
  ;; It has been reported that it includes the entire mail box on
  ;; occasion.  See Bug #498477.  It should not be used until that
  ;; problem resolved.
  (let ((start (point)))
    (vm-insert-region-from-buffer
     (save-excursion
       (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
       ;; ensure the current message is presented 
       (vm-present-current-message)
       (vm-show-current-message)
       (vm-select-folder-buffer)
       (when vm-presentation-buffer
	   (set-buffer vm-presentation-buffer))
       (current-buffer)))
    (save-excursion
      (goto-char start)
      (when (looking-at "From ")
	(delete-region start (1+ (line-end-position)))))))

(defconst vm-mime-yanked-button-format-alist
  '(
    ("text" .        "[DELETED ATTACHMENT %f, %t]")
    ("message" .     "[DELETED ATTACHMENT %f, %t]")
    ("audio" .       "[DELETED ATTACHMENT %f, %t]")
    ("video" .       "[DELETED ATTACHMENT %f, %t]")
    ("image" .       "[DELETED ATTACHMENT %f, %t]")
    ("application" . "[DELETED ATTACHMENT %f, %t]")
    ))

(defun vm-yank-message-mime (message layout)
  ;; This is Rob's new code that uses vm-decode-mime-layout for
  ;; creating the yanked text, but use the reply-specific settings for
  ;; filling etc.
  (let ((vm-word-wrap-paragraphs 
	 vm-word-wrap-paragraphs-in-reply)
					; doesn't work well with fill-prefixes
	(vm-fill-paragraphs-containing-long-lines
	 vm-fill-paragraphs-containing-long-lines-in-reply)
	(vm-paragraph-fill-column
	 vm-fill-long-lines-in-reply-column)
	;; An HTML part is converted to text here, and the converter would
	;; otherwise pick a width of its own -- the window's, in the case of
	;; emacs-w3m (#369).
	(vm-html-fill-column vm-html-in-reply-column)
	)
    (if (eq layout 'none)
	(vm-insert-region-from-buffer (vm-buffer-of message)
				      (vm-headers-of message)
				      (vm-text-end-of message))
      (vm-insert-region-from-buffer (vm-buffer-of message)
				    (vm-headers-of message)
				    (vm-text-of message))
      (save-excursion
	(goto-char (point-min))
	(vm-decode-mime-message-headers))

      ;; Use normal MIME decoding but override normal parameter settings
      (let (;; override the alternative-select-method if necessary
	    (vm-mime-alternative-show-method
	     (or vm-mime-alternative-yank-method
		 vm-mime-alternative-show-method))
	    ;; include only text and message/rfc822 types
	    ;; message/external-body should not be included
	    (vm-mime-auto-displayed-content-types '("text" "message/rfc822"))
	    ;; don't include separator for multipart
	    (vm-mime-parts-display-separator "")
	    ;; make MIME buttons look like text unless they are included
	    (vm-mime-button-face (if vm-include-mime-attachments
				     vm-mime-button-face
				   'default))
	    (vm-mime-button-mouse-face (if vm-include-mime-attachments
					   vm-mime-button-mouse-face
					 nil))
	    ;; use different labels
	    (vm-mime-button-format-alist vm-mime-yanked-button-format-alist)
	    )
	(vm-decode-mime-layout layout))

      ;; Make the MIME buttons attachment buttons
      (if vm-include-mime-attachments
	  (vm-mime-convert-to-attachment-buttons)))))

(defun vm-yank-message-text (message layout)
  ;; This is the original code for included text
  (let (new-layout alternatives parts res insert-start) ;; type
    (if (null (vectorp (vm-mm-layout message)))
	(let ((b (current-buffer)))
	  (set-buffer (vm-buffer-of message))
	  (save-restriction
	    (widen)
	    ;; decode MIME encoded words so supercite and other
	    ;; mail-citation-hook denizens won't have to eat 'em.
	    (append-to-buffer b (vm-headers-of message)
			      (vm-text-end-of message))
	    (set-buffer b)))
      (setq parts (list layout))
      (setq alternatives 0)

      (vm-insert-region-from-buffer 
       (vm-buffer-of message) (vm-headers-of message) (vm-text-of message))
      (while parts
	(setq layout (car parts))
	(cond ((vm-mime-text-type-layout-p layout)
	       (cond ((vm-mime-types-match
		       "text/plain" (car (vm-mm-layout-type layout)))
		      (setq res (vm-mime-display-internal-text/plain
				 layout t)))
		     ((vm-mime-types-match
		       "text/enriched" (car (vm-mm-layout-type layout)))
		      (setq res (vm-mime-display-internal-text/enriched
				 layout)))
		     ((vm-mime-types-match
		       "message/rfc822" (car (vm-mm-layout-type layout)))
		      (setq res (vm-mime-display-internal-message/rfc822
				 layout)))
		     ;; no text/html for now
		     ((member (downcase (car (vm-mm-layout-type layout)))
			      vm-included-mime-types-list)
		      (if (and (not (vm-mm-layout-is-converted layout))
			       (vm-mime-can-convert 
				(car (vm-mm-layout-type layout)))
			       (setq new-layout
				     (vm-mime-convert-undisplayable-layout
				      layout)))
			  (setq res (vm-decode-mime-layout new-layout))
			(setq res (vm-mime-display-internal-text/plain
				   layout t)))))
	       (if res
		   (while (> alternatives 1)
		     (setq parts (cdr parts))
		     (setq alternatives (1- alternatives)))
		 (when (member (downcase (car (vm-mm-layout-type layout)))
			       vm-included-mime-types-list)
		   ;; charset problems probably
		   ;; just dump the raw bits
		   (setq insert-start (point))
		   (vm-mime-insert-mime-body layout)
		   (vm-mime-transfer-decode-region 
		    layout insert-start (point))))
	       (setq parts (cdr parts)))
	      ((vm-mime-composite-type-p (car (vm-mm-layout-type layout)))
	       (when (vm-mime-types-match 
		      "multipart/alternative" (car (vm-mm-layout-type layout)))
		 (setq alternatives (length (vm-mm-layout-parts (car parts)))))
	       (setq parts (nconc (copy-sequence
				   (vm-mm-layout-parts
				    (car parts)))
				  (cdr parts))))
	      (t
	       (setq alternatives (1- alternatives))
	       (setq parts (cdr parts))))))))

;;;###autoload
(defun vm-mail-send-and-exit (&rest _ignored)
  "Send message and maybe delete the composition buffer.
The value of `vm-keep-sent-messages' determines whether the composition buffer
is deleted.  If the composition is a reply to a message in a currently visited
folder, that message is marked as having been replied to."  
  (interactive "P")
  (vm-check-for-killed-folder)
  (when (and (boundp 'mail-alias-file)
	     mail-alias-file
	     (not (eq (user-uid) 0)))
    (error "Must be superuser to use mail-alias-file.  Please set mail-alias-file to nil."))
  (let ((b (current-buffer)))
    (vm-mail-send)
    (cond ((null (buffer-name b)) ;; dead buffer
	   ;; This improves window configuration behavior in
	   ;; XEmacs.  It avoids taking the folder buffer from
	   ;; one frame and attaching it to the selected frame.
	   (set-buffer (window-buffer (selected-window)))
	   (vm-display nil nil '(vm-mail-send-and-exit)
		       '(vm-mail-send-and-exit
			 reading-message
			 startup)))
	  (t
	   (vm-display b nil '(vm-mail-send-and-exit)
		       '(vm-mail-send-and-exit reading-message startup))
	   (vm-bury-buffer b)))))

(defun vm-keep-mail-buffer (buffer)
  (vm-keep-some-buffers buffer 'vm-kept-mail-buffers vm-keep-sent-messages))

(defun vm-check-recipient-format ()
  (save-excursion
    (goto-char (point-min))
    (while (vm-match-header)
      (if (not (vm-match-header "To:\\|Resent-To:\\|Cc:\\|Resent-Cc:"))
	  (goto-char (vm-matched-header-end))
	(goto-char (vm-matched-header-contents-start))
	(if (re-search-forward "[^, \t][ \t]*\n[ \t\n]+[^ \t\n]"
			       (vm-matched-header-contents-end)
			       t)
	    (error "missing trailing comma in `%s' header" (vm-matched-header-name)))
	(goto-char (vm-matched-header-end))))))

(defun vm-mail-mode-insert-message-id-maybe ()
  (when vm-mail-header-insert-message-id
    (save-restriction
      (save-excursion
	(let ((resent nil))
	  (if (or (vm-mail-mode-get-header-contents "Resent-To:")
		  (vm-mail-mode-get-header-contents "Resent-Cc:")
		  (vm-mail-mode-get-header-contents "Resent-Bcc:"))
	      (progn
		(vm-mail-mode-remove-header "Resent-Message-ID:")
		(setq resent t))
	    (vm-mail-mode-remove-header "Message-ID:"))
	  (widen)
	  (goto-char (point-min))
	  (insert (format "%sMessage-ID: %s\n"
			  (if resent "Resent-" "")
			  (vm-make-message-id))))))))

(defun vm-mail-mode-insert-date-maybe ()
  "Insert a Date header into the composition, unless it has one to keep.
`vm-mail-mode-fake-date-p' is what keeps one: it lets you write the Date
yourself and have VM leave it alone."
  (if (or (not vm-mail-header-insert-date)
	  (and vm-mail-mode-fake-date-p
	       (vm-mail-mode-get-header-contents "Date:")))
      nil
    (save-restriction
      (save-excursion
	(let* ((timezone (car (current-time-zone)))
	       (hour (/ timezone 3600))
	       (min (/ (- timezone (* hour 3600)) 60))
	       (time (current-time))
	       (resent nil))
	  (if (or (vm-mail-mode-get-header-contents "Resent-To:")
		  (vm-mail-mode-get-header-contents "Resent-Cc:")
		  (vm-mail-mode-get-header-contents "Resent-Bcc:"))
	      (progn
		(vm-mail-mode-remove-header "Resent-Date:")
		(setq resent t))
	    (vm-mail-mode-remove-header "Date:"))
	  (widen)
	  (goto-char (point-min))
	  (insert (format "%sDate: " (if resent "Resent-" ""))
		  (capitalize
		   (car (nth (string-to-number (format-time-string "%w" time))
			     vm-weekday-alist)))
		  ", "
		  ;; %e generated " 2".  Go from string to int
		  ;; to string to get rid of the blank.
		  (int-to-string
		   (string-to-number
		    (format-time-string "%e" time)))
		  " "
		  (capitalize
		   (car (nth
			 (1- (string-to-number (format-time-string "%m" time)))
			 vm-month-alist)))
		  (format-time-string " %Y %H:%M:%S" time)
		  (format " %s%02d%02d"
			  (if (< timezone 0) "-" "+")
			  (abs hour)
			  (abs min))
;; localization in Europe and elsewhere can cause %Z to return
;; 8-bit chars, which are forbidden in headers.
		  "\n"))))))

(defun vm-mail-mode-remove-message-id-maybe ()
  (if vm-mail-header-insert-message-id
      (let () ;; (resent nil)
	(if (or (vm-mail-mode-get-header-contents "Resent-To:")
		(vm-mail-mode-get-header-contents "Resent-Cc:")
		(vm-mail-mode-get-header-contents "Resent-Bcc:"))
	    (progn
	      (vm-mail-mode-remove-header "Resent-Message-ID:")
	      t)
	  (vm-mail-mode-remove-header "Message-ID:")))))

(defun vm-mail-mode-remove-date-maybe ()
  (if vm-mail-header-insert-date
      (let ();; (resent nil)
	(if (or (vm-mail-mode-get-header-contents "Resent-To:")
		(vm-mail-mode-get-header-contents "Resent-Cc:")
		(vm-mail-mode-get-header-contents "Resent-Bcc:"))
	    (progn
	      (vm-mail-mode-remove-header "Resent-Date:")
	      t)
	  (vm-mail-mode-remove-header "Date:")))))

;;;###autoload
(defun vm-mail-get-header-contents (header-name-regexp &optional clump-sep)
  "Return the contents of the header(s) matching HEADER-NAME-REGEXP
for the message in the current-buffer.    The result will be a string that is
mime-encoded.  The optional argument CLUMP-SEP, if present, should be
a string, which can be used as a separator to concatenate the fields
of multiple header lines which might match HEADER-NAME-REGEXP.

This function is a variant of `vm-get-header-contents'."
  (let ((contents nil)
        (text-of-message 0)
        (regexp (concat "^\\(" header-name-regexp "\\)")))
    (save-excursion
      (goto-char (point-min))
      (if (re-search-forward 
	   (concat "^\\(" (regexp-quote mail-header-separator) "\\)$")
	   (point-max) t)
          (setq text-of-message (match-end 0))
        (error "No mail header separator found!"))

      (goto-char (point-min))
      (let ((case-fold-search t))
        (while (and (or (null contents) clump-sep)
                    (re-search-forward regexp text-of-message t)
                    (save-excursion (goto-char (match-beginning 0))
                                    (vm-match-header)))
          (if contents
              (setq contents
                    (concat contents clump-sep (vm-matched-header-contents)))
            (setq contents (vm-matched-header-contents)))))
      contents)))

(defvar vm-dont-ask-coding-system-question nil)

(cond ((and (fboundp 'select-message-coding-system)
	    (not (fboundp 'vm-old-select-message-coding-system)))
       (fset 'vm-old-select-message-coding-system
	     (symbol-function 'select-message-coding-system))
       (defun select-message-coding-system (&rest ignored)
	 (if vm-dont-ask-coding-system-question
	     nil
	   (apply 'vm-old-select-message-coding-system ignored)))))

(defvar select-safe-coding-system-function)

(defvar coding-system-for-write)
(defvar mail-send-nonascii)

(defvar vm-call-process-region-original nil
  "`call-process-region' as it was before the send stood in for it.
`vm-mail-send' binds this to the definition it is replacing, so the stand-in
can hand back the calls it does not implement.  Calling
`call-process-region' by name from inside the stand-in would reach the
stand-in again.")

(defun vm-call-process-region-interruptibly (start end program
						   &optional delete buffer
						   display &rest args)
  "Run PROGRAM on the region as `call-process-region' does, and let C-g out.
`call-process-region' stops the whole of Emacs while it waits: no timer
runs, nothing reads the keyboard, and so a C-g is not ignored but never
seen.  A mailer waiting on a server that has stopped answering can then only
be got out of with a signal sent from outside Emacs (emacs-vm/vm#842).  This
runs PROGRAM under `make-process' and waits with `accept-process-output',
which leaves Emacs able to see the C-g; it kills PROGRAM when it does and
says that the message may have gone out anyway.

The arguments are `call-process-region's and so is the value: the exit
status of PROGRAM, or the signal that killed it.  DISPLAY is ignored, output
being inserted as it arrives whatever it says.  A BUFFER of 0 and the
two-element BUFFER that sends standard error to a file both go to
`vm-call-process-region-original', the first having no wait to interrupt and
the second no counterpart here."
  (if (or (eq buffer 0) (consp buffer))
      (apply (or vm-call-process-region-original #'call-process-region)
	     start end program delete buffer display args)
    (let ((input (buffer-substring-no-properties start end))
	  (process (vm-start-process-on-input
		    program args (if (eq buffer t) (current-buffer) buffer))))
      (when delete
	(delete-region start end))
      (unwind-protect
	  (condition-case nil
	      (progn
		(vm-send-input-to-process process input)
		(vm-wait-for-process process)
		(vm-process-exit-value process))
	    (quit (vm-abandon-send process program)))
	(when (process-live-p process)
	  (delete-process process))))))

(defun vm-start-process-on-input (program args buffer)
  "Start PROGRAM with ARGS, ready to be sent its standard input.
Its output is inserted before point in BUFFER, which is where
`call-process-region' puts it rather than at the end where a process filter
would; BUFFER nil discards it.  The sentinel is set because the default one
writes a line of its own into the process buffer, which
`call-process-region' does not do; what it is told is kept for
`vm-process-exit-value' to read."
  (let ((out (and buffer (get-buffer-create buffer)))
	(process nil))
    (setq process (make-process
		   :name (file-name-nondirectory program)
		   :command (cons program args)
		   :connection-type 'pipe
		   :noquery t
		   :filter (and out (lambda (_process text)
				      (with-current-buffer out
					(insert text))))))
    (set-process-sentinel process
			  (lambda (p event) (process-put p 'vm-death event)))
    process))

(defun vm-send-input-to-process (process input)
  "Give PROCESS its standard input, INPUT, a piece at a time.
A mailer that refuses the message and exits before it has read all of it
leaves nothing to write to.  `call-process-region' never meets that, having
handed the program a file to read; writing to a pipe that has gone is an
error, and in a batch Emacs a SIGPIPE that kills it outright.  So this stops
as soon as the program has, and the exit status of the program is what
answers the send, which is what answered it before."
  (let ((start 0)
	(end (length input))
	(sending t))
    (while (and sending (< start end))
      (let ((stop (min end (+ start 8192))))
	(if (vm-write-to-process process (substring input start stop))
	    (setq start stop)
	  (setq sending nil)))
      ;; reaps a program that has exited, so the next turn stops
      (accept-process-output process 0))
    (vm-write-to-process process nil)))

(defun vm-write-to-process (process text)
  "Write TEXT to PROCESS, or close its standard input where TEXT is nil.
Answers nil where the program has stopped reading, which is not an error
here: see `vm-send-input-to-process'."
  (condition-case nil
      (progn (if text
		 (process-send-string process text)
	       (process-send-eof process))
	     t)
    (error nil)))

(defun vm-wait-for-process (process)
  "Wait for PROCESS to finish, leaving Emacs able to see a C-g.
Other processes are left where they are while it waits, as
`call-process-region' leaves them: their output is read once the wait is
over."
  (while (or (accept-process-output process 0.2 nil t)
	     (process-live-p process))))

(defun vm-process-exit-value (process)
  "What `call-process-region' would have answered for the finished PROCESS.
A number is an exit status.  A string names the signal that killed the
program, which is what `call-process-region' answers for one; the sentinel
is told it in lower case and that function capitalises it, so this does
too."
  (if (eq (process-status process) 'signal)
      (upcase-initials
       (string-trim (or (process-get process 'vm-death) "killed")))
    (process-exit-status process)))

(defun vm-abandon-send (process program)
  "Kill PROCESS after a C-g, and say what stopping it did not undo."
  (delete-process process)
  (error (concat "%s was interrupted.  It may have handed the message to the"
		 " server already: check where the message went before"
		 " sending it again")
	 (file-name-nondirectory program)))

;;;###autoload
(defun vm-mail-send ()
  "Just like mail-send except that VM flags the appropriate message(s)
as replied to, forwarded, etc, if appropriate."
  (interactive)
  (if vm-mail-check-recipient-format
      (vm-check-recipient-format))
  ;; protect value of this-command from minibuffer read
  (let ((this-command this-command))
    (when (and vm-confirm-mail-send
	       (not (y-or-n-p "Send the message? ")))
      (error "Message not sent.")))
  (vm-mail-mode-show-headers)
  (when vm-check-recipients
    (vm-mail-check-recipients))
  (when vm-check-bcc-removal
    (vm-mail-check-bcc-removal))
  (when vm-check-for-empty-subject
    (vm-mail-check-for-empty-subject))
  (save-excursion (run-hooks 'vm-mail-send-hook))
  ;; A header carrying anything outside US-ASCII has to be encoded whatever
  ;; the body is done with, so this is not conditional on
  ;; `vm-send-using-mime': without it an 8-bit Subject went out raw when
  ;; MIME was off.  `vm-mime-encode-composition' calls it again below and
  ;; finds nothing left to do, the first pass having left pure ASCII.
  (vm-mime-encode-headers)
  (vm-mail-mode-insert-date-maybe)
  (vm-mail-mode-insert-message-id-maybe)
  ;; send mail using MIME if user requests it and if the buffer
  ;; has not already been MIME encoded.
  (when (and vm-send-using-mime
	     (null (vm-mail-mode-get-header-contents "MIME-Version:")))
    ;; Guarded, or a copy filed before this point is filed again here: the
    ;; encrypting commands file the unencoded copy when they encode, which is
    ;; before any of this runs (emacs-vm/vm#784).
    (when (and vm-do-fcc-before-mime-encode (not vm-fcc-filed))
      (vm-do-fcc-before-mime-encode))
    (vm-mime-encode-composition))
  (when vm-mail-reorder-message-headers
    (vm-reorder-message-headers
     nil :keep-list vm-mail-header-order :discard-regexp 'none))
  ;; this to prevent Emacs 19 from asking whether a message that
  ;; has already been sent should be sent again.  VM renames mail
  ;; buffers after the message has been sent, so the user should
  ;; already know that the message has been sent.
  (set-buffer-modified-p t)
  (let ((composition-buffer (current-buffer))
	;; preserve these in case the composition buffer gets
	;; killed.
	(vm-reply-list vm-reply-list)
	(vm-forward-list vm-forward-list)
	(vm-redistribute-list vm-redistribute-list))
    ;; fragment message using message/partial if it is too big.
    (if (and vm-send-using-mime
	     (integerp vm-mime-max-message-size)
	     (> (buffer-size) vm-mime-max-message-size))
	(let (list)
	  (setq list (vm-mime-fragment-composition vm-mime-max-message-size))
	  (while list
	    (with-current-buffer (car list)
	      (vm-mail-send)
	      (kill-buffer (car list)))
	    (setq list (cdr list)))
	  ;; what mail-send would have done
	  (set-buffer-modified-p nil))
      ;; don't want a buffer change to occur here
      ;; save-excursion to be sure.
      ;;
      ;; also protect value of this-command from minibuffer reads
      (let ((this-command this-command)
	    ;; set up coding-system-for-write so that FCC uses
	    ;; the correct coding system to save the message into
	    ;; a folder.
	    (coding-system-for-write
	     (if (stringp mail-archive-file-name)
		 (vm-get-file-line-ending-coding-system
		  mail-archive-file-name)
	       (and (boundp 'coding-system-for-write)
		    coding-system-for-write)))
	    ;; For Emacs 21.
	    (mail-send-nonascii t)
	    (sendmail-coding-system (vm-binary-coding-system))
	    (vm-dont-ask-coding-system-question t)
	    (select-safe-coding-system-function nil))
	;; File the copy ourselves, unless it went already because
	;; `vm-do-fcc-before-mime-encode' is set.
	(unless vm-fcc-filed
	  (vm-do-fcc-in-composition))
	;; An IMAP-FCC header names a mailbox on the account the composition
	;; came from, and VM files that copy too.  Until this it was done
	;; only by `vm-imap-save-composition' on `mail-send-hook', which the
	;; reader had to add by hand (emacs-vm/vm#68).  Anyone who added it
	;; still has it, and finds nothing to do: the header is removed here,
	;; before `mail-send' runs the hook, so no second copy is filed.
	(when (vm-mail-mode-get-header-contents "IMAP-FCC:")
	  (vm-imap-save-composition))
	;; `mail-send' would file it again, through `mail-do-fcc', which
	;; writes one format whatever the folder is -- see `vm-do-fcc'.  For
	;; the length of the send it does the one part of its job still worth
	;; doing: taking the Fcc headers out of the copy that goes out, which
	;; is the only thing that does that, and which is why it cannot simply
	;; be turned off.  The composition itself is left alone.
	;;
	;; `call-process-region' is stood in for so that a mailer which stops
	;; answering can be got out of with a C-g: the real one blocks the
	;; whole of Emacs, keyboard included (emacs-vm/vm#842).  It is the
	;; call `sendmail-send-it' makes, and any other sender that runs a
	;; program.
	(save-excursion
	  (let ((vm-call-process-region-original
		 (symbol-function 'call-process-region)))
	    (cl-letf (((symbol-function 'mail-do-fcc) #'vm-fcc-strip-headers)
		      ((symbol-function 'call-process-region)
		       #'vm-call-process-region-interruptibly))
	      (mail-send))))))
    ;; be careful, something could have killed the composition
    ;; buffer inside mail-send.
    ;; The copies of this send are filed, so the next one is to file its own.
    ;; Cleared here and not at the start of the send: `vm-epg-encrypt' and its
    ;; kind file the unencoded copy when they encode, which is before any of
    ;; this runs, and a flag cleared at the start threw that away and filed a
    ;; second copy of the encrypted message (emacs-vm/vm#784).  The buffer is
    ;; kept after a send, so it must be cleared somewhere: a flag left set
    ;; would mean a message edited and sent again was filed nowhere.
    (setq vm-fcc-filed nil)
    (when (eq (current-buffer) composition-buffer)
      (cond ((eq vm-system-state 'replying)
	     (vm-mail-mark-replied))
	    ((eq vm-system-state 'forwarding)
	     (vm-mail-mark-forwarded))
	    ((eq vm-system-state 'redistributing)
	     (vm-mail-mark-redistributed)))
      (vm-rename-current-mail-buffer)
      (vm-keep-mail-buffer (current-buffer)))
    (vm-display nil nil '(vm-mail-send) '(vm-mail-send))))

;;; Filing a copy of what we send

;; `mail-do-fcc' in sendmail.el writes one format whatever the folder is: a
;; `From ' line of its own devising, `\nFrom ' quoted to `>From ' always --
;; its own comment says "this isn't really quoting" -- and never a
;; `Content-Length'.  So an Fcc into a `mboxcl2' folder
;; appends a message the byte counts do not describe, and the folder stops
;; reading back the way it was written, silently.  VM does it itself.
;;                                                              Issue #597.

(defvar vm-fcc-filed nil
  "Whether the Fcc copies have been filed during the send now under way.
Buffer-local, and cleared by `vm-mail-send' at the end of each send.  It
exists only to stop the copy being filed twice within one send:
`vm-do-fcc-before-mime-encode' files it before the message is encoded, and
`vm-mail-send' files it otherwise.

At the end and not at the start, because the encrypting commands file their
copy as they encode, which is before the send begins: a flag cleared at the
start threw that away and a second copy went to the folder
(emacs-vm/vm#784).  It must not outlive the send.  VM keeps the composition
buffer, so a flag left set would mean a message edited and sent again was
filed nowhere.")
(make-variable-buffer-local 'vm-fcc-filed)

(defun vm-fcc-strip-headers (header-end)
  "Delete the Fcc headers before HEADER-END, returning the folders they named.
Used on the copy of the message that goes out, where an Fcc header has no
business being -- it names a folder on this machine -- and on the copy that
is filed, which does not need to say where it was filed."
  (let ((folders nil)
	(case-fold-search t))
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward "^Fcc:[ \t]*" header-end t)
	(push (buffer-substring-no-properties
	       (point)
	       (progn (end-of-line) (skip-chars-backward " \t") (point)))
	      folders)
	(delete-region (match-beginning 0) (progn (forward-line 1) (point)))))
    (nreverse folders)))

(defun vm-fcc-folders (header-end)
  "Return the folders named by the Fcc headers before HEADER-END.
The composition is not touched: the headers stay where they are, so the
buffer VM leaves you with still says where the copy went, and editing it and
sending again files it again."
  (let ((folders nil)
	(case-fold-search t))
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward "^Fcc:[ \t]*" header-end t)
	(push (buffer-substring-no-properties
	       (point)
	       (progn (end-of-line) (skip-chars-backward " \t") (point)))
	      folders)))
    (nreverse folders)))

(defun vm-fcc-leading-separator (type)
  "The envelope line to file a copy of the message in this buffer under.
Named after the address the message is from, and dated from its own Date
header, so that filing the same message twice records when it was sent both
times -- which matters for a composition postponed and sent days later.

The message struct the other separator callers have does not exist here: the
composition is not in a folder, so the headers are read from the buffer.  A
composition may not carry a From header at all, since the MTA will add one,
and then the copy is filed under `user-mail-address' -- it is a copy of your
own outgoing mail, and you are its sender."
  (if (not (memq type '(From_ mboxcl2 BellFrom_)))
      (vm-leading-message-separator type)
    (let ((end (save-excursion (goto-char (point-min))
			       (if (re-search-forward "\n\n" nil t)
				   (point) (point-max)))))
      (vm-From_-separator
       (or (vm-From_-address (vm-fcc-header-contents "From" end))
	   (vm-From_-address user-mail-address))
       (vm-fcc-header-contents "Date" end)))))

(defun vm-fcc-header-contents (name end)
  "The contents of header NAME in the headers before END, or nil."
  (save-excursion
    (goto-char (point-min))
    (let ((case-fold-search t))
      (when (re-search-forward (concat "^" (regexp-quote name) ": *\\(.*\\)$")
			       end t)
	(match-string 1)))))

(defun vm-fcc-message-text (type)
  "The message in the current buffer, ready to append to a folder of TYPE.
The Fcc headers come off first: the copy does not need to say where it was
filed, and the composition keeps its own."
  (let ((mailbuf (current-buffer)))
    (with-temp-buffer
      (insert-buffer-substring mailbuf)
      (vm-fcc-strip-headers (point-max))
      (vm-message-text-for-folder type))))

(defun vm-message-text-for-folder (type)
  "The message in the current buffer, ready to append to a folder of TYPE.
That means: quoted the way TYPE wants it quoted and not otherwise, wrapped
in TYPE's separators, and carrying a `Content-Length' where TYPE asks for
one.  Neither a composition nor the message in a .eml file has been through
any of that.

The envelope line names the address the message is from and carries its own
Date, which is why this reads the headers rather than taking a message
struct: the caller has none.  See `vm-fcc-leading-separator'."
  (let ((mailbuf (current-buffer)))
    (with-temp-buffer
      (insert-buffer-substring mailbuf)
      (vm-munge-message-separators type (point-min) (point-max))
      ;; A message written into a folder ends with a newline.  The trailing
      ;; separator then makes the blank line the next leading separator has
      ;; to follow, and the separators of the other types begin at the start
      ;; of a line.  A composition need not end with one, and this filed it
      ;; as it stood, so two messages read back as one (#783).  Done before
      ;; the count below, which has to describe what is written.
      (goto-char (point-max))
      (unless (bolp) (insert "\n"))
      (goto-char (point-min))
      (progn
	(concat (vm-fcc-leading-separator type)
		(or (vm-content-length-header-line type) "")
		(buffer-substring-no-properties (point-min) (point-max))
		(vm-trailing-message-separator type))))))

(defun vm-fcc-write (folder)
  "Append the message in the current buffer to FOLDER, in FOLDER's own format.
A folder VM is visiting is appended to in its buffer, so that the copy shows
up without a revert; any other folder is appended to on disk.

A folder that does not exist yet is created, and one created as mboxcl2 is
created under a name that says so.  See `vm-new-folder-file-name' (#767)."
  (setq folder (vm-new-folder-file-name folder))
  (let* ((type (or (vm-get-folder-type folder)
		   (vm-folder-type-for-name folder)
		   vm-default-folder-type
		   'From_))
	 (folder-buffer (vm-get-file-buffer folder))
	 (attributes (file-attributes folder))
	 (text (vm-fcc-message-text type)))
    (when (eq type 'unknown)
      (error "Not filing in %s: VM does not recognize its folder type" folder))
    (if folder-buffer
	(with-current-buffer folder-buffer
	  (vm-error-if-folder-read-only)
	  (let ((buffer-read-only nil))
	    (save-restriction
	      (widen)
	      (goto-char (point-max))
	      (insert text)
	      (when (eq major-mode 'vm-mode)
		(vm-increment vm-messages-not-on-disk)
		(vm-clear-modification-flag-undos)
		(vm-check-for-killed-summary)
		(vm-assimilate-new-messages)
		(vm-update-summary-and-mode-line)))))
      (when (or (null attributes) (zerop (file-attribute-size attributes)))
	(vm-write-string folder (vm-folder-header type)))
      (vm-write-string folder text))))

(defun vm-fcc-write-imap (spec)
  "Append the message in the current buffer to the IMAP mailbox SPEC names.
The manual has always said an Fcc header may name \"the maildrop
specification of a folder on an IMAP server\", and until this it was taken
as a file name like any other -- so an Fcc of
\"imap:mail.example.com:143:inbox:login:user:*\" wrote a file of that name
in the default directory and put the sent copy in it (issue #605).

The session is opened for this one message and closed again, since a
composition has no folder whose session it could borrow."
  ;; `vm-imap-spec-fields' and not `vm-imap-parse-spec-to-list', which drops
  ;; an empty field: a maildrop with no mailbox read its `login' as the
  ;; mailbox and nothing said so (emacs-vm/vm#822).
  (let ((mailbox (nth 3 (vm-imap-spec-fields spec)))
	(string (vm-imap-subst-CRLF-for-LF
		 (buffer-substring-no-properties (point-min) (point-max)))))
    (when (or (null mailbox) (equal mailbox ""))
      (error "Not filing in %s: no mailbox in the maildrop specification" spec))
    ;; On the driver: sending a message should not stop Emacs while a copy
    ;; of it goes to a server.
    (vm-imap-net-append-text spec mailbox string)))

(defun vm-do-fcc (header-end)
  "File a copy of this composition in each folder its Fcc headers name.
HEADER-END is a marker at the end of the header section.  Each folder is
written in its own format; see `vm-fcc-write'."
  ;; Expanded only so that `~' works, as it did when `write-region' was
  ;; handed the name.  Deliberately not resolved against
  ;; `vm-folder-directory': an Fcc header has never meant that, and making
  ;; it mean that would move where existing configurations file their mail.
  (dolist (folder (vm-fcc-folders header-end))
    (if (vm-imap-folder-spec-p folder)
	(vm-fcc-write-imap folder)
      (vm-fcc-write (expand-file-name folder))))
  (setq vm-fcc-filed t))

(defun vm-do-fcc-in-composition ()
  "Carry out this composition's Fcc headers, if it still has any.
The header separator is what stands where a message has a blank line, so it
is taken out for the copy and put back afterwards."
  (save-excursion
    (goto-char (point-min))
    (when (re-search-forward
	   (concat "^\\(" (regexp-quote mail-header-separator) "\\)$")
	   nil t)
      (delete-region (match-beginning 0) (match-end 0))
      (let ((header-end (point-marker)))
	(unwind-protect
	    (vm-do-fcc header-end)
	  (goto-char header-end)
	  (insert mail-header-separator)
	  (set-marker header-end nil))))))

(defun vm-do-fcc-before-mime-encode ()
  "The name says it all.
Sometimes you may want to save a message unencoded, specifically not to waste
storage for attachments which are stored on disk anyway."
  (interactive)
  (vm-do-fcc-in-composition))
(put 'vm-do-fcc-before-mime-encode 'vm-called-by-vm t)

;;;###autoload
(defun vm-mail-mode-get-header-contents (header-name-regexp)
  (let (regexp)
    (setq regexp (concat "^\\(" header-name-regexp "\\)\\|\\(^"
			 (regexp-quote mail-header-separator) "$\\)"))
    (save-excursion
      (save-restriction
	(widen)
	(goto-char (point-min))
	(let ((case-fold-search t))
	  (if (and (re-search-forward regexp nil t)
		   (match-beginning 1)
		   (progn (goto-char (match-beginning 0))
			  (vm-match-header)))
	      (vm-matched-header-contents)
	    nil ))))))

(defun vm-mail-mode-remove-header (header-name-regexp)
  (let (regexp)
    (setq regexp (concat "^\\(" header-name-regexp "\\)\\|\\(^"
			 (regexp-quote mail-header-separator) "$\\)"))
    (save-excursion
      (save-restriction
	(widen)
	(goto-char (point-min))
	(let ((case-fold-search t))
	  (if (and (re-search-forward regexp nil t)
		   (match-beginning 1)
		   (progn (goto-char (match-beginning 0))
			  (vm-match-header)))
	      (delete-region (vm-matched-header-start) (vm-matched-header-end))
	    nil ))))))

(defun vm-rename-current-mail-buffer ()
  (if vm-rename-current-buffer-function
      (funcall vm-rename-current-buffer-function)
    (let ((case-fold-search nil))
      (if (not (string-match "^sent " (buffer-name)))
	  (let (prefix name n)
	    (if (not (string-match "^mail to \\?" (buffer-name)))
		(setq prefix (format "sent %s" (buffer-name)))
	      (let (recipients)
		(cond ((not (zerop (length (setq recipients
						 (mail-fetch-field "To"))))))
		      ((not (zerop (length (setq recipients
						 (mail-fetch-field "Cc"))))))
		      ((not (zerop (length (setq recipients
						 (mail-fetch-field "Bcc"))))))
					; can't happen?!?
		      (t (setq recipients "the horse with no name")))
		(setq prefix (format "sent mail to %s" recipients))))
	    (if (> (length prefix) 44)
		(setq prefix (concat (substring prefix 0 40) " ...")))
	    (setq name prefix n 2)
	    (if (equal name (buffer-name))
		t ; do nothing
	      (while (get-buffer name)
		(setq name (format "%s<%d>" prefix n))
		(vm-increment n))
	      (rename-buffer name)))))))

(defun vm-mail-mark-replied ()
  (save-excursion
    (let ((mp vm-reply-list))
      (while mp
	(if (null (buffer-name (vm-buffer-of (car mp))))
	    ()
	  (set-buffer (vm-buffer-of (car mp)))
	  (cond ((and (memq (car mp) vm-message-list)
		      (null (vm-replied-flag (car mp))))
		 (vm-set-replied-flag (car mp) t))))
	(setq mp (cdr mp)))
      (vm-update-summary-and-mode-line))))

(defun vm-mail-mark-forwarded ()
  (save-excursion
    (let ((mp vm-forward-list))
      (while mp
	(if (null (buffer-name (vm-buffer-of (car mp))))
	    ()
	  (set-buffer (vm-buffer-of (car mp)))
	  (cond ((and (memq (car mp) vm-message-list)
		      (null (vm-forwarded-flag (car mp))))
		 (vm-set-forwarded-flag (car mp) t))))
	(setq mp (cdr mp)))
      (vm-update-summary-and-mode-line))))

(defun vm-mail-mark-redistributed ()
  (save-excursion
    (let ((mp vm-redistribute-list))
      (while mp
	(if (null (buffer-name (vm-buffer-of (car mp))))
	    ()
	  (set-buffer (vm-buffer-of (car mp)))
	  (cond ((and (memq (car mp) vm-message-list)
		      (null (vm-redistributed-flag (car mp))))
		 (vm-set-redistributed-flag (car mp) t))))
	(setq mp (cdr mp)))
      (vm-update-summary-and-mode-line))))

;;;###autoload
(defun vm-reply (count)
  "Reply to the sender of the current message.
Numeric prefix argument N means to reply to the current message plus the
next N-1 messages.  A negative N means reply to the current message and
the previous N-1 messages.

If invoked on marked messages (via `vm-next-command-uses-marks'),
all marked messages will be replied to.

You will be placed into a standard Emacs Mail mode buffer to compose and
send your message.  See the documentation for the function `mail' for
more info.

Note that the normal binding of C-c C-y in the reply buffer is
automatically changed to `vm-yank-message' during a reply.  This
allows you to yank any message from the current folder into a
reply.

Normal VM commands may be accessed in the reply buffer by prefixing them
with C-c C-v."
  (interactive "p")
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((vm-enable-thread-operations nil))
    (vm-do-reply nil nil count)))

;;;###autoload
(defun vm-reply-include-text (count)
  "Reply to the sender (only) of the current message and include text
from the message.  See the documentation for function vm-reply for details."
  (interactive "p")
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((vm-enable-thread-operations nil))
    (vm-do-reply nil t count)))

;;;###autoload
(defun vm-followup (count)
  "Reply to all recipients of the current message.
See the documentation for the function vm-reply for details."
  (interactive "p")
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((vm-enable-thread-operations nil))
    (vm-do-reply t nil count)))

;;;###autoload
(defun vm-followup-include-text (count)
  "Reply to all recipients of the current message and include text from
the message.  See the documentation for the function vm-reply for details."
  (interactive "p")
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((vm-enable-thread-operations nil))
    (vm-do-reply t t count)))

;;;###autoload
(defun vm-forward-message-all-headers ()
  "Like `vm-forward-message' but forwards all the headers."
  (interactive)
  (let ((vm-forwarded-headers nil)
	(vm-unforwarded-header-regexp "only-drop-this-header")
	;; set these because vm-forward-message calls vm-send-digest
	;; if there is more than one message to be forwarded.
	(vm-rfc934-digest-headers nil)
	(vm-rfc934-digest-discard-header-regexp "only-drop-this-header")
	(vm-rfc1153-digest-headers nil)
	(vm-rfc1153-digest-discard-header-regexp "only-drop-this-header")
	(vm-mime-digest-headers nil)
	(vm-mime-digest-discard-header-regexp "only-drop-this-header"))
    (vm-forward-message)))

;;;###autoload
(defun vm-forward-message-plain ()
  "Forward the current message in plain text to one or more
recipients.  You will be placed in a Mail mode buffer as you
would with a reply, but you must fill in the \"To:\" header and
perhaps the \"Subject:\" header manually.

Any MIME attachments in the forwarded message will be attached
to the outgoing message.

See `vm-forward-message' for other forms of forwarding."
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((vm-forwarded-headers vm-forwarded-headers-plain)
	(vm-unforwarded-header-regexp vm-unforwarded-header-regexp-plain))
    (vm-forward-message t (vm-select-operable-messages
			   1 (vm-interactive-p) "Forward"))))

;;;###autoload
(defun vm-forward-message (&optional plain mlist)
  "Forward the current message to one or more recipients.
You will be placed in a Mail mode buffer as you would with a
reply, but you must fill in the \"To:\" header and perhaps the
\"Subject:\" header manually.

See `vm-forward-message-plain' for forwarding messages in plain text."
  ;; The optional argument PLAIN says that the forwarding should be
  ;; done as plain text, irrespective of the value of
  ;; `vm-forwarding-digest-type'.
  ;; The optional argument MLIST is the list of messages to be
  ;; forwarded. 
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((miming (and vm-send-using-mime
		     (not plain)
		     (equal vm-forwarding-digest-type "mime")))
	reply-buffer
	header-end)
    (unless mlist
	(setq mlist (vm-select-operable-messages
		     1 (vm-interactive-p) "Forward")))
    (if (cdr mlist)
	;; multiple message forwarding
	(progn
	  (let ((vm-digest-send-type (if plain nil
				       vm-forwarding-digest-type)))
	    (vm-send-digest nil mlist)))
      ;; single message forwarding
      (vm-retrieve-operable-messages 1 mlist :fail t)
      (save-restriction
	(widen)
	(vm-mail-internal
	 :buffer-name (format "forward of %s's note re: %s"
			      (vm-su-full-name (car vm-message-pointer))
			      (vm-su-subject (car vm-message-pointer)))
	 :subject (when vm-forwarding-subject-format
		    (let ((vm-summary-uninteresting-senders nil))
		      (vm-summary-sprintf vm-forwarding-subject-format
					  (car mlist)))))
	(make-local-variable 'vm-forward-list)
	(setq vm-system-state 'forwarding
	      vm-forward-list mlist)
	;; current-buffer is now the reply buffer
	(if miming
	    (progn
	      (setq reply-buffer (current-buffer))
	      (set-buffer (vm-make-work-buffer "*vm-forward-buffer*"))
	      (setq header-end (point))
	      (insert "\n"))
	  (goto-char (point-min))
	  (re-search-forward (concat "^" (regexp-quote mail-header-separator)
				     "\n"))
	  (goto-char (match-end 0))
	  (setq header-end (match-beginning 0)))
	(cond ((or plain (null vm-forwarding-digest-type))
	       (vm-no-frills-encapsulate-message
	       	(car mlist) 
	       	(append vm-forwarded-headers vm-forwarded-mime-headers)
	       	vm-unforwarded-header-regexp))
	      ((equal vm-forwarding-digest-type "mime")
	       (vm-mime-encapsulate-messages 
		mlist
		;; :keep-list nil :discard-regexp "none" 
		:keep-list vm-forwarded-headers  
		:discard-regexp vm-unforwarded-header-regexp
		:always-use-digest nil)
	       (goto-char header-end)
	       (insert "MIME-Version: 1.0\n")
	       (insert "Content-Type: message/rfc822\n")
	       (insert "Content-Transfer-Encoding: "
		       (vm-mime-encapsulation-transfer-encoding (point)
							       (point-max))
		       "\n")
	       (insert "Content-Description: forwarded message\n")
	       ;; eight bit chars will get \201 prepended if we
	       ;; don't do this.
	       (set-buffer-multibyte t))	; is this safe?
	      ((equal vm-forwarding-digest-type "rfc934")
	       (vm-rfc934-encapsulate-messages
		vm-forward-list 
		(append vm-forwarded-headers vm-forwarded-mime-headers)
		vm-unforwarded-header-regexp))
	      ((equal vm-forwarding-digest-type "rfc1153")
	       (vm-rfc1153-encapsulate-messages
		vm-forward-list 
		(append vm-forwarded-headers vm-forwarded-mime-headers)
		vm-unforwarded-header-regexp)))
	(when miming
	  (let ((work-buffer (current-buffer)))
	    (set-buffer reply-buffer)	; intended buffer change
	    (mail-text)
	    (vm-attach-object work-buffer
			      :type "message/rfc822" :params nil 
			      :disposition '("inline")
			      :description "forwarded message" :mimed t)
	    (add-hook 'kill-buffer-hook
		      `(lambda ()
			 (if (eq ,reply-buffer (current-buffer))
			     (kill-buffer ,work-buffer)))
		      )))
	(mail-position-on-field "To"))
      (run-hooks 'vm-forward-message-hook)
      (vm-mail-mode-apply-options)
      (run-hooks 'vm-mail-mode-hook))))

;;;###autoload
(defun vm-resend-bounced-message ()
  "Extract the original text from a bounced message and resend it.
You will be placed in a Mail mode buffer with the extracted message and
you can change the recipient address before resending the message."
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((b (current-buffer)) start
	(layout (vm-mm-layout (car vm-message-pointer)))
	(lim (vm-text-end-of (car vm-message-pointer))))
    ;; We only want to select one message here
    (vm-retrieve-operable-messages 1 (list (car vm-message-pointer))
				   :fail t)
    (save-restriction
      (widen)
      ;; if the mailer message has the original message as a MIME
      ;; attachment, then set layout to the attachment.
      ;; otherwise find the body of the message heuristically.
      (if (or (not (vectorp layout))
	      (not (setq layout (vm-mime-layout-contains-type
				 layout "message/rfc822"))))
	  (save-excursion
	    (goto-char (vm-text-of (car vm-message-pointer)))
	    (let ((case-fold-search t))
	      ;; What a wonderful world it would be if mailers
	      ;; used a single message encapsulation standard
	      ;; instead of all the weird variants. It is
	      ;; useless to try to cover them all.  This simple
	      ;; rule should cover the sanest of the formats
	      (if (not (re-search-forward "^Received:" lim t))
		  (error "This doesn't look like a bounced message."))
	      (beginning-of-line)
	      (setq start (point)))))
      ;; briefly nullify vm-mail-header-from to keep vm-mail-internal
      ;; from inserting another From header.
      (let ((vm-mail-header-from nil))
	(vm-mail-internal
	 :buffer-name (format "retry of bounce from %s"
			      (vm-su-from (car vm-message-pointer)))))
      (goto-char (point-min))
      (if (vectorp layout)
	  ;; attachment message
	  (progn
	    (setq start (point))
	    (vm-mime-insert-mime-body layout)
	    (vm-mime-transfer-decode-region layout start (point)))
	;; plain text message
	(insert-buffer-substring b start lim))
      (delete-region (point) (point-max))
      (goto-char (point-min))
      ;; delete all but pertinent headers
      (vm-reorder-message-headers
       nil :keep-list nil :discard-regexp "\\(X-VM-\\|Status:\\|Sender:\\)")
      (vm-reorder-message-headers 
       nil :keep-list vm-resend-bounced-headers
       :discard-regexp vm-resend-bounced-discard-header-regexp)
      (if (search-forward "\n\n" nil t)
	  (replace-match "")
	(goto-char (point-max)))
      (insert ?\n mail-header-separator ?\n)
      (goto-char (point-min))
      (if vm-mail-header-from
	  (insert "Resent-From: " vm-mail-header-from ?\n))
      (if (vm-mail-mode-get-header-contents "Resent-To:")
	  (mail-position-on-field "Resent-To")
	(insert "Resent-To: \n")
	(forward-char -1))))
  (run-hooks 'vm-resend-bounced-message-hook)
  (vm-mail-mode-apply-options)
  (run-hooks 'vm-mail-mode-hook))
;;;###autoload (autoload 'vm-retry-bounced-message "vm-reply" nil t)
(defalias 'vm-retry-bounced-message 'vm-resend-bounced-message)

;;;###autoload
(defun vm-resend-message ()
  "Resend the current message to someone else.
The current message will be copied to a Mail mode buffer and you
can edit the message and send it as usual.

NOTE: since you are doing a resend, a Resent-To header is provided
for you to fill in the new recipient list.  If you don't fill in
this header, what happens when you send the message is undefined.
You may also create a Resent-Cc header."
  (interactive)
  (vm-follow-summary-cursor)
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (save-restriction
    (widen)
    (let ((b (current-buffer))
	  (vmp vm-message-pointer)
	  (start (vm-headers-of (car vm-message-pointer)))
	  (lim (vm-text-end-of (car vm-message-pointer))))
      ;; We only want to select one message here
      (vm-retrieve-operable-messages 1 (list (car vm-message-pointer))
				     :fail t)
      ;; briefly nullify vm-mail-header-from to keep vm-mail-internal
      ;; from inserting another From header.
      (let ((vm-mail-header-from nil))
	(vm-mail-internal
	 :buffer-name (format "resend of %s's note re: %s"
			      (vm-su-full-name (car vm-message-pointer))
			      (vm-su-subject (car vm-message-pointer)))))
      (goto-char (point-min))
      (insert-buffer-substring b start lim)
      (delete-region (point) (point-max))
      (goto-char (point-min))
      (if vm-mail-header-from
	  (insert "Resent-From: " vm-mail-header-from ?\n))
      (insert "Resent-To: \n")
      (if mail-self-blind
	  (insert "Bcc: "
		  (if (stringp user-mail-address)
		      user-mail-address
		    (user-login-name))
		  ?\n))
      (if mail-archive-file-name
	  (insert "FCC: " mail-archive-file-name ?\n))
      ;; delete all but pertinent headers
      (vm-reorder-message-headers
       nil :keep-list nil :discard-regexp "\\(X-VM-\\|Status:\\|Sender:\\)")
      (vm-reorder-message-headers 
       nil :keep-list vm-resend-headers
       :discard-regexp vm-resend-discard-header-regexp)
      (if (search-forward "\n\n" nil t)
	  (replace-match ""))
      (insert ?\n mail-header-separator ?\n)
      (goto-char (point-min))
      (mail-position-on-field "Resent-To")
      (make-local-variable 'vm-redistribute-list)
      (setq vm-system-state 'redistributing
	    vm-redistribute-list (list (car vmp)))
      (run-hooks 'vm-resend-message-hook)
      (vm-mail-mode-apply-options)
      (run-hooks 'vm-mail-mode-hook))))

;;;###autoload
(defun vm-send-digest (&optional prefix mlist)
  "Send a digest of all messages in the current folder to recipients.
The type of the digest is specified by the variable `vm-digest-send-type'.
You will be placed in a Mail mode buffer as is usual with replies, but you
must fill in the \"To:\" and \"Subject:\" headers manually.

Prefix arg means to insert a list of preamble lines at the beginning of
the digest.  One line is generated for each message being digestified.
The variable `vm-digest-preamble-format' determines the format of the
preamble lines.

If invoked on marked messages (via `vm-next-command-uses-marks'),
only marked messages will be put into the digest.  If applied to
collapsed threads in summary and thread operations are enabled via
`vm-enable-thread-operations' then all messages in the thread are
included in the digest."
  (interactive "P")
  (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
  (let ((miming (and vm-send-using-mime (equal vm-digest-send-type "mime")))
	mp mail-buffer work-buffer ;; b
	start header-end boundary) ;; ms
    (unless mlist
      ;; prefix arg doesn't have "normal" meaning here, so only call
      ;; vm-select-operable-messages for marks or threads.
      (setq mlist (vm-select-operable-messages 
		   1 (vm-interactive-p) "Send as digest")))
    ;; if messages were selected use them, otherwise the whole folder
    (cond ((cdr mlist)
	   (vm-retrieve-operable-messages 1 mlist :fail t))
	  ((not (y-or-n-p "Send the entire folder as a digest? "))
	   (error "aborted"))
	  ((vm-find vm-message-list
		    (lambda (m) (vm-body-to-be-retrieved-of m)))
	   (error "Headers-only external messages present in the folder"))
	  (t
	   (setq mlist vm-message-list)))
    (save-restriction
      (widen)
      (vm-mail-internal
       :buffer-name (format "digest from %s" (buffer-name))
       :subject (and vm-forwarding-subject-format
		     (let ((vm-summary-uninteresting-senders nil))
		       (concat (vm-summary-sprintf 
				vm-forwarding-subject-format (car mlist))
			       (if (cdr mlist)
				   (format " [and %d more messages]"
					   (length (cdr mlist))))))))
      ;; current buffer is mail-buffer
      (setq mail-buffer (current-buffer))
      (make-local-variable 'vm-forward-list)
      (setq vm-system-state 'forwarding
	    vm-forward-list mlist)
      (if miming
	  (progn
	    ;; buffer is changed for only the mime case
	    (setq work-buffer (vm-make-work-buffer "*vm-digest-buffer*"))
	    (set-buffer work-buffer)
	    (setq header-end (point))
	    (insert "\n")
	    (setq start (point-marker)))
	(goto-char (point-min))
	(re-search-forward (concat "^" (regexp-quote mail-header-separator)
				   "\n"))
	(goto-char (match-end 0))
	(setq start (point-marker)
	      header-end (match-beginning 0)))
      (vm-inform 5 "Building %s digest..." vm-digest-send-type)
      (cond ((equal vm-digest-send-type "mime")
	     (setq boundary 
		   (vm-mime-encapsulate-messages
		    mlist :keep-list vm-mime-digest-headers
		    :discard-regexp vm-mime-digest-discard-header-regexp
		    :always-use-digest t))
	     (goto-char header-end)
	     (insert "MIME-Version: 1.0\n")
	     (insert (if vm-mime-avoid-folding-content-type
			 "Content-Type: multipart/digest; boundary=\""
		       "Content-Type: multipart/digest;\n\tboundary=\"")
		     boundary "\"\n")
	     (insert "Content-Transfer-Encoding: "
		     (vm-mime-encapsulation-transfer-encoding (point)
							     (point-max))
		     "\n"))
	    ((equal vm-digest-send-type "rfc934")
	     (vm-rfc934-encapsulate-messages
	      mlist vm-rfc934-digest-headers
	      vm-rfc934-digest-discard-header-regexp))
	    ((equal vm-digest-send-type "rfc1153")
	     (vm-rfc1153-encapsulate-messages
	      mlist vm-rfc1153-digest-headers
	      vm-rfc1153-digest-discard-header-regexp))
            ((equal vm-digest-send-type nil)
             ;; Walked with `dolist', not by cutting `mlist' down: the
             ;; preamble below reads `mlist' after this, and an arm that
             ;; consumed it left every nil-type digest with no preamble at
             ;; all (emacs-vm/vm#804).
             (dolist (m mlist)
               (vm-no-frills-encapsulate-message
                m
		(append vm-forwarded-headers vm-forwarded-mime-headers)
                vm-unforwarded-header-regexp) ; nil?
	       (insert "\n"))))

      (goto-char start)
      (setq mp mlist)
      (when miming
	;; restore buffer in the mime case
	(set-buffer mail-buffer)
	(mail-text)
	(save-excursion
	  (vm-attach-object work-buffer
				 :type "multipart/digest" 
				 :params (list (concat "boundary=\"" 
						       boundary "\"")) 
				 :disposition '("inline")
				 :description "forwarded messages" :mimed t)
	  (add-hook 'kill-buffer-hook
		    `(lambda ()
		       (if (eq (current-buffer) ,mail-buffer)
			   (kill-buffer ,work-buffer))))))
      (when prefix
	(vm-inform 6 "Building digest preamble...")
	(while mp
	  (let ((vm-summary-uninteresting-senders nil))
	    (insert (vm-summary-sprintf vm-digest-preamble-format
					(car mp))
		    "\n"))
	  (if vm-digest-center-preamble
	      (progn
		(forward-char -1)
		(center-line)
		(forward-char 1)))
	  (setq mp (cdr mp))))
      (mail-position-on-field "To")
      (vm-inform 5 "Building %s digest... done" vm-digest-send-type)))
  (run-hooks 'vm-send-digest-hook)
  (vm-mail-mode-apply-options)
  (run-hooks 'vm-mail-mode-hook))

;;;###autoload
(defun vm-send-rfc934-digest (&optional preamble)
  "Like vm-send-digest but always sends an RFC 934 digest."
  (interactive "P")
  (let ((vm-digest-send-type "rfc934"))
    (vm-send-digest preamble)))

;;;###autoload
(defun vm-send-rfc1153-digest (&optional preamble)
  "Like vm-send-digest but always sends an RFC 1153 digest."
  (interactive "P")
  (let ((vm-digest-send-type "rfc1153"))
    (vm-send-digest preamble)))

;;;###autoload
(defun vm-send-mime-digest (&optional preamble)
  "Like vm-send-digest but always sends an MIME (multipart/digest) digest."
  (interactive "P")
  (let ((vm-digest-send-type "mime"))
    (vm-send-digest preamble)))

;;;###autoload
(defun vm-continue-composing-message (&optional not-picky)
  "Find and select the most recently used mail composition buffer.
If the selected buffer is already a Mail mode buffer then it is
buried before beginning the search.  Non Mail mode buffers and
unmodified Mail buffers are skipped.  Prefix arg means unmodified
Mail mode buffers are not skipped.  If no suitable buffer is
found, the current buffer remains selected."
  (interactive "P")
  (if (eq major-mode 'mail-mode)
      (vm-bury-buffer (current-buffer)))
  (let ((b (vm-find-composition-buffer not-picky)))
    (if (not (or (null b) (eq b (current-buffer))))
	(progn
	  ;; avoid having the window configuration code choose a
	  ;; different composition buffer.
	  (vm-unbury-buffer b)
	  (set-buffer b)
	  (if (and vm-mutable-frame-configuration vm-frame-per-composition
		   (vm-multiple-frames-possible-p)
		   ;; only pop up a frame if there's an undisplay
		   ;; hook in place to make the frame go away.
		   vm-undisplay-buffer-hook)
	      (let ((w (vm-get-buffer-window b)))
		(if (null w)
		    (vm-goto-new-frame 'composition)
		  (select-window w)
		  (and vm-warp-mouse-to-new-frame
		       (vm-warp-mouse-to-frame-maybe (vm-window-frame w))))
		;; need to do this here too, since XEmacs has per
		;; frame buffer lists.
		(vm-unbury-buffer b)
		(vm-set-hooks-for-frame-deletion)))
	  (vm-display b t '(vm-continue-composing-message)
		      '(vm-continue-composing-message composing-message)))
      (vm-inform 5 "No composition buffers found"))))

;;;###autoload
(defun vm-mail-to-mailto-url (url)
  "Creates a message composition buffer to send mail to the URL.  This
command can be invoked from external agents via an emacsclient."
  (interactive "s")
  (vm-session-initialization)
  (vm-check-for-killed-folder)
  (vm-select-folder-buffer-if-possible)
  (vm-check-for-killed-summary)
  (let ((list (vm-parse url "^mailto:\\([^?]*\\)\\??\\|\\([^&]+\\)&?"
			'(1 2)))
	to subject in-reply-to cc references newsgroups body
	tem header value header-list)
    (setq to (car list)
	  to (vm-url-decode-string to)
	  list (cdr list))
    (while list
      (setq tem (vm-parse (car list) "\\([^=]+\\)=?"))
      (if (null (nth 1 tem))
	  nil
	(setq header (downcase (vm-url-decode-string (car tem)))
	      value (vm-url-decode-string (nth 1 tem)))
	(if (member header '("subject" "in-reply-to" "cc"
			     "references" "newsgroups" "body"))
	    ;; set the variable let-bound above
	    (setf (pcase header
	           ("subject"     subject)
	           ("in-reply-to" in-reply-to)
	           ("cc"          cc)
		   ("references"  references)
		   ("newsgroups"  newsgroups)
		   ("body"        body))
		  value)
	  ;; we'll insert the header later
	  (setq header-list (cons header (cons value header-list)))))
      (setq list (cdr list)))
    (vm-mail-internal :to to :subject subject :in-reply-to in-reply-to
		      :cc cc :references references :newsgroups newsgroups)
    (save-excursion
      (goto-char (point-min))
      (while header-list
	(insert (car header-list) ": ")
	(capitalize-region (point) (save-excursion (beginning-of-line) (point)))
	(insert (nth 1 header-list) "\n")
	(setq header-list (nthcdr 2 header-list)))
      (if (null body)
	  nil
	(mail-text)
	(save-excursion (insert body "\n"))
	;; CRLF to LF for line breaks in the body
	(while (search-forward "\r\n" nil t)
	  (replace-match "\n"))))
    (run-hooks 'vm-mail-hook)
    (vm-mail-mode-apply-options)
    (run-hooks 'vm-mail-mode-hook)))

;; external variables
(defvar mail-mode-map)
(defvar mail-aliases)
(defvar mail-default-reply-to)
(defvar mail-signature-file)
(defvar mail-personal-alias-file)

(defun vm-sanitize-buffer-name (buffer-name)
  "Replace chars matching `vm-drop-buffer-name-chars' by an \"_\"."
  (let ((r vm-drop-buffer-name-chars))
    (when buffer-name
      (if r
          (setq buffer-name (vm-replace-in-string buffer-name r "_" t)))
      (if (>= (length buffer-name) vm-buffer-name-limit)
          (setq buffer-name 
		(concat (substring buffer-name 0 (-  vm-buffer-name-limit 4))
			"...")))))
  buffer-name)

(defvar vm-compositions-exist nil)
(defvar vm-composition-buffer-count 0
  "The current number of composition buffers.")

(defvar vm-ml-composition-buffer-count ""
  "The modeline string displayed for the current number of composition
buffers.") 

(defvar dnd-protocol-alist)

(defun vm-update-ml-composition-buffer-count ()
   (setq vm-ml-composition-buffer-count
         (format "%d composition%s" vm-composition-buffer-count
                 (if (= vm-composition-buffer-count 1) "" "s"))))

(defun vm-forget-composition-buffer ()
  (setq vm-composition-buffer-count (- vm-composition-buffer-count 1))
  (setq vm-compositions-exist (> vm-composition-buffer-count 0))
  (vm-update-ml-composition-buffer-count))

(declare-function vm-save-killed-message-hook "vm-postpone" ())
(declare-function vm-remove-save-killed-message-hook "vm-postpone" ())

(defvar vm-composition-headers-vm-wrote nil
  "This composition\\='s headers as VM wrote them, or nil where VM did not say.
Set once the composition is ready for the writer, `mail-setup-hook' included,
so that `vm-composition-headers-changed-p' can tell a header the writer typed
from one they were handed.")
(make-variable-buffer-local 'vm-composition-headers-vm-wrote)

(defun vm-composition-header-text ()
  "This composition\\='s headers, as text, or nil where it has no separator."
  (save-excursion
    (goto-char (point-min))
    (and (re-search-forward
          (concat "^" (regexp-quote mail-header-separator) "$") nil t)
         (buffer-substring-no-properties (point-min) (match-beginning 0)))))

(defun vm-composition-has-body-p ()
  "Whether anything but whitespace follows `mail-header-separator' here."
  (save-excursion
    (goto-char (point-min))
    (and (re-search-forward
          (concat "^" (regexp-quote mail-header-separator) "$") nil t)
         (re-search-forward "[^ \t\n]" nil t))))

(defun vm-composition-headers-changed-p ()
  "Whether this composition\\='s headers differ from the ones VM wrote.
Nil where VM did not record them, which is a composition VM did not make."
  (and vm-composition-headers-vm-wrote
       (not (equal (vm-composition-header-text)
                   vm-composition-headers-vm-wrote))))

(defun vm-composition-worth-keeping-p (&optional buffer)
  "Whether BUFFER holds a composition with anything in it.
A composition begun and abandoned untouched is not worth a question, still
less a draft in the postponed folder.

Modified is not enough on its own: VM writes the headers itself, so a
composition is modified from the moment it appears.  What says the writer has
written something is text after `mail-header-separator', or a header they
changed from the one VM handed them: a recipient and a subject typed with the
body still empty were writing, and were killed silently (emacs-vm/vm#856)."
  (with-current-buffer (or buffer (current-buffer))
    (and (buffer-modified-p)
         (or (vm-composition-has-body-p)
             (vm-composition-headers-changed-p)))))

(defcustom vm-confirm-killing-a-composition t
  "*Whether VM asks before a composition with writing in it is killed.

A composition buffer belongs to no file, so Emacs kills it without the
question it asks about an unsaved file: `kill-buffer' and everything bound to
it, `kill-this-buffer' included, took an unsent reply with no warning
(emacs-vm/vm#824).  Nil restores that.

The question is not asked for a composition nothing has been written in, nor
for one that has been sent."
  :group 'vm-compose
  :type 'boolean)

(defvar vm-save-killed-message)

(defun vm-composition-kill-buffer-saves-it-p ()
  "Whether killing this composition will keep it as a draft.

`vm-save-killed-message-hook' on the local `kill-buffer-hook' is what keeps
it, and `vm-save-killed-message' says whether it keeps, asks, or does neither.
Where it will speak for itself there is nothing to ask first, and
`vm-postpone-unfinished-compositions' kills a composition for the express
purpose of reaching it.

The hook is autoloaded, so vm-postpone.el may not be loaded when this runs:
query functions run before `kill-buffer-hook' does.  It is loaded here rather
than guessing, since the answer turns on an option defined there and the kill
about to happen would load it a moment later anyway."
  (and (memq 'vm-save-killed-message-hook kill-buffer-hook)
       (progn (require 'vm-postpone) vm-save-killed-message)
       t))

(defun vm-composition-kill-buffer-query ()
  "Ask before this composition is killed with writing in it.
On `kill-buffer-query-functions' in a composition buffer; answering no leaves
the buffer alone.  See `vm-confirm-killing-a-composition'."
  (or (not vm-confirm-killing-a-composition)
      (not (vm-composition-worth-keeping-p))
      (vm-composition-kill-buffer-saves-it-p)
      (yes-or-no-p
       (format "%s has writing in it and has not been sent; kill it? "
	       (buffer-name)))))

(defun vm-new-composition-buffer ()
  (setq vm-composition-buffer-count (+ 1 vm-composition-buffer-count))
  (setq vm-compositions-exist t)
  (add-hook 'kill-buffer-hook 'vm-forget-composition-buffer nil t)
  (add-hook 'vm-mail-send-hook 'vm-forget-composition-buffer nil t)
  ;; Killing this composition keeps what is written in it, as
  ;; `vm-save-killed-message' says to.  Every composition, rather than only
  ;; those made while `vm-postpone-mode' is on: a reader who had not switched
  ;; that on lost the writing to any key bound to `kill-buffer'
  ;; (emacs-vm/vm#824).  Taken off again when the message is sent or postponed,
  ;; there being nothing to keep then.
  (add-hook 'kill-buffer-hook #'vm-save-killed-message-hook nil t)
  (add-hook 'mail-send-hook #'vm-remove-save-killed-message-hook nil t)
  (add-hook 'vm-postpone-message-hook #'vm-remove-save-killed-message-hook
	    nil t)
  ;; And a question where nothing will be kept.  On the query hook rather than
  ;; `kill-buffer-hook': that one runs after the decision is made and cannot
  ;; stop the kill.
  (add-hook 'kill-buffer-query-functions #'vm-composition-kill-buffer-query
	    nil t)
  (vm-update-ml-composition-buffer-count))

;;;###autoload
(defun vm-select-recipient-from-sender-if-possible (&optional use-sender)
  "Select a recipient's address from the current message's sender, if
possible and appropriate.

The optional argument USE-SENDER may be nil, in which case the
variable `vm-mail-use-sender-address' determines whether the sender
address is used."
  (when (and (or use-sender vm-mail-use-sender-address)
	     (memq major-mode '(vm-mode vm-virtual-mode
					vm-summary-mode vm-presentation-mode)))
    (vm-select-folder-buffer)
    ;; "if possible" includes there being a message to take the sender from:
    ;; an empty folder has none, and reading a header out of nil is an error
    ;; rather than an absent recipient (issue #514).
    (when vm-message-pointer
      (vm-get-header-contents (car vm-message-pointer) "From:"))))


(defun vm-mail-mode-parent-keymap ()
  "Give `vm-mail-mode-map' the bindings of `mail-mode-map' as well.
VM's composition keymap holds only VM's own bindings, and Mail mode's have to
remain reachable behind them.

This used to be done with

    (nconc vm-mail-mode-map mail-mode-map)

on GNU Emacs, `set-keymap-parents' being XEmacs's.  That works, in that
`keymap-parent' afterwards is `mail-mode-map' -- the splice makes VM's keymap
literally end in it -- but it is destructive, and doing it a second time walks
to the end of the spliced list, which is now inside `mail-mode-map', and points
that cell back at `mail-mode-map' itself.  A circular keymap: `lookup-key' on it
does not return, and Emacs dies of a stack overflow.  Nothing but a global flag
stood between VM and corrupting one of Emacs's own keymaps.

`set-keymap-parent' does the same job without touching the parent, and, being
what parenting actually means, can be repeated harmlessly.  It has been in GNU
Emacs throughout the range of versions VM supports."
  (set-keymap-parent vm-mail-mode-map mail-mode-map))

;;;###autoload
(defvar vm-said-pcrisis-is-off nil
  "Whether this session has said that Personality Crisis is switched off.
Once is enough: the reader is composing, and a line repeated at every
composition is one they learn to read past.")

(defun vm-say-if-pcrisis-is-off ()
  "Say once that Personality Crisis has rules and is switched off.

Only where vm-pcrisis.el has not been loaded.  `vm-pcrisis-warn-if-off' says
it at every composition and is the one to hear, but it reaches
`vm-mail-mode-hook' as that file loads, so a reader who set the rule
variables in their init and never loaded it is told nothing by anything.
That is the quiet half of emacs-vm/vm#561, and this is why the check names
the variables rather than reading them through the file.

Once, unlike that one: a reader in this state has no vm-pcrisis loaded to
repeat it, and the line is about their init file rather than about the
message in front of them."
  (when (and (not vm-said-pcrisis-is-off)
             (not (featurep 'vm-pcrisis))
             (vm-pcrisis-configured-but-off-p))
    (setq vm-said-pcrisis-is-off t)
    (vm-warn 0 2 (concat "Personality Crisis has rules and is switched off,"
                         " so none of them ran.  Add (vm-pcrisis-mode 1) to"
                         " your init file"))))

(cl-defun vm-mail-internal (&key buffer-name to guessed-to subject
			       in-reply-to cc references newsgroups)
    "Create a message buffer and set it up according to args.
Fills in the headers as given by the arguments.
Binds the `vm-mail-mode-map' and hooks"
  (let ((folder-buffer nil))
    (when (memq major-mode '(vm-mode vm-virtual-mode))
      (setq folder-buffer (current-buffer)))
    (setq buffer-name (if buffer-name
                          (vm-decode-mime-encoded-words-in-string buffer-name)
                        "mail to ?"))
    (setq buffer-name (vm-sanitize-buffer-name buffer-name))
    (set-buffer (generate-new-buffer buffer-name))
    ;; FSF Emacs: try to prevent write-region (called to handle FCC) from
    ;; asking the user to choose a safe coding system.
    (set-buffer-file-coding-system 'raw-text)
    ;; Avoid trying to write auto-save files in potentially unwritable
    ;; directories.  This is the composition's directory from here on: the
    ;; commands that start one used to put the folder's own directory back
    ;; afterwards, which for an IMAP folder is its local cache, and anything
    ;; that recomputed the auto-save name then wrote there (emacs-vm/vm#666).
    (setq default-directory 
	  (or vm-mail-auto-save-directory vm-folder-directory 
	      (expand-file-name "~/")))
    (auto-save-mode (if auto-save-default 1 -1))
    (mail-mode)
    ;; TM infests mail mode, uninfest it if VM's MIME stuff is in
    ;; use.
    (when vm-send-using-mime
      (vm-mail-mode-remove-tm-hooks))
    (use-local-map vm-mail-mode-map)
    (vm-mail-mode-parent-keymap)
    (when (boundp 'dnd-protocol-alist)
      (set (make-local-variable 'dnd-protocol-alist)
	   (append vm-dnd-protocol-alist dnd-protocol-alist)))
    (setq vm-mail-buffer folder-buffer
	  mode-popup-menu (and vm-use-menus
			       (vm-menu-support-possible-p)
			       (vm-menu-mode-menu)))
    (and vm-use-menus (vm-menu-support-possible-p)
	 (vm-menu-install-mail-mode-menu))
    ;; Mail aliases, from ~/.mailrc through mailalias.el, as Emacs's own
    ;; `mail-setup' does it.  `sendmail-sync-aliases' first, so that a file
    ;; edited during this Emacs session is read again rather than being
    ;; whatever it said when the first composition was made
    ;; (emacs-vm/vm#820); it sets `mail-aliases' back to t when the
    ;; modification time has moved.
    ;;
    ;; A reader who would rather see the address than the alias in the
    ;; composition puts `mail-abbrevs-setup' on `vm-mail-mode-hook'.  Both
    ;; read the same file; see Composing setup in the VM manual.
    (vm-say-if-pcrisis-is-off)
    (sendmail-sync-aliases)
    (when (eq mail-aliases t)
      (setq mail-aliases nil)
      (when (file-exists-p (or mail-personal-alias-file "~/.mailrc"))
	(build-mail-aliases)))
    (cond
     ((stringp vm-mail-header-from)
      (insert "From: " vm-mail-header-from "\n"))
     (mail-setup-with-from
      ;; What Emacs's own `mail-setup' does with that variable, which
      ;; defaults to t, and VM did not: a composition with no From header is
      ;; filed by Fcc and by IMAP-FCC without one, the copy being made before
      ;; the send puts it in, so the copy in a Sent folder named no sender at
      ;; all (emacs-vm/vm#832).  `mail-insert-from-field' is the function
      ;; `sendmail-send-it' would have used, so what goes to the recipient is
      ;; the same header either way, and `mail-setup-with-from' set to nil is
      ;; the Emacs way of asking for neither.
      (mail-insert-from-field)))
    (setq to (if to 
		 (vm-decode-mime-encoded-words-in-string to))
	  guessed-to (if guessed-to 
			 (vm-decode-mime-encoded-words-in-string guessed-to))
	  subject (if subject 
		      (vm-decode-mime-encoded-words-in-string subject))
	  cc (if cc 
		 (vm-decode-mime-encoded-words-in-string cc)))
    (insert "To: " (or to guessed-to "") "\n")
    (and cc (insert "Cc: " cc "\n"))
    (insert "Subject: " (or subject "") "\n")
    (and newsgroups (insert "Newsgroups: " newsgroups "\n"))
    (and in-reply-to (insert "In-Reply-To: " in-reply-to "\n"))
    (and references (insert "References: " references "\n"))
    (insert "X-Mailer: VM " (vm-version) " under "
	    (vm-emacs-name-and-version))
    (if (boundp 'system-configuration)
	(insert " (" system-configuration ")"))
    (insert "\n")
    ;; REPLYTO environmental variable support
    ;; note that in FSF Emacs v19.29 we would initialize if the
    ;; value was t.  nil is the trigger value used now.
    (and (eq mail-default-reply-to nil)
	 (setq mail-default-reply-to (getenv "REPLYTO")))
    (when mail-default-reply-to
      (insert "Reply-To: " mail-default-reply-to "\n"))
    (when mail-self-blind
      (insert "Bcc: "
	      (if (stringp user-mail-address)
		  user-mail-address
		(user-login-name))
	      ?\n))
    (when mail-archive-file-name
      (insert "FCC: " mail-archive-file-name "\n"))
    (when mail-default-headers
      (insert mail-default-headers))
    (unless (= (preceding-char) ?\n)
      (insert ?\n))
    (insert mail-header-separator "\n")
    (condition-case err
	(when mail-signature
	  (save-excursion
	    (save-restriction
	      (narrow-to-region (point) (point))
	      (cond ((stringp mail-signature)
		     (insert mail-signature))
		    ((eq mail-signature t)
		     (insert-file-contents 
		      (or (and (boundp 'mail-signature-file)
			       (stringp mail-signature-file)
			       mail-signature-file)
			  "~/.signature")))
		    (t
		     (let ((str (eval mail-signature)))
		       (if (stringp str)
			   (insert str)))))
	      (goto-char (point-min))
	      (if (looking-at "\n*-- \n")
		  nil
		(insert "\n-- \n"))
	      (goto-char (point-max)))))
      (error (vm-warn 1 2 "Could not read signature file: %s" (cdr err))))
    ;; move this buffer to the head of the buffer list so window
    ;; config stuff will select it as the composition buffer.
    (vm-unbury-buffer (current-buffer))
    ;; make a new frame if the user wants it.
    (when (and vm-mutable-frame-configuration vm-frame-per-composition
	       (vm-multiple-frames-possible-p))
      (vm-goto-new-frame 'composition)
      (vm-set-hooks-for-frame-deletion))
    ;; now do window configuration
    (vm-display (current-buffer) t
		'(vm-mail
		  vm-mail-other-frame
		  vm-mail-other-window
		  vm-reply
		  vm-reply-other-frame
		  vm-reply-include-text
		  vm-reply-include-text-other-frame
		  vm-followup
		  vm-followup-other-frame
		  vm-followup-include-text
		  vm-followup-include-text-other-frame
		  vm-send-digest
		  vm-send-digest-other-frame
		  vm-send-rfc934-digest
		  vm-send-rfc934-digest-other-frame
		  vm-send-rfc1153-digest
		  vm-send-rfc1153-digest-other-frame
		  vm-send-mime-digest
		  vm-send-mime-digest-other-frame
		  vm-forward-message
		  vm-forward-message-other-frame
		  vm-forward-message-all-headers
		  vm-forward-message-all-headers-other-frame
		  vm-resend-message
		  vm-resend-message-other-frame
		  vm-resend-bounced-message
		  vm-resend-bounced-message-other-frame)
		(list this-command 'composing-message))
    (cond ((null to)
	   (mail-position-on-field "To" t))
	  ((null subject)
	   (mail-position-on-field "Subject" t)))
    (unless vm-update-composition-buffer-name-timer
      (setq vm-update-composition-buffer-name-timer
	    (run-with-idle-timer
	     1.5 t 'vm-update-composition-buffer-name)))
    (vm-new-composition-buffer)
    (run-hooks 'mail-setup-hook)
    ;; Now that the composition is the writer's, what its headers say is what
    ;; VM said.  After the hook, which may add a header of its own.
    (setq vm-composition-headers-vm-wrote (vm-composition-header-text))))

;;;###autoload
(defun vm-reply-other-frame (count)
  "Like vm-reply, but run in a newly created frame."
  (interactive "p")
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-reply count))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-reply-include-text-other-frame (count)
  "Like vm-reply-include-text, but run in a newly created frame."
  (interactive "p")
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-reply-include-text count))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-followup-other-frame (count)
  "Like vm-followup, but run in a newly created frame."
  (interactive "p")
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-followup count))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-followup-include-text-other-frame (count)
  "Like vm-followup-include-text, but run in a newly created frame."
  (interactive "p")
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-followup-include-text count))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-forward-message-all-headers-other-frame ()
  "Like vm-forward-message-all-headers, but run in a newly created frame."
  (interactive)
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-forward-message-all-headers))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-forward-message-other-frame ()
  "Like vm-forward-message, but run in a newly created frame."
  (interactive)
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-forward-message))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-forward-message-plain-other-frame ()
  "Like vm-forward-message-plain, but run in a newly created frame."
  (interactive)
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-forward-message-plain))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-resend-message-other-frame ()
  "Like vm-resend-message, but run in a newly created frame."
  (interactive)
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-resend-message))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-resend-bounced-message-other-frame ()
  "Like vm-resend-bounced-message, but run in a newly created frame."
  (interactive)
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-resend-bounced-message))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-send-digest-other-frame (&optional prefix)
  "Like vm-send-digest, but run in a newly created frame."
  (interactive "P")
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-send-digest prefix))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-send-rfc934-digest-other-frame (&optional prefix)
  "Like vm-send-rfc934-digest, but run in a newly created frame."
  (interactive "P")
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-send-rfc934-digest prefix))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-send-rfc1153-digest-other-frame (&optional prefix)
  "Like vm-send-rfc1153-digest, but run in a newly created frame."
  (interactive "P")
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-send-rfc1153-digest prefix))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

;;;###autoload
(defun vm-send-mime-digest-other-frame (&optional prefix)
  "Like vm-send-mime-digest, but run in a newly created frame."
  (interactive "P")
  (when (vm-multiple-frames-possible-p)
    (vm-goto-new-frame 'composition))
  (let ((vm-frame-per-composition nil)
	(vm-search-other-frames nil))
    (vm-send-mime-digest prefix))
  (when (vm-multiple-frames-possible-p)
    (vm-set-hooks-for-frame-deletion)))

(defvar enriched-mode)

;;;###autoload
(defun vm-preview-composition ()
  "Show how the current composition buffer might be displayed
in a MIME-aware mail reader.  VM copies and encodes the current
mail composition buffer and displays it as a mail folder.
Type `q' to quit this temp folder and return to composing your
message."
  (interactive)
  (when (not (eq major-mode 'mail-mode))
    (error "Command must be used in a VM Mail mode buffer."))
  (let ((temp-buffer nil)
	(mail-buffer (current-buffer))
	(enriched (and (boundp 'enriched-mode) enriched-mode))
	) ;; e-list
    (unwind-protect
	(progn
	  (setq temp-buffer (generate-new-buffer "composition preview"))
	  (set-buffer temp-buffer)
	  ;; so vm-mime-xxxx-encode-composition won't complain
	  (setq major-mode 'mail-mode)
	  (set (make-local-variable 'enriched-mode) enriched)
	  (vm-insert-region-from-buffer mail-buffer)
	  (goto-char (point-min))
	  (unless (vm-mail-mode-get-header-contents "From")
	    (insert "From: " (user-login-name) "\n"))
	  (unless (vm-mail-mode-get-header-contents "Message-ID")
	    (insert (format "Message-ID: <fake.%d.%d@fake.fake>\n"
			    (random 1000000) (random 1000000))))
	  (unless (vm-mail-mode-get-header-contents "Date")
	    (insert "Date: "
		    (format-time-string "%a, %d %b %Y %T %z"
					(current-time))
		    "\n"))
	  (when (and vm-send-using-mime
		     (null (vm-mail-mode-get-header-contents "MIME-Version:")))
	    (vm-mime-encode-composition))
          (when vm-mail-reorder-message-headers
	    (vm-reorder-message-headers 
	     nil :keep-list vm-mail-header-order :discard-regexp 'none))
  	  (vm-remove-mail-mode-header-separator)
	  (vm-munge-message-separators 'mmdf (point-min) (point-max))
	  (goto-char (point-min))
	  (insert (vm-leading-message-separator 'mmdf))
	  (goto-char (point-max))
	  (unless (eq (preceding-char) ?\n)
	    (insert ?\n))
	  (insert (vm-trailing-message-separator 'mmdf))
	  (set-buffer-modified-p nil)
	  ;; point of no return, don't kill it if the user quits
	  (setq temp-buffer nil)
	  (let ((vm-auto-decode-mime-messages t))
	    (save-current-buffer
	     (vm-goto-new-folder-frame-maybe 'folder)
	     (vm-mode)))
	  (vm-inform 5
	   (substitute-command-keys
	    "Type \\[vm-quit] to continue composing your message"))
	  ;; temp buffer, don't offer to save it.
	  (setq buffer-offer-save nil)
	  (vm-display (or vm-presentation-buffer (current-buffer)) t
		      (list this-command) '(vm-mode startup)))
      (when temp-buffer (kill-buffer temp-buffer)))))

(defun vm-update-composition-buffer-name ()
  (when (and (eq major-mode 'mail-mode)
	     (save-match-data (string-match "^\\(mail\\|reply\\) to "
					    (buffer-name))))
    (let ((to (mail-fetch-field "To"))
	  (cc (mail-fetch-field "Cc"))
	  (curbufname (buffer-name))
	  (deactivate-mark)
	  fmt newbufname
	  (ellipsis ""))
      (cond (vm-reply-list (setq fmt "reply to %s%s"))
	    (t (setq fmt "mail to %s%s on \"%s\"")))
      (setq to (vm-parse-addresses to)
	    cc (vm-parse-addresses cc))
      (when (or (cdr to)
                (and (car to) (car cc)))
	(setq ellipsis ", ..."))
      (setq newbufname (or (car to) (car cc) "foo (?)")
	    newbufname (funcall vm-chop-full-name-function newbufname)
	    newbufname (or (car newbufname) (car (cdr newbufname)))
	    newbufname (format fmt newbufname ellipsis
			       (mail-fetch-field "Subject")))
      (unless (equal newbufname curbufname)
	(setq newbufname (vm-sanitize-buffer-name newbufname))
	(rename-buffer newbufname t)))))

;;;###autoload
(defun vm-mail-mode-remove-tm-hooks ()
  (remove-hook 'mail-setup-hook 'turn-on-mime-edit)
  (remove-hook 'mail-setup-hook 'mime/decode-message-header)
  (remove-hook 'mail-setup-hook 'mime/editor-mode)
  (remove-hook 'mail-send-hook  'mime-edit-maybe-translate)
  (remove-hook 'mail-send-hook 'mime-editor/maybe-translate))


;;;###autoload
(defun vm-mail-mode-show-headers ()
  "Display any hidden headers in a composition buffer."
  (interactive)
  (mapc 'delete-overlay (overlays-in (point-min)
				     (save-excursion (mail-text) (point))))
  (if (local-variable-p 'line-move-ignore-invisible (current-buffer))
      (setq line-move-ignore-invisible nil)))

(make-variable-buffer-local 'line-move-ignore-invisible)

;;;###autoload
(defun vm-mail-mode-hide-headers ()
  "Hides and protects headers listed in `vm-mail-mode-hidden-headers'.
With a prefix arg, call `vm-mail-mode-show-headers' instead."
  (interactive)
  (let ((case-fold-search t)
        (header-regexp (regexp-opt vm-mail-mode-hidden-headers))
        (header-end (save-excursion (mail-text) (point)))
        start end) ;; o
    (setq header-regexp (concat "^" header-regexp))
    (setq line-move-ignore-invisible t)
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward header-regexp header-end t)
        (setq start (match-beginning 0)
              end (1- (re-search-forward "^[^ \t]" header-end)))
        (goto-char end)
        (let ((o (or (car (overlays-at start))
                     (make-overlay start end))))
          (when (not (overlay-get o 'invisible))
            (overlay-put o 'invisible t)
            (overlay-put o 'read-only t)))))))

;;;###autoload
(defun vm-dnd-attach-file (uri _action)
  "Insert a drag and drop file as a MIME attachment in a VM
composition buffer.  URI is the url of the file as described in
`dnd-protocol-alist'.  ACTION is ignored."
  (let ((file (dnd-get-local-file-name uri t))
	type)
    (unless vm-send-using-mime
      (error (concat "MIME attachments disabled, "
		     "set vm-send-using-mime non-nil to enable.")))
    (when (and file (file-regular-p file))
      (setq type (or (vm-mime-default-type-from-filename file)
		     "application/octet-stream"))
      (vm-attach-file file type))))

(defun vm-mail-mode-hide-headers-hook ()
  "Hook which handles `vm-mail-mode-hidden-headers'."
  (when vm-mail-mode-hidden-headers
    (vm-mail-mode-hide-headers)))

(add-hook 'vm-mail-mode-hook 'vm-mail-mode-hide-headers-hook)

;;; Composition helpers, from vm-rfaddons.el (issue #606)

(defun vm-mail-mode-apply-options ()
  "Apply the composition options to this buffer.
Called wherever VM sets a composition up, just before
`vm-mail-mode-hook\', so that a hook function can undo any of it."
  (when vm-clean-subject-prefixes
    (vm-mail-subject-cleanup))
  (when vm-open-line-in-quoted-text
    (vm-mail-mode-install-open-line)))



(defun vm-mail-subject-cleanup ()
  "Do some subject line clean up.
- Replace subject prefixes according to `vm-mail-subject-prefix-replacements'.
- Add a number after replies is `vm-mail-subject-number-reply' is t.

You might add this function to `vm-mail-mode-hook' in order to clean up the
Subject header."
  (interactive)
  (save-excursion
    ;; cleanup
    (goto-char (point-min))
    (re-search-forward 
     (concat "^\\(" (regexp-quote mail-header-separator) "\\)$")
     (point-max))
    (let ((case-fold-search t)
          (rpl vm-mail-subject-prefix-replacements))
      (while rpl
        (if (re-search-backward (concat "^Subject:[ \t]*" (caar rpl))
                                (point-min) t)
            (replace-match (concat "Subject: " (cdar rpl))))
        (setq rpl (cdr rpl))))

    ;; add number to replys
    (let (refs (start 0) end (count 0))
      (when (and vm-mail-subject-number-reply vm-reply-list
                 (setq refs  (vm-mail-mode-get-header-contents "References:")))
        (while (string-match "<[^<>]+>" refs start)
          (setq count (1+ count)
                start (match-end 0)))
        (when (> count 1)
          ;; the number goes inside the reply prefix, so there has to be one:
          ;; `vm-reply-subject-prefix' is nil by default, and passing that to
          ;; `regexp-quote' below signalled wrong-type-argument
          (unless vm-reply-subject-prefix
            (error (concat "vm-mail-subject-cleanup: "
                           "`vm-mail-subject-number-reply' needs "
                           "`vm-reply-subject-prefix' set to the prefix to "
                           "number, such as \"Re: \"")))
          (mail-position-on-field "Subject" t)
          (setq end (point))
          (if (re-search-backward "^Subject:" (point-min) t)
              (setq start (point))
            (error "vm-mail-subject-cleanup: no Subject header to number"))
          (goto-char start)
          (if (not (re-search-forward (regexp-quote vm-reply-subject-prefix)
                                      end t))
              (error (concat "vm-mail-subject-cleanup: the Subject header "
                             "does not begin with `vm-reply-subject-prefix' "
                             "(%s), so there is nothing to number")
                     vm-reply-subject-prefix)
            (goto-char (match-end 0))
            (skip-chars-backward ": \t")
            (insert (format "[%d]" count))))))))
(put 'vm-mail-subject-cleanup 'vm-called-by-vm t)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun vm-mail-check-recipients-strip (address)
  "Remove from ADDRESS the parts that may legitimately contain an \"@\".
That is MIME encoded words, quoted strings and RFC 5322 comments, all of
which occur alongside the address proper.  What is left should hold
exactly one address.

`vm-parse-addresses' decodes encoded words, marking what it decoded with
the `vm-string' text property, so those are removed by property; a word
still in its encoded form is removed by matching."
  (let ((start 0)
	(len (length address))
	(pieces nil)
	(stripped nil)
	(previous nil))
    ;; drop the decoded encoded words
    (while (< start len)
      (let ((end (or (next-single-property-change start 'vm-string address)
		     len)))
	(unless (get-text-property start 'vm-string address)
	  (push (substring-no-properties address start end) pieces))
	(setq start end)))
    (setq stripped
	  (vm-replace-in-string
	   (vm-replace-in-string (apply #'concat (nreverse pieces))
				 vm-mime-encoded-word-regexp "")
	   "\"[^\"]*\"" ""))
    ;; and the comments, innermost first so nested ones go too
    (while (not (equal previous stripped))
      (setq previous stripped)
      (setq stripped (vm-replace-in-string stripped "([^()]*)" "")))
    stripped))

(defun vm-mail-check-recipients ()
  "Check if the recipients are specified correctly.
Actually it checks only if there are any missing commas or the like in the
headers."
  (interactive)
  (let ((header-list '("To:" "CC:" "BCC:"
                       "Resent-To:" "Resent-CC:" "Resent-BCC:"))
        (contents nil)
        (errors nil))
    (while header-list
      (setq contents (vm-mail-mode-get-header-contents (car header-list)))
      ;; Split into addresses first, respecting quoting and comments, and
      ;; look for a second "@" within one of them.  Testing the whole
      ;; header at once cannot tell a missing comma from a display name
      ;; that contains an "@" -- an encoded word holding an address, say,
      ;; which is legal and which Exchange and Outlook both produce.
      (dolist (address (vm-parse-addresses contents))
        (let ((bare (vm-mail-check-recipients-strip address)))
          (when (string-match "@[^,]*@" bare)
            (setq errors
                  (vm-replace-in-string
                   (format
                    "vm-mail-check-recipients: Missing separator in %s \"%s\"!  "
                    (car header-list) address)
                   "[\n\t ]+" " ")))))
      (setq header-list (cdr header-list)))
    ;; "%s" matters: the message has an address interpolated into it, and
    ;; "%" is legal in a local part -- percent-hack routing uses it -- so
    ;; passing it as the format string fails with "Not enough arguments
    ;; for format string" instead of saying what is wrong.
    (if errors
        (error "%s" errors))))
(put 'vm-mail-check-recipients 'vm-called-by-vm t)


(defun vm-mail-check-bcc-removal ()
  "Ask before sending if this composition's Bcc could reach the other recipients.

A Bcc header is a promise: the addresses in it are told nothing to the people
who receive the message.  With `send-mail-function' set to
`sendmail-send-it', VM and Emacs keep the header in the message they hand
to `sendmail-program' and trust that program to take it out, because with
-t those addresses are also how it learns whom to deliver to.  When it does
not take it out, everyone on the message reads who was blind copied, and
nothing has failed anywhere that anyone can see (emacs-vm/vm#815).

Asks rather than refuses because a working sendmail, postfix or exim does
remove it, and those are a great many of the people sending mail this way.
Declining says what to change and where it is written down."
  (interactive)
  (when (and (vm-mail-mode-get-header-contents "\\(Resent-\\)?BCC:")
             (not (memq send-mail-function vm-senders-that-remove-bcc))
             (not (y-or-n-p
                   (format (concat "This message has a Bcc and %s leaves"
                                   " removing it to your mail transport;"
                                   " see Sending Options in the VM manual."
                                   "  Send anyway? ")
                           send-mail-function))))
    (error (concat "Message not sent.  Set send-mail-function to"
                   " smtpmail-send-it, which removes the Bcc itself; or take"
                   " the Bcc header out; or set vm-check-bcc-removal to nil"
                   " if you know your transport removes it.  See the node"
                   " Sending Options in the VM manual, and Sending under"
                   " Setting Up for a worked smtpmail configuration"))))
(put 'vm-mail-check-bcc-removal 'vm-called-by-vm t)

(defun vm-mail-check-for-empty-subject ()
  "Check if the subject line is empty and issue an error if so."
  (interactive)
  (let (subject)
    (setq subject (vm-mail-mode-get-header-contents "Subject:"))
    (if (or (not subject) (string-match "^[ \t]*$" subject))
        (if (not vm-mail-prompt-if-subject-empty)
            (error "Empty subject header")
          (mail-position-on-field "Subject")
          (insert (read-string "Subject: "))))))
(put 'vm-mail-check-for-empty-subject 'vm-called-by-vm t)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;###autoload
(defun vm-mail-mode-citation-clean-up ()
  "Remove doubly-cited text and extra lines in a mail message."
  (interactive)
  (save-excursion
    (mail-text)
    (let ((re-alist vm-mail-mode-citation-kill-regexp-alist)
          (pmin (point))
          re subst)

      (while re-alist
        (goto-char pmin)
        (setq re (caar re-alist)
              subst (cdar re-alist))
        (while (re-search-forward re (point-max) t)
          (replace-match subst))
        (setq re-alist (cdr re-alist))))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
(defun vm-mail-mode-install-open-line ()
  "Install the open-line hooks for VM composition buffers.
Add this to `vm-mail-mode-hook'."
  ;; these are not local even when using add-hook, so we make them local
  (add-hook 'before-change-functions 'vm-mail-mode-open-line nil t)
  (add-hook 'after-change-functions 'vm-mail-mode-open-line nil t))

(defun vm-mail-mode-open-line (start end &optional length)
  "Opens a line when inserting into the region of a reply.

Insert newlines before and after an insert where necessary and does a cleanup
of empty lines which have been quoted." 
  (if (= start end)
      (save-excursion
        (beginning-of-line)
        (setq vm-mail-mode-open-line
              (if (and (eq this-command 'self-insert-command)
                       (looking-at (concat "^"
                                           vm-mail-mode-open-line-regexp)))
                  (if (< (point) start) (point) start))))
    (if (and length (= length 0) vm-mail-mode-open-line)
        (let (start-mark end-mark)
          (save-excursion 
            (if (< vm-mail-mode-open-line start)
                (progn
                  (insert "\n\n" vm-included-text-prefix)
                  (setq end-mark (point-marker))
                  (goto-char start)
                  (setq start-mark (point-marker))
                  (insert "\n\n"))
              (if (looking-at (concat "\\("
                                      vm-mail-mode-open-line-regexp
                                      "\\)+[ \t]*\n"))
                  (replace-match ""))
              (insert "\n\n")
              (setq end-mark (point-marker))
              (goto-char start)
              (setq start-mark (point-marker))
              (insert "\n"))

            ;; clean leading and trailing garbage 
            (let ((iq (concat "^" vm-mail-mode-open-line-regexp
                              "[> \t]*\n")))
              (save-excursion
                (goto-char start-mark)
                (beginning-of-line)
                (while (looking-at "^$") (forward-line -1))
                (while (looking-at iq)
                  (replace-match "")
                  (forward-line -1))
                (goto-char end-mark)
                (beginning-of-line)
                (while (looking-at "^$") (forward-line 1))
                (while (looking-at iq)
                  (replace-match "")))))
      
          (setq vm-mail-mode-open-line nil)))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;###autoload
(defun vm-mail-mode-elide-reply-region (b e)
  "Replace marked region or current line with `vm-mail-mode-elide-reply-region'.
B and E are the beginning and end of the marked region or the current line."
  (interactive (if (mark)
                   (if (< (mark) (point))
                       (list (mark) (point))
                     (list (point) (mark)))
                 (list (save-excursion (beginning-of-line) (point))
                       (save-excursion (end-of-line) (point)))))
  (if (eobp) (insert "\n"))
  (if (mark) (delete-region b e) (delete-region b (+ 1 e)))
  (insert vm-mail-mode-elide-reply-region))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;###autoload

;;; Return receipts, from vm-rfaddons.el (issue #606)

(defun vm-handle-return-receipt ()
  "Generate a reply to the current message if it requests a return receipt
and has not been replied so far.
See the variable `vm-handle-return-receipt-mode' for customization."
  (interactive)
  (save-excursion
    (vm-select-folder-buffer-and-validate 1 (vm-interactive-p))
    (let* ((msg (car vm-message-pointer))
           (sender (vm-get-header-contents msg  "Return-Receipt-To:"))
           (mail-signature nil)
           (mode (and sender
                      (cond ((equal 'ask vm-handle-return-receipt-mode)
                             (y-or-n-p "Send a return receipt? "))
                            ((symbolp vm-handle-return-receipt-mode)
                             vm-handle-return-receipt-mode)
                            (t
                             (eval vm-handle-return-receipt-mode)))))
           (vm-mutable-frame-configuration 
	    (if (eq mode 'edit) vm-mutable-frame-configuration nil))
           (vm-mail-mode-hook nil)
           (vm-mode-hook nil)
           message)
      (when (and mode (not (vm-replied-flag msg)))
        ;; Put the reader's windows back afterwards.  The receipt is composed
        ;; and sent without their asking to see it, and `vm-reply' below
        ;; displays the composition, so the summary window was left replaced
        ;; by the presentation buffer and had to be brought back by hand
        ;; (emacs-vm/vm#800).  In `edit' mode they are shown the composition
        ;; on purpose and the display is theirs to keep, which is the
        ;; distinction `vm-mutable-frame-configuration' is bound by above.
        (let ((windows (unless (eq mode 'edit) (current-window-configuration))))
         (unwind-protect
        (progn
        (vm-reply 1)
        (vm-mail-mode-remove-header "Return-Receipt-To:")
        (vm-mail-mode-remove-header "To:")
        (goto-char (point-min))
        (insert "To: " sender "\n")
        (mail-text)
        (delete-region (point) (point-max))
        (insert 
         (format 
          "Your mail has been received on %s."
          (current-time-string)))
        ;; `save-restriction' inside the buffer switch: entered outside it,
        ;; it held the composition and left the folder widened (#780).
        (with-current-buffer (vm-buffer-of msg)
          (save-restriction
            (widen)
            (setq message
                  (buffer-substring
                   (vm-vheaders-of msg)
                   (let ((tp (+ vm-handle-return-receipt-peek
                                (marker-position
                                 (vm-text-of msg))))
                         (ep (marker-position
                              (vm-end-of msg))))
                     (if (< tp ep) tp ep))
                   ))))
        (insert "\n-----------------------------------------------------------------------------\n"
                message)
        (if (re-search-backward "^\\s-+.*" (point-min) t)
            (replace-match ""))
        (insert "[...]\n")
        (if (not (eq mode 'edit))
            (vm-mail-send-and-exit nil))
        )
           (when windows (set-window-configuration windows)))))
      )))
(put 'vm-handle-return-receipt 'vm-called-by-vm t)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(provide 'vm-reply)
;;; vm-reply.el ends here
