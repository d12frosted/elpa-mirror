;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.0snapshot0.20261007.244" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "4388b250ae85a4eafba19efbf01c720336923dac" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
