;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261126.431" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "b23eac58cb45beb69601e0bd46799e5374580185" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
