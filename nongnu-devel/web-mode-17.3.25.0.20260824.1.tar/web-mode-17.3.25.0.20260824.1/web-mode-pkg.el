;; Generated package description from web-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "web-mode" "17.3.25.0.20260824.1" "major mode for editing web templates" '((emacs "24.3.1")) :commit "e417e389474f934f4f3c11c88ad6c476642e1f90" :maintainer '("François-Xavier Bois" . "fxbois@gmail.com") :keywords '("languages") :url "https://web-mode.org")
