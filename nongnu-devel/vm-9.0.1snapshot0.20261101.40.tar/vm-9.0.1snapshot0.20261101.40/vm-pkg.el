;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261101.40" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "be44878cd5812c22f90245d82abe1fd7c493239e" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
