;; Generated package description from geiser-chicken.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "geiser-chicken" "0.17.0.20260727.7" "Chicken's implementation of the geiser protocols" '((emacs "24.4") (geiser "0.19")) :commit "46ace7bebaa2b035aa874c7a272400348df674ef" :keywords '("languages" "chicken" "scheme" "geiser") :url "https://gitlab.com/emacs-geiser/chicken")
