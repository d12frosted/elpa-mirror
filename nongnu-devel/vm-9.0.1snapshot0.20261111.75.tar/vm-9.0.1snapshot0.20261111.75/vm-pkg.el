;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261111.75" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "06f8fe41013e0ebec15022c2b78ef813e2726065" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
