;;; pinyin-isearch.el --- Pinyin mode for isearch  -*- lexical-binding: t -*-

;; Copyright (c) 2024-2026 Anoncheg

;; Maintainer: Anoncheg <vitalij@gmx.com>
;; Author: Anoncheg <vitalij@gmx.com>
;; Keywords: chinese, isearch, matching, convenience
;; URL: https://github.com/Anoncheg1/pinyin-isearch
;; Version: 1.7.2
;; Package-Requires: ((emacs "28.1"))
;; SPDX-License-Identifier: AGPL-3.0-or-later

;;; License

;; This file is not part of GNU Emacs.

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; There are two types of search: for pinyin (pīnyīn) and for Chinese
;; characters (汉字) text.
;; 查找有两种类型：一种是拼音（pīnyīn）查找，另一种是汉字（汉字）查找。

;; You can use both or select one of them.
;; 你可以同时使用两种，或者只选一种。
;; Pinyin without tones is used for input.
;; 输入时使用不带声调的拼音。
;; Input is transformed to regex expression like:
;; 输入会被转化为类似这样的正则表达式：
;; "\\([嗯唔][爱哀挨埃癌]\\|[乃奶奈耐氖艿鼐柰]\\|n\\([ūúǔùǖǘǚǜ]\\s-*e\\|ü[ēéěè]\\)\\)"

;; Based on Emacs "chinese-sisheng", "chinese-py", "chinese-punct".

;; Configuration in ~/.emacs or ~/.emacs.d/init.el:

;; (require 'pinyin-isearch)
;; (pinyin-isearch-load) ; force loading (optional) before mode

;;;; Usage:

;; M-x pinyin-isearch-mode
;; C-u C-s for normal search.
;; or
;; C-s M-s p/h/s - to activate (p)inyin or (h) Chonese characters (s)trict
;; C-s M-s F1 - to see all keys

;; Usage without activation of minor mode:
;; M-x pinyin-isearch-forward/backward
;;
;; Customization:
;;
;; M-x customize-group RET pinyin-isearch
;;
;; This package depends on Quail minor mode (input multilingual text
;; easily) and uses it's translation table (named Quail map).
;; It is possible to adopt this code to many other languages.

;; Search variants:

;; By default active search for both pinyin and chinese characters
;; with fallback to latin normal characters.

;;;; Other packages:

;; - Modern navigation in major modes https://github.com/Anoncheg1/firstly-search
;; - Ediff no 3-th window	https://github.com/Anoncheg1/ediffnw
;; - Dired history		https://github.com/Anoncheg1/dired-hist
;; - Selected window contrast	https://github.com/Anoncheg1/selected-window-contrast
;; - Copy link to clipboard	https://github.com/Anoncheg1/emacs-org-links
;; - Solution for "callback hell"	https://github.com/Anoncheg1/emacs-async1
;; - Restore buffer state	https://github.com/Anoncheg1/emacs-unmodified-buffer1
;; - outline.el usage		https://github.com/Anoncheg1/emacs-outline-it
;; - Dates for Org-mode headers	https://github.com/Anoncheg1/emacs-org-history
;; - Call LLMs and agents from Org-mode cui blocks https://github.com/Anoncheg1/emacs-cui

;;;; Donate:

;; - BTC (Bitcoin) address: 1CcDWSQ2vgqv5LxZuWaHGW52B9fkT5io25
;; - USDT (Tether) address: TVoXfYMkVYLnQZV3mGZ6GvmumuBfGsZzsN
;; - TON (Telegram) address: UQC8rjJFCHQkfdp7KmCkTZCb5dGzLFYe2TzsiZpfsnyTFt9D

;;;; Todo:

;; - ('’) in (Fāng'àn) apostrophe, syllable delimiter (隔音符号),
;; is a strict grammatical requirement used to prevent ambiguity.
;; Apostrophe use is rare, generally at word boundaries or within
;; compounds.  to prevent misreading when a syllable starting
;; with a, e, or o follows another syllable directly.  - chech that it is solved.
;; - Upperacase for pinyin.
;; - Cangjie search
;; - method for  getting pinyin for chinese characters.
;; - allow connecting other input methods.
;; - use "M-s s" key to enable strict mode
;;  for current pinuin/characrters/both modes if active

;;; Code:

;; 感人名言：1）把自己项目文件的 require 放前面，库的放后面。2）大概只有圣人才会付钱。
;;;; -=-= imports
(require 'pinyin-isearch-pinyin)
(require 'pinyin-isearch-chars)

(require 'isearch)

(declare-function pinyin-isearch-pinyin-regexp-function "pinyin-isearch-pinyin" (string &optional lax))
(declare-function pinyin-isearch-chars-regexp-function "pinyin-isearch-chars" (string &optional lax))
(declare-function pinyin-isearch-chars-strict-regexp-function "pinyin-isearch-chars" (string &optional lax))
(declare-function pinyin-isearch-chars-load "pinyin-isearch-chars")
(declare-function pinyin-isearch-pinyin-load "pinyin-isearch-pinyin")

(defgroup pinyin-isearch nil
  "Pinyin-isearch customization."
  :group 'pinyin-isearch)

;;;; -=-= vars
(defcustom pinyin-isearch-strict nil
  "Non-nil means use strict matching mode.

Strict mode behavior:
- For Chinese characters: Only search for exact character matches
- For Pinyin: Only search if first syllable matches exactly
- Fallback to Latin letters is disabled

By default we are looking for all characters and pinyin syllables that
 start with typed by user first part of syllable. Non-nil means prohibit
 adding to search all possible completion.

This is a global strictness control. Individual modes may override this.
See `pinyin-isearch-strict-both' and `pinyin-isearch-strict-characters'
for mode-specific strictness."
  :local t ; because pinyin-isearch-mode with :global nil.
  :group 'pinyin-isearch
  :type 'boolean)

(defcustom pinyin-isearch-full-fallback t
  "Non-nil means search for normal normal latin letters also.
For mandaring characters, wif non-nil we always search for full latin
 input.
For pinyin search this means we use latin symbols in regex for vowels to
 search for letters without diacritical mark tones.  If is nil and
 syllable was not found pinyin search dont look for latin string.
Used in `pinyin-isearch-chars--concat-variants'."
  :local t ; because pinyin-isearch-mode with :global nil.
  :group 'pinyin-isearch
  :type 'boolean)

(defcustom pinyin-isearch-default-mode 'both
  "Select target text in `pinyin-isearch-mode'.
Whether to search for for pinyin or for Chinese characters or for
both of them.  Used for mode `pinyin-isearch-mode', and functions
`pinyin-isearch-forward', `pinyin-isearch-backward'."
  :local t ; because pinyin-isearch-mode with :global nil.
  :group 'pinyin-isearch
  :type '(choice (const :tag "Search in both: pinyin and Chinese characters" both)
                 (const :tag "Search in Chinese characters only" characters)
                 (const :tag "Search in Chinese characters only, same as characters" t)
                 (const :tag "Search in both: pinyin and Chinese characters strictly" strict-both)
                 (const :tag "Search in Chinese characters strictly" strict-characters)
                 (const :tag "Search in pinyin only" pinyin)))

(defcustom pinyin-isearch-fix-jumping-flag t
  "Non-nil means fix isearch behavior.
When typing new character the new search begins from last
success found occurance, not from when you begin whole search.
This fix force isearch to begin from the starting point.
Disable for native isearch behavior."
  :local t ; because pinyin-isearch-mode with :global nil.
  :group 'pinyin-isearch
  :type 'boolean)

;;;; -=-= fns

(defun pinyin-isearch-both-regexp-function (string &optional _lax)
  "Concat pinyin and Chinese chars regex as alternation.
If `pinyin-isearch-strict' is non-nil, strict mode applies.
Mode-specific strict settings override global setting.
Replacement for function `isearch-regexp-function'.
Argument STRING is a query string.
Optional argument LAX for isearch special cases."
  (let* ((psr (pinyin-isearch-pinyin-regexp-function string))
         (hsr (let ((pinyin-isearch-full-fallback nil))
                (pinyin-isearch-chars-regexp-function string))))
    (cond
     ((equal hsr regexp-unmatchable) psr)
     ((equal psr regexp-unmatchable) hsr)
     ((equal psr hsr) psr)
     (t
      (concat psr "\\|" hsr))))) ; alternation branches are arbitrary strings.

(defun pinyin-isearch-both-strict-regexp-function (string &optional lax)
  "Strict variant of `pinyin-isearch-both-regexp-function'.
Argument STRING is a query string, LAX is not used."
  (let ((pinyin-isearch-strict t)
        (pinyin-isearch-chars-fallback nil)
        (pinyin-isearch-full-fallback nil))
    (pinyin-isearch-both-regexp-function string lax)))

(defun pinyin-isearch--get-regexp-function ()
  "Return regexp function based on `pinyin-isearch-default-mode'.
Those functions generate regex for isearch that used in wrapping
 functions `pinyin-isearch-forwar' and `pinyin-isearch-backward'."
  (pcase pinyin-isearch-default-mode
    ('both		#'pinyin-isearch-both-regexp-function)
    ('strict-both	#'pinyin-isearch-both-strict-regexp-function)
    ('strict-characters #'pinyin-isearch-chars-strict-regexp-function)
    ('characters	#'pinyin-isearch-chars-regexp-function)
    ('pinyin		#'pinyin-isearch-pinyin-regexp-function)
    (_ (user-error "Invalid pinyin-isearch-default-mode: %S"
                   pinyin-isearch-default-mode))))

(defun pinyin-isearch--reset-before-printing-char-advice (&rest _args)
  "Reset Isearch start point before inserting a printing character.
Prevents jumping past the original start when typing characters
during a pinyin Isearch session.
In other words, force search from original position.
In other words, when in incremental search result appear at back after
 moving forward we return backward to first one."
  (when (and pinyin-isearch-fix-jumping-flag
             ;; we check that `isearch-mode' uses our function.
             (string-prefix-p "pinyin-isearch-" (symbol-name isearch-regexp-function)))
    (goto-char isearch-opoint)
    (setq isearch-adjusted t)))

(defun pinyin-isearch-load ()
  "Load and activate modules and hooks used by all."
  (unless (and pinyin-isearch-chars--first-syllable-letters ; for speed
               pinyin-isearch-pinyin-syllable-table)
    (pinyin-isearch-chars-load) ; activate pinyin-isearch-chars
    (pinyin-isearch-pinyin-load))) ; activate pinyin-isearch-pinyin


;;;; -=-= keymap

(defun pinyin-isearch-describe-bindings ()
  "Show bindings in the current (M - s) prefix map."
  (interactive)
  (describe-keymap 'pinyin-isearch-m-s-map)
  (when isearch-mode
    (isearch-abort)))


(defvar pinyin-isearch-m-s-standard-map (lookup-key isearch-mode-map (kbd "M-s"))
  "`isearch-mode-map' (M - s) keys.")

(defvar pinyin-isearch-m-s-map
  (let ((map (make-sparse-keymap)))
    ;; Inherit all standard M-s bindings (including your toggles)
    (set-keymap-parent map pinyin-isearch-m-s-standard-map)
    ;; Add F1/C-h help
    (define-key map (kbd "<f1>") #'pinyin-isearch-describe-bindings)
    (define-key map (kbd "C-h") #'pinyin-isearch-describe-bindings)
    (define-key map (kbd "<help>") #'pinyin-isearch-describe-bindings)
    map)
  "Keys for (M - s) keys prefix.
Pressed during `pinyin-isearch-forward' or `pinyin-isearch-backward'.")


;; Use the macro to define the toggle (off/on) command and key binding
;; Add toggles globally (binds them to M-s p, M-s p, M-s h, M-s s)
;; TODO: use "s" key to enable strict mode
;; for current pinuin/characrters/both modes if active.

;; Arguments: mode key function &optional docstring &rest body
;; Create:
;; 1) isearch-toggle-MODE
;; 2) A key binding in `isearch-mode-map` to `M-s KEY`
;; 3) for FUNCTION set the `isearch-message-prefix` property and update `search-default-mode` custom type
(isearch-define-mode-toggle "pinyin-both" "n" pinyin-isearch-both-regexp-function
  "Toggle Pinyin+characters search.")

(isearch-define-mode-toggle "pinyin-only" "p" pinyin-isearch-pinyin-regexp-function
  "Toggle Pinyin-only search.")

(isearch-define-mode-toggle "characters-only" "h" pinyin-isearch-chars-regexp-function
  "Toggle characters-only search.")

(isearch-define-mode-toggle "pinyin-strict-both" "s" pinyin-isearch-both-strict-regexp-function
  "Toggle strict Pinyin+characters search.")

(isearch-define-mode-toggle "pinyin-strict-characters" "u" pinyin-isearch-chars-strict-regexp-function
  "Toggle strict characters search.")

(put #'pinyin-isearch-both-regexp-function #'isearch-message-prefix "Pinyin+both ")
(put #'pinyin-isearch-pinyin-regexp-function #'isearch-message-prefix "Pinyin-only ")
(put #'pinyin-isearch-chars-regexp-function #'isearch-message-prefix "Characters-only ")
(put #'pinyin-isearch-both-strict-regexp-function #'isearch-message-prefix "Strict both ")
(put #'pinyin-isearch-chars-strict-regexp-function #'isearch-message-prefix "Strict characters ")

(defun pinyin-isearch-setup-keymap ()
  "Extend (M - s prefix) map."
  (define-key isearch-mode-map (kbd "M-s") pinyin-isearch-m-s-map))

(defun pinyin-isearch-cleanup-keymap ()
  "Restore standard (M - s prefix) map when pinyin isearch ends."
    (define-key isearch-mode-map (kbd "M-s") pinyin-isearch-m-s-standard-map))


;;;; -=-= interface with isearch and interactives

;;;###autoload
(defun pinyin-isearch-forward (&optional regexp-p no-recursive-edit)
  "Do incremental search forward.
If called with a universal argument, falls back to standard
 function `isearch-forward'.
Optional argument REGEXP-P see original function `isearch-forward'.
Optional argument NO-RECURSIVE-EDIT see original function
 `isearch-forward'.
TODO: Issue with isearch: in incremental search if first characters was
 not found isearch continue to tell \"Failing\"."
  (interactive "P\np")
  (if current-prefix-arg
      ;; If C-u was pressed, run standard isearch
      (isearch-forward regexp-p no-recursive-edit)
    ;; else
    ;; Otherwise, run your custom pinyin isearch
    (pinyin-isearch-load) ; lazy loading
    (isearch-mode t regexp-p nil (not no-recursive-edit) (pinyin-isearch--get-regexp-function))))

;;;###autoload
(defun pinyin-isearch-backward (&optional regexp-p no-recursive-edit)
  "Do incremental search backward.
If called with a universal argument, falls back to standard
 function `isearch-backward'.
Optional argument REGEXP-P see original function `isearch-backward'.
Optional argument NO-RECURSIVE-EDIT see original function `isearch-backward'."
  (interactive "P\np")
  (if current-prefix-arg
      (isearch-backward regexp-p no-recursive-edit)
    ;; else
    (pinyin-isearch-load) ; lazy loading, for usage without minor mode
    (isearch-mode nil regexp-p nil (not no-recursive-edit) (pinyin-isearch--get-regexp-function))))


;;;; -=-= The minor mode definition
;;;###autoload
(define-minor-mode pinyin-isearch-mode
  "Replace isearch key bindings to support Pinyin searching.
Focus on functions `isearch-forward' and `isearch-backward'.
Allow with query {pinyin} to find {pīnyīn}.  \\C-\\u \\C-\\s used for
normal search.

Subcommands (after M - s key prefix):
- n - Toggle Pinyin+characters search
- p - Toggle Pinyin-only search
- h - Toggle characters-only search
- s - Toggle strict Pinyin+characters search
- u - Toggle strict characters-only search
- r - Return to standard (non-Pinyin) search

Use \\[isearch-forward] and \\[isearch-backward] for search.

The search mode is controlled by `pinyin-isearch-default-mode',
which can be customized to set the default behavior."
  :lighter " p-isearch"
  :global nil
  :group 'pinyin-isearch
  :keymap (let ((map (make-sparse-keymap)))
            ;; Bind the main search commands
            (define-key map (kbd "C-s") #'pinyin-isearch-forward)
            (define-key map (kbd "C-r") #'pinyin-isearch-backward)
            map)
  ;; Manage the hooks cleanly
  (if pinyin-isearch-mode
      (progn
        ;; Load any additional configuration
        (pinyin-isearch-load)
        ;; M-s keys
        (add-hook 'isearch-mode-hook #'pinyin-isearch-setup-keymap t t)
        (add-hook 'isearch-mode-end-hook #'pinyin-isearch-cleanup-keymap t t)
        ;; Prevents jumping
        (advice-add 'isearch-printing-char :before #'pinyin-isearch--reset-before-printing-char-advice)
        ;; Enable exntended Help system (C-s F1 F1)
        (when (fboundp 'pinyin-isearch-help-advice)
          (advice-add 'isearch-help-for-help :around #'pinyin-isearch-help-advice)))
    ;; else - Clean up when disabling the mode
    ;; M-s keys
    (remove-hook 'isearch-mode-hook #'pinyin-isearch-setup-keymap t)
    (remove-hook 'isearch-mode-end-hook #'pinyin-isearch-cleanup-keymap t)
    ;; Prevents jumping
    (advice-remove 'isearch-printing-char #'pinyin-isearch--reset-before-printing-char-advice)
    ;; help
    (when (fboundp 'pinyin-isearch-help-advice)
          (advice-remove 'isearch-help-for-help #'pinyin-isearch-help-advice))))

;;;; -=-= Help C-s M-s <f1> <f1>
;; We show help screen with when isearch with pinyin-isearch is active.
;; We show original help of isearch and inherit keys.

(eval-when-compile (require 'help-macro nil t))
;; Silence byte-compiler warnings for external symbols
(defvar isearch-help-map)
(defvar isearch--display-help-action)
(defvar pinyin-isearch-help-for-help-internal)
;; (defvar isearch-mode)
;; (defvar pinyin-isearch-mode)

;; Only define help if required infrastructure exists
(when (and (fboundp 'make-help-screen)
           (boundp 'isearch--display-help-action)
           (boundp 'isearch-help-map)
           (fboundp #'isearch-help-for-help-internal))

  (make-help-screen pinyin-isearch-help-for-help-internal
    (purecopy "Show pinyin-isearch help with key bindings and current status.")
    (concat
     "=== Pinyin-Isearch Help ===\n\n"
     "Key bindings under M-s prefix:\n"
     "  M-s n   Toggle Pinyin+characters search\n"
     "  M-s p   Toggle Pinyin-only search\n"
     "  M-s h   Toggle characters-only search\n"
     "  M-s s   Toggle strict Pinyin+characters search\n"
     "  M-s u   Toggle strict characters-only search\n"
     "  M-s r   Return to standard (non-Pinyin) search\n\n"
     "Current search mode: "
     (if (and (boundp 'isearch-regexp-function) isearch-regexp-function)
         (symbol-name isearch-regexp-function)
       "standard")
     "\n\nHelp options (press key):\n"
     "  b   Show standard Isearch key bindings\n"
     "  k   Show documentation for a specific key\n"
     "  m   Show Isearch mode documentation\n"
     "  q   Exit help")
    isearch-help-map)

  (defun pinyin-isearch-help-advice (orig-fun &rest args)
    "Show extended help when `pinyin-isearch-mode' is active.
Argument ORIG-FUN and ARGS is `isearch-help-for-help'."
    (if (and (boundp 'pinyin-isearch-mode) pinyin-isearch-mode)
        (let ((display-buffer-overriding-action isearch--display-help-action))
          (when (fboundp 'pinyin-isearch-help-for-help-internal)
            (pinyin-isearch-help-for-help-internal))
          (isearch-update))
      ;; else
      (apply orig-fun args))))

;;;; -=-= provide
(provide 'pinyin-isearch)
;;; pinyin-isearch.el ends here
