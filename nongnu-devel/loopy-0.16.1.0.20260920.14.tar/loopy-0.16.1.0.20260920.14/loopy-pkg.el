;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.16.1.0.20260920.14" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "c50c15d87709ece2bee7f45d6a6d906bb8524aac" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy")
