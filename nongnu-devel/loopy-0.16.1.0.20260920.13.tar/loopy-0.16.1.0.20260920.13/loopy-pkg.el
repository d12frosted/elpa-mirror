;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.16.1.0.20260920.13" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "8dbce3056d4bb12a325704229dab072f0c934be3" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy")
