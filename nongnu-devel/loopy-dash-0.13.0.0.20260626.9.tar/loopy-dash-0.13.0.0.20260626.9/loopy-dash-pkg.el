;; Generated package description from loopy-dash.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy-dash" "0.13.0.0.20260626.9" "Dash destructuring for `loopy'" '((emacs "28.1") (loopy "0.13.0") (dash "2.20")) :commit "d42ca0524fa564914a03708c67c61d90106ee007" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy-dash")
