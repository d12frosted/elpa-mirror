;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260717.52" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "79b0b75f71aac249f00b17d95aa63ae3ff97ef75" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
