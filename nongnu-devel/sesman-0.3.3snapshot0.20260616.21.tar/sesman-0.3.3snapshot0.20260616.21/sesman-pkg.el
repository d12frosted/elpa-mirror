;; Generated package description from sesman.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sesman" "0.3.3snapshot0.20260616.21" "Generic Session Manager" '((emacs "25")) :commit "7eb733acb33e610a53979fa7fc13393eeda3cc53" :keywords '("process") :url "https://github.com/vspinu/sesman")
