;; Generated package description from dockerfile-mode.el  -*- no-byte-compile: t -*-
(define-package "dockerfile-mode" "1.9.0.20251221.114459" "Major mode for editing Docker's Dockerfiles" '((emacs "24")) :commit "97733ce074b1252c1270fd5e8a53d178b66668ed" :keywords '("docker" "languages" "processes" "tools") :url "https://github.com/spotify/dockerfile-mode")
