;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261018.81" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "b53e5e3fe14cff97cf7a1b2240981023e1f71d70" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
