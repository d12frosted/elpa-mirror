;; Generated package description from geiser-chicken.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "geiser-chicken" "0.17.0.20260924.11" "Chicken's implementation of the geiser protocols" '((emacs "24.4") (geiser "0.19")) :commit "74610c900b671dd40c1bd7114c991781e0621102" :keywords '("languages" "chicken" "scheme" "geiser") :url "https://gitlab.com/emacs-geiser/chicken")
