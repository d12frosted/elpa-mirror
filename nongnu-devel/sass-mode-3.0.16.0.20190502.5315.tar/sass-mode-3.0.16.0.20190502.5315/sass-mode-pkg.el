;; Generated package description from sass-mode.el  -*- no-byte-compile: t -*-
(define-package "sass-mode" "3.0.16.0.20190502.5315" "Major mode for editing Sass files" '((haml-mode "3.0.15") (cl-lib "0.5")) :commit "247a0d4b509f10b28e4687cd8763492bca03599b" :keywords '("markup" "language" "css") :url "http://github.com/nex3/haml/tree/master")
