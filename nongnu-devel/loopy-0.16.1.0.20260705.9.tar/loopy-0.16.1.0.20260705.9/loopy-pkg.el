;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.16.1.0.20260705.9" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "0895cad3714a0d588f24a8bf0d16c3c6a4d15776" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy")
