;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261017.79" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "abaa3d07cc05470ec471511a3626a48d25f198fd" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
