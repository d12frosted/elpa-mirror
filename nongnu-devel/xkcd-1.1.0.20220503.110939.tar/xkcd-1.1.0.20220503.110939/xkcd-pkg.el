;; Generated package description from xkcd.el  -*- no-byte-compile: t -*-
(define-package "xkcd" "1.1.0.20220503.110939" "View xkcd from Emacs" '((json "1.3")) :commit "80011da2e7def8f65233d4e0d790ca60d287081d" :authors '(("Vibhav Pant" . "vibhavp@gmail.com")) :maintainer '("Vibhav Pant" . "vibhavp@gmail.com") :keywords '("xkcd" "webcomic") :url "https://github.com/vibhavp/emacs-xkcd")
