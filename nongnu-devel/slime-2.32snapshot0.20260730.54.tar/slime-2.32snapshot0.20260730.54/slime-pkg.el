;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260730.54" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "957f61d8b8b57c1f463b56620a274eb77a09bc16" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
