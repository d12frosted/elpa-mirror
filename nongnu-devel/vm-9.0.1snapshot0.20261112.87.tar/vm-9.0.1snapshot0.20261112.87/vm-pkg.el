;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261112.87" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "2840a34e51c81b5533f1fb1f01868d64318ebc17" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
