;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.0snapshot0.20261018.283" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "c331d01d3792c111ac168057da84b352705025cc" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
