;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260925.73" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "6bcb626f1a7e2b4f39146f6f9c3d9460858f7ab1" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
