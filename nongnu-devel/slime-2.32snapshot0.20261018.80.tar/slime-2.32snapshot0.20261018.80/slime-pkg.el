;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261018.80" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "4d998729d930af2a026c1fe67f8ff772b5f53d6a" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
