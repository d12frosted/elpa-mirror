;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261031.25" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "0c0f3fd328d6083ba63bd810c304ae2634dd29bb" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
