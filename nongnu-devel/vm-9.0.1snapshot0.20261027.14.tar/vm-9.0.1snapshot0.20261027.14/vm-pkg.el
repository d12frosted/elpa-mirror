;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261027.14" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "1b9dcdc53b1dc02781f7c4bc2ab208f2d7b28aa2" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
