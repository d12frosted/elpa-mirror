;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260808.55" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "32740772e0b669679df835d38044493b9b090487" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
