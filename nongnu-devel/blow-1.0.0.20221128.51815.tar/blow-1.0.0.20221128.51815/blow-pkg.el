;; Generated package description from blow.el  -*- no-byte-compile: t -*-
(define-package "blow" "1.0.0.20221128.51815" "Blow away mode lighters" '((emacs "24.1")) :commit "19152095662c95bc73f1f25b8dcce432294b06a1" :authors '(("Akib Azmain Turja" . "akib@disroot.org")) :maintainer '("Akib Azmain Turja" . "akib@disroot.org") :keywords '("convenience") :url "https://codeberg.org/akib/emacs-blow")
