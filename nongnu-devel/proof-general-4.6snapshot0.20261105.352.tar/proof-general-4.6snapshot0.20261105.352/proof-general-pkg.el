;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261105.352" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "9f1021edcc7b1c066c61fd01a15c4f159900bf78" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
