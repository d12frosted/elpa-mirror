;; Generated package description from geiser-chicken.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "geiser-chicken" "0.17.0.20260819.10" "Chicken's implementation of the geiser protocols" '((emacs "24.4") (geiser "0.19")) :commit "ba0c16df8ce21f1722e27e4591656c9b64fafdff" :keywords '("languages" "chicken" "scheme" "geiser") :url "https://gitlab.com/emacs-geiser/chicken")
