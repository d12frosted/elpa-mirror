;; Generated package description from haml-mode.el  -*- no-byte-compile: t -*-
(define-package "haml-mode" "3.2.1.0.20250714.144103" "Major mode for editing Haml files" '((emacs "24.1") (cl-lib "0.5")) :commit "3bb4a96535eb5c81dbe6a43bfa8d67a778d449c0" :keywords '("markup" "languages" "html") :url "https://github.com/nex3/haml-mode")
