;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261102.317" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "af05b1cac037f3bfb4e2355f37c21f0d8dcb7978" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
