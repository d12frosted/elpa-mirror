;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260901.63" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "4a5b4fb0b536da711fa536760137f5424301f087" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
