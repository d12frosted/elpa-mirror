;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.4.0.20261116.16" "A major mode for editing subtitles" '((emacs "25.1")) :commit "3a86b1c9dff65c82e5fd9cd7be1ce2aa7eb7c480" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
