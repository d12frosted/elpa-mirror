;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260828.62" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "7f6201d750234a48f1ab5995880a816b5ecb03bc" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
