;; Generated package description from geiser-chicken.el  -*- no-byte-compile: t -*-
(define-package "geiser-chicken" "0.17.0.20250803.172103" "Chicken's implementation of the geiser protocols" '((emacs "24.4") (geiser "0.19")) :commit "8342bad8ce1c79fee3563cd95ee27a8b062f6a9e" :keywords '("languages" "chicken" "scheme" "geiser") :url "https://gitlab.com/emacs-geiser/chicken")
