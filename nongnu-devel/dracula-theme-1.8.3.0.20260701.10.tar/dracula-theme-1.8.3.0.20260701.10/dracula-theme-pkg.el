;; Generated package description from dracula-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "dracula-theme" "1.8.3.0.20260701.10" "Dracula Theme" '((emacs "24.3")) :commit "1acd97258258415f6a43c332475fbdcd7ceb9274" :maintainer '("tienne Deparis" . "etienne@depar.is") :url "https://github.com/dracula/emacs")
