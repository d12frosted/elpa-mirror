;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261112.100" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "aff6222b3c40fc6f84ebaa0e4d38ba46761a92f4" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
