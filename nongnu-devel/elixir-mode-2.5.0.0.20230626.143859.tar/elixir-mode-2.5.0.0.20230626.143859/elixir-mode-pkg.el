;; Generated package description from elixir-mode.el  -*- no-byte-compile: t -*-
(define-package "elixir-mode" "2.5.0.0.20230626.143859" "Major mode for editing Elixir files" '((emacs "25")) :commit "00d6580a040a750e019218f9392cf9a4c2dac23a" :keywords '("languages" "elixir") :url "https://github.com/elixir-editors/emacs-elixir")
