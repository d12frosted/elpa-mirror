;; Generated package description from php-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.26.1.0.20260702.44" "Major mode for editing PHP code" '((emacs "27.1")) :commit "a6a79415a834b4da213f8e74b55bbb5f4dae9210" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
