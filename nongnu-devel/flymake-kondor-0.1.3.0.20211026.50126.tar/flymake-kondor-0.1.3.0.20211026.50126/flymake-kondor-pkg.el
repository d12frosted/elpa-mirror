;; Generated package description from flymake-kondor.el  -*- no-byte-compile: t -*-
(define-package "flymake-kondor" "0.1.3.0.20211026.50126" "Linter with clj-kondo" '((emacs "26.1")) :commit "784e57f36812a37e323409b90b935ef3c6920a22" :url "https://github.com/turbo-cafe/flymake-kondor")
