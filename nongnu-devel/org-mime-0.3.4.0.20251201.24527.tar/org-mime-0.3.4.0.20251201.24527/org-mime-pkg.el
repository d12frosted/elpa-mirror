;; Generated package description from org-mime.el  -*- no-byte-compile: t -*-
(define-package "org-mime" "0.3.4.0.20251201.24527" "org html export for text/html MIME emails" '((emacs "27.1")) :commit "ffaad784a8597ee52842a578c01bd347d3e0281d" :maintainer '("Chen Bin" . "chenbin.sh@gmail.com") :keywords '("mime" "mail" "email" "html") :url "http://github.com/org-mime/org-mime")
