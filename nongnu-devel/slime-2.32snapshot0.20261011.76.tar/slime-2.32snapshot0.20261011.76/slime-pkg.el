;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261011.76" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "56d528fefd8057a025437b4330ebf506f46ca27d" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
