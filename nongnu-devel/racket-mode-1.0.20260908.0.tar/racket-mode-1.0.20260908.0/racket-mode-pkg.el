;; Generated package description from racket-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "racket-mode" "1.0.20260908.0" "Racket editing, REPL, and more" '((emacs "25.1") (compat "30.0.2.0")) :commit "747b922221991c9eaff37976de325a6d7e571dd9" :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")) :url "https://www.racket-mode.com/")
