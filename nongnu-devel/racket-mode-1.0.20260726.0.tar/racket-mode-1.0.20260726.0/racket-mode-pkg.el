;; Generated package description from racket-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "racket-mode" "1.0.20260726.0" "Racket editing, REPL, and more" '((emacs "25.1") (compat "30.0.2.0")) :commit "f92a33dcc3b604f53ef23a538e26e1f25c4fea47" :authors '(("Greg Hendershott" . "racket-mode-author@greghendershott.com")) :url "https://www.racket-mode.com/")
