;; Generated package description from autothemer.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "autothemer" "0.2.18.0.20260620.7" "Conveniently define themes" '((dash "2.10.0") (emacs "26.1")) :commit "04ae311c64ba715c1094d2f6179377ad74ea612f" :maintainer '("Jason Milkins" . "jasonm23@gmail.com") :url "https://github.com/jasonm23/autothemer")
