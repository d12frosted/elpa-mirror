;; Generated package description from haskell-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "haskell-mode" "17.5.0.20261016.73" "A Haskell editing mode" '((emacs "25.1")) :commit "f957090cfb2fb8757a06750c6438561b21419f86" :keywords '("haskell" "cabal" "ghc" "repl" "languages") :url "https://github.com/haskell/haskell-mode")
