;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261113.108" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "2e5579f752638700b0d86c5c9b98d3a188ef5a6e" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
