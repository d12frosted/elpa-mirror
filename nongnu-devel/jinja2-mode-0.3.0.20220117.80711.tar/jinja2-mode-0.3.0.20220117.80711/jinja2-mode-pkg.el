;; Generated package description from jinja2-mode.el  -*- no-byte-compile: t -*-
(define-package "jinja2-mode" "0.3.0.20220117.80711" "A major mode for jinja2" 'nil :commit "03e5430a7efe1d163a16beaf3c82c5fd2c2caee1" :url "https://elpa.nongnu.org/nongnu/jinja2-mode.html")
