;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260820.56" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "ec7d59f50007cf899ebe7539a639bdb88392baf4" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
