;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261030.309" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "e0a6d4f042c083018896bc831234589abb33b915" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
