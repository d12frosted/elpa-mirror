;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "8.3.3snapshot0.20260628.43" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "ba6f0201d2544fb626160cdd1dd2cc9912036770" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
