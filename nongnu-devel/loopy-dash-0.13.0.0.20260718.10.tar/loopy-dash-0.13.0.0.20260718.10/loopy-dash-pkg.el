;; Generated package description from loopy-dash.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy-dash" "0.13.0.0.20260718.10" "Dash destructuring for `loopy'" '((emacs "28.1") (loopy "0.13.0") (dash "2.20")) :commit "b1a12170806a6565db34f918a22c4931b0176716" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy-dash")
