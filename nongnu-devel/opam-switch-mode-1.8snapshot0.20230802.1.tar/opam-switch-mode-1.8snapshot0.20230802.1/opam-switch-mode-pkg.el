;; Generated package description from opam-switch-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "opam-switch-mode" "1.8snapshot0.20230802.1" "Select OCaml opam switches via a menu" '((emacs "25.1")) :commit "1069e56a662f23ea09d4e05611bdedeb99257012" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://github.com/ProofGeneral/opam-switch-mode")
