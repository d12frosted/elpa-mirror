;; Generated package description from julia-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "julia-mode" "1.1.0.0.20260529.7" "Major mode for editing Julia source code" '((emacs "26.1")) :commit "1b5a4c2f5b7c3f842785985bf8778b8805cc6766" :keywords '("languages") :url "https://github.com/JuliaEditorSupport/julia-emacs")
