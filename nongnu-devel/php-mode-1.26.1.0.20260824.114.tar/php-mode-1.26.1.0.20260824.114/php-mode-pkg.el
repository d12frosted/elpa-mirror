;; Generated package description from php-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.26.1.0.20260824.114" "Major mode for editing PHP code" '((emacs "27.1")) :commit "3d57e94aa7ec2b94c6b0f39d39a70c79c7326e25" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
