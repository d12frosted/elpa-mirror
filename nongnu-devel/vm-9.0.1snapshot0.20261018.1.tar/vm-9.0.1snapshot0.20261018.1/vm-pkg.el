;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261018.1" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "13308f8a758fb7f0f861588af2f607a9a711e574" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
