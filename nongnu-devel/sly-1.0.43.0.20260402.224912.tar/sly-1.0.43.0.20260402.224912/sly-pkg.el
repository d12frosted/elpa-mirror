;; Generated package description from sly.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sly" "1.0.43.0.20260402.224912" "Sylvester the Cat's Common Lisp IDE" '((emacs "24.5")) :commit "759c0ff8741ced8793257f2b7ed95a23e13e1407" :keywords '("languages" "lisp" "sly") :url "https://github.com/joaotavora/sly")
