;; Generated package description from php-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.26.1.0.20260804.86" "Major mode for editing PHP code" '((emacs "27.1")) :commit "4bc3f18bc93574f4bd0575fc9642a5e92b60c59a" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
