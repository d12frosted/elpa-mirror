;; Generated package description from spacemacs-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "spacemacs-theme" "0.2.0.20260906.51" "Color theme with a dark and light versions." '((emacs "24")) :commit "b24b756863e290959a64245504ef2ade8c1e3a9f" :keywords '("color" "theme") :url "https://github.com/nashamri/spacemacs-theme")
