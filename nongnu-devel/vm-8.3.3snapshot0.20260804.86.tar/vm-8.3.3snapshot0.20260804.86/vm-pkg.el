;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "8.3.3snapshot0.20260804.86" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "ac3b46232fd7492bb7c78d5008e005a3ea91e57e" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
