;; Generated package description from dart-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "dart-mode" "1.0.7.0.20260619.52" "Major mode for editing Dart files" '((emacs "27.1")) :commit "ea9c2204f3e27b5419b9c5dba8b2078b22eb8461" :maintainer '("Jen-Chieh Shen" . "jcs090218@gmail.com") :keywords '("languages") :url "https://github.com/emacsorphanage/dart-mode")
