;; Generated package description from sly.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sly" "1.0.43.0.20261013.150" "Sylvester the Cat's Common Lisp IDE" '((emacs "24.5")) :commit "9b3477a5dc6c9a4496d4fbb6804349961e861835" :keywords '("languages" "lisp" "sly") :url "https://github.com/joaotavora/sly")
