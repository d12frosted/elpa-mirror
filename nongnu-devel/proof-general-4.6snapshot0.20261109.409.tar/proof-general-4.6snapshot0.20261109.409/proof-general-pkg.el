;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261109.409" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "e09cd62ada58d5e38986a81101cffe1be28e527d" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
