;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20260825.269" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "9799d01c357f9c35634887dffb3276b6d7adb1ac" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
