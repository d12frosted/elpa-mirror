;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261124.84" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "77e704daee0931afcb137a525c7d011f97f22e0e" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
