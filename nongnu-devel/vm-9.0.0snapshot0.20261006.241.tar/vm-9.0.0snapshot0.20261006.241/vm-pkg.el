;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.0snapshot0.20261006.241" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "f4331f8fb1744ba72a3e0cafd5d00755aaa6b3a0" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
