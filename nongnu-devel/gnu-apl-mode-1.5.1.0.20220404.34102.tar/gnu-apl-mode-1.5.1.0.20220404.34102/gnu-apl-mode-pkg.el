;; Generated package description from gnu-apl-mode.el  -*- no-byte-compile: t -*-
(define-package "gnu-apl-mode" "1.5.1.0.20220404.34102" "Emacs mode for GNU APL" 'nil :commit "c8695b0d55b5167263a843252ffd21a589018427" :authors '(("Elias Mårtenson" . "lokedhs@gmail.com")) :maintainer '("Elias Mårtenson" . "lokedhs@gmail.com") :keywords '("languages") :url "http://www.gnu.org/software/apl/")
