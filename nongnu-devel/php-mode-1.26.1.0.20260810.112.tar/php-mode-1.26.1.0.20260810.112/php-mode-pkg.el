;; Generated package description from php-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.26.1.0.20260810.112" "Major mode for editing PHP code" '((emacs "27.1")) :commit "fdcba033490bf974c465f09f1590277772d46eb0" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
