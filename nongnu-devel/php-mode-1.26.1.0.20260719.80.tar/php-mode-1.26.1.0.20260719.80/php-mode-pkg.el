;; Generated package description from php-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "php-mode" "1.26.1.0.20260719.80" "Major mode for editing PHP code" '((emacs "27.1")) :commit "6ebe4a618aa64db3e15f809b036c1b1a6d05c030" :maintainer '("USAMI Kenta" . "tadsan@zonu.me") :keywords '("languages" "php") :url "https://github.com/emacs-php/php-mode")
