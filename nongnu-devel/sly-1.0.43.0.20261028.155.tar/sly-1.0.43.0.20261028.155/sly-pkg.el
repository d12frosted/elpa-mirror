;; Generated package description from sly.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sly" "1.0.43.0.20261028.155" "Sylvester the Cat's Common Lisp IDE" '((emacs "24.5")) :commit "70350623eecd1f41837c9e57cbb6d5c06678a60d" :keywords '("languages" "lisp" "sly") :url "https://github.com/joaotavora/sly")
