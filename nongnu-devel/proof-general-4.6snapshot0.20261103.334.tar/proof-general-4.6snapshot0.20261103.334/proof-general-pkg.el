;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261103.334" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "70696abaff29def0c17d7a740806b1687dba3153" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
