;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261028.273" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "7117e4b9bad3e3801f464091df9cd77d7f560be2" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
