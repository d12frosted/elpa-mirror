;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.0snapshot0.20261017.267" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "e9772d8b718c9849b1707d1950825dfc579c138a" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
