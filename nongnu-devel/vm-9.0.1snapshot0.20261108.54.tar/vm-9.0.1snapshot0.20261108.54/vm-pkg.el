;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261108.54" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "9d27c643fbd25a051097ca9dc23c99a04d4e1e2a" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
