;; Generated package description from org-present.el  -*- no-byte-compile: t -*-
(define-package "org-present" "0.1.0.20220806.144744" "Minimalist presentation minor-mode for Emacs org-mode." '((org "7")) :commit "4ec04e1b77dea76d7c30066ccf3200d2e0b7bee9" :url "https://github.com/rlister/org-present")
