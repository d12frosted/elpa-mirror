;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261026.10" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "f66e4b348f5e959cf5c16179365663bdbb59d4b4" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
