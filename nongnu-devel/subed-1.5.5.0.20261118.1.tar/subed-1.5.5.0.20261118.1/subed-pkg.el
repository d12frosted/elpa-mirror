;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.5.0.20261118.1" "A major mode for editing subtitles" '((emacs "25.1")) :commit "14dec0bd1121a7cb29ec32e628ecb66b17af13e4" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
