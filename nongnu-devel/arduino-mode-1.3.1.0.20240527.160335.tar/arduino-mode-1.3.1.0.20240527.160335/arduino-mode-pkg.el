;; Generated package description from arduino-mode.el  -*- no-byte-compile: t -*-
(define-package "arduino-mode" "1.3.1.0.20240527.160335" "Major mode for editing Arduino code" '((emacs "25.1") (spinner "1.7.3")) :commit "b2ffd8441851659cb1cc844156073967729585e5" :maintainer '("stardiviner" . "numbchild@gmail.com") :keywords '("languages" "arduino") :url "https://repo.or.cz/arduino-mode.git")
