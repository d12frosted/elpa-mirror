;; Generated package description from spacemacs-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "spacemacs-theme" "0.2.0.20260822.48" "Color theme with a dark and light versions." '((emacs "24")) :commit "77bc457dbb7927c7b12abfa6f9c9318b7c768c15" :keywords '("color" "theme") :url "https://github.com/nashamri/spacemacs-theme")
