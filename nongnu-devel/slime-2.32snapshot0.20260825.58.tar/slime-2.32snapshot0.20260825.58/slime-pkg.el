;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260825.58" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "06e46196ad7d972c10559291d8a82f8beb735463" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
