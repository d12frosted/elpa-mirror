;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "9.0.1snapshot0.20261023.4" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "8e68879b4cfd5542a563f436b7b344267820444d" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
