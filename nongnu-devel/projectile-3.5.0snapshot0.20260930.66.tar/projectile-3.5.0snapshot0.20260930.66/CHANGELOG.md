# Changelog

<!-- Entries are one line per item and section headings repeat for every release,
     so the line-length and duplicate-heading rules don't fit this file. -->
<!-- markdownlint-disable MD013 MD024 -->

## master (unreleased)

### New features

- [#2182](https://github.com/bbatsov/projectile/pull/2182): Add `projectile-todos-in-projects` and `projectile-multi-occur-in-projects`, so every sibling command now has a public generic taking any list of projects behind it and a command for a group of your own is a two-line wrapper for all five.
- [#2181](https://github.com/bbatsov/projectile/pull/2181): Sapling and Bazaar projects can now list their own ignored files, via the new `projectile-sapling-ignored-command` and `projectile-bzr-ignored-command`.
- [#2180](https://github.com/bbatsov/projectile/pull/2180): Every shell backend can now open in another window (`s-p x 4 <key>`), not just vterm, eat and ghostel: `shell`, `eshell`, `ielm`, `term` and the backend-dispatching `projectile-run` gained `-other-window` commands.
- [#2160](https://github.com/bbatsov/projectile/pull/2160): Add `projectile-find-file-in-sibling-projects` (`s-p n f`) and `projectile-search-in-sibling-projects` (`s-p n s`), which work across the family of related projects rather than just the one you're in.
  - Both are built on `projectile-find-file-in-projects` and `projectile-search-in-projects`, which take any list of projects, so a command for a group of your own is a two-line wrapper.
  - A group search puts every match in one `*projectile-search*` buffer, named relative to the directory containing the group, so each one is labelled with the project it came from.
- [#2165](https://github.com/bbatsov/projectile/pull/2165): A subproject now has its own project type, so the `s-p c m` lifecycle commands build a monorepo member with the member's own toolchain - a Rust crate or Go module under a JavaScript repository runs `cargo test` or `go test` rather than the repository's `npm test`. New `projectile-subproject-type`.
  - A member identified by the same manifest as the repository keeps the repository's type: a pnpm or yarn workspace member holds only a `package.json` and would otherwise fall back to plain `npm`.
- [#2166](https://github.com/bbatsov/projectile/pull/2166): Subprojects now come from the workspace's own member list when the repository declares one - pnpm, npm/yarn/bun, Cargo and `go.work` - instead of from scanning for manifests, so test fixtures and excluded crates stop showing up as subprojects. Babel's repository goes from 205 to its declared 162. New `projectile-subproject-functions`.
  - Build tools that compute their members rather than declaring them (Gradle, Bazel) keep using the scan, which is why it remains the fallback.
- [#2163](https://github.com/bbatsov/projectile/pull/2163): Add `projectile-switch-to-buffer-in-sibling-projects` (`s-p n b`), `projectile-multi-occur-in-sibling-projects` (`s-p n o`) and `projectile-todos-in-sibling-projects` (`s-p n t`), so buffers and annotations follow the same family as files and searches.
  - `projectile-switch-to-buffer-in-projects` joins the two existing generic commands, and `projectile-todos` now shares one implementation with its group form.

### Changes

- [#2184](https://github.com/bbatsov/projectile/pull/2184): Rename the options that still broke their naming schemes: `projectile-ignored-project-patterns` to `projectile-ignored-project-regexps` (it holds regexps, and since 3.4 "patterns" means globs), `projectile-track-known-projects-automatically` to `projectile-auto-track-known-projects`, `projectile-watch-directory-limit` to `projectile-watch-max-directories`, `projectile-dashboard-recent-files` to `projectile-dashboard-max-recent-files` (a count, not a list) and `projectile-session-autosave` to `projectile-session-auto-save`. The old names still work as obsolete aliases.
- [#2179](https://github.com/bbatsov/projectile/pull/2179): `projectile-session-auto-save` now defaults to `t`. `projectile-session-restore-on-switch` reads what autosave writes, so with the save off by default `projectile-session-mode` restored layouts it had never recorded and did nothing until you saved one by hand.
- [#2160](https://github.com/bbatsov/projectile/pull/2160): `projectile-switch-sibling-project` moved from `s-p n` to `s-p n p`. `s-p n` is now the prefix for every command that works across related projects, with each key mirroring the project-wide one a level down, the way `c m` does for subprojects.
- [#2168](https://github.com/bbatsov/projectile/pull/2168): Search results are redrawn at most every `projectile-search-render-interval` while streaming, instead of on every chunk. The buffer is redrawn from scratch, so drawing per chunk cost roughly chunks times matches - two thirds of a sibling-group search went on redrawing. A search across 18 projects drops from 0.32s to 0.18s, and across 122 from 4.8s to 2.8s.
- [#2164](https://github.com/bbatsov/projectile/pull/2164): A search across several projects now uses ripgrep, one run per project, instead of falling back to the Emacs Lisp scanner. The candidate file list is also only computed when something is going to scan it, so the ripgrep path no longer pays for a directory walk it never reads.

### Bugs fixed

- [#2196](https://github.com/bbatsov/projectile/pull/2196): With the default in-memory cache, a project with a `.projectile` no longer throws its cache away and re-indexes on every `projectile-find-file` ([#2193](https://github.com/bbatsov/projectile/issues/2193)).
- [#2195](https://github.com/bbatsov/projectile/pull/2195): `projectile-dispatch` can be extended with `transient-insert-suffix`/`transient-append-suffix` as soon as `transient` is loaded, instead of failing with "Not a transient prefix command" until the menu had been opened once ([#2194](https://github.com/bbatsov/projectile/discussions/2194)).
- [#2191](https://github.com/bbatsov/projectile/pull/2191): The test suite passes under native compilation with an empty eln cache, as in distro package builds, instead of failing two dirconfig specs with `native-lisp-load-failed` ([#2100](https://github.com/bbatsov/projectile/issues/2100)).
- [#2190](https://github.com/bbatsov/projectile/pull/2190): Alien indexing no longer hands git exclude pathspecs to an `fd` whose `projectile-git-fd-args` lacks `--strip-cwd-prefix`, which made it fail with `No valid search paths given` ([#2187](https://github.com/bbatsov/projectile/issues/2187)).
- [#2183](https://github.com/bbatsov/projectile/pull/2183): `projectile-run-test-at-point` now builds a usable file path when the project is reached through a symlink (anything under `/tmp` on macOS, or a symlinked `~/src`), instead of one that climbs out of the project and gets rejected by the test runner.
- [#2178](https://github.com/bbatsov/projectile/pull/2178): The file-extension filter of `projectile-replace` and friends is now shell-quoted. ag received it unquoted, so a `*.el` filter reached it as the regexp `.el$` and also matched files ending in `model` or `panel`; on the other tools an extension containing a quote broke the command outright.
- [#2177](https://github.com/bbatsov/projectile/pull/2177): `projectile-ripgrep` no longer dies under zsh with `no matches found`. The `ripgrep` package runs its command line through the shell, and the ignore exclusions went in unquoted - harmless until the generated-directory defaults introduced a pattern with a `*` in it.
- [#2172](https://github.com/bbatsov/projectile/pull/2172): Fix subproject detection in a Go workspace. A `go.work` names its modules as `./api`, and the leading `./` survived into the subproject name, which then matched none of the project's file paths - so `projectile-find-file-in-subproject` offered nothing at all in a Go monorepo. Members are now spelled relative to the project root whatever the manifest wrote.
- [#2171](https://github.com/bbatsov/projectile/pull/2171): The commands that list the known projects now load the persisted list first. They read the `projectile-known-projects` variable, which stays nil until the same-named accessor loads it from disk and which nothing loads at startup - so whichever of them you reached for first in a session offered nothing. `projectile-find-file-in-known-projects` completed over an empty list; `projectile-vc`, `projectile-remove-known-project` and the "Switch to project" prompt of `projectile-require-project-root` were affected too.
- [#2170](https://github.com/bbatsov/projectile/pull/2170): Navigating a search results buffer while the scan is still running is no longer undone by the next chunk. Each redraw ended by going to the top of the buffer, so point jumped back on every batch of matches; it now stays where you left it.
- [#2167](https://github.com/bbatsov/projectile/pull/2167): The Emacs Lisp search scanner no longer decompresses or decrypts the files it reads. It went through `file-name-handler-alist`, so every archive in the candidate set was run through gzip and every `.gpg` handed to EPA - work discarded a moment later as binary, and on an encrypted file a passphrase prompt in the middle of a project search.
  - Matches inside compressed files are no longer reported by that scanner, which is what the ripgrep path already did.
- [#2162](https://github.com/bbatsov/projectile/pull/2162): Listing another project's files now applies that project's own ignore rules instead of the rules of whichever project you happen to be visiting. `projectile-find-file-in-known-projects` and the sibling commands used to filter every other project by the current one's dirconfig, and with caching on they stored that wrong list under the other project's key - so an ordinary `projectile-find-file` there kept offering ignored files, and with persistent caching it survived a restart.
- [#2161](https://github.com/bbatsov/projectile/pull/2161): Customizing `projectile-mode-line-prefix` now reaches buffers whose lighter is never recomputed - every buffer when `projectile-dynamic-mode-line` is off, which is the case its docstring describes, and remote ones always. The prefix used to be frozen at whatever it was when Projectile loaded.
- [#2157](https://github.com/bbatsov/projectile/pull/2157): `projectile-use-comint-mode` now covers the named tasks run by `projectile-run-task`, which were always given a read-only compilation buffer however it was set - so a task that needs to ask for a sudo password had nowhere to type one ([#2156](https://github.com/bbatsov/projectile/issues/2156)). Name `task` in the list, or set the option to `t`.

## 3.4.0 (2026-08-10)

### New features

- [#2148](https://github.com/bbatsov/projectile/pull/2148): Add `projectile-switch-sibling-project` (`s-p n`), which offers only the projects related to the one you're in, rather than every project on the machine.
  - Relatedness comes from `projectile-project-groups` if you've configured it, then from the owner of the upstream remote, then from the leading word of the directory name - see `projectile-sibling-project-functions`.
  - The remote's owner is what relates projects whose names have nothing in common; an inferred group covering more than `projectile-sibling-max-group-share` of your projects is dropped, since "we're all under the same account" relates nothing.
- [#2151](https://github.com/bbatsov/projectile/pull/2151): `projectile-switch-worktree` also offers Jujutsu workspaces, and a jj repository is now identified through its git backing store, so a workspace and the colocated git checkout agree on being the same thing and jj projects get siblings like any other.
- [#2147](https://github.com/bbatsov/projectile/pull/2147): Add `projectile-switch-worktree` (`s-p W`), which offers the other checkouts of the current project's repository, each annotated with whatever tells it apart - the branch for git and Mercurial, the workspace name for Jujutsu.
  - Git worktrees and separate clones of the same upstream both count as checkouts, since they're the same workflow with and without the plumbing; `projectile-worktree-functions` is where other ways of finding them plug in.
- [#2138](https://github.com/bbatsov/projectile/pull/2138): Better support for OCaml, Erlang and F#.
  - `projectile-run-test-at-point` learns `erlang-ts-mode` (EUnit's `_test`/`_test_` functions, run as `rebar3 eunit --test=module:name`) and `fsharp-ts-mode` (bindings attributed `[<Fact>]`, `[<Theory>]`, `[<Test>]`, `[<TestCase>]` or `[<Property>]`, run through `dotnet test --filter`).
  - The `ocaml-dune` and `rebar` project types gained their run, install, package and source/test directory attributes, and a new `erlang-mk` type covers the other common Erlang build tool.
  - OCaml deliberately gets no test-at-point rule: its tests are ordinary values registered with Alcotest or OUnit rather than anything the syntax marks out, so there is nothing to recognize.
- [#2137](https://github.com/bbatsov/projectile/pull/2137): Ship `:file-kinds` tables for Phoenix, Laravel and Next.js, so `projectile-find-file-of-kind` (`s-p j`) and `projectile-toggle-related-file` (`s-p J`) work in those out of the box - Rails and Django were the only frameworks covered before.
  - Phoenix keys a resource's modules on the name they share (`user_controller.ex`, `user_html.ex`, `user_live.ex`), Laravel on the model's class name, Next.js on the app router's directory.
  - Adds a `nextjs` project type (`next.config.js` and friends) to hang the last of those on.
- [#2136](https://github.com/bbatsov/projectile/pull/2136): `projectile-run-test-at-point` now knows Ruby (RSpec and Minitest), Rust, Elixir and Java, on top of the Python, Go and JS/TS rules it shipped with.
  - Ruby is written the same way whichever framework you use, so the project type picks the runner; Java's picks between Maven and Gradle, and takes the class name from the file.
  - ExUnit can't select a test by name from the command line, so Elixir tests are addressed as `FILE:LINE`.
- [#2135](https://github.com/bbatsov/projectile/pull/2135): Add `projectile-ignored-project-patterns`, the regexp-matching sibling of `projectile-ignored-projects` (exact paths) and `projectile-ignored-project-function` (a predicate), so keeping whole areas of a machine out of the known projects doesn't need a lambda.
- [#2134](https://github.com/bbatsov/projectile/pull/2134): Add `projectile-find-changed-file` (`s-p C`), which completes over the files git reports as staged, unstaged or untracked - or, with a prefix argument, over everything that differs from a revision you pick.
- [#2133](https://github.com/bbatsov/projectile/pull/2133): `projectile-doctor` findings you can act on now carry a button that does it - `[enable]` for a disabled `projectile-mode`, `[enable caching]` on a large uncached project, `[open dirconfig]` for a `.projectile` with prefix-less lines, `[edit .dir-locals.el]` for an undetected project type. Pressing one regenerates the report, so the finding answers for itself; findings Projectile can't act on stay plain advice.
- [#2132](https://github.com/bbatsov/projectile/pull/2132): The dashboard gained a "Notable files" section linking the project's README, changelog, license, its type's own manifest and its `.projectile` (see `projectile-dashboard-link-files`), plus a count of its open buffers and a summary of the ignore rules in effect.
  - A project with nothing cached now offers an `[index now]` button instead of only reporting that it isn't indexed.
  - Both report buffers set up `outline-minor-mode` over their sections, so a long report folds with the usual outline keys, and their footers derive the keys they advertise with `substitute-command-keys` rather than hardcoding them.
- [#2131](https://github.com/bbatsov/projectile/pull/2131): The `projectile-doctor` and `projectile-dashboard` buffers are no longer plain text: section headers, field labels, the project's identity and the doctor's findings are faced by meaning, with the findings colored by severity and sorted so anything wanting action comes first.
  - All the new faces only inherit from standard ones, so themes style them without knowing about Projectile and a terminal without colors degrades to what you got before.
  - `projectile-report-copy` (`w` in either buffer) copies the buffer as plain text, without the faces and buttons - a doctor report usually ends up in an issue.
- [#2130](https://github.com/bbatsov/projectile/pull/2130): `projectile-run-task` now also discovers rake tasks, read out of the project's `Rakefile` and its `.rake` files (in `rakelib`, `tasks` and `lib/tasks`) rather than by running `rake -T`, which would load the whole application. Tasks are qualified with their `namespace` (`rake:db:migrate`) and run through `bundle exec` when the project has a `Gemfile`.

### Changes

- [#2152](https://github.com/bbatsov/projectile/pull/2152): The per-command-type histories now belong to the repository rather than the directory, so pressing `M-p` at a compile or test prompt in a fresh git worktree - or in a second clone of the same upstream - offers the commands the project is actually built with instead of nothing ([#1786](https://github.com/bbatsov/projectile/issues/1786)).
  - What a prompt is pre-filled with, and what `projectile-repeat-last-command` replays, stay local to the checkout you're in: both act without asking, and a remembered command can carry absolute paths back into the checkout it was typed in.
  - Existing histories are adopted rather than dropped, and `projectile-command-history-scope` set to `project` restores a history per directory.
- [#2146](https://github.com/bbatsov/projectile/pull/2146): The six `projectile-<cmd>-use-comint-mode` options fold into one `projectile-use-comint-mode`, taking `t` or a list of the phases to make interactive.
- [#2146](https://github.com/bbatsov/projectile/pull/2146): `projectile-per-project-compilation-buffer` and `projectile-per-command-compilation-buffer` fold into `projectile-compilation-buffer-scope`, a list of `project` and/or `command` - which is what setting both booleans already meant.
- [#2146](https://github.com/bbatsov/projectile/pull/2146): Rename the options that broke their own naming schemes: `projectile-global-ignore-file-patterns` to `projectile-globally-ignored-file-regexps`, `projectile-cmd-hist-ignoredups` to `projectile-command-history-ignore-duplicates`, `projectile-related-files-fn-function` to `projectile-related-files-function`, `projectile-auto-discover` to `projectile-auto-discover-projects`, and the three reviewable-search options named after replace (`projectile-replace-max-matches`, `-async` and `-scan-chunk-size`) to the `projectile-search-` prefix their siblings already used.
- [#2146](https://github.com/bbatsov/projectile/pull/2146): `projectile-tags-file-name` and `projectile-go-project-test-function` are obsolete; both were only ever read as Projectile loaded, so setting them from your init file afterwards did nothing. List the tags file in `projectile-globally-ignored-files`, and re-register the `go` project type to change how it's detected.
- [#2146](https://github.com/bbatsov/projectile/pull/2146): Every renamed or folded option is still honored under its old name, so existing configuration keeps working.
- [#2146](https://github.com/bbatsov/projectile/pull/2146): Make the options' Customize metadata uniform - seven options that document `nil` as meaningful had a `:type` that rejected it, so Customize refused to edit them, and the `:safe` predicates now cover all the ignore lists rather than four of the nine.

### Bugs fixed

- [#2145](https://github.com/bbatsov/projectile/pull/2145): The known projects file, the frecency store and the session directory are resolved with `locate-user-emacs-file` rather than expanded against `user-emacs-directory` by hand, so they land beside the rest of your Emacs state when your configuration lives in `~/.config/emacs` instead of `~/.emacs.d`. Nothing moves for a configuration in the usual place.
- [#2144](https://github.com/bbatsov/projectile/pull/2144): Internal: the two shapes a project type marker can take are decoded in one place now, rather than by each of the four consumers separately.
- [#2142](https://github.com/bbatsov/projectile/pull/2142): Project types can declare `:src-extension` and `:test-extension`, for the languages whose tests don't carry the same extension as their sources. The bundled `elixir` type sets them, so toggling from `lib/foo.ex` now offers to create `test/foo_test.exs` - a script ExUnit will actually run - rather than `test/foo_test.ex`.
- [#2141](https://github.com/bbatsov/projectile/pull/2141): The messages Projectile emits without being asked are now prefixed with `[Projectile]`, so it's clear where they came from; the ones that answer a command you just invoked stay unprefixed. Five different conventions across the file (a `Projectile:` prefix, a bare `Projectile` one, the project name in brackets, plain passthrough, and no prefix at all) become one rule.
  - The indexing notice follows the manual's `Operating...`/`Operating...done` idiom, so a long index no longer leaves the echo area claiming to still be working.
  - `projectile-project-info` reads `Project: /path/ (npm, git)` rather than separating its three fields with `##`.
- [#2140](https://github.com/bbatsov/projectile/pull/2140): `projectile-verbose` now covers five more messages Projectile emitted without being asked: caching a file the `find-file` hook picked up, a search path entry that doesn't exist, an indexing command that exited non-zero but produced usable output (both the sync and async runners), and a session file from an older format version. Commands you invoke still report what they did whatever the option is set to, and the two that are also commands (`projectile-cache-current-file`, `projectile-discover-projects-in-directory`) still speak when invoked directly.
- [#2139](https://github.com/bbatsov/projectile/pull/2139): The file-notification cache updates now honor the VCS's ignore rules too, so a watched project no longer gains files a re-index would never have listed - the last place `.gitignore` was going unread, after [#2126](https://github.com/bbatsov/projectile/pull/2126) fixed it for files opened by hand. One `git check-ignore` covers a whole batch of events, since a batch can be an entire directory moved into the project.
- [#2146](https://github.com/bbatsov/projectile/pull/2146): The default `projectile-globally-ignored-buffers` entries are matched as regexps, so `*scratch*` only matched by accident and `*scratchhh*` matched too; the asterisks are now escaped.
- [#2146](https://github.com/bbatsov/projectile/pull/2146): `projectile-svn-command` filtered directories out of `svn list -R` with `grep -v '$/'`, where the `$` is a literal rather than an anchor, so it never dropped anything and svn projects listed their directories among their files.

## 3.3.0 (2026-07-27)

### New features

- [#1867](https://github.com/bbatsov/projectile/issues/1867): Add `projectile-per-command-compilation-buffer`, so compiling, testing and running a project no longer overwrite each other's output (`*compilation*<test>`).
- [#2121](https://github.com/bbatsov/projectile/pull/2121): Recognize the subprojects of a monorepo: `projectile-find-file-in-subproject` (`s-p c m f`) scopes file completion to one part of the repository, `projectile-project-subprojects` lists them, and the subproject lifecycle commands now work in any project rather than only where the module's manifest matches the project's own type (`projectile-subproject-markers`).
- [#2120](https://github.com/bbatsov/projectile/pull/2120): `projectile-run-task` now also offers the tasks a project's own tooling defines - npm scripts, Deno tasks, Composer scripts, just recipes, go-task tasks and Make targets - named after the tool that defines them (`npm:build`) and switched off with `projectile-discover-tasks`.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): Add 34 project types that used to come out as generic projects: `node` (a `package.json` with no lock file), `bun`, `deno`, `nx`, `turborepo`, `python-uv`, `python-pdm`, `php-composer`, `php-laravel`, `xcode`, `flutter`, `terraform`, `pulumi`, `helm`, `ansible`, `docker-compose`, `just`, `mise`, `buck2`, `pants`, `gleam`, `babashka`, `scala-cli`, `dub`, `fpm`, `alire`, `foundry`, `godot`, `platformio`, `hugo`, `jekyll`, `zola`, `mkdocs` and `quarto`.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): A project type marker can now be an `(:any "file1" "file2")` clause, so a build file with several spellings no longer needs a predicate function.
- [#2115](https://github.com/bbatsov/projectile/pull/2115): Add `projectile-replace-undo` (`s-p u`), which reverts the last replace applied from the reviewable replace buffer, leaving alone any file whose replaced text has changed since.
- [#2114](https://github.com/bbatsov/projectile/pull/2114): Add project-scoped bookmarks - `projectile-bookmark-set` (`s-p B s`), `projectile-bookmark-jump` (`s-p B j`) and `projectile-bookmark-delete` (`s-p B d`) - which are plain Emacs bookmarks with the completion scoped to the current project (see `projectile-bookmark-scope`).
- [#2113](https://github.com/bbatsov/projectile/pull/2113): Add `projectile-todos` (`s-p s t`), which collects the project's `TODO`/`FIXME`-style annotations (`projectile-todo-keywords`) into the reviewable search buffer.
- [#2112](https://github.com/bbatsov/projectile/pull/2112): Add `projectile-dashboard` (`s-p P`), a buffer summarising the current project - name, root, type, file count, branch and working tree status, most-visited files, tasks and lifecycle commands, each of them a button - which also works as a `projectile-switch-project-action`.
- [#2111](https://github.com/bbatsov/projectile/pull/2111): Add `projectile-doctor` (`s-p H`), which reports how Projectile sees the current project - root, type, indexing method and command, available tools, cache state and effective ignore rules - and ends with a list of concrete suggestions.
- [#2104](https://github.com/bbatsov/projectile/pull/2104): Alien indexing now honors Projectile's ignore rules, which it previously skipped entirely, by pushing them into the external tool.
  - Alien projects will list fewer files than before; set `projectile-alien-honors-ignores` to nil for the old behavior.
  - Tools that can't express exclusions (svn, fossil, bzr, darcs, pijul, plain `find`) are filtered in Emacs Lisp instead, and dirconfig `+` keep entries stay `hybrid`/`native` only.
- [#2096](https://github.com/bbatsov/projectile/pull/2096): Add an optional Embark/Marginalia integration, wired via `with-eval-after-load` so neither package becomes a dependency.

### Changes

- [#2123](https://github.com/bbatsov/projectile/pull/2123): Every lifecycle command now has a subproject variant - `projectile-configure-subproject`, `-install-` and `-package-` join compile, test and run (`s-p c m o`, `s-p c m i`, `s-p c m p`) - and they all say which subproject they'll run in at the prompt.
- [#2123](https://github.com/bbatsov/projectile/pull/2123): Fix the subproject commands discarding the project type's compilation directory, which had a Meson monorepo building in `sub/` instead of `sub/build/`; `projectile-compilation-dir` now takes the subproject as an optional base directory.
- [#2122](https://github.com/bbatsov/projectile/pull/2122): `projectile-globally-ignored-directories` now also covers the dependency and build output directories of the common ecosystems - `node_modules`, `target`, `_build`, `__pycache__`, `.venv`, `.next`, `.terraform` and a couple of dozen more.
  - Names that projects do sometimes commit (`vendor`, `dist`, `public`, `build`) are deliberately left out, and `projectile-globally-unignored-directories` takes any of the others back.
- [#2121](https://github.com/bbatsov/projectile/pull/2121): `go.mod` is now the Go type's project file, so it can anchor the root of a Go project outside version control and mark a module inside a larger repository.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): Bring the stale build tool markers up to date: Bazel now matches on `MODULE.bazel`, Gradle on the Kotlin DSL and on a settings file alone, Zig on `build.zig`, and go-task on all four `Taskfile` spellings.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): Modernize the lifecycle commands that no longer work: Symfony's console moved to `bin/` and its server out of the framework, the Dart CLI subsumed `pub`, `setup.py build` is deprecated by the PyPA, and poetry projects run pytest.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): Rails and Django had their development server wired to the compile command, leaving the run command empty; the server is now the run command.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): The PHP types are now registered after the JavaScript ones, so a PHP application isn't detected as a Node project because of the `package.json` its asset pipeline ships.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): The supported project types table in the manual is now generated from the registry, which had drifted well behind it.
- [#2114](https://github.com/bbatsov/projectile/pull/2114): In `projectile-dispatch`, "display buffer" moved from `B` to `C-o` (mirroring its `s-p 4 C-o` binding), so `B` could become the bookmark prefix.
- [#2110](https://github.com/bbatsov/projectile/pull/2110): The grep/ag search integration and the ignore predicates now derive their exclusions from the same gitignore patterns indexing uses, so they answer exactly what indexing would.
  - `projectile-ignored-file-p` and `projectile-ignored-directory-p` take an optional project root instead of a pre-computed list of ignored paths.
  - Removed `projectile-ignored-files`, `projectile-ignored-directories`, their `-rel` variants, `projectile-project-ignored`, `projectile-project-ignored-files`, `projectile-project-ignored-directories`, `projectile-paths-to-ignore` and `projectile-patterns-to-ignore`, which existed only to build those absolute path lists.
- [#2109](https://github.com/bbatsov/projectile/pull/2109): `alien` indexing now honors dirconfig `+` keep entries, which it previously ignored without saying so.
- [#2109](https://github.com/bbatsov/projectile/pull/2109): Fix indexing failing outright when a dirconfig had `+` keep entries and the indexing command was a shell pipeline (the plain `find` fallback, svn, fossil, pijul).
- [#2107](https://github.com/bbatsov/projectile/pull/2107): Projectile's ignore configuration now speaks gitignore patterns everywhere, matched the same way by every indexing method: a slashless pattern matches at any depth, a pattern with a slash is anchored at the project root, a trailing `/` means directory-only, and `*`, `**`, `?` and `[...]` are wildcards.
  - The `*` prefix in `projectile-globally-ignored-directories` is no longer a marker meaning "at any depth" (that's now the default) - it's a plain wildcard, so `*node_modules` should become `node_modules`.
  - A bare entry is no longer top-level-only under `hybrid`; write `/tmp` if you meant only the project root.
  - Dirconfig `!` ensure entries now apply under `alien` too, and `projectile-global-ignore-file-patterns` stays Emacs regexps and therefore `native`-only.
- [#2104](https://github.com/bbatsov/projectile/pull/2104): Ignore matching is now case-sensitive under every indexing method, where `native` and `hybrid` previously folded case (so `.elc` also hid `BUILD.ELC`).
- [#2104](https://github.com/bbatsov/projectile/pull/2104): Drop `.ensime_cache` and `.eunit` from the default `projectile-globally-ignored-directories`, as ENSIME was archived in 2018 and `.eunit` is a rebar2 artifact.
- [#2104](https://github.com/bbatsov/projectile/pull/2104): Remove `projectile-warn-when-dirconfig-is-ignored`, which existed only to warn that `alien` bypassed the dirconfig.
- [#2099](https://github.com/bbatsov/projectile/pull/2099): Drop the standalone package headers (`Version`, `Package-Requires`) from `projectile-consult.el`, since the phantom `Package-Requires` made build tooling treat an in-package module as its own package.

### Bugs fixed

- [#1927](https://github.com/bbatsov/projectile/issues/1927): A known projects file Projectile can't read is now moved aside with a `.corrupt` suffix and reported, instead of being read as an empty list - which made it look like another Emacs had removed every project, so the merge dropped the session's projects too and overwrote the file. Projectile also strips text properties when saving, since a propertized string whose properties don't read back is how the file gets corrupted in the first place.
- [#2118](https://github.com/bbatsov/projectile/issues/2118): Fix `projectile-find-file` showing "Projectile is indexing" forever with `projectile-async-indexing` enabled: Projectile waited for the indexing process's sentinel, which Emacs doesn't guarantee to run while a command sits waiting on the process, and now collects the finished command's output itself instead (`projectile-async-index-sentinel-timeout`).
- [#2097](https://github.com/bbatsov/projectile/issues/2097): Fix `projectile-compile-project` and `projectile-test-project` forgetting a command you edited at the prompt in a CMake project, where a command the project type registers as a function was never cached - the function's own answer still isn't, so a preset picker keeps prompting.
- [#1075](https://github.com/bbatsov/projectile/issues/1075): Opening a file the VCS ignores no longer adds it to the file cache under `alien`/`hybrid` indexing, so a compiled artifact you happen to visit stops turning up in `projectile-find-file`.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): Fix the `angular` project type never matching anything: its two markers were ANDed, but a project has either `angular.json` (Angular 6+) or `.angular-cli.json`, never both.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): Fix the Python project types shadowing each other - `pyproject.toml` was checked before `django`, `python-poetry`, `python-pipenv` and `python-tox`, and since nearly every Python project has one, those four never matched.
- [#2119](https://github.com/bbatsov/projectile/pull/2119): Fix `php-symfony` not matching a modern Symfony project: it required an `app` directory, gone since Symfony 3, and a `vendor` directory, which only exists after someone has run composer.

## 3.2.1 (2026-07-13)

### Bugs fixed

- [#2116](https://github.com/bbatsov/projectile/issues/2116): Fix alien/hybrid indexing being broken on Windows: the asynchronous indexer no longer hardcodes `/bin/sh` (which `make-process` can't spawn on Windows), locating `sh` via `exec-path` there and falling back to the synchronous runner when no POSIX shell is available.
- [#2094](https://github.com/bbatsov/projectile/issues/2094): Fix a `wrong-type-argument stringp` crash when running `projectile-search` (a 3.2.0 regression): the search-prompt tool tag now accepts the backend name symbol, not just a string.

## 3.2.0 (2026-07-12)

### New features

- [#2072](https://github.com/bbatsov/projectile/pull/2072): Add reviewable read-only search commands, a search-only sibling of the reviewable replace UI.
  - `projectile-search-review` (`s R`) searches for a literal string; `projectile-search-regexp-review` (`s X`) searches for an Emacs regexp, honoring full Emacs regexp syntax.
  - Matches are gathered into a read-only `*projectile-search*` buffer, grouped by file, one `LINE:COL: CONTEXT` line per match with the matched span highlighted; there is no preview, no per-match toggle and no apply.
  - The buffer reuses the replace reviewer's navigation, case/regexp toggles (`c`/`x`), line and file filters (`k`/`d`/`K`/`D`), re-search (`g`) and grep-mode export (`e`).
  - `r` bridges the current search to the replace reviewer, carrying over the term, literal-ness and case setting and prompting only for the replacement.
  - A literal `projectile-search-review` accelerates its scan with ripgrep when `rg` is installed, streaming matches in near-instantly on large projects.
    - Controlled by `projectile-search-use-ripgrep` (default on); set it to nil to always use the pure-elisp scan.
    - The ripgrep fast-path follows ripgrep's ignore rules plus Projectile's ignore globs, which can differ slightly from the elisp path's file set (e.g. hidden files, symlinks); regexp search and the whole replace reviewer always use the portable elisp scan.
  - The commands are available from `projectile-dispatch` and the Projectile menu.
- [#1924](https://github.com/bbatsov/projectile/issues/1924): Add reviewable project-wide replace commands that let you preview matches and choose which to apply, instead of the blocking, file-by-file `query-replace` walk of `projectile-replace`.
  - `projectile-replace-review` (`R`) does a literal replace; `projectile-replace-regexp-review` does an Emacs-regexp replace whose replacement can reference capture groups.
  - Matches are gathered in Emacs Lisp, so the regexp command honors full Emacs regexp syntax and the preview reflects exactly what will be edited, including unsaved changes in open buffers.
  - The `*projectile-replace*` results buffer shows a per-file, per-match preview where each match can be toggled on or off; `!` (or `C-c C-c`) applies just the enabled ones, in any order.
  - Applying edits each file from the bottom up, edits open buffers in place under a single undo step, writes closed files back preserving their coding system, and skips buffers modified since the search rather than corrupting them.
  - The results buffer can reshape the search in place, each action re-scanning and re-rendering the previews:
    - `c` toggles case sensitivity (seeded from `case-fold-search`).
    - `x` toggles between literal and Emacs-regexp matching, refusing an invalid regexp rather than erroring.
    - `k`/`d` keep or flush the matches whose line matches a regexp; `K`/`D` do the same by file name; re-searching with `g` restores anything filtered away.
  - A status line at the top shows the term, replacement, match and file counts, the mode flags, and a note when the list has been filtered.
  - `e` exports the shown matches to a `grep-mode` buffer so wgrep or Emacs 31's `grep-edit-mode` can turn them editable and write back; wgrep stays an optional integration and `!` remains the no-dependency apply path.
  - Both reviewers scan the project asynchronously, so a large search no longer freezes Emacs.
    - The results buffer opens right away, matches stream in as they're found (the header shows a "Searching..." progress note), and the scan is cancelable with `q`, `C-g`, or by killing the buffer.
    - While a scan is still running, `!` (apply), `e` (export) and the filter keys (`k`/`d`/`K`/`D`) refuse until it finishes, so the write-back never runs against a partial match set and a filter can't be outrun by a later chunk; starting a new scan (`g`/`c`/`x`) cancels any in-flight one.
    - Set `projectile-replace-async` to nil to force the old synchronous single-pass scan; batch runs always scan synchronously.
  - The commands are available from `projectile-dispatch` and the Projectile menu, and the match cap is customizable via `projectile-replace-max-matches`.
- [#2065](https://github.com/bbatsov/projectile/pull/2065): Add `projectile-session-mode`, a global minor mode that gives each project its own `tab-bar` tab.
  - Switching to a project selects its existing tab (restoring that project's window layout) when one is open, or otherwise opens a fresh tab named after the project and populated via `projectile-session-default-action`.
  - Same-named checkouts get distinct tab names (e.g. `work/foo` and `home/foo`); customize the scheme with `projectile-session-tab-name-function`.
  - `projectile-session-switch-to-buffer` completes over just the current tab's project buffers.
  - Sessions persist across Emacs restarts: `projectile-session-save`, `projectile-session-restore` and `projectile-session-forget` write a project's window layout and buffers to a file under `projectile-session-directory` and read it back; `projectile-session-save-all` saves every open project at once.
  - Switching to a project with a saved session restores it (gated by `projectile-session-restore-on-switch`); `projectile-session-autosave` saves sessions on switch-away and on exit.
  - `projectile-session-restore-all` reopens every saved project's session, each into its own tab (skipping projects already open and dropping stale sessions whose files are gone); set `projectile-session-restore-on-startup` to run it automatically at Emacs startup.
  - Which buffers are recorded, and how, is extensible via `projectile-session-buffer-serializers`; file-visiting and `dired-mode` buffers work out of the box.
  - The session commands are bound under the `w` sub-prefix of the command map (`s-p w s`, `s-p w S`, `s-p w r`, `s-p w R`, `s-p w f`, `s-p w b`), and are also available from `projectile-dispatch` and the Projectile menu.

### Changes

- [#2082](https://github.com/bbatsov/projectile/pull/2082): Add `projectile-frecency-max-projects` (default 100), which caps how many projects' frecency history is kept so the store can't grow without bound.
- [#2082](https://github.com/bbatsov/projectile/pull/2082): `projectile-replace-scan-chunk-size` is now a user-facing `defcustom` (was an internal variable).
- [#2093](https://github.com/bbatsov/projectile/pull/2093): Advertise the right completion metadata category per command so marginalia and embark annotate and act on candidates correctly: buffer switching now uses the `buffer` category (so marginalia shows its rich buffer annotations), project switching uses `file`, and file commands keep `project-file` - previously every completion was hardcoded to `project-file`. `projectile-completing-read` gained a `:category` keyword for this.
- [#2092](https://github.com/bbatsov/projectile/pull/2092): Add whole-word matching to the reviewable search/replace: toggle it with `w` in the results buffer, default it with `projectile-search-whole-word`, or seed it for one run with the `projectile-dispatch` `--word` switch. The elisp scan fences the pattern with word boundaries and the ripgrep fast-path passes `--word-regexp`, so both engines agree.
- [#2091](https://github.com/bbatsov/projectile/pull/2091): Wire the reviewable search/replace into the `projectile-dispatch` Modifiers: the two literal/regexp search entries are folded into one `sR` driven by `--regexp` (matching how `--regexp` already drives the ag/ripgrep search), and a new `--case-sensitive` switch seeds the reviewable search/replace case-sensitive. Both can still be flipped with `x`/`c` in the results buffer.
- [#2090](https://github.com/bbatsov/projectile/pull/2090): Highlight the search tool and the default value in the search prompts, and give them one consistent `Search [tool] for (default: X)` format across `projectile-search`, `projectile-grep`/`-ag`/`-ripgrep` and the reviewable search. The tool that will run (`grep`/`ag`/`ripgrep`, or `ripgrep`/`elisp` for the reviewable search's literal fast-path) is faced with `projectile-search-prompt-tool` and the symbol-at-point default with `projectile-search-prompt-default`. The reviewable search now also shows its default up front and which engine it will use.

### Bugs fixed

- [#1549](https://github.com/bbatsov/projectile/issues/1549), [#1676](https://github.com/bbatsov/projectile/issues/1676): Re-invoke a function-valued lifecycle command (e.g. a CMake preset picker or a project type's `:run`/`:test` function) on every run instead of freezing its first result in the command cache, so it can prompt again.

## 3.1.0 (2026-07-04)

### New features

- [#2064](https://github.com/bbatsov/projectile/pull/2064): Add declarative "file kinds", letting a project type describe categories of files (e.g. Rails models, controllers and views) via the new `:file-kinds` keyword of `projectile-register-project-type`.
  - `projectile-find-file-of-kind` (`j`) prompts for a kind and completes over just the project files of that kind.
  - `projectile-toggle-related-file` (`J`) generalizes `projectile-toggle-between-implementation-and-test`: it jumps to related files of other kinds, jumping straight when there's one, prompting when there are several, and cycling through them on repeated presses.
  - The `rails-test`, `rails-rspec` and `django` project types ship with ready-made `:file-kinds` tables. Related files are keyed by their namespaced path, so a top-level `UsersController` relates to the top-level `User` model rather than an `Admin::User`.
- [#2059](https://github.com/bbatsov/projectile/pull/2059): `projectile-find-file` and `projectile-find-file-dwim` now rank the files you work with first, ordering completion candidates by how often and how recently you've visited them (with decay).
  - The ranking is applied through completion metadata, so it works with any completion UI and under every indexing method, including `alien` (which `projectile-sort-order` never reached).
  - Controlled by `projectile-enable-frecency` (default on); the per-project history is persisted in `projectile-frecency-file` and capped by `projectile-frecency-max-files`.
- [#1992](https://github.com/bbatsov/projectile/issues/1992), [#1587](https://github.com/bbatsov/projectile/issues/1587), [#1553](https://github.com/bbatsov/projectile/issues/1553), [#1794](https://github.com/bbatsov/projectile/issues/1794): Add named project tasks - shell commands (or functions returning them) that you can run by name.
  - `projectile-tasks` maps task names to commands and can be set globally, per project type via the new `:tasks` keyword of `projectile-register-project-type`, or per project via `.dir-locals.el`.
  - `projectile-run-task` (`c x`) picks a task with completion and runs it like the lifecycle commands, in a per-task compilation buffer; a prefix argument lets you edit the command first (e.g. to pass ad-hoc arguments).
  - `projectile-repeat-last-task` (`c X`) re-runs the project's last task.
- [#978](https://github.com/bbatsov/projectile/issues/978): Add `projectile-project-changed-functions`, run whenever the current project changes - including implicitly via visiting a file or directory of another project - with the new and previous project root as arguments.
- [#1442](https://github.com/bbatsov/projectile/pull/1442): `projectile-sort-order` can now be set to a function that receives the list of project files and returns them in the desired order.
- [#1984](https://github.com/bbatsov/projectile/pull/1984): The VCS markers are now customizable via `projectile-vcs-markers`, whose order breaks ties between markers in the same directory - so colocated `jj`+`git` repositories can be detected as `jj` by moving `.jj` first.
- [#1890](https://github.com/bbatsov/projectile/pull/1890): Recognize osc (openSUSE Build Service) checkouts: `.osc` is now a VCS marker, a top-down-recurring root marker, and globally ignored; file listing uses the generic indexing command.
- [#1694](https://github.com/bbatsov/projectile/issues/1694): Add `projectile-invalidate-cache-all`, which invalidates the caches of all known projects at once (handy when commands like `projectile-find-file-in-known-projects` serve stale results).
- [#1075](https://github.com/bbatsov/projectile/issues/1075): Add experimental opt-in automatic cache updates via filesystem notifications, so files created, deleted or renamed outside Emacs update the cache without a manual `projectile-invalidate-cache`.
  - Enable it with `projectile-auto-update-cache-with-watches`; only local, cached projects are watched.
  - Each project uses one `file-notify` watch per directory, bounded by `projectile-watch-directory-limit`.
- [#2063](https://github.com/bbatsov/projectile/pull/2063): Add `projectile-other-window-command` (`s-p 4 4`) and `projectile-other-frame-command` (`s-p 5 5`), modeled after Emacs's `other-window-prefix`/`other-frame-prefix` (`C-x 4 4`/`C-x 5 5`): they display the buffer of the next command in another window or frame, keeping the Projectile keymap active for the next key.
  - This works with any command, including ones without a dedicated `-other-window`/`-other-frame` variant, e.g. `s-p 4 4 x s` starts a project shell in another window.
- [#2060](https://github.com/bbatsov/projectile/pull/2060): Add `projectile-run-test-at-point` (bound to `c .`), which runs just the test around point, located via the buffer's tree-sitter parse tree (requires Emacs 29+ with tree-sitter).
  - Rules for pytest (`python-ts-mode`), `go test` (`go-ts-mode`) and jest (`js-ts-mode`/`typescript-ts-mode`/`tsx-ts-mode`) are built in; other languages can be added via `projectile-test-at-point-rules`.

### Changes

- [#2010](https://github.com/bbatsov/projectile/pull/2010): Project root detection and project-type detection now probe marker files with a single directory listing per directory level instead of one file stat per marker, collapsing dozens of sequential round-trips over TRAMP into one.
  - Marker matching is exact-case as a result, even on case-insensitive filesystems. This corrected the `gnumake` type's marker to GNU make's actual `GNUmakefile` spelling, and the `make` type now recognizes a lowercase `makefile` too.
- `projectile-auto-discover` now defaults to `t`, so setting `projectile-project-search-path` is enough to have those projects discovered (no change for anyone without a search path).
  - The scan now runs once per session on the first project switch, rather than on every switch, and remote (TRAMP) search-path entries are skipped.
- [#1771](https://github.com/bbatsov/projectile/issues/1771), [#740](https://github.com/bbatsov/projectile/issues/740): Hybrid indexing now applies the dirconfig glob patterns (`-`/`!` entries without a leading slash); previously they were silently ignored under `hybrid` and only `/`-prefixed path entries took effect.
- [#1941](https://github.com/bbatsov/projectile/issues/1941): Dirconfig glob patterns now follow `.gitignore`-like rules, identical under `native` and `hybrid` indexing (previously `native` used loose string suffixes, so `-build` also ignored `mybuild`, and expanded globs per directory level, so matching differed from level to level):
  - a slashless pattern matches the file name or any directory segment at any depth;
  - a pattern containing a slash is anchored at the project root (prefix with `**/` to match anywhere);
  - a trailing slash matches directories only, and a matched directory covers its subtree;
  - `*` stops at `/` while `**` crosses it.
- Remove `projectile-check-pattern-p` and `projectile-ignored-rel-p`, the old pattern matchers superseded by the compiled dirconfig matcher (nothing referenced them anymore).
- `projectile-verify-file` now goes through `projectile-file-exists-p`, so cold project-type detection benefits from the remote file-exists cache instead of issuing a TRAMP round-trip for every marker file probed.
- The mode-line updater is only added to `window-configuration-change-hook` when `projectile-dynamic-mode-line` is enabled; change the option via Customize or `setopt` for it to apply immediately.
- The `recentf` and `recently-active` sort orders no longer rescan the full project file list once per recent file, making them usable on very large projects.
- [#1953](https://github.com/bbatsov/projectile/issues/1953): Cache the git submodule listing instead of shelling out to `git submodule foreach` on every alien/hybrid file listing; the cache invalidates automatically when `.gitmodules` changes and is also cleared by `projectile-invalidate-cache`.
- User-facing conditions (no project found, missing optional package, nothing to toggle to, etc.) now signal `user-error` instead of `error`, so they no longer trigger the debugger under `debug-on-error`.

### Bugs fixed

- [#1115](https://github.com/bbatsov/projectile/issues/1115): `projectile-replace` no longer skips replacements (or reports "All files processed" without replacing anything) when the project root is in abbreviated `~/...` form, or when a match's case differs from a lower-case input.
- [#1677](https://github.com/bbatsov/projectile/issues/1677): `projectile-replace` and `projectile-replace-regexp` now scan buffers that already visit a project file from the beginning, so matches before point in those buffers are no longer missed.
- [#1849](https://github.com/bbatsov/projectile/issues/1849): `projectile-skel-dir-locals` now exits its variable-entry loop on an empty variable name, keeping the entries made so far, instead of trapping the user in the prompt and discarding input on `C-g`.
- CMake preset files referenced via `include` are now resolved relative to the file that includes them; previously the top-level `CMakePresets.json`'s includes resolved against `default-directory`, silently dropping the included presets when the current buffer was outside the project root.
- [#1600](https://github.com/bbatsov/projectile/issues/1600): The default git submodule listing no longer depends on a Unix shell (single quotes, `tr`), fixing alien/hybrid indexing of projects with submodules on Windows.
- Invalidating a project's cache now cancels its pending deferred cache flush; previously a flush scheduled before the invalidation could fire afterwards and recreate the just-deleted cache file with empty contents.
- Frecency tracking now works for projects reached through a symlinked root; the visited file is resolved the same way as the project root, so its visits are no longer silently dropped.
- `projectile-find-other-file` no longer treats the dot before a file's extension as a wildcard when matching, so `foo.el` won't match an unrelated `fooXel`-style name.

## 3.0.0 (2026-07-01)

### Changes

- [#2055](https://github.com/bbatsov/projectile/pull/2055): Remove the dedicated `ido`/`ivy`/`helm` completion systems (and the `auto` mode that detected `ido-mode`/`ivy-mode`/`helm-mode`). `projectile-completing-read` now uses Emacs's `completing-read` (the former `default`), which works with Vertico, Consult, Fido, `ido-completing-read+`, etc., and still tags candidates with the `project-file` category. `projectile-completion-system` now takes `default` or a custom function; the removed values degrade to `default`, so nothing breaks. `helm-projectile` and `counsel-projectile` are unaffected (they don't go through this path).
- [#2045](https://github.com/bbatsov/projectile/pull/2045): `projectile-find-references` now honours Projectile's ignore configuration (`.projectile` and the globally-ignored files/directories) and is scoped via the project's file set, like `projectile-grep`/`-ag`/`-ripgrep`. It previously went through the semantic-symref API, which searched the whole tree and ignored that configuration. It also now defaults the prompt from the active region (not just the symbol at point) and no longer carries a dead pre-27 display fallback. The search remains a backend-agnostic textual one; for semantic references use the built-in `xref-find-references` (which is also scoped to the Projectile project).
- [#2041](https://github.com/bbatsov/projectile/pull/2041): Remove the built-in tags support: `projectile-find-tag`, `projectile-regenerate-tags`, `projectile-visit-project-tags-table`, and the `projectile-tags-command`/`projectile-tags-backend` options (along with the ggtags/etags-select special casing). ctags/etags navigation has been largely superseded by `xref` and LSP (`eglot` is built in since Emacs 29). Use `xref-find-definitions` directly, or `projectile-find-references` for project-wide references. `projectile-tags-file-name` is kept, since it's still used to exclude a generated tags file from indexing.
- [#2040](https://github.com/bbatsov/projectile/pull/2040): Remove `projectile-browse-dirty-projects` and `projectile-vcs-dirty-state`. The implementation spun up `vc-dir` and busy-waited (`sleep-for`) up to 30 seconds per project across every known project, scraping status strings - slow, blocking, and niche. Use Magit, `vc-dir`, or a dedicated tool to find projects with uncommitted changes.
- [#2039](https://github.com/bbatsov/projectile/pull/2039): Remove the idle timer (`projectile-enable-idle-timer`, `projectile-idle-timer-seconds`, `projectile-idle-timer-hook`). It existed mainly to re-run `projectile-regenerate-tags` on an idle timer, which makes little sense in an LSP/xref world, and it was off by default. Use a plain `run-with-idle-timer` if you really want this behavior.
- [#2036](https://github.com/bbatsov/projectile/pull/2036): Remove `projectile-commander` (and `def-projectile-commander-method`), the single-key command dispatcher. It's superseded by `projectile-dispatch`, the `transient` menu added in this cycle. The `s-p m` binding and the `C-u s-p p` project-switch prefix now invoke `projectile-dispatch` instead (the prefix falls back to `projectile-switch-project-action` when `transient` isn't installed).
- [#2032](https://github.com/bbatsov/projectile/pull/2032): A cold `projectile-find-file` (and any command that lists project files) no longer freezes Emacs while the project is indexed under the `alien`/`hybrid` methods. The indexing command runs asynchronously and is awaited in a way that keeps Emacs responsive to redisplay and `C-g` (which aborts the indexing), instead of blocking until it finishes. The resulting file list is identical; only the responsiveness during indexing differs. Controlled by the new `projectile-async-indexing` (default on); it has no effect under `native` indexing, in batch mode, or while a keyboard macro runs, all of which index synchronously as before.
- [#2030](https://github.com/bbatsov/projectile/pull/2030): Speed up native indexing further: `projectile-index-directory` now reads each directory with `directory-files-and-attributes`, so an entry's type comes from the listing call instead of a `file-directory-p` stat per file. That stat was a separate filesystem round-trip each, which dominated the walk on large and remote (TRAMP) trees - it's now one round-trip per directory instead of one per file. Symlinks pointing at directories are still followed, matching the previous behaviour. Roughly 40% faster on a local 12k-file tree; the win is far larger over TRAMP.
- [#2035](https://github.com/bbatsov/projectile/pull/2035): Speed up native indexing's post-walk step: `projectile-dir-files-native` strips the project-root prefix with a single `substring` per file instead of `file-relative-name`, which paid for an `expand-file-name`/`abbreviate-file-name` per file. `projectile-project-files` also skips re-relativising the listing when the only directory walked is the project root itself (the common single-directory case). Together that removes roughly two seconds of overhead per 90k files indexed.
- [#1872](https://github.com/bbatsov/projectile/issues/1872): Clarify in the `projectile-register-project-type` docstring and the manual that a list of `marker-files` must *all* be present for a type to match (logical AND), and that a predicate function should be used to match when any one of several files is present.
- [#1935](https://github.com/bbatsov/projectile/issues/1935): The `emacs-eask` project type now has a `test` command (`eask test`), so `projectile-test-project` works out of the box for Eask projects. Eask auto-detects the test framework (buttercup, ERT, ...), so no framework-specific type is needed.
- [#1638](https://github.com/bbatsov/projectile/issues/1638): Document in `projectile-svn-command` that it runs non-interactively and therefore needs SVN credentials to be cached up front for authenticated remotes.
- [#2016](https://github.com/bbatsov/projectile/pull/2016): Keep a separate command history per lifecycle command type (configure, compile, test, install, package, run), so the prompt's `M-p` history no longer mixes, say, test commands with compile commands. `projectile-repeat-last-command` still uses the combined per-project history and is unaffected.
- Remove the unused private `projectile--init-known-projects` alias (a leftover compatibility shim for the old known-projects API; nothing in the codebase referenced it).
- [#2000](https://github.com/bbatsov/projectile/pull/2000): `projectile-get-immediate-sub-projects` skips the `git submodule foreach` shell-out for git projects with no `.gitmodules` file anywhere up the parent chain. Hot path for monorepos that index the project root often.
- [#2000](https://github.com/bbatsov/projectile/pull/2000): `projectile-discover-projects-in-directory` now uses `directory-files-no-dot-files-regexp` to skip `.` and `..` at the C level instead of doing the post-filter in Elisp - matches the indexing walker.
- [#2000](https://github.com/bbatsov/projectile/pull/2000): Document the anchored vs `*`-prefixed semantics of `projectile-globally-ignored-directories`, the `find` fallback's lack of common directory exclusions when `fd` isn't available, and how `fd`/`git ls-files` handle deleted-but-unstaged files differently.
- [#1999](https://github.com/bbatsov/projectile/pull/1999): Speed up native indexing on large trees: `projectile-index-directory` now hashes the ignored-files / ignored-directories / globally-ignored-directory-names lists once per indexing call (the per-file `member` scans were O(N*M)), expands dirconfig glob patterns once per directory level instead of once per (file, pattern) pair, and accumulates results into a shared cell so we no longer pay for an `apply append` at each recursion level.
- [#1999](https://github.com/bbatsov/projectile/pull/1999): `projectile-remove-ignored` (hybrid post-processing) now hashes the ignored-files basenames and pre-splits ignored-dirs into prefix-match and any-segment groups, so the per-file inner loops drop from O(M) `seq-some` walks to O(1) hash lookups (or O(segments) for `*`-prefixed entries).
- [#1998](https://github.com/bbatsov/projectile/pull/1998): Hybrid indexing now batches the external command into a single invocation when the project's `.projectile` declares multiple `+` keep entries, instead of shelling out once per kept subdirectory. The kept paths are passed to the indexing tool (e.g. `git ls-files`, `fd`, `find`) as positional pathspecs and submodule files outside those subdirectories are filtered out. Resolves the long-standing TODO in `projectile-project-files`.
- [#1998](https://github.com/bbatsov/projectile/pull/1998): `projectile-files-via-ext-command` now accepts an optional `pathspecs` argument; entries are shell-quoted before being appended to the command. `projectile-dir-files-alien` similarly accepts an optional `subdirs` argument that threads through.
- [#1997](https://github.com/bbatsov/projectile/pull/1997): Document the `hybrid` indexing method in the manual and add a feature matrix showing which Projectile knobs (dirconfig, global ignores/unignores, sort order, default caching) apply under `native`/`hybrid`/`alien`.
- [#1997](https://github.com/bbatsov/projectile/pull/1997): `projectile-dir-files-alien` now accepts an optional `vcs` argument so the dispatcher can thread through the already-resolved VCS instead of recomputing it. Existing single-argument callers are unaffected.
- [#1997](https://github.com/bbatsov/projectile/pull/1997): `projectile-index-directory` (native indexing) now relies on `directory-files-no-dot-files-regexp` to filter out `.` and `..` at the C level instead of walking past them in Elisp.
- [#1996](https://github.com/bbatsov/projectile/pull/1996): `projectile-project-root-cache` now keys entries on cons cells (`(FUNC . DIR)` for per-function results, `('none . DIR)` for the overall failure marker) instead of formatted strings. This is internal state, but third-party code that reaches into the cache directly will need to update.
- [#1994](https://github.com/bbatsov/projectile/pull/1994): `projectile-parse-dirconfig-file` now returns a `projectile-dirconfig` struct (with `keep`, `ignore`, `ensure`, and `prefixless-ignore` slots) instead of a positional 3-tuple. External callers should use the accessors (`projectile-dirconfig-keep` etc.) rather than `car`/`cadr`/`caddr`.
- [#1994](https://github.com/bbatsov/projectile/pull/1994): Soft-deprecate prefix-less ignore entries in `.projectile`. Lines without a `+`/`-`/`!` prefix are still treated as ignore patterns for backward compatibility, but a one-time warning is now shown for each project that uses them. Set `projectile-warn-on-prefixless-dirconfig-lines` to nil to silence.
- [#2056](https://github.com/bbatsov/projectile/pull/2056): **[Breaking]** Remove the legacy single-letter lifecycle keybindings `C`/`K`/`L`/`P`/`u` (configure/package/install/test/run project). Use the `c` prefix instead (`c o`, `c p`, `c i`, `c t`, `c r`).
- [#2056](https://github.com/bbatsov/projectile/pull/2056): Remove two long-obsolete aliases: `projectile-global-mode` (use `projectile-mode`) and `projectile-project-root-files-functions` (use `projectile-project-root-functions`).
- [#1986](https://github.com/bbatsov/projectile/pull/1986): Pre-compute file timestamps in `projectile-sort-by-modification-time` and `projectile-sort-by-access-time` to reduce stat calls from O(n log n) to O(n).
- [#1986](https://github.com/bbatsov/projectile/pull/1986): Cache `projectile-parse-dirconfig-file` results per project root (invalidated by file modification time), avoiding redundant file reads during indexing.
- [#1986](https://github.com/bbatsov/projectile/pull/1986): Cache `file-truename` results in `projectile-project-buffer-p` when checking multiple buffers, reducing redundant symlink resolution.
- [#1987](https://github.com/bbatsov/projectile/pull/1987): Use a hash set for deleted file removal in `projectile-dir-files-alien`, improving performance from O(n*m) to O(n+m) when filtering deleted-but-unstaged files.
- [#1987](https://github.com/bbatsov/projectile/pull/1987): Avoid redundant `projectile-project-root` call in `projectile-detect-project-type` by passing through the already-resolved root.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Share `file-truename` cache across buffers in `projectile-open-projects`, matching the optimization already in `projectile-project-buffers`.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Remove unnecessary temp buffer creation in `projectile--cache-project-commands-p` (was creating a buffer and re-reading `.dir-locals.el` on every compile/test/run invocation).
- [#2056](https://github.com/bbatsov/projectile/pull/2056): **[Breaking]** Bump the minimum required Emacs version to 28.1 (from 26.1). This removes ~30 lines of compatibility code (fileloop fallback, `time-convert` fallback, `projectile-flatten` shim), makes `transient` (and therefore `projectile-dispatch`) an unconditional dependency, and fixes the `tags-query-replace` FIXME in `projectile-replace-regexp`.
- Add `compat` as a dependency, enabling the use of modern Emacs APIs (e.g. `string-replace`) on older Emacs versions.
- Replace most `cl-lib` sequence functions with `seq.el` equivalents (`seq-filter`, `seq-remove`, `seq-some`, `seq-find`, `seq-sort`, `seq-every-p`, `seq-difference`) and convert `cl-case` to `pcase`.
- [#1971](https://github.com/bbatsov/projectile/pull/1971): Support `slnx` files for dotnet project types.
- [#1958](https://github.com/bbatsov/projectile/issues/1958): Exclude `.projectile-cache.eld` from search results (ripgrep/ag/grep) by default.
- [#1947](https://github.com/bbatsov/projectile/issues/1947): `projectile-project-name` should be marked as safe.
- Set `projectile-auto-discover` to `nil` by default (to avoid startup slowdowns in some situations).
- [#1943](https://github.com/bbatsov/projectile/pull/1943): Consider `projectile-indexing-method` to be safe as a dir-local variable if it is one of the preset values.
- [#1936](https://github.com/bbatsov/projectile/issues/1936): Do not require selecting a project when using `M-x projectile-invalidate-cache`, since there is a global cache that is also cleared by that command, even when not operating on any specific project.
- Add `build.mill` as an alternative project marker for the Mill project type, matching Mill's current recommended file extension.
- Replace obsolete `when-let` and `cl-gensym` with `when-let*` and `gensym` for compatibility with Emacs 31+.

### New features

- [#1697](https://github.com/bbatsov/projectile/issues/1697): Add `projectile-add-and-switch-project`, which prompts for a directory, adds it to the known projects, and immediately switches to it.
- [#1698](https://github.com/bbatsov/projectile/issues/1698): Support `%p` in project command strings (configure/compile/test/run/install/package); it is replaced with the project name when the command runs, so e.g. `:run "docker run %p"` works for both registered project types and interactively entered commands.
- [#2053](https://github.com/bbatsov/projectile/pull/2053): Add `projectile-run` (`s-p x r`), a single command that opens a shell, REPL or terminal in the project root over a *pluggable backend* (the same registry that powers `projectile-search`). Projectile ships `shell`, `eshell`, `ielm`, `term`, `vterm`, `eat` and `ghostel` backends; `projectile-shell-backend` selects which is used (default `eshell`). Register your own terminal with `projectile-register-shell-backend`. The dedicated commands (`projectile-run-eshell`, `projectile-run-vterm`, ..., and the `-other-window` variants) are kept as thin wrappers that force a backend.
- [#2052](https://github.com/bbatsov/projectile/pull/2052): Add `projectile-search` (`s-p s s`), a single search command that runs over a *pluggable backend*. Projectile ships `grep`, `ripgrep` and `ag` backends; `projectile-search-backend` selects which is used (`auto` by default, favouring ripgrep then grep). Register your own tool (deadgrep, consult-ripgrep, ...) with `projectile-register-search-backend`. `projectile-grep`, `projectile-ripgrep` and `projectile-ag` are kept as thin wrappers that force a specific backend. Note the keymap change: `s-p s s` is now `projectile-search` (it used to be `projectile-ag`), and `projectile-ag` moves to `s-p s a`. The generic registry behind this (`projectile-register-backend`) is designed to be reused for other command families later.
- [#2051](https://github.com/bbatsov/projectile/pull/2051): `projectile-dispatch` now exposes command modifiers as `transient` switches. A *Modifiers* group offers `--invalidate-cache` (`-i`, rebuild the file cache first, for the find file/dir commands), `--regexp` (`-r`, for `ag`/`ripgrep`), `--new-process` (`-n`, for the shells/REPLs), and `--display` (`-d`, cycle the display target through this window / other window / other frame, for the file/buffer/project commands). The `--display` switch replaces the old dedicated "Other window" and "Other frame" menu columns. (The `projectile-command-map` `4 <key>` / `5 <key>` bindings are unchanged.)
- [#2034](https://github.com/bbatsov/projectile/pull/2034): Add `projectile-consult.el`, an optional Consult integration distributed alongside Projectile (with a soft dependency on `consult`, so it's only loaded if you `require` it). `projectile-consult-find-file` drives a streaming Consult finder from Projectile's own indexing command (via `projectile-project-files-producer`), so candidates appear in the minibuffer as the project is indexed instead of blocking until it's done, while still honouring the project's VCS and indexing configuration. The module is self-contained so it can be split into its own package later; it requires Emacs 29.1+ (Consult's floor).
- [#2031](https://github.com/bbatsov/projectile/pull/2031): Add `projectile-index-project-async`, which indexes the current project in the background (via `make-process`) and populates the files cache without freezing Emacs, so a later `projectile-find-file` finds the cache already warm. Works with the `alien`/`hybrid` indexing methods (the `native` Elisp walk can't run off the main thread) and requires caching to be enabled. The underlying building blocks - `projectile-files-via-ext-command-async` and `projectile-dir-files-alien-async` - are public, so a streaming finder (e.g. one built on `consult`) can drive Projectile's indexing command asynchronously. Remote projects are handled via TRAMP. The result is identical to the synchronous indexing path.
- [#2033](https://github.com/bbatsov/projectile/pull/2033): Add `projectile-project-files-producer`, which returns a plist (`:directory`, `:vcs`, `:command`, `:separator`) describing how to list a project's files with its external indexing command. It gives an external asynchronous/streaming file finder (e.g. one built on `consult` or `affe`) a single, stable entry point for driving Projectile's own indexing command instead of stitching together the root, VCS and command builders by hand.
- [#1956](https://github.com/bbatsov/projectile/issues/1956): Add `projectile-switch-project-other-window` and `projectile-switch-project-other-frame` (bound to `4 p` and `5 p`), which switch to a project and display it in another window/frame. The action they run is configurable via `projectile-switch-project-other-window-action` / `projectile-switch-project-other-frame-action` (find-file in the other window/frame by default).
- [#1809](https://github.com/bbatsov/projectile/issues/1809): Track the project switched away from in `projectile-most-recent-project` and add `projectile-switch-to-most-recent-project` to jump back to it (repeated calls toggle between the two). Only switches made through Projectile's switch-project commands are tracked.
- [#1861](https://github.com/bbatsov/projectile/issues/1861): Add `projectile-discard-command-cache` to drop the cached configure/compile/test/install/package/run commands for the current project, so a freshly edited `.dir-locals.el` (or project-type default) is picked up on the next run. Can be called manually or added to `after-save-hook`.
- [#2011](https://github.com/bbatsov/projectile/pull/2011): Add `projectile-uniquify-dirname-transform`, a project-aware value for `uniquify-dirname-transform` that disambiguates same-named buffers using the project name. Mirrors `project.el`'s `project-uniquify-dirname-transform`.
- [#2012](https://github.com/bbatsov/projectile/pull/2012): Add `projectile-dispatch`, a `transient` menu mirroring `projectile-command-map` for more discoverable command access. `transient` is an optional dependency (it requires Emacs 28+); the menu is only available when it's installed and is not bound to a key by default.
- [#2008](https://github.com/bbatsov/projectile/issues/2008): Add `projectile-remove-project-type` to unregister a project type. This is the supported way to stop Projectile auto-detecting a type; clearing its `marker-files` does not work (see the related bug fix below).
- [#1936](https://github.com/bbatsov/projectile/issues/1936): Add `projectile-discard-root-cache` command to clear `projectile-project-root-cache` without touching other Projectile caches. Useful after creating or removing a project marker, since the existing `projectile-invalidate-cache` either also drops the file list cache or prompts for a project depending on context.
- [#1993](https://github.com/bbatsov/projectile/pull/1993): Warn once per session when `projectile-indexing-method` is `alien` but the project has a non-empty `.projectile` file, so users notice their dirconfig rules are being bypassed. Controlled by the new `projectile-warn-when-dirconfig-is-ignored` option.
- [#1993](https://github.com/bbatsov/projectile/pull/1993): Warn when a `+` keep entry in `.projectile` contains glob metacharacters. The `+` prefix is for subdirectory paths only and globs are silently coerced into a non-matching directory name; the warning surfaces the misuse rather than letting it fail silently.
- [#1964](https://github.com/bbatsov/projectile/issues/1964): Implement `project-name` and `project-buffers` methods for the `project.el` integration, so that code using `project.el` APIs returns correct results for Projectile-managed projects.
- [#2013](https://github.com/bbatsov/projectile/pull/2013): Implement the `project-ignores` method for the `project.el` integration, translating Projectile's global ignores, ignored file suffixes, and dirconfig (`.projectile`) ignore entries into the glob format `project.el` expects. This makes Projectile a more complete `project.el` backend for tools that rely on the protocol (e.g. `project-find-regexp`).
- [#2014](https://github.com/bbatsov/projectile/pull/2014): Add `projectile-forget-projects-under` to drop all known projects located under a directory (with a prefix argument it recurses into nested projects). Mirrors `project.el`'s `project-forget-projects-under`.
- [#2014](https://github.com/bbatsov/projectile/pull/2014): Add `projectile-forget-zombie-projects` as an alias for `projectile-cleanup-known-projects`, for discoverability and parity with `project.el`'s `project-forget-zombie-projects`.
- [#2015](https://github.com/bbatsov/projectile/pull/2015): `projectile-kill-buffers-filter` now also accepts a composable list of conditions (buffer-name regexps, predicates, and `major-mode`/`derived-mode`/`not`/`and`/`or` forms), modeled on `project.el`'s `project-kill-buffer-conditions`. The existing `kill-all`, `kill-only-files`, and predicate-function values keep working unchanged.
- [#1837](https://github.com/bbatsov/projectile/issues/1837): Add `eat` project terminal commands with keybindings `x x` and `x 4 x`.
- [#2022](https://github.com/bbatsov/projectile/pull/2022): Add `ghostel` project terminal commands with keybindings `x G` and `x 4 G`.
- [#1937](https://github.com/bbatsov/projectile/pull/1937): Add keybinding `A` (in the projectile command map) and a menu entry for `projectile-add-known-project`.
- [#1653](https://github.com/bbatsov/projectile/issues/1653): Add `projectile-compile-subproject` and `projectile-test-subproject` commands for building/testing individual modules in multi-module projects (e.g. Maven, Gradle). Bound to `c m c` and `c m t`.

### Bugs fixed

- [#2005](https://github.com/bbatsov/projectile/issues/2005): Fix hybrid indexing with `fd` when the `.projectile` file has `+` keep entries. The kept directories were appended to the `fd` command as bare positional arguments, but `fd`'s grammar is `[pattern] [path...]` (so the first path was misread as the search pattern) and `fd` 9+ additionally rejects `--strip-cwd-prefix` alongside explicit paths (`error: ... '--strip-cwd-prefix' cannot be used with '[path]...'`). Projectile now passes the directories to `fd` via `--search-path` and drops `--strip-cwd-prefix` in that case. Other tools (`git ls-files`, `find`, etc.) still get plain trailing paths.
- [#2042](https://github.com/bbatsov/projectile/issues/2042): Asynchronous indexing now runs its command under `/bin/sh` rather than the user's interactive `shell-file-name`. The async runner wraps the command as `{ ...; } 2>file`, which is POSIX-sh syntax and broke for users whose shell is `csh`/`tcsh`/`fish` (it produced bogus `{`-related output instead of a file list). The indexing command itself is a plain POSIX command, so a POSIX shell is the correct interpreter regardless of the login shell.
- [#2046](https://github.com/bbatsov/projectile/issues/2046): Commands chosen from the `projectile-dispatch` menu now run in the project that was just selected, instead of the current buffer's project. The menu is a `transient`, so its suffix commands run after the project switch has unwound; the switched-to project is now kept current for the lifetime of the menu and restored when it exits. This applies whether the menu is reached via `C-u s-p p` or by setting `projectile-switch-project-action` to `projectile-dispatch` (or any other transient).
- [#2037](https://github.com/bbatsov/projectile/issues/2037): `projectile-consult.el` now byte-compiles cleanly when `consult` isn't installed. Because the module ships inside the Projectile MELPA package, build systems (package.el, nixpkgs) try to compile it without `consult` present, which previously errored on its top-level `(require 'consult)`. `consult` is now loaded softly at the top (and hard-required inside the command, where it's actually needed), with the used functions forward-declared.
- [#2042](https://github.com/bbatsov/projectile/issues/2042): A non-zero exit from the indexing command (`fd`, `git ls-files`, `find`, ...) no longer aborts `projectile-find-file` when the command still produced a file listing. External listers like `fd` routinely exit non-zero on benign conditions (e.g. an unreadable directory hit mid-traversal); that output is now used. A `user-error` is still raised when a non-zero exit produced no output at all, so a genuinely broken/missing command is still surfaced rather than mistaken for an empty project.
- [#1663](https://github.com/bbatsov/projectile/issues/1663): Projects matched by `projectile-ignored-projects` (or `projectile-ignored-project-function`) are now excluded from `projectile-relevant-known-projects`, so they no longer show up in `projectile-switch-project` even when they were added to the known projects before being ignored. Previously the ignore list was only consulted when adding a project.
- [#1909](https://github.com/bbatsov/projectile/issues/1909): A project type registered with a predicate `marker-files` function now receives the project root as its argument when detecting the current project's type. Previously it was passed `nil`, so such a function could never match the current project.
- [#1829](https://github.com/bbatsov/projectile/issues/1829): `projectile-project-root` no longer errors with `(wrong-type-argument stringp nil)` when `default-directory` is nil (which can happen in some non-file buffers); it returns nil instead.
- [#1946](https://github.com/bbatsov/projectile/issues/1946): `projectile-ripgrep` now builds its ignore exclusions as `--glob=!PATTERN` instead of `--glob '!PATTERN'`. The surrounding single quotes were only stripped by POSIX shells, so on Windows `cmd` they became part of the pattern and the exclusions silently failed.
- [#2008](https://github.com/bbatsov/projectile/issues/2008): A project type with an empty `marker-files` list no longer matches every project. `projectile-verify-files` is vacuously true for an empty list, so a type whose markers were cleared (e.g. via `projectile-update-project-type ... :marker-files nil`) would be detected everywhere instead of nowhere. `projectile-detect-project-type` now treats an empty marker set as a non-match.
- `projectile-discard-root-cache` and `projectile-invalidate-cache` now also clear `projectile-file-exists-cache`. Without this, after creating a new project marker (`.projectile`, `.git`, etc.) over TRAMP, the negative entries cached during earlier root-walks would keep reporting "not found" for up to `projectile-file-exists-remote-cache-expire` seconds even after the user explicitly invalidated the root cache.
- `projectile-find-file-hook-function` no longer disables *all* of Projectile for remote buffers - the cheap operations (file caching, known-projects tracking, project buffer-count cap) now run regardless of remoteness, and only the genuinely slow ones (mode-line update, tags-table visit) stay gated. Previously the entire hook was a single `(unless (file-remote-p ...))`, which meant remote projects never showed up in known-projects auto-tracking and never had their files cached on visit.
- Stop stat'ing remote known projects in `projectile-keep-project-p`. The "remote and connected" branch used `file-readable-p`, which is a remote round-trip per project; with `projectile-auto-cleanup-known-projects` enabled, that turned every project switch into a serial network walk over all remote known projects. Remote projects are now always kept; users can drop dead ones with `projectile-remove-known-project`.
- Skip `file-truename` for remote paths in `projectile-ignored-project-p` and `projectile-ignored-projects`. The known-projects tracker calls `projectile-ignored-project-p` from the find-file hook for every visit, and the previous behavior round-tripped to the remote on each call (and once per ignored entry) just to canonicalize symlinks.
- `projectile-project-buffer-p` now skips the `file-truename` call for buffers visiting remote (TRAMP) files. Each truename was a remote round-trip and `projectile-project-buffers` iterates the full `buffer-list`, so projects with N remote buffers in distinct directories were paying N round-trips on every call. Resolving symlinks across a TRAMP boundary is rarely meaningful in any case.
- Replace the 10 sequential `file-exists-p` probes in `projectile-project-vcs` with a single `directory-files` listing, and cache the per-project result in `projectile-project-vcs-cache`. Also collapse the up-the-tree dominator walk so each ancestor directory is listed at most once instead of up to 10 times. Over TRAMP this turns "1 round-trip per VCS marker per probed directory" into "1 round-trip per probed directory", and the cache means follow-up callers (the indexing path, `projectile-project-info`, the project-cleanup loop) hit memory.
- Cut down `projectile-project-root` round-trips on TRAMP. The cache-validity check used raw `file-exists-p` on the cached project root, which is a fresh remote stat on every call; switched to `projectile-file-exists-p` so the per-host TTL applies. Also memoize `(file-truename dir)` across the `projectile-project-root-functions` loop so cache-miss calls compute the truename once instead of once per probe (4-5 remote stats with the default function list).
- [#1501](https://github.com/bbatsov/projectile/issues/1501), [#1275](https://github.com/bbatsov/projectile/issues/1275): Detect `fd`/`fdfind` on the remote host for TRAMP projects instead of reusing the locally-detected `projectile-fd-executable`. The locally-resolved value is meaningless on the remote, so when `fd` was installed on the local box but not on the remote (or vice-versa), git indexing would silently fall back to an empty file list. The new `projectile-fd-executable-for` returns the per-directory executable, with a per-host cache so the remote `executable-find` lookup runs at most once per host per session.
- [#1898](https://github.com/bbatsov/projectile/issues/1898), [#1932](https://github.com/bbatsov/projectile/issues/1932): Surface non-zero exit codes from the indexing command in `projectile-files-via-ext-command` instead of silently returning an empty file list. The most common cause is `fd`/`git` being installed locally but not on the remote host of a TRAMP project — previously this manifested as an unexplained empty completion list (or `stringp, nil` crashes downstream); it now signals a `user-error` pointing at the `*projectile-files-errors*` buffer for the captured stderr.
- [#1211](https://github.com/bbatsov/projectile/issues/1211): Fix file-local `projectile-project-root` overrides being ignored after the first buffer in a directory was visited. The cache used `(default-directory)` as part of the key but `projectile-root-local` reads a buffer-local variable, so two buffers in the same directory with different overrides got the first buffer's answer. Results from `projectile-root-local` are no longer cached.
- [#1836](https://github.com/bbatsov/projectile/issues/1836): Memoize per-function `nil` results in the project root cache. Previously, when an early entry in `projectile-project-root-functions` returned nil, the nil was indistinguishable from a missing cache entry, so the function was re-run on every `projectile-project-root` call. With many entries this could cost several full directory walks per call. A `'none` sentinel is now stored for unsuccessful entries.
- [#1508](https://github.com/bbatsov/projectile/issues/1508): Fix dirconfig parser silently treating lines as ignore patterns when the `+`/`-`/`!` prefix or the comment character is preceded by whitespace; leading spaces and tabs are now skipped before prefix dispatch.
- [#1989](https://github.com/bbatsov/projectile/pull/1989): Fix `projectile-files-via-ext-command` executing empty string as shell command for non-git VCS sub-projects.
- [#1989](https://github.com/bbatsov/projectile/pull/1989): Fix `projectile-select-files` crashing on filenames with regexp metacharacters by using `string-search` instead of `string-match`.
- [#1989](https://github.com/bbatsov/projectile/pull/1989): Fix `projectile-find-references` using internal `xref--show-xrefs` API whose signature changed across Emacs versions.
- [#1989](https://github.com/bbatsov/projectile/pull/1989): Fix `projectile-determine-find-tag-fn` falling back to `find-tag` which was removed in Emacs 29; now falls back to `xref-find-definitions`.
- [#1989](https://github.com/bbatsov/projectile/pull/1989): Fix `projectile-files-to-ensure` expanding wildcards relative to the current buffer instead of the project root.
- [#1989](https://github.com/bbatsov/projectile/pull/1989): Fix `projectile-ignored-project-p` failing to match abbreviated paths against truename-resolved ignored projects list.
- [#1989](https://github.com/bbatsov/projectile/pull/1989): Fix `projectile-edit-dir-locals` saving partial `.dir-locals.el` content when the user aborts skeleton insertion with `C-g`.
- [#1989](https://github.com/bbatsov/projectile/pull/1989): Fix `projectile--other-extension-files` sort comparator ignoring its second argument, producing undefined ordering; replaced with a stable partition.
- [#1989](https://github.com/bbatsov/projectile/pull/1989): Fix `projectile-toggle-project-read-only` operating on the wrong buffer after `add-dir-local-variable` by wrapping in `save-selected-window`.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile-cache-current-file` calling `projectile-project-root` twice instead of reusing the already-resolved value.
- Fix `projectile-cache-current-file` queueing one idle timer per opened file, each capturing a stale snapshot of the file list. With persistent caching, opening many files in a session would result in N redundant disk writes after Emacs went idle. A pending flush is now coalesced per project and reads the latest in-memory cache at fire time.
- Fix `projectile-load-project-cache` not recording a cache time, which combined with `projectile-files-cache-expire` made the TTL check immediately re-evict freshly loaded data — every call ended up re-reading the cache file from disk and the data was never reindexed. The cache file's mtime is now used to seed `projectile-projects-cache-time`.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile-load-project-cache` storing nil in cache on corrupt/empty cache files, preventing future reload attempts.
- Fix `projectile-purge-dir-from-cache` only updating the in-memory cache; with persistent caching the purged directory's files would reappear on the next session. The on-disk cache is now updated as well, matching the behavior of `projectile-purge-file-from-cache`.
- `projectile-invalidate-cache` now deletes the persistent cache file instead of overwriting it with a serialized `nil`.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile--cmake-command-presets` using `mapcar` instead of `mapcan`, producing nested lists for included presets.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile--eat` ignoring the `new-process` argument when generating buffer names.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile-check-vcs-status` hanging indefinitely by adding a 30-second timeout to its busy-wait loop.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile-sort-by-modification-time` and `projectile-sort-by-access-time` crashing on deleted files (nil `file-attributes`).
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile-recentf-files` failing to match files when the project root contains symlinks.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile--run-project-cmd` passing nil to `compile` when no command is configured and `compilation-read-command` is nil — now signals a clear `user-error`.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile--merge-related-files-fns` using destructive `nconc` which could corrupt shared data and silently drop values when the existing list was nil.
- [#1988](https://github.com/bbatsov/projectile/pull/1988): Fix `projectile-configure-command` format call passing an unused `compile-dir` argument.
- [#1987](https://github.com/bbatsov/projectile/pull/1987): Fix `projectile-update-project-type` resetting the project type cache with wrong hash table `:test` (used default `eql` instead of `equal` for string keys).
- [#1987](https://github.com/bbatsov/projectile/pull/1987): Fix `projectile-find-file-hook-function` running `projectile-maybe-limit-project-file-buffers` on TRAMP buffers, causing potential hangs on slow connections.
- [#1987](https://github.com/bbatsov/projectile/pull/1987): Use `expand-file-name` instead of `file-truename` in `projectile-compilation-dir` to avoid unnecessary symlink resolution (and TRAMP network round-trips).
- [#1987](https://github.com/bbatsov/projectile/pull/1987): Use non-destructive `append` instead of `nconc` in `projectile-get-all-sub-projects` to avoid mutating caller data.
- [#1987](https://github.com/bbatsov/projectile/pull/1987): Add `safe-local-variable` predicates for project settings variables (`projectile-project-test-suffix`, `projectile-project-compilation-cmd`, etc.) so they can be set in `.dir-locals.el` without prompting.
- [#1962](https://github.com/bbatsov/projectile/issues/1962): Fix `projectile-get-other-files` crashing when a candidate other-file lives in the project root directory.
- [#1816](https://github.com/bbatsov/projectile/issues/1816): Fix `projectile-expand-file-name-wildcard` failing when a parent directory is not readable (e.g. iCloud Drive, Termux).
- [#1841](https://github.com/bbatsov/projectile/issues/1841): Preserve user's `compilation-buffer-name-function` when `projectile-per-project-compilation-buffer` is nil.
- [#1823](https://github.com/bbatsov/projectile/issues/1823): Update the mode-line via `window-configuration-change-hook` so non-file buffers (e.g. Magit) display the correct project info.
- [#1886](https://github.com/bbatsov/projectile/issues/1886): Fix `(wrong-type-argument stringp nil)` error when running project commands in a newly created project by using `projectile-acquire-root` instead of `projectile-project-root` in `projectile--run-project-cmd`.
- [#1456](https://github.com/bbatsov/projectile/issues/1456): Fix `projectile-replace-regexp` stopping when encountering a missing file by filtering nonexistent files from the replacement file list.
- [#1687](https://github.com/bbatsov/projectile/issues/1687): Fix `projectile-grep-finished-hook` not running on subsequent grep calls due to buffer rename collision.
- [#1939](https://github.com/bbatsov/projectile/issues/1939): Handle corrupted `projectile-known-projects-file` gracefully instead of crashing with `(wrong-type-argument listp ...)`.
- [#1748](https://github.com/bbatsov/projectile/issues/1748): Fix `projectile-replace` falling back to the legacy Emacs 25/26 code path on Emacs 27+ because `fileloop` was not loaded.
- [#1741](https://github.com/bbatsov/projectile/issues/1741): Fix `projectile-replace` treating the search string as a regexp instead of a literal string on Emacs 27+.
- [#1729](https://github.com/bbatsov/projectile/issues/1729): Fix `projectile-root-top-down` to actually return the topmost matching project root instead of the bottommost.
- [#1596](https://github.com/bbatsov/projectile/issues/1596): `projectile-find-dir` now includes intermediate directories that contain only subdirectories (e.g. `src/` when it only has `src/ComponentA/`, `src/ComponentB/`).
- [#1551](https://github.com/bbatsov/projectile/issues/1551): Don't add nonexistent files to the project cache (e.g. when visiting a new file with `find-file` and then abandoning the buffer).
- [#1554](https://github.com/bbatsov/projectile/issues/1554): Fix `projectile-files-with-string` failing on special characters when using `grep` or `git-grep` by adding the `-F` (fixed-string) flag.
- [#1897](https://github.com/bbatsov/projectile/issues/1897): Filter deleted-but-unstaged files from `git ls-files` output in alien/hybrid indexing (when `fd` is not used).
- [#1873](https://github.com/bbatsov/projectile/issues/1873): Skip unreadable directories during native indexing instead of aborting with a permission error.
- [#1961](https://github.com/bbatsov/projectile/issues/1961): Prevent directories from matching file-type project root markers (e.g., a `workspace` directory no longer matches the `WORKSPACE` Bazel marker on case-insensitive filesystems).
- [#1749](https://github.com/bbatsov/projectile/issues/1749): Strip `./` prefix from `fd` output in `projectile-files-via-ext-command`, fixing compatibility with older `fd` versions that don't support `--strip-cwd-prefix`.
- [#1942](https://github.com/bbatsov/projectile/pull/1942): Fix `projectile-ripgrep` failing on zsh when ignored file patterns contain glob characters, by quoting `--glob` arguments.
- [#1952](https://github.com/bbatsov/projectile/pull/1952): Fix CMake version parsing failing when `cmake --version` output contains extra text after the version number.
- [#1944](https://github.com/bbatsov/projectile/pull/1944): Fix Jujutsu file listing to use template syntax for null-byte-separated output, making it robust against user customization of `jj` output format.
- [#1986](https://github.com/bbatsov/projectile/pull/1986): Fix `projectile-purge-file-from-cache` serializing the stale file list to disk instead of the updated one.
- [#1986](https://github.com/bbatsov/projectile/pull/1986): Fix misplaced paren in `projectile-project-buffers-other-buffer` causing `switch-to-buffer` arguments to be ignored.
- [#1986](https://github.com/bbatsov/projectile/pull/1986): Fix `projectile-default-generic-command` silently dropping lambda/closure commands (only symbol commands worked).
- [#1986](https://github.com/bbatsov/projectile/pull/1986): Fix `dired-before-readin-hook` being added as buffer-local instead of global in `projectile-mode`, so it now correctly fires in all dired buffers.
- [#1986](https://github.com/bbatsov/projectile/pull/1986): Fix `projectile-find-dir-hook` not being cleaned up when disabling `projectile-mode`.
- [#1986](https://github.com/bbatsov/projectile/pull/1986): Use `display-warning` instead of `message` when cache serialization fails, making the failure visible in the `*Warnings*` buffer.

## 2.9.1 (2025-02-13)

### Bugs Fixed

- [#1929](https://github.com/bbatsov/projectile/pull/1929): Don't create cache files when `projectile-use-caching` is not set to `persistent`.

## 2.9.0 (2025-02-12)

### New features

- [#1870](https://github.com/bbatsov/projectile/pull/1870): Add package command for CMake projects.
- [#1875](https://github.com/bbatsov/projectile/pull/1875): Add support for Sapling VCS.
- [#1876](https://github.com/bbatsov/projectile/pull/1876): Add support for Jujutsu VCS.
- [#1877](https://github.com/bbatsov/projectile/pull/1877): Add custom variable `projectile-cmd-hist-ignoredups`.
- Add support for Eask projects.
- [#1892](https://github.com/bbatsov/projectile/pull/1892): Add category metadata to `completing-read`. (it's used by packages like `marginalia` and `embark`)
- [#1899](https://github.com/bbatsov/projectile/pull/1899): Add support for xmake build utility.
- [#1918](https://github.com/bbatsov/projectile/pull/1895): Add Zig project discovery.
- Add support for Swift project discovery.
- Introduce `projectile-global-ignore-file-patterns` config that allows to ignore files and directories with regexp patterns.
- Introduce `projectile-auto-cleanup-known-projects` option that allows you to auto-cleanup missing projects.

### Bugs fixed

- [#1881](https://github.com/bbatsov/projectile/issues/1881): Fix `projectile-recentf` when called outside any project.
- [#1915](https://github.com/bbatsov/projectile/pull/1915): Fix dotnet-sln project-type recognition. (check `*.sln` files instead of `src/`)
- [#1850](https://github.com/bbatsov/projectile/issues/1850): Ensure the presence of a project in `projectile-compilation-dir`.
- [#1811](https://github.com/bbatsov/projectile/issues/1811): Revert a change to `projectile-ignored-directories` that had converted them into regular expressions.
- [#1893](https://github.com/bbatsov/projectile/issues/1893): Fix `projectile-discover-projects-in-directory` when called interactively.

### Changes

- [#1874](https://github.com/bbatsov/projectile/pull/1874): Changes `compilation-find-file-projectile-find-compilation-buffer` to navigate directly to the file if already present on disk to help improve performance in scenarios where there are a large number of project directories.
- Drop support for Emacs 25.
- Rework the caching logic. The main changes from before are:

  - Each project has its own cache file
  - Cache files are consulted only when you request the files of some project

    This makes caching both more robust and faster, as before the cache file
    for all projects was loaded when projectile-mode was enabled.
- Make the cache transient by default. (meaning it lives only in memory and is not persisted to a file)
  - To enable persistent caching you need to set `projectile-enable-caching` to `'persistent`.
- Speed-up load time by moving known projects initialization outside of `projectile-mode`'s init.
  - As a side effect the known projects will be initialized properly even if you're not using `projectile-mode`.
  - The projects are read from disk the first time you invoke `projectile-switch-project` or a similar command.
- Introduce a common prefix for project lifecycle command keybindings:
  - `c o` -> `projectile-configure-project`
  - `c c` -> `projectile-compile-project`
  - `c p` -> `projectile-package-project`
  - `c i` -> `projectile-install-project`
  - `c t` -> `projectile-test-project`
  - `c r` -> `projectile-run-project`
  - The old keybindings will be removed in a future version of Projectile.

## 2.8.0 (2023-10-13)

### New features

- [#1862](https://github.com/bbatsov/projectile/pull/1862): Add project types "yarn" and "pnpm" separate from "npm".
- [#1851](https://github.com/bbatsov/projectile/pull/1851): Add ripgrep to `projectile-commander` with binding `?p`.
- [#1833](https://github.com/bbatsov/projectile/pull/1833): Add Julia project discovery.
- [#1828](https://github.com/bbatsov/projectile/pull/1828): Add Nimble-based Nim project discovery.
- Add elm project type.
- [#1821](https://github.com/bbatsov/projectile/pull/1821): Add `pyproject.toml` discovery for python projects.
- [#1830](https://github.com/bbatsov/projectile/issues/1830): Add command `projectile-run-vterm-other-window` and bind it to `x 4 v`.

### Changes

- [#1839](https://github.com/bbatsov/projectile/issues/1839): Ensure `projectile-toggle-between-implementation-and-test` also obeys `projectile-project-test-dir` and `projectile-project-src-dir`.
- [#1285](https://github.com/bbatsov/projectile/pull/1825): By default, use [fd](https://github.com/sharkdp/fd) in Git repositories instead of `git ls-files` when it is installed, in order to solve the problem where deleted files were still shown in `projectile-find-file` until their deletions were staged. The user-facing behavior should be the same, although potentially with different performance characteristics in large Git repositories. The old behavior can be reclaimed by setting `projectile-git-use-fd` to nil.
- [#1831](https://github.com/bbatsov/projectile/issues/1831): Enable the project.el integration only when `projectile-mode` is active.
- [#1847](https://github.com/bbatsov/projectile/issues/1847): Use literal directory name casing when toggling between impl and test.

### Bugs fixed

- Fix `fd` inserting color control sequences when used over tramp.
- [#1835](https://github.com/bbatsov/projectile/issues/1835): Reopening existing vterm buffer in other window
- [#1865](https://github.com/bbatsov/projectile/pull/1865): `projectile-generic-command` should use `projectile-fd-executable` to find the path for fd.

## 2.7.0 (2022-11-22)

### New features

- [#1591](https://github.com/bbatsov/projectile/issues/1591): Add `project.el` integration that will make Projectile the default provider for project lookup.
- Add new command `projectile-find-references` (bound to `C-c C-p ?` and `C-c C-p s x`).
- [#1737](https://github.com/bbatsov/projectile/pull/1737): Add helpers for `dir-local-variables` for 3rd party use. Functions `projectile-add-dir-local-variable` and `projectile-delete-dir-local-variable` wrap their built-in counterparts. They always use `.dir-locals.el` from the root of the current Projectile project.
- Add a new defcustom (`projectile-dirconfig-file`) controlling the name of the file used as Projectile’s root marker and configuration file.
- [#1813](https://github.com/bbatsov/projectile/pull/1813): Allow project-files to contain wildcards and allow multiple project-files per project type registration. Add a new project-type for .NET solutions.

### Changes

- [#1812](https://github.com/bbatsov/projectile/pull/1812): Add a `projectile-root-marked` function for finding roots marked by `.projectile`. Prioritize `.projectile` above other bottom-up root files.

### Bugs fixed

- [#1796](https://github.com/bbatsov/projectile/issues/1796): Fix `projectile-root-bottom-up` doesn't always find bottom-most file.
- [#1799](https://github.com/bbatsov/projectile/pull/1799): Fix `projectile-open-projects` lists projects for which all buffers are closed.
- [#1806](https://github.com/bbatsov/projectile/pull/1806): Fix `projectile-project-type` to return the correct project type even when we pass it the DIR arg. As a result of the fix,
`projectile-expand-root`, `projectile-detect-project-type`, `projectile-verify-files` , `projectile-verify-file` `projectile-verify-file-wildcard`, `projectile-cabal-project-p`,
`projectile-dotnet-project-p`, `projectile-go-project-p` and the newly factored out `projectile-eldev-project-p` now also takes an &optional DIR arg to specify the directory it is acting on.

## 2.6.0 (2022-10-25)

### New features

- [#1790](https://github.com/bbatsov/projectile/pull/1790): Add `src-dir` and `test-dir` properties for the mill project type.
- [#1778](https://github.com/bbatsov/projectile/pull/1778): Allow `projectile-replace` to select file extensions when using prefix arg (`C-u`).
- [#1757](https://github.com/bbatsov/projectile/pull/1757): Add support for the Pijul VCS.
- [#1745](https://github.com/bbatsov/projectile/pull/1745): Allow `projectile-update-project-type` to change project type precedence and remove project options.
- [#1699](https://github.com/bbatsov/projectile/pull/1699): `projectile-ripgrep` now supports [rg.el](https://github.com/dajva/rg.el).
- [#1712](https://github.com/bbatsov/projectile/issues/1712): Make it possible to hide Projectile's menu. See `projectile-show-menu`.
- [#1718](https://github.com/bbatsov/projectile/issues/1718): Add a project type definition for `GNUMakefile`.
- [#1747](https://github.com/bbatsov/projectile/pull/1747): Add support for preset-based install-commands for CMake projects.
- [#1768](https://github.com/bbatsov/projectile/pull/1768): Add support for disabling command caching on a per-project basis.
- [#1797](https://github.com/bbatsov/projectile/pull/1797): Make all project type attributes locally overridable.
- [#1803](https://github.com/bbatsov/projectile/pull/1803): Add support go-task/task.

### Bugs fixed

- [#1781](https://github.com/bbatsov/projectile/pull/1781): Fix `rails-rspec` and `rails-test` to use `app` instead of `lib` as `src-dir`.
- [#1762](https://github.com/bbatsov/projectile/pull/1762): Fix `projectile-globally-ignored-directories` unescaped regex.
- [#1713](https://github.com/bbatsov/projectile/issues/1731): Fix `projectile-discover-projects-in-directory` reordering known projects.
- [#1514](https://github.com/bbatsov/projectile/issues/1514): Fix `projectile-ag` global ignores not in effect.
- [#1714](https://github.com/bbatsov/projectile/issues/1714): Fix `projectile-discover-projects-in-directory` not interactive.
- [#1734](https://github.com/bbatsov/projectile/pull/1734): Make `projectile--find-matching-test` use `src-dir/test-dir` properties.
- [#1750](https://github.com/bbatsov/projectile/issues/1750): Fix source and test directories for Maven projects.
- [#1765](https://github.com/bbatsov/projectile/issues/1765): Fix `src-dir`/`test-dir` not defaulting to `"src/"` and `"test/"` with `projectile-toggle-between-implementation-and-test`.
- Fix version extraction logic.
- [1654](https://github.com/bbatsov/projectile/issues/1654) Fix consecutive duplicates appearing in command history.
- [#1755](https://github.com/bbatsov/projectile/issues/1755) Cache failure to find project root.

### Changes

- [#1785](https://github.com/bbatsov/projectile/pull/1785): Give the project type "go" higher precedence than universal types, namely "make".
- [#1447](https://github.com/bbatsov/projectile/issues/1447): Restructure the menu.
- [#1692](https://github.com/bbatsov/projectile/issues/1692): Enable minibuffer completions when reading shell-commands.
- Change the Grails project marker to `application.yml`.
- [#1789](https://github.com/bbatsov/projectile/pull/1789): Progress reporter for recursive progress discovery.
- [#1708](https://github.com/bbatsov/projectile/issues/1708): `projectile-ripgrep` now consistently searches hidden files.

## 2.5.0 (2021-08-10)

### New features

- [#1680](https://github.com/bbatsov/projectile/pull/1680): Add support for recursive project discovery.
- [#1671](https://github.com/bbatsov/projectile/pull/1671)/[#1679](https://github.com/bbatsov/projectile/pull/1679): Allow the `:test-dir` and `:src-dir` options of a project to be set to functions for more flexible test switching.
- [#1672](https://github.com/bbatsov/projectile/pull/1672): Add `projectile-<cmd>-use-comint-mode` variables (where `<cmd>` is `configure`, `compile`, `test`, `install`, `package`, or `run`). These enable interactive compilation buffers.
- [#1705](https://github.com/bbatsov/projectile/pull/1705): Add project detection for Nix flakes.

### Bugs fixed

- [#1550](https://github.com/bbatsov/projectile/issues/1550): Make `projectile-regenerate-tags` tramp-aware.
- [#1673](https://github.com/bbatsov/projectile/issues/1673): Fix CMake system-preset filename.
- [#1691](https://github.com/bbatsov/projectile/pull/1691): Fix `compilation-find-file` advice handling of directory.

### Changes

- Remove `pkg-info` dependency.

## 2.4.0 (2021-05-27)

### New features

- Add `projectile-update-project-type` function for updating the properties of existing project types.
- [#1658](https://github.com/bbatsov/projectile/pull/1658): New command `projectile-reset-known-projects`.
- [#1656](https://github.com/bbatsov/projectile/pull/1656): Add support for CMake configure, build and test presets. Enabled by setting `projectile-cmake-presets` to non-nil, disabled by default.
- Add optional parameters to `projectile-run-shell-command-in-root` and `projectile-run-async-shell-command-in-root`

### Changes

- Add `project` param to `projectile-generate-process-name`.
- [#1608](https://github.com/bbatsov/projectile/pull/1608): Use rebar3 build system by default for Erlang projects.
- Rename `projectile-project-root-files-functions` to `projectile-project-root-functions`.
- [#1647](https://github.com/bbatsov/projectile/issues/1647): Use "-B" in the mvn commands to avoid ANSI coloring clutter in the compile buffer
- [#1657](https://github.com/bbatsov/projectile/pull/1657): Add project detection for Debian packaging directories.
- [#1656](https://github.com/bbatsov/projectile/pull/1656): CMake compilation-dir removed to accommodate preset support, commands adjusted to run from project-root, with "build" still being the default build-directory. The non-preset test-command now uses "cmake" with "--target test" instead of "ctest".

### Bugs fixed

- [#1639](https://github.com/bbatsov/projectile/pull/1639): Do not ask twice for project running ielm, term and vterm.
- [#1250](https://github.com/bbatsov/projectile/issues/1250): Fix `projectile-globally-ignored-directories` not working with native indexing.
- [#1438](https://github.com/bbatsov/projectile/pull/1438): Make sure `projectile-files-via-ext-command` returns files, not errors.
- [#1450](https://github.com/bbatsov/projectile/pull/1450): Call `switch-project-action` within project's temp buffer.
- [#1340](https://github.com/bbatsov/projectile/pull/1340): Fix remote projects being removed if TRAMP can't connect.
- [#1655](https://github.com/bbatsov/projectile/pull/1655): Fix `projectile-replace-regexp` searching the wrong files when called with prefix arg.
- [#1659](https://github.com/bbatsov/projectile/issues/1659): Fix `projectile-project-vcs` to work outside a project.
- [#1637](https://github.com/bbatsov/projectile/pull/1661): Integrate with savehist-mode.

## 2.3.0 (2020-11-27)

### New features

- [#1517](https://github.com/bbatsov/projectile/issues/1517): Add project-specific compilation buffers and only ask to save files in the project when compiling.
- New functions `projectile-acquire-root` and `projectile-process-current-project-buffers-current`
- New project commands `projectile-package-project`, `projectile-install-project`.
- [#1539](https://github.com/bbatsov/projectile/pull/1539): New defcustom `projectile-auto-discover` controlling whether to automatically discover projects in the search path when `projectile-mode` activates.
- Add [emacs-eldev](https://github.com/doublep/eldev) project type.
- Add Dart project type.
- [#1555](https://github.com/bbatsov/projectile/pull/1555): Add search with ripgrep.
- Add Python-poetry project type.
- [#1576](https://github.com/bbatsov/projectile/pull/1576): Add OCaml [Dune](https://github.com/ocaml/dune) project type.
- Add [Mill](http://www.lihaoyi.com/mill/) project type.
- Auto-detect completion system, supporting `ido`, `ivy`, `helm` and the default completion system.

### Changes

- [#1540](https://github.com/bbatsov/projectile/pull/1540): Add default `test-suffix` to Angular projects.
- Add a `:project-file` param to `projectile-register-project-type`.
- [#1588](https://github.com/bbatsov/projectile/pull/1588): Improve performance of `projectile-ibuffer` with many buffers not in project.
- [#1601](https://github.com/bbatsov/projectile/pull/1601): Implement separate compilation command history for each project.

### Bugs fixed

- [#1377](https://github.com/bbatsov/projectile/issues/1377): Fix `projectile-regenerate-tags` directory.

## 2.2.0 (2020-06-10)

### New features

- [#1523](https://github.com/bbatsov/projectile/issues/1523): Add a new defcustom (`projectile-max-file-buffer-count`) controlling how many opened file buffers should Projectile maintain per project.
- Optional support for comments in .projectile dirconfig files using `projectile-dirconfig-comment-prefix`.
- [#1497](https://github.com/bbatsov/projectile/pull/1497): New command `projectile-run-gdb` (<kbd>x g</kbd> in `projectile-command-map`).
- Add [Bazel](https://bazel.build) project type.

### Bugs fixed

- [#1503](https://github.com/bbatsov/projectile/pull/1503): Leave archive before searching for the project root.

### Changes

- [#1528](https://github.com/bbatsov/projectile/pull/1528): Improve massively the performance of native indexing (it's around 10x faster now).

## 2.1.0 (2020-02-04)

### New features

- [#1486](https://github.com/bbatsov/projectile/pull/1486) Allow `projectile-run-shell/eshell/term/vterm/ielm` to start extra processes if invoked with the prefix argument.
- New command `projectile-run-vterm` (<kbd>x v</kbd> in `projectile-command-map`).
- Add `related-files-fn` option to use custom function to find test/impl/other files.
- [#1019](https://github.com/bbatsov/projectile/issues/1019): Jump to a test named the same way but in a different directory.
- [#982](https://github.com/bbatsov/projectile/issues/982): Add heuristic for projectile-find-matching-test.
- Support a list of functions for `related-files-fn` options and helper functions.
- [#1405](https://github.com/bbatsov/projectile/pull/1405): Add Bloop Scala build server project detection.
- [#1418](https://github.com/bbatsov/projectile/pull/1418): The presence of a `go.mod` file implies a go project.
- [#1419](https://github.com/bbatsov/projectile/pull/1419): When possible, use [fd](https://github.com/sharkdp/fd) instead
of `find` to list the files of a non-VCS project. This should be much faster.

### Bugs fixed

- [#675](https://github.com/bbatsov/projectile/issues/675): Performance improvement for native project indexing strategy.
- [#97](https://github.com/bbatsov/projectile/issues/97): Respect `.projectile` ignores which are paths to files and patterns when using `projectile-grep`.
- [#1391](https://github.com/bbatsov/projectile/issues/1391): A `.cabal` sub-directory is no longer considered project indicator.
- [#1385](https://github.com/bbatsov/projectile/issues/1385): Update `projectile-replace` for Emacs 27.
- [#1432](https://github.com/bbatsov/projectile/issues/1432): Support .NET project.
- [#1270](https://github.com/bbatsov/projectile/issues/1270): Fix running commands that don't have a default value.
- [#1475](https://github.com/bbatsov/projectile/issues/1475): Fix directories being ignored with hybrid mode despite being explicitly unignored.
- [#1482](https://github.com/bbatsov/projectile/issues/1482): Run a separate grep buffer per project root.
- [#1488](https://github.com/bbatsov/projectile/issues/1488): Fix `projectile-find-file-in-directory` when in a subdir of `projectile-project-root`.

## 2.0.0 (2019-01-01)

### New features

- [#972](https://github.com/bbatsov/projectile/issues/972): Add toggle for project read only mode: `projectile-toggle-project-read-only`.
- New interactive command `projectile-run-ielm`.
- Add [crystal](https://crystal-lang.org) project type.
- [#850](https://github.com/bbatsov/projectile/issues/850): Make it possible to prompt for a project, when you're not in a project, instead of raising an error. (see `projectile-require-project-root`).
- [#1147](https://github.com/bbatsov/projectile/issues/1147): Introduce a new indexing method called `hybrid` which behaves like the old `alien`.
- [#896](https://github.com/bbatsov/projectile/issues/896) Add commands `projectile-previous-project-buffer` and
`projectile-next-project-buffer` to switch to other buffer in the project.
- [#1016](https://github.com/bbatsov/projectile/issues/1016): Add a new defcustom (`projectile-current-project-on-switch`) controlling what to do with the current project on switch.
- [#1233](https://github.com/bbatsov/projectile/issues/1233): Add a new defcustom (`projectile-kill-buffers-filter`) controlling which buffers are killed by `projectile-kill-buffers`.
- [#1279](https://github.com/bbatsov/projectile/issues/1279): Add command `projectile-repeat-last-command` to re-execute the last external command in a project.

### Changes

- **(Breaking)** [#1147](https://github.com/bbatsov/projectile/issues/1147): Remove any post-processing from the `alien` indexing method.
- Specify project path for `projectile-regenerate-tags`.
- Handle files with special characters in `projectile-get-other-files`.
- [#1260](https://github.com/bbatsov/projectile/pull/1260): ignored-*-p: Now they match against regular expressions.
- **(Breaking)** Remove the default prefix key (`C-c p`) for Projectile. Users now have to pick one themselves.
- Deprecate `projectile-keymap-prefix`.
- Avoid "No projects needed to be removed." messages in global mode.
- [#1278](https://github.com/bbatsov/projectile/issues/1278): Add default `test-suffix` to `npm` project.
- [#1285](https://github.com/bbatsov/projectile/pull/1285): Add default `test-suffix` to Python projects.
- [#1285](https://github.com/bbatsov/projectile/pull/1285): Add support for Pipenv-managed Python projects.
- [#1232](https://github.com/bbatsov/projectile/issues/1232): Stop evaluating code dynamically in the mode-line and switch to a simpler scheme where the mode-line is updated just once using `find-file-hook`.
- Make the mode line configurable via `projectile-dynamic-mode-line` and `projectile-mode-line-function`.
- [#1205](https://github.com/bbatsov/projectile/issues/1205): Check that project directory exists when switching projects.
- Move Projectile's menu out of the "Tools" menu.
- [API] **(Breaking)** Stop raising errors from `projectile-project-root` if not invoked within a project. Now it will simply return nil. Use it together with `projectile-ensure-project` to emulate the old behavior.

### Bugs fixed

- [#1315](https://github.com/bbatsov/projectile/issues/1315): Give preference to the project types that were registered last.
- [#1367](https://github.com/bbatsov/projectile/issues/1367): Fix the Makefile so that we can compile projectile - use `make`.

## 1.0.0 (2018-07-21)

### New Features

- [#1255](https://github.com/bbatsov/projectile/pull/1255): Add support for function symbols as project default commands
- [#1243](https://github.com/bbatsov/projectile/pull/1243): Add [angular](https://angular.io) project support.
- [#1228](https://github.com/bbatsov/projectile/pull/1228): Add support for a prefix argument to `projectile-vc`.
- [#1221](https://github.com/bbatsov/projectile/pull/1221): Modify Ruby and Elixir project settings.
- [#1175](https://github.com/bbatsov/projectile/pull/1175): Add a command `projectile-configure-command` for running a configuration for build systems that need that.
- [#1168](https://github.com/bbatsov/projectile/pull/1168): Add CMake and Meson project support.
- [#1159](https://github.com/bbatsov/projectile/pull/1159) Add [nix](http://nixos.org) project support.
- [#1166](https://github.com/bbatsov/projectile/pull/1166): Add `-other-frame` versions of commands that had `-other-window` versions.
- Consider Ensime configuration file as root marker, `.ensime`.
- [#1057](https://github.com/bbatsov/projectile/issues/1057): Make it possible to disable automatic project tracking via `projectile-track-known-projects-automatically`.
- Added ability to specify test files suffix and prefix at the project registration.
- [#1154](https://github.com/bbatsov/projectile/pull/1154) Use npm install instead of build.
- Added the ability to expire old files list caches via `projectile-projectile-files-cache-expire`.
- [#1204](https://github.com/bbatsov/projectile/pull/1204): `projectile-register-project-type` can now be used to customize the source and test directory via `:src-dir` and `:test-dir` for projects with custom needs (eg. maven).
- [#1240](https://github.com/bbatsov/projectile/pull/1240): Add some integration with ripgrep.
- Add `projectile-project-search-path`, which is auto-searched for projects when `projectile-mode` starts.
- Add `projectile-discover-projects-in-search-path` command which searches for projects in `projectile-project-search-path`.
- Auto-cleanup missing known-projects on `projectile-mode` start.

### Changes

- [#1213](https://github.com/bbatsov/projectile/pull/1213): Cache project root in non-file-backed buffers.
- [#1175](https://github.com/bbatsov/projectile/pull/1175): `projectile-register-project-type` can now set a default compilation directory for build systems that need to build out-of-tree (eg. meson).
- [#1175](https://github.com/bbatsov/projectile/pull/1175): `projectile-{test,run}-project` now run inside `(projectile-compilation-dir)`, just like `projectile-compile-project`.
- [#1175](https://github.com/bbatsov/projectile/pull/1175): `projectile-{test,run}-project` now stores the default command per directory instead of per project, just like `projectile-compile-project`.
- Cache the root of the current project to increase performance
- [#1129](https://github.com/bbatsov/projectile/pull/1129): Fix TRAMP issues.
- Add R DESCRIPTION file to `projectile-project-root-files`.
- Ignore backup files in `projectile-get-other-files`.
- Ignore Ensime cache directory, `.ensime_cache`.
- [#364](https://github.com/bbatsov/projectile/issues/364): `projectile-add-known-project` can now be used interactively.
- `projectile-mode` is now a global mode.
- `projectile-find-tag` now defaults to xref on Emacs 25.1+.
- Add relation between `.h` and `.cc` files in `projectile-other-file-alist`.
- Cache the name of the current project for mode-line display of the project name.
- [#1078](https://github.com/bbatsov/projectile/issues/1078): For projectile-grep/ag use default value like grep/rgrep/ag.
- Don't treat `package.json` as a project marker.
- [#987](https://github.com/bbatsov/projectile/issues/987): projectile-ag ignores ag-ignore-list when projectile-project-vcs is git
- [#1119](https://github.com/bbatsov/projectile/issues/1119): File search ignores non-root dirs if prefixed with "*"
- Treat members of `projectile-globally-ignored-file-suffixes` as file name suffixes (previously treated as file extensions).
- Ensure project roots are added as directory names to avoid near-duplicate projects, e.g. "~/project/" and "~/project".
- Don't autoload defcustoms.
- **(Breaking)** Require Emacs 25.1.
- Remove the support for grizzl.

### Bugs fixed

- [#1222](https://github.com/bbatsov/projectile/issues/1222): `projectile-configure-project` fails for generic project type
- [#1162](https://github.com/bbatsov/projectile/issues/1162): `projectile-ag` causes "Attempt to modify read-only object" error.
- [#1169](https://github.com/bbatsov/projectile/issues/1169): `projectile-compile-project` does not prompt for compilation command.
- [#1072](https://github.com/bbatsov/projectile/issues/1072): Create test files only within the project.
- [#1063](https://github.com/bbatsov/projectile/issues/1063): Support Fossil checkouts on Windows.
- [#1024](https://github.com/bbatsov/projectile/issues/1024): Do not cache ignored project files.
- [#1022](https://github.com/bbatsov/projectile/issues/1022): Scan for Fossil's checkout DB, not its config DB.
- [#1007](https://github.com/bbatsov/projectile/issues/1007): Make use of `projectile-go-function`.
- [#1011](https://github.com/bbatsov/projectile/issues/1011): Save project files before running project tests.
- [#1099](https://github.com/bbatsov/projectile/issues/1099): Fix the behaviour of `projectile-purge-dir-from-cache`.
- [#1067](https://github.com/bbatsov/projectile/issues/1067): Don't mess up `default-directory` after switching projects.
- [#1246](https://github.com/bbatsov/projectile/issues/1246): Don't blow away real project file during tests.

## 0.14.0 (2016-07-08)

### New features

- Add [elixir](http://elixir-lang.org) project type.
- Add [emacs-cask](https://github.com/cask/cask) project type.
- Add [boot-clj](https://github.com/boot-clj/boot) project type.
- Add [racket](http://racket-lang.org) project type.
- Add support for projects using gradlew script.
- Prefer Haskell stack projects over cabal projects.
- Add ability to use elisp functions for test, compile and run commands.
- Consider `TAGS` and `GTAGS` root markers.
- Add relation between the `.h`, `.cxx`, `.ixx` and `.hxx` files in `projectile-other-file-alist`.
- Add relation between the `.hpp` and `.cc` files in `projectile-other-file-alist`.
- Add support to specify project name either via `.dir-locals.el` or by providing a customized `projectile-project-name-function`.
- Add a command to switch between open projects (`projectile-switch-open-project`).
- Add a command to edit the .dir-locals.el file of the project (`projectile-edit-dir-locals`).
- Add file local variable `projectile-project-root`, which allows overriding the project root on a per-file basis. This allows navigating a different project from, say, an org file in a another git repository.
- Add `projectile-grep-finished-hook`.
- Ignore file suffixes listed in `projectile-globally-ignored-file-suffixes` when using `projectile-grep` and `projectile-ag`.
- Add `projectile-replace-regexp`, which supports replacement by regexp within a project. `projectile-replace` is now used solely for literal replacements.
- New command `projectile-run-shell` (<kbd>C-c p x s</kbd>).
- New command `projectile-run-eshell` (<kbd>C-c p x e</kbd>).
- New command `projectile-run-term` (<kbd>C-c p x t</kbd>).
- [#971](https://github.com/bbatsov/projectile/pull/971): Let user unignore files in `.projectile` with the ! prefix.
- Add a command to add all projects in a directory to the cache (`projectile-discover-projects-in-directory`).
- Add a command to list dirty version controlled projects (`projectile-browse-dirty-projects`).

### Changes

- Prefer ag's internal .gitignore parsing.
- Added variable to control use of external find-tag implementations.
- Specify `--with-keep.source` argument when installing R projects

### Bugs fixed

- [#871](https://github.com/bbatsov/projectile/issues/871): Stop advice for `compilation-find-file` to override other advices.
- [#557](https://github.com/bbatsov/projectile/issues/557): stack overflow in `projectile-find-tag`.
- [#955](https://github.com/bbatsov/projectile/issues/955): Error while toggling between test and source file.
- [#952](https://github.com/bbatsov/projectile/issues/952): VCS submodules brought in even though not descendent of project root.
- [#576](https://github.com/bbatsov/projectile/issues/576): `projectile-replace` stomps regular expressions.
- [#957](https://github.com/bbatsov/projectile/pull/957): When opening a specified file from the terminal, do not error inside of `projectile-cache-current-file`.
- [#984](https://github.com/bbatsov/projectile/pull/984): Error when a project is a symlink that changes target.
- [#1013](https://github.com/bbatsov/projectile/issues/1013): `projectile-project-buffer-p` may return incorrect result on Windows.

## 0.13.0 (2015-10-21)

### New features

- Add `projectile-before-switch-project-hook`.
- Add the ability to specify the project type via `.dir-locals.el`.
- Add support for projects using Midje.
- Add the ability to create missing tests automatically (controlled via the `projectile-create-missing-test-files` defcustom).
- Add the ability to dynamically decide if a project should be added to `projectile-known-projects` (via new `projectile-ignored-project-function` defcustom).
- Add the ability to register new project types dynamically with `projectile-register-project-type`.
- Add the ability to specify a project compilation and test commands via `.dir-locals.el`.
This is done via the variables `projectile-project-compilation-cmd` and `projectile-project-test-cmd`.
- [#489](https://github.com/bbatsov/projectile/issues/489): New interactive command `projectile-run-project`.
- Optionally run [monky](http://ananthakumaran.in/monky/) on Mercurial projects.
- Add the ability to specify a project compilation directory relative to the root directory via `.dir-locals.el` with the variable `projectile-project-compilation-dir`.
- When there is a selected region, projectile-ag, projectile-grep, projectile-replace and projectile-find-tag uses its content as a search term instead of symbol at point.

### Changes

- Rename `projectile-switch-project-hook` to `projectile-after-switch-project-hook`.
- `projectile-compile-project` now offers appropriate completion
targets even when called from a subdirectory.
- Add an argument specifying the regexp to search to `projectile-grep`.
- Use `helm-projectile-grep` instead of `helm-find-file` when selecting a project.
- Omit current buffer from `projectile-switch-to-buffer` and `projectile-switch-to-buffer-other-window` choices.

### Bugs fixed

- [#721](https://github.com/bbatsov/projectile/issues/721#issuecomment-100830507): Remove current buffer from `helm-projectile-switch-project`.
- [#667](https://github.com/bbatsov/projectile/issues/667) Use `file-truename` when caching filenames to prevent duplicate/symlinked filepaths from appearing when opening a project file.
- [#625](https://github.com/bbatsov/projectile/issues/625): Ensure the directory has a trailing slash while searching for it.
- [#763](https://github.com/bbatsov/projectile/issues/763): Check for `projectile-use-git-grep` in `helm-projectile-grep`
- Fix `projectile-parse-dirconfig-file` to parse non-ASCII characters properly.

## 0.12.0 (2015-03-29)

### New features

- Replace Helm equivalent commands in `projectile-commander` when using Helm.
- Add replacement commands projectile-grep, projectile-ack and projectile-ag with their Helm versions.
- Add virtual directory manager that allows to create/update (add or delete files) a Dired buffer based on Projectile files.
- Add a new Helm command: `helm-projectile-find-file-in-known-projects` that opens all files in all known projects.
- Add an action for `helm-projectile-switch-project` to delete multiple marked projects.
- Add the ability to retrieve files in all sub-projects under a project root.
- Add `projectile-find-file-dwim` and `helm-projectile-find-file-dwim` commands.
- Provide actual Helm commands for common Projectile commands.
- Use existing Helm actions and map in `helm-find-files` that allows `helm-source-projectile-files-list`
to behave like `helm-find-files`, such as multifile selection and opening or delete on selected files.
- Add compile action to `helm-projectile`.
- Allows using Eshell and Magit outside of a project in `helm-projectile`.
- Add Helm action for incremental grep in the selected projects.
- Add command projectile-find-other-file  Switch between files with
the same  name but different extensions.
- Add Helm interface to switch project. For more details checkout the file
README.md.
- Make the mode line format customizable with `projectile-mode-line`
- Add support for `cargo.toml` projects
- Try to use projectile to find files in compilation buffers
- Support `helm` as a completion system
- New command `projectile-project-info` displays basic info about the current project.
- New `defcustom` `projectile-globally-ignored-buffers` allows you to ignore
buffers by name
- New `defcustom` `projectile-globally-ignored-file-suffixes` allows
you to globally ignore files with particular extensions

### Changes

- get-other-files returns more accurate results for files with the same name placed under different directories
- Collect search tool (`grep`, `ag`, `ack`) keybindings under a common keymap prefix (`C-c p s`)
- Remove `defcustom` `projectile-remember-window-configs` in favor of
`persp-projectile.el`.
- Progress reporter for the native indexing method.

### Bugs fixed

- Fix `projectile-regenerate-tags` to work in directories that include spaces.
- Prevent `projectile-kill-buffers` from trying to kill indirect
buffers.
- [#412](https://github.com/bbatsov/projectile/issues/412): Handle multiple possible targets in `projectile-toggle-between-implementation-or-test`.

## 0.11.0 (2014-05-27)

### New features

- Added support for default file glob pattern to `projectile-grep`
- added file existence cache with defcustoms
`projectile-file-exists-remote-cache-expire` and
`projectile-file-exists-local-cache-expire`.
- added new defcustoms `projectile-project-root-files-top-down-recurring`,
`projectile-project-root-files-bottom-up` and
`projectile-project-root-files-functions`.
- Added new command `projectile-save-project-buffers`.
- Added new command `projectile-cleanup-known-projects`.
- Added new commands `projectile-display-buffer`
and `projectile-find-dir-other-window`.
- Added new interactive function `projectile-project-buffers-other-buffer`
which runs new `projectile-project-buffers-non-visible` function, the former
is bound to `C-c p ESC`.
- New variable `projectile-enable-idle-timer` turns on an idle timer
which runs the hook `projectile-idle-timer-hook` every
`projectile-idle-timer-seconds` seconds when non-nil.
- New defcustom `projectile-remember-window-configs` will make
`projectile-switch-project` restore the most recent window configuration (if
any) of the target project.
- New command `projectile-run-command-in-root`.
- New command `projectile-run-shell-command-in-root`.
- New command `projectile-run-async-shell-command-in-root`.
- New defcustom `projectile-use-git-grep` will make `projectile-grep` use `git grep`
for git projects.
- Added new `projectile-commander` methods ?v and ?R which run
`projectile-vc` and `projectile-regenerate-tags`, respectively.
- `projectile-vc` will use `magit-status` if available.
- New functions `projectile-find-implementation-or-test` and
`projectile-find-implementation-or-test-other-window`, the latter is
bound to `C-c p 4 t`.
- New defcustoms `projectile-test-prefix-function` and `projectile-test-suffix-function`
allow users to customize how projectile identifies test files by project type.
- `projectile-grep` will ask for a file pattern if invoked with a
prefix argument.
- Subversion checkouts are now automatically detected.
- CVS checkouts are now automatically detected.
- added `projectile-persp-switch-project` command to make perspective
mode work along with projectile.
- Changed `projectile-mode-line-lighter` to a defcustom variable to make
mode line indicator prefix customizable.
- New command `projectile-find-file-in-known-projects`.
- New defcustom `projectile-ignored-projects` allows you to specify projects
that shouldn't be added to the known projects list.
- New command `projectile-remove-current-project-from-known-projects`.
- New defcustom `projectile-buffers-filter-function`.
- New defcustom `projectile-sort-order`.
- New function `projectile-process-current-project-buffers`.
- New function `projectile-process-current-project-files`.

### Changes

- The presence of a `Makefile` is no longer taken as an indicator
of the project root by default, since recursive make is unfortunately
a common occurrence (affects `projectile-project-root-files`).
- Projectile is now able to find the project pertaining to a symlink
pointing to a version-controlled file.
- Drop `projectile-ack-function` defcustom.
- `projectile-command-map` is now the keymap referenced by the
`projectile-keymap-prefix` in `projectile-mode-map`. This allows
modification of the inner map, and allows additional prefix keys to
reference it.

### Bugs fixed

- Modified `projectile-ack` to append to `ack-and-a-half-arguments`
instead of overriding them.
- [#229] Fix `projectile-find-file-in-directory`'s behavior for project directories
- `projectile-toggle-between-implementation-or-test` shows
understandable error if current buffer is not visiting a file.
- [#244] Correct folder picked up by `projectile-ack` after project-switch.
- [#182] Invalidate project cache if .projectile is modified.

## 0.10.0 (2013-12-09)

### New features

- Added new command `projectile-find-file-other-window`.
- Added new command `projectile-switch-to-buffer-other-window`.
- Added new command `projectile-find-file-in-directory` that allows
you to jump to files in any directory.
- `.projectile` is now always taken into account.
- `projectile-switch-project`'s behavior is now customizable via
`projectile-switch-project-action`.
- Added support for Gradle projects.
- Added support for `Ag`.
- Added new command `projectile-purge-file-from-cache`.
- Added new command `projectile-purge-dir-from-cache`.
- Added new command `projectile-find-tag`.
- Added new command `projectile-commander`. It allows you to quickly
run many Projectile commands with a single key. Very useful as a
project-switching action.
- `projectile-switch-project` now supports a prefix argument. When it's present
the switch action is `projectile-commander`.

### Changes

- Replaced variable `projectile-use-native-indexing` with `projectile-indexing-method`.
- Corrected grammar on error message for not being in a project.

### Bug fixes

- `projectile-find-test-file` now properly displays only test files (#145).

## 0.9.2 (2013-07-16)

### New features

- `projectile-invalidate-cache` now accepts a prefix argument. When
present you'll be prompted for the project whose cache to
invalidate.
- New command `projectile-find-dir` works similar to
`projectile-find-file` - displays the project's dirs and opens them
with `dired`. It's bound to `C-c p d`.
- Added support for `grizzl` as a completion system.
- Added support for `fossil` projects.
- Added support for `Symfony 2` project.
- New command `projectile-clear-known-projects` removes all known projects.
- New command `projectile-remove-known-project` prompts you for a known project to remove.

### Bugs fixed

- Fixed `projectile-replace`, which was broken from the use of relative paths
- #103 - `projectile-switch-project` does not require a project to work
- Don't show hidden buffers in projectile-project-buffers

### Changes

- Rebound `projectile-compile-project` to <kbd>C-c p c</kbd>
- Rebound `projectile-dired` to <kbd>C-c p D</kbd>
- Reworked `projectile-compile-project` and `projectile-test-project`
to be smarter, more configurable and closer in behavior to the stock
`compile` command
- `projectile-switch-project` (<kbd>C-c p s</kbd>) now runs `projectile-find-file` instead of `dired`.

## 0.9.1 (2013-04-26)

### New features

- Display recentf files in helm-projectile.

### Bugs fixed

- #95 - handle properly missing project root

## 0.9.0 (2013-04-24)

### New features

- Use fast external tools to find project files when possible. This is the default option on all Unices.
- Removed obsolete command `projectile-reindex-project`.
- Removed obsolete command `projectile-open`.
- Introduced support for finding tests and switching between code and tests.
- Implement basic project type detection.
- Add a simple version reporting command projectile-version.
- Display relative paths to project files instead of disambiguated filenames.
- Directories listed in .projectile file are excluded when tags are generated.
- Remembers visited projects and may switch between them with `projectile-switch-project`.
- Supports `lein {compile|test}` in Clojure projects.
- Support projects only for subdirs of the project root.
- Add the ability to manually cache files.

### Bugs fixed

- #57 - properly set the current working dir, before invoking shell commands
- #71 - correct regenerate tags keybinding in the README

### Misc

- Move menu entry under `Tools`
- Show indexing message only when doing native project indexing
- Massive performance improvements
