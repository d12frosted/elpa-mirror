;; Generated package description from evil-visualstar.el  -*- no-byte-compile: t -*-
(define-package "evil-visualstar" "0.2.0.0.20160222.194815" "Starts a * or # search from the visual selection" '((evil "0")) :commit "06c053d8f7381f91c53311b1234872ca96ced752" :keywords '("evil" "vim" "visualstar") :url "https://github.com/bling/evil-visualstar")
