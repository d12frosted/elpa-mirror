;; Generated package description from haskell-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "haskell-mode" "17.5.0.20261124.74" "A Haskell editing mode" '((emacs "25.1")) :commit "f8309349a87c14150a4dfec4171db7c22dc6fda3" :keywords '("haskell" "cabal" "ghc" "repl" "languages") :url "https://github.com/haskell/haskell-mode")
