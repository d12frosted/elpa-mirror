;; Generated package description from flx-ido.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "flx-ido" "0.6.2.0.20260820.11" "flx integration for ido" '((emacs "24.1") (flx "0.1") (cl-lib "0.3")) :commit "6803eca89d0c4c7871433c993463e66aabf77443" :url "https://github.com/lewang/flx")
