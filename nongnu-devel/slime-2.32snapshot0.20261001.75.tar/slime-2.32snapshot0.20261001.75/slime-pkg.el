;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20261001.75" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "82dfda1a83e22de6fad93f54f3201f5dec6754fb" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
