;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261103.322" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "4f6d2d856dff1eaaa460a7e6c885c110b461c17b" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
