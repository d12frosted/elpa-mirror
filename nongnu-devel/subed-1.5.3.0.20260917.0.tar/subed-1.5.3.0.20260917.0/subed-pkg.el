;; Generated package description from subed.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "subed" "1.5.3.0.20260917.0" "A major mode for editing subtitles" '((emacs "25.1")) :commit "581d53e80518ddba48432f439bd73b4e208bec60" :maintainer '("Sacha Chua" . "sacha@sachachua.com") :keywords '("convenience" "files" "hypermedia" "multimedia") :url "https://github.com/sachac/subed")
