;; Generated package description from loopy-dash.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy-dash" "0.13.0.0.20260718.11" "Dash destructuring for `loopy'" '((emacs "28.1") (loopy "0.13.0") (dash "2.20")) :commit "d98d1a0a7b2d97a5a3517a7e3f5cc941d2331413" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy-dash")
