;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261118.418" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "f0460033ef60baa04a989f565a79d5f871196df4" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
