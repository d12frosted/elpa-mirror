;; Generated package description from loopy.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "loopy" "0.16.1.0.20260703.2" "A looping macro" '((emacs "28.1") (map "3.3.1") (seq "2.22") (compat "29.1.3") (stream "2.4.0")) :commit "5cd39a76ed340c69f07e7d5116b1df2e297e31cd" :keywords '("extensions") :url "https://codeberg.org/okamsn/loopy")
