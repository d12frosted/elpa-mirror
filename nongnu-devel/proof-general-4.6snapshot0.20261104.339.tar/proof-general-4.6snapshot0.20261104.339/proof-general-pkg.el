;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261104.339" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "e418af92903c1c174db08bc29f25dfee1197dd1b" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
