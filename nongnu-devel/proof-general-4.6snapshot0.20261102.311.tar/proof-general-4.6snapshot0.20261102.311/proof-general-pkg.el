;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261102.311" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "587a3de1ea98f8f38266b4b1151c2d598dd948dc" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
