;; Generated package description from vm.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "vm" "8.3.3snapshot0.20260727.55" "VM mail reader" '((emacs "28.1") (vcard "0.2.2")) :commit "88361f97daa22a4df0a49c0f4b93e257ecba8a5b" :maintainer '(nil . "viewmail-info@nongnu.org") :keywords '("mail") :url "https://gitlab.com/emacs-vm/vm")
