;; Generated package description from hideshowvis.el  -*- no-byte-compile: t -*-
(define-package "hideshowvis" "0.9.0.20251119.95800" "Fringe markers for regions foldable by hideshow.el" '((emacs "27.1")) :commit "cfae9e1f57804a557b81bb1ad778ef355877bc72" :authors '(("Jan Rehders" . "jan@sheijk.net")) :maintainer '("Jan Rehders" . "jan@sheijk.net") :url "https://github.com/sheijk/hideshowvis")
