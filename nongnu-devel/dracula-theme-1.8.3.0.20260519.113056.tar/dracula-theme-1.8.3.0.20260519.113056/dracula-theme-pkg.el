;; Generated package description from dracula-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "dracula-theme" "1.8.3.0.20260519.113056" "Dracula Theme" '((emacs "24.3")) :commit "f7ee0933b93a34a9f9cf6117293afef6c2464d9d" :maintainer '("tienne Deparis" . "etienne@depar.is") :url "https://github.com/dracula/emacs")
