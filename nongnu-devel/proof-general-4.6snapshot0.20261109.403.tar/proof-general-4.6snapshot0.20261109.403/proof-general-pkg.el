;; Generated package description from proof-general.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "proof-general" "4.6snapshot0.20261109.403" "A generic Emacs interface for proof assistants" '((emacs "25.2")) :commit "9a579a70bcc5c3a0b8fb921a135759c3b12f738a" :maintainer '(nil . "proof-general-maintainers@groupes.renater.fr") :url "https://proofgeneral.github.io/")
