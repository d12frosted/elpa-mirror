;; Generated package description from slime.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "slime" "2.32snapshot0.20260904.67" "Superior Lisp Interaction Mode for Emacs" '((emacs "24.3") (macrostep "0.9")) :commit "990ad02bd5b9830245e4df6bcdbfe96ce05d1c5f" :keywords '("languages" "lisp" "slime") :url "https://github.com/slime/slime")
