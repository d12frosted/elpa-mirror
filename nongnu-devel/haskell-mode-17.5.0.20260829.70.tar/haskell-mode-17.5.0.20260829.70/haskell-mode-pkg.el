;; Generated package description from haskell-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "haskell-mode" "17.5.0.20260829.70" "A Haskell editing mode" '((emacs "25.1")) :commit "d252d4a6feb3b15e4d0be88e6a42b98d8f5766ba" :keywords '("haskell" "cabal" "ghc" "repl" "languages") :url "https://github.com/haskell/haskell-mode")
