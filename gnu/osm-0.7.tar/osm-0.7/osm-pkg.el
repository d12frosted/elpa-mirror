;; Generated package description from osm.el  -*- no-byte-compile: t -*-
(define-package "osm" "0.7" "OpenStreetMap viewer" '((emacs "27.1")) :commit "e3ea969ce1bf84343f357efa2de97e1dd857f481" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/osm")
