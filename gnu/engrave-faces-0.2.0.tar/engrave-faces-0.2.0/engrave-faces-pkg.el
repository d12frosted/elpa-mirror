;; Generated package description from engrave-faces.el  -*- no-byte-compile: t -*-
(define-package "engrave-faces" "0.2.0" "Convert font-lock faces to other formats" '((emacs "27.1")) :keywords '("faces") :authors '(("TEC <https://github/tecosaur>")) :maintainer '("TEC" . "tec@tecosaur.com") :url "https://github.com/tecosaur/engrave-faces")
