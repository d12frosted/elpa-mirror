;; Generated package description from jarchive.el  -*- no-byte-compile: t -*-
(define-package "jarchive" "0.3.0" "Open project dependencies in jar archives" '((emacs "26.1")) :commit "bfcc201cca1546c7646912956168e5e840c2d6a0" :maintainer '("Danny Freeman" . "danny@dfreeman.email>") :keywords '("tools" "languages" "jvm" "java" "clojure") :url "https://git.sr.ht/~dannyfreeman/jarchive")
