;; Generated package description from mct.el  -*- no-byte-compile: t -*-
(define-package "mct" "0.4.2" "Minibuffer and Completions in Tandem" '((emacs "27.1")) :commit "e250562c531578c88f91db7cad1210f56adcf095" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://gitlab.com/protesilaos/mct")
