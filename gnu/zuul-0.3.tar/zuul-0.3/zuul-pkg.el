;; Generated package description from zuul.el  -*- no-byte-compile: t -*-
(define-package "zuul" "0.3" "Interface to Zuul" '((emacs "28.1")) :commit "c515b22c32f1306e920489868920957e3ebd1e2f" :authors '(("Niklas Eklund" . "niklas.eklund@posteo.net")) :maintainer '("Niklas Eklund" . "niklas.eklund@posteo.net") :keywords '("convenience" "tools") :url "https://git.sr.ht/~niklaseklund/zuul.el")
