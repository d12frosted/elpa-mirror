;; Generated package description from jarchive.el  -*- no-byte-compile: t -*-
(define-package "jarchive" "0.6.0" "Open project dependencies in jar archives" '((emacs "26.1")) :commit "1f3a00fee6951ec57c948ae86b05018865ab3767" :maintainer '("Danny Freeman" . "danny@dfreeman.email") :keywords '("tools" "languages" "jvm" "java" "clojure") :url "https://git.sr.ht/~dannyfreeman/jarchive")
