;; Generated package description from expreg.el  -*- no-byte-compile: t -*-
(define-package "expreg" "1.1.0" "Simple expand region" '((emacs "29.1")) :commit "4fc82bbaafacbd3456cdf401f0b45c5203bd0a9d" :authors '(("Yuan Fu" . "casouri@gmail.com")) :maintainer '("Yuan Fu" . "casouri@gmail.com") :keywords '("text" "editing") :url "https://github.com/casouri/expreg")
