;; Generated package description from sql-beeline.el  -*- no-byte-compile: t -*-
(define-package "sql-beeline" "0.1" "Beeline support for sql.el" 'nil :url "https://elpa.gnu.org/packages/sql-beeline.html" :authors '(("Filipp Gunbin" . "fgunbin@fastmail.fm")) :maintainer '("Filipp Gunbin" . "fgunbin@fastmail.fm") :keywords '("sql" "hive" "beeline" "hiveserver2"))
