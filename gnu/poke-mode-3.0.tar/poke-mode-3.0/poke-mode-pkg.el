;; Generated package description from poke-mode.el  -*- no-byte-compile: t -*-
(define-package "poke-mode" "3.0" "Major mode for editing Poke programs" 'nil :commit "488a44cf462b7c98a2e7f3146afcffc9ba208bb0" :url "https://elpa.gnu.org/packages/poke-mode.html" :authors '(("Aurelien Aptel" . "aaptel@suse.com")) :maintainer '("Jose E. Marchesi" . "jemarch@gnu.org"))
