;; Generated package description from tempel.el  -*- no-byte-compile: t -*-
(define-package "tempel" "0.3" "Tempo templates/snippets with in-buffer field editing" '((emacs "27.1")) :commit "ee964c24b69579fcd5ec3c7d3d1d84d1ca3d90e4" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/tempel")
