;; Generated package description from kind-icon.el  -*- no-byte-compile: t -*-
(define-package "kind-icon" "0.1.4" "Completion kind icons" '((emacs "27.1") (svg-lib "0")) :authors '(("J.D. Smith" . "jdtsmith@gmail.com")) :maintainer '("J.D. Smith" . "jdtsmith@gmail.com") :keywords '("completion") :url "https://github.com/jdtsmith/kind-icon")
