;; Generated package description from boxy.el  -*- no-byte-compile: t -*-
(define-package "boxy" "1.1.1" "A boxy layout framework" '((emacs "26.1")) :commit "350bc70ed16c4eccc3b20114347cbdc3591140f3" :authors '(("Tyler Grinn" . "tylergrinn@gmail.com")) :maintainer '("Tyler Grinn" . "tylergrinn@gmail.com") :keywords '("tools") :url "https://gitlab.com/tygrdev/boxy")
