
x <- TRUE
"foo"
