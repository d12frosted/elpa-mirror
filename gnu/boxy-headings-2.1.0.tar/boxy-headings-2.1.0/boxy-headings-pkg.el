;; Generated package description from boxy-headings.el  -*- no-byte-compile: t -*-
(define-package "boxy-headings" "2.1.0" "View org files in a boxy diagram" '((emacs "26.1") (boxy "1.0") (org "9.3")) :authors '(("Tyler Grinn" . "tylergrinn@gmail.com")) :maintainer '("Tyler Grinn" . "tylergrinn@gmail.com") :keywords '("tools") :url "https://gitlab.com/tygrdev/boxy-headings")
