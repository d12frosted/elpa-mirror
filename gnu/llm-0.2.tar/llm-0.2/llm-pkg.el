;; Generated package description from llm.el  -*- no-byte-compile: t -*-
(define-package "llm" "0.2" "Interface to pluggable llm backends" '((emacs "28.1")) :commit "09fce97090bde133e98310090c1a363f034396a7" :authors '(("Andrew Hyatt" . "ahyatt@gmail.com")) :maintainer '("Andrew Hyatt" . "ahyatt@gmail.com") :url "https://github.com/ahyatt/llm")
