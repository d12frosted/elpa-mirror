;; Generated package description from dape.el  -*- no-byte-compile: t -*-
(define-package "dape" "0.2" "Debug Adapter Protocol for Emacs" '((emacs "29.1")) :commit "ee2ecae446c76f2b306bd75eedcf4976b2652ee4" :url "https://github.com/svaante/dape")
