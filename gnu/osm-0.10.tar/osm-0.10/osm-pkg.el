;; Generated package description from osm.el  -*- no-byte-compile: t -*-
(define-package "osm" "0.10" "OpenStreetMap viewer" '((emacs "27.1") (compat "29.1.3.4")) :commit "c3fbc813f2e76c71056bf6e28ae3a997f33718d1" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/osm")
