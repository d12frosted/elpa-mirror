;; Generated package description from osm.el  -*- no-byte-compile: t -*-
(define-package "osm" "0.2" "OpenStreetMap viewer" '((emacs "27.1")) :commit "cb191d426f1ac387e6d1895cd7fb4a79ad81762b" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/osm")
