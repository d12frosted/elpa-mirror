;; Generated package description from verilog-mode.el  -*- no-byte-compile: t -*-
(define-package "verilog-mode" "2021.9.16.45775504" "major mode for editing verilog source in Emacs" 'nil :authors '(("Michael McNamara" . "mac@verilog.com") ("Wilson Snyder" . "wsnyder@wsnyder.org")) :maintainer '("Michael McNamara" . "mac@verilog.com") :keywords '("languages") :url "https://www.veripool.org")
