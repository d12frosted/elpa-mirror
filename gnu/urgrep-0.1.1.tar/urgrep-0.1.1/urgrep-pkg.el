;; Generated package description from urgrep.el  -*- no-byte-compile: t -*-
(define-package "urgrep" "0.1.1" "Universal recursive grep" '((emacs "27.1") (compat "29.1.0.1") (project "0.3.0")) :commit "1924e175a52a9aecc2dd1e1339d0a063fbb398f1" :authors '(("Jim Porter")) :maintainer '("Jim Porter") :keywords '("grep" "search") :url "https://github.com/jimporter/urgrep")
