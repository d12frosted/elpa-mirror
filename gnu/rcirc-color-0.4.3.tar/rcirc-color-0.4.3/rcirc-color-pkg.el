;; Generated package description from rcirc-color.el  -*- no-byte-compile: t -*-
(define-package "rcirc-color" "0.4.3" "color nicks" '((emacs "24.4")) :commit "e34c4a6e338633808774c259e8bbd272351dbf4f" :url "https://elpa.gnu.org/packages/rcirc-color.html" :authors '(("Alex Schroeder" . "alex@gnu.org")) :maintainer '("Alex Schroeder" . "alex@gnu.org") :keywords '("comm"))
