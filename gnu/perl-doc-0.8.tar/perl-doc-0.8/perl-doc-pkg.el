;; Generated package description from perl-doc.el  -*- no-byte-compile: t -*-
(define-package "perl-doc" "0.8" "Read Perl documentation" '((emacs "27")) :commit "050df667a6d2eda08e8c7628772d4e12fc632064" :authors '(("Harald Jörg" . "haj@posteo.de")) :maintainer '("Harald Jörg" . "haj@posteo.de") :keywords '("languages") :url "https://github.com/HaraldJoerg/emacs-perl-doc")
