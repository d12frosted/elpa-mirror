;; Generated package description from vertico.el  -*- no-byte-compile: t -*-
(define-package "vertico" "0.3" "VERTical Interactive COmpletion" '((emacs "27.1")) :authors '(("Daniel Mendler")) :maintainer '("Daniel Mendler") :url "https://github.com/minad/vertico")
