;; Generated package description from blist.el  -*- no-byte-compile: t -*-
(define-package "blist" "0.1" "Display bookmarks in an ibuffer way" 'nil :url "https://elpa.gnu.org/packages/blist.html" :authors '(("Durand" . "mmemmew@gmail.com")) :maintainer '("Durand" . "mmemmew@gmail.com") :keywords '("convenience"))
