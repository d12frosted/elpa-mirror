;; Generated package description from engrave-faces.el  -*- no-byte-compile: t -*-
(define-package "engrave-faces" "0.3.0" "Convert font-lock faces to other formats" '((emacs "27.1")) :commit "3739d9f690412beb5bf717b11bc828fe39ade231" :authors '(("TEC <https://github/tecosaur>")) :maintainer '("TEC" . "tec@tecosaur.com") :keywords '("faces") :url "https://github.com/tecosaur/engrave-faces")
