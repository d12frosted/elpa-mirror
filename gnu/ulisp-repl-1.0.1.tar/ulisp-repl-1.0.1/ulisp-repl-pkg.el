;; Generated package description from ulisp-repl.el  -*- no-byte-compile: t -*-
(define-package "ulisp-repl" "1.0.1" "uLisp REPL" '((emacs "26.1") (paredit "26")) :commit "f4f30edf019de237729a6e599ced12699f125ff8" :url "https://elpa.gnu.org/packages/ulisp-repl.html" :authors '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")) :maintainer '("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
