;; Generated package description from llm.el  -*- no-byte-compile: t -*-
(define-package "llm" "0.3.0" "Interface to pluggable llm backends" '((emacs "28.1")) :commit "7954a92d7cd15ed4e265101ac94d2f969fae473d" :authors '(("Andrew Hyatt" . "ahyatt@gmail.com")) :maintainer '("Andrew Hyatt" . "ahyatt@gmail.com") :url "https://github.com/ahyatt/llm")
