;; Generated package description from company.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "company" "1.3.1" "Modular text completion framework" '((emacs "26.1") (posframe "1.5.1")) :commit "2f4512331742305aa39168cecf84588e6b476a0a" :maintainer '("Dmitry Gutov" . "dmitry@gutov.dev") :keywords '("abbrev" "convenience" "matching") :url "http://company-mode.github.io/")
