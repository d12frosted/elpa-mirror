;; Generated package description from urgrep.el  -*- no-byte-compile: t -*-
(define-package "urgrep" "0.2.0" "Universal recursive grep" '((emacs "27.1") (compat "29.1.0.1") (project "0.3.0")) :commit "4a034d9b2ec90fcdbd1d4539c1bfb9555020f0e3" :keywords '("grep" "search") :url "https://github.com/jimporter/urgrep")
