;; Generated package description from corfu.el  -*- no-byte-compile: t -*-
(define-package "corfu" "0.22" "Completion Overlay Region FUnction" '((emacs "27.1")) :commit "8591833f7dc76233dbe94b59c4eea9be6b4540f9" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/corfu")
