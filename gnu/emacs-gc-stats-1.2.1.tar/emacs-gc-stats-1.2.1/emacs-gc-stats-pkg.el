;; Generated package description from emacs-gc-stats.el  -*- no-byte-compile: t -*-
(define-package "emacs-gc-stats" "1.2.1" "Collect Emacs GC statistics" '((emacs "25.1")) :commit "478b9fcb0810592dfdf6417d780169e7fbeb13ba" :authors '(("Ihor Radchenko" . "yantar92@posteo.net")) :maintainer '("Ihor Radchenko" . "yantar92@posteo.net") :url "https://git.sr.ht/~yantar92/emacs-gc-stats")
