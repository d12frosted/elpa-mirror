;; Generated package description from srht.el  -*- no-byte-compile: t -*-
(define-package "srht" "0.1" "Sourcehut" '((emacs "27.1") (plz "0.1")) :commit "e4648260024bef41006bc77b18a598623e7d7201" :authors '(("Aleksandr Vityazev" . "avityazev@posteo.org")) :maintainer '("Aleksandr Vityazev" . "avityazev@posteo.org") :keywords '("comm" "vc") :url "https://sr.ht/~akagi/srht.el/")
