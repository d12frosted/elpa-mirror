;; Generated package description from mct.el  -*- no-byte-compile: t -*-
(define-package "mct" "0.5.0" "Minibuffer and Completions in Tandem" '((emacs "27.1")) :commit "680d7727216ed05ba58e7d2f04a046d1f27cf3e9" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://gitlab.com/protesilaos/mct")
