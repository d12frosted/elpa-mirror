;; Generated package description from keymap-popup.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "keymap-popup" "0.2.1" "Described keymaps with popup help" '((emacs "29.1")) :commit "7118da2bb2726698cabb314653fb5b87b05e1492" :keywords '("convenience") :url "https://codeberg.org/thanosapollo/emacs-keymap-popup")
