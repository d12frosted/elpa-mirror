;;; keymap-popup.el --- Described keymaps with popup help  -*- lexical-binding: t; -*-

;; Copyright (C) 2026  Free Software Foundation, Inc.

;; Author: Thanos Apollo <public@thanosapollo.org>
;; Version: 0.4.5
;; Package-Requires: ((emacs "29.1"))
;; Keywords: convenience
;; URL: https://git.thanosapollo.org/emacs-keymap-popup/

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Two macros: `keymap-popup-define' produces a real `defvar-keymap'
;; with embedded descriptions; `keymap-popup-annotate' adds popup
;; descriptions to an existing keymap.  `keymap-popup' displays
;; either as an interactive menu.  One definition, two uses:
;; direct key dispatch and popup help.
;;
;; Rendering is pure: commands mutate state in the user's buffer and the
;; popup re-reads it on refresh.  A compact session plist owns only popup
;; navigation, transient-map, and display lifecycle state.

;;; Code:

(require 'cl-lib)
(require 'seq)
(require 'subr-x)

(defgroup keymap-popup nil
  "Described keymaps with popup help."
  :group 'convenience)

(defcustom keymap-popup-display-action
  '(display-buffer-in-side-window (side . bottom))
  "Display action for the popup buffer.
Only used by `keymap-popup-backend-side-window'.
Common values:
  (display-buffer-in-side-window (side . bottom))  - frame-wide
  (display-buffer-below-selected)                  - current window only"
  :type display-buffer--action-custom-type
  :group 'keymap-popup)

(defcustom keymap-popup-backend #'keymap-popup-backend-side-window
  "Function returning a display backend plist (:show :fit :hide).
Each backend function receives a single buffer argument.
:show displays the buffer, :fit refits after content changes,
:hide removes the display and cleans up."
  :type '(choice (function-item :tag "Side window" keymap-popup-backend-side-window)
                 (function-item :tag "Child frame" keymap-popup-backend-child-frame)
                 (function :tag "Custom backend"))
  :group 'keymap-popup)

(defcustom keymap-popup-child-frame-parameters
  '((no-accept-focus . t)
    (no-focus-on-map . t)
    (min-width . t)
    (min-height . t)
    (border-width . 0)
    (child-frame-border-width . 1)
    (left-fringe . 0)
    (right-fringe . 0)
    (vertical-scroll-bars . nil)
    (horizontal-scroll-bars . nil)
    (menu-bar-lines . 0)
    (tool-bar-lines . 0)
    (tab-bar-lines . 0)
    (no-other-frame . t)
    (no-other-window . t)
    (no-delete-other-windows . t)
    (unsplittable . t)
    (undecorated . t)
    (cursor-type . nil)
    (no-special-glyphs . t)
    (desktop-dont-save . t))
  "Frame parameters for the child-frame backend.
These are merged with runtime parameters (parent-frame, minibuffer,
visibility) when creating the child frame."
  :type '(alist :key-type symbol :value-type sexp)
  :group 'keymap-popup)

(defcustom keymap-popup-buffer-parameters
  '((buffer-read-only . t)
    (cursor-type . nil)
    (mode-line-format
     . (" "
        (:eval (and-let* ((active (plist-get keymap-popup--session :active))
                          (exit-key (plist-get active :exit-key)))
                 (propertize (format " %s " exit-key)
                             'face 'keymap-popup-key)))
        " "
        (:eval (or (plist-get (plist-get keymap-popup--session :active)
                             :resolved-docstring)
                   ""))))
    (header-line-format . nil)
    (tab-line-format . nil)
    (left-margin-width . 1)
    (right-margin-width . 1))
  "Buffer-local parameters applied to the popup buffer.
Each entry is (VARIABLE . VALUE).  Users can remove entries to
keep defaults or change values to customize the popup appearance."
  :type '(alist :key-type symbol :value-type sexp)
  :group 'keymap-popup)

(defcustom keymap-popup-persistent nil
  "When non-nil, the popup stays open after every key press.
All suffix commands execute and refresh the popup in place.
Only the exit key and \\`C-g' dismiss it.
Can also be set per-keymap via the `:persistent' keyword in
`keymap-popup-define' or `keymap-popup-annotate'."
  :type 'boolean
  :group 'keymap-popup)

(defcustom keymap-popup-default-popup-key "h"
  "Default key to open the popup in keymaps defined with `keymap-popup-define'.
Applied by `keymap-popup-define' when :popup-key is not specified.
Read when the definition is loaded, so customize it before loading
packages that define popups.  Not applied by `keymap-popup-annotate'
\(must be given explicitly)."
  :type 'key
  :group 'keymap-popup)

(defcustom keymap-popup-default-exit-key "q"
  "Default key to dismiss the popup.
Used as the fallback when the popup is shown and the keymap stores
no explicit :exit-key, for both `keymap-popup-define' and
`keymap-popup-annotate'."
  :type 'key
  :group 'keymap-popup)

(defconst keymap-popup--buffer-name "*keymap-popup*"
  "Preferred name for a newly allocated popup buffer.")

(defvar keymap-popup--buffer nil
  "Buffer owning the current popup session, or nil.")

;;; Faces

(defface keymap-popup-key
  '((t :inherit help-key-binding))
  "Face for key bindings in the popup.")

(defface keymap-popup-group-header
  '((t :weight bold))
  "Face for group headers in the popup.")

(defface keymap-popup-value
  '((t :inherit font-lock-string-face :weight bold))
  "Face for switch values in the popup.")

(defface keymap-popup-submenu
  '((t :inherit font-lock-type-face))
  "Face for sub-menu entries in the popup.")

(defface keymap-popup-inapt
  '((t :inherit shadow))
  "Face for inapt (disabled) entries in the popup.")

;;; Keymap metadata

(defun keymap-popup--metadata-properties (binding)
  "Return popup properties from BINDING, upgrading legacy storage in place.
Older public declarations stored properties in a pseudo-key submap.
Convert only that metadata object to an inert menu item on first use,
without replacing its owning map or copying command objects.  Retained
parents and composed maps therefore see the same upgrade.  Ordinary
bindings and customizations are never changed."
  (when (eq (car-safe binding) 'keymap)
    (let ((properties
           (mapcan (lambda (prop)
                     (list prop (lookup-key binding (vector prop))))
                   '(descriptions exit-key description persistent))))
      (setcar binding 'menu-item)
      (setcdr binding (append '("" nil) properties))))
  (and (eq (car-safe binding) 'menu-item) (nthcdr 3 binding)))

(defun keymap-popup--meta (keymap prop)
  "Get effective popup metadata PROP from KEYMAP.
Follow native component and parent order for each property separately.
Nil falls through, like an unbound key; explicit false persistence is
stored as `no' and therefore overrides inherited persistence."
  (catch 'metadata
    (map-keymap
     (lambda (event binding)
       (when (eq event 'keymap-popup)
         (when-let* ((value (plist-get
                            (keymap-popup--metadata-properties binding) prop)))
           (throw 'metadata value))))
     keymap)))

(defun keymap-popup--set-meta (keymap prop value)
  "Set KEYMAP's local metadata PROP to VALUE.
Keep metadata in an inert menu item's properties, not its binding.
Native help and dispatch ignore the nil binding, while `copy-keymap'
retains the properties and the identity of anonymous commands.  Replace
rather than mutate properties shared with a copied map."
  (let* ((item (catch 'metadata
                 ;; Follow `store_in_keymap' for this symbolic event.  Unlike
                 ;; `map-keymap-internal', it skips embedded keymap symbols.
                 (let ((tail (cdr (if (symbolp keymap)
                                      (indirect-function keymap) keymap))))
                   (while (and (consp tail) (not (eq (car tail) 'keymap)))
                     (let ((binding (car tail)))
                       (cond
                        ((eq (car-safe binding) 'keymap)
                         (setq tail (cdr binding)))
                        ((eq (car-safe binding) 'keymap-popup)
                         (throw 'metadata (cdr binding)))
                        (t (setq tail (cdr tail)))))))))
         (properties (copy-sequence (keymap-popup--metadata-properties item))))
    (define-key keymap [keymap-popup]
                (append '(menu-item "" nil)
                        (plist-put properties prop value)))))

(gv-define-setter keymap-popup--meta (val keymap prop)
  `(keymap-popup--set-meta ,keymap ,prop ,val))

(defun keymap-popup--attach-meta (keymap rows &rest opts)
  "Attach popup descriptions ROWS and metadata OPTS to KEYMAP.
OPTS is a plist accepting :exit-key, :description, and
:persistent; other keys are ignored.  Reattaching replaces all
previous metadata, so omitted options return to their defaults.
:persistent is stored as `yes' or `no' to distinguish an explicit
false value from an omitted option.
Returns KEYMAP."
  (let ((persistent (and (plist-member opts :persistent)
                         (if (plist-get opts :persistent) 'yes 'no))))
    (setf (keymap-popup--meta keymap 'descriptions) rows
          (keymap-popup--meta keymap 'exit-key) (plist-get opts :exit-key)
          (keymap-popup--meta keymap 'description) (plist-get opts :description)
          (keymap-popup--meta keymap 'persistent) persistent))
  keymap)

;;; Parsers

(defconst keymap-popup--entry-properties
  '(:if :inapt-if :stay-open :c-u)
  "Properties accepted by popup entries.")

(defconst keymap-popup--group-properties
  '(:if :inapt-if)
  "Properties accepted by popup groups.")

(defun keymap-popup--invalid (context format-string &rest args)
  "Signal an invalid popup declaration in CONTEXT.
FORMAT-STRING and ARGS describe the error."
  (error "keymap-popup: %s: %s"
         context (apply #'format format-string args)))

(defun keymap-popup--parse-properties (properties allowed context)
  "Parse PROPERTIES accepted by ALLOWED for CONTEXT.
The :stay-open property may omit its value."
  (named-let parse ((rest properties) (seen nil))
    (cond
     ((null rest) nil)
     ((not (consp rest))
      (keymap-popup--invalid context "malformed property list"))
     (t
      (let ((property (car rest)))
        (unless (keywordp property)
          (keymap-popup--invalid context "expected property, got %S" property))
        (unless (memq property allowed)
          (keymap-popup--invalid context "unknown property %S" property))
        (when (memq property seen)
          (keymap-popup--invalid context "duplicate property %S" property))
        (if (and (eq property :stay-open)
                 (or (null (cdr rest)) (keywordp (cadr rest))))
            (cons property
                  (cons t (parse (cdr rest) (cons property seen))))
          (unless (cdr rest)
            (keymap-popup--invalid context "property %S needs a value" property))
          (cons property
                (cons (cadr rest)
                      (parse (cddr rest) (cons property seen))))))))))

(defun keymap-popup--function-form-p (value)
  "Return non-nil when VALUE is a quoted or literal function form."
  (and (consp value) (memq (car value) '(closure function lambda))))

(defun keymap-popup--function-designator-p (value)
  "Return non-nil when VALUE is a function object or function symbol."
  (or (functionp value)
      (and (symbolp value)
           (not (memq value '(nil t)))
           (not (keywordp value)))))

(defun keymap-popup--valid-description-p (description runtime)
  "Return non-nil when DESCRIPTION is valid for RUNTIME input."
  (or (stringp description)
      (keymap-popup--function-designator-p description)
      (and (not runtime) (consp description))))

(defun keymap-popup--validate-description (description context runtime)
  "Validate DESCRIPTION for CONTEXT and RUNTIME input."
  (unless (keymap-popup--valid-description-p description runtime)
    (keymap-popup--invalid context
                           "description must be a string or function, got %S"
                           description)))

(defun keymap-popup--valid-function-value-p (value runtime)
  "Return non-nil when VALUE is a function value for RUNTIME input."
  (or (null value)
      (keymap-popup--function-designator-p value)
      (and (not runtime) (consp value))))

(defun keymap-popup--valid-string-value-p (value runtime)
  "Return non-nil when VALUE is a string value for RUNTIME input."
  (or (null value)
      (stringp value)
      (and (not runtime)
           (not (eq value t))
           (not (keywordp value))
           (or (symbolp value) (consp value)))))

(defun keymap-popup--validate-properties (properties context runtime)
  "Validate parsed PROPERTIES for CONTEXT and RUNTIME input."
  (named-let validate ((rest properties))
    (when rest
      (pcase-exhaustive (car rest)
        ((or :if :inapt-if)
         (unless (keymap-popup--valid-function-value-p (cadr rest) runtime)
           (keymap-popup--invalid context "%S needs a function" (car rest))))
        (:stay-open
         (when (and runtime (not (memq (cadr rest) '(nil t))))
           (keymap-popup--invalid context ":stay-open needs a boolean")))
        (:c-u
         (unless (keymap-popup--valid-string-value-p (cadr rest) runtime)
           (keymap-popup--invalid context ":c-u needs a string"))))
      (validate (cddr rest))))
  properties)

(defun keymap-popup--valid-command-p (command runtime)
  "Return non-nil when COMMAND is valid for RUNTIME input."
  (let ((command-symbol (and (symbolp command)
                             (not (memq command '(nil t)))
                             (not (keywordp command)))))
    (if runtime
        (or command-symbol (commandp command))
      (or command-symbol (functionp command) (consp command)))))

(defun keymap-popup--entry (key description type &rest properties)
  "Return a canonical popup entry plist.
KEY, DESCRIPTION, and TYPE identify the entry.  PROPERTIES supplies
the type-specific payload and optional predicates."
  (list :key key
        :description description
        :type type
        :command (plist-get properties :command)
        :variable (plist-get properties :variable)
        :target (plist-get properties :target)
        :if (plist-get properties :if)
        :inapt-if (plist-get properties :inapt-if)
        :stay-open (plist-get properties :stay-open)
        :c-u (plist-get properties :c-u)))

(defun keymap-popup--group (name entries &rest properties)
  "Return a canonical popup group with NAME, ENTRIES, and PROPERTIES."
  (list :name name
        :entries entries
        :if (plist-get properties :if)
        :inapt-if (plist-get properties :inapt-if)))

(defun keymap-popup--validate-key (key mode context)
  "Validate entry KEY for parser MODE and CONTEXT."
  (cond
   ((stringp key)
    (unless (key-valid-p key)
      (keymap-popup--invalid context "invalid key %S" key)))
   ((and (symbolp key) (not (memq key '(nil t))) (not (keywordp key)))
    (when (eq mode 'define)
      (keymap-popup--invalid context "definitions require a key string")))
   (t (keymap-popup--invalid context "invalid key or command %S" key))))

(defun keymap-popup--key-events (key)
  "Return native keymap events for key string KEY, or nil for nil.
Expand Meta characters using `meta-prefix-char', as `define-key' does."
  (when key
    (cl-loop for event across (key-parse key)
             if (and (integerp event) (/= 0 (logand event #x8000000)))
             append (list meta-prefix-char (logand event (lognot #x8000000)))
             else collect event)))

(defun keymap-popup--same-key-p (a b)
  "Return non-nil when key strings A and B name the same native events."
  (and (stringp a) (stringp b)
       (equal (keymap-popup--key-events a) (keymap-popup--key-events b))))

(defun keymap-popup--parse-annotated-entry (key spec context runtime)
  "Parse annotated SPEC for command KEY in CONTEXT.
RUNTIME means values have already been evaluated."
  (let* ((parts (if (or (not (consp spec))
                        (functionp spec)
                        (keymap-popup--function-form-p spec))
                    (list spec)
                  spec))
         (description (car parts))
         (properties (keymap-popup--validate-properties
                      (keymap-popup--parse-properties
                       (cdr parts) keymap-popup--entry-properties context)
                      context runtime)))
    (keymap-popup--validate-description description context runtime)
    (unless (keymap-popup--valid-command-p key runtime)
      (keymap-popup--invalid context "invalid command %S" key))
    (apply #'keymap-popup--entry nil description 'suffix
           :command key properties)))

(defun keymap-popup--parse-keyed-entry (key spec context runtime)
  "Parse keyed SPEC for KEY in CONTEXT.
RUNTIME means values have already been evaluated."
  (unless (and (proper-list-p spec) (>= (length spec) 2))
    (keymap-popup--invalid context
                           "expected (DESCRIPTION COMMAND-OR-TYPE ...)"))
  (let ((description (car spec))
        (kind (cadr spec))
        (payload (cddr spec)))
    (keymap-popup--validate-description description context runtime)
    (pcase kind
      (:switch
       (unless (and (symbolp (car payload))
                    (not (memq (car payload) '(nil t)))
                    (not (keywordp (car payload))))
         (keymap-popup--invalid context "switch needs a variable symbol"))
       (apply #'keymap-popup--entry key description 'switch
              :variable (car payload)
              (keymap-popup--validate-properties
               (keymap-popup--parse-properties
                (cdr payload) keymap-popup--entry-properties context)
               context runtime)))
      (:keymap
       (if runtime
           (unless (keymapp (car payload))
             (keymap-popup--invalid context "submenu target is not a keymap"))
         (unless (and (symbolp (car payload))
                      (not (memq (car payload) '(nil t)))
                      (not (keywordp (car payload))))
           (keymap-popup--invalid context "submenu needs a keymap symbol")))
       (apply #'keymap-popup--entry key description 'keymap
              :target (car payload)
              (keymap-popup--validate-properties
               (keymap-popup--parse-properties
                (cdr payload) keymap-popup--entry-properties context)
               context runtime)))
      (_
       (unless (keymap-popup--valid-command-p kind runtime)
         (keymap-popup--invalid context "invalid command %S" kind))
       (apply #'keymap-popup--entry key description 'suffix
              :command kind
              (keymap-popup--validate-properties
               (keymap-popup--parse-properties
                payload keymap-popup--entry-properties context)
               context runtime))))))

(defun keymap-popup--parse-entry (key spec &optional mode)
  "Parse binding SPEC for KEY into a plist.
KEY is a key string for normal entries, or a command symbol for
annotated entries.  SPEC is (DESCRIPTION COMMAND-OR-TYPE &rest PROPS)
for key-based entries, or (DESCRIPTION &rest PROPS) for annotated ones.
MODE is `define', `annotate', or `runtime'; omitted means macro syntax."
  (let* ((mode (or mode 'macro))
         (context (format "entry %S" key))
         (runtime (eq mode 'runtime)))
    (keymap-popup--validate-key key mode context)
    (if (stringp key)
        (keymap-popup--parse-keyed-entry key spec context runtime)
      (keymap-popup--parse-annotated-entry key spec context runtime))))

(defun keymap-popup--split-groups (bindings)
  "Split BINDINGS at :group and :row keywords.
Returns a list of rows, each row a list of (NAME . FLAT-ENTRIES) chunks.
`:group' starts a new group within the current row.
`:row' starts a new row."
  (named-let split ((rest bindings) (name nil) (entries nil)
                    (groups nil) (rows nil))
    (let ((flushed (if entries
                       (cons (cons name (reverse entries)) groups)
                     groups)))
      (cond
       ((null rest)
        (reverse (if flushed (cons (reverse flushed) rows) rows)))
       ((eq (car rest) :row)
        (split (cdr rest) nil nil nil
               (if flushed (cons (reverse flushed) rows) rows)))
       ((eq (car rest) :group)
        (unless (cdr rest)
          (keymap-popup--invalid "bindings" ":group needs a name"))
        (split (cddr rest) (cadr rest) nil flushed rows))
       ((keywordp (car rest))
        (keymap-popup--invalid "bindings" "unknown directive %S" (car rest)))
       ((null (cdr rest))
        (keymap-popup--invalid "bindings" "entry %S needs a specification"
                               (car rest)))
       (t
        (split (cddr rest) name
               (cons (cons (car rest) (cadr rest)) entries)
               groups rows))))))

(defun keymap-popup--parse-group-name (raw &optional mode)
  "Parse RAW group name into (NAME . PROPS).
RAW is a string, a lambda, or a list (NAME :if PRED :inapt-if PRED).
A list whose car is not `lambda' is treated as a name with properties.
MODE controls whether values have already been evaluated."
  (let* ((runtime (eq mode 'runtime))
         (context (format "group %S" raw))
         (specified (and (consp raw)
                         (not (functionp raw))
                         (not (keymap-popup--function-form-p raw))))
         (name (if specified (car raw) raw))
         (properties (and specified
                          (keymap-popup--validate-properties
                           (keymap-popup--parse-properties
                            (cdr raw) keymap-popup--group-properties context)
                           context runtime))))
    (when name
      (keymap-popup--validate-description name context runtime))
    (cons name properties)))

(defun keymap-popup--parse-chunk (chunk &optional mode)
  "Parse CHUNK into a group plist according to parser MODE."
  (let* ((name-props (keymap-popup--parse-group-name (car chunk) mode))
         (name (car name-props))
         (group-props (cdr name-props))
         (entries (cl-loop for (k . v) in (cdr chunk)
                           collect (keymap-popup--parse-entry k v mode))))
    (apply #'keymap-popup--group name entries group-props)))

(defun keymap-popup--parse-bindings (bindings &optional mode)
  "Parse BINDINGS into a list of rows.
Each row is a list of group plists with :name and :entries.
MODE controls whether values have already been evaluated."
  (mapcar (lambda (row)
            (mapcar (lambda (chunk)
                      (keymap-popup--parse-chunk chunk mode))
                    row))
          (keymap-popup--split-groups bindings)))

(defun keymap-popup--if-allows-p (plist)
  "Return non-nil when PLIST has no :if or its :if predicate is non-nil."
  (let ((pred (plist-get plist :if)))
    (or (null pred) (funcall pred))))

(defun keymap-popup--inapt-active-p (plist)
  "Return non-nil when PLIST's :inapt-if predicate is currently active."
  (and-let* ((pred (plist-get plist :inapt-if)))
    (funcall pred)))

(defun keymap-popup--combine-preds (a b)
  "AND-combine zero-arg predicates A and B.  Either may be nil."
  (cond ((null a) b)
        ((null b) a)
        (t (lambda () (and (funcall a) (funcall b))))))

(defun keymap-popup--flatten-with-groups (rows)
  "Flatten ROWS into entries without changing their predicates."
  (cl-loop for row in rows
           append (cl-loop for group in row
                           append (plist-get group :entries))))

;;; Generated symbol names

(defun keymap-popup--toggle-name (map-name var)
  "Return the symbol naming the toggle command for VAR in MAP-NAME."
  (intern (format "%s--toggle-%s" map-name var)))

(defun keymap-popup--enter-name (map-name target)
  "Return the symbol naming the sub-menu enterer for TARGET in MAP-NAME."
  (intern (format "%s--enter-%s" map-name target)))

(defun keymap-popup--launcher-name (map-name)
  "Return the symbol naming the popup launcher for MAP-NAME."
  (intern (concat (symbol-name map-name) "-popup")))

(defun keymap-popup--entry-command (map-name entry)
  "Return the command to bind in MAP-NAME's keymap for ENTRY.
Switch and keymap entries name generated commands; suffix entries
retain their declared command."
  (pcase-exhaustive (plist-get entry :type)
    ('suffix (plist-get entry :command))
    ('switch (keymap-popup--toggle-name map-name (plist-get entry :variable)))
    ('keymap (keymap-popup--enter-name map-name (plist-get entry :target)))))

;;; Macro helpers

(defun keymap-popup--make-if-filter (pred)
  "Return a `menu-item' :filter exposing the binding only when PRED is non-nil."
  (lambda (b) (and (funcall pred) b)))

(defun keymap-popup--filter-binding (binding pred)
  "Return BINDING filtered by PRED, or BINDING when PRED is nil."
  (if pred
      (list 'menu-item "" binding :filter
            (keymap-popup--make-if-filter pred))
    binding))

(defun keymap-popup--wrap-binding-form (cmd-form if-pred)
  "Wrap CMD-FORM with a `menu-item' :filter when IF-PRED is set.
IF-PRED is a form that evaluates to a zero-arg predicate; a nil
filter result makes the key act as unbound.  `:inapt-if' is not a
keymap concern -- it is enforced by the popup wrapper at keypress
time.  The filter closure is built by a helper in this file so it
remains lexical regardless of the caller."
  (if if-pred
      `(keymap-popup--filter-binding ,cmd-form ,if-pred)
    cmd-form))

(defun keymap-popup--build-keymap-pairs (map-name rows &optional commands)
  "Build flat key/command forms for MAP-NAME from ROWS.
Group and entry :if forms are evaluated at load time, then combined
as function values for the live binding's filter.
COMMANDS maps entries to variables holding their evaluated commands."
  (cl-loop for row in rows append
           (cl-loop for group in row append
                    (cl-loop for entry in (plist-get group :entries)
                             for cmd = (keymap-popup--entry-command map-name entry)
                             for cmd-form = (or (cdr (assq entry commands))
                                                (if (symbolp cmd) `#',cmd cmd))
                             for group-if = (plist-get group :if)
                             for entry-if = (plist-get entry :if)
                             for pred = (if (and group-if entry-if)
                                            `(keymap-popup--combine-preds
                                              ,group-if ,entry-if)
                                          (or group-if entry-if))
                             append (list (plist-get entry :key)
                                          (keymap-popup--wrap-binding-form
                                           cmd-form pred))))))

(defun keymap-popup--build-entry-form (entry &optional map-name commands)
  "Build a canonical entry form for ENTRY.
When MAP-NAME is non-nil, switch and keymap entries also store the
generated toggle/enter command as :command, so every entry is
command-addressable (annotate entries have no generated commands,
so their builders pass no MAP-NAME).
COMMANDS maps entries to variables holding their evaluated commands."
  (let* ((type (plist-get entry :type))
         (command (pcase-exhaustive type
                    ('suffix (plist-get entry :command))
                    ((or 'switch 'keymap)
                     (and map-name
                          (keymap-popup--entry-command map-name entry)))))
         (command-form (or (cdr (assq entry commands))
                           (and command
                                (if (symbolp command) `#',command command))))
         (variable-form (and (eq type 'switch)
                             `(quote ,(plist-get entry :variable))))
         (target-form (and (eq type 'keymap)
                           `(quote ,(plist-get entry :target)))))
    `(keymap-popup--entry
      ,(plist-get entry :key)
      ,(plist-get entry :description)
      ',type
      :command ,command-form
      :variable ,variable-form
      :target ,target-form
      :if ,(plist-get entry :if)
      :inapt-if ,(plist-get entry :inapt-if)
      :stay-open ,(plist-get entry :stay-open)
      :c-u ,(plist-get entry :c-u))))

(defun keymap-popup--build-group-form (group &optional map-name commands)
  "Build a canonical form for one GROUP plist.
MAP-NAME and COMMANDS are passed to `keymap-popup--build-entry-form'."
  `(keymap-popup--group
    ,(plist-get group :name)
    (list ,@(mapcar (lambda (entry)
                      (keymap-popup--build-entry-form entry map-name commands))
                    (plist-get group :entries)))
    :if ,(plist-get group :if)
    :inapt-if ,(plist-get group :inapt-if)))

(defun keymap-popup--build-descriptions-form (rows &optional map-name commands)
  "Build a `list' form that constructs descriptions at load time.
ROWS is a list of rows, each row a list of groups.  Uses `list'
calls so lambdas in :if/:inapt-if/:description get compiled.
MAP-NAME and COMMANDS are passed down to the entry forms."
  `(list ,@(mapcar (lambda (row)
                     `(list ,@(mapcar (lambda (group)
                                        (keymap-popup--build-group-form
                                         group map-name commands))
                                      row)))
                   rows)))

(defun keymap-popup--build-switch-forms (map-name entries)
  "Build `defvar-local' + toggle `defun' forms for switch ENTRIES in MAP-NAME."
  (mapcan (lambda (e)
            (let* ((var (plist-get e :variable))
                   (toggle (keymap-popup--toggle-name map-name var)))
              `((defvar-local ,var nil
                  ,(format "Buffer-local switch state.\nToggled by `%s'."
                           toggle))
                (defun ,toggle ()
                  ,(format "Toggle the buffer-local switch.\nSets `%s' in the current buffer." var)
                  (interactive)
                  (setq ,var (not ,var))
                  (message "%s: %s" ',var (if ,var "on" "off"))))))
          entries))

(defun keymap-popup--build-enter-forms (map-name entries)
  "Build sub-menu enter defun forms for keymap ENTRIES in MAP-NAME."
  (mapcar (lambda (e)
            (let* ((target (plist-get e :target))
                   (enter (keymap-popup--enter-name map-name target)))
              `(defun ,enter ()
                 ,(format "Show popup for `%s' (sub-menu of `%s')."
                          target map-name)
                 (interactive)
                 (keymap-popup (keymap-popup--resolve-submenu-target
                                ',target)))))
          entries))

(defun keymap-popup--build-launcher-form (map-name launcher)
  "Build the launcher defun form named LAUNCHER for MAP-NAME."
  `(defun ,launcher ()
     ,(format "Show popup help for `%s'." map-name)
     (interactive)
     (keymap-popup ,map-name)))

(defun keymap-popup--raw-local-event-binding (keymap event)
  "Return EVENT's raw local binding in KEYMAP.
Do not follow parents or evaluate `menu-item' filters."
  (catch 'binding
    (map-keymap-internal
     (lambda (map-event binding)
       (when (or (equal map-event event)
                 (and (consp map-event)
                      (integerp event)
                      (integerp (car map-event))
                      (integerp (cdr map-event))
                      (<= (car map-event) event (cdr map-event))))
         (throw 'binding binding)))
     keymap)
    nil))

(defun keymap-popup--raw-local-binding (keymap key)
  "Return KEY's raw local binding in KEYMAP.
Do not follow KEYMAP's parent or evaluate `menu-item' filters."
  (let ((events (keymap-popup--key-events key))
        (map keymap))
    (catch 'missing
      (while (cdr events)
        (let ((prefix (keymap-popup--raw-local-event-binding
                       map (pop events))))
          (unless (keymapp prefix)
            (throw 'missing nil))
          (setq map prefix)))
      (keymap-popup--raw-local-event-binding map (car events)))))

(defun keymap-popup--declared-command (keymap key)
  "Return the previously described command for KEY in KEYMAP.
Consult local metadata, not live bindings: a user replacement must
not acquire the original command's description on reload."
  (when-let* ((meta (keymap-popup--raw-local-event-binding
                    keymap 'keymap-popup))
              (rows (plist-get (keymap-popup--metadata-properties meta)
                               'descriptions)))
    (plist-get
     (seq-find (lambda (entry)
                 (keymap-popup--same-key-p (plist-get entry :key) key))
               (keymap-popup--flatten-with-groups rows))
     :command)))

(defun keymap-popup--bind-launcher (keymap key command)
  "Bind popup launcher COMMAND to KEY in KEYMAP.
Signal an error instead of replacing an existing local binding."
  (let ((local (keymap-popup--raw-local-binding keymap key)))
    (when (and local (not (eq local command)))
      (error "keymap-popup: Popup key %S is already bound" key)))
  (when (symbolp command)
    (put command 'keymap-popup-launcher t))
  (keymap-set keymap key command))

(defun keymap-popup--build-declaration-forms (map-name parent entries)
  "Build bare `defvar' forms for MAP-NAME, PARENT, and targets in ENTRIES."
  (mapcar (lambda (symbol) `(defvar ,symbol))
          (seq-uniq
           (append (list map-name)
                   (and parent (symbolp parent) (list parent))
                   (cl-loop for entry in entries
                            for target = (plist-get entry :target)
                            when (and (eq (plist-get entry :type) 'keymap)
                                      target
                                      (symbolp target))
                            collect target)))))

(defun keymap-popup--build-attach-form (map-name rows-form exit-key
                                                 description persistent
                                                 persistent-p)
  "Build the `keymap-popup--attach-meta' call form for MAP-NAME.
ROWS-FORM constructs the descriptions at load time.  Each of
EXIT-KEY and DESCRIPTION is passed only when non-nil.  PERSISTENT
is passed when PERSISTENT-P is non-nil."
  `(keymap-popup--attach-meta ,map-name ,rows-form
                              ,@(and exit-key `(:exit-key ,exit-key))
                              ,@(and description `(:description ,description))
                              ,@(and persistent-p
                                      `(:persistent ,persistent))))

;;; Macro

(defconst keymap-popup--define-options
  '(:popup-key :exit-key :parent :description :persistent)
  "Options accepted by `keymap-popup-define'.")

(defconst keymap-popup--annotate-options
  '(:popup-key :exit-key :description :persistent)
  "Options accepted by `keymap-popup-annotate'.")

(defconst keymap-popup--attach-options
  '(:exit-key :description :persistent)
  "Options accepted by `keymap-popup-attach'.")

(defun keymap-popup--parse-options (values allowed context)
  "Parse leading options from VALUES for CONTEXT.
ALLOWED lists recognized option names.  Return (OPTIONS . REST)."
  (named-let parse ((rest values) (options nil) (seen nil))
    (cond
     ((null rest) (cons (reverse options) nil))
     ((memq (car rest) allowed)
      (unless (cdr rest)
        (keymap-popup--invalid context "option %S needs a value" (car rest)))
      (when (memq (car rest) seen)
        (keymap-popup--invalid context "duplicate option %S" (car rest)))
      (parse (cddr rest)
             (cons (cadr rest) (cons (car rest) options))
             (cons (car rest) seen)))
     ((and (keywordp (car rest))
           (not (memq (car rest) '(:group :row))))
      (keymap-popup--invalid context "unknown option %S" (car rest)))
     (t (cons (reverse options) rest)))))

(defun keymap-popup--validate-key-option (options property context runtime)
  "Validate key PROPERTY in OPTIONS for CONTEXT and RUNTIME input."
  (when-let* ((value (plist-get options property)))
    (cond
     ((stringp value)
      (unless (key-valid-p value)
        (keymap-popup--invalid context "%S is not a valid key" value)))
     ((or runtime
          (memq value '(nil t))
          (keywordp value)
          (not (or (symbolp value) (consp value))))
      (keymap-popup--invalid context "%S needs a key string" property)))))

(defun keymap-popup--validate-options (options context runtime)
  "Validate OPTIONS for CONTEXT and RUNTIME input."
  (keymap-popup--validate-key-option options :popup-key context runtime)
  (keymap-popup--validate-key-option options :exit-key context runtime)
  (when-let* ((description (plist-get options :description)))
    (keymap-popup--validate-description description context runtime))
  (when (and runtime
             (plist-member options :persistent)
             (not (memq (plist-get options :persistent) '(nil t))))
    (keymap-popup--invalid context ":persistent needs a boolean"))
  options)

(defun keymap-popup--extract-macro-opts (body allowed context)
  "Extract options accepted by ALLOWED from macro BODY for CONTEXT.
Return a plist containing :docstring, parsed options, and :bindings."
  (let* ((docstring (and (stringp (car body))
                         (or (null (cadr body))
                             (not (listp (cadr body))))
                         (car body)))
         (rest (if docstring (cdr body) body))
         (result (keymap-popup--parse-options rest allowed context))
         (options (append (list :docstring docstring)
                          (car result)
                          (list :bindings (cdr result)))))
    (keymap-popup--validate-options options context nil)))

;;;###autoload
(defmacro keymap-popup-define (name &rest body)
  "Define NAME as a keymap with embedded descriptions.
BODY is an optional docstring, optional :popup-key KEY (default
per `keymap-popup-default-popup-key'), optional :exit-key KEY
\(default per `keymap-popup-default-exit-key'), optional :parent
KEYMAP, optional :description STRING-OR-FUNCTION, optional
:persistent BOOL, followed by :group keywords and KEY (DESC ...)
pairs.
Reevaluation preserves the initialized keymap and its original
anonymous commands, while refreshing descriptions and options."
  (declare (indent 1))
  (let* ((options (keymap-popup--extract-macro-opts
                   body keymap-popup--define-options
                   (format "definition %S" name)))
         (docstring (plist-get options :docstring))
         (popup-key (plist-get options :popup-key))
         (exit-key (plist-get options :exit-key))
         (parent (plist-get options :parent))
         (description (plist-get options :description))
         (persistent (plist-get options :persistent))
         (persistent-p (plist-member options :persistent))
         (bindings (plist-get options :bindings))
         (rows (keymap-popup--parse-bindings bindings 'define))
         (all-entries (keymap-popup--flatten-with-groups rows))
         (switch-entries (cl-loop for entry in all-entries
                                  when (eq (plist-get entry :type) 'switch)
                                  collect entry))
         (keymap-entries (cl-loop for entry in all-entries
                                  when (eq (plist-get entry :type) 'keymap)
                                  collect entry))
         (commands (cl-loop for entry in all-entries
                            for command = (keymap-popup--entry-command name entry)
                            unless (symbolp command)
                            collect (cons entry (make-symbol "command"))))
         (keymap-pairs (keymap-popup--build-keymap-pairs name rows commands))
         (launcher (keymap-popup--launcher-name name))
         (definition
          `((defvar-keymap ,name
              ,@(and docstring (list :doc docstring))
              ,@(and parent (list :parent parent))
              ,@keymap-pairs)
            ;; Read the default popup key at load time.
            (keymap-popup--bind-launcher
             ,name ,(or popup-key 'keymap-popup-default-popup-key) #',launcher)
            ,(keymap-popup--build-attach-form
              name (keymap-popup--build-descriptions-form rows name commands)
              exit-key description persistent persistent-p))))
    `(progn
       ,@(keymap-popup--build-declaration-forms name parent all-entries)
       ,@(keymap-popup--build-switch-forms name switch-entries)
       ,@(keymap-popup--build-enter-forms name keymap-entries)
       ,(keymap-popup--build-launcher-form name launcher)
       ,@(if commands
             ;; Share function objects, not merely equal closure forms, between
             ;; the live bindings and descriptions.  Keep predicate layers apart.
             `((let ,(mapcar (lambda (pair)
                              `(,(cdr pair)
                                (or (and (boundp ',name)
                                         (keymap-popup--declared-command
                                          ,name ,(plist-get (car pair) :key)))
                                    ,(plist-get (car pair) :command))))
                            commands)
                 ,@definition))
           definition))))

;;;###autoload
(defmacro keymap-popup-annotate (keymap &rest body)
  "Annotate existing KEYMAP with popup descriptions.
BODY is optional :popup-key KEY, optional :exit-key KEY, optional
:description STRING-OR-FUNCTION, optional :persistent BOOL,
followed by :group keywords and COMMAND-SYMBOL DESCRIPTION pairs.
COMMAND-SYMBOL is a function symbol already bound in the keymap.
DESCRIPTION is a string or (STRING &rest PROPS).

Unlike `keymap-popup-define', no defaults are applied for
:popup-key or :exit-key.  Only explicitly provided values take
effect.  When :exit-key is omitted, the popup falls back to
`keymap-popup-default-exit-key' at display time.

Keys are resolved dynamically via `where-is-internal' at display
time, so the popup always reflects the user's current bindings."
  (declare (indent 1))
  (let* ((options (keymap-popup--extract-macro-opts
                   body keymap-popup--annotate-options "annotation"))
         (popup-key (plist-get options :popup-key))
         (exit-key (plist-get options :exit-key))
         (description (plist-get options :description))
         (persistent (plist-get options :persistent))
         (persistent-p (plist-member options :persistent))
         (bindings (plist-get options :bindings))
         (rows (keymap-popup--parse-bindings bindings 'annotate))
         (launcher (and popup-key (symbolp keymap)
                        (keymap-popup--launcher-name keymap))))
    `(progn
       ,@(cond
          (launcher
           `(,(keymap-popup--build-launcher-form keymap launcher)
             (keymap-popup--bind-launcher
              ,keymap ,popup-key #',launcher)))
          (popup-key
           `((keymap-popup--bind-launcher
              ,keymap ,popup-key
              (lambda () (interactive) (keymap-popup ,keymap))))))
       ,(keymap-popup--build-attach-form
         keymap (keymap-popup--build-descriptions-form rows)
         exit-key description persistent persistent-p))))

;;; Public API

;;;###autoload
(defun keymap-popup-attach (keymap bindings &rest opts)
  "Attach popup descriptions for BINDINGS to KEYMAP at runtime.
BINDINGS is an evaluated list shaped like `keymap-popup-annotate'
BODY: KEY (DESCRIPTION COMMAND . PROPS) or COMMAND-SYMBOL
DESCRIPTION pairs, optionally grouped with :group.  Commands and
predicates are actual objects, not forms.  OPTS is a plist
accepting :exit-key, :description, and :persistent.  Returns
KEYMAP.

Unlike the macros, this attaches descriptions computed from data,
so it suits anonymous keymaps and menus built from runtime lists.
Reattaching replaces prior descriptions and options; omitted
options return to their defaults.  It does not bind keys or define
commands; keyed entries should already be bound in KEYMAP.  Switch
entries require `keymap-popup-define' and are rejected here."
  (let ((parsed (keymap-popup--parse-options
                 opts keymap-popup--attach-options "attachment")))
    (when (cdr parsed)
      (keymap-popup--invalid "attachment" "expected option, got %S"
                             (car (cdr parsed))))
    (let* ((options (keymap-popup--validate-options
                     (car parsed) "attachment" t))
           (rows (keymap-popup--parse-bindings bindings 'runtime)))
      (when (seq-some (lambda (entry)
                        (eq (plist-get entry :type) 'switch))
                      (keymap-popup--flatten-with-groups rows))
        (keymap-popup--invalid
         "attachment" ":switch requires `keymap-popup-define'"))
      (apply #'keymap-popup--attach-meta keymap
             rows options))))

(defun keymap-popup--map-groups (rows fn)
  "Apply FN to each group in ROWS, returning the transformed rows.
FN receives a group plist and returns a new group plist."
  (mapcar (lambda (row) (mapcar fn row)) rows))

(defun keymap-popup--descriptions-present-p (rows)
  "Return non-nil if ROWS contain at least one entry."
  (seq-some (lambda (row)
              (seq-some (lambda (group)
                          (consp (plist-get group :entries)))
                        row))
            rows))

(defun keymap-popup--add-entry-to-rows (rows entry target)
  "Return ROWS with ENTRY appended to the group object TARGET."
  (keymap-popup--map-groups
   rows
   (lambda (group)
     (if (eq group target)
         (plist-put (copy-sequence group) :entries
                    (append (plist-get group :entries) (list entry)))
       group))))

(defun keymap-popup--remove-key-from-rows (rows key)
  "Return ROWS with entries matching KEY filtered out."
  (keymap-popup--map-groups
   rows
   (lambda (group)
     (plist-put (copy-sequence group) :entries
                (cl-remove-if
                 (lambda (e) (keymap-popup--same-key-p (plist-get e :key) key))
                 (plist-get group :entries))))))

;;;###autoload
(defun keymap-popup-add-entry (keymap key description command &optional group)
  "Add KEY binding with DESCRIPTION and COMMAND to KEYMAP.
GROUP is the group name to add to (nil or missing means the first group).
Updates both the keymap and the popup descriptions.  The destination
group's :if predicate governs direct dispatch; :inapt-if remains
popup-only.  Equivalent key spellings replace the same entry."
  (let ((descs (keymap-popup--meta keymap 'descriptions)))
    (or descs (user-error "No descriptions in keymap"))
    (let* ((entry (keymap-popup--parse-entry
                   key (list description command) 'runtime))
           (rows (keymap-popup--remove-key-from-rows descs key))
           (target (or (and group
                            (cl-loop for row in rows
                                     thereis (cl-find group row
                                                      :key (lambda (item)
                                                             (plist-get item :name))
                                                      :test #'equal)))
                       (caar rows))))
      (keymap-set keymap key
                  (keymap-popup--filter-binding command (plist-get target :if)))
      (setf (keymap-popup--meta keymap 'descriptions)
            (keymap-popup--add-entry-to-rows rows entry target)))))

;;;###autoload
(defun keymap-popup-remove-entry (keymap key)
  "Remove KEY binding from KEYMAP.
Updates both the keymap and the popup descriptions, including entries
whose key spelling denotes the same native events as KEY."
  (let ((descriptions (keymap-popup--meta keymap 'descriptions)))
    (or descriptions (user-error "No descriptions in keymap"))
    (let ((remaining (keymap-popup--remove-key-from-rows descriptions key)))
      (keymap-set keymap key nil)
      (setf (keymap-popup--meta keymap 'descriptions)
            (and (keymap-popup--descriptions-present-p remaining)
                 remaining)))))

;;; Renderer

(defconst keymap-popup--max-description-width 40
  "Maximum visible width of a resolved description, in columns.
Resolved descriptions longer than this are truncated with an
ellipsis.  Authors should keep descriptions short by convention;
this bound exists so dynamic descriptions can't blow out the
column layout.")

(defun keymap-popup--resolve-description (desc)
  "Resolve DESC to a display string.
If DESC is a function, call it.  Return nil for nil and stringify
other non-string values.  Collapse runs of whitespace and truncate to
`keymap-popup--max-description-width'."
  (let* ((raw (if (functionp desc) (funcall desc) desc))
         (text (and raw (if (stringp raw) raw (format "%s" raw))))
         (collapsed (and text (string-clean-whitespace text))))
    (and collapsed
         (truncate-string-to-width
          collapsed keymap-popup--max-description-width nil nil t))))

(defun keymap-popup--pad-width (string width)
  "Pad STRING with spaces to display WIDTH, preserving text properties."
  (concat string (make-string (max 0 (- width (string-width string))) ?\s)))

(defun keymap-popup--render-entry (entry &optional prefix-mode key-width)
  "Render ENTRY into a formatted line, or nil if :if hides it.
When PREFIX-MODE is non-nil, entries with :c-u are highlighted and
their :c-u description is shown; other entries are dimmed.
KEY-WIDTH pads the key column for alignment."
  (and (keymap-popup--if-allows-p entry)
       (and-let* ((raw-desc (keymap-popup--resolve-description
                             (plist-get entry :description))))
         (let* ((inapt (keymap-popup--inapt-active-p entry))
              (type (plist-get entry :type))
              (desc (if (eq type 'keymap)
			(propertize raw-desc 'face 'keymap-popup-submenu)
                      raw-desc))
              (c-u-desc (plist-get entry :c-u))
              (raw-key (plist-get entry :key))
              (mouse-props (unless inapt
                             (list 'keymap-popup--entry entry
                                   'mouse-face 'highlight)))
              (click-key (apply #'propertize raw-key mouse-props))
              (padded-key (if key-width
                              (keymap-popup--pad-width click-key key-width)
                            click-key))
              (key-str (propertize padded-key 'face 'keymap-popup-key))
              (value-str (if (eq type 'switch)
                             (propertize
                              (if (symbol-value (plist-get entry :variable))
				  " [on]" " [off]")
                              'face 'keymap-popup-value)
			   ""))
              (c-u-str (and c-u-desc
                            (propertize (format " (%s)" c-u-desc)
                                        'face (if prefix-mode 'warning 'shadow))))
              (line (concat "  " key-str "  "
                            (apply #'propertize
                                   (concat desc value-str (or c-u-str ""))
                                   mouse-props))))
	 (cond
	  (inapt (propertize line 'face 'keymap-popup-inapt))
	  ((and prefix-mode (not c-u-desc))
           (propertize line 'face 'shadow))
	  (t line))))))

(defun keymap-popup--render-group-lines (group &optional prefix-mode)
  "Render GROUP into a list of lines (strings).
When PREFIX-MODE is non-nil, pass it to entry rendering.
Returns nil if the group is hidden by :if or has no visible entries.
When the group has :inapt-if that returns non-nil, all entries are
rendered with the inapt face."
  (and (keymap-popup--if-allows-p group)
       (let* ((group-inapt (keymap-popup--inapt-active-p group))
              (entries (plist-get group :entries))
              (key-width (cl-loop for entry in entries
				  maximize (string-width (plist-get entry :key))))
              (header (and-let* ((raw-name (plist-get group :name))
				 (name (keymap-popup--resolve-description raw-name)))
			(propertize name 'face (if group-inapt
                                                   'keymap-popup-inapt
						 'keymap-popup-group-header))))
              (lines (cl-loop for entry in entries
                              when (keymap-popup--render-entry
				    entry prefix-mode key-width)
                              collect it)))
	 (and lines
              (let ((result (if header (cons header lines) lines)))
                (if group-inapt
		    (mapcar (lambda (line)
                              (propertize line 'face 'keymap-popup-inapt
                                          'keymap-popup--entry nil 'mouse-face nil))
			    result)
                  result))))))

(defun keymap-popup--column-width (col)
  "Return the max visible width of lines in COL."
  (cl-loop for line in col
           maximize (string-width line)))

(defun keymap-popup--join-columns (columns separator col-widths)
  "Join COLUMNS side by side with SEPARATOR between them.
COL-WIDTHS is a list of minimum widths per column position.
Shorter columns are padded with blank lines."
  (let* ((max-height (cl-loop for col in columns maximize (length col)))
         (padded-cols (cl-mapcar
                       (lambda (col width)
                         (let ((padded (mapcar (lambda (line)
                                                 (keymap-popup--pad-width line width))
                                               col))
                               (blanks (make-list (- max-height (length col))
                                                  (make-string width ?\s))))
                           (append padded blanks)))
                       columns col-widths)))
    (cl-loop for row from 0 below max-height
             collect (string-trim-right
                      (mapconcat (lambda (col) (nth row col))
                                 padded-cols
                                 separator)))))

(defun keymap-popup--rows-to-columns (rows &optional prefix-mode)
  "Render each row of ROWS into its list of column line-lists.
When PREFIX-MODE is non-nil, pass it to group rendering.
Returns a list of ((col-lines ...) ...) per row, filtering empty groups."
  (mapcar (lambda (row)
            (seq-keep (lambda (group)
                        (keymap-popup--render-group-lines group prefix-mode))
                      row))
          rows))

(defun keymap-popup--global-col-widths (rendered-rows)
  "Compute max column width per position across all RENDERED-ROWS."
  (let ((max-cols (or (cl-loop for cols in rendered-rows
                               maximize (length cols))
                      0)))
    (cl-loop for i from 0 below max-cols
             collect (cl-loop for cols in rendered-rows
                              when (nth i cols)
                              maximize (keymap-popup--column-width (nth i cols))))))

(defconst keymap-popup--column-separator "   "
  "Horizontal separator between popup columns.")

(defun keymap-popup--wrap-column-row (columns widths max-width)
  "Split COLUMNS and WIDTHS into rows fitting MAX-WIDTH.
Each result is a plist with :columns and :widths.  A single column
wider than MAX-WIDTH remains intact for final line truncation."
  (named-let wrap ((cols columns) (rest-widths widths)
                   (row-cols nil) (row-widths nil) (row-width 0)
                   (result nil))
    (if (null cols)
        (append result
                (and row-cols
                     (list (list :columns row-cols :widths row-widths))))
      (let* ((width (car rest-widths))
             (next-width (+ row-width width
                            (if row-cols
                                (string-width keymap-popup--column-separator)
                              0))))
        (if (and row-cols max-width (> next-width max-width))
            (wrap cols rest-widths nil nil 0
                  (append result
                          (list (list :columns row-cols :widths row-widths))))
          (wrap (cdr cols) (cdr rest-widths)
                (append row-cols (list (car cols)))
                (append row-widths (list width))
                next-width result))))))

(defun keymap-popup--layout-column-rows (rendered-rows widths max-width)
  "Return RENDERED-ROWS laid out within MAX-WIDTH using WIDTHS."
  (apply #'append
         (mapcar
          (lambda (columns)
            (keymap-popup--wrap-column-row
             columns (seq-take widths (length columns)) max-width))
          rendered-rows)))

(defun keymap-popup--fit-line (line max-width)
  "Return LINE truncated to MAX-WIDTH when necessary."
  (if (and max-width (> (string-width line) max-width))
      (truncate-string-to-width line max-width nil nil t)
    line))

(defun keymap-popup--render-columns (rendered-rows &optional max-width)
  "Render RENDERED-ROWS within MAX-WIDTH as a popup string."
  (let* ((max-width (and max-width (max 1 max-width)))
         (col-widths (keymap-popup--global-col-widths rendered-rows))
         (layout (keymap-popup--layout-column-rows
                  rendered-rows col-widths max-width))
         (sections
          (mapcar
           (lambda (row)
             (string-join
              (mapcar (lambda (line)
                        (keymap-popup--fit-line line max-width))
                      (keymap-popup--join-columns
                       (plist-get row :columns)
                       keymap-popup--column-separator
                       (plist-get row :widths)))
              "\n"))
           layout)))
    (concat (string-join sections "\n") "\n")))

(defun keymap-popup--render (rows &optional prefix-mode max-width)
  "Render ROWS into a complete popup string.
ROWS is a list of rows, each row a list of groups.  When PREFIX-MODE
is non-nil, highlight :c-u entries and dim others.  Align column
widths across declared rows.  When MAX-WIDTH is non-nil, flow groups
onto additional display rows and truncate any lone over-wide column."
  (keymap-popup--render-columns
   (keymap-popup--rows-to-columns rows prefix-mode) max-width))

;;; Popup state

(defvar-local keymap-popup--session nil
  "Popup session plist owned by the popup buffer.
The :active value is a navigation-state plist; :stack holds parent
states.  Session-wide source, prefix, persistence, backend, and hook
values live beside them.")

(defun keymap-popup--plist-with (plist &rest properties)
  "Return PLIST with PROPERTIES replaced without changing PLIST."
  (named-let replace ((result (copy-sequence plist)) (rest properties))
    (if (null rest)
        result
      (replace (plist-put result (car rest) (cadr rest)) (cddr rest)))))

(defun keymap-popup--session-state (buf)
  "Return BUF's popup session plist."
  (and (buffer-live-p buf)
       (buffer-local-value 'keymap-popup--session buf)))

(defun keymap-popup--session-get (buf property)
  "Return PROPERTY from BUF's popup session."
  (plist-get (keymap-popup--session-state buf) property))

(defun keymap-popup--popup-buffer ()
  "Return the live buffer owning the active popup, or nil."
  (and (buffer-live-p keymap-popup--buffer)
       (not (buffer-local-value 'buffer-file-name keymap-popup--buffer))
       (keymap-popup--session-state keymap-popup--buffer)
       (not (keymap-popup--session-get keymap-popup--buffer :closing))
       keymap-popup--buffer))

(defun keymap-popup--active-get (buf property)
  "Return PROPERTY from BUF's active popup state."
  (plist-get (keymap-popup--session-get buf :active) property))

(defun keymap-popup--set-session (buf &rest properties)
  "Replace PROPERTIES in BUF's popup session."
  (with-current-buffer buf
    (unless keymap-popup--session
      (error "Popup session is no longer active"))
    (setq-local keymap-popup--session
                (apply #'keymap-popup--plist-with
                       keymap-popup--session properties))))

(defun keymap-popup--set-active (buf &rest properties)
  "Replace PROPERTIES in BUF's active popup state."
  (let ((active (keymap-popup--session-get buf :active)))
    (keymap-popup--set-session
     buf :active (apply #'keymap-popup--plist-with active properties))))

(defun keymap-popup--make-state (keymap descriptions docstring exit-key)
  "Return state for KEYMAP, DESCRIPTIONS, DOCSTRING, and EXIT-KEY."
  (list :keymap keymap
        :descriptions descriptions
        :docstring docstring
        :resolved-docstring nil
        :exit-key exit-key
        :wrapper-map nil
        :exit-function nil))

;;; Popup display

(defun keymap-popup--dedupe-descriptions (descriptions)
  "Return DESCRIPTIONS with duplicate-key entries removed.
The first occurrence of each key wins; later duplicates are dropped.
Entries with nil :key (annotated entries before key resolution)
are preserved as-is.  Groups and rows that end up empty are removed."
  (let ((seen (make-hash-table :test 'equal)))
    (cl-labels ((keep-entry (e)
                  (let ((k (keymap-popup--key-events (plist-get e :key))))
                    (cond ((null k) e)
                          ((gethash k seen) nil)
                          (t (puthash k t seen) e))))
                (keep-group (g)
                  (and-let* ((es (seq-keep #'keep-entry (plist-get g :entries))))
                    (plist-put (copy-sequence g) :entries es)))
                (keep-row (r)
                  (seq-keep #'keep-group r)))
	       (seq-keep #'keep-row descriptions))))

(defun keymap-popup--collect-descriptions (keymap)
  "Collect descriptions from KEYMAP, its components and parents.
Visit local metadata in native keymap traversal order.  Copy groups
with their :source-maps so resolution can reject filtered-out paths
before applying key precedence.  Shared parents may have more than
one path.  Keep all candidates, including unresolved annotation keys."
  (let ((rows nil))
    (cl-labels
        ((visit (map sources)
           (let* ((sources (cons map sources))
                  (tail
                   (map-keymap-internal
                    (lambda (event binding)
                      (when (eq event 'keymap-popup)
                        (push (keymap-popup--map-groups
                               (plist-get (keymap-popup--metadata-properties binding)
                                          'descriptions)
                               (lambda (group)
                                 (plist-put (copy-sequence group)
                                            :source-maps sources)))
                              rows)))
                    map)))
             ;; Retain component boundaries: a filtered child masks its
             ;; parent, even if another composed component has a binding.
             (while (and (consp tail) (keymapp (car tail)))
               (visit (car tail) sources)
               (setq tail (cdr tail)))
             (when tail
               (visit (if (keymapp tail) tail (cons 'keymap tail)) sources)))))
      (visit keymap nil))
    (apply #'append (nreverse rows))))

(defun keymap-popup--find-entry-with-group (descriptions key-str)
  "Return (ENTRY . GROUP) matching KEY-STR in DESCRIPTIONS."
  (let ((key (keymap-popup--key-events key-str)))
    (cl-loop for row in descriptions
             thereis (cl-loop for group in row
                              for entry = (cl-find
                                           key (plist-get group :entries)
                                           :key (lambda (item)
                                                  (keymap-popup--key-events
                                                   (plist-get item :key)))
                                           :test #'equal)
                              when entry return (cons entry group)))))

(defun keymap-popup--find-entry-by-key (descriptions key-str)
  "Find the entry matching KEY-STR in DESCRIPTIONS.
DESCRIPTIONS is a list of rows, each row a list of groups.
Returns the entry plist, or nil."
  (car (keymap-popup--find-entry-with-group descriptions key-str)))

(defun keymap-popup--keep-popup-p (descriptions key-str)
  "Return non-nil if KEY-STR should keep the popup open in DESCRIPTIONS.
True for switches, stay-open suffixes, and :keymap entries with a
target.  Inapt-key handling is folded into the keep-pred via
`keymap-popup--inapt-key-p'."
  (and-let* ((entry (keymap-popup--find-entry-by-key descriptions key-str)))
    (or (eq (plist-get entry :type) 'switch)
        (plist-get entry :stay-open)
        (and (eq (plist-get entry :type) 'keymap)
             (plist-get entry :target)))))

(defun keymap-popup--active-descriptions (buf)
  "Return BUF's descriptions resolved against current native bindings."
  (let* ((active (keymap-popup--session-get buf :active))
         (candidates (plist-get active :description-candidates))
         (source (keymap-popup--session-get buf :source))
         (rows (if candidates
                   (with-current-buffer (if (buffer-live-p source) source (current-buffer))
                     (keymap-popup--resolve-descriptions
                      candidates (plist-get active :keymap)))
                 (plist-get active :descriptions))))
    ;; These keys are popup controls, regardless of their source bindings.
    ;; Do not advertise (or make clickable) an action they cannot execute.
    (keymap-popup--map-groups
     rows
     (lambda (group)
       (plist-put
        (copy-sequence group) :entries
        (seq-remove
         (lambda (entry)
           (let ((events (keymap-popup--key-events (plist-get entry :key))))
             (seq-some (lambda (key)
                         (let ((control (keymap-popup--key-events key)))
                           (and control
                                (equal control (seq-take events (length control))))))
                       (list (plist-get active :exit-key) "C-u"))))
         (plist-get group :entries)))))))

(defun keymap-popup--inapt-key-p (buf key-str)
  "Return non-nil when KEY-STR is currently inapt in BUF's popup.
Checks both the entry's own :inapt-if and its containing group's;
group predicates are not merged into the descriptions tree.
Returns nil when BUF is dead (the popup already closed)."
  (and (buffer-live-p buf)
       (pcase-let ((`(,entry . ,group)
                     (keymap-popup--find-entry-with-group
                      (keymap-popup--active-descriptions buf) key-str)))
         (and entry
              (or (keymap-popup--inapt-active-p entry)
                  (keymap-popup--inapt-active-p group))))))

(defun keymap-popup--write-rendered (buf rendered-rows)
  "Write RENDERED-ROWS and BUF's navigation hint, then refit its backend."
  (unless (keymap-popup--session-state buf)
    (error "Popup session is no longer active"))
  (let* ((window (if (plist-member (keymap-popup--session-state buf) :window)
                     (keymap-popup--display-window buf)
                   (get-buffer-window buf t)))
         ;; `window-body-width' includes the continuation column.
         (width (and window (max 1 (1- (window-body-width window)))))
         (content (keymap-popup--render-columns rendered-rows width)))
    (with-current-buffer buf
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert content)
        ;; This describes navigation, not the swallowed source binding.
        ;; Keep it outside the action columns and without mouse properties.
        ;; C-u's prefix override also shadows any exit below that prefix.
        (when-let* ((exit (keymap-popup--active-get buf :exit-key))
                    ((not (eq (car (keymap-popup--key-events exit)) ?\C-u))))
          (insert "\n"
                  (keymap-popup--fit-line
                   (concat "  " (propertize (substring-no-properties exit)
                                            'face 'keymap-popup-key)
                           "  " (if (keymap-popup--session-get buf :stack)
                                    "Back" "Dismiss menu"))
                   width)
                  "\n"))
        (goto-char (point-min))))
    (when-let* ((fit (plist-get (keymap-popup--session-get buf :backend) :fit)))
      (funcall fit buf))
    rendered-rows))

(defun keymap-popup--refresh-buffer (buf descriptions &optional prefix-mode)
  "Re-render popup BUF with DESCRIPTIONS, refit via backend.
PREFIX-MODE toggles prefix argument highlighting.  When BUF is
visible, flow groups within its window's usable text width.  Return
the rendered columns so an initial display can reflow them unchanged."
  (keymap-popup--write-rendered
   buf (keymap-popup--rows-to-columns descriptions prefix-mode)))

(defun keymap-popup--refresh (buf)
  "Re-render popup BUF from its buffer-local state.
Renders in the source buffer's context so `symbol-value' for
switch variables sees the user's buffer-local values.
Resolves the docstring for mode-line display."
  (when (buffer-live-p buf)
    (let* ((session (keymap-popup--session-state buf))
           (active (plist-get session :active))
           (source (plist-get session :source))
           (descriptions (keymap-popup--active-descriptions buf))
           (docstring (plist-get active :docstring))
           (prefix (plist-get session :prefix-mode)))
      (keymap-popup--set-active buf :descriptions descriptions)
      (with-current-buffer (if (buffer-live-p source) source buf)
        (let ((resolved (and docstring
                             (keymap-popup--resolve-description docstring))))
          (keymap-popup--set-active buf :resolved-docstring resolved))
        (keymap-popup--refresh-buffer buf descriptions prefix)))))

(defun keymap-popup--resolve-key (entry keymap)
  "Return ENTRY with :key reflecting KEYMAP's current bindings.
An entry keeps its stored :key while that key still dispatches to
the entry's :command.  When the command has been rebound,
`where-is-internal' supplies the current key; when it finds no
binding, an unbound stored key is kept to cover `:if' filters.
A stored key now bound to a different command is dropped.  Entries
with no stored :key (annotated) resolve via `where-is-internal' and
are dropped when
unbound.  Resolution searches only KEYMAP and its parents, never
the global map."
  (let ((cmd (plist-get entry :command))
        (stored (plist-get entry :key)))
    (cond
     ((null cmd) entry)
     ((and stored (eq (keymap-lookup keymap stored) cmd)) entry)
     (t (let ((keys (where-is-internal cmd (list keymap) t)))
          (cond
           (keys (plist-put (copy-sequence entry) :key
                            (key-description keys)))
           ((and stored (null (keymap-lookup keymap stored))) entry)))))))

(defun keymap-popup--resolve-entry-path (entry sources)
  "Resolve ENTRY from its origin through SOURCES to the active keymap.
Follow rebinding at each step, not the final key in every ancestor.
A live binding must survive the whole path; otherwise a filtered-out
component could donate metadata to another component's binding.
When the final key is unbound, retain its hidden-key fallback."
  (cl-loop with resolved = entry
           for source in sources
           do (setq resolved (and resolved
                                  (keymap-popup--resolve-key resolved source)))
           for key = (plist-get resolved :key)
           for binding = (and key (keymap-lookup source key))
           collect binding into bindings
           finally return
           (and resolved
                (or (null binding)
                    (if (plist-get entry :command)
                        (seq-every-p (lambda (value) (eq value binding)) bindings)
                      ;; Runtime submenus are popup-only overrides.  Native
                      ;; prefixes may merge into a new composed keymap.
                      (seq-every-p #'identity bindings)))
                resolved)))

(defun keymap-popup--resolve-descriptions (rows keymap)
  "Resolve entry keys in ROWS against KEYMAP's current bindings.
Drop unbound annotations and metadata from filtered-out components
when another component supplies the binding.  Preserve hidden keys
when the whole map has no binding.  Only then remove duplicate keys."
  (keymap-popup--dedupe-descriptions
   (keymap-popup--map-groups
    rows
    (lambda (group)
      (plist-put
       (copy-sequence group) :entries
       (seq-keep (lambda (entry)
                   (keymap-popup--resolve-entry-path
                    entry (or (plist-get group :source-maps) (list keymap))))
                 (plist-get group :entries)))))))

;;; Display backends

(defun keymap-popup--display-window (buf)
  "Return BUF's owned display window if it still displays BUF."
  (let ((window (keymap-popup--session-get buf :window)))
    (and (window-live-p window)
         (eq (window-buffer window) buf)
         window)))

(defun keymap-popup--show-side-window (buf)
  "Display BUF and retain the chosen window in its session."
  (let ((window (display-buffer buf keymap-popup-display-action)))
    (keymap-popup--set-session buf :window window)
    window))

(defun keymap-popup--fit-side-window (buf)
  "Refit the display window owned by BUF."
  (when-let* ((window (keymap-popup--display-window buf)))
    (fit-window-to-buffer window)))

(defun keymap-popup--hide-side-window (buf)
  "Retire BUF's display, restoring a reused window natively."
  (when-let* ((window (keymap-popup--display-window buf)))
    (quit-restore-window window 'killing)))

(defun keymap-popup--show-child-frame (buf)
  "Display BUF in a child frame centered on the parent.
Frame parameters are taken from `keymap-popup-child-frame-parameters'."
  (let* ((parent (selected-frame))
         ;; Skip window-system init hooks (DnD, terminal face setup,
         ;; user hooks); irrelevant for an ephemeral popup frame.
         (after-make-frame-functions nil)
         (frame (make-frame
                 `((parent-frame . ,parent)
                   (minibuffer . ,(minibuffer-window))
                   (visibility . nil)
                   ,@keymap-popup-child-frame-parameters)))
         (win (frame-root-window frame)))
    ;; Record allocation before any fitting or user-visible operation can fail.
    (keymap-popup--set-session buf :frame frame)
    (set-window-buffer win buf)
    (keymap-popup--set-session buf :window win)
    (set-window-dedicated-p win t)
    (fit-frame-to-buffer frame)
    (let ((x (/ (- (frame-pixel-width parent) (frame-pixel-width frame)) 2))
          (y (/ (- (frame-pixel-height parent) (frame-pixel-height frame)) 2)))
      (set-frame-position frame (max 0 x) (max 0 y)))
    (make-frame-visible frame)
    (redirect-frame-focus frame parent)))

(defun keymap-popup--fit-child-frame (buf)
  "Refit the child frame owned by BUF."
  (when-let* ((frame (keymap-popup--session-get buf :frame))
              ((frame-live-p frame))
              ((keymap-popup--display-window buf)))
    (fit-frame-to-buffer frame)))

(defun keymap-popup--hide-child-frame (buf)
  "Delete the child frame allocated for BUF."
  (when-let* ((frame (keymap-popup--session-get buf :frame))
              ((frame-live-p frame))
              ((or (null (keymap-popup--session-get buf :window))
                   (keymap-popup--display-window buf))))
    (delete-frame frame)))

(defun keymap-popup-backend-side-window ()
  "Return a side-window display backend."
  (list :show #'keymap-popup--show-side-window
        :fit #'keymap-popup--fit-side-window
        :hide #'keymap-popup--hide-side-window))

(defun keymap-popup-backend-child-frame ()
  "Return a child-frame display backend."
  (list :show #'keymap-popup--show-child-frame
        :fit #'keymap-popup--fit-child-frame
        :hide #'keymap-popup--hide-child-frame))

(defun keymap-popup--prepare-buffer ()
  "Allocate and configure a new popup buffer without claiming a name."
  (let ((buf (generate-new-buffer keymap-popup--buffer-name))
        (complete nil))
    (setq keymap-popup--buffer buf)
    (unwind-protect
        (progn
          (with-current-buffer buf
            (pcase-dolist (`(,var . ,val) keymap-popup-buffer-parameters)
              (set (make-local-variable var) val)))
          (setq complete t)
          buf)
      (unless complete
        (when (eq keymap-popup--buffer buf)
          (setq keymap-popup--buffer nil))
        (condition-case err
            (kill-buffer buf)
          ((error quit) (message "Popup cleanup failed: %s"
                                 (error-message-string err))))))))

;; `internal-{push,pop}-keymap' are the only public path for manipulating
;; `overriding-terminal-local-map'; `set-transient-map' itself uses them.

(defun keymap-popup--session-wrapper-maps (session)
  "Return SESSION's wrapper maps in highest-to-lowest priority order."
  (seq-keep (lambda (state) (plist-get state :wrapper-map))
            (cons (plist-get session :active)
                  (plist-get session :stack))))

(defun keymap-popup--suspend ()
  "Suspend the popup's transient maps for minibuffer input."
  (when-let* ((buf (keymap-popup--popup-buffer))
              (session (keymap-popup--session-state buf)))
    (unless (plist-get session :suspended-depth)
      (keymap-popup--set-session
       buf :suspended-depth (minibuffer-depth))
      (mapc (lambda (map)
              (internal-pop-keymap map 'overriding-terminal-local-map))
            (keymap-popup--session-wrapper-maps session)))))

(defun keymap-popup--resume ()
  "Resume the popup's transient maps after minibuffer input."
  (when-let* ((buf (keymap-popup--popup-buffer))
              (session (keymap-popup--session-state buf))
              (depth (plist-get session :suspended-depth))
              ((= depth (minibuffer-depth))))
    (keymap-popup--set-session buf :suspended-depth nil)
    (mapc (lambda (map)
            (internal-push-keymap map 'overriding-terminal-local-map))
          (reverse (keymap-popup--session-wrapper-maps session)))))

(defun keymap-popup--session-exit-functions (session include-active)
  "Return exit functions owned by SESSION.
INCLUDE-ACTIVE includes the active transient map as well as parents."
  (let* ((active (plist-get session :active))
         (states (if include-active
                     (cons active (plist-get session :stack))
                   (plist-get session :stack))))
    (seq-keep (lambda (state)
                (and-let* ((exit (plist-get state :exit-function))
                           ((functionp exit)))
                  exit))
              states)))

(defun keymap-popup--close-session (session include-active)
  "Deactivate SESSION's captured maps after marking its buffer closing.
INCLUDE-ACTIVE also deactivates the active transient map."
  (let ((exits (keymap-popup--session-exit-functions session include-active))
        (failure nil))
    (dolist (exit exits)
      (condition-case err
          (funcall exit)
        ((error quit) (unless failure (setq failure err)))))
    (when failure (signal (car failure) (cdr failure)))))

(defun keymap-popup--remove-session-hooks (session)
  "Remove hooks owned by the captured SESSION."
  (remove-hook 'minibuffer-setup-hook #'keymap-popup--suspend)
  (remove-hook 'minibuffer-exit-hook #'keymap-popup--resume)
  (when-let* ((source (plist-get session :source))
              ((buffer-live-p source))
              (retire (plist-get session :source-retire)))
    (with-current-buffer source
      (remove-hook 'change-major-mode-hook retire t)
      (remove-hook 'after-set-visited-file-name-hook retire t)))
  (when-let* ((hook (plist-get session :persistent-hook)))
    (remove-hook 'post-command-hook hook)))

(defun keymap-popup--clear-session (buf)
  "Detach BUF from its session and native lifecycle hooks."
  (with-current-buffer buf
    (setq keymap-popup--session nil)
    (when (eq keymap-popup--buffer buf)
      (setq keymap-popup--buffer nil))
    (remove-hook 'kill-buffer-hook #'keymap-popup--kill-buffer-cleanup t)
    (remove-hook 'change-major-mode-hook #'keymap-popup--kill-buffer-cleanup t)
    (remove-hook 'after-set-visited-file-name-hook
                 #'keymap-popup--kill-buffer-cleanup t)))

(defun keymap-popup--hide-session (buf)
  "Hide the display owned by BUF's popup session."
  (when-let* ((backend (keymap-popup--session-get buf :backend))
              (hide (plist-get backend :hide)))
    (funcall hide buf)))

(defun keymap-popup--cleanup (buf &optional keep-buffer)
  "Retire BUF's session, completing internal cleanup after callback failures.
With KEEP-BUFFER, leave BUF alive for its native kill or mode change.
Otherwise kill BUF only while the closing session still owns it.
Signal the first cleanup failure after attempting the remaining steps."
  (when (and (buffer-live-p buf)
             (or (eq keymap-popup--buffer buf)
                 (keymap-popup--session-state buf)))
    (save-current-buffer
      (let* ((session (keymap-popup--session-state buf))
             (closing (and session (keymap-popup--set-session buf :closing t)))
             (failure nil)
             (inhibit-quit t))
        ;; Retire captured input resources even if a callback repurposes BUF.
        (dolist (step (list (lambda () (keymap-popup--close-session session t))
                            (lambda () (keymap-popup--remove-session-hooks session))
                            (lambda ()
                              (when (eq (keymap-popup--session-state buf) closing)
                                (keymap-popup--hide-session buf)))))
          (condition-case err
              (funcall step)
            ((error quit) (unless failure (setq failure err)))))
        (when (and (buffer-live-p buf)
                   (eq (keymap-popup--session-state buf) closing))
          (with-current-buffer buf
            (keymap-popup--clear-session buf)
            (unless (or keep-buffer buffer-file-name)
              (condition-case err
                  (kill-buffer buf)
                ((error quit) (unless failure (setq failure err)))))))
        (when failure (signal (car failure) (cdr failure)))))))

(defun keymap-popup--kill-buffer-cleanup ()
  "Retire popup resources before buffer death or an ownership change."
  (when keymap-popup--session
    (if (plist-get keymap-popup--session :closing)
        ;; Closing suppresses recursive cleanup, not ownership retirement.
        (keymap-popup--clear-session (current-buffer))
      ;; A backend failure must not veto the native kill or mode change.
      (condition-case err
          (keymap-popup--cleanup (current-buffer) t)
        ((error quit) (message "Popup cleanup failed: %s"
                               (error-message-string err)))))))

(defun keymap-popup--teardown (buf)
  "Remove the popup display for BUF and kill it."
  (keymap-popup--cleanup buf))

(defun keymap-popup--ignore-mouse ()
  "Ignore a popup mouse event without consuming its pending prefix."
  (interactive)
  (prefix-command-preserve-state)
  ;; Emacs 29 does not restore this part of native prefix history.
  (setq current-prefix-arg last-prefix-arg))

(defun keymap-popup--mouse-entry (buf position)
  "Return BUF's entry at mouse POSITION, excluding non-text areas."
  (let ((window (posn-window position))
        (point (posn-point position)))
    (when (and (eq window (keymap-popup--display-window buf))
               (null (posn-area position))
               (integerp point))
      (with-current-buffer buf
        (when (and (<= (point-min) point) (< point (point-max)))
          (get-text-property point 'keymap-popup--entry))))))

(defun keymap-popup--mouse-owner-p (buf wrapper session)
  "Return non-nil if BUF and WRAPPER still own SESSION's mouse source.
This check runs no predicates or menu filters."
  (let ((source (plist-get session :source))
        (window (plist-get session :source-window))
        (lifetime (plist-get session :source-live)))
    (and (car lifetime)
         (eq lifetime (keymap-popup--session-get buf :source-live))
         (eq buf (keymap-popup--popup-buffer))
         (not (active-minibuffer-window))
         (buffer-live-p source)
         (window-live-p window)
         (eq (window-buffer window) source)
         (eq (selected-window) window)
         (eq (current-buffer) source)
         (eq wrapper (keymap-popup--active-get buf :wrapper-map)))))

(defun keymap-popup--mouse-current-p (buf wrapper entry)
  "Return non-nil when ENTRY is available in BUF through WRAPPER."
  (let ((session (keymap-popup--session-state buf))
        (key (plist-get entry :key)))
    (and entry
         (keymap-popup--mouse-owner-p buf wrapper session)
         (pcase-let ((`(,current . ,group)
                      (keymap-popup--find-entry-with-group
                       (keymap-popup--active-descriptions buf) key)))
           (and (equal entry current)
                (keymap-popup--if-allows-p current)
                (keymap-popup--if-allows-p group)
                (not (keymap-popup--inapt-active-p current))
                (not (keymap-popup--inapt-active-p group))
                (keymap-lookup (keymap-popup--active-get buf :keymap) key)
                (let* ((binding (key-binding (key-parse key)))
                       (failure (and (symbolp binding)
                                     (get binding 'keymap-popup--failure))))
                  (when failure (signal (car failure) (cdr failure)))
                  (commandp binding))))
         ;; Predicates and menu filters can run Lisp; recheck ownership.
         (keymap-popup--mouse-owner-p buf wrapper session))))

(defun keymap-popup--mouse-replay (buf wrapper entry)
  "Replay BUF's ENTRY as native keys, qualified by WRAPPER and source.
A one-command guard rejects stale queued input before native teardown.
Like keyboard input, dispatch remains subject to later command hooks."
  (let* ((keys (key-parse (plist-get entry :key)))
         (session (keymap-popup--session-state buf))
         (epoch (keymap-popup--session-get buf :mouse-epoch))
         (events (mapcar (lambda (event) (cons t event))
                         (listify-key-sequence keys)))
         (guard (make-symbol "keymap-popup--mouse-replay")))
    (fset guard
          (lambda ()
            (remove-hook 'pre-command-hook guard)
            (let ((command this-command))
              (setq this-command
                    (condition-case err
                        (cond
                         ;; A captured failure is diagnostic, not an action.
                         ;; Preserve it even if its callback retired this owner.
                         ((and (symbolp command)
                               (get command 'keymap-popup--failure)) command)
                         ((and (equal keys (this-command-keys-vector))
                               (keymap-popup--mouse-current-p buf wrapper entry))
                          (let ((binding (key-binding keys)))
                            (cond
                             ((and (symbolp binding)
                                   (get binding 'keymap-popup--failure)) binding)
                             ;; Even the final lookup can run a menu filter.
                             ((and (eq command binding)
                                   (keymap-popup--mouse-owner-p buf wrapper session)
                                   (eq epoch (keymap-popup--session-get buf :mouse-epoch)))
                              command)
                             (t #'keymap-popup--ignore-mouse))))
                         (t #'keymap-popup--ignore-mouse))
                      ((error quit) (keymap-popup--failure-command err))))
              (when (or (eq this-command #'keymap-popup--ignore-mouse)
                        (and (symbolp this-command)
                             (get this-command 'keymap-popup--failure)))
                (setq real-this-command this-command)
                ;; Remove only this replay's as-yet unread events.
                (setq unread-command-events
                      (seq-remove (lambda (event) (memq event events))
                                  unread-command-events))))))
    (add-hook 'pre-command-hook guard -90)
    (setq unread-command-events (append events unread-command-events))))

(defun keymap-popup--mouse (event)
  "Handle owned popup EVENT without selecting its display window.
Only a matched left-button press and release activates an entry.
Replay its key, not a saved command, so native lookup, remapping and
popup policy apply."
  (interactive "e")
  (keymap-popup--ignore-mouse)
  (when-let* ((buf (keymap-popup--popup-buffer)))
    (let* ((entry (keymap-popup--mouse-entry buf (event-start event)))
           (wrapper (keymap-popup--active-get buf :wrapper-map))
           (epoch (keymap-popup--session-get buf :mouse-epoch))
           (window (keymap-popup--session-get buf :source-window))
           (press (keymap-popup--session-get buf :mouse-press)))
      (keymap-popup--set-session buf :mouse-press nil)
      (pcase (car event)
        ('down-mouse-1
         (unless (active-minibuffer-window)
           (keymap-popup--set-session buf :mouse-press (cons wrapper entry))))
        ('mouse-1
         (when (and press
                    (eq wrapper (car press))
                    (equal entry (cdr press))
                    (not (active-minibuffer-window))
                    (window-live-p window)
                    (eq (window-buffer window)
                        (keymap-popup--session-get buf :source))
                    (with-selected-window window
                      (keymap-popup--mouse-current-p buf wrapper entry))
                    (eq epoch (keymap-popup--session-get buf :mouse-epoch)))
           (select-window window)
           (keymap-popup--mouse-replay buf wrapper entry)))))))

(defun keymap-popup--failure-command (condition)
  "Return a native command that signals the captured CONDITION.
Mark this uninterned command so the keep predicate cannot overwrite the
original failure with a later policy evaluation.  No session owns it:
the failing callback may already have opened a successor popup."
  (let ((command (make-symbol "keymap-popup--failure")))
    (fset command (lambda () (interactive)
                   (signal (car condition) (cdr condition))))
    (put command 'keymap-popup--failure condition)
    command))

(defun keymap-popup--make-keep-pred (buf)
  "Return a keep-pred for `set-transient-map'.
Read state from BUF and consume its reentering flag on read.
Defer predicate failures to command execution so an error or quit cannot
remove the native exit hook while leaving its transient map installed."
  (lambda ()
    (condition-case err
        (and (buffer-live-p buf)
             (let* ((session (keymap-popup--session-state buf))
                    (active (plist-get session :active))
                    (key-str (key-description (this-command-keys-vector))))
               (cond
                ((and (symbolp this-command)
                      (get this-command 'keymap-popup--failure)) t)
                ((and (mouse-event-p last-input-event)
                      (let ((window (posn-window (event-start last-input-event))))
                        (and (window-live-p window)
                             (eq (window-buffer window) buf))))
                 ;; Consume the position before any suffix retires its window.
                 ;; This hook stays active while maps are suspended for a reader.
                 (setq this-command #'keymap-popup--mouse)
                 (keymap-popup--set-session buf :reentering nil)
                 t)
                ((eq this-command #'keymap-popup--ignore-mouse) t)
                ((active-minibuffer-window) t)
                ((plist-get session :reentering)
                 (keymap-popup--set-session buf :reentering nil)
                 t)
                ((memq this-command
                       '(universal-argument universal-argument-more
                         digit-argument negative-argument
                         keymap-popup--prefix-argument
                         describe-key describe-key-briefly)))
                ((keymap-popup--same-key-p key-str (plist-get active :exit-key)) nil)
                ((eq this-command 'keyboard-quit) nil)
                ((keymap-popup--inapt-key-p buf key-str)
                 ;; Lookup preceded earlier pre-command hooks.  Enforce the
                 ;; refusal observed here, without wrapping accepted commands.
                 (setq this-command
                       (lambda () (interactive)
                         (keymap-popup--refuse-inapt buf))
                       real-this-command this-command)
                 t)
                ((plist-get session :persistent)
                 ;; Settle presentation before native dispatch, even on failure.
                 (keymap-popup--consume-prefix buf)
                 t)
                ((keymap-popup--keep-popup-p
                  (keymap-popup--active-descriptions buf) key-str)
                 (keymap-popup--consume-prefix buf)
                 t))))
      ((error quit)
       ;; Fail closed outside `pre-command-hook', preserving the exact failure.
       ;; Do not clean up here: the predicate may have installed a successor.
       (setq this-command (keymap-popup--failure-command err)
             real-this-command this-command)
       t))))

(defun keymap-popup--make-on-exit (buf)
  "Return an on-exit callback for `set-transient-map' closing BUF.
Pops the sub-menu stack if exit-key or \\`C-g' caused the exit,
otherwise tears down completely."
  (lambda ()
    (when (buffer-live-p buf)
      (let* ((session (keymap-popup--session-state buf))
             (active (plist-get session :active))
             (stack (plist-get session :stack))
             (key-str (key-description (this-command-keys-vector))))
        (unless (plist-get session :closing)
          (if (and stack
                   (or (keymap-popup--same-key-p key-str (plist-get active :exit-key))
                       (equal key-str "C-g")))
              (progn
                (keymap-popup--set-session
                 buf :active (car stack) :stack (cdr stack)
                 :mouse-press nil :mouse-epoch (make-symbol "mouse-navigation")
                 :reentering t :prefix-mode nil)
                (keymap-popup--refresh buf))
            (keymap-popup--teardown buf)))))))

(defun keymap-popup--state-for-keymap (keymap)
  "Derive navigation state from KEYMAP."
  (let ((candidates (keymap-popup--collect-descriptions keymap)))
    (keymap-popup--plist-with
     (keymap-popup--make-state
      keymap (keymap-popup--resolve-descriptions candidates keymap)
      (keymap-popup--meta keymap 'description)
      (or (keymap-popup--meta keymap 'exit-key)
          keymap-popup-default-exit-key))
     :description-candidates candidates)))

(defun keymap-popup--resolve-submenu-target (target)
  "Return TARGET's keymap value or signal a clear user error."
  (let ((keymap (if (symbolp target)
                    (and (boundp target) (symbol-value target))
                  target)))
    (or (and (keymapp keymap) keymap)
        (user-error "Submenu target %S is not a keymap" target))))

(defun keymap-popup--push-submenu (buf child-keymap)
  "Push current popup state in BUF and activate CHILD-KEYMAP's transient map."
  (let* ((child-keymap (keymap-popup--resolve-submenu-target child-keymap))
         (session (keymap-popup--session-state buf))
         (parent (plist-get session :active))
         (child (keymap-popup--state-for-keymap child-keymap))
         (stack (cons parent (plist-get session :stack)))
         (content (with-current-buffer buf (buffer-string)))
         (position (with-current-buffer buf (point)))
         (complete nil))
    (or (keymap-popup--descriptions-present-p
         (plist-get child :descriptions))
        (user-error "No descriptions in keymap"))
    (unwind-protect
        (progn
          (keymap-popup--set-session
           buf :active child :stack stack
           :mouse-press nil :mouse-epoch (make-symbol "mouse-navigation")
           :prefix-mode nil)
          (keymap-popup--refresh buf)
          (keymap-popup--activate-transient-map buf)
          (setq complete t))
      ;; A failed callback must not leave child state driving the parent map.
      ;; Restore only this still-owned push, never a retired or replaced view.
      (when (and (not complete)
                 (eq (keymap-popup--popup-buffer) buf)
                 (eq (keymap-popup--session-get buf :stack) stack))
        (with-current-buffer buf
          (setq keymap-popup--session session)
          (let ((inhibit-read-only t))
            (erase-buffer)
            (insert content)
            (goto-char position)))))))

(defun keymap-popup--prefix-argument ()
  "Toggle prefix argument mode in the active popup.
When toggling on, activates `universal-argument-map' so that
subsequent digit and `negative-argument' keys refine the prefix."
  (interactive)
  (when-let* ((buf (keymap-popup--popup-buffer)))
    (let ((enabled (not (keymap-popup--session-get buf :prefix-mode))))
      (keymap-popup--set-session buf :prefix-mode enabled)
      (setq prefix-arg (and enabled '(4)))
      (keymap-popup--refresh buf)
      (when enabled
        (universal-argument--mode)))))

(defun keymap-popup--core-overrides (exit-key)
  "Return alist of core overrides for EXIT-KEY and prefix toggle.
The exit key is bound to `ignore'; the keep-pred exits on the key
itself, so the binding only needs to exist and do nothing."
  (list (cons exit-key #'ignore)
        (cons "C-u" #'keymap-popup--prefix-argument)))

(defun keymap-popup--refuse-inapt (buf)
  "Refuse an inapt key press for the popup in BUF.
Preserves the current prefix argument while BUF's prefix-mode is
active, including refinements made with digits or a minus sign."
  (message "Command unavailable")
  (when (and (buffer-live-p buf)
             (keymap-popup--session-get buf :prefix-mode))
    (setq prefix-arg current-prefix-arg)))

(defun keymap-popup--call-real-binding (keymap key-str)
  "Call KEY-STR's live binding in KEYMAP if it is a command.
Set native command identities for a retained control handler.
Ordinary suffix lookup leaves remapping to the native reader; this
fallback has already passed that boundary and must remap exactly once.
Return the binding, which may be nil."
  (let* ((original (keymap-lookup keymap key-str nil t))
         (cmd (or (and (symbolp original)
                       (command-remapping original))
                  original)))
    (when (commandp cmd)
      (setq this-original-command original
            this-command cmd
            real-this-command cmd)
      ;; The outer command loop has already consumed `prefix-arg'.
      (let ((prefix-arg current-prefix-arg))
        (command-execute cmd)))
    cmd))

(defun keymap-popup--consume-prefix (buf)
  "Clear prefix presentation owned by popup BUF before command dispatch.
Leave native prefix arguments to the command loop, including any new
prefix established by the command.  Refresh before dispatch so errors
and quits cannot leave consumed prefix highlighting behind."
  (when (keymap-popup--session-get buf :prefix-mode)
    (keymap-popup--set-session buf :prefix-mode nil)
    (keymap-popup--refresh buf)))

(defun keymap-popup--dispatch-entry (keymap entry buf)
  "Dispatch KEYMAP's popup ENTRY for BUF.
If BUF's session expired after native key lookup, call the live source
binding instead of attempting navigation in the expired popup."
  (let ((key (plist-get entry :key)))
    (cond
     ((or (not (keymap-popup--session-state buf))
          (keymap-popup--session-get buf :closing))
      (keymap-popup--call-real-binding keymap key))
     ((keymap-popup--inapt-key-p buf key)
      (keymap-popup--refuse-inapt buf))
     (t
      (pcase-exhaustive (plist-get entry :type)
        ('keymap
         (keymap-popup--push-submenu buf (plist-get entry :target)))
        ((or 'switch 'suffix)
         (keymap-popup--consume-prefix buf)
         (keymap-popup--call-real-binding keymap key)
         (when (or (eq (plist-get entry :type) 'switch)
                   (plist-get entry :stay-open))
           (keymap-popup--refresh buf))))))))

(defun keymap-popup--entry-needs-override-p (entry group)
  "Return non-nil when ENTRY in GROUP needs popup dispatch."
  (pcase-exhaustive (plist-get entry :type)
    ((or 'switch 'keymap) t)
    ('suffix (or (plist-get entry :stay-open)
                 (plist-get entry :inapt-if)
                 (plist-get group :inapt-if)))))

(defun keymap-popup--entry-override (keymap entry group buf descriptions)
  "Return KEYMAP override for ENTRY in GROUP and BUF, or nil.
Select the native winning entry from DESCRIPTIONS at lookup time."
  (and-let* ((key (plist-get entry :key))
             ((keymap-popup--entry-needs-override-p entry group)))
    (cons key
          (list 'menu-item ""
                (lambda ()
                  (interactive)
                  (let ((current (keymap-popup--find-entry-by-key
                                  (keymap-popup--resolve-descriptions descriptions keymap)
                                  key)))
                    (if current
                        (keymap-popup--dispatch-entry keymap current buf)
                      (keymap-popup--call-real-binding keymap key))))
                :filter
                (lambda (binding)
                  (condition-case err
                      (pcase-let ((`(,winner . ,owner)
                                   (keymap-popup--find-entry-with-group
                                    (keymap-popup--resolve-descriptions descriptions keymap)
                                    key)))
                        (cond
                         ((or (null winner)
                              (not (keymap-popup--entry-needs-override-p winner owner)))
                          (keymap-lookup keymap key nil t))
                         ((and (keymap-popup--if-allows-p owner)
                               (keymap-popup--if-allows-p winner))
                          ;; Native dispatch owns remapping, command identities,
                          ;; disabled commands, macros and repeat.
                          (if (or (eq (plist-get winner :type) 'keymap)
                                  (keymap-popup--inapt-active-p owner)
                                  (keymap-popup--inapt-active-p winner))
                              binding
                            (keymap-lookup keymap key nil t)))))
                    ((error quit)
                     ;; Lookup must return a binding even on failure (mouse
                     ;; replay still needs its guard).  Never retry a failed
                     ;; predicate into an action, even if it opened a successor.
                     (keymap-popup--failure-command err))))))))

(defun keymap-popup--entry-potential-keys (entry keymap)
  "Return ENTRY's stored, resolved and existing native keys in KEYMAP.
A filter can move the selected description to an ordinary command alias
while the popup remains open.  These keys only reserve handlers; lookup
and dispatch still select the current native description and binding."
  (delete-dups
   (delq nil
         (append (list (plist-get entry :key)
                       (plist-get (keymap-popup--resolve-key entry keymap) :key))
                 (when-let* ((command (plist-get entry :command)))
                   (mapcar #'key-description
                           (where-is-internal command (list keymap))))))))

(defun keymap-popup--description-overrides (keymap descriptions buf)
  "Return popup entry overrides for KEYMAP, DESCRIPTIONS, and BUF."
  (mapcan
   (lambda (row)
     (mapcan
      (lambda (group)
        (mapcan (lambda (entry)
                  (seq-keep (lambda (key)
                              (keymap-popup--entry-override
                               keymap (plist-put (copy-sequence entry) :key key)
                               group buf descriptions))
                            (keymap-popup--entry-potential-keys entry keymap)))
                (plist-get group :entries)))
      row))
   descriptions))

(defun keymap-popup--build-wrapper-map (keymap descriptions buf exit-key)
  "Build wrapper keymap over KEYMAP with DESCRIPTIONS for BUF.
EXIT-KEY and entry handlers layer over KEYMAP.  Shadowing entry
handlers preserve KEYMAP's `:if' filters; `:inapt-if' is enforced
here at keypress time."
  (let* ((map (make-sparse-keymap))
         (overrides (append
                     (keymap-popup--description-overrides
                      keymap descriptions buf)
                     (keymap-popup--core-overrides exit-key))))
    (set-keymap-parent map keymap)
    (pcase-dolist (`(,key . ,cmd) overrides)
      (keymap-set map key cmd))
    map))

(defun keymap-popup-dismiss ()
  "Dismiss the active popup, if any.
Deactivates every transient map in a nested popup session and
removes the popup display."
  (interactive)
  (when-let* ((buf (keymap-popup--popup-buffer)))
    (keymap-popup--cleanup buf)))

(defun keymap-popup--make-session (keymap &optional active)
  "Derive a popup session for KEYMAP and the current buffer.
Use ACTIVE instead of deriving the initial navigation state when non-nil."
  (let ((source-live (list (make-symbol "keymap-popup-source"))))
    (list :source (current-buffer)
          :source-window (selected-window)
          :source-live source-live
          :source-retire (lambda () (setcar source-live nil))
          :mouse-press nil
          :mouse-epoch (make-symbol "mouse-navigation")
          :active (or active (keymap-popup--state-for-keymap keymap))
          :stack nil
          :prefix-mode nil
          :reentering nil
          :suspended-depth nil
          :closing nil
          :persistent (pcase (keymap-popup--meta keymap 'persistent)
                        ('yes t)
                        ('no nil)
                        (_ keymap-popup-persistent))
          :backend (funcall keymap-popup-backend)
          :persistent-hook nil)))

(defun keymap-popup--init-session (buf session)
  "Install SESSION in BUF and arrange cleanup on buffer death."
  ;; A live buffer object can acquire a new mode or document.  Retire the
  ;; captured lifetime, not a buffer-local flag that mode setup can erase.
  (with-current-buffer (plist-get session :source)
    (let ((retire (plist-get session :source-retire)))
      (add-hook 'change-major-mode-hook retire nil t)
      (add-hook 'after-set-visited-file-name-hook retire nil t)))
  (with-current-buffer buf
    (setq-local keymap-popup--session session)
    (setq keymap-popup--buffer buf)
    (add-hook 'kill-buffer-hook #'keymap-popup--kill-buffer-cleanup nil t)
    (add-hook 'change-major-mode-hook #'keymap-popup--kill-buffer-cleanup nil t)
    (add-hook 'after-set-visited-file-name-hook
              #'keymap-popup--kill-buffer-cleanup nil t)))

(defun keymap-popup--activate-transient-map (buf)
  "Build and activate the transient map for BUF's active state."
  (let* ((active (keymap-popup--session-get buf :active))
         (wrapper (keymap-popup--build-wrapper-map
                   (plist-get active :keymap)
                   (or (plist-get active :description-candidates)
                       (plist-get active :descriptions))
                   buf
                   (plist-get active :exit-key))))
    (keymap-popup--set-active buf :wrapper-map wrapper)
    (let ((exit-function
           (set-transient-map wrapper
                              (keymap-popup--make-keep-pred buf)
                              (keymap-popup--make-on-exit buf))))
      (when (buffer-live-p buf)
        (keymap-popup--set-active buf :exit-function exit-function)))))

(defun keymap-popup--install-persistent-hook (buf)
  "Install a self-removing refresh hook for BUF's retained actions."
  (let ((hook-fn (make-symbol "keymap-popup--persistent-refresh")))
    (fset hook-fn
          (lambda ()
            (condition-case err
                (if (buffer-live-p buf)
                    (when (and (not (mouse-event-p last-input-event))
                               (not (eq this-command #'keymap-popup--ignore-mouse))
                               ;; Do not retry an already captured failure.
                               (not (and (symbolp this-command)
                                         (get this-command 'keymap-popup--failure)))
                               (or (keymap-popup--session-get buf :persistent)
                                   (keymap-popup--keep-popup-p
                                    (keymap-popup--active-descriptions buf)
                                    (key-description (this-command-keys-vector)))))
                      (keymap-popup--refresh buf))
                  (remove-hook 'post-command-hook hook-fn))
              ((error quit)
               ;; Qualification and rendering can fail for the first time
               ;; after an accepted action.  Report without letting Emacs
               ;; remove the hook, retrying callbacks or reviving a retired BUF.
               (message "Popup refresh failed: %S" err)))))
    (keymap-popup--set-session buf :persistent-hook hook-fn)
    (add-hook 'post-command-hook hook-fn)))

;;;###autoload
(defun keymap-popup (keymap)
  "Show popup help for described KEYMAP.
Activates KEYMAP as a transient map.  Switch keys execute and re-render
without closing.  Inapt keys are refused with \"Command unavailable\"
and keep the popup open; outside a popup, `:inapt-if' does not block
dispatch.  Sub-menu keys push a navigation stack.
The exit key and \\[universal-argument] are popup controls; source actions
shadowed by those controls are omitted from the displayed entries.
\\[universal-argument] toggles prefix mode."
  (let ((active (keymap-popup--state-for-keymap keymap)))
    (or (keymap-popup--descriptions-present-p
         (plist-get active :descriptions))
        (user-error "No descriptions in keymap"))
    (keymap-popup-dismiss)
    (let ((session (keymap-popup--make-session keymap active))
          (buf (keymap-popup--prepare-buffer))
          (complete nil))
      (unwind-protect
          (progn
            (keymap-popup--init-session buf session)
            (let ((rendered-rows (keymap-popup--refresh buf)))
              (funcall (plist-get (plist-get session :backend) :show) buf)
              ;; Reflow saved columns at the chosen window's actual width.
              (keymap-popup--write-rendered buf rendered-rows))
            (keymap-popup--activate-transient-map buf)
            (add-hook 'minibuffer-setup-hook #'keymap-popup--suspend)
            (add-hook 'minibuffer-exit-hook #'keymap-popup--resume)
            (keymap-popup--install-persistent-hook buf)
            (setq complete t))
        (unless complete
          ;; Preserve the launch error or quit, even if :hide also fails.
          (condition-case err
              (keymap-popup--cleanup buf)
            ((error quit) (message "Popup cleanup failed: %s"
                                   (error-message-string err)))))))))

(provide 'keymap-popup)
;;; keymap-popup.el ends here
