;; Generated package description from taxy.el  -*- no-byte-compile: t -*-
(define-package "taxy" "0.9" "Programmable taxonomical grouping for arbitrary objects" '((emacs "26.3")) :commit "b209692b632bbe8d7f97ea8a39b0c28c1be3b7ec" :authors '(("Adam Porter" . "adam@alphapapa.net")) :maintainer '("Adam Porter" . "adam@alphapapa.net") :keywords '("lisp") :url "https://github.com/alphapapa/taxy.el")
