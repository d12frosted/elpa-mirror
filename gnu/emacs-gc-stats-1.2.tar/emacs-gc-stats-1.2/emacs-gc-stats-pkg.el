;; Generated package description from emacs-gc-stats.el  -*- no-byte-compile: t -*-
(define-package "emacs-gc-stats" "1.2" "Collect Emacs GC statistics" '((emacs "25.1")) :commit "c19aedb41c8e6fb224e8284b19d5447b8472a669" :authors '(("Ihor Radchenko" . "yantar92@posteo.net")) :maintainer '("Ihor Radchenko" . "yantar92@posteo.net") :url "https://git.sr.ht/~yantar92/emacs-gc-stats")
