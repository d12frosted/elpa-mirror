;; Generated package description from boxy.el  -*- no-byte-compile: t -*-
(define-package "boxy" "1.0.5" "A boxy layout framework" '((emacs "26.1")) :commit "3a949d5b14349f33f27bc5041178445a0fedcc6c" :authors '(("Tyler Grinn" . "tylergrinn@gmail.com")) :maintainer '("Tyler Grinn" . "tylergrinn@gmail.com") :keywords '("tools") :url "https://gitlab.com/tygrdev/boxy.el")
