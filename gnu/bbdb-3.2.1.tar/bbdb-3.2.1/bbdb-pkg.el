;; Generated package description from bbdb.el  -*- no-byte-compile: t -*-
(define-package "bbdb" "3.2.1" "core of BBDB" '((emacs "24") (cl-lib "0.5")) :commit "b3739cbaf2f021ac776925254e12abf0699e46f8" :url "https://elpa.gnu.org/packages/bbdb.html" :maintainer '("Roland Winkler" . "winkler@gnu.org"))
