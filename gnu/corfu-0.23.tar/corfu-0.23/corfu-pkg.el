;; Generated package description from corfu.el  -*- no-byte-compile: t -*-
(define-package "corfu" "0.23" "Completion Overlay Region FUnction" '((emacs "27.1")) :commit "bf9bb725f70fb3165e2831c5926217bd6a8bc68d" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/corfu")
