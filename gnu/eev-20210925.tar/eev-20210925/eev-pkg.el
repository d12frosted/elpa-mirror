;; Generated package description from eev.el  -*- no-byte-compile: t -*-
(define-package "eev" "20210925" "Support for e-scripts (eepitch blocks, elisp hyperlinks, etc)" '((emacs "24.4")) :authors '(("Eduardo Ochs" . "eduardoochs@gmail.com")) :maintainer '("Eduardo Ochs" . "eduardoochs@gmail.com") :keywords '("lisp" "e-scripts") :url "http://angg.twu.net/#eev")
