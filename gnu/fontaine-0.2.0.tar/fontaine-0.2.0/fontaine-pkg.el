;; Generated package description from fontaine.el  -*- no-byte-compile: t -*-
(define-package "fontaine" "0.2.0" "Set font configurations using presets" '((emacs "27.1")) :commit "a8e7f2e9b8ec6c4eaa75eb55acbc74702c96d438" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://git.sr.ht/~protesilaos/fontaine")
