;; Generated package description from llm.el  -*- no-byte-compile: t -*-
(define-package "llm" "0.2.1" "Interface to pluggable llm backends" '((emacs "28.1")) :commit "8dee3d059adb57d23117b68a5f09cfe0e08a43f9" :authors '(("Andrew Hyatt" . "ahyatt@gmail.com")) :maintainer '("Andrew Hyatt" . "ahyatt@gmail.com") :url "https://github.com/ahyatt/llm")
