;; Generated package description from parser-generator.el  -*- no-byte-compile: t -*-
(define-package "parser-generator" "0.1.3" "Parser Generator library" '((emacs "26")) :authors '(("Christian Johansson" . "christian@cvj.se")) :maintainer '("Christian Johansson" . "christian@cvj.se") :keywords '("tools" "convenience") :url "https://github.com/cjohansson/emacs-parser-generator")
