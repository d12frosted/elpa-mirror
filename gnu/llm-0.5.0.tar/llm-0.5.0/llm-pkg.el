;; Generated package description from llm.el  -*- no-byte-compile: t -*-
(define-package "llm" "0.5.0" "Interface to pluggable llm backends" '((emacs "28.1")) :commit "8f431fad9e4dd173fe12d7f9849dff934ea0331d" :authors '(("Andrew Hyatt" . "ahyatt@gmail.com")) :maintainer '("Andrew Hyatt" . "ahyatt@gmail.com") :url "https://github.com/ahyatt/llm")
