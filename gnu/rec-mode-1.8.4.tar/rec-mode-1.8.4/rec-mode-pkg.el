;; Generated package description from rec-mode.el  -*- no-byte-compile: t -*-
(define-package "rec-mode" "1.8.4" "Major mode for viewing/editing rec files" '((emacs "25")) :commit "a8e7c19a548eb91762316c84870bdebb4490f2c7" :authors '(("Jose E. Marchesi" . "jemarch@gnu.org")) :maintainer '("Antoine Kalmbach" . "ane@iki.fi") :url "https://www.gnu.org/software/recutils/")
