;; Generated package description from expreg.el  -*- no-byte-compile: t -*-
(define-package "expreg" "1.2.1" "Simple expand region" '((emacs "29.1")) :commit "b9fd9f90c6f00b628a610e556d560d5719a92d7d" :authors '(("Yuan Fu" . "casouri@gmail.com")) :maintainer '("Yuan Fu" . "casouri@gmail.com") :keywords '("text" "editing") :url "https://github.com/casouri/expreg")
