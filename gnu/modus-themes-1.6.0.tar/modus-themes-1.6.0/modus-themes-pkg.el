;; Generated package description from modus-themes.el  -*- no-byte-compile: t -*-
(define-package "modus-themes" "1.6.0" "Highly accessible themes (WCAG AAA)" '((emacs "27.1")) :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :keywords '("faces" "theme" "accessibility") :url "https://gitlab.com/protesilaos/modus-themes")
