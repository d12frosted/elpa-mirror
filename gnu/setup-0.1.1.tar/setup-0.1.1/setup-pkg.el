;; Generated package description from setup.el  -*- no-byte-compile: t -*-
(define-package "setup" "0.1.1" "Helpful Configuration Macro" '((emacs "24.4")) :url "https://elpa.gnu.org/packages/setup.html" :keywords '("lisp" "local") :authors '(("Philip K." . "philipk@posteo.net")) :maintainer '("Philip K." . "philipk@posteo.net"))
