;; Generated package description from cape.el  -*- no-byte-compile: t -*-
(define-package "cape" "0.5" "Completion At Point Extensions" '((emacs "27.1")) :commit "9567f1ca09a3867e50ef8f990b486e916460df9d" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/cape")
