;; Generated package description from r-ts-mode.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "r-ts-mode" "1.2.0" "R treesitter mode" '((emacs "30.1")) :commit "f5e4f6395a09a4d20a7dd41b5d8606ba56e39057" :authors '(("Manuel Teodoro" . "ttm@teoten.me")) :maintainer '("Manuel Teodoro" . "ttm@teoten.me") :url "https://codeberg.org/R-for-emacs/r-ts-mode")
