;; Generated package description from po-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "po-mode" "2.33" "major mode for GNU gettext PO files" '((emacs "23")) :commit "6b49cd88523aa4363adbc9eafe4111e611d322d1" :url "https://elpa.gnu.org/packages/po-mode.html" :keywords '("i18n" "gettext"))
