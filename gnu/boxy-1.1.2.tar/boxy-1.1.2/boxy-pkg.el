;; Generated package description from boxy.el  -*- no-byte-compile: t -*-
(define-package "boxy" "1.1.2" "A boxy layout framework" '((emacs "26.1")) :commit "f6477177f7a4b335decea379b147981a8ee58a19" :authors '(("Taylor Grinn" . "grinntaylor@gmail.com")) :maintainer '("Taylor Grinn" . "grinntaylor@gmail.com") :keywords '("tools") :url "https://gitlab.com/tygrdev/boxy")
