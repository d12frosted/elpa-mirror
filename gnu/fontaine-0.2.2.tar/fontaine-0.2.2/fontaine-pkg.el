;; Generated package description from fontaine.el  -*- no-byte-compile: t -*-
(define-package "fontaine" "0.2.2" "Set font configurations using presets" '((emacs "27.1")) :commit "7cf7cd0ed264f427a9824ad31dae8aa781574083" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://git.sr.ht/~protesilaos/fontaine")
