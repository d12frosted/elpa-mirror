;; Generated package description from jinx.el  -*- no-byte-compile: t -*-
(define-package "jinx" "0.2" "Enchanted just-in-time spell checker" '((emacs "27.1") (compat "29.1.4.0")) :commit "d4705491707b7bca493993b16aab89c8edbc0f06" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/jinx")
