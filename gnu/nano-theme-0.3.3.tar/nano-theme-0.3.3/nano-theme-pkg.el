;; Generated package description from nano-theme.el  -*- no-byte-compile: t -*-
(define-package "nano-theme" "0.3.3" "N Λ N O theme" '((emacs "27.1")) :commit "e1d0265b5e16782e874960f40d390200bbf3a756" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("theme" "dark" "light") :url "https://github.com/rougier/nano-theme")
