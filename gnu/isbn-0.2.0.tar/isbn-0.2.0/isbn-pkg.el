;; Generated package description from isbn.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "isbn" "0.2.0" "ISBN library" '((emacs "28.1")) :commit "e52d1c194e4fd7c0da7c3bf67b33e6923f785059" :authors '(("Maximilian Cook" . "maximilian@fclr.net")) :maintainer '("Maximilian Cook" . "maximilian@fclr.net") :keywords '("data") :url "https://git.sr.ht/~cook/isbn.el")
