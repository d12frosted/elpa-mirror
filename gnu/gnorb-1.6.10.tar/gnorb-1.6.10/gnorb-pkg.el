;; Generated package description from gnorb.el  -*- no-byte-compile: t -*-
(define-package "gnorb" "1.6.10" "Glue code between Gnus, Org, and BBDB" '((cl-lib "0.5")) :url "https://elpa.gnu.org/packages/gnorb.html" :authors '(("Eric Abrahamsen" . "eric@ericabrahamsen.net")) :maintainer '("Eric Abrahamsen" . "eric@ericabrahamsen.net") :keywords '("mail" "org" "gnus" "bbdb" "todo" "task"))
