;; Generated package description from emacs-gc-stats.el  -*- no-byte-compile: t -*-
(define-package "emacs-gc-stats" "1.3" "Collect Emacs GC statistics" '((emacs "25.1")) :commit "f17fd30098c284a11feb06d505308d1f85ba2c55" :authors '(("Ihor Radchenko" . "yantar92@posteo.net")) :maintainer '("Ihor Radchenko" . "yantar92@posteo.net") :url "https://git.sr.ht/~yantar92/emacs-gc-stats")
