;; Generated package description from rec-mode.el  -*- no-byte-compile: t -*-
(define-package "rec-mode" "1.8.2" "Major mode for viewing/editing rec files" '((emacs "25")) :authors '(("Jose E. Marchesi" . "jemarch@gnu.org")) :maintainer '("Antoine Kalmbach" . "ane@iki.fi") :url "https://www.gnu.org/software/recutils/")
