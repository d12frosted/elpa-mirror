;; Generated package description from fontaine.el  -*- no-byte-compile: t -*-
(define-package "fontaine" "0.2.3" "Set font configurations using presets" '((emacs "27.1")) :commit "e18cc2e2a6180342ebfed8c94048b7d83e7d0d5d" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://git.sr.ht/~protesilaos/fontaine")
