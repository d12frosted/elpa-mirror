;; Generated package description from emacs-gc-stats.el  -*- no-byte-compile: t -*-
(define-package "emacs-gc-stats" "1.2.3" "Collect Emacs GC statistics" '((emacs "25.1")) :commit "cdea9f03baf8f451760b12444de5b177a9366ef3" :authors '(("Ihor Radchenko" . "yantar92@posteo.net")) :maintainer '("Ihor Radchenko" . "yantar92@posteo.net") :url "https://git.sr.ht/~yantar92/emacs-gc-stats")
