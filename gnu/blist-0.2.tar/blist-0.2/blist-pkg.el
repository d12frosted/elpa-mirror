;; Generated package description from blist.el  -*- no-byte-compile: t -*-
(define-package "blist" "0.2" "Display bookmarks in an ibuffer way" 'nil :commit "c5aadbce3b713a2a9e7dba8c3c0881c43ebb2b4d" :url "https://elpa.gnu.org/packages/blist.html" :authors '(("Durand" . "mmemmew@gmail.com")) :maintainer '("Durand" . "mmemmew@gmail.com") :keywords '("convenience"))
