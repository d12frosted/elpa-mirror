;; Generated package description from bbdb.el  -*- no-byte-compile: t -*-
(define-package "bbdb" "3.2.2" "Big Brother DataBase" '((emacs "24") (cl-lib "0.5")) :commit "e300a375d55ef4033b3651e937c5ec2042871f91" :url "https://elpa.gnu.org/packages/bbdb.html" :maintainer '("Roland Winkler" . "winkler@gnu.org"))
