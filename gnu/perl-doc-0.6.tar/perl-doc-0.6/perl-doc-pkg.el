;; Generated package description from perl-doc.el  -*- no-byte-compile: t -*-
(define-package "perl-doc" "0.6" "Read Perl documentation" '((emacs "27")) :commit "eb329f2675e71d656e1512ba7ec5a37ada4603d6" :authors '(("Harald Jörg" . "haj@posteo.de")) :maintainer '("Harald Jörg" . "haj@posteo.de") :keywords '("languages") :url "https://github.com/HaraldJoerg/emacs-perl-doc")
