;; Generated package description from nano-agenda.el  -*- no-byte-compile: t -*-
(define-package "nano-agenda" "0.2.2" "N Λ N O agenda" '((emacs "27.1")) :commit "f0a536eea1c2dd90454b622d0930bc80757a95da" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience" "org-mode" "org-agenda") :url "https://github.com/rougier/nano-agenda")
