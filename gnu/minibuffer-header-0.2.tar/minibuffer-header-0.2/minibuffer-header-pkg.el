;; Generated package description from minibuffer-header.el  -*- no-byte-compile: t -*-
(define-package "minibuffer-header" "0.2" "Minibuffer header line" '((emacs "27.1")) :commit "ad10a018c75d8ff8039252b73daf57d19b060d3b" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience") :url "https://github.com/rougier/minibuffer-header")
