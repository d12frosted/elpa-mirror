;; Generated package description from org-transclusion.el  -*- no-byte-compile: t -*-
(define-package "org-transclusion" "1.0.1" "transclude text contents of linked target" '((emacs "27.1") (org "9.4")) :authors '(("Noboru Ota" . "me@nobiot.com")) :maintainer '("Noboru Ota" . "me@nobiot.com") :keywords '("org-mode" "transclusion" "writing") :url "https://github.com/nobiot/org-transclusion")
