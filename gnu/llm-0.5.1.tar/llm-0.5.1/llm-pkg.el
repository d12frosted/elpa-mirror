;; Generated package description from llm.el  -*- no-byte-compile: t -*-
(define-package "llm" "0.5.1" "Interface to pluggable llm backends" '((emacs "28.1")) :commit "a3b4ba46f926a53ec8c35893c21f6273b22ec4d8" :authors '(("Andrew Hyatt" . "ahyatt@gmail.com")) :maintainer '("Andrew Hyatt" . "ahyatt@gmail.com") :url "https://github.com/ahyatt/llm")
