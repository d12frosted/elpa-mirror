;; Generated package description from coterm.el  -*- no-byte-compile: t -*-
(define-package "coterm" "1.3" "Terminal emulation for comint" '((emacs "26.1")) :authors '(("jakanakaevangeli" . "jakanakaevangeli@chiru.no")) :maintainer '("jakanakaevangeli" . "jakanakaevangeli@chiru.no") :keywords '("processes") :url "https://repo.or.cz/emacs-coterm.git")
