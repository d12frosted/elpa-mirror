;; Generated package description from urgrep.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "urgrep" "0.6.0" "Universal recursive grep" '((emacs "28.1") (compat "29.1.0.1") (project "0.3.0")) :commit "334aa0a364b2811ccba67b1ce4e719e9e96f963a" :keywords '("grep" "search") :url "https://sr.ht/~jimporter/urgrep/")
