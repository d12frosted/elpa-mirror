;; Generated package description from tmr.el  -*- no-byte-compile: t -*-
(define-package "tmr" "0.2.1" "TMR Must Recur" '((emacs "27.1")) :commit "30784cbe2eb036e58e99cd9b9e44909e7db93cdc" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://git.sr.ht/~protesilaos/tmr")
