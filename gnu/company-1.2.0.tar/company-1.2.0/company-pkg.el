;; Generated package description from company.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "company" "1.2.0" "Modular text completion framework" '((emacs "26.1") (posframe "1.5.1")) :commit "ba9c346c43bbe3c904cec60364100f521c43faea" :maintainer '("Dmitry Gutov" . "dmitry@gutov.dev") :keywords '("abbrev" "convenience" "matching") :url "http://company-mode.github.io/")
