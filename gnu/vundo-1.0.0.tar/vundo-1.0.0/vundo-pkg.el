;; Generated package description from vundo.el  -*- no-byte-compile: t -*-
(define-package "vundo" "1.0.0" "Visual undo tree" '((emacs "28.1")) :commit "0e3af84944c2c69ddaf5364868fe77c31f62527e" :authors '(("Yuan Fu" . "casouri@gmail.com")) :maintainer '("Yuan Fu" . "casouri@gmail.com") :keywords '("undo" "text" "editing") :url "https://github.com/casouri/vundo")
