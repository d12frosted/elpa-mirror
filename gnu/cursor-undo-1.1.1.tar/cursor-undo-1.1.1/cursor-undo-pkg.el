;; Generated package description from cursor-undo.el  -*- no-byte-compile: t -*-
(define-package "cursor-undo" "1.1.1" "Undo Cursor Movement" 'nil :commit "d49909de3cd00256378768d53990a7828f20d435" :url "https://elpa.gnu.org/packages/cursor-undo.html" :authors '(("Luke Lee" . "luke.yx.lee@gmail.com")) :maintainer '("Luke Lee" . "luke.yx.lee@gmail.com") :keywords '("undo" "cursor"))
