;; Generated package description from rcirc-color.el  -*- no-byte-compile: t -*-
(define-package "rcirc-color" "0.4.4" "color nicks" '((emacs "24.4")) :commit "cba15c56375575da5518f5537a22f85706625b5c" :url "https://elpa.gnu.org/packages/rcirc-color.html" :authors '(("Alex Schroeder" . "alex@gnu.org")) :maintainer '("Alex Schroeder" . "alex@gnu.org") :keywords '("comm"))
