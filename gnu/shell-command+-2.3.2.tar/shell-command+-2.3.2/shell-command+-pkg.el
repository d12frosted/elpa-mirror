;; Generated package description from shell-command+.el  -*- no-byte-compile: t -*-
(define-package "shell-command+" "2.3.2" "An extended shell-command" '((emacs "24.1")) :authors '(("Philip Kaludercic" . "philipk@posteo.net")) :maintainer '("Philip Kaludercic" . "philipk@posteo.net") :keywords '("unix" "processes" "convenience") :url "https://git.sr.ht/~pkal/shell-command-plus")
