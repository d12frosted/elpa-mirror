;; Generated package description from nano-modeline.el  -*- no-byte-compile: t -*-
(define-package "nano-modeline" "1.0.0" "N Λ N O modeline" '((emacs "27.1")) :commit "cba074e55c847f289085ec35c21fb2ad8df1b483" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience" "mode-line" "header-line") :url "https://github.com/rougier/nano-modeline")
