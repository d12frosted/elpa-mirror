;; Generated package description from company.el  -*- no-byte-compile: t -*-
(define-package "company" "1.0.0" "Modular text completion framework" '((emacs "25.1")) :commit "852149619580dfeb5d37e435df40c22cfa851a34" :maintainer '("Dmitry Gutov" . "dmitry@gutov.dev") :keywords '("abbrev" "convenience" "matching") :url "http://company-mode.github.io/")
