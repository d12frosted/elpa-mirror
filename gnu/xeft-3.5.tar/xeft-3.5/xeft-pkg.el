;; Generated package description from xeft.el  -*- no-byte-compile: t -*-
(define-package "xeft" "3.5" "Deft feat. Xapian" '((emacs "26.0")) :commit "21465bba67c83a923b71808e1788ab1060745976" :authors '(("Yuan Fu" . "casouri@gmail.com")) :maintainer '("Yuan Fu" . "casouri@gmail.com") :keywords '("applications" "note" "searching") :url "https://sr.ht/~casouri/xeft")
