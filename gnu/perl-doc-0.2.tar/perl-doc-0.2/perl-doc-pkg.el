;; Generated package description from perl-doc.el  -*- no-byte-compile: t -*-
(define-package "perl-doc" "0.2" "Read Perl documentation" '((emacs "27")) :commit "bc968d37dcc29db4cae65e6d1c3ddc80e31ffbb3" :authors '(("Harald Jörg" . "haj@posteo.de")) :maintainer '("Harald Jörg" . "haj@posteo.de") :keywords '("languages") :url "https://github.com/HaraldJoerg/emacs-perl-doc")
