;; Generated package description from jinx.el  -*- no-byte-compile: t -*-
(define-package "jinx" "0.5" "Enchanted Just-in-time Spell Checker" '((emacs "27.1") (compat "29.1.4.0")) :commit "3d4a633a1c9a91f7776f52db9494fc21e4728f67" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/jinx")
