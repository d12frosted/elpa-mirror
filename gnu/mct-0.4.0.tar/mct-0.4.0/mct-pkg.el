;; Generated package description from mct.el  -*- no-byte-compile: t -*-
(define-package "mct" "0.4.0" "Minibuffer and Completions in Tandem" '((emacs "27.1")) :commit "e6e5d3318146133f3772a8cdddcf88c974808eaf" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://gitlab.com/protesilaos/mct")
