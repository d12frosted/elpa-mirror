;; Generated package description from jarchive.el  -*- no-byte-compile: t -*-
(define-package "jarchive" "0.8.0" "Open project dependencies in jar archives" '((emacs "26.1")) :commit "f05bd44af29055f28745f61f5345fb4afdc2b20b" :maintainer '("Danny Freeman" . "danny@dfreeman.email") :keywords '("tools" "languages" "jvm" "java" "clojure") :url "https://git.sr.ht/~dannyfreeman/jarchive")
