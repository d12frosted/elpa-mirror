;; Generated package description from llm.el  -*- no-byte-compile: t -*-
(define-package "llm" "0.1.1" "Interface to pluggable llm backends" '((request "0.3.3") (emacs "28.1")) :commit "9ca27d742b43283f5c81d925be74dc0d27c95924" :authors '(("Andrew Hyatt" . "ahyatt@gmail.com")) :maintainer '("Andrew Hyatt" . "ahyatt@gmail.com") :url "https://github.com/ahyatt/llm")
