;;; polish.el --- AUCTeX style for the `polish' babel option.  -*- lexical-binding: t; -*-

;; Copyright (C) 2007, 2020 Free Software Foundation, Inc.

;; Author: Ralf Angeli <angeli@caeruleus.net>
;; Maintainer: auctex-devel@gnu.org
;; Created: 2007-01-08
;; Keywords: tex

;; This file is part of AUCTeX.

;; AUCTeX is free software; you can redistribute it and/or modify it
;; under the terms of the GNU General Public License as published by the
;; Free Software Foundation; either version 3, or (at your option) any
;; later version.

;; AUCTeX is distributed in the hope that it will be useful, but WITHOUT
;; ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
;; FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
;; for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Set up AUCTeX for editing Polish text in connection with the
;; `polish' babel option.

;;; Code:

(require 'tex)
(require 'latex)

(defvar LaTeX-polish-mode-syntax-table
  (copy-syntax-table LaTeX-mode-syntax-table)
  "Syntax table used in LaTeX mode when using `polish.sty'.")

(modify-syntax-entry ?\" "w" LaTeX-polish-mode-syntax-table)

(TeX-add-style-hook
 "polish"
 (lambda ()
   (set-syntax-table LaTeX-polish-mode-syntax-table)
   (unless (eq (car TeX-quote-language) 'override)
     (setq TeX-quote-language `("polish" "\"`" "\"'" ,TeX-quote-after-quote)))
   ;; Fontification of quotation marks.
   (when (fboundp 'font-latex-add-quotes)
     (font-latex-add-quotes '("\"`" "\"'"))
     (font-latex-add-quotes '("\"<" "\">" french)))
   (run-hooks 'TeX-language-pl-hook))
 TeX-dialect)

;;; polish.el ends here
