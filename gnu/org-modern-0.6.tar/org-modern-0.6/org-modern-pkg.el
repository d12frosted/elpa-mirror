;; Generated package description from org-modern.el  -*- no-byte-compile: t -*-
(define-package "org-modern" "0.6" "Modern looks for Org" '((emacs "27.1")) :commit "e87ca8a9ec45fcfa2556028aa9feffb7bc3aecee" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/org-modern")
