;; Generated package description from srht.el  -*- no-byte-compile: t -*-
(define-package "srht" "0.2" "Sourcehut" '((emacs "27.1") (plz "0.1")) :commit "5605a75111a9b1a1e67bd012bbf78fc6cb54f96b" :authors '(("Aleksandr Vityazev" . "avityazev@posteo.org")) :maintainer '("Aleksandr Vityazev" . "avityazev@posteo.org") :keywords '("comm" "vc") :url "https://sr.ht/~akagi/srht.el/")
