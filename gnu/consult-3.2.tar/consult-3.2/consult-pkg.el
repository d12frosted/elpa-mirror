;; Generated package description from consult.el  -*- mode: lisp-data; no-byte-compile: t -*-
(define-package "consult" "3.2" "Search and navigate via completing-read" '((emacs "29.1") (compat "30")) :commit "74e6cc77609cb36cd61aa2a23848659fbb66f05a" :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("matching" "files" "completion") :url "https://github.com/minad/consult")
