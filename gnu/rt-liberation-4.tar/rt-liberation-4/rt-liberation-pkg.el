;; Generated package description from rt-liberation.el  -*- no-byte-compile: t -*-
(define-package "rt-liberation" "4" "Emacs interface to RT" 'nil :commit "f9dbe356479c10c32a8f420e4f3d2c7a99edf9ce" :authors '(("Yoni Rabkin" . "yrk@gnu.org")) :maintainer '("Yoni Rabkin" . "yrk@gnu.org") :keywords '("rt" "tickets") :url "http://www.nongnu.org/rtliber/")
