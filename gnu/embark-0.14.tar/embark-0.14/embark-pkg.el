;; Generated package description from embark.el  -*- no-byte-compile: t -*-
(define-package "embark" "0.14" "Conveniently act on minibuffer completions" '((emacs "26.1")) :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")) :maintainer '("Omar Antolín Camarena" . "omar@matem.unam.mx") :keywords '("convenience") :url "https://github.com/oantolin/embark")
