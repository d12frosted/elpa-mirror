;; Generated package description from setup.el  -*- no-byte-compile: t -*-
(define-package "setup" "1.3.1" "Helpful Configuration Macro" '((emacs "26.1")) :commit "d768687d78a76ebe90a9eb824e98d7598655058e" :authors '(("Philip Kaludercic" . "philipk@posteo.net")) :maintainer '("Philip Kaludercic" . "~pkal/public-inbox@lists.sr.ht") :keywords '("lisp" "local") :url "https://git.sr.ht/~pkal/setup")
