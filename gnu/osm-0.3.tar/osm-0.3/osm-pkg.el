;; Generated package description from osm.el  -*- no-byte-compile: t -*-
(define-package "osm" "0.3" "OpenStreetMap viewer" '((emacs "27.1")) :commit "954a97495d50ae27f21597a7ca29f14ac1f8e7c6" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/osm")
