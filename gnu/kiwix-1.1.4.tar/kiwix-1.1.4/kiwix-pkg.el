;; Generated package description from kiwix.el  -*- no-byte-compile: t -*-
(define-package "kiwix" "1.1.4" "Searching offline Wikipedia through Kiwix." '((emacs "25.1") (request "0.3.0")) :authors '(("stardiviner" . "numbchild@gmail.com")) :maintainer '("stardiviner" . "numbchild@gmail.com") :keywords '("kiwix" "wikipedia") :url "https://github.com/stardiviner/kiwix.el")
