;; Generated package description from nano-modeline.el  -*- no-byte-compile: t -*-
(define-package "nano-modeline" "0.7.1" "N Λ N O modeline" '((emacs "27.1")) :commit "823161c8894996e5c8375249f467a422579a2947" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience" "mode-line" "header-line") :url "https://github.com/rougier/nano-modeline")
