;; Generated package description from minibuffer-header.el  -*- no-byte-compile: t -*-
(define-package "minibuffer-header" "0.4" "Minibuffer header line" '((emacs "27.1")) :commit "22b1d168ebb9baf06b27db077f5b95c3ecd915f9" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience") :url "https://github.com/rougier/minibuffer-header")
