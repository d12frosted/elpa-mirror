;; Generated package description from emacs-gc-stats.el  -*- no-byte-compile: t -*-
(define-package "emacs-gc-stats" "1.1" "Collect Emacs GC statistics" '((emacs "25.1")) :commit "19c24e427fcee57fe834b7842cd48f0e23ba8a84" :authors '(("Ihor Radchenko" . "yantar92@posteo.net")) :maintainer '("Ihor Radchenko" . "yantar92@posteo.net") :url "https://git.sr.ht/~yantar92/emacs-gc-stats")
