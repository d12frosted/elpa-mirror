;; Generated package description from org-real.el  -*- no-byte-compile: t -*-
(define-package "org-real" "1.0.2" "Keep track of real things as org-mode links" '((emacs "26.1") (boxy "1.0")) :authors '(("Tyler Grinn" . "tylergrinn@gmail.com")) :maintainer '("Tyler Grinn" . "tylergrinn@gmail.com") :keywords '("tools") :url "https://gitlab.com/tygrdev/org-real")
