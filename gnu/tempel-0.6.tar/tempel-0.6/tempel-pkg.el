;; Generated package description from tempel.el  -*- no-byte-compile: t -*-
(define-package "tempel" "0.6" "Tempo templates/snippets with in-buffer field editing" '((emacs "27.1")) :commit "9a25bacc16eac8b83c1bef1aefa0be27cfa8a762" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/tempel")
