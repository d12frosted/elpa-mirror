;; Generated package description from perl-doc.el  -*- no-byte-compile: t -*-
(define-package "perl-doc" "0.4" "Read Perl documentation" '((emacs "27")) :commit "ad005b228af43ca0cc15be52e5e45137f7599216" :authors '(("Harald Jörg" . "haj@posteo.de")) :maintainer '("Harald Jörg" . "haj@posteo.de") :keywords '("languages") :url "https://github.com/HaraldJoerg/emacs-perl-doc")
