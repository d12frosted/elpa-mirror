;; Generated package description from eldoc-eval.el  -*- no-byte-compile: t -*-
(define-package "eldoc-eval" "0.2" "Enable eldoc support when minibuffer is in use." 'nil :commit "e91800503c90cb75dc70abe42f1d6ae499346cc1" :url "https://elpa.gnu.org/packages/eldoc-eval.html" :authors '(("Thierry Volpiatto" . "thievol@posteo.net")) :maintainer '("Thierry Volpiatto" . "thievol@posteo.net"))
