;; Generated package description from fontaine.el  -*- no-byte-compile: t -*-
(define-package "fontaine" "0.1.1" "Set font configurations using presets" '((emacs "27.1")) :commit "e8e25d681854a97483a5ca3a0c39f04aaa19b1a0" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://git.sr.ht/~protesilaos/fontaine")
