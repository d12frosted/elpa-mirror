;; Generated package description from csharp-mode.el  -*- no-byte-compile: t -*-
(define-package "csharp-mode" "1.0.2" "C# mode derived mode" '((emacs "26.1")) :keywords '("c#" "languages" "oop" "mode") :authors '(("Theodor Thornhill" . "theo@thornhill.no")) :maintainer '("Jostein Kjønigsen" . "jostein@gmail.com") :url "https://github.com/emacs-csharp/csharp-mode")
