;; Generated package description from company.el  -*- no-byte-compile: t -*-
(define-package "company" "0.10.0" "Modular text completion framework" '((emacs "25.1")) :commit "b59662293cc9bd52bf6c7a4c3f70393351b52d71" :maintainer '("Dmitry Gutov" . "dmitry@gutov.dev") :keywords '("abbrev" "convenience" "matching") :url "http://company-mode.github.io/")
