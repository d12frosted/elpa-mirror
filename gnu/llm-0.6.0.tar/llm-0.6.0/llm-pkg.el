;; Generated package description from llm.el  -*- no-byte-compile: t -*-
(define-package "llm" "0.6.0" "Interface to pluggable llm backends" '((emacs "28.1")) :commit "d903c6ab759ef41d746e29c7f63924d403f23c22" :authors '(("Andrew Hyatt" . "ahyatt@gmail.com")) :maintainer '("Andrew Hyatt" . "ahyatt@gmail.com") :url "https://github.com/ahyatt/llm")
