;; Generated package description from llm.el  -*- no-byte-compile: t -*-
(define-package "llm" "0.4.0" "Interface to pluggable llm backends" '((emacs "28.1")) :commit "3d3f898c3085421e0d70faa85c38aac71e38de35" :authors '(("Andrew Hyatt" . "ahyatt@gmail.com")) :maintainer '("Andrew Hyatt" . "ahyatt@gmail.com") :url "https://github.com/ahyatt/llm")
