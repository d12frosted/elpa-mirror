;; Generated package description from javaimp.el  -*- no-byte-compile: t -*-
(define-package "javaimp" "0.8" "Add and reorder Java import statements in Maven/Gradle projects" 'nil :url "https://elpa.gnu.org/packages/javaimp.html" :authors '(("Filipp Gunbin" . "fgunbin@fastmail.fm")) :maintainer '("Filipp Gunbin" . "fgunbin@fastmail.fm") :keywords '("java" "maven" "gradle" "programming"))
