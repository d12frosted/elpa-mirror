;; Generated package description from rec-mode.el  -*- no-byte-compile: t -*-
(define-package "rec-mode" "1.9.1" "Major mode for viewing/editing rec files" '((emacs "25")) :commit "faae27aeb71cc9397d0fc1a19bd0df8c9e11cc98" :authors '(("Jose E. Marchesi" . "jemarch@gnu.org")) :maintainer '("Antoine Kalmbach" . "ane@iki.fi") :url "https://www.gnu.org/software/recutils/")
