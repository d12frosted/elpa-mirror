;; Generated package description from ulisp-repl.el  -*- no-byte-compile: t -*-
(define-package "ulisp-repl" "1.0.2" "uLisp REPL" '((emacs "26.1")) :commit "54f56604e95129a2734f043954163c8620fb864c" :url "https://elpa.gnu.org/packages/ulisp-repl.html" :authors '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")) :maintainer '("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
