;; Generated package description from sketch-mode.el  -*- no-byte-compile: t -*-
(define-package "sketch-mode" "1.0.3" "Quickly create svg sketches using keyboard and mouse" 'nil :authors '(("D.L. Nicolai" . "dalanicolai@gmail.com")) :maintainer '("D.L. Nicolai" . "dalanicolai@gmail.com") :keywords '("multimedia") :url "https://github.com/dalanicolai/sketch-mode")
