;; Generated package description from llm.el  -*- no-byte-compile: t -*-
(define-package "llm" "0.5.2" "Interface to pluggable llm backends" '((emacs "28.1")) :commit "a26abb4edee6c9f125c1c10804f197795be7fc6c" :authors '(("Andrew Hyatt" . "ahyatt@gmail.com")) :maintainer '("Andrew Hyatt" . "ahyatt@gmail.com") :url "https://github.com/ahyatt/llm")
