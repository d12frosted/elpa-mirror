;; Generated package description from vc-got.el  -*- no-byte-compile: t -*-
(define-package "vc-got" "1.0" "VC backend for Game of Trees VCS" '((emacs "25.1")) :keywords '("vc" "tools") :authors '(("Omar Polo" . "op@omarpolo.com") ("Timo Myyrä" . "timo.myyra@bittivirhe.fi")) :maintainer '("Omar Polo" . "op@omarpolo.com") :url "https://git.omarpolo.com/vc-got/")
