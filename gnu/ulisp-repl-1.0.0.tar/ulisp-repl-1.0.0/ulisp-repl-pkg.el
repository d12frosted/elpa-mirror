;; Generated package description from ulisp-repl.el  -*- no-byte-compile: t -*-
(define-package "ulisp-repl" "1.0.0" "uLisp REPL" '((emacs "26.1") (paredit "26")) :commit "1464faec29151e591ee171f7a7821bba5291595b" :url "https://elpa.gnu.org/packages/ulisp-repl.html" :authors '(("Thomas Fitzsimmons" . "fitzsim@fitzsim.org")) :maintainer '("Thomas Fitzsimmons" . "fitzsim@fitzsim.org"))
