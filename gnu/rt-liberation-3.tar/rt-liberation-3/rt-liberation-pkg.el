;; Generated package description from rt-liberation.el  -*- no-byte-compile: t -*-
(define-package "rt-liberation" "3" "Emacs interface to RT" 'nil :commit "d9342c68c3fd28d8a13738e2ac32a34f31f2debd" :authors '(("Yoni Rabkin" . "yrk@gnu.org")) :maintainer '("Yoni Rabkin" . "yrk@gnu.org") :keywords '("rt" "tickets") :url "http://www.nongnu.org/rtliber/")
