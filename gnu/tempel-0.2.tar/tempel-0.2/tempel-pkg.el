;; Generated package description from tempel.el  -*- no-byte-compile: t -*-
(define-package "tempel" "0.2" "Tempo templates/snippets with in-buffer field editing" '((emacs "27.1")) :commit "91d19e22f9f77f897c97177601d7f870fbf807cb" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/tempel")
