;; Generated package description from vc-backup.el  -*- no-byte-compile: t -*-
(define-package "vc-backup" "1.0.0" "VC backend for versioned backups" 'nil :keywords '("vc") :authors '(("Philip Kaludercic" . "philipk@posteo.net")) :maintainer '("Philip Kaludercic" . "philipk@posteo.net") :url "https://git.sr.ht/~pkal/vc-backup")
