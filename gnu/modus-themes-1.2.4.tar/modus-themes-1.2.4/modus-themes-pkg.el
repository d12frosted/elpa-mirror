;; Generated package description from modus-themes.el  -*- no-byte-compile: t -*-
(define-package "modus-themes" "1.2.4" "Highly accessible themes (WCAG AAA)" '((emacs "26.1")) :keywords '("faces" "theme" "accessibility") :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://gitlab.com/protesilaos/modus-themes")
