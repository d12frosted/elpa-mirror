;; Generated package description from boxy.el  -*- no-byte-compile: t -*-
(define-package "boxy" "1.0.3" "A boxy layout framework" '((emacs "26.1")) :authors '(("Tyler Grinn" . "tylergrinn@gmail.com")) :maintainer '("Tyler Grinn" . "tylergrinn@gmail.com") :keywords '("tools") :url "https://gitlab.com/tygrdev/boxy.el")
