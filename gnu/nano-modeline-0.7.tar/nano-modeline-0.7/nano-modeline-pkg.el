;; Generated package description from nano-modeline.el  -*- no-byte-compile: t -*-
(define-package "nano-modeline" "0.7" "N Λ N O modeline" '((emacs "27.1")) :commit "960ff4f01aa1273b4395d9985b5bda2d96af0cab" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience" "mode-line" "header-line") :url "https://github.com/rougier/nano-modeline")
