;; Generated package description from corfu.el  -*- no-byte-compile: t -*-
(define-package "corfu" "0.31" "Completion Overlay Region FUnction" '((emacs "27.1")) :commit "01ddb3b13e7b32c640cce208fe3bdac04a3e5bb0" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/corfu")
