;; Generated package description from rec-mode.el  -*- no-byte-compile: t -*-
(define-package "rec-mode" "1.9.0" "Major mode for viewing/editing rec files" '((emacs "25")) :commit "09f828e9f54f32b56a805e4192588643d95c2f44" :authors '(("Jose E. Marchesi" . "jemarch@gnu.org")) :maintainer '("Antoine Kalmbach" . "ane@iki.fi") :url "https://www.gnu.org/software/recutils/")
