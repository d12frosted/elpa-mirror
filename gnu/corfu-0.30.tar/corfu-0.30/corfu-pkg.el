;; Generated package description from corfu.el  -*- no-byte-compile: t -*-
(define-package "corfu" "0.30" "Completion Overlay Region FUnction" '((emacs "27.1")) :commit "aab6f7e34d7a65f060ba196cf1b1c62d6ceb9e43" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/corfu")
