;; Generated package description from counsel.el  -*- no-byte-compile: t -*-
(define-package "counsel" "0.12.0" "Various completion functions using Ivy" '((emacs "24.3") (swiper "0.12.0")) :keywords '("convenience" "matching" "tools") :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com")) :maintainer '("Oleh Krehel" . "ohwoeowho@gmail.com") :url "https://github.com/abo-abo/swiper")
