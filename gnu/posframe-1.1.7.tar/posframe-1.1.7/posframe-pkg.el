;; Generated package description from posframe.el  -*- no-byte-compile: t -*-
(define-package "posframe" "1.1.7" "Pop a posframe (just a frame) at point" '((emacs "26.1")) :commit "c91d4d53fa479ceb604071008ce0a901770eff57" :authors '(("Feng Shu" . "tumashu@163.com")) :maintainer '("Feng Shu" . "tumashu@163.com") :keywords '("convenience" "tooltip") :url "https://github.com/tumashu/posframe")
