;; Generated package description from setup.el  -*- no-byte-compile: t -*-
(define-package "setup" "1.0.0" "Helpful Configuration Macro" '((emacs "26.1")) :keywords '("lisp" "local") :authors '(("Philip Kaludercic" . "philipk@posteo.net")) :maintainer '("Philip Kaludercic" . "philipk@posteo.net") :url "https://git.sr.ht/~pkal/setup")
