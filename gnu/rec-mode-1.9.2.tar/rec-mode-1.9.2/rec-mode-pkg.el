;; Generated package description from rec-mode.el  -*- no-byte-compile: t -*-
(define-package "rec-mode" "1.9.2" "Major mode for viewing/editing rec files" '((emacs "25")) :commit "cfaa22f57d13e7ee5dc8a5725a464fee083ad915" :authors '(("Jose E. Marchesi" . "jemarch@gnu.org")) :maintainer '("Antoine Kalmbach" . "ane@iki.fi") :url "https://www.gnu.org/software/recutils/")
