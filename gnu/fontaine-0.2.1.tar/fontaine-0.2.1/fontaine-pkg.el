;; Generated package description from fontaine.el  -*- no-byte-compile: t -*-
(define-package "fontaine" "0.2.1" "Set font configurations using presets" '((emacs "27.1")) :commit "165aa35d9c73943372bfcdd52e95589e3cb9c10f" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://git.sr.ht/~protesilaos/fontaine")
