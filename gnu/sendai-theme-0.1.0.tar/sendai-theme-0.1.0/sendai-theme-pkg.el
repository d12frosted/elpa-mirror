;; Generated package description from sendai-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sendai-theme" "0.1.0" "A cool blue color theme" '((emacs "27.1")) :commit "e7a7fc191035f98082020113fbb5c89ac1b74f37" :keywords '("theme") :url "https://sr.ht/~jimporter/sendai-theme/")
