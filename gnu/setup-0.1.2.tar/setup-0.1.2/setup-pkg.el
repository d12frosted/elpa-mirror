;; Generated package description from setup.el  -*- no-byte-compile: t -*-
(define-package "setup" "0.1.2" "Helpful Configuration Macro" '((emacs "26.1")) :keywords '("lisp" "local") :authors '(("Philip K." . "philipk@posteo.net")) :maintainer '("Philip K." . "philipk@posteo.net") :url "https://git.sr.ht/~zge/setup")
