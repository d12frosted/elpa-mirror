;; Generated package description from ebdb.el  -*- no-byte-compile: t -*-
(define-package "ebdb" "0.8.5" "Contact management package" '((emacs "25.1") (seq "2.15")) :authors '(("Eric Abrahamsen" . "eric@ericabrahamsen.net")) :maintainer '("Eric Abrahamsen" . "eric@ericabrahamsen.net") :keywords '("convenience" "mail") :url "https://github.com/girzel/ebdb")
