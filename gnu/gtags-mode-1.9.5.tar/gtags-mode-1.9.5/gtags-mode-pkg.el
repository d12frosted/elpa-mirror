;; Generated package description from gtags-mode.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "gtags-mode" "1.9.5" "GNU Global integration with xref, project and imenu." '((emacs "28")) :commit "94de3a0a9c6b28d5a3dadc97dd52230922462a5d" :keywords '("xref" "project" "imenu" "gtags" "global") :url "https://github.com/Ergus/gtags-mode")
