;; Generated package description from beframe.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "beframe" "1.6.0" "Isolate buffers per frame" '((emacs "28.1")) :commit "6467a15db1144b8157cc73e21a491ceffa87e74a" :authors '(("Protesilaos" . "info@protesilaos.com")) :maintainer '("Protesilaos" . "info@protesilaos.com") :url "https://github.com/protesilaos/beframe")
