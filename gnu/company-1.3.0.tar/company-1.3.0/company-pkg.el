;; Generated package description from company.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "company" "1.3.0" "Modular text completion framework" '((emacs "26.1") (posframe "1.5.1")) :commit "db7f60efdf8364e66161cb8a8ea9bb703ab37247" :maintainer '("Dmitry Gutov" . "dmitry@gutov.dev") :keywords '("abbrev" "convenience" "matching") :url "http://company-mode.github.io/")
