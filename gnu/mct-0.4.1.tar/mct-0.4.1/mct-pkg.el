;; Generated package description from mct.el  -*- no-byte-compile: t -*-
(define-package "mct" "0.4.1" "Minibuffer and Completions in Tandem" '((emacs "27.1")) :commit "36047846601360089ad134570a43c38c250cad31" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://gitlab.com/protesilaos/mct")
