;; Generated package description from taxy.el  -*- no-byte-compile: t -*-
(define-package "taxy" "0.4" "Programmable taxonomical grouping for arbitrary objects" '((emacs "26.3")) :keywords '("lisp") :authors '(("Adam Porter" . "adam@alphapapa.net")) :maintainer '("Adam Porter" . "adam@alphapapa.net") :url "https://github.com/alphapapa/taxy.el")
