;; Generated package description from mct.el  -*- no-byte-compile: t -*-
(define-package "mct" "0.1.0" "Minibuffer and Completions in Tandem" '((emacs "28.1")) :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://gitlab.com/protesilaos/mct")
