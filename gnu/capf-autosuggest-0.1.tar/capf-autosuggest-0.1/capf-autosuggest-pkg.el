;; Generated package description from capf-autosuggest.el  -*- no-byte-compile: t -*-
(define-package "capf-autosuggest" "0.1" "History autosuggestions for comint and eshell" '((emacs "25.1")) :authors '(("jakanakaevangeli" . "jakanakaevangeli@chiru.no")) :maintainer '("jakanakaevangeli" . "jakanakaevangeli@chiru.no") :url "https://repo.or.cz/emacs-capf-autosuggest.git")
