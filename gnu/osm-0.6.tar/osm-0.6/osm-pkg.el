;; Generated package description from osm.el  -*- no-byte-compile: t -*-
(define-package "osm" "0.6" "OpenStreetMap viewer" '((emacs "27.1")) :commit "f76decfd0e94d5fc030a1d5c3230c213c87b47ef" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/osm")
