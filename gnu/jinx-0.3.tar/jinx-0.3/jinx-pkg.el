;; Generated package description from jinx.el  -*- no-byte-compile: t -*-
(define-package "jinx" "0.3" "Enchanted Just-in-time Spell Checker" '((emacs "27.1") (compat "29.1.4.0")) :commit "1293ba8eda27b3c68e832d1681b4d12307b63df4" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/jinx")
