;; Generated package description from boxy.el  -*- no-byte-compile: t -*-
(define-package "boxy" "1.1.0" "A boxy layout framework" '((emacs "26.1")) :commit "68b1c6db7bb585e5942ab2e12765cf80cfcfb619" :authors '(("Tyler Grinn" . "tylergrinn@gmail.com")) :maintainer '("Tyler Grinn" . "tylergrinn@gmail.com") :keywords '("tools") :url "https://gitlab.com/tygrdev/boxy")
