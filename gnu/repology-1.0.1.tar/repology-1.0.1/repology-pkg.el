;; Generated package description from repology.el  -*- no-byte-compile: t -*-
(define-package "repology" "1.0.1" "Repology API access via Elisp" '((emacs "26.1")) :url "https://elpa.gnu.org/packages/repology.html" :keywords '("web") :authors '(("Nicolas Goaziou" . "mail@nicolasgoaziou.fr")) :maintainer '("Nicolas Goaziou" . "mail@nicolasgoaziou.fr"))
