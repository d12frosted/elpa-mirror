;; Generated package description from plz.el  -*- no-byte-compile: t -*-
(define-package "plz" "0.5" "HTTP library" '((emacs "26.3")) :commit "fc8159a6a9bf56d70614931bc50a7adf62707967" :authors '(("Adam Porter" . "adam@alphapapa.net")) :maintainer '("Adam Porter" . "adam@alphapapa.net") :keywords '("comm" "network" "http") :url "https://github.com/alphapapa/plz.el")
