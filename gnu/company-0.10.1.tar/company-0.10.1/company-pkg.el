;; Generated package description from company.el  -*- no-byte-compile: t -*-
(define-package "company" "0.10.1" "Modular text completion framework" '((emacs "25.1")) :commit "d832d886d0dce655b44de8c5e1eec749b2bea3a3" :maintainer '("Dmitry Gutov" . "dmitry@gutov.dev") :keywords '("abbrev" "convenience" "matching") :url "http://company-mode.github.io/")
