;; Generated package description from osm.el  -*- no-byte-compile: t -*-
(define-package "osm" "0.8" "OpenStreetMap viewer" '((emacs "27.1")) :commit "563d9646b1f8df37cefcec5d51d20249eba407da" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/osm")
