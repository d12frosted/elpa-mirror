;; Generated package description from logos.el  -*- no-byte-compile: t -*-
(define-package "logos" "0.1.2" "Simple focus mode and extras" '((emacs "27.1")) :commit "37138ce54044d04eaad5d5f81d42eefceef0df01" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://gitlab.com/protesilaos/logos")
