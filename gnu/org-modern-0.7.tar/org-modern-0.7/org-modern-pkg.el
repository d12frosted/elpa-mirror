;; Generated package description from org-modern.el  -*- no-byte-compile: t -*-
(define-package "org-modern" "0.7" "Modern looks for Org" '((emacs "27.1")) :commit "c9c0c5135a66382f55681bc84f3a2658a7c8ac76" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/org-modern")
