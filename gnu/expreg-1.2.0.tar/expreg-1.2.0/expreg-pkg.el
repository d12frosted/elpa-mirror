;; Generated package description from expreg.el  -*- no-byte-compile: t -*-
(define-package "expreg" "1.2.0" "Simple expand region" '((emacs "29.1")) :commit "f6f6abcd00960d0b8bb7cc96f9706036ed1956c9" :authors '(("Yuan Fu" . "casouri@gmail.com")) :maintainer '("Yuan Fu" . "casouri@gmail.com") :keywords '("text" "editing") :url "https://github.com/casouri/expreg")
