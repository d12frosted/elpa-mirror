;; Generated package description from rt-liberation.el  -*- no-byte-compile: t -*-
(define-package "rt-liberation" "2.4" "Emacs interface to RT" 'nil :keywords '("rt" "tickets") :authors '(("Yoni Rabkin" . "yrk@gnu.org")) :maintainer '("Yoni Rabkin" . "yrk@gnu.org") :url "http://www.nongnu.org/rtliber/")
