;; Generated package description from rec-mode.el  -*- no-byte-compile: t -*-
(define-package "rec-mode" "1.8.3" "Major mode for viewing/editing rec files" '((emacs "25")) :commit "24adb19f70f682f28d6edac03598b1fee971d599" :authors '(("Jose E. Marchesi" . "jemarch@gnu.org")) :maintainer '("Antoine Kalmbach" . "ane@iki.fi") :url "https://www.gnu.org/software/recutils/")
