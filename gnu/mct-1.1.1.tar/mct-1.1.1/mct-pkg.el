;; Generated package description from mct.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "mct" "1.1.1" "Minibuffer Confines Transcended" '((emacs "29.4")) :commit "ffe1555ace9041c93b78ba2fdf1f4656111394f3" :authors '(("Protesilaos" . "info@protesilaos.com")) :maintainer '("Protesilaos" . "info@protesilaos.com") :url "https://github.com/protesilaos/mct")
