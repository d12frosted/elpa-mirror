;; Generated package description from jarchive.el  -*- no-byte-compile: t -*-
(define-package "jarchive" "0.9.0" "Open project dependencies in jar archives" '((emacs "26.1")) :commit "9f14b742fce3d3379c41dfca3039c80e6fe8c53a" :maintainer '("Danny Freeman" . "danny@dfreeman.email") :keywords '("tools" "languages" "jvm" "java" "clojure") :url "https://git.sr.ht/~dannyfreeman/jarchive")
