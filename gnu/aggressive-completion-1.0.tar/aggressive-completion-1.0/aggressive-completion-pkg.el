;; Generated package description from aggressive-completion.el  -*- no-byte-compile: t -*-
(define-package "aggressive-completion" "1.0" "Automatic minibuffer completion" '((emacs "27.1")) :url "https://elpa.gnu.org/packages/aggressive-completion.html" :keywords '("minibuffer" "completion") :authors '(("Tassilo Horn" . "tsdh@gnu.org")) :maintainer '("Tassilo Horn" . "tsdh@gnu.org"))
