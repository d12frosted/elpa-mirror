;; Generated package description from auctex.el  -*- mode: lisp-data; no-byte-compile: t -*-
(define-package "auctex" "14.1.1" "Integrated environment for *TeX*" '((emacs "28.1")) :commit "001686a66066774c8d3d3541c09ac735aef62455" :maintainer '(nil . "auctex-devel@gnu.org") :keywords '("tex" "latex" "texinfo" "context" "doctex" "preview-latex") :url "https://www.gnu.org/software/auctex/")
