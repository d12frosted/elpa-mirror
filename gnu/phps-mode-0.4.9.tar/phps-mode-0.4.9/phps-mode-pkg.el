;; Generated package description from phps-mode.el  -*- no-byte-compile: t -*-
(define-package "phps-mode" "0.4.9" "Major mode for PHP with Semantic integration" '((emacs "26")) :authors '(("Christian Johansson" . "christian@cvj.se")) :maintainer '("Christian Johansson" . "christian@cvj.se") :keywords '("tools" "convenience") :url "https://github.com/cjohansson/emacs-phps-mode")
