;; Generated package description from bbdb.el  -*- no-byte-compile: t -*-
(define-package "bbdb" "3.2.2.1" "Big Brother DataBase" '((emacs "24") (cl-lib "0.5")) :commit "387bb5f216dd7c2d901af186b07d84f005c583c4" :url "https://elpa.gnu.org/packages/bbdb.html" :maintainer '("Roland Winkler" . "winkler@gnu.org"))
