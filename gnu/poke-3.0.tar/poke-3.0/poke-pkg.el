;; Generated package description from poke.el  -*- no-byte-compile: t -*-
(define-package "poke" "3.0" "Emacs meets GNU poke!" '((emacs "25")) :commit "bc0bd9e618a468bbb0d0a68cdc2462db43b5b689" :authors '(("Jose E. Marchesi" . "jemarch@gnu.org")) :maintainer '("Jose E. Marchesi" . "jemarch@gnu.org") :url "https://www.jemarch.net/poke")
