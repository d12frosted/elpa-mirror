;; Generated package description from boxy.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "boxy" "2.0.1" "A boxy layout framework" '((emacs "26.1")) :commit "793e3d65ffb970fa8b52e89d25e7ea5e6f39508a" :authors '(("Amy Pillow" . "amypillow@lavache.com")) :maintainer '("Amy Pillow" . "amypillow@lavache.com") :keywords '("tools") :url "https://codeberg.org/strawburster/boxy")
