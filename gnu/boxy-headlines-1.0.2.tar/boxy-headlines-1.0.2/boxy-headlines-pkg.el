;; Generated package description from boxy-headlines.el  -*- no-byte-compile: t -*-
(define-package "boxy-headlines" "1.0.2" "View org files in a boxy diagram" '((emacs "26.1") (boxy "1.0")) :authors '(("Tyler Grinn" . "tylergrinn@gmail.com")) :maintainer '("Tyler Grinn" . "tylergrinn@gmail.com") :keywords '("tools") :url "https://gitlab.com/tygrdev/boxy-headlines")
