;; Generated package description from plz.el  -*- no-byte-compile: t -*-
(define-package "plz" "0.4" "HTTP library" '((emacs "26.3")) :commit "3e8a8e0bf6312922ccf65721f2d13dbd7ce76170" :authors '(("Adam Porter" . "adam@alphapapa.net")) :maintainer '("Adam Porter" . "adam@alphapapa.net") :keywords '("comm" "network" "http") :url "https://github.com/alphapapa/plz.el")
