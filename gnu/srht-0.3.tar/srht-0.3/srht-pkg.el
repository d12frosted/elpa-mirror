;; Generated package description from srht.el  -*- no-byte-compile: t -*-
(define-package "srht" "0.3" "Sourcehut" '((emacs "27.1") (plz "0.7")) :commit "8cab1e48bcb5b8ee70c498a712fb6f52eddc95ab" :authors '(("Aleksandr Vityazev" . "avityazev@posteo.org")) :maintainer '("Aleksandr Vityazev" . "avityazev@posteo.org") :keywords '("comm" "vc") :url "https://sr.ht/~akagi/srht.el/")
