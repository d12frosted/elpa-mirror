;; Generated package description from urgrep.el  -*- no-byte-compile: t -*-
(define-package "urgrep" "0.1.0" "Universal recursive grep" '((emacs "27.1") (compat "29.1.0.1") (project "0.3.0")) :commit "d1cc269eeca739aceb31d983a562264d94ea2dfb" :authors '(("Jim Porter")) :maintainer '("Jim Porter") :keywords '("grep" "search") :url "https://github.com/jimporter/urgrep")
