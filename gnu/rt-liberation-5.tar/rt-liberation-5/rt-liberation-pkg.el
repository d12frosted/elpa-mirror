;; Generated package description from rt-liberation.el  -*- no-byte-compile: t -*-
(define-package "rt-liberation" "5" "Emacs interface to RT" 'nil :commit "b76ae2828b12efc5f45f51ba873489e049a70924" :authors '(("Yoni Rabkin" . "yrk@gnu.org")) :maintainer '("Yoni Rabkin" . "yrk@gnu.org") :keywords '("rt" "tickets") :url "http://www.nongnu.org/rtliber/")
