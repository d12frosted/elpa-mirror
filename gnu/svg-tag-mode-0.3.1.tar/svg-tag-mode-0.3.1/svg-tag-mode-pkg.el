;; Generated package description from svg-tag-mode.el  -*- no-byte-compile: t -*-
(define-package "svg-tag-mode" "0.3.1" "Replace keywords with SVG tags" '((emacs "27.1") (svg-lib "0.3")) :authors '(("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr")) :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience") :url "https://github.com/rougier/svg-tag-mode")
