;; Generated package description from tempel.el  -*- no-byte-compile: t -*-
(define-package "tempel" "0.4" "Tempo templates/snippets with in-buffer field editing" '((emacs "27.1")) :commit "ff9756b0646b1d06443eb4bdc64db443f1aa6c40" :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :url "https://github.com/minad/tempel")
