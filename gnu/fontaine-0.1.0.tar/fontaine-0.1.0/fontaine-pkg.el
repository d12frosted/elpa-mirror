;; Generated package description from fontaine.el  -*- no-byte-compile: t -*-
(define-package "fontaine" "0.1.0" "Set font configurations using presets" '((emacs "27.1")) :commit "7896f2cdf5b2b71c718a580eec44677a0da48234" :authors '(("Protesilaos Stavrou" . "info@protesilaos.com")) :maintainer '("Protesilaos Stavrou" . "info@protesilaos.com") :url "https://git.sr.ht/~protesilaos/fontaine")
