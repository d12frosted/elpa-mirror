;; Generated package description from minibuffer-header.el  -*- no-byte-compile: t -*-
(define-package "minibuffer-header" "0.5.0.20220921.71345" "Minibuffer header line" '((emacs "27.1")) :commit "5b5ffd9cbb6a07eecb2b04118ca235657f85a8df" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience") :url "https://github.com/rougier/minibuffer-header")
