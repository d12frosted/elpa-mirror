# QREncode EL

QR Code encoder written in pure Emacs Lisp.

For example the self-link (<https://github.com/ruediger/qrencode-el>)
below was generated using this code:

![](qr-self.svg)

## Usage

This package provides three user facing interactive functions, that
will encode text into a QR Code and show it in a separate buffer.

`qrencode-region`  
Shows the current selection as a QR Code.

`qrencode-url-at-point`  
Encode URL at point as QR Code.

`qrencode-string`  
Encode a specific string (leading/trailing
whitespace trimmed).

Some customizations are provided using `M-x customize-group RET
  qrencode RET`.

QR Codes are rendered as Unicode text, but there is an option to
export them as bitmap (NetPBM format) or vector graphics (SVG) by
pressing `e` in the QR Code buffer. There are also some public
elisp library functions to generate QR Codes for use in other elisp
code.

Currently two NetPBM formats are supported: P1 and P4. The latter
is much smaller and the exporter much faster, so highly recommended.
But due to backwards compatibility reasons we currently default to
P1. By customizing `qrencode-export-format` to `'p4` the export
format can be changed. In the next major version release P1 support
is likely to get dropped in favour of P4.

SVG export is available if `svg.el` (Emacs 26.1 or newer) is
available. This can be selected by customizing
`qrencode-export-format` to `'svg` or by using the `.svg` file name
suffix. Filename based format detection is controlled using
`qrencode-export-format-based-on-filename`, which is enabled by
default.

### Converting different bitmaps

This package only supports exporting to NetPBM format due to the
simplicity of the format. If PNG or other bitmap formats are
desired this can be achieved by using
`qrencode-post-export-functions` to run a conversion after the
export. For example using `convert(1)` from [ImageMagick](https://www.imagemagick.org/script/convert.php):

``` commonlisp
(add-hook 'qrencode-post-export-functions
        #'(lambda (filename)
            (call-process "convert" nil nil nil
                          filename
                          (file-name-with-extension filename "png"))))
```

## Installation

[![](https://elpa.gnu.org/packages/qrencode.svg)](https://elpa.gnu.org/packages/qrencode.html)
[![](https://elpa.gnu.org/devel/qrencode.svg)](https://elpa.gnu.org/devel/qrencode.html)
[![](https://melpa.org/packages/qrencode-badge.svg)](https://melpa.org/#/qrencode)
[![](https://stable.melpa.org/packages/qrencode-badge.svg)](https://stable.melpa.org/#/qrencode)

QREncode is available via [GNU ELPA](https://elpa.gnu.org/packages/qrencode.html), [MELPA,](https://melpa.org/#/qrencode) and [el-get](https://github.com/dimitri/el-get/blob/master/recipes/qrencode.rcp).

## Background

![](https://github.com/ruediger/qrencode-el/actions/workflows/test.yml/badge.svg)

The code is written in pure Emacs Lisp on GNU Emacs 31. It should
be backwards compatible to GNU Emacs 25.1 and potentially even
earlier with `seq` and `cl-lib` compat libraries.

There are unit tests and an integration test using [zbar.sf.net](https://zbar.sf.net)
(Debian/Ubuntu package `zbar-tools`) to verify that generated QR
Codes can be decoded. <https://qrlogo.kaarposoft.dk/qrdecode.html> is
another good way to test the generated codes, since the decoder
supports debug output.

The encoder is written for the ISO/IEC 18004:2015 standard. It only
supports regular QR Codes (Model 2) and byte encoding (#11). I
believe this is sufficient for use-cases in GNU Emacs. The word "QR
Code" is registered trademark of DENSO WAVE INCORPORATED in Japan
and other countries.
