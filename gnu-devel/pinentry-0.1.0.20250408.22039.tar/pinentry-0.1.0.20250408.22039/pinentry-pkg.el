;; Generated package description from .el  -*- pinentryno-byte-compile: t -*-
(define-package "pinentry" "0.1.0.20250408.22039" "GnuPG Pinentry server implementation" 'nil :commit "0079964a1dde954ccb2ce8a28613d8020c549a36" :authors '(("Daiki Ueno" . "ueno@gnu.org")) :maintainer '("Daiki Ueno" . "ueno@gnu.org") :keywords '("gnupg") :url "https://github.com/ueno/pinentry-el")
