;; Generated package description from sisu-mode.el  -*- no-byte-compile: t -*-
(define-package "sisu-mode" "7.1.8.0.20221221.82114" "Major mode for SiSU markup text" 'nil :commit "96ab69ba228860c99f505bc02d2917a8b607cc07" :maintainer '("Ralph Amissah" . "ralph.amissah@gmail.com") :keywords '("text" "syntax" "processes" "tools") :url "https://www.sisudoc.org/")
