;; Test resource

(a b)
