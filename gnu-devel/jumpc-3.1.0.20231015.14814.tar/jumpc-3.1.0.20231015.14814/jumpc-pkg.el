;; Generated package description from jumpc.el  -*- no-byte-compile: t -*-
(define-package "jumpc" "3.1.0.20231015.14814" "jump to previous insertion points" 'nil :commit "ab83a2a5416f83405361e25df8cbd8aab35cb8b3" :url "https://elpa.gnu.org/packages/jumpc.html" :authors '(("Ivan Kanis" . "ivan@kanis.fr")) :maintainer '("Ivan Kanis" . "ivan@kanis.fr"))
