;; Generated package description from filladapt.el  -*- no-byte-compile: t -*-
(define-package "filladapt" "2.12.2.0.20221221.75607" "Adaptive fill" '((emacs "24.4")) :commit "802c1942a7685ebf2af4db021f303d7a767c5915" :url "https://elpa.gnu.org/packages/filladapt.html" :authors '(("Kyle E. Jones" . "kyle_jones@wonderworks.com")) :maintainer '(nil . "emacs-devel@gnu.org"))
