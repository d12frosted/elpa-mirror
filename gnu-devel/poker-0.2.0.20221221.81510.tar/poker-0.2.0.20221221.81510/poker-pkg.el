;; Generated package description from poker.el  -*- no-byte-compile: t -*-
(define-package "poker" "0.2.0.20221221.81510" "Texas hold 'em poker" 'nil :commit "52559b7bb0e046d044d09469ea06240fc252786e" :url "https://elpa.gnu.org/packages/poker.html" :authors '(("Mario Lang" . "mlang@delysid.org")) :maintainer '("Mario Lang" . "mlang@delysid.org") :keywords '("games"))
