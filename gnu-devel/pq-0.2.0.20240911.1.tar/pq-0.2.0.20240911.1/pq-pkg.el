;; Generated package description from pq.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "pq" "0.2.0.20240911.1" "libpq binding" '((emacs "25")) :commit "a4f4083e2b2ec14ff60ce556d5a457579dd62dd3" :authors '(("Tom Gillespie" . "tgbugs@gmail.com")) :maintainer '("Tom Gillespie" . "tgbugs@gmail.com") :url "https://github.com/anse1/emacs-libpq")
