;; Generated package description from rcirc-color.el  -*- no-byte-compile: t -*-
(define-package "rcirc-color" "0.4.5.0.20230414.195045" "color nicks" '((emacs "24.4")) :commit "79449152cb71ec4d719d4b1a95c1192fb9831ceb" :url "https://elpa.gnu.org/packages/rcirc-color.html" :authors '(("Alex Schroeder" . "alex@gnu.org")) :maintainer '("Alex Schroeder" . "alex@gnu.org") :keywords '("comm"))
