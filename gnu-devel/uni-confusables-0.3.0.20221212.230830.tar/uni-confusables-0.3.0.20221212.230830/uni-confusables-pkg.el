;; Generated package description from uni-confusables.el  -*- no-byte-compile: t -*-
(define-package "uni-confusables" "0.3.0.20221212.230830" "Unicode confusables table" 'nil :commit "717f69029bde6479b98d3b2ba52850051913c796" :url "https://elpa.gnu.org/packages/uni-confusables.html" :maintainer '("Teodor Zlatanov" . "tzz@lifelogs.com"))
