;; Generated package description from captain.el  -*- no-byte-compile: t -*-
(define-package "captain" "1.0.3.0.20221221.74732" "CAPiTalization is Automatic IN emacs" 'nil :commit "364ee98226ad5f8bb8d125299a912afa1ca67c49" :url "https://elpa.gnu.org/packages/captain.html" :authors '(("Ian Dunn" . "dunni@gnu.org")) :maintainer '("Ian Dunn" . "dunni@gnu.org") :keywords '("editing"))
