;;; gnosis.el --- Linked notes and spaced repetition  -*- lexical-binding: t; -*-

;; Copyright (C) 2023-2026  Free Software Foundation, Inc.

;; Author: Thanos Apollo <public@thanosapollo.org>
;; Keywords: extensions
;; URL: https://git.thanosapollo.org/emacs-gnosis

;; Version: 0.13.0

;; Package-Requires: ((emacs "29.1") (compat "29.1.4.2")
;;                     (keymap-popup "0.4.4"))

;; This program is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; Gnosis combines linked Org notes with spaced repetition and self-testing.
;; Notes (nodes) remain plain Org files.  SQLite stores their index,
;; questions (themata), schedules and review history.
;;
;; Write notes with `gnosis-nodes-find', create questions with
;; `gnosis-add-thema', and link them to their sources using
;; `gnosis-nodes-insert'.  Use `gnosis-review' for scheduled review or
;; `gnosis-review-topic' to study questions linked to a note.  Separate
;; practice sessions leave spaced-repetition schedules unchanged.
;;
;; Scheduling uses FSRS-6.  Optional agent interfaces support content
;; discovery, guarded organization, native practice and rubric-based
;; response evaluation.  Ordinary use requires no model or service.

;;; Code:

(require 'cl-lib)
(require 'seq)
(require 'subr-x)

(require 'gnosis-db)
(require 'gnosis-model)
(require 'gnosis-image)
(require 'gnosis-scheduler)
(require 'gnosis-logical-day)
(require 'gnosis-vc)
(require 'gnosis-tags)
(require 'gnosis-links)
(require 'animate)

(require 'org)
(require 'org-element)

(require 'gnosis-monkeytype)
(require 'gnosis-utils)
(require 'gnosis-answer)
(require 'gnosis-org)
(require 'gnosis-cloze)
(require 'gnosis-nodes)
(require 'gnosis-journal)

(defgroup gnosis nil
  "Knowledege Management System For Note Taking & Self Testing."
  :group 'external
  :prefix "gnosis-")

(defcustom gnosis-string-difference 1
  "Threshold value for string comparison in Gnosis.

This variable determines the maximum acceptable Levenshtein distance
between two strings to consider them as similar."
  :type 'integer)

(defcustom gnosis-completing-read-function
  (cond ((or (bound-and-true-p ivy-mode)
	     (bound-and-true-p helm-mode)
	     (bound-and-true-p vertico-mode)
	     (bound-and-true-p fido-mode))
	 #'completing-read)
	(t #'ido-completing-read))
  "Function to use for `completing-read'."
  :type 'function)

(defcustom gnosis-new-themata-limit nil
  "Total new themata limit."
  :type '(choice (const :tag "None" nil)
		 (integer :tag "Number")))

(defcustom gnosis-review-new-first t
  "Review new themata first.

When nil, review new themata last."
  :type 'boolean)

(defcustom gnosis-default-average-review-period 90
  "Number of days of which the average review score will be calculated."
  :type 'integer)

(defcustom gnosis-center-content-during-review t
  "Default value for centering content during review sessions.

This is the global default used when creating new review buffers.
When non-nil, center content during review sessions.
When nil, content will be displayed left-aligned instead of centered."
  :type 'boolean)

(defcustom gnosis-latex-preview nil
  "When non-nil, render LaTeX fragments during review."
  :type 'boolean
  :group 'gnosis)

(defcustom gnosis-script-input-method-alist
  '((greek . "greek")
    (cyrillic . "cyrillic-translit"))
  "Alist mapping script symbols to input method names.
Each element is (SCRIPT . INPUT-METHOD) where SCRIPT is a symbol
from `char-script-table' and INPUT-METHOD is a string suitable for
`activate-input-method'."
  :type '(alist :key-type symbol :value-type string)
  :group 'gnosis)

(defvar-local gnosis-center-content t
  "Buffer-local variable controlling content centering.

When non-nil, center content in the current buffer.
This is set automatically based on buffer type:
- Review buffers: uses `gnosis-center-content-during-review'
- Dashboard buffers: always t (centered)
- Other buffers: defaults to t")

;;; Faces

(defface gnosis-face-separator
  '((default :inherit org-hide)
    (((background light)) :strike-through "gray70")
    (t :strike-through "gray30"))
  "Face for section separator.")

(defface gnosis-face-directions
  '((t :inherit underline))
  "Face for gnosis directions.")

(defface gnosis-face-correct
  '((t :inherit match))
  "Face for user choice.")

(defface gnosis-face-cloze
  '((t :inherit (highlight italic)))
  "Face for clozes.")

(defface gnosis-face-false
  '((t :inherit error))
  "Face for user choice.")

(defface gnosis-face-unanswered
  '((t :inherit (italic underline)))
  "Face for unanswered clozes.")

(defface gnosis-face-hint
  '((t :inherit warning))
  "Face for user choice.")

(defface gnosis-face-cloze-unanswered
  '((t :inherit underline))
  "Face for user choice.")

(defface gnosis-face-next-review
  '((t :inherit bold))
  "Face for next review.")

(autoload 'gnosis-dashboard "gnosis-dashboard" nil t)

(defvar gnosis-thema-types
  '(("Basic" . gnosis-add-thema--basic)
    ("Agent-eval" . gnosis-add-thema--agent-eval)
    ("MCQ" .  gnosis-add-thema--mcq)
    ("Double" .  gnosis-add-thema--double)
    ("Cloze" . gnosis-add-thema--cloze)
    ("MC-cloze" . gnosis-add-thema--mc-cloze)
    ("Model" . gnosis-model--save)
    ("Model-name" . gnosis-model--save)
    ("Image-region" . gnosis-image--save)
    ("Image-occlusion" . gnosis-image--save))
  "Mapping of thema types to their save functions.
Each function returns the saved integer ID or, for multiple themata, a
list of integer IDs.  Native save publishes those IDs after commit.")

(defvar gnosis-previous-thema-hint nil
  "Hint input from previously added thema.")

(defvar gnosis-due-themata-total nil
  "Total due themata.")


;; Review autoloads
(autoload 'gnosis-review "gnosis-review" nil t)
(autoload 'gnosis-review-topic "gnosis-review" nil t)
(autoload 'gnosis-review-get-due-themata "gnosis-review")
(autoload 'gnosis-review-get--due-themata "gnosis-review")
(autoload 'gnosis-review-is-due-p "gnosis-review")
(autoload 'gnosis-review-is-due-today-p "gnosis-review")
(autoload 'gnosis-review-is-thema-new-p "gnosis-review")
(autoload 'gnosis-review-get-overdue-themata "gnosis-review")
(autoload 'gnosis-review-count-due "gnosis-review")
(autoload 'gnosis-review-count-overdue "gnosis-review")
(autoload 'gnosis-review-algorithm "gnosis-review")
(autoload 'gnosis-display-next-review "gnosis-review")
(autoload 'gnosis-get-linked-nodes "gnosis-review")
(autoload 'gnosis-monkeytype-start "gnosis-review" nil t)

;; Anki import autoload
(autoload 'gnosis-import-anki "gnosis-anki" nil t)

;; Export/import autoloads
(autoload 'gnosis-export--insert-thema "gnosis-export-import")
(autoload 'gnosis-export--insert-themata "gnosis-export-import")
(autoload 'gnosis-export-parse-themata "gnosis-export-import")
(autoload 'gnosis-export-db "gnosis-export-import" nil t)
(autoload 'gnosis-import-db "gnosis-export-import" nil t)
(autoload 'gnosis-save-thema "gnosis-export-import")
(autoload 'gnosis-save "gnosis-export-import" nil t)

(defvar gnosis-export-separator "\n- ")

(defvar gnosis-save-hook nil
  "Hook run after a successful `gnosis-save'.
Each function is called once per saved thema ID (integer), after commit.")


(defvar gnosis-review-editing-p nil
  "Boolean value to check if user is currently in a review edit.")

(defun gnosis-delete-thema (id &optional verification validate)
  "Delete thema with ID.

When VERIFICATION is non-nil, skip `y-or-n-p' prompt.
Optional VALIDATE checks caller ownership before and after confirmation.
Return t when deletion completes, or nil when confirmation is declined.
Errors and quits propagate without reporting completion."
  (when validate (funcall validate))
  (when (or verification (y-or-n-p "Delete thema?"))
    (when validate (funcall validate))
    (gnosis-delete-themata (list id))))

(defun gnosis-delete-themata (ids)
  "Delete themata with IDS, batched to stay within SQL variable limits.
Return t after the transaction completes, including for already absent IDs.
Errors and quits roll back the transaction and propagate to the caller."
  (let ((db (gnosis--ensure-db)))
    (gnosis-sqlite-with-transaction db
      (dolist (table '("thema_tag" "thema_links" "extras" "themata"))
        (gnosis-sqlite-execute-batch db
				     (format "DELETE FROM %s WHERE %s IN (%%s)"
					     table
					     (if (string= table "thema_tag") "thema_id"
					       (if (string= table "thema_links") "source" "id")))
				     ids)))
    t))


(defun gnosis-review-activity (&optional date)
  "Return aggregate review activity, optionally only for DATE.
Rows have the shape (DATE REVIEWED-TOTAL REVIEWED-NEW).  A missing DATE
returns an explicit zero row without mutating review evidence."
  (let ((rows (gnosis-db-review-activity)))
    (if date (or (assoc date rows) (list date 0 0)) rows)))

(defun gnosis-calculate-average-daily-reviews (&optional days)
  "Calculate average reviews over the last DAYS days."
  (let* ((days (or days gnosis-default-average-review-period))
	 (dates (cl-loop for d from 0 below days
			 collect (gnosis--date-to-int (gnosis-date (- d)))))
	 (activity (gnosis-review-activity))
	 (review-counts
	  (cl-loop for date in dates
		   for count = (nth 1 (assoc date activity))
		   when (and count (> count 0)) collect count)))
    (if review-counts
	(/ (apply #'+ review-counts) (float (length review-counts)))
      0)))

(defun gnosis-shuffle (seq)
  "Shuffle SEQ."
  (cl-loop with len = (length seq)
           for i from len downto 2
           do (let ((j (random i)))  ; Get random index < i.
                (cl-rotatef (nth (1- i) seq) (nth j seq)))  ; Swap elements.
           finally return seq))

(defun gnosis-completing-read (prompt seq &optional require-match)
  "Call `gnosis-completing-read-function' with shuffled SEQ.

PROMPT: Prompt for `gnosis-completing-read-function'.
REQUIRE-MATCH: When non-nil, user must select from SEQ.
History is disabled."
  (let ((history-add-new-input nil)
	(collection (gnosis-shuffle (copy-sequence seq))))
    (if require-match
	(completing-read prompt collection nil t)
      (funcall gnosis-completing-read-function prompt collection))))

(defun gnosis-insert-separator ()
  "Insert a line separator."
  (insert "\n" (propertize " " 'display '(space :width text)
                           'gnosis-display-layout 'independent
                           'face 'gnosis-face-separator)))

(defun gnosis-center-current-line ()
  "Center the current text line, ignoring leading spaces.
Leave display-bearing lines intact; their widths are not character counts."
  (let* ((start (line-beginning-position))
         (end (line-end-position))
         (text (string-trim (buffer-substring start end)))
         (padding (max (/ (- (window-width) (length text)) 2) 0)))
    ;; Display objects have pixel widths, not the width of their backing text.
    (unless (text-property-not-all start end 'display nil)
      (delete-region start end)
      (insert (make-string padding ? ) text))))

(defun gnosis-center-string (str)
  "Center each text line of STR in current window width.
Replace links `[[source][description]]' with `description'.
Leave display-bearing lines unfilled and unpadded, preserving their properties."
  (let* ((width (window-width))
         (lines (split-string str "\n")))
    (mapconcat
     (lambda (line)
       (cond
        ;; Do not trim/fill image-bearing spaces or pad by character width.
        ((text-property-not-all 0 (length line) 'display nil line)
         (replace-regexp-in-string
          "\\[\\[\\([^]]+\\)\\]\\[\\([^]]+\\)\\]\\]" "\\2" line))
        ((string-blank-p line) "")
        (t
         (let* ((trimmed (string-trim line))
                ;; Replace links with just the description part
                (processed (replace-regexp-in-string
			    "\\[\\[\\([^]]+\\)\\]\\[\\([^]]+\\)\\]\\]"
			    "\\2"
			    trimmed))
                ;; Fill the text to wrap it properly
                (wrapped (with-temp-buffer
                           (insert processed)
                           (fill-region (point-min) (point-max))
                           (buffer-string)))
                ;; Process each wrapped line with proper centering
                (wrapped-lines (split-string wrapped "\n")))
           (mapconcat
	    (lambda (wline)
	      (let ((padding (max 0 (/ (- width (string-width wline)) 2))))
                (concat (make-string padding ?\s) wline)))
	    wrapped-lines
	    "\n")))))
     lines
     "\n")))

(defun gnosis-format-string (str)
  "Format STR for display, optionally centering based on buffer preference.

When `gnosis-center-content' is non-nil, centers the text.
Otherwise, just processes org-links without centering."
  (setq str (gnosis-image-format-string str))
  (if gnosis-center-content
      (gnosis-center-string str)
    (replace-regexp-in-string
     "\\[\\[\\([^]]+\\)\\]\\[\\([^]]+\\)\\]\\]"
     "\\2"
     str)))

(defun gnosis-apply-center-buffer-overlay (&optional point)
  "Center text in buffer starting at POINT using `gnosis-center-current-line'.
This will not be applied to sentences that start with double space.

Respects `gnosis-center-content' buffer-local setting."
  (when gnosis-center-content
    (save-excursion
      (goto-char (or point (point-min)))
      (while (not (or (= (point-max) (point)) (looking-at "^  ")))
        (gnosis-center-current-line)
        (forward-line 1)))))

(defun gnosis-org-format-string (str)
  "Return STR fontified as in `org-mode'.
When `gnosis-latex-preview' is non-nil, render LaTeX fragments as
images using `org-format-latex'."
  (with-temp-buffer
    (org-mode)
    (org-toggle-pretty-entities)
    (insert str)
    (font-lock-ensure)
    (when gnosis-latex-preview
      (condition-case err
          (progn
            (goto-char (point-min))
            (org-format-latex "ltximg/org-ltximg"
                              (point-min) (point-max) temporary-file-directory
                              'overlays nil 'forbuffer
                              org-preview-latex-default-process)
            ;; Convert overlays to text properties so they
            ;; survive buffer-string
            (dolist (ov (overlays-in (point-min) (point-max)))
              (when-let* ((display (overlay-get ov 'display)))
                (put-text-property (overlay-start ov) (overlay-end ov)
                                   'display display)
                (when (memq (car-safe display) '(image space))
                  (put-text-property (overlay-start ov) (overlay-end ov)
                                     'gnosis-display-layout 'independent))
                (delete-overlay ov))))
        (error (message "LaTeX preview: %s" (error-message-string err)))))
    (gnosis-image-format-string (buffer-string))))

(defun gnosis-cloze-create (str clozes &optional cloze-string)
  "Render STR as Org and replace CLOZES with CLOZE-STRING.
Preserve whitespace patterns and replace each cloze's preferred occurrence.
CLOZE-STRING defaults to `gnosis-cloze-string'.  Fontification and optional
LaTeX preview run once, before substitution, as in `gnosis-org-format-string'."
  (cl-assert (listp clozes) nil "Adding clozes: Clozes need to be a list.")
  (let ((cloze-string (or cloze-string gnosis-cloze-string))
        ;; Match the original temporary buffer's default search context,
        ;; rather than inheriting the calling mode's local search settings.
        (case-fold (default-value 'case-fold-search)))
    (gnosis-cloze--replace (gnosis-org-format-string str)
                          clozes cloze-string case-fold)))

(cl-defun gnosis--prompt (prompt &optional (downcase nil) (split nil))
  "PROMPT user for input until `q' is given.

The user is prompted to provide input for the PROMPT message.
Returns the list of non-q inputs in reverse order of their entry.

Set DOWNCASE to t to downcase all input given.
Set SPLIT to t to split all input given."
  (cl-loop with input = nil
           for response = (read-string (concat prompt " (q for quit): "))
	   do (if downcase (setf response (downcase response)))
           for response-parts = (if split
                                    (split-string response " ")
                                  (list response))
           if (member "q" response-parts) return (nreverse input)
           do (cl-loop for part in response-parts
	               unless (string-empty-p part)
                       do (push part input))))


(cl-defun gnosis-toggle-suspend-themata
    (ids &optional suspend-value verification validate)
  "Suspend or unsuspend themata IDS.

When SUSPEND-VALUE is nil and IDS has one element, toggle that thema's
current value.  When SUSPEND-VALUE is 0 or 1, set all IDS to that value
explicitly (safe for bulk operations).

When VERIFICATION is non-nil, skip `y-or-n-p' prompt.
Optional VALIDATE checks caller ownership before and after confirmation."
  (cl-assert (listp ids) nil "IDS value needs to be a list.")
  (cl-assert (or (null suspend-value)
                 (memq suspend-value '(0 1)))
             nil "SUSPEND-VALUE must be nil, 0, or 1.")
  (when validate (funcall validate))
  (let* ((items-num (length ids))
         (suspend-value
          (or suspend-value
              (if (= items-num 1)
                  (if (= (gnosis-get 'suspended 'scheduler-state
                                     `(= thema-id ,(car ids)))
                         1)
                      0 1)
                1)))
         (action (if (= suspend-value 1) "Suspend" "Unsuspend"))
         (verification
          (or verification
              (if (= items-num 1)
                  (y-or-n-p (format "%s thema? " action))
                (y-or-n-p (format "%s %d themata? " action items-num))))))
    (when verification
      (when validate (funcall validate))
      (let ((db (gnosis--ensure-db)))
        (gnosis-sqlite-with-transaction db
          (gnosis-sqlite-execute-batch
           db "UPDATE scheduler_state SET suspended = ?
                WHERE thema_id IN (%s)" ids (list suspend-value)))))))

(defun gnosis-mcq-answer (id)
  "Choose the correct answer, from mcq choices for question ID."
  (let ((choices (gnosis-get 'hypothesis 'themata `(= id ,id)))
	(history-add-new-input nil)) ;; Disable history
    (gnosis-completing-read "Answer: " choices)))

(defun gnosis-compare-strings (str1 str2)
  "Compare STR1 and STR2 with the configured typo tolerance.
Ignore quote wrappers, case and whitespace, preserving short-string rules."
  (gnosis-answer-match-p str1 str2 nil gnosis-string-difference))

(defun gnosis--read-string-with-input-method (prompt answer)
  "Read string with PROMPT, activating input method matching ANSWER's script.
Activates the input method in the current buffer so `read-string' with
INHERIT-INPUT-METHOD propagates it into the minibuffer.  Restore the
original buffer's previous input method on return, error or quit."
  (let ((method (alist-get (gnosis-utils-detect-script answer)
                           gnosis-script-input-method-alist))
        (buffer (current-buffer))
        (previous-method current-input-method))
    (if (not method)
        (read-string prompt)
      (unwind-protect
          (progn
            (activate-input-method method)
            (read-string prompt nil nil nil t))
        (when (buffer-live-p buffer)
          (with-current-buffer buffer
            (activate-input-method previous-method)))))))

(defun gnosis-suspended-p (id)
  "Return t if thema with ID is suspended."
  (= (gnosis-get 'suspended 'scheduler-state `(= thema-id ,id)) 1))

(cl-defun gnosis-collect-thema-ids (&key tags due query)
  "Return list of thema IDs filtered by TAGS, DUE, QUERY.

TAGS: cons (INCLUDE-TAGS . EXCLUDE-TAGS) as returned by
      `gnosis-tags-filter-prompt', or nil for no tag filtering.
DUE: non-nil to keep only due themata.
QUERY: search string."
  (let ((ids (cond (query (gnosis-search-thema query))
		   (tags  (gnosis-filter-by-tags (car tags) (cdr tags)))
		   (t     (gnosis-select 'id 'themata nil t)))))
    (if due
	(seq-intersection ids (gnosis-review-get-due-themata))
      ids)))


(defun gnosis-get-themata-by-reviews (max-reviews &optional thema-ids)
  "Return thema IDs with at most MAX-REVIEWS total reviews.
When THEMA-IDS is non-nil, restrict to that subset."
  (gnosis-select 'thema-id 'scheduler-state
                 (if thema-ids
                     `(and (<= reps ,max-reviews)
                           (in thema-id ,(vconcat thema-ids)))
                   `(<= reps ,max-reviews))
                 t))


(defun gnosis--validate-accepted-aliases (type answer aliases)
  "Validate ALIASES for TYPE and canonical ANSWER before a content write."
  (gnosis-answer-validate-aliases aliases)
  (when aliases
    (unless (gnosis-answer-aliases-eligible-p type answer)
      (user-error "Accepted aliases require one canonical typed answer")))
  aliases)

(defun gnosis--validate-agent-eval-fields (type keimenon hypothesis answer rubric)
  "Validate TYPE, KEIMENON, HYPOTHESIS, ANSWER and independent RUBRIC.
Agent-eval requires a nonempty question, one nonempty reference string,
optional string hints and a nonempty rubric.  Other types require nil rubric."
  (if (equal (downcase type) "agent-eval")
      (progn
        (unless (and (stringp keimenon)
                     (not (string-empty-p (string-trim keimenon))))
          (user-error "Agent-eval requires a nonempty question"))
        (unless (and (proper-list-p answer) (= (length answer) 1)
                     (stringp (car answer))
                     (not (string-empty-p (string-trim (car answer)))))
          (user-error "Agent-eval requires one nonempty reference answer"))
        (unless (and (proper-list-p hypothesis) (seq-every-p #'stringp hypothesis))
          (user-error "Agent-eval hints must be a list of strings"))
        (unless (and (stringp rubric) (not (string-empty-p (string-trim rubric))))
          (user-error "Agent-eval requires a nonempty rubric")))
    (when rubric (user-error "Rubric is only supported for agent-eval themata")))
  rubric)

(defun gnosis-add-thema-fields (type keimenon hypothesis answer
				     parathema tags suspend links
				     &optional review-image gnosis-id accepted-aliases rubric)
  "Insert fields for new thema.

TYPE: Thema type e.g \"mcq\"
KEIMENON: Thema's keimenon
HYPOTHESIS: Thema hypothesis, e.g choices for mcq for OR hints for
cloze/basic thema
ANSWER: Correct answer for thema, for MCQ is an integer while for
cloze/basic a string/list of the right answer(s)
PARATHEMA: Parathema information to display after the answer
TAGS: Tags to organize themata
SUSPEND: Integer value of 1 or 0, where 1 suspends the card.
LINKS: List of id links, stored as unique associations.
REVIEW-IMAGE is optional image data and GNOSIS-ID is an optional ID.
ACCEPTED-ALIASES is an optional list of explicitly accepted typed spellings.
RUBRIC is the independent nonempty grading guidance for agent-eval themata.
Return the inserted integer ID."
  (cl-assert (stringp type) nil "Type must be a string")
  (gnosis--validate-accepted-aliases type answer accepted-aliases)
  (gnosis--validate-agent-eval-fields type keimenon hypothesis answer rubric)
  (gnosis-image-validate-fields type keimenon hypothesis answer parathema review-image)
  (when (equal (downcase type) "model")
    (gnosis-model-resolve hypothesis answer))
  (when (equal (downcase type) "model-name")
    (gnosis-model-fields type hypothesis answer))
  (cl-assert (stringp keimenon) nil "Keimenon must be a string")
  (cl-assert (listp hypothesis) nil "Hypothesis value must be a list")
  (cl-assert (listp answer) nil "Answer value must be a list")
  (cl-assert (stringp parathema) nil "Parathema must be a string")
  (cl-assert (listp tags) nil "Tags must be a list")
  (cl-assert (listp links) nil "Links must be a list")
  (let* ((gnosis-id (or gnosis-id (gnosis-generate-id)))
	 (review-image (or review-image ""))
         (today (gnosis--today-int)))
    (gnosis-sqlite-with-transaction (gnosis--ensure-db)
      ;; Name owned columns so retained archive metadata keeps its default.
      ;; Store an absent hint as the readable empty list under NOT NULL.
      (gnosis-sqlite-execute
       (gnosis--ensure-db)
       "INSERT INTO themata (id, type, keimenon, hypothesis, answer, source_guid, accepted_aliases, rubric)
        VALUES (?, ?, ?, COALESCE(?, 'nil'), ?, NULL, ?, ?)"
       (list gnosis-id (downcase type) keimenon hypothesis answer accepted-aliases rubric))
      (gnosis-scheduler-initialize-thema gnosis-id today suspend)
      (gnosis--insert-into 'extras `([,gnosis-id ,parathema ,review-image]))
      (cl-loop for link in (seq-uniq links)
	       do (gnosis--insert-into 'thema-links `([,gnosis-id ,link])))
      (cl-loop for tag in tags
	       do (gnosis--insert-into 'thema-tag `([,gnosis-id ,tag]))))
    gnosis-id))

(cl-defun gnosis-update-thema (id keimenon hypothesis answer parathema tags links
			       &optional type (accepted-aliases nil aliases-p)
                               (rubric nil rubric-p))
  "Update thema ID with KEIMENON, HYPOTHESIS, ANSWER, and PARATHEMA.
TAGS and LINKS replace existing associations; repeated LINKS are stored once.
TYPE optionally changes type.
Omitted ACCEPTED-ALIASES preserves stored aliases; explicit nil clears them.
Omitted RUBRIC preserves it; explicit nil clears it for non-agent types.

If ID does not exist, TYPE is required to create it anew and issue a warning.
Return the saved integer ID."
  (let* ((id (if (stringp id) (string-to-number id) id))
	 (current-type (gnosis-get 'type 'themata `(= id ,id)))
         (accepted-aliases (if aliases-p accepted-aliases
                             (gnosis-get 'accepted-aliases 'themata `(= id ,id))))
         (rubric (if rubric-p rubric (gnosis-get 'rubric 'themata `(= id ,id)))))
    (gnosis--validate-accepted-aliases (or type current-type "") answer accepted-aliases)
    (gnosis--validate-agent-eval-fields
     (or type current-type "") keimenon hypothesis answer rubric)
    (gnosis-image-validate-fields (or type current-type "") keimenon hypothesis answer parathema)
    (when (equal (downcase (or type current-type "")) "model")
      (gnosis-model-resolve hypothesis answer))
    (when (equal (downcase (or type current-type "")) "model-name")
      (gnosis-model-fields (or type current-type) hypothesis answer))
    (if (gnosis-get 'id 'themata `(= id ,id))
	(gnosis-sqlite-with-transaction (gnosis--ensure-db)
	  ;; Single multi-column UPDATE for themata
	  (gnosis-sqlite-execute (gnosis--ensure-db)
				 "UPDATE themata SET keimenon = ?, hypothesis = COALESCE(?, 'nil'), answer = ?, type = ?, accepted_aliases = ?, rubric = ? WHERE id = ?"
				 (list keimenon hypothesis answer
				       (or type current-type) accepted-aliases rubric id))
	  ;; Imports may omit extras; update only Parathema on an existing row.
          (gnosis-sqlite-execute
           (gnosis--ensure-db)
           "INSERT INTO extras (id, parathema) VALUES (?, ?)
            ON CONFLICT(id) DO UPDATE SET parathema = excluded.parathema"
           (list id parathema))
	  ;; Re-sync links
	  (gnosis--delete 'thema-links `(= source ,id))
	  (cl-loop for link in (seq-uniq links)
		   do (gnosis--insert-into 'thema-links `([,id ,link])))
	  ;; Re-sync tags
	  (gnosis--delete 'thema-tag `(= thema-id ,id))
	  (cl-loop for tag in tags
		   do (gnosis--insert-into 'thema-tag `([,id ,tag]))))
      (display-warning 'gnosis
		       (format "Thema id:%d does not exist, creating anew" id)
		       :warning)
      (gnosis-add-thema-fields type keimenon hypothesis answer parathema tags
			       0 links nil id accepted-aliases rubric))
    id))

;;;;;;;;;;;;;;;;;;;;;; THEMA HELPERS ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; These functions provide assertions depending on the type of thema.
;;
;; Each thema should use a helper function that calls to provide
;; assertions, such as length of hypothesis and answer, for said
;; thema.
;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

(defun gnosis-add-thema--assert-common (keimenon tags suspend links)
  "Assert common fields shared by all thema types.
KEIMENON, TAGS, SUSPEND, and LINKS are validated."
  (cl-assert (stringp keimenon) nil "Keimenon must be a string.")
  (cl-assert (and (listp tags) (cl-every #'stringp tags))
             nil "Tags must be a list of strings.")
  (cl-assert (memq suspend '(0 1)) nil
             "Suspend value must be 0 or 1.")
  (cl-assert (and (listp links) (cl-every #'stringp links))
             nil "Links must be a list of strings."))

(cl-defun gnosis-add-thema--dispatch (id type keimenon hypothesis
				      answer parathema tags suspend links
                                      &optional (accepted-aliases nil aliases-p)
                                      (rubric nil rubric-p))
  "Dispatch creation or update for thema ID of TYPE.
KEIMENON, HYPOTHESIS, ANSWER, PARATHEMA, TAGS, SUSPEND, and LINKS are fields.
When ID is \"NEW\", create via `gnosis-add-thema-fields'.
Otherwise, update via `gnosis-update-thema'.
Omitted ACCEPTED-ALIASES or RUBRIC preserves the corresponding stored field;
explicit nil clears it, subject to type validation."
  (if (equal id "NEW")
      (gnosis-add-thema-fields type keimenon (or hypothesis (list ""))
			       answer parathema tags suspend links nil nil accepted-aliases rubric)
    (apply #'gnosis-update-thema id keimenon hypothesis answer
           parathema tags links type
           (cond (rubric-p (list accepted-aliases rubric))
                 (aliases-p (list accepted-aliases))))))

(cl-defun gnosis-add-thema--agent-eval
    (id type keimenon hypothesis answer parathema tags suspend links
        &optional (accepted-aliases nil aliases-p) (rubric nil rubric-p))
  "Add or update agent-eval thema ID of TYPE.
Use KEIMENON, HYPOTHESIS, ANSWER, PARATHEMA, TAGS, SUSPEND and LINKS as fields.
ACCEPTED-ALIASES must be nil.  Omitted RUBRIC preserves it on update."
  (gnosis-add-thema--assert-common keimenon tags suspend links)
  (apply #'gnosis-add-thema--dispatch id type keimenon hypothesis
         answer parathema tags suspend links
         (cond (rubric-p (list accepted-aliases rubric))
               (aliases-p (list accepted-aliases)))))

(cl-defun gnosis-add-thema--basic (id type keimenon hypothesis
				   answer parathema tags suspend links
                                   &optional (accepted-aliases nil aliases-p))
  "Add or update basic thema ID of TYPE.
Use KEIMENON, HYPOTHESIS, ANSWER, PARATHEMA, TAGS, SUSPEND, and LINKS as fields.
ACCEPTED-ALIASES explicitly replaces aliases when supplied."
  (gnosis-add-thema--assert-common keimenon tags suspend links)
  (cl-assert (or (null hypothesis)
		 (and (listp hypothesis) (= (length hypothesis) 1)))
	     nil "Hypothesis must be a list of a single item or nil.")
  (cl-assert (and (listp answer) (= (length answer) 1))
	     nil "Answer must be a list of a single item.")
  (apply #'gnosis-add-thema--dispatch id type keimenon hypothesis
         answer parathema tags suspend links (when aliases-p (list accepted-aliases))))

(cl-defun gnosis-add-thema--double (id _type keimenon hypothesis
				    answer parathema tags suspend links
                                    &optional (accepted-aliases nil aliases-p))
  "Add or update double thema ID, ignoring _TYPE.
Use KEIMENON, HYPOTHESIS, ANSWER, PARATHEMA, TAGS, SUSPEND, and LINKS as fields.
When ID is \"NEW\", create two basic themata with reversed question and answer;
otherwise update the existing thema.
ACCEPTED-ALIASES applies only to the forward answer when supplied."
  (gnosis-add-thema--assert-common keimenon tags suspend links)
  (cl-assert (listp hypothesis) nil "Hypothesis must be a list.")
  (cl-assert (and (listp answer) (= (length answer) 1))
	     nil "Answer must be a list of a single item.")
  (let ((type "basic")
	(hypothesis (or hypothesis (list ""))))
    (if (equal id "NEW")
	(list
	  (gnosis-add-thema-fields type keimenon hypothesis
				   answer parathema tags suspend links nil nil accepted-aliases)
	  (gnosis-add-thema-fields type (car answer) hypothesis
				   (list keimenon) parathema tags suspend links))
      (apply #'gnosis-update-thema id keimenon hypothesis answer
             parathema tags links type (when aliases-p (list accepted-aliases))))))

(cl-defun gnosis-add-thema--mcq (id type keimenon hypothesis
				 answer parathema tags suspend links
                                 &optional (accepted-aliases nil aliases-p))
  "Add or update MCQ thema ID of TYPE.
Use KEIMENON, HYPOTHESIS, ANSWER, PARATHEMA, TAGS, SUSPEND, and LINKS as fields.
ACCEPTED-ALIASES must be nil for choice-based responses."
  (gnosis-add-thema--assert-common keimenon tags suspend links)
  (cl-assert (string= type "mcq") nil "TYPE must be \"mcq\".")
  (cl-assert (and (listp hypothesis) (> (length hypothesis) 1))
	     nil "Hypothesis must be a list of more than 1 item.")
  (cl-assert (and (listp answer) (= (length answer) 1)
		  (member (car answer) hypothesis))
	     nil "Answer must be a single item, member of hypothesis.")
  (apply #'gnosis-add-thema--dispatch id type keimenon hypothesis
         answer parathema tags suspend links (when aliases-p (list accepted-aliases))))

(cl-defun gnosis-add-thema--cloze (id type keimenon hypothesis
				   answer parathema tags suspend links
                                   &optional (accepted-aliases nil aliases-p))
  "Add or update cloze thema ID of TYPE.
Use KEIMENON, HYPOTHESIS, ANSWER, PARATHEMA, TAGS, SUSPEND, and LINKS as fields.
ACCEPTED-ALIASES must be nil: cloze answers are separate required blanks."
  (gnosis-add-thema--assert-common keimenon tags suspend links)
  (cl-assert (string= type "cloze") nil "TYPE must be \"cloze\".")
  (gnosis--validate-accepted-aliases type answer accepted-aliases)
  (cl-assert (or (null hypothesis) (>= (length answer) (length hypothesis)))
	     nil "Hypothesis length must not exceed answer length.")
  (cl-assert (listp answer) nil "Answer must be a list.")
  (let ((keimenon-clean (gnosis-cloze-remove-tags keimenon)))
    (cl-assert (gnosis-cloze-check keimenon-clean answer) nil
               "Cloze answers require disjoint occurrences in keimenon.")
    (if (equal id "NEW")
	(if (null answer)
	    (let* ((contents (gnosis-cloze-extract-contents keimenon))
		   (clozes (gnosis-cloze-extract-answers contents))
		   (hints (gnosis-cloze-extract-hints contents)))
              (unless clozes
                (user-error "Cloze requires an answer or at least one inline blank"))
	      (cl-loop for cloze in clozes
		       for hint in hints
                       do (cl-assert (gnosis-cloze-check keimenon-clean cloze) nil
                                     "Cloze answers require disjoint occurrences in keimenon.")
                       collect (gnosis-add-thema-fields type keimenon-clean hint cloze
						   parathema tags suspend links)))
	  (gnosis-add-thema-fields type keimenon-clean (or hypothesis (list ""))
				   answer parathema tags suspend links))
      (apply #'gnosis-update-thema id keimenon-clean hypothesis
             answer parathema tags links type (when aliases-p (list accepted-aliases))))))

(cl-defun gnosis-add-thema--mc-cloze (id type keimenon hypothesis
				      answer parathema tags suspend links
                                      &optional (accepted-aliases nil aliases-p))
  "Add or update mc-cloze thema ID of TYPE.
Use KEIMENON, HYPOTHESIS, ANSWER, PARATHEMA, TAGS, SUSPEND, and LINKS as fields.
ACCEPTED-ALIASES must be nil for choice-based responses."
  (gnosis-add-thema--assert-common keimenon tags suspend links)
  (cl-assert (string= type "mc-cloze") nil "TYPE must be \"mc-cloze\".")
  (cl-assert (and (listp hypothesis) (> (length hypothesis) (length answer)))
	     nil "Hypothesis must be a list, longer than answer.")
  (cl-assert (and (listp answer) (length= answer 1)
		  (member (car answer) hypothesis))
	     nil "Answer must be a list of one item, member of hypothesis.")
  (let ((keimenon-clean (gnosis-cloze-remove-tags keimenon)))
    (cl-assert (gnosis-cloze-check keimenon-clean answer) nil
               "Cloze answers require disjoint occurrences in keimenon.")
    (apply #'gnosis-add-thema--dispatch id type keimenon-clean hypothesis
           answer parathema tags suspend links (when aliases-p (list accepted-aliases)))))

;;;###autoload
(defun gnosis-add-model-name-thema ()
  "Create a typed-name thema for a visibly highlighted model target."
  (interactive)
  (gnosis-add-model-thema "model-name"))

(defvar-local gnosis--draft-db nil
  "Database connection that owns the current native draft.")

(defvar-local gnosis--draft-original nil
  "Original edit content as (ID . SNAPSHOT), or nil for a creation draft.")

(defvar-local gnosis--draft-saved-p nil
  "Non-nil after this draft occurrence committed successfully.
Retain this disposition if native buffer teardown is vetoed or interrupted.")

(defvar-local gnosis--draft-save-receipt nil
  "Optional one-cell receipt owned by this native edit occurrence.
A successful save fills its car with (DATABASE ID CONTENT), before closing
or running user hooks.  CONTENT holds the saved response and extras rows;
review can acknowledge this write without replacing the answered content.")

(defun gnosis--draft-content (db id)
  "Return the retained content of thema ID on DB, excluding study state."
  (mapcar (lambda (sql) (sqlite-select db sql (list id)))
          '("SELECT type, keimenon, hypothesis, answer, accepted_aliases, rubric
               FROM themata WHERE id = ?"
            "SELECT parathema, review_image FROM extras WHERE id = ?"
            "SELECT tag FROM thema_tag WHERE thema_id = ? ORDER BY tag"
            "SELECT dest FROM thema_links WHERE source = ? ORDER BY dest")))

(defun gnosis--draft-check-owner ()
  "Refuse a saved draft or one without its original live connection."
  (when gnosis--draft-saved-p
    (user-error "Draft already saved; copy its text or cancel to close it"))
  (unless (and gnosis--draft-db (eq gnosis-db gnosis--draft-db)
               (condition-case nil
                   (sqlite-select gnosis--draft-db "SELECT 1")
                 (error nil)))
    (user-error
     (concat "Draft database closed or changed; copy your draft text, "
             "cancel, then reopen it in the intended database and reconcile"))))

(defun gnosis--draft-validate (themata)
  "Validate parsed THEMATA against the draft owner and original content.
Call inside the save transaction, before any thema writes."
  (gnosis--draft-check-owner)
  (when (and gnosis--draft-original
             (not (equal (cdr gnosis--draft-original)
                         (gnosis--draft-content
                          gnosis--draft-db (car gnosis--draft-original)))))
    (user-error
     (concat "Thema changed or was deleted; copy your draft text, cancel, "
             "then reopen the current thema and reconcile your edits")))
  (unless (cl-every (lambda (thema)
                      (or (equal (car thema) "NEW")
                          (and gnosis--draft-original
                               (equal (car thema)
                                      (number-to-string
                                       (car gnosis--draft-original))))))
                    themata)
    (user-error
     "Draft target changed; copy your text and reopen the intended thema")))

;;;###autoload
(cl-defun gnosis-add-thema (type &optional keimenon hypothesis
			      answer parathema tags example
                              (accepted-aliases nil aliases-p) rubric)
  "Add thema with TYPE and optional KEIMENON, HYPOTHESIS, and fields.
The remaining optional fields are ANSWER, PARATHEMA, TAGS, EXAMPLE,
explicit ACCEPTED-ALIASES, and independent agent-eval RUBRIC.
Refuse TAGS that native Org cannot represent, before opening a draft."
  (interactive (list
		(downcase (completing-read "Select type: " gnosis-thema-types))))
  (if (and (member (downcase type) '("model" "model-name" "image-region" "image-occlusion"))
           (null hypothesis))
      (pcase (downcase type)
        ("model" (gnosis-add-model-thema))
        ("model-name" (gnosis-add-model-name-thema))
        (image-type (gnosis-add-image-thema image-type)))
    (when (get-buffer "*Gnosis NEW*")
      (user-error "Finish or cancel the existing *Gnosis NEW* draft first"))
    (gnosis-tags--check-org tags)
    (let ((owner (gnosis--ensure-db)))
      (window-configuration-to-register :gnosis-edit)
      (pop-to-buffer "*Gnosis NEW*")
      (with-current-buffer "*Gnosis NEW*"
        (let ((inhibit-read-only 1))
          (erase-buffer))
        (gnosis-edit-mode)
        (setq gnosis--draft-db owner)
        (gnosis-export--insert-thema "NEW" type keimenon hypothesis
                                     answer parathema tags example
                                     (and aliases-p accepted-aliases) rubric))
      (when (member (downcase type) '("model" "model-name"))
        (use-local-map (copy-keymap (current-local-map)))
        (local-set-key (kbd "C-c C-a") #'gnosis-model-attach))
      (search-backward "keimenon")
      (forward-line))))

(defun gnosis--source-thema-round-trip-p (answer parathema)
  "Return non-nil if ANSWER and PARATHEMA survive the thema Org codec.
Allow only outer whitespace trimming in ANSWER.  Require exactly one
basic thema, with no injected fields and an unchanged PARATHEMA."
  (condition-case nil
      (with-temp-buffer
        (delay-mode-hooks (org-mode))
        (gnosis-export--insert-thema "NEW" "basic" nil nil answer parathema)
        (let ((themata (gnosis-export-parse-themata)))
          (and (= (length themata) 1)
               (equal (butlast (car themata))
                      (list "NEW" "basic" nil nil
                            (when answer (list (string-trim answer)))
                            parathema nil)))))
    (error nil)))

;;;###autoload
(defun gnosis-add-thema-from-node ()
  "Compose a basic thema linked to the Org node at point.
Use the nearest enclosing ID, including a file-level ID.  Prefill Answer
with the active region, if any, and leave Keimenon empty.  Put the source
link in Parathema, which is shown only after answering.

Accept copied text only if the Org codec preserves one Answer and the
source link, apart from trimming outer answer whitespace.  Reject lossy
selections such as separator lines, headings, or a leading list marker before
opening the editor.  Select a plain passage instead, or author structured
content manually in the editor's supported fields.

Open the ordinary thema editor beside the source.  Save with
`gnosis-save' or cancel with `gnosis-edit-quit'.  Do not create an ID,
modify or save the source, or replace an existing creation draft."
  (interactive)
  (unless (derived-mode-p 'org-mode)
    (user-error "Create a thema from an Org buffer with a source ID"))
  (let ((id (save-restriction
              (widen)
              (gnosis-org-get-id)))
        (answer (when (use-region-p)
                  (buffer-substring-no-properties
                   (region-beginning) (region-end))))
        (display-buffer-overriding-action
         '((display-buffer-below-selected) (inhibit-same-window . t))))
    (unless (and id (not (string-empty-p id)))
      (user-error "No source ID at point or in an enclosing Org node"))
    (let ((parathema (org-link-make-string (concat "id:" id) "Source")))
      (unless (gnosis--source-thema-round-trip-p answer parathema)
        (user-error
         (concat "Source passage cannot be copied without changing its content; "
                 "select a plain passage or author structured content manually "
                 "in the editor's supported fields")))
      (gnosis-add-thema "basic" nil nil answer parathema))))

(defun gnosis-edit-thema (id)
  "Edit thema with ID without replacing an unfinished edit.
Refuse stored tags that native Org cannot represent without changing them.
Explicitly rename or remove those tags through the tag commands first.
Never reuse an existing buffer named *Gnosis Edit*, even if unmodified."
  (when (get-buffer "*Gnosis Edit*")
    (user-error "Finish or rename the existing *Gnosis Edit* buffer first"))
  (let* ((owner (gnosis--ensure-db))
         (original (gnosis--draft-content owner id)))
    (unless (car original)
      (user-error "Thema no longer exists; reopen the collection"))
    (gnosis-tags--check-org (gnosis-get-tags-for-ids (list id)))
    (window-configuration-to-register :gnosis-edit)
    (let ((buffer (generate-new-buffer "*Gnosis Edit*")))
      (with-current-buffer buffer
        (gnosis-edit-mode)
        (unless (and (eq major-mode 'gnosis-edit-mode)
                     (not buffer-file-name) (zerop (buffer-size)))
          (user-error "Editor changed during setup; preserve it and reopen the thema"))
        (setq gnosis--draft-db owner
              gnosis--draft-original (cons id original))
        (gnosis-export--insert-themata (list id))
        (when (member (gnosis-get 'type 'themata `(= id ,id)) '("model" "model-name"))
          (use-local-map (copy-keymap (current-local-map)))
          (local-set-key (kbd "C-c C-a") #'gnosis-model-attach))
        (search-backward "keimenon")
        (forward-line))
      (pop-to-buffer buffer))))

(defun gnosis-edit-quit ()
  "Quit recrusive edit & kill current buffer."
  (interactive nil gnosis-edit-mode)
  (kill-buffer)
  (jump-to-register :gnosis-edit)
  (when gnosis-review-editing-p
    (setf gnosis-review-editing-p nil)
    (exit-recursive-edit)))

(autoload 'gnosis-lecture-attach "gnosis-lecture" nil t)
(autoload 'gnosis-lecture-cancel "gnosis-lecture" nil t)

(defvar-keymap gnosis-edit-mode-map
  :doc "gnosis org mode map"
  "C-c C-c" #'gnosis-save
  "C-c C-a" #'gnosis-image-attach
  "C-c C-l" #'gnosis-lecture-attach
  "C-c C-x" #'gnosis-lecture-cancel
  "C-c C-q" #'gnosis-tags-prompt
  "C-c C-o" #'gnosis-nodes-goto-id
  "C-c C-k" #'gnosis-edit-quit)

(define-derived-mode gnosis-edit-mode org-mode "Gnosis Org"
  "Gnosis Org Mode."
  :interactive nil
  :lighter " Gnosis Edit"
  :keymap gnosis-edit-mode-map
  (setq header-line-format
	(substitute-command-keys
	 " Save thema by running \\[gnosis-save] or \\[gnosis-edit-quit] to quit")))

(defun gnosis-get-date-total-themata (&optional date)
  "Return total themata reviewed for DATE (YYYYMMDD integer).
Defaults to current date."
  (nth 1 (gnosis-review-activity (or date (gnosis--today-int)))))

(defun gnosis-get-date-new-themata (&optional date)
  "Return new themata reviewed for DATE (YYYYMMDD integer).

Defaults to current date."
  (nth 2 (gnosis-review-activity (or date (gnosis--today-int)))))
(defun gnosis-search-thema (&optional query)
  "Search for thema QUERY.

Return thema ids for themata that match QUERY."
  (cl-assert (or (stringp query) (eq query nil)))
  (let* ((query (or query (read-string "Search for thema: ")))
         (words (split-string query))
         (clause-keimenon `(and ,@(mapcar (lambda (word)
					    `(like keimenon ,(format "%%%s%%" word)))
					  words)))
	 (clause-answer `(and ,@(mapcar (lambda (word)
					  `(like answer ,(format "%%%s%%" word)))
					words))))
    (append (gnosis-select 'id 'themata clause-keimenon t)
	    (gnosis-select 'id 'themata clause-answer t))))

;;;###autoload
(defun gnosis ()
  "Open the Gnosis dashboard."
  (interactive)
  (gnosis-dashboard))

;; Gnosis mode ;;
;;;;;;;;;;;;;;;;;

(defconst gnosis--modeline-entry
  '(:eval
    (if (and gnosis-due-themata-total (> gnosis-due-themata-total 0))
        (propertize (format " [%d] " gnosis-due-themata-total)
                    'face 'warning 'gnosis-modeline t)
      ""))
  "Owned mode-line form, independent of its current rendered text.")

;;;###autoload
(define-minor-mode gnosis-modeline-mode
  "Minor mode for showing gnosis total due themata on modeline."
  :global t
  :group 'gnosis
  :lighter nil
  (when gnosis-modeline-mode
    (setq gnosis-due-themata-total (length (gnosis-review-get-due-themata)))
    ;; The query or a variable watcher may have disabled the mode.
    (when gnosis-modeline-mode
      (add-to-list 'global-mode-string gnosis--modeline-entry)))
  ;; Publication watchers run before assignment and may disable the mode.
  (unless gnosis-modeline-mode
    (setq global-mode-string (remove gnosis--modeline-entry global-mode-string)))
  (force-mode-line-update))

(defvar gnosis--mode-setup-function nil
  "Optional caller initializer for `gnosis-mode'.
Called after the parent mode resets local variables, before minor-mode
hooks can run.  Return a function that checks the caller's ownership;
it is called after each callback-capable initialization operation.
Bind only around the intended mode invocation; nested modes do not inherit it.")

(define-derived-mode gnosis-mode special-mode "Gnosis"
  "Gnosis Mode."
  :interactive nil
  (let* ((setup gnosis--mode-setup-function)
         (gnosis--mode-setup-function nil)
         (validate (and setup (funcall setup))))
    (read-only-mode 0)
    (when validate (funcall validate))
    (display-line-numbers-mode 0)
    (when validate (funcall validate))
    ;; Initialize centering only while the caller still owns this mode entry.
    (setq-local gnosis-center-content gnosis-center-content-during-review)))

(provide 'gnosis)
;;; gnosis.el ends here
