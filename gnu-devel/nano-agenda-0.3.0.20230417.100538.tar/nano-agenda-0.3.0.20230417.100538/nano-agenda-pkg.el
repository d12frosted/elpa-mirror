;; Generated package description from nano-agenda.el  -*- no-byte-compile: t -*-
(define-package "nano-agenda" "0.3.0.20230417.100538" "N Λ N O agenda" '((emacs "27.1")) :commit "3d1e280fd94ac1abd630d0c100a860b94472836d" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("convenience" "org-mode" "org-agenda") :url "https://github.com/rougier/nano-agenda")
