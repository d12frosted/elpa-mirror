;; Generated package description from ob-asymptote.el  -*- no-byte-compile: t -*-
(define-package "ob-asymptote" "1.0.2.0.20250511.114502" "Babel Functions for Asymptote" 'nil :commit "339b5bef1434b1833d636c9fea9b95b3e990fe71" :maintainer '("Jarmo Hurri" . "jarmo.hurri@iki.fi") :keywords '("literate programming" "reproducible research") :url "https://github.com/hurrja/ob-asymptote")
