;; Generated package description from load-dir.el  -*- no-byte-compile: t -*-
(define-package "load-dir" "0.0.5.0.20221221.80456" "Load all Emacs Lisp files in a given directory" '((cl-lib "0.5")) :commit "22bcac73d8808a680fd9b261cd89937d8e5c6a3c" :url "https://elpa.gnu.org/packages/load-dir.html" :maintainer '("Teodor Zlatanov" . "tzz@lifelogs.com") :keywords '("lisp" "files" "convenience"))
