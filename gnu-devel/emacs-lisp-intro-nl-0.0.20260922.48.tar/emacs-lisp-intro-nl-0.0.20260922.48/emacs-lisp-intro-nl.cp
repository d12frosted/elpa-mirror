\entry{Lisp geschiedenis}{3}{Lisp geschiedenis}
\entry{Maclisp}{3}{Maclisp}
\entry{Common Lisp}{3}{Common Lisp}
\entry{Lisp lijsten}{1}{Lisp lijsten}
\entry{Bloemen in een veld}{1}{Bloemen in een veld}
\entry{Lisp atomen}{1}{Lisp atomen}
\entry{empty list gedefinieerd}{2}{@samp {empty list} gedefinieerd}
\entry{Symbolische expressies, geïntroduceerd}{2}{Symbolische expressies, geïntroduceerd}
\entry{expressie gedefinieerd}{2}{@samp {expressie} gedefinieerd}
\entry{vorm gedefinieerd}{2}{@samp {vorm} gedefinieerd}
\entry{Tekst tussen dubbele aanhalingstekens}{2}{Tekst tussen dubbele aanhalingstekens}
\entry{string gedefinieerd}{2}{@samp {string} gedefinieerd}
\entry{Witte ruimte in lijsten}{2}{Witte ruimte in lijsten}
\entry{Hulp bij lijsten typen}{3}{Hulp bij lijsten typen}
\entry{Hulp bij formatteren}{3}{Hulp bij formatteren}
\entry{Een programma draaien}{3}{Een programma draaien}
\entry{Draai een programma}{3}{Draai een programma}
\entry{evaluate gedefinieerd}{3}{@samp {evaluate} gedefinieerd}
\entry{quote}{3}{@code {quote}}
\entry{' om te quoten}{3}{@code {'} om te quoten}
\entry{quoten met de apostrof}{3}{quoten met de apostrof}
\entry{apostrof om te quoten}{3}{apostrof om te quoten}
\entry{Lisp interpreter, uitgelegd}{4}{Lisp interpreter, uitgelegd}
\entry{Interpreter, Lisp, uitgelegd}{4}{Interpreter, Lisp, uitgelegd}
\entry{Genereer een foutmelding}{4}{Genereer een foutmelding}
\entry{Foutmelding generatie}{4}{Foutmelding generatie}
\entry{functie gedefinieerd}{5}{@samp {functie} gedefinieerd}
\entry{functie gedefinieerd}{5}{@samp {functie} gedefinieerd}
\entry{Symboolnamen}{6}{Symboolnamen}
\entry{Lisp interpreter, wat die doet}{7}{Lisp interpreter, wat die doet}
\entry{Lisp interpreter, wat die doet}{7}{Lisp interpreter, wat die doet}
\entry{Speciale vorm}{7}{Speciale vorm}
\entry{Byte compiling}{7}{Byte compiling}
\entry{Evaluatie}{8}{Evaluatie}
\entry{teruggegeven waarde uitgelegd}{8}{@samp {teruggegeven waarde} uitgelegd}
\entry{zij-effect gedefinieerd}{8}{@samp {zij-effect} gedefinieerd}
\entry{Binnenste lijst evaluatie}{8}{Binnenste lijst evaluatie}
\entry{Het evalueren van een binnenste lijst}{8}{Het evalueren van een binnenste lijst}
\entry{Variabelen}{9}{Variabelen}
\entry{fill-column, een voorbeeldvariabele}{10}{@code {fill-column@r {, een voorbeeldvariabele}}}
\entry{Voorbeeldvariabele, fill-column}{10}{Voorbeeldvariabele, @code {fill-column}}
\entry{Variabele, voorbeeld van, fill-column}{10}{Variabele, voorbeeld van, @code {fill-column}}
\entry{Symbool zonder functie foutmelding}{10}{Symbool zonder functie foutmelding}
\entry{Fout van symbool zonder functie}{10}{Fout van symbool zonder functie}
\entry{Symbool zonder waarde fout}{11}{Symbool zonder waarde fout}
\entry{Fout voor symbool zonder waarde}{11}{Fout voor symbool zonder waarde}
\entry{Argumenten}{12}{Argumenten}
\entry{Informatie naar functies doorgeven}{12}{Informatie naar functies doorgeven}
\entry{argument gedefinieerd}{12}{@samp {argument} gedefinieerd}
\entry{Data typen}{13}{Data typen}
\entry{Typen van data}{13}{Typen van data}
\entry{Data typen van argumenten}{13}{Data typen van argumenten}
\entry{concat}{13}{@code {concat}}
\entry{substring}{13}{substring}
\entry{Variabel aantal argumenten}{14}{Variabel aantal argumenten}
\entry{Argumenten, variabel aantal}{14}{Argumenten, variabel aantal}
\entry{Verkeerde type argument}{14}{Verkeerde type argument}
\entry{Argument, verkeerde type}{14}{Argument, verkeerde type}
\entry{predicate gedefinieerd}{15}{@samp {predicate} gedefinieerd}
\entry{message}{16}{@code {message}}
\entry{Variabele, waarde zetten}{17}{Variabele, waarde zetten}
\entry{De waarde van een variabele zetten}{17}{De waarde van een variabele zetten}
\entry{bind gedefinieerd}{17}{@samp {bind} gedefinieerd}
\entry{set}{17}{@code {set}}
\entry{Tellen}{18}{Tellen}
\entry{Evaluatie oefenen}{21}{Evaluatie oefenen}
\entry{Evaluatiepraktijk}{21}{Evaluatiepraktijk}
\entry{interactive function gedefinieerd}{21}{@samp {interactive function} gedefinieerd}
\entry{command gedefinieerd}{21}{@samp {command} gedefinieerd}
\entry{buffer-name}{21}{@code {buffer-name}}
\entry{buffer-file-name}{21}{@code {buffer-file-name}}
\entry{nil, geschiedenis van woord}{22}{@code {nil}, geschiedenis van woord}
\entry{Buffer, geschiedenis van woord}{22}{Buffer, geschiedenis van woord}
\entry{current-buffer}{23}{@code {current-buffer}}
\entry{other-buffer}{23}{@code {other-buffer}}
\entry{Een buffer krijgen}{23}{Een buffer krijgen}
\entry{switch-to-buffer}{24}{@code {switch-to-buffer}}
\entry{set-buffer}{24}{@code {set-buffer}}
\entry{Switching to a buffer}{24}{Switching to a buffer}
\entry{aanroepen gedefinieerd}{25}{@samp {aanroepen} gedefinieerd}
\entry{Buffergrootte}{25}{Buffergrootte}
\entry{Buffergrootte}{25}{Buffergrootte}
\entry{Lokatie van point}{25}{Lokatie van point}
\entry{Lokatie van point}{25}{Lokatie van point}
\entry{point gedefinieerd}{25}{@samp {point} gedefinieerd}
\entry{narrowing defined}{26}{@samp {narrowing} defined}
\entry{Definitie schrijven}{27}{Definitie schrijven}
\entry{Functiedefinitie schrijven}{27}{Functiedefinitie schrijven}
\entry{Schrijven van een functiedefinitie}{27}{Schrijven van een functiedefinitie}
\entry{Primitieve functies}{27}{Primitieve functies}
\entry{Functies, primitief}{27}{Functies, primitief}
\entry{C-taal primitieven}{27}{C-taal primitieven}
\entry{Primitieven geschreven in C}{27}{Primitieven geschreven in C}
\entry{defun}{27}{@code {defun}}
\entry{functiedefinitie gedefinieerd}{27}{@samp {functiedefinitie} gedefinieerd}
\entry{body gedefinieerd}{28}{@samp {body} gedefinieerd}
\entry{argumentlijst gedefinieerd}{28}{@samp {argumentlijst} gedefinieerd}
\entry{* (vermenigvuldiging)}{29}{@code {* @r {(vermenigvuldiging)}}}
\entry{Installeer een functiedefinitie}{29}{Installeer een functiedefinitie}
\entry{Definitie installatie}{29}{Definitie installatie}
\entry{functiedefinitie installatie}{29}{functiedefinitie installatie}
\entry{Een functiedefinitie wijzigen}{30}{Een functiedefinitie wijzigen}
\entry{Functiedefinitie, hoe te wijzigen}{30}{Functiedefinitie, hoe te wijzigen}
\entry{Definitie, hoe te wijzigen}{30}{Definitie, hoe te wijzigen}
\entry{Commentaar in Lisp code}{30}{Commentaar in Lisp code}
\entry{Interactieve functies}{30}{Interactieve functies}
\entry{interactive}{30}{@code {interactive}}
\entry{Opties voor interactive}{32}{Opties voor @code {interactive}}
\entry{Interactieve opties}{32}{Interactieve opties}
\entry{Code permanent installeren}{33}{Code permanent installeren}
\entry{Permanente code installatie}{33}{Permanente code installatie}
\entry{Code installtie}{33}{Code installtie}
\entry{let}{34}{@code {let}}
\entry{lokale variabele gedefinieerd}{34}{@samp {lokale variabele} gedefinieerd}
\entry{variabele, lokaal, gedefinieerd}{34}{@samp {variabele, lokaal}, gedefinieerd}
\entry{let expressie, delen van}{35}{@code {let} expressie, delen van}
\entry{Delen van een let expressie}{35}{Delen van een let expressie}
\entry{varlist gedefinieerd}{35}{@samp {varlist} gedefinieerd}
\entry{Voorbeeld let expressie}{36}{Voorbeeld @code {let} expressie}
\entry{let expressie voorbeeld}{36}{@code {let} expressie voorbeeld}
\entry{Ongeïnitialiseerde let variabelen}{36}{Ongeïnitialiseerde @code {let} variabelen}
\entry{let variabelen ongeïnitialiseerd}{36}{@code {let} variabelen ongeïnitialiseerd}
\entry{Lexical binding}{37}{Lexical binding}
\entry{Binding, lexical}{37}{Binding, lexical}
\entry{Dynamische binding}{37}{Dynamische binding}
\entry{Binding, dynamisch}{37}{Binding, dynamisch}
\entry{if}{39}{@code {if}}
\entry{Conditioneel met if}{39}{Conditioneel met @code {if}}
\entry{wanneer-deel gedefinieerd}{39}{@samp {wanneer-deel} gedefinieerd}
\entry{dan-deel gedefinieerd}{39}{@samp {dan-deel} gedefinieerd}
\entry{> (greater than)}{39}{@code {> @r {(greater than)}}}
\entry{Else}{41}{Else}
\entry{Waar en onwaarheid in Emacs Lisp}{42}{Waar en onwaarheid in Emacs Lisp}
\entry{Onwaarheid en waar in Emacs Lisp}{42}{Onwaarheid en waar in Emacs Lisp}
\entry{nil}{42}{@code {nil}}
\entry{save-excursion}{43}{@code {save-excursion}}
\entry{Region, wat is het}{43}{Region, wat is het}
\entry{Point en buffer behouden}{43}{Point en buffer behouden}
\entry{Point en buffer behouden}{43}{Point en buffer behouden}
\entry{point}{43}{@code {point}}
\entry{mark}{43}{@code {mark}}
\entry{equal}{47}{@code {equal}}
\entry{eq}{47}{@code {eq}}
\entry{lege string gedefinieerd}{47}{@samp {lege string} gedefinieerd}
\entry{describe-function, geïntroduceerd}{49}{@code {describe-function@r {, geïntroduceerd}}}
\entry{Vind functiedocumentatie}{49}{Vind functiedocumentatie}
\entry{De source van een functie vinden}{49}{De source van een functie vinden}
\entry{Bibliotheek als term voor ``bestand''}{49}{Bibliotheek als term voor ``bestand''}
\entry{versimpelde-beginning-of-buffer}{50}{@code {versimpelde-beginning-of-buffer}}
\entry{describe-function}{51}{@code {describe-function}}
\entry{mark-whole-buffer}{51}{@code {mark-whole-buffer}}
\entry{append-to-buffer}{53}{@code {append-to-buffer}}
\entry{insert-buffer-substring}{53}{@code {insert-buffer-substring}}
\entry{Indentie voor formatteren}{57}{Indentie voor formatteren}
\entry{Formattering conventie}{57}{Formattering conventie}
\entry{let*}{58}{@code {let*}}
\entry{copy-to-buffer}{61}{@code {copy-to-buffer}}
\entry{insert-buffer}{62}{@code {insert-buffer}}
\entry{interactive, voorbeeld gebruik van}{63}{@code {interactive@r {, voorbeeld gebruik van}}}
\entry{Read-only buffer}{63}{Read-only buffer}
\entry{Sterretje voor een read-only buffer}{63}{Sterretje voor een read-only buffer}
\entry{* voor read-only buffer}{63}{@code {* @r {voor read-only buffer}}}
\entry{or}{65}{@code {or}}
\entry{insert-buffer, nieuwe versie body}{67}{@code {insert-buffer@r {, nieuwe versie body}}}
\entry{nieuwe versie body voor insert-buffer}{67}{nieuwe versie body voor @code {insert-buffer}}
\entry{beginning-of-buffer}{67}{@code {beginning-of-buffer}}
\entry{Optionele argumenten}{68}{Optionele argumenten}
\entry{Sleutelwoord}{68}{Sleutelwoord}
\entry{optionall}{68}{@code {optionall}}
\entry{/ (deling)}{70}{@code {/ @r {(deling)}}}
\entry{Deling}{70}{Deling}
\entry{Aandacht richten (versmallen)}{75}{Aandacht richten (versmallen)}
\entry{Versmallen}{75}{Versmallen}
\entry{Verbreden}{75}{Verbreden}
\entry{save-restriction}{75}{@code {save-restriction}}
\entry{what-line}{76}{@code {what-line}}
\entry{Verbreden, voorbeeld van}{76}{Verbreden, voorbeeld van}
\entry{Eigenschappen, vermelding van buffer-substring-no-properties}{78}{Eigenschappen, vermelding van @code {buffer-substring-no-properties}}
\entry{car, introduced}{79}{@code {car@r {, introduced}}}
\entry{cdr, introduced}{79}{@code {cdr@r {, introduced}}}
\entry{cons, geïntroduceerd}{81}{@code {cons@r {, geïntroduceerd}}}
\entry{length}{82}{@code {length}}
\entry{nthcdr}{82}{@code {nthcdr}}
\entry{nth}{84}{@code {nth}}
\entry{setcar}{85}{@code {setcar}}
\entry{setcdr}{86}{@code {setcdr}}
\entry{Tekst knippen en opslaan}{87}{Tekst knippen en opslaan}
\entry{Tekst opslaan en knippen}{87}{Tekst opslaan en knippen}
\entry{Tekst killen}{87}{Tekst killen}
\entry{Text clippen}{87}{Text clippen}
\entry{Tekst wissen}{87}{Tekst wissen}
\entry{Tekst deleten}{87}{Tekst deleten}
\entry{zap-to-char}{87}{@code {zap-to-char}}
\entry{gebogen aanhalingstekens}{88}{gebogen aanhalingstekens}
\entry{gebogen aanhalingstekens}{88}{gebogen aanhalingstekens}
\entry{search-forward}{89}{@code {search-forward}}
\entry{progn}{90}{@code {progn}}
\entry{kill-region}{91}{@code {kill-region}}
\entry{condition-case}{93}{@code {condition-case}}
\entry{Macro, lisp}{94}{Macro, lisp}
\entry{Lisp macro}{94}{Lisp macro}
\entry{copy-region-as-kill}{95}{@code {copy-region-as-kill}}
\entry{nthcdr}{95}{@code {nthcdr}}
\entry{filter-buffer-substring}{97}{@code {filter-buffer-substring}}
\entry{eq (voorbeeld van gebruik)}{97}{@code {eq @r {(voorbeeld van gebruik)}}}
\entry{kill-append}{97}{@code {kill-append}}
\entry{kill-new}{99}{@code {kill-new}}
\entry{push, voorbeeld}{101}{@code {push@r {, voorbeeld}}}
\entry{nthcdr, voorbeeld}{101}{@code {nthcdr@r {, voorbeeld}}}
\entry{setcdr, voorbeeld}{101}{@code {setcdr@r {, voorbeeld}}}
\entry{and}{102}{@code {and}}
\entry{delete-and-extract-region}{103}{@code {delete-and-extract-region}}
\entry{C, een uitweiding naar}{103}{C, een uitweiding naar}
\entry{Uitwijding naar C}{103}{Uitwijding naar C}
\entry{defvar}{105}{@code {defvar}}
\entry{Een variabele initialiseren}{105}{Een variabele initialiseren}
\entry{Variabele initialisatie}{105}{Variabele initialisatie}
\entry{defvar voor een user-customizable variabele}{106}{@code {defvar @r {voor een user-customizable variabele}}}
\entry{defvar met een sterretje}{106}{@code {defvar @r {met een sterretje}}}
\entry{set-variable}{106}{@code {set-variable}}
\entry{Lijsten in een computer}{109}{Lijsten in een computer}
\entry{dotted pair}{111}{dotted pair}
\entry{cons-cel}{111}{cons-cel}
\entry{Symbolen als een ladekast}{112}{Symbolen als een ladekast}
\entry{Ladekast, metafoor voor een symbool}{112}{Ladekast, metafoor voor een symbool}
\entry{Ladekast, metafoor voor een symbool}{112}{Ladekast, metafoor voor een symbool}
\entry{yank}{114}{@code {yank}}
\entry{Tekst terughalen}{114}{Tekst terughalen}
\entry{Tekst terughalen}{114}{Tekst terughalen}
\entry{Tekst plakken}{114}{Tekst plakken}
\entry{Killring overzicht}{114}{Killring overzicht}
\entry{Loops en recursie}{117}{Loops en recursie}
\entry{Recursie en loops}{117}{Recursie en loops}
\entry{Herhaling (loops)}{117}{Herhaling (loops)}
\entry{Loops}{117}{Loops}
\entry{while}{117}{@code {while}}
\entry{print-elements-of-list}{119}{@code {print-elements-of-list}}
\entry{*scratch* buffer}{119}{@file {*scratch*} buffer}
\entry{<= (kleiner of gelijk)}{123}{@code {<= @r {(kleiner of gelijk)}}}
\entry{Argument als lokale variabele}{127}{Argument als lokale variabele}
\entry{dolist}{128}{@code {dolist}}
\entry{dotimes}{129}{@code {dotimes}}
\entry{Recursie}{130}{Recursie}
\entry{Robots bouwen}{130}{Robots bouwen}
\entry{Robots, bouwen}{130}{Robots, bouwen}
\entry{Onderdelen van een recursieve definitie}{131}{Onderdelen van een recursieve definitie}
\entry{Recursive definitie onderdelen}{131}{Recursive definitie onderdelen}
\entry{print-elementen-recursief}{132}{@code {print-elementen-recursief}}
\entry{driehoek-recursief}{133}{@code {driehoek-recursief}}
\entry{cond}{135}{@code {cond}}
\entry{Recursieve patronen}{136}{Recursieve patronen}
\entry{Elke, soort van recursief patroon}{136}{Elke, soort van recursief patroon}
\entry{Recursive pattern - elke}{136}{Recursive pattern - elke}
\entry{Accumuleren, type recursief patroon}{138}{Accumuleren, type recursief patroon}
\entry{Recursief patroon - accumuleren}{138}{Recursief patroon - accumuleren}
\entry{Bewaren, type recursief patroon}{138}{Bewaren, type recursief patroon}
\entry{Recursieve patronen - bewaren}{138}{Recursieve patronen - bewaren}
\entry{Uitstel in recursie}{139}{Uitstel in recursie}
\entry{Recursie zonder uitstel}{139}{Recursie zonder uitstel}
\entry{Zonder uitstel oplossing}{140}{Zonder uitstel oplossing}
\entry{Oplossing zonder uitstel}{140}{Oplossing zonder uitstel}
\entry{Zoeken, illustreren}{144}{Zoeken, illustreren}
\entry{Reguliere expressie zoekopdrachten}{144}{Reguliere expressie zoekopdrachten}
\entry{Patronen, zoeken naar}{144}{Patronen, zoeken naar}
\entry{Bewegen per zin en paragraaf}{144}{Bewegen per zin en paragraaf}
\entry{Zinnen, bewegen per}{144}{Zinnen, bewegen per}
\entry{Paragrafen, bewegen per}{144}{Paragrafen, bewegen per}
\entry{sentence-end}{144}{@code {sentence-end}}
\entry{re-search-forward}{146}{@code {re-search-forward}}
\entry{forward-sentence}{146}{@code {forward-sentence}}
\entry{forward-paragraph}{150}{@code {forward-paragraph}}
\entry{let*}{151}{@code {let*}}
\entry{and}{152}{@code {and}}
\entry{regexp-quote}{152}{@code {regexp-quote}}
\entry{eobp}{154}{@code {eobp}}
\entry{looking-at}{154}{@code {looking-at}}
\entry{match-beginning}{156}{@code {match-beginning}}
\entry{Repetitie voor tellen van woorden}{159}{Repetitie voor tellen van woorden}
\entry{Reguliere expressie voor tellen van woorden}{159}{Reguliere expressie voor tellen van woorden}
\entry{tel-woorden-voorbeeld}{159}{@code {tel-woorden-voorbeeld}}
\entry{Tel woorden recursief}{165}{Tel woorden recursief}
\entry{Recursief woorden tellen}{165}{Recursief woorden tellen}
\entry{Woorden, recursief geteld}{165}{Woorden, recursief geteld}
\entry{recursive-count-words}{170}{@code {recursive-count-words}}
\entry{Woorden tellen in een defun}{172}{Woorden tellen in een @code {defun}}
\entry{Woorden tellen in een defun}{172}{Woorden tellen in een @code {defun}}
\entry{Woorden en symbolen in defun}{172}{Woorden en symbolen in defun}
\entry{Syntax categorieën en tabellen}{173}{Syntax categorieën en tabellen}
\entry{Woorden tellen in een defun}{174}{Woorden tellen in een @code {defun}}
\entry{tel-woorden-in-defun}{176}{@code {tel-woorden-in-defun}}
\entry{Een bestand vinden}{177}{Een bestand vinden}
\entry{lengte-lijst-bestand}{178}{@code {lengte-lijst-bestand}}
\entry{lengths-list-many-files}{181}{@code {lengths-list-many-files}}
\entry{recursieve-lengte-lijst-veel-bestanden}{182}{@code {recursieve-lengte-lijst-veel-bestanden}}
\entry{sorteren}{184}{@code {sorteren}}
\entry{directory-files}{184}{@code {directory-files}}
\entry{bestanden-in-onderliggende-directory}{185}{@code {bestanden-in-onderliggende-directory}}
\entry{hoogste-van-ranges}{188}{@code {hoogste-van-ranges}}
\entry{nreverse}{189}{@code {nreverse}}
\entry{reverse}{190}{@code {reverse}}
\entry{Een grafiek voorbereiden}{192}{Een grafiek voorbereiden}
\entry{Grafiek prototype}{192}{Grafiek prototype}
\entry{Prototype grafiek}{192}{Prototype grafiek}
\entry{Body van grafiek}{192}{Body van grafiek}
\entry{apropos}{192}{@code {apropos}}
\entry{max}{194}{@code {max}}
\entry{min}{194}{@code {min}}
\entry{apply}{194}{@code {apply}}
\entry{grafiek-body-tonen}{197}{@code {grafiek-body-tonen}}
\entry{recursieve-grafiek-body-tonen}{199}{@code {recursieve-grafiek-body-tonen}}
\entry{.emacs bestand}{201}{@file {.emacs} bestand}
\entry{Je .emacs aanpassen}{201}{Je @file {.emacs} aanpassen}
\entry{Initialisatie bestand}{201}{Initialisatie bestand}
\entry{default.el init bestand}{202}{@file {default.el} init bestand}
\entry{site-init.el init bestand}{202}{@file {site-init.el} init bestand}
\entry{site-load.el init bestand}{202}{@file {site-load.el} init bestand}
\entry{defcustom}{202}{@code {defcustom}}
\entry{defsubst}{204}{@code {defsubst}}
\entry{defconst}{204}{@code {defconst}}
\entry{.emacs bestand, begin van}{204}{@file {.emacs} bestand, begin van}
\entry{Per-buffer, lokale variabelen lijst}{206}{Per-buffer, lokale variabelen lijst}
\entry{Local variables list, per-buffer,}{206}{Local variables list, per-buffer,}
\entry{Automatische mode selectie}{206}{Automatische mode selectie}
\entry{Mode selectie, automatisch}{206}{Mode selectie, automatisch}
\entry{Text Mode aangezet}{206}{Text Mode aangezet}
\entry{Auto Fill mode aangezet}{206}{Auto Fill mode aangezet}
\entry{add-hook}{206}{@code {add-hook}}
\entry{Mail aliases}{207}{Mail aliases}
\entry{Tabs, voorkomen}{207}{Tabs, voorkomen}
\entry{indent-tabs-mode}{207}{@code {indent-tabs-mode}}
\entry{compare-windows}{208}{@code {compare-windows}}
\entry{Een globale key zetten}{208}{Een globale key zetten}
\entry{Keymap globaal zetten}{208}{Keymap globaal zetten}
\entry{Key globaal zetten}{208}{Key globaal zetten}
\entry{keymap-global-set}{208}{@code {keymap-global-set}}
\entry{occur}{208}{@code {occur}}
\entry{keymap-global-unset}{208}{@code {keymap-global-unset}}
\entry{Ontkoppelen toets}{208}{Ontkoppelen toets}
\entry{Toets ontkoppelen}{208}{Toets ontkoppelen}
\entry{list-buffers, rebound}{209}{@code {list-buffers@r {, rebound}}}
\entry{buffer-menu, gebonden aan een toetscombinatie}{209}{@code {buffer-menu@r {, gebonden aan een toetscombinatie}}}
\entry{global-set-key}{209}{@code {global-set-key}}
\entry{Globaal instellen toestcombinatie}{209}{Globaal instellen toestcombinatie}
\entry{global-unset-key}{209}{@code {global-unset-key}}
\entry{Keymaps}{209}{Keymaps}
\entry{Toestcombinaties opnieuw binden}{209}{Toestcombinaties opnieuw binden}
\entry{Bestanden laden}{210}{Bestanden laden}
\entry{load-path}{211}{@code {load-path}}
\entry{load-library}{211}{@code {load-library}}
\entry{autoload}{211}{@code {autoload}}
\entry{line-to-top-of-window}{212}{@code {line-to-top-of-window}}
\entry{Eenvoudige uitbreiding in de .emacs bestand}{212}{Eenvoudige uitbreiding in de @file {.emacs} bestand}
\entry{Conditional tussen twee versies van Emacs}{213}{Conditional tussen twee versies van Emacs}
\entry{Versie van Emacs, kiezen}{213}{Versie van Emacs, kiezen}
\entry{Emacs versie, kiezen}{213}{Emacs versie, kiezen}
\entry{Kebindings, verbeteren}{217}{Kebindings, verbeteren}
\entry{Bindings, key, verbeteren onplezierige}{217}{Bindings, key, verbeteren onplezierige}
\entry{mode-line-format}{218}{@code {mode-line-format}}
\entry{Mode line format}{218}{Mode line format}
\entry{Eigenschappen in het mode line voorbeeld}{219}{Eigenschappen in het mode line voorbeeld}
\entry{debuggen}{221}{debuggen}
\entry{debug}{221}{@code {debug}}
\entry{driehoek-met-bug}{221}{@code {driehoek-met-bug}}
\entry{debug-on-entry}{222}{@code {debug-on-entry}}
\entry{cancel-debug-on-entry}{224}{@code {cancel-debug-on-entry}}
\entry{debug-on-quit}{224}{@code {debug-on-quit}}
\entry{(debug) in code}{225}{@code {(debug)} in code}
\entry{Source level debugger}{225}{Source level debugger}
\entry{edebug}{225}{@code {edebug}}
\entry{de-de}{230}{@code {de-de}}
\entry{Gedupliceerde woorden functie}{230}{Gedupliceerde woorden functie}
\entry{Woorden, gedupliceerd}{230}{Woorden, gedupliceerd}
\entry{Killring hanteren}{232}{Killring hanteren}
\entry{Hanteren van de killring}{232}{Hanteren van de killring}
\entry{Ring, een lijst maken zoals een}{232}{Ring, een lijst maken zoals een}
\entry{current-kill}{232}{@code {current-kill}}
\entry{zerrop}{234}{@code {zerrop}}
\entry{error}{234}{@code {error}}
\entry{global variable gedefinieerd}{237}{@samp {global variable} gedefinieerd}
\entry{variable, global, gedefinieerd}{237}{@samp {variable, global}, gedefinieerd}
\entry{yank}{237}{@code {yank}}
\entry{yank-pop}{239}{@code {yank-pop}}
\entry{ring.el bestand}{240}{@file {ring.el} bestand}
\entry{toon-grafiek varlist}{242}{@code {toon-grafiek} varlist}
\entry{As, verticaal tonen}{243}{As, verticaal tonen}
\entry{Y-as tonen}{243}{Y-as tonen}
\entry{Verticale as tonen}{243}{Verticale as tonen}
\entry{Toon verticale as}{243}{Toon verticale as}
\entry{% (rest functie)}{244}{@code {% @r {(rest functie)}}}
\entry{Rest functie, %}{244}{Rest functie, @code {%}}
\entry{Y-as-label-spacing}{245}{@code {Y-as-label-spacing}}
\entry{number-to-string}{245}{@code {number-to-string}}
\entry{Y-as-tic}{246}{@code {Y-as-tic}}
\entry{make-string}{246}{@code {make-string}}
\entry{Y-axis-column}{247}{@code {Y-axis-column}}
\entry{print-Y-axis}{248}{@code {print-Y-axis}}
\entry{As, horizontaal tonen}{249}{As, horizontaal tonen}
\entry{X-as tonen}{249}{X-as tonen}
\entry{Toon horizontale as}{249}{Toon horizontale as}
\entry{Horizontale as tonen}{249}{Horizontale as tonen}
\entry{toon-X-as-tic-line}{251}{@code {toon-X-as-tic-line}}
\entry{X-as-element}{252}{@code {X-as-element}}
\entry{toon-X-as-genummerde-regel}{252}{@code {toon-X-as-genummerde-regel}}
\entry{print-X-axis}{252}{@code {print-X-axis}}
\entry{De gehele grafiek tonen}{253}{De gehele grafiek tonen}
\entry{Hele grafiek tonen}{253}{Hele grafiek tonen}
\entry{Grafiek, alles tonen}{253}{Grafiek, alles tonen}
\entry{Y-as-kolom finale versie}{254}{@code {Y-as-kolom @r {finale versie}}}
\entry{grafiek-body-tonen Finale versie.}{254}{@code {grafiek-body-tonen @r {Finale versie.}}}
\entry{toon-grafiek Finale versie.}{255}{@code {toon-grafiek @r {Finale versie.}}}
\entry{Anonieme functie}{258}{Anonieme functie}
\entry{lambda}{258}{@code {lambda}}
\entry{mapcar}{259}{@code {mapcar}}
\entry{Bug, meest verraderlijke type}{260}{Bug, meest verraderlijke type}
\entry{Verraderlijk type bug}{260}{Verraderlijk type bug}
\entry{FDL, GNU Free Documentation License}{265}{FDL, GNU Free Documentation License}
