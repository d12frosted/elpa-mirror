;; Generated package description from pabbrev.el  -*- no-byte-compile: t -*-
(define-package "pabbrev" "4.3.0.0.20240617.162224" "Predictive abbreviation expansion" '((emacs "25.1")) :commit "d5f120c523ddce2e8dea1868150248cd188d8ad8" :authors '(("Phillip Lord" . "phillip.lord@newcastle.ac.uk")) :maintainer '("Arthur Miller" . "arthur.miller@live.com") :url "https://github.com/phillord/pabbrev")
