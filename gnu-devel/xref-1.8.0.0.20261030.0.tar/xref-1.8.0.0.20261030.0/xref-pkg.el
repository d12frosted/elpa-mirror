;; Generated package description from xref.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "xref" "1.8.0.0.20261030.0" "Cross-referencing commands" '((emacs "26.1")) :commit "47557cebb4f84553afc43b25c45c912e8b6e14b4" :url "https://elpa.gnu.org/packages/xref.html")
