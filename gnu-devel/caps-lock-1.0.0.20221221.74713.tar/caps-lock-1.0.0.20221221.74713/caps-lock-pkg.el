;; Generated package description from caps-lock.el  -*- no-byte-compile: t -*-
(define-package "caps-lock" "1.0.0.20221221.74713" "Caps-lock as a minor mode" 'nil :commit "0bb2e7fbe5f70253d2329e475264c1b7721847d4" :url "https://elpa.gnu.org/packages/caps-lock.html" :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
