;; Generated package description from chess.el  -*- no-byte-compile: t -*-
(define-package "chess" "2.0.5.0.20220926.150547" "Play chess in GNU Emacs" '((cl-lib "0.5")) :commit "e4adaf1a8e276ff556763aca8a47e10193f2bed4" :url "https://elpa.gnu.org/packages/chess.html" :authors '(("John Wiegley" . "johnw@gnu.org")) :maintainer '("Mario Lang" . "mlang@delysid.org") :keywords '("games"))
