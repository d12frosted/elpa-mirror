;; Generated package description from notes-mode.el  -*- no-byte-compile: t -*-
(define-package "notes-mode" "1.31.0.20240402.80928" "Indexing system for on-line note-taking" 'nil :commit "2a25d79f7e5d9ab7298ba40e11e78d1f2ded06d2" :authors '(("John Heidemann" . "johnh@isi.edu")) :maintainer '("John Heidemann" . "johnh@isi.edu") :url "https://ant.isi.edu/~johnh/SOFTWARE/NOTES_MODE/")
