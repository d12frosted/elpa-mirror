;; Generated package description from lv.el  -*- mode: lisp-data; no-byte-compile: t -*-
(define-package "lv" "0.15.0.0.20250316.223951" "Other echo area" 'nil :commit "84a9db01eff1fcc52ad054c5ad3c22316739573f" :url "https://elpa.gnu.org/packages/lv.html")
