;; Generated package description from poke-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "poke-mode" "3.1.0.20260809.1" "Major mode for editing Poke programs" 'nil :commit "c81e1985cc0c94ee6a98300179976d72370f4b4e" :url "https://elpa.gnu.org/packages/poke-mode.html" :authors '(("Aurelien Aptel" . "aaptel@suse.com")) :maintainer '("Jose E. Marchesi" . "jemarch@gnu.org"))
