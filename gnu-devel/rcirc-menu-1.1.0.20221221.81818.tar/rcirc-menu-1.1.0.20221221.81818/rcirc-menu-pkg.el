;; Generated package description from rcirc-menu.el  -*- no-byte-compile: t -*-
(define-package "rcirc-menu" "1.1.0.20221221.81818" "A menu of all your rcirc connections" 'nil :commit "36f65fcb850c415b9d1ad037c4b6ae5fc0b5be69" :url "https://elpa.gnu.org/packages/rcirc-menu.html" :authors '(("Alex Schroeder" . "alex@gnu.org")) :maintainer '("Alex Schroeder" . "alex@gnu.org") :keywords '("comm"))
