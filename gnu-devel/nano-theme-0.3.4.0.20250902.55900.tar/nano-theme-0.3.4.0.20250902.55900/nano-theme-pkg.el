;; Generated package description from nano-theme.el  -*- no-byte-compile: t -*-
(define-package "nano-theme" "0.3.4.0.20250902.55900" "N Λ N O theme" '((emacs "27.1")) :commit "41ef36999bacbffe43c4a96320ad6bb285b7f09f" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("theme" "dark" "light") :url "https://github.com/rougier/nano-theme")
