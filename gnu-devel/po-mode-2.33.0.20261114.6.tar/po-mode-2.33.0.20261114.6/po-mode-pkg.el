;; Generated package description from po-mode.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "po-mode" "2.33.0.20261114.6" "major mode for GNU gettext PO files" '((emacs "23")) :commit "be0c57e778fe90e71abe6a7e68d8961fa1782a97" :url "https://elpa.gnu.org/packages/po-mode.html" :keywords '("i18n" "gettext"))
