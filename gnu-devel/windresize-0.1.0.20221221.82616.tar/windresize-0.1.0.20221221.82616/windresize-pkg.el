;; Generated package description from windresize.el  -*- no-byte-compile: t -*-
(define-package "windresize" "0.1.0.20221221.82616" "Resize windows interactively" 'nil :commit "b61132c344f10ca02df56357b0aa3e8eaf4a3392" :url "https://elpa.gnu.org/packages/windresize.html" :authors '(("Bastien" . "bzg@gnu.org")) :maintainer '("Bastien" . "bzg@gnu.org") :keywords '("window"))
