;; Generated package description from lex.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "lex" "1.3.0.20260601.0" "Lexical analyser construction" 'nil :commit "ccbfa1da2d773e07c9f1e0451b70b23f721fa7d5" :url "https://elpa.gnu.org/packages/lex.html" :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
