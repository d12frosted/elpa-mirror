;; Generated package description from xpm.el  -*- no-byte-compile: t -*-
(define-package "xpm" "1.0.5.0.20230911.4618" "edit XPM images" '((cl-lib "0.5") (queue "0.2")) :commit "72f43a16fdc629e3d7bf90bf6cdebdaff97a95c7" :authors '(("Thien-Thi Nguyen" . "ttn@gnu.org")) :maintainer '(nil . "emacs-devel@gnu.org") :keywords '("multimedia" "xpm") :url "https://www.gnuvola.org/software/xpm/")
