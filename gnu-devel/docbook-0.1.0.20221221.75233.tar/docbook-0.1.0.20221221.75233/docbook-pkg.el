;; Generated package description from docbook.el  -*- no-byte-compile: t -*-
(define-package "docbook" "0.1.0.20221221.75233" "Info-like viewer for DocBook" 'nil :commit "9b7c2dbae38b523442f7c1155bc4e3db16a0c49f" :url "https://elpa.gnu.org/packages/docbook.html" :authors '(("Chong Yidong" . "cyd@gnu.org")) :maintainer '("Chong Yidong" . "cyd@gnu.org") :keywords '("docs" "help"))
