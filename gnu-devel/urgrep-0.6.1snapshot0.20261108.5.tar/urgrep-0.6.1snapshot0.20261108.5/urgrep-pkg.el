;; Generated package description from urgrep.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "urgrep" "0.6.1snapshot0.20261108.5" "Universal recursive grep" '((emacs "28.1") (compat "29.1.0.1")) :commit "d28807a3a50e550bc56118e223b00f116ceb50ec" :keywords '("grep" "search") :url "https://sr.ht/~jimporter/urgrep/")
