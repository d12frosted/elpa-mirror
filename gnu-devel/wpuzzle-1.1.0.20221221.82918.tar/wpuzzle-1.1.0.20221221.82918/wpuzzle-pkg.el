;; Generated package description from wpuzzle.el  -*- no-byte-compile: t -*-
(define-package "wpuzzle" "1.1.0.20221221.82918" "find as many word in a given time" 'nil :commit "cc5e4c53177d01ab160e4f42e4e66410aeb69419" :url "https://elpa.gnu.org/packages/wpuzzle.html" :authors '(("Ivan Kanis" . "ivan@kanis.fr")) :maintainer '("Ivan Kanis" . "ivan@kanis.fr"))
