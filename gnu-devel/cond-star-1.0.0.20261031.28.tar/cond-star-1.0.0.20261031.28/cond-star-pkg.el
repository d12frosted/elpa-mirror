;; Generated package description from cond-star.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "cond-star" "1.0.0.20261031.28" "Extended form of `cond' construct" '((emacs "24.3")) :commit "47557cebb4f84553afc43b25c45c912e8b6e14b4" :url "https://elpa.gnu.org/packages/cond-star.html" :maintainer '("Richard Stallman" . "rms@gnu.org"))
