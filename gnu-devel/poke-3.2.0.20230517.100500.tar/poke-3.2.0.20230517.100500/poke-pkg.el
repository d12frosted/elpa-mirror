;; Generated package description from poke.el  -*- no-byte-compile: t -*-
(define-package "poke" "3.2.0.20230517.100500" "Emacs meets GNU poke!" '((emacs "25")) :commit "1268958f1d9eb2a21ab548101b3bdf0dcc348253" :authors '(("Jose E. Marchesi" . "jemarch@gnu.org")) :maintainer '("Jose E. Marchesi" . "jemarch@gnu.org") :url "https://www.jemarch.net/poke")
