;; Generated package description from svg-lib.el  -*- no-byte-compile: t -*-
(define-package "svg-lib" "0.3.0.20250822.125859" "SVG tags, progress bars & icons" '((emacs "27.1")) :commit "925ed4a0215c197ba836e7810a93905b34bea777" :maintainer '("Nicolas P. Rougier" . "Nicolas.Rougier@inria.fr") :keywords '("svg" "icons" "tags" "convenience") :url "https://github.com/rougier/svg-lib")
