@c automatically generated, do not edit
@set VERSION 10.0-pre (10.0-pre-3ddb8a)
@set DATE 2026-11-22
