;; Generated package description from lmc.el  -*- no-byte-compile: t -*-
(define-package "lmc" "1.4.0.20230105.113402" "Little Man Computer in Elisp" '((emacs "24") (cl-lib "0.5")) :commit "cff4a32cd5c08b3624b9848b91493860cd36b07f" :url "https://elpa.gnu.org/packages/lmc.html" :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
