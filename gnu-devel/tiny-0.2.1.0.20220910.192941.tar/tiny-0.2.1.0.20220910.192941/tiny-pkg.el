;; Generated package description from tiny.el  -*- no-byte-compile: t -*-
(define-package "tiny" "0.2.1.0.20220910.192941" "Quickly generate linear ranges in Emacs" 'nil :commit "c107480fca7e42737c51b2afaa33ac31e92a7290" :authors '(("Oleh Krehel" . "ohwoeowho@gmail.com")) :maintainer '("Oleh Krehel" . "ohwoeowho@gmail.com") :keywords '("convenience") :url "https://github.com/abo-abo/tiny")
