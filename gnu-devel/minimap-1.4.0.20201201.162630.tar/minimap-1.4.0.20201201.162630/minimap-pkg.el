;; Generated package description from minimap.el  -*- no-byte-compile: t -*-
(define-package "minimap" "1.4.0.20201201.162630" "Sidebar showing a \"mini-map\" of a buffer" 'nil :commit "b295cab07c1932c11dd00f23ba29c1ff0de486ab" :url "https://elpa.gnu.org/packages/minimap.html" :authors '(("David Engster" . "deng@randomsample.de")) :maintainer '("David Engster" . "deng@randomsample.de"))
