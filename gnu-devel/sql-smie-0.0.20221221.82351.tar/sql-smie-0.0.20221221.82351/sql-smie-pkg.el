;; Generated package description from sql-smie.el  -*- no-byte-compile: t -*-
(define-package "sql-smie" "0.0.20221221.82351" "SMIE support for SQL-mode" 'nil :commit "902d88d3ec4a0e6fd0040d239634e44bc00d65b1" :url "https://elpa.gnu.org/packages/sql-smie.html" :authors '(("Stefan Monnier" . "monnier@iro.umontreal.ca")) :maintainer '("Stefan Monnier" . "monnier@iro.umontreal.ca"))
