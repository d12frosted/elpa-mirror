;;; gtags-mode.el --- GNU Global integration with xref, project and imenu  -*- lexical-binding: t; -*-

;; Copyright (C) 2022-2026  Free Software Foundation, Inc.

;; Author: Jimmy Aguilar Mena <kratsbinovish@gmail.com>
;; URL: https://github.com/Ergus/gtags-mode
;; Keywords: xref, project, imenu, gtags, global
;; Version: 2.0.0
;; Package-Requires: ((emacs "30"))

;; This program is free software: you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation, either version 3 of the License, or
;; (at your option) any later version.

;; This program is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <http://www.gnu.org/licenses/>.

;;; Commentary:

;; GNU Global integration with xref, project, completion-at-point
;; (capf) and imenu.

;; There are many other packages with their own approach and set of
;; more complete/complex features, maps and functionalities; like
;; ggtags, gtags.el, gxref, agtags and some others referenced in:
;; https://www.gnu.org/software/global/links.html

;; This package leaves all the work to the Emacs tools available for such
;; functions and avoids external dependencies.  Unlike the other
;; packages; this module does not create extra special maps, bindings
;; or menus, but just adds support to the mentioned features to use
;; gtags/global as a backend when possible.  We put special emphasis on
;; minimalism, simplicity, efficiency, and Tramp support.

;; This package may be extended in the future with new features and to
;; support other tools, but only if they are required and included in
;; an Emacs distribution and don't need external dependencies.

;;; Code:

(require 'xref)
(require 'project)
(require 'seq)
(require 'files-x)
(eval-when-compile (require 'subr-x))

(defgroup gtags-mode nil
  "GNU Global group for xref."
  :group 'xref)

(defcustom gtags-mode-global-executable "global"
  "GNU Global executable."
  :type 'string
  :local t)

(defcustom gtags-mode-gtags-executable "gtags"
  "GNU Gtags executable."
  :type 'string
  :local t)

(defcustom gtags-mode-update-args ""
  "Extra arguments to use when updating the database.
The string is split with shell syntax, so arguments containing spaces
must be quoted.  For example to use universal-ctags you can set this to:
\"--gtagsconf=/usr/share/gtags/gtags.conf --gtagslabel=universal-ctags\""
  :type 'string
  :local t)

(defcustom gtags-mode-lighter " Gtags"
  "The text displayed in the mode line."
  :type 'string
  :risky t)

(defcustom gtags-mode-features '(project xref completion imenu hooks)
  "The list of features enabled in gtags-mode.
This variable must be set before enabling gtags-mode."
  :type '(set (const project)
              (const xref)
              (const completion)
              (const imenu)
              (const hooks))
  :risky t)

(defcustom gtags-mode-verbose-level 2
  "Verbosity of gtags-mode messages.
Messages of level less than or equal to this value are printed; 0
prints none.  Level 1 (errors and warnings) also goes to the echo
area; higher levels only to the *Messages* buffer."
  :type 'natnum
  :risky t)

(defvar gtags-mode--alist nil
  "List of Global project plists, one per root.
Each plist is shared by the buffers of its project.  Remote roots
include the remote prefix.")
(put 'gtags-mode--alist 'risky-local-variable t)

(defvar gtags-mode--no-root-dirs (make-hash-table :test #'equal)
  "Directories known to be outside any Global project.
Keys are expanded directory names, with a trailing slash.  Avoids
running `global --print-dbpath' (a round trip over TRAMP) on every
`gtags-mode--project-find' call for such a directory.  Entries under
a new root are removed when its plist is created; the table is
cleared when a database is created or updated and when the mode is
toggled.")

(defvar-local gtags-mode--global (executable-find gtags-mode-global-executable)
  "Path of the global executable for this buffer, or nil.
Resolved from `gtags-mode-global-executable'; connection-local in
remote buffers.")
(defvar-local gtags-mode--gtags (executable-find gtags-mode-gtags-executable)
  "Path of the gtags executable for this buffer, or nil.
Resolved from `gtags-mode-gtags-executable'; connection-local in
remote buffers.")
(defvar-local gtags-mode--plist nil
  "Global project plist of this buffer, or nil.
The object is shared with `gtags-mode--alist'.  Keys: `:gtagsroot',
`:cache' and `:prefix-cache'.  A local nil value means no project
and is not recomputed.")
(defvar-local gtags-mode--true-file-name nil
  "Cached `file-truename' of variable `buffer-file-name'.
Must stay buffer-local: `gtags-mode--plist' is shared by all the
buffers of a project.")

(defconst gtags-mode--output-format-regex
  "^\\(.+?\\) \\([^ ]+\\) \\([[:digit:]]+\\) \\(.*\\)"
  "Regex to filter the output with `gtags-mode--output-format-options'.")

(defconst gtags-mode--output-format-options
  '("--result=cscope" "--path-style=relative" "--color=never")
  "Command line options to use with `gtags-mode--output-format-regex'.")

(defsubst gtags-mode--message (level format-string &rest args)
  "Log FORMAT-STRING with ARGS when LEVEL <= `gtags-mode-verbose-level'.
Level 1 messages (errors and warnings) also go to the echo area;
higher levels only to the *Messages* buffer."
  (when (>= gtags-mode-verbose-level level)
    (let ((inhibit-message (> level 1)))
      (apply #'message (concat "gtags-mode: " format-string) args))))

;; Connection functions
(defun gtags-mode--set-connection-locals ()
  "Set connection local variables when possible and needed."
  (when-let* ((remote (file-remote-p default-directory))
	      ((not (and (local-variable-p 'gtags-mode--global)
			 (local-variable-p 'gtags-mode--gtags))))
	      (criteria (connection-local-criteria-for-default-directory))
	      (symvars (intern (format "gtags-mode--%s-vars" remote)))
	      (enable-connection-local-variables t))
    (unless (alist-get symvars connection-local-profile-alist)
      (with-connection-local-variables  ;; because *-executable can be set as connection local
       (let ((global (if (local-variable-p 'gtags-mode-global-executable)
			 gtags-mode-global-executable
		       (file-name-nondirectory gtags-mode-global-executable)))
	     (gtags (if (local-variable-p 'gtags-mode-gtags-executable)
			gtags-mode-gtags-executable
		      (file-name-nondirectory gtags-mode-gtags-executable))))
	 (connection-local-set-profile-variables
	  symvars
	  `((gtags-mode--global . ,(executable-find global t))
	    (gtags-mode--gtags . ,(executable-find gtags t))))
	 (connection-local-set-profiles criteria symvars))))
    (hack-connection-local-variables-apply criteria)))

(defvar gtags-mode--pr-async nil
  "The running asynchronous gtags or global process, or nil.
At most one runs at a time.")

;; Async functions
(defun gtags-mode--exec-async-sentinel (process event)
  "Sentinel to run when PROCESS emits EVENT.
This is the sentinel set in `gtags-mode--exec-async'."
  (if (and (eq (process-status process) 'exit)         ;; On success
	   (eql (process-exit-status process) 0))
      (let ((temp-buffer (process-buffer process))
	    (parent-buffer (process-get process :parent-buffer))
	    (extra-sentinel (process-get process :extra-sentinel)))
	(when (buffer-name temp-buffer)                ;; kill temp buffer
	  (while (accept-process-output process))
	  (kill-buffer temp-buffer))
	(when (buffer-live-p parent-buffer)            ;; work on parent buffer
	  (with-current-buffer parent-buffer
	    (when (functionp extra-sentinel)           ;; run extra sentinel
	      (funcall extra-sentinel))
	    (when gtags-mode--plist                    ;; clear project caches
	      (setq gtags-mode--plist (plist-put gtags-mode--plist :cache nil))
	      (setq gtags-mode--plist (plist-put gtags-mode--plist :prefix-cache nil))))))
    (let ((temp-buffer (process-buffer process)))      ;; In failure print error
      (when (buffer-live-p temp-buffer)
	(with-current-buffer temp-buffer
	  (while (accept-process-output process))
	  (gtags-mode--message 1 "Global async error output:\n%s"
			       (string-trim
				(buffer-substring-no-properties (point-min) (point-max)))))
	(kill-buffer temp-buffer))))
  (setq gtags-mode--pr-async nil)
  (gtags-mode--message 2 "Async %s: result: %s elapsed: %.06f"
		       (process-get process :command)
		       (string-trim event)
		       (float-time (time-subtract (current-time)
						  (process-get process :start-time))))) ;; Always notify

(defun gtags-mode--exec-async (cmd &rest args)
  "Run the executable stored in variable CMD with ARGS asynchronously.
CMD is `gtags-mode--global' or `gtags-mode--gtags'.  The process runs
in `default-directory', with `gtags-mode-update-args' before ARGS.
Return the process, or nil when CMD is nil or another process is
running.  `gtags-mode--exec-async-sentinel' kills the process buffer
and, on success, clears the project caches of the calling buffer."
  (let ((executable (with-temp-buffer ;; inherits `default-directory'
		      (gtags-mode--set-connection-locals)
		      (symbol-value cmd))))
    (cond
     ((not executable)
      (gtags-mode--message 1 "Can't start async process: `%s' is nil" cmd)
      nil)
     (gtags-mode--pr-async
      (gtags-mode--message 1 "Cannot run command: There is a gtags or global process already running.")
      nil)
     (t
      (let* ((command (append `(,executable)
			      (split-string-shell-command gtags-mode-update-args)
			      args))
	     (start-time (current-time))
	     ;; Signals on failure instead of returning nil.
	     (pr (make-process :name (format "%s-async" executable)
			       :buffer (generate-new-buffer " *temp*" t)
			       :command command
			       :sentinel #'gtags-mode--exec-async-sentinel
			       :file-handler t)))
	(gtags-mode--message 2 "Starting async process: %s" command)
	;; In future not needed with `remote-commands'.
	(set-process-plist pr (list :parent-buffer (current-buffer)
				    :command command
				    :start-time start-time))
	(setq gtags-mode--pr-async pr))))))

(defun gtags-mode--exec-sync (&rest args)
  "Run global with ARGS synchronously in `default-directory'.
Return the output lines, or nil on error."
  (with-temp-buffer
    ;; The temporary buffer inherits `default-directory': resolve the
    ;; executable for its host, not the calling buffer's.
    (gtags-mode--set-connection-locals)
    (if-let* ((cmd gtags-mode--global))
	(let* ((start-time (current-time))
	       (status (apply #'process-file cmd nil (current-buffer) nil args))
	       (output (string-trim
			(buffer-substring-no-properties (point-min) (point-max)))))
	  (if (eq status 0)
	      (let ((res (string-lines output t)))
		(gtags-mode--message 2 "Global sync %s elapsed: %s lines: %s"
				     args
				     (float-time (time-subtract (current-time) start-time))
				     (length res))
		res)
	    (gtags-mode--message 1 "Global sync error output:\n%s" output)
	    (gtags-mode--message 1 "Sync %s %s: exited abnormally with code: %s elapsed: %.06f"
				 cmd args status
				 (float-time (time-subtract (current-time) start-time)))
	    nil))
      (gtags-mode--message 1 "Can't start sync process: `gtags-mode--global' is nil")
      nil)))

(defsubst gtags-mode--get-root (dir)
  "Return the Global root directory for DIR, or nil.
The result ends in a slash and includes the remote prefix of DIR."
  (when-let* ((gtags-mode--global)
	      ;; Suppress any warning when searching the root
	      ;; because `global' returns an error value when there is
	      ;; not dbpath found.
	      (gtags-mode-verbose-level 0)
	      (default-directory dir)
	      ;; The check id independent of the concat because when
	      ;; empty (no root) on remote systems, the concat will
	      ;; returns always a non nil value.
	      (root (car (gtags-mode--exec-sync "--print-dbpath"))))
    (concat (file-remote-p dir)              ;; add remote prefix if remote
	    (file-name-as-directory root)))) ;; add a / at the end if missing

;; Utilities functions (a bit less low level) ========================
(defun gtags-mode--get-plist (dir)
  "Return the plist in `gtags-mode--alist' whose root contains DIR, or nil.
With nested roots, return the innermost: the list is sorted by
decreasing root length."
  (seq-find (lambda (plist)
	      (string-prefix-p (plist-get plist :gtagsroot) dir))
	    gtags-mode--alist))

(defun gtags-mode--create-plist (dir)
  "Return the plist of the Global project containing DIR, or nil.
Query global; add a plist to `gtags-mode--alist' for a new root."
  (when-let* ((root (gtags-mode--get-root dir)))
    (gtags-mode--message 2 "Gtags file in %s applies to default-directory: %s" root dir)
    ;; Exact match: `gtags-mode--get-plist' would return an enclosing
    ;; root for a new nested one.
    (or (seq-find (lambda (plist) (string= root (plist-get plist :gtagsroot)))
		  gtags-mode--alist)
	;; All keys must exist: `plist-put' and `with-memoization' then
	;; modify the plist shared by the project buffers in place
	;; instead of consing a buffer-local copy.
	(let ((plist (list :gtagsroot root :cache nil :prefix-cache nil)))
	  ;; The database may have been created outside Emacs.
	  (maphash (lambda (key _)
		     (when (string-prefix-p root key)
		       (remhash key gtags-mode--no-root-dirs)))
		   gtags-mode--no-root-dirs)
	  (setq gtags-mode--alist
		(sort (cons plist gtags-mode--alist)
		      :key (lambda (p) (length (plist-get p :gtagsroot)))
		      :reverse t))
	  plist))))

(defun gtags-mode--set-local-plist (dir)
  "Find the project for DIR and store it in `gtags-mode--plist'.
Apply connection-local variables first.  Query global only when the
buffer visits a file.  Also set `gtags-mode--true-file-name'.  Return
the plist, or nil; nil is stored too."
  (let ((default-directory (file-truename dir)))
    (gtags-mode--set-connection-locals)
    (setq-local gtags-mode--plist
		(or (gtags-mode--get-plist default-directory)
		    ;; Heuristic: create new plists only when visiting
		    ;; real files.  This avoids calling the external
		    ;; process repeatedly when there is no tags file, i.e
		    ;; in magit buffers that are regenerated every time
		    ;; and forget the local variables.
		    (and buffer-file-name
			 (gtags-mode--create-plist default-directory))))
    (when (and gtags-mode--plist buffer-file-name)
      (setq-local gtags-mode--true-file-name (file-truename buffer-file-name)))
    gtags-mode--plist))

(defun gtags-mode--local-plist (&optional dir)
  "Return `gtags-mode--plist', computing it for DIR on first call.
DIR defaults to `default-directory'.  Once set, the local value,
including nil, is returned without lookups.  Also used in
`xref-backend-functions'."
  (if (local-variable-p 'gtags-mode--plist)
      gtags-mode--plist
    (gtags-mode--set-local-plist (or dir default-directory))))

(defun gtags-mode--project-find (dir)
  "Return the Global project plist containing DIR, or nil.
For `project-find-functions'.  DIR may be unrelated to the current
buffer (e.g. `project-switch-project'); in that case the lookup
neither reads nor sets the buffer-local `gtags-mode--plist', and
connection-local variables are applied in a temporary buffer."
  (let ((dir (file-name-as-directory (expand-file-name dir))))
    (if (string= dir (file-name-as-directory (expand-file-name default-directory)))
	(gtags-mode--local-plist dir)
      ;; No `file-truename': it is expensive over TRAMP, and on a miss
      ;; `global --print-dbpath' returns the resolved root, which
      ;; `gtags-mode--create-plist' matches against existing plists.
      (or (gtags-mode--get-plist dir)
	  (and (not (gethash dir gtags-mode--no-root-dirs))
	       ;; Not cached when missing: the directory may appear later.
	       (file-directory-p dir)
	       (or (with-temp-buffer
		     (setq default-directory dir)
		     (gtags-mode--set-connection-locals)
		     (gtags-mode--create-plist dir))
		   (ignore (puthash dir t gtags-mode--no-root-dirs))))))))

(defun gtags-mode--list-completions (prefix)
  "Get the list of completions for PREFIX.
When PREFIX is nil or empty; return the entire list of
completions.  Both results are cached in the project plist:
`:cache' holds the entire list and `:prefix-cache' a hash table
keyed on (PREFIX . `completion-ignore-case').  Nil results are
not cached."
  (let* ((plist (or (gtags-mode--local-plist default-directory)
		    (error "Calling `gtags-mode--list-completions' with no gtags-mode--plist")))
	 (root (file-local-name (plist-get plist :gtagsroot))))
    (if (and (stringp prefix)
	     (not (string-blank-p prefix))) ;; not match empty or only -
	(let ((prefix (substring-no-properties prefix)))
	  (with-memoization
	      (gethash (cons prefix completion-ignore-case)
		       (with-memoization (plist-get gtags-mode--plist :prefix-cache)
			 (make-hash-table :test #'equal)))
	    (gtags-mode--exec-sync
	     "--directory" root
	     (if completion-ignore-case "--ignore-case" "--match-case")
	     "--through" "--completion" "--" prefix)))
      (with-memoization (plist-get gtags-mode--plist :cache)
	(gtags-mode--exec-sync "--directory" root "--through" "--completion")))))

(defun gtags-mode--filter-find-symbol (args symbol creator)
  "Run `gtags-mode--exec-sync' with ARGS on SYMBOL and filter output with CREATOR.
Returns the results as a list of CREATORS outputs similar to
`mapcar'.  Creator should be a function with 4 input arguments:
name, code, file, line."
  (if-let* ((root (plist-get (gtags-mode--local-plist default-directory) :gtagsroot)))
      (delete nil (mapcar
		   (lambda (line)
		     (when (string-match gtags-mode--output-format-regex line)
		       (funcall creator
				(match-string-no-properties 2 line)   ;; name
				(match-string-no-properties 4 line)   ;; code
				(concat root (match-string-no-properties 1 line)) ;; file
				(string-to-number (match-string-no-properties 3 line))))) ;; line
		   (apply #'gtags-mode--exec-sync
			  (append gtags-mode--output-format-options args
				  ;; "--" ends options: SYMBOL may start with "-".
				  `("--directory" ,(file-local-name root) "--" ,symbol)))))
    (error "Calling gtags-mode--filter-find-symbol without GTAGSROOT")))

(defun gtags-mode--update-buffers-plist ()
  "Refresh state after `gtags-mode-create' or `gtags-mode-update'.
Clear `gtags-mode--no-root-dirs' and the caches of all projects, and
recompute `gtags-mode--plist' in file buffers where it is nil."
  (clrhash gtags-mode--no-root-dirs)
  ;; `gtags-mode-create' may rebuild a project other than the one of
  ;; the parent buffer, whose caches the sentinel clears.
  (dolist (plist gtags-mode--alist)
    (plist-put plist :cache nil)
    (plist-put plist :prefix-cache nil))
  (gtags-mode--message 2 "Updating all buffers")
  (dolist (buff (buffer-list))
    (with-current-buffer buff
      (when (and buffer-file-name (not gtags-mode--plist))
	(gtags-mode--set-connection-locals)
	(kill-local-variable 'gtags-mode--plist) ;; kill the local to reset it
	(gtags-mode--local-plist default-directory)))))

;; Interactive commands ==============================================

;;;###autoload
(defun gtags-mode-create (root-dir)
  "Create a GLOBAL GTAGS file in ROOT-DIR asynchronously."
  (interactive "DCreate GLOBAL files in directory: ")
  (when-let* ((default-directory root-dir)
	      (pr (gtags-mode--exec-async 'gtags-mode--gtags)))
    (process-put pr :extra-sentinel #'gtags-mode--update-buffers-plist)))

;;;###autoload
(defun gtags-mode-update ()
  "Update the Global database of the current project asynchronously.
Signal a `user-error' when the buffer is not in a Global project."
  (interactive)
  (unless (gtags-mode--local-plist default-directory)
    (user-error "No Global project for %s" default-directory))
  (when-let* ((default-directory (plist-get gtags-mode--plist :gtagsroot))
	      (pr (gtags-mode--exec-async 'gtags-mode--global "--update")))
    (process-put pr :extra-sentinel #'gtags-mode--update-buffers-plist)))

;; Hooks =============================================================
(defun gtags-mode--after-save-hook ()
  "Update the Global database for the saved file asynchronously.
Run `global --single-update' on the file.  Look up the project if not
done yet: a new buffer acquires variable `buffer-file-name' only on
its first save."
  (when (and buffer-file-name
	     (gtags-mode--local-plist default-directory))
    (when-let* ((default-directory (plist-get gtags-mode--plist :gtagsroot))
		(true-file-name gtags-mode--true-file-name))
      ;; The sentinel clears the project caches.
      (gtags-mode--exec-async
       'gtags-mode--global "--single-update" (file-relative-name true-file-name)))))

;; xref integration ==================================================
(defun gtags-mode--xref-find-symbol (args symbol)
  "Run GNU Global to create xref input list with ARGS on SYMBOL.
Return as a list of xref location objects."
  (gtags-mode--filter-find-symbol
   args symbol
   (lambda (_name code file line)
     (xref-make code (xref-make-file-location file line 0)))))

(cl-defmethod xref-backend-identifier-completion-table ((_backend (head :gtagsroot)))
  "List all symbols."
  (gtags-mode--list-completions nil))

(cl-defmethod xref-backend-definitions ((_backend (head :gtagsroot)) symbol)
  "List all definitions for SYMBOL."
  (gtags-mode--xref-find-symbol '("--definition") symbol))

(cl-defmethod xref-backend-references ((_backend (head :gtagsroot)) symbol)
  "List all references to SYMBOL."
  (gtags-mode--xref-find-symbol '("--reference" "--symbol") symbol))

(cl-defmethod xref-backend-apropos ((_backend (head :gtagsroot)) pattern)
  "List the definitions of the symbols matching PATTERN.
PATTERN follows `xref-find-apropos': a regexp, or words of which a
symbol must contain at least two (or the only one).  global selects
candidates with an extended regexp; `xref-apropos-regexp' filters
them.  Regexps using Emacs-only syntax (e.g. \\_<) find nothing.
Case folding follows `case-fold-search'."
  (require 'apropos)                    ;; for `xref-apropos-regexp'
  (let* ((regexp (xref-apropos-regexp pattern))
	 (candidates
	  (if (string-equal (regexp-quote pattern) pattern)
	      ;; Word list: symbols containing any of the words.
	      (concat "("
		      (mapconcat
		       (lambda (word)
			 (replace-regexp-in-string "[](){}|.*+?^$\\[]" "\\\\\\&" word))
		       (split-string pattern "[ \t]+" t) "|")
		      ")")
	    pattern)))
    (gtags-mode--filter-find-symbol
     (list "--definition" (if case-fold-search "--ignore-case" "--match-case"))
     candidates
     (lambda (name code file line)
       (when (string-match-p regexp name)
	 (xref-make code (xref-make-file-location file line 0)))))))

;; imenu integration =================================================
(defun gtags-mode--imenu-goto-function (_name line)
  "Go to LINE; NAME is ignored.
Function of the imenu entries built by `gtags-mode--imenu-advice'."
  (funcall-interactively #'goto-line line))

(defun gtags-mode--imenu-advice ()
  "Return the imenu index of the current buffer from Global, or nil.
On nil, the major mode's index function runs."
  (when-let* (((and buffer-file-name (gtags-mode--local-plist default-directory)))
	      (true-file-name gtags-mode--true-file-name))
    ;; global resolves --file against --directory, i.e. the root.
    (gtags-mode--filter-find-symbol
     '("--file") (file-relative-name true-file-name
				     (plist-get gtags-mode--plist :gtagsroot))
     (lambda (name _code _file line)
       (list name line #'gtags-mode--imenu-goto-function)))))

(defun gtags-mode--imenu-setup ()
  "Install `gtags-mode--imenu-advice' in the current buffer.
imenu calls the value of `imenu-create-index-function', which major
modes set buffer-locally, so the advice goes on the local value.  Runs
from `after-change-major-mode-hook' to wrap the mode's function."
  (add-function :before-until (local 'imenu-create-index-function)
		#'gtags-mode--imenu-advice))

(defun gtags-mode--imenu-teardown ()
  "Remove `gtags-mode--imenu-advice' from the current buffer."
  ;; The check avoids creating a local binding in untouched buffers.
  (when (local-variable-p 'imenu-create-index-function)
    (remove-function (local 'imenu-create-index-function)
		     #'gtags-mode--imenu-advice)))

;; project integration ===============================================

(cl-defmethod project-root ((project (head :gtagsroot)))
  "Root for PROJECT."
  (plist-get project :gtagsroot))

(cl-defmethod project-files ((project (head :gtagsroot)) &optional dirs)
  "List files inside all the PROJECT or in DIRS if specified."
  (let* ((default-directory (project-root project))
	 (dirs (or (delete-dups dirs) `(,default-directory)))
	 (results (if project-files-relative-names
		      (gtags-mode--exec-sync
		       "--path-style=relative" "--path"
		       (string-remove-prefix default-directory (car dirs)))
		    (mapcan
		     (lambda (dir)
		       (when (string-prefix-p default-directory dir)
			 (mapcar (lambda (file)
				   (expand-file-name file default-directory))
				 (gtags-mode--exec-sync
				  "--path-style=through" "--path"
				  (string-remove-prefix default-directory dir)))))
		     dirs))))
    (if (length> dirs 1) (delete-dups results) results)))

(cl-defmethod project-buffers ((project (head :gtagsroot)))
  "Return the list of all live buffers that belong to PROJECT."
  (delq nil
	(mapcar (lambda (buff)
		  (cond
		   ((eq (buffer-local-value 'gtags-mode--plist buff) project) buff)
		   ((local-variable-p 'gtags-mode--plist buff) nil)
		   (t (with-current-buffer buff
			(when (eq (gtags-mode--local-plist default-directory) project)
			  (current-buffer))))))
		(buffer-list))))

;; Completion-at-point-function (capf) ===============================
(defun gtags-mode-completion-function ()
  "Complete the symbol at point with Global symbols.
For `completion-at-point-functions'; non-exclusive."
  (if (gtags-mode--local-plist default-directory)
      (when-let* ((bounds (bounds-of-thing-at-point 'symbol)))
	(list (car bounds) (point)
	      (completion-table-dynamic #'gtags-mode--list-completions)
	      :exclusive 'no))))

(defmacro gtags-mode--with-feature (feature &rest body)
  "Evaluate BODY when FEATURE is in `gtags-mode-features'."
  (declare (indent 1) (debug t))
  `(when (memq ,feature gtags-mode-features)
     ,@body))

;;;###autoload
(define-minor-mode gtags-mode
  "Use GNU Global as backend for project, xref, capf and imenu.
When the buffer is not in a global-project, then all these tools
rely on their original or user configured default behavior."
  :global t
  ;; Only in buffers of a Global project.
  :lighter (:eval (and gtags-mode--plist gtags-mode-lighter))
  (clrhash gtags-mode--no-root-dirs)
  (cond
   (gtags-mode
    (gtags-mode--with-feature 'project
      (add-hook 'project-find-functions #'gtags-mode--project-find))
    (gtags-mode--with-feature 'xref
      (add-hook 'xref-backend-functions #'gtags-mode--local-plist))
    (gtags-mode--with-feature 'completion
      (add-hook 'completion-at-point-functions #'gtags-mode-completion-function))
    (gtags-mode--with-feature 'hooks
      (add-hook 'after-save-hook #'gtags-mode--after-save-hook))
    (gtags-mode--with-feature 'imenu
      (require 'imenu)
      (add-hook 'after-change-major-mode-hook #'gtags-mode--imenu-setup)
      (dolist (buff (buffer-list))
	(with-current-buffer buff (gtags-mode--imenu-setup)))))
   (t
    (remove-hook 'project-find-functions #'gtags-mode--project-find)
    (remove-hook 'xref-backend-functions #'gtags-mode--local-plist)
    (remove-hook 'completion-at-point-functions #'gtags-mode-completion-function)
    (remove-hook 'after-save-hook #'gtags-mode--after-save-hook)
    (remove-hook 'after-change-major-mode-hook #'gtags-mode--imenu-setup)
    (when-let* ((pr gtags-mode--pr-async))
      ;; No sentinel: it would report the kill as an error and run the
      ;; extra sentinel.
      (set-process-sentinel pr #'ignore)
      (delete-process pr)
      (kill-buffer (process-buffer pr))
      (setq gtags-mode--pr-async nil))
    ;; Plists and caches go stale while the mode is off.
    (setq gtags-mode--alist nil)
    (dolist (buff (buffer-list))
      (with-current-buffer buff
	(gtags-mode--imenu-teardown)
	(kill-local-variable 'gtags-mode--plist)
	(kill-local-variable 'gtags-mode--true-file-name))))))

(provide 'gtags-mode)
;;; gtags-mode.el ends here
