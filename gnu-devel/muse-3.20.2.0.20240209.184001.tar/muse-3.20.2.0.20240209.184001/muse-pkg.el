;; Generated package description from muse.el  -*- no-byte-compile: t -*-
(define-package "muse" "3.20.2.0.20240209.184001" "Authoring and publishing tool for Emacs" 'nil :commit "8710adde8fef5fb570e23383900f5cfa1d39060c" :authors '(("John Wiegley" . "johnw@gnu.org")) :maintainer '("Michael Olson" . "mwolson@gnu.org") :keywords '("hypermedia") :url "http://mwolson.org/projects/EmacsMuse.html")
