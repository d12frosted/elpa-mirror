;; Generated package description from gnus-mock.el  -*- no-byte-compile: t -*-
(define-package "gnus-mock" "0.5.0.20210503.105756" "Mock Gnus installation for testing" 'nil :commit "11f3af99568f9e7ff8728105e4d78e23fb6a4379" :url "https://elpa.gnu.org/packages/gnus-mock.html" :authors '(("Eric Abrahamsen" . "eric@ericabrahamsen.net")) :maintainer '("Eric Abrahamsen" . "eric@ericabrahamsen.net"))
