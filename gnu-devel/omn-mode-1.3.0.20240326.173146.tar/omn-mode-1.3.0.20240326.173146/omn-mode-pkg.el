;; Generated package description from omn-mode.el  -*- no-byte-compile: t -*-
(define-package "omn-mode" "1.3.0.20240326.173146" "Support for OWL Manchester Notation" 'nil :commit "a8533cf40de37ed06b522798eb7fb82114128b64" :url "https://elpa.gnu.org/packages/omn-mode.html" :authors '(("Phillip Lord" . "phillip.lord@russet.org.uk")) :maintainer '("Phillip Lord" . "phillip.lord@russet.org.uk"))
