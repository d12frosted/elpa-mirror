;; Generated package description from multi-mode.el  -*- no-byte-compile: t -*-
(define-package "multi-mode" "1.14.0.20240919.113013" "support for multiple major modes" 'nil :commit "aa25809db7af993011247d335482400e49d46670" :authors '(("Dave Love" . "fx@gnu.org")) :maintainer '("Dave Love" . "fx@gnu.org") :keywords '("languages" "extensions" "files") :url "http://www.loveshack.ukfsn.org/emacs")
