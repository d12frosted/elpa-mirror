<?php
bareword
