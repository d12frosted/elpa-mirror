;; Generated package description from dape.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "dape" "0.28.0.0.20261112.1" "Debug Adapter Protocol for Emacs" '((emacs "29.1") (jsonrpc "1.0.25")) :commit "1951daef650f61b29019428a83ecd84315c5ba97" :maintainer '("Daniel Pettersson" . "daniel@dpettersson.net") :url "https://github.com/svaante/dape")
