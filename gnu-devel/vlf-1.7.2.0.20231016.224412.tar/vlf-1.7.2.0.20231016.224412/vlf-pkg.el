;; Generated package description from vlf.el  -*- no-byte-compile: t -*-
(define-package "vlf" "1.7.2.0.20231016.224412" "View Large Files" '((emacs "24.4")) :commit "6192573ee088079bf1f81abc2bf2a370a5a92397" :url "https://elpa.gnu.org/packages/vlf.html" :maintainer '("Andrey Kotlarski" . "m00naticus@gmail.com") :keywords '("large files" "utilities"))
