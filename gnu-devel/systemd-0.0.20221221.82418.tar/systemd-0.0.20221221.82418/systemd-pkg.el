;; Generated package description from systemd.el  -*- no-byte-compile: t -*-
(define-package "systemd" "0.0.20221221.82418" "Interface to Systemd" '((cl-lib "0.5")) :commit "a0a88926a101fadaa269c0ddc3a9b8de80050a31" :url "https://elpa.gnu.org/packages/systemd.html" :authors '(("Mario Lang" . "mlang@delysid.org")) :maintainer '("Mario Lang" . "mlang@delysid.org") :keywords '("comm"))
