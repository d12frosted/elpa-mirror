ffs
===

This package provides a minor mode for simple plain text presentations
in Emacs where the slides are separated using the `page-delimiter`, by
default the form feed character (`^L`).

- Package name (GNU ELPA): `ffs`
- Manual: <https://www.shemshak.org/~amin/ffs/ffs.html>
- NEWS: <https://www.shemshak.org/~amin/ffs/NEWS>
- Git repository: <https://www.shemshak.org/~amin/ffs>
- Backronyms: fabulous foolproof slides - for freedom's sake - ffs flips slides
