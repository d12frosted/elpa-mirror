;; Generated package description from smalltalk-mode.el  -*- no-byte-compile: t -*-
(define-package "smalltalk-mode" "4.0.0.20221221.82225" "Major mode for the GNU Smalltalk programming language" 'nil :commit "f2e976fd395f36c95b9b0b44a22e027232f550ac" :url "https://elpa.gnu.org/packages/smalltalk-mode.html" :maintainer '("Derek Zhou" . "derek@3qin.us"))
