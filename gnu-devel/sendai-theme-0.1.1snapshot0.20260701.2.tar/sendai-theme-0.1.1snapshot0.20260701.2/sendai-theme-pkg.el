;; Generated package description from sendai-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sendai-theme" "0.1.1snapshot0.20260701.2" "A cool blue color theme" '((emacs "27.1")) :commit "cccc533de1f626a9e4213820bad73ae9200cb04f" :keywords '("theme") :url "https://sr.ht/~jimporter/sendai-theme/")
