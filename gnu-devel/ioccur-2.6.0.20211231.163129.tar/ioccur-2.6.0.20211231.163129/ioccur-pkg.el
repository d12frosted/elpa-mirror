;; Generated package description from ioccur.el  -*- no-byte-compile: t -*-
(define-package "ioccur" "2.6.0.20211231.163129" "Incremental occur" '((emacs "24") (cl-lib "0.5")) :commit "253f69b17187b99b59b60f46a2a72c8c1802b342" :authors '(("Thierry Volpiatto" . "thievol@posteo.net")) :maintainer '("Thierry Volpiatto" . "thievol@posteo.net") :url "https://github.com/thierryvolpiatto/ioccur")
