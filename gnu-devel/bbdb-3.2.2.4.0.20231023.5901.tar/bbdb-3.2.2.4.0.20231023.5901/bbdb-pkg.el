;; Generated package description from bbdb.el  -*- no-byte-compile: t -*-
(define-package "bbdb" "3.2.2.4.0.20231023.5901" "Big Brother DataBase" '((emacs "24") (cl-lib "0.5")) :commit "641ff1f309e65ac8bd9794bd5f72cfc9ffc297a4" :url "https://elpa.gnu.org/packages/bbdb.html" :maintainer '("Roland Winkler" . "winkler@gnu.org"))
