;; Generated package description from dape.el  -*- mode: lisp-data; no-byte-compile: t; lexical-binding:t -*-
(define-package "dape" "0.28.0.0.20261113.2" "Debug Adapter Protocol for Emacs" '((emacs "29.1") (jsonrpc "1.0.25")) :commit "d4c2a119198362103f44a38e864da59d1d56ef16" :maintainer '("Daniel Pettersson" . "daniel@dpettersson.net") :url "https://github.com/svaante/dape")
