;; Generated package description from ilist.el  -*- no-byte-compile: t -*-
(define-package "ilist" "0.4.0.20240807.41050" "Display a list in an ibuffer way." 'nil :commit "8f221c58a8c694112738e346c630d4d49a41d967" :authors '(("Durand" . "mmemmew@gmail.com")) :maintainer '("Durand" . "mmemmew@gmail.com") :keywords '("convenience") :url "https://gitlab.com/mmemmew/ilist")
