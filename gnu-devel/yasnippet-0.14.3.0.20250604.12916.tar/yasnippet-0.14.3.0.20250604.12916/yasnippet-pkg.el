;; Generated package description from yasnippet.el  -*- no-byte-compile: t -*-
(define-package "yasnippet" "0.14.3.0.20250604.12916" "Yet another snippet extension for Emacs" '((cl-lib "0.5") (emacs "24.4")) :commit "c1e6ff23e9af16b856c88dfaab9d3ad7b746ad37" :maintainer '("Noam Postavsky" . "npostavs@gmail.com") :keywords '("convenience" "emulation") :url "http://github.com/joaotavora/yasnippet")
