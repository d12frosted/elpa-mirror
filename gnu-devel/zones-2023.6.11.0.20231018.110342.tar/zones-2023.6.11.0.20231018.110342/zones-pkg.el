;; Generated package description from zones.el  -*- no-byte-compile: t -*-
(define-package "zones" "2023.6.11.0.20231018.110342" "Zones of text - like multiple regions" 'nil :commit "f7e1b641ee8360ddb8bae1711d3978863efa692d" :maintainer '("Drew Adams" . "drew.adams@oracle.com") :keywords '("narrow" "restriction" "widen" "region" "zone") :url "https://elpa.gnu.org/packages/zones.html")
