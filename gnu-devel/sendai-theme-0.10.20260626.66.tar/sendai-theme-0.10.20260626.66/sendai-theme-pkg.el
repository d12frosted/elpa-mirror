;; Generated package description from sendai-theme.el  -*- no-byte-compile: t; lexical-binding:t -*-
(define-package "sendai-theme" "0.10.20260626.66" "A cool blue color theme" '((emacs "27.1")) :commit "4686c5efae93cf413399f3d1e79f089a2d169d67" :keywords '("theme") :url "https://sr.ht/~jimporter/sendai-theme/")
