;; Generated package description from perl-doc.el  -*- no-byte-compile: t -*-
(define-package "perl-doc" "0.82.0.20250606.121940" "Read Perl documentation" '((emacs "27")) :commit "9ac4eeb55b554601c2f0205f099645806a05dc82" :authors '(("Harald Jörg" . "haj@posteo.de")) :maintainer '("Harald Jörg" . "haj@posteo.de") :keywords '("languages") :url "https://github.com/HaraldJoerg/emacs-perl-doc")
