;;; pst-slpe.el --- AUCTeX style for `pst-slpe.sty'  -*- lexical-binding: t; -*-

;; Copyright (C) 2007, 2020 Free Software Foundation, Inc.

;; Author: Holger Sparr <holger.sparr@gmx.net>
;; Created: 21 Jun 2007
;; Keywords: latex, pstricks, auctex, emacs

;; This file is part of AUCTeX.

;; AUCTeX is free software; you can redistribute it and/or modify it
;; under the terms of the GNU General Public License as published by the
;; Free Software Foundation; either version 3, or (at your option) any
;; later version.

;; AUCTeX is distributed in the hope that it will be useful, but WITHOUT
;; ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
;; FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
;; for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Commentary:

;; This file adds support for `pst-slpe.sty'.

;;; TODO:
;;
;; -- 

;;; Code:

(require 'tex)

;; Silence the compiler:
(defvar LaTeX-pst-fillstyle-list)
(defvar LaTeX-pst-parameters-completion-regexp)
(defvar LaTeX-pst-parameters-name-list)

;;; Parameters
(defvar LaTeX-pstslpe-parameters-name-list
  '("slopeangle" "slopecenter" "slopecolors" "slopebegin" "slopeend"
    "sloperadius" "slopesteps")
  "A list of parameter names in pst-slpe.")

;;; Aliases
(defvaralias 'LaTeX-pst-slopebegin-list 'LaTeX-pst-color-list)
(defvaralias 'LaTeX-pst-slopeend-list 'LaTeX-pst-color-list)

;;; Define hook
(TeX-add-style-hook
 "pst-slpe"
 (lambda ()
   (TeX-run-style-hooks
    "pstricks")
   (unless (member "slope" LaTeX-pst-fillstyle-list)
     (setq LaTeX-pst-fillstyle-list
           (append LaTeX-pst-fillstyle-list
                   '("slope" "slopes" "ccslope" "ccslopes" "radslope"
                     "radslopes")))
     (setq LaTeX-pst-parameters-completion-regexp
           (concat
            (substring LaTeX-pst-parameters-completion-regexp 0 -2)
            "\\|slopebegin\\|slopeend\\)")))
   (make-local-variable 'LaTeX-pst-parameters-name-list)
   (setq LaTeX-pst-parameters-name-list
         (append LaTeX-pstslpe-parameters-name-list
                 LaTeX-pst-parameters-name-list)))
 TeX-dialect)

;;; pst-slpe.el ends here
