;; Generated package description from hcel.el  -*- no-byte-compile: t -*-
(define-package "hcel" "1.0.0.0.20221012.11633" "Haskell codebase explorer / cross referencer" '((emacs "28")) :commit "e032d09d659f7bc41f864a8ef66940e16b69868e" :authors '(("Yuchen Pei" . "id@ypei.org")) :maintainer '("Yuchen Pei" . "id@ypei.org") :keywords '("haskell") :url "https://g.ypei.me/hc.el.git")
